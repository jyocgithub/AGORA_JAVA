package aed.hotel;

import es.upm.aedlib.indexedlist.ArrayIndexedList;
import es.upm.aedlib.indexedlist.IndexedList;

/**
 * Implementa el interfaz Hotel, para realisar y cancelar reservas en un hotel,
 * y para realisar preguntas sobre reservas en vigor.
 */
public class MiHotel implements Hotel {
	/**
	 * Usa esta estructura para guardar las habitaciones creados.
	 */
	private IndexedList<Habitacion> habitaciones;

	@Override
	public void anadirHabitacion(Habitacion habitacion) {
		int i = buscaIndiceHab(habitacion.getNombre());
		if (i != -1) {
			throw new IllegalArgumentException();
		} else {
			habitaciones.add(0, habitacion);
		}
	}

	private int buscaIndiceHab(String nombre) {
		// busqueda binaria de un nombre de habitacion entre las habitaciones
		int middleIndex = 0;
		int firstIndex = 0;
		int lastIndex = habitaciones.size() - 1;

		while (firstIndex <= lastIndex) {
//			System.out.println(nombre + "." + firstIndex + "." + lastIndex + "." + middleIndex);
			if (habitaciones.get(middleIndex).getNombre().compareTo(nombre) == 0) {
				return middleIndex;
			} else if (habitaciones.get(middleIndex).getNombre().compareTo(nombre) < 0) {
				firstIndex = middleIndex + 1;
			} else if (habitaciones.get(middleIndex).getNombre().compareTo(nombre) > 0) {
				lastIndex = middleIndex - 1;
			}
		}
		return -1;
	}

	private Habitacion buscaObjetoHab(String nombre) {
		// busqueda binaria de un Objeto de habitacion entre las habitaciones
		int firstIndex = 0;
		int lastIndex = habitaciones.size() - 1;
		int middleIndex = (firstIndex + lastIndex) / 2;
		if (firstIndex == 0 && lastIndex == 0) {
			middleIndex = 0;
		} else {
			middleIndex = (firstIndex + lastIndex) / 2;
		}

		while (firstIndex <= lastIndex) {
			if (habitaciones.get(middleIndex).getNombre().compareTo(nombre) == 0) {
				return habitaciones.get(middleIndex);
			} else if (habitaciones.get(middleIndex).getNombre().compareTo(nombre) < 0) {
				firstIndex = middleIndex + 1;
			} else if (habitaciones.get(middleIndex).getNombre().compareTo(nombre) > 0) {
				lastIndex = middleIndex - 1;
			}
		}
		return null;
	}

	private String buscaHab(String nombre) {
		int i = buscaIndiceHab(nombre);
		if (i != -1) {
			return nombre;
		} else {
			throw new IllegalArgumentException();
		}
	}

	private boolean conflictos(String diaEntrada1, String diaEntrada2, String diaSalida1, String diaSalida2) {
//		if (diaSalida1.compareTo(diaEntrada2) > 0 || diaSalida2.compareTo(diaEntrada1) > 0) {
//			return true;
//		} else {
//			return false;
//		}
		return diaSalida1.compareTo(diaEntrada2) > 0 || diaSalida2.compareTo(diaEntrada1) > 0;

	}

	@Override
	public boolean reservaHabitacion(Reserva reserva) throws IllegalArgumentException {
//		int i = 0;

		String nombrehabitacion = buscaHab(reserva.getHabitacion());
		Habitacion habitacion = buscaObjetoHab(nombrehabitacion);
		return añadirReserva(reserva, habitacion.getReservas());

	}

	private boolean añadirReserva(Reserva r, IndexedList<Reserva> rs) {
		int i = 0;

		boolean existeYaUnaReservaIgual = false;
		for (i = 0; i < rs.size() - 1 && existeYaUnaReservaIgual == false; i++) {
			if (conflictos(r.getDiaEntrada(), rs.get(i).getDiaEntrada(), r.getDiaSalida(), rs.get(i).getDiaSalida())) {
				existeYaUnaReservaIgual = true;
			}
		}
		if (!existeYaUnaReservaIgual) {
			rs.add(i, r);
		}
		return !existeYaUnaReservaIgual;
	}

	@Override
	public boolean cancelarReserva(Reserva reserva) {

		Habitacion habitacion = buscaObjetoHab(reserva.getHabitacion());
		if (habitacion == null) {
			throw new IllegalArgumentException();
		}
		boolean exito = habitacion.getReservas().remove(reserva);

		return exito;
	}

	@Override
	public IndexedList<Habitacion> disponibilidadHabitaciones(String diaEntrada, String diaSalida) {

		IndexedList<Habitacion> habitacionesDisponibles = new ArrayIndexedList<>();
		int pos = 0;
		// miramos una a una cada habitacion
		for (int i = 0; i < habitaciones.size(); i++) {
			Habitacion habitacion = habitaciones.get(i);

			boolean hayreserva = false;
			// miramos una a una cada reserva de la habitacion
			for (int j = 0; j < habitacion.getReservas().size() && hayreserva == false; j++) {
				Reserva reserva = habitacion.getReservas().get(j);
				if (!conflictos(reserva.getDiaEntrada(), diaEntrada, reserva.getDiaSalida(), diaSalida)) {
					hayreserva = true;
				}
			}
			if (!hayreserva) {
				habitacionesDisponibles.add(pos++, habitacion);
			}
		}
		return habitacionesDisponibles;
	}

	@Override
	public IndexedList<Reserva> reservasPorCliente(String dniPasaporte) {

		IndexedList<Reserva> habitacionesCliente = new ArrayIndexedList<>();
		int pos = 0;
		// miramos una a una cada habitacion
		for (int i = 0; i < habitaciones.size(); i++) {
			Habitacion habitacion = habitaciones.get(i);

			boolean hayreserva = false;
			// miramos una a una cada reserva de la habitacion
			for (int j = 0; j < habitacion.getReservas().size() && hayreserva == false; j++) {
				Reserva reserva = habitacion.getReservas().get(j);
				if (reserva.getDniPasaporte().equals(dniPasaporte)) {
					habitacionesCliente.add(pos++, reserva);
				}
			}
		}
		return habitacionesCliente;
	}

	@Override
	public IndexedList<Habitacion> habitacionesParaLimpiar(String hoyDia) {
//		 entrada fue antes que hoyDia y su salida es despues or igual a hoyDia.
		int pos = 0;
		IndexedList<Habitacion> habitacionesLimpiar = new ArrayIndexedList<>();
		// miramos una a una cada habitacion
		for (int i = 0; i < habitaciones.size(); i++) {
			Habitacion habitacion = habitaciones.get(i);

			boolean hayquelimpiar = false;
			// miramos una a una cada reserva de la habitacion
			for (int j = 0; j < habitacion.getReservas().size(); j++) {
				Reserva reserva = habitacion.getReservas().get(j);
				if (reserva.getDiaEntrada().compareTo(hoyDia) < 0 && reserva.getDiaSalida().compareTo(hoyDia) >= 0) {
					habitacionesLimpiar.add(pos++, habitacion);
				}
			}
		}

		return habitacionesLimpiar;
	}

	@Override
	public Reserva reservaDeHabitacion(String nombreHabitacion, String dia) {
		Habitacion habitacion = buscaObjetoHab(nombreHabitacion);
		Reserva reserva = null;

		for (int i = 0; i < habitacion.getReservas().size() && reserva == null; i++) {
			if (habitacion.getReservas().get(i).getDiaEntrada().equals(dia)) {
				reserva = habitacion.getReservas().get(i);
			}
		}
		return reserva;
	}

	/**
	 * Crea una instancia del hotel.
	 */
	public MiHotel() {
		// No se debe cambiar este codigo
		this.habitaciones = new ArrayIndexedList<>();
	}

}
