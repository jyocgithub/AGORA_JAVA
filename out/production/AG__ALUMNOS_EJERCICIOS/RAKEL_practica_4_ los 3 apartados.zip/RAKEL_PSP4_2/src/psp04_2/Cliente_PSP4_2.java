
package RAKEL_PSP4_2.src.psp04_2;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * @author rakel
 */
public class Cliente_PSP4_2 {

    public static void main(String[] args) throws ClassNotFoundException {
        Scanner sc = new Scanner(System.in);
        Scanner sc2 = new Scanner(System.in);
        ObjectInputStream lector = null;
        ObjectOutputStream escritor = null;
        Socket socket = null;
        try {

            socket = new Socket("localhost", 2223);

            escritor = new ObjectOutputStream(socket.getOutputStream());
            lector = new ObjectInputStream(socket.getInputStream()); // Abrimos los canales de E/S


            int accion = 0;

            do {
                System.out.println("\nMenu\n1.-LS\n2.-GET\n3.-Fin");
                accion = sc.nextInt();


                switch (accion) {
                    case 1:
                        escritor.writeObject("ls");

                        break;
                    case 2:
                        escritor.writeObject("get");

                        String mensaje = (String) lector.readObject();

                        System.out.println(mensaje);
                        String nombrefichero = sc2.nextLine();

                        escritor.writeObject(nombrefichero);

                        break;
                    case 3:
                        escritor.writeObject("exit");
                        break;
                    default:
                        System.out.println("Instruccion inválida");
                        break;
                }
            } while (accion != 3);


        } catch (IOException ex) {
            ex.printStackTrace();
        } finally {
            try {
                escritor.close();
                lector.close();
                socket.close();
            } catch (IOException ex) {
                ex.printStackTrace();
            }
        }

    }
}
