/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package RAKEL_PSP4_3.src.psp04_3;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * @author rakel
 */
public class Servidor_PSP4_3 {

    public static void main(String[] args) {

        ServerSocket servidor = null;
        Socket socket = null;
        int contador = 1;

        try {
            servidor = new ServerSocket(2223); // Creamos un ServerSocket en el puerto 2223
            System.out.println("Servidor Arrancado.");
            while (true) {
                System.out.println("Esperando llamada de conexion de algun cliente...");
                socket = servidor.accept(); // Esperamos una conexión
                System.out.println("Conectado con el cliente " + contador);
                HiloServidor_PSP4_2 hs = new HiloServidor_PSP4_2(socket, contador);
                hs.start();
                contador++;
            }
        } catch (IOException e) {
            e.printStackTrace();

        } finally {
            try {
                servidor.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}


class HiloServidor_PSP4_2 extends Thread {
    Socket socket;
    int numeroHilo;
    ObjectOutputStream escritor = null;

    ObjectInputStream lector = null;
    BufferedReader br = null;

    public HiloServidor_PSP4_2(Socket socket, int numeroHilo) {
        this.socket = socket;
        this.numeroHilo = numeroHilo;
    }

    public void run() {
        try {
            lector = new ObjectInputStream(socket.getInputStream()); // Abrimos los canales de E/S
            escritor = new ObjectOutputStream(socket.getOutputStream());

            boolean puedepasar = false;
            while (puedepasar == false) {
                puedepasar = estadoPre1();
            }

            estado1();

            // la continuacion de aqui es el estado  -1

        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            System.out.println("Fin de la conexion con el cliente  " + numeroHilo);
            try {
                escritor.close();
                lector.close();
                socket.close();
                if (br != null) {
                    br.close();
                }
            } catch (IOException ex) {
                Logger.getLogger(Servidor_PSP4_3.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    public boolean estadoPre1() {
        String nombre , password;
        try {
             nombre = (String) lector.readObject();
             password = (String) lector.readObject();
            if (nombre.equals("pepe") && password.equals("123")) {
                escritor.writeObject("OK");
                return true;
            }
            escritor.writeObject("KO");
        } catch (IOException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
        return false;

    }

    public void estado1() {
        String accion = "";
        boolean seguir = true;
        try {
            while (seguir) {

                accion = (String) lector.readObject();
                accion = accion.toLowerCase();

                switch (accion) {
                    case "ls":
                        estado2();
                        break;
                    case "get":
                        estado3();
                        break;
                    case "exit":
                        seguir = false;
                        break;
                }
            }

        } catch (IOException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }


    }


    public void estado3() {
        try {

            escritor.writeObject("escribe el nombre del fichero a mostrar:");
            String nombrefichero = (String) lector.readObject();
            estado4(nombrefichero);

        } catch (IOException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }


    public void estado4(String nombrefichero) {
        File archivo = new File(nombrefichero);
        if (archivo.exists()) {
            BufferedReader br = null;
            System.out.println("\n------- Inicio del archivo");
            try {
                br = new BufferedReader(new FileReader(archivo));

                String linea = br.readLine();
                while (linea != null) {
                    System.out.println(linea);
                    linea = br.readLine();
                }
            } catch (IOException ex) {
                ex.printStackTrace();
            } finally {
                try {
                    br.close();
                } catch (IOException ex) {
                    ex.printStackTrace();
                }
            }
            System.out.println("\n------- Fin del archivo");
        } else {
            System.out.println("\nArchivo inexistente");
        }
    }

    public void estado2() {
        try {
            ProcessBuilder obProBuil = new ProcessBuilder("ls", "-l");
            obProBuil.directory(new File("."));
            Process obProcesoHijo = obProBuil.start();

            InputStream obInpStr = obProcesoHijo.getInputStream();

            InputStreamReader obInpStrRea = new InputStreamReader(obInpStr);
            BufferedReader obBufRea = new BufferedReader(obInpStrRea);
            System.out.println("La ejecucion del proceso devuelve: ");

            String line;
            while ((line = obBufRea.readLine()) != null) {
                // Imprimo por pantalla lo que voy leyendo
                System.out.println(line);
            }
            System.out.println("\n------- Fin del directorio");

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}
