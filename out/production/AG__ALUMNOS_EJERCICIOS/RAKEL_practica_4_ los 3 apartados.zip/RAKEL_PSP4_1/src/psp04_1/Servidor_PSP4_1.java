/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package RAKEL_PSP4_1.src.psp04_1;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * @author rakel
 */
public class Servidor_PSP4_1 {

    public static void main(String[] args) {

        ServerSocket servidor;
        Socket socket = null;
        int contador = 1;

        try {
            servidor = new ServerSocket(2223); // Creamos un ServerSocket en el puerto 2223
            System.out.println("Servidor Arrancado.");
            while (true) {
                System.out.println("Esperando llamada de conexion de algun cliente...");
                socket = servidor.accept(); // Esperamos una conexión
        System.out.println("Conectado con el cliente " + contador );
                HiloServidor_PSP4_1 hs = new HiloServidor_PSP4_1(socket, contador);
                hs.start();
                contador++;
            }
        } catch (IOException e) {
            e.printStackTrace();

        }
    }
}


class HiloServidor_PSP4_1 extends Thread {
    Socket socket;
    int numeroHilo;
    ObjectOutputStream escritor = null;

    ObjectInputStream lector = null;
    BufferedReader br = null;

    public HiloServidor_PSP4_1(Socket socket, int numeroHilo) {
        this.socket = socket;
        this.numeroHilo = numeroHilo;
    }

    public void run() {
        try {
            lector = new ObjectInputStream(socket.getInputStream()); // Abrimos los canales de E/S
            escritor = new ObjectOutputStream(socket.getOutputStream());

            // recibo el nombre  del fichero que tengo que leer
            String fichero = (String) lector.readObject();

            // LEEMOS EL FICHERO QUE ME PIDEN Y LO ENVIAMOS AL CLIENTE
            File f = new File(fichero);

            if (f.exists()) {
                FileReader fr = new FileReader(f);
                br = new BufferedReader(fr);
                String linea = br.readLine();
                while (linea != null) {
                    escritor.writeObject(linea);

                    linea = br.readLine();
                }
                escritor.writeObject("--EOF--");
            } else {
                System.out.println("Error, el fichero no existe");
                escritor.writeObject("Error, el fichero no existe");
            }
        } catch (IOException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } finally {
            try {
                escritor.close();
                lector.close();
                socket.close();
                if (br != null) {
                    br.close();
                }
            } catch (IOException ex) {
                Logger.getLogger(Servidor_PSP4_1.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }


}
