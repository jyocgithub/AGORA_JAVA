
package RAKEL_PSP4_1.src.psp04_1;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author rakel
 */
public class Cliente_PSP4_1
{

    public static void main(String[] args) 
    {

        ObjectInputStream lector = null;
        ObjectOutputStream escritor = null;
        Socket socket = null;
        PrintWriter pw = null;
        try {

            socket = new Socket("localhost", 2223);

            escritor = new ObjectOutputStream(socket.getOutputStream());
            lector = new ObjectInputStream(socket.getInputStream()); // Abrimos los canales de E/S

            escritor.writeObject("cosas.txt");
            String linealeida = "";
            pw = new PrintWriter("fichero_recibido.txt");

            boolean sigo = true;

            while (!linealeida.equalsIgnoreCase("--EOF--") && sigo == true) 
            {

                linealeida = (String) lector.readObject();

                if (linealeida.equals("Error, el fichero no existe")) 
                {
                    // salir
                    sigo = false;
                } else 
                {
                    if (!linealeida.equals("--EOF--")) 
                    {
                        pw.println(linealeida);
                System.out.println("Leido " + linealeida);
                    }
                }


            }

        } catch (IOException ex) 
        {
            Logger.getLogger(Cliente_PSP4_1.class.getName()).log(Level.SEVERE, null, ex);
        } 
        catch (ClassNotFoundException ex) 
        {
            Logger.getLogger(Cliente_PSP4_1.class.getName()).log(Level.SEVERE, null, ex);
        } 
        finally 
        {
            try 
            {
                escritor.close();
                lector.close();
                socket.close();
                pw.close();
            } 
            catch (IOException ex) 
            {
                Logger.getLogger(Servidor_PSP4_1.class.getName()).log(Level.SEVERE, null, ex);
            }
        }

    }

//    try
//    {
//        cliente = new 
//    }
}
