package CARLOS_Agenda.ventanas;

import CARLOS_Agenda.basedeDatos.BasedeDatosAficiones;
import CARLOS_Agenda.basedeDatos.BasedeDatosContacto;
import CARLOS_Agenda.basedeDatos.BasedeDatosPrincipal;
import CARLOS_Agenda.clases.*;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

public class VentanaAnadir_modificarContacto extends JFrame {
	private JTextField texto_Apodo;
	private JTextField texto_Notas;

	private JTextField texto_nombre;
	private JTextField texto_Apellidos;
	private JTable tableTelefonos;
	VentanaAnadir_modificarContacto ventanaAnadir_modificar;
	String[] cabeceraTelefono = { "Numero", "Tipo" };
	String[][] datosTel;
	JScrollPane scrollPaneTelefonos;
	GridBagConstraints gbc_scrollPaneTelefonos;
	JPanel panel_gestion_contacto;
	private JButton btnAnadirTelefono;
	private JTable tableCorreos;
	private JTable tableAficiones;
	private JScrollPane scrollPaneCorreos;
	private JButton btnAnadir_Correo;
	ArrayList<Aficion> listaaficionesmaestras;
	private JButton btnAnadir_Aficion;
	private JScrollPane scrollPaneAficiones;
	private JComboBox comboBoxTipoContacto;
	private JButton btnAnadirContacto;
	private JComboBox comboBoxSexo;
	ventanas.VentanaInicial2 ventanaMadre;
	private JButton btnModificarContacto_1;
	private JButton btnEliminarTelefono;
	BasedeDatosPrincipal baseDeDatosPrincipal;
	BasedeDatosContacto baseDeDatosContacto;
	BasedeDatosAficiones baseDeDatosAficiones;
	private JButton btnEliminarCorreo;
	private JButton btnEliminarAficion;
	private JButton btnSalir;
	ArrayList<Telefono> ltel = new ArrayList<>();
	ArrayList<Correo> lCor = new ArrayList<>();
	ArrayList<Aficion> lAficiones = new ArrayList<>();
	int modo;

	Contacto contactoRecibido;

	public VentanaAnadir_modificarContacto(Contacto contactoRecibido, int modo, ventanas.VentanaInicial2 ventanaMadre) {
		this.ventanaMadre = ventanaMadre;
		this.modo = modo;
		this.contactoRecibido = contactoRecibido;
		ventanaAnadir_modificar = this;

		baseDeDatosPrincipal = new BasedeDatosPrincipal();
		baseDeDatosContacto = new BasedeDatosContacto();
		baseDeDatosAficiones = new BasedeDatosAficiones();

		initialize();
		pintarDatosContacto();
		pedirTipoContacto();
		rellenarJTableTel();
		rellenarJTableCorreo();
		rellenarJTableAficiones();
		eventos();
		elegirVisibilidad();
	}

	private void initialize() {

		setBounds(100, 100, 1014, 653);
		setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
		getContentPane().setLayout(new CardLayout(0, 0));
		setLocationRelativeTo(null);

		panel_gestion_contacto = new JPanel();
		getContentPane().add(panel_gestion_contacto, "name_4469919974522");
		GridBagLayout gbl_panel_gestion_contacto = new GridBagLayout();
		gbl_panel_gestion_contacto.columnWidths = new int[] { 91, 73, 0, 0, 0, 0, 109, 0 };
		gbl_panel_gestion_contacto.rowHeights = new int[] { 52, 0, 0, 0, 0, 0, 0, 0, 151, 0, 58 };
		gbl_panel_gestion_contacto.columnWeights = new double[] { 0.0, 1.0, 0.0, 0.0, 0.0, 1.0, 1.0, Double.MIN_VALUE };
		gbl_panel_gestion_contacto.rowWeights = new double[] { 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0 };
		panel_gestion_contacto.setLayout(gbl_panel_gestion_contacto);

		scrollPaneTelefonos = new JScrollPane(tableTelefonos);
		gbc_scrollPaneTelefonos = new GridBagConstraints();
		gbc_scrollPaneTelefonos.fill = GridBagConstraints.BOTH;
		gbc_scrollPaneTelefonos.gridheight = 5;
		gbc_scrollPaneTelefonos.gridwidth = 2;
		gbc_scrollPaneTelefonos.insets = new Insets(0, 0, 5, 0);
		gbc_scrollPaneTelefonos.gridx = 5;
		gbc_scrollPaneTelefonos.gridy = 1;
		panel_gestion_contacto.add(scrollPaneTelefonos, gbc_scrollPaneTelefonos);

		JLabel lblNewLabel = new JLabel("Tipo Contacto");
		GridBagConstraints gbc_lblNewLabel = new GridBagConstraints();
		gbc_lblNewLabel.insets = new Insets(0, 0, 5, 5);
		gbc_lblNewLabel.anchor = GridBagConstraints.EAST;
		gbc_lblNewLabel.gridx = 0;
		gbc_lblNewLabel.gridy = 0;
		panel_gestion_contacto.add(lblNewLabel, gbc_lblNewLabel);

		comboBoxTipoContacto = new JComboBox();
		comboBoxTipoContacto.setMaximumRowCount(4);
		GridBagConstraints gbc_comboBoxTipoContacto = new GridBagConstraints();
		gbc_comboBoxTipoContacto.insets = new Insets(0, 0, 5, 5);
		gbc_comboBoxTipoContacto.fill = GridBagConstraints.HORIZONTAL;
		gbc_comboBoxTipoContacto.gridx = 1;
		gbc_comboBoxTipoContacto.gridy = 0;
		panel_gestion_contacto.add(comboBoxTipoContacto, gbc_comboBoxTipoContacto);

		JLabel lblTelefonos = new JLabel("Telefonos");
		GridBagConstraints gbc_lblTelefonos = new GridBagConstraints();
		gbc_lblTelefonos.insets = new Insets(0, 0, 5, 5);
		gbc_lblTelefonos.gridx = 5;
		gbc_lblTelefonos.gridy = 0;
		panel_gestion_contacto.add(lblTelefonos, gbc_lblTelefonos);

		JLabel lblNombre = new JLabel("Nombre");
		GridBagConstraints gbc_lblNombre = new GridBagConstraints();
		gbc_lblNombre.insets = new Insets(0, 0, 5, 5);
		gbc_lblNombre.anchor = GridBagConstraints.EAST;
		gbc_lblNombre.gridx = 0;
		gbc_lblNombre.gridy = 2;
		panel_gestion_contacto.add(lblNombre, gbc_lblNombre);

		texto_nombre = new JTextField();
		GridBagConstraints gbc_texto_nombre = new GridBagConstraints();
		gbc_texto_nombre.insets = new Insets(0, 0, 5, 5);
		gbc_texto_nombre.fill = GridBagConstraints.HORIZONTAL;
		gbc_texto_nombre.gridx = 1;
		gbc_texto_nombre.gridy = 2;
		panel_gestion_contacto.add(texto_nombre, gbc_texto_nombre);
		texto_nombre.setColumns(10);

		JLabel lblApellidos = new JLabel("Apellidos");
		GridBagConstraints gbc_lblApellidos = new GridBagConstraints();
		gbc_lblApellidos.insets = new Insets(0, 0, 5, 5);
		gbc_lblApellidos.anchor = GridBagConstraints.EAST;
		gbc_lblApellidos.gridx = 0;
		gbc_lblApellidos.gridy = 3;
		panel_gestion_contacto.add(lblApellidos, gbc_lblApellidos);

		texto_Apellidos = new JTextField();
		GridBagConstraints gbc_texto_Apellidos = new GridBagConstraints();
		gbc_texto_Apellidos.insets = new Insets(0, 0, 5, 5);
		gbc_texto_Apellidos.fill = GridBagConstraints.HORIZONTAL;
		gbc_texto_Apellidos.gridx = 1;
		gbc_texto_Apellidos.gridy = 3;
		panel_gestion_contacto.add(texto_Apellidos, gbc_texto_Apellidos);
		texto_Apellidos.setColumns(10);

		JLabel lblApodo = new JLabel("Apodo");
		GridBagConstraints gbc_lblApodo = new GridBagConstraints();
		gbc_lblApodo.insets = new Insets(0, 0, 5, 5);
		gbc_lblApodo.anchor = GridBagConstraints.EAST;
		gbc_lblApodo.gridx = 0;
		gbc_lblApodo.gridy = 4;
		panel_gestion_contacto.add(lblApodo, gbc_lblApodo);

		texto_Apodo = new JTextField();
		GridBagConstraints gbc_texto_Apodo = new GridBagConstraints();
		gbc_texto_Apodo.insets = new Insets(0, 0, 5, 5);
		gbc_texto_Apodo.fill = GridBagConstraints.HORIZONTAL;
		gbc_texto_Apodo.gridx = 1;
		gbc_texto_Apodo.gridy = 4;
		panel_gestion_contacto.add(texto_Apodo, gbc_texto_Apodo);
		texto_Apodo.setColumns(10);

		JLabel lblSexo = new JLabel("Sexo");
		GridBagConstraints gbc_lblSexo = new GridBagConstraints();
		gbc_lblSexo.insets = new Insets(0, 0, 5, 5);
		gbc_lblSexo.anchor = GridBagConstraints.EAST;
		gbc_lblSexo.gridx = 0;
		gbc_lblSexo.gridy = 5;
		panel_gestion_contacto.add(lblSexo, gbc_lblSexo);

		comboBoxSexo = new JComboBox();
		GridBagConstraints gbc_comboBoxSexo = new GridBagConstraints();
		gbc_comboBoxSexo.insets = new Insets(0, 0, 5, 5);
		gbc_comboBoxSexo.fill = GridBagConstraints.HORIZONTAL;
		gbc_comboBoxSexo.gridx = 1;
		gbc_comboBoxSexo.gridy = 5;
		panel_gestion_contacto.add(comboBoxSexo, gbc_comboBoxSexo);
		comboBoxSexo.addItem("hombre");
		comboBoxSexo.addItem("mujer");

		JLabel lblNotas = new JLabel("Notas");
		GridBagConstraints gbc_lblNotas = new GridBagConstraints();
		gbc_lblNotas.insets = new Insets(0, 0, 5, 5);
		gbc_lblNotas.anchor = GridBagConstraints.EAST;
		gbc_lblNotas.gridx = 0;
		gbc_lblNotas.gridy = 6;
		panel_gestion_contacto.add(lblNotas, gbc_lblNotas);

		texto_Notas = new JTextField();
		GridBagConstraints gbc_texto_Notas = new GridBagConstraints();
		gbc_texto_Notas.insets = new Insets(0, 0, 5, 5);
		gbc_texto_Notas.fill = GridBagConstraints.HORIZONTAL;
		gbc_texto_Notas.gridx = 1;
		gbc_texto_Notas.gridy = 6;
		panel_gestion_contacto.add(texto_Notas, gbc_texto_Notas);
		texto_Notas.setColumns(10);

		btnAnadirTelefono = new JButton("Nuevo ");
		GridBagConstraints gbc_btnAnadirTelefono = new GridBagConstraints();
		gbc_btnAnadirTelefono.anchor = GridBagConstraints.ABOVE_BASELINE_LEADING;
		gbc_btnAnadirTelefono.insets = new Insets(0, 0, 5, 5);
		gbc_btnAnadirTelefono.gridx = 5;
		gbc_btnAnadirTelefono.gridy = 6;
		panel_gestion_contacto.add(btnAnadirTelefono, gbc_btnAnadirTelefono);

		btnEliminarTelefono = new JButton("Eliminar");
		GridBagConstraints gbc_btnEliminarTelefono = new GridBagConstraints();
		gbc_btnEliminarTelefono.insets = new Insets(0, 0, 5, 0);
		gbc_btnEliminarTelefono.gridx = 6;
		gbc_btnEliminarTelefono.gridy = 6;
		panel_gestion_contacto.add(btnEliminarTelefono, gbc_btnEliminarTelefono);

		JLabel lblAficiones = new JLabel("Aficiones");
		GridBagConstraints gbc_lblAficiones = new GridBagConstraints();
		gbc_lblAficiones.insets = new Insets(0, 0, 5, 5);
		gbc_lblAficiones.gridx = 1;
		gbc_lblAficiones.gridy = 7;
		panel_gestion_contacto.add(lblAficiones, gbc_lblAficiones);

		JLabel lblCorreos = new JLabel("Correos");
		GridBagConstraints gbc_lblCorreos = new GridBagConstraints();
		gbc_lblCorreos.insets = new Insets(0, 0, 5, 5);
		gbc_lblCorreos.gridx = 5;
		gbc_lblCorreos.gridy = 7;
		panel_gestion_contacto.add(lblCorreos, gbc_lblCorreos);

		scrollPaneAficiones = new JScrollPane();
		GridBagConstraints gbc_scrollPaneAficiones = new GridBagConstraints();
		gbc_scrollPaneAficiones.gridwidth = 2;
		gbc_scrollPaneAficiones.fill = GridBagConstraints.BOTH;
		gbc_scrollPaneAficiones.insets = new Insets(0, 0, 5, 5);
		gbc_scrollPaneAficiones.gridx = 1;
		gbc_scrollPaneAficiones.gridy = 8;
		panel_gestion_contacto.add(scrollPaneAficiones, gbc_scrollPaneAficiones);

		tableAficiones = new JTable();
		scrollPaneAficiones.setViewportView(tableAficiones);

		scrollPaneCorreos = new JScrollPane();
		GridBagConstraints gbc_scrollPaneCorreos = new GridBagConstraints();
		gbc_scrollPaneCorreos.fill = GridBagConstraints.BOTH;
		gbc_scrollPaneCorreos.gridwidth = 2;
		gbc_scrollPaneCorreos.insets = new Insets(0, 0, 5, 0);
		gbc_scrollPaneCorreos.gridx = 5;
		gbc_scrollPaneCorreos.gridy = 8;
		panel_gestion_contacto.add(scrollPaneCorreos, gbc_scrollPaneCorreos);

		tableCorreos = new JTable();
		scrollPaneCorreos.setViewportView(tableCorreos);

		btnAnadir_Aficion = new JButton("anadir");
		GridBagConstraints gbc_btnAnadir_Aficion = new GridBagConstraints();
		gbc_btnAnadir_Aficion.anchor = GridBagConstraints.WEST;
		gbc_btnAnadir_Aficion.insets = new Insets(0, 0, 5, 5);
		gbc_btnAnadir_Aficion.gridx = 1;
		gbc_btnAnadir_Aficion.gridy = 9;
		panel_gestion_contacto.add(btnAnadir_Aficion, gbc_btnAnadir_Aficion);

		btnEliminarAficion = new JButton("borrar");
		GridBagConstraints gbc_btnEliminarAficion = new GridBagConstraints();
		gbc_btnEliminarAficion.insets = new Insets(0, 0, 5, 5);
		gbc_btnEliminarAficion.gridx = 2;
		gbc_btnEliminarAficion.gridy = 9;
		panel_gestion_contacto.add(btnEliminarAficion, gbc_btnEliminarAficion);

		btnAnadir_Correo = new JButton("anadir");
		GridBagConstraints gbc_btnAnadir_Correo = new GridBagConstraints();
		gbc_btnAnadir_Correo.anchor = GridBagConstraints.WEST;
		gbc_btnAnadir_Correo.insets = new Insets(0, 0, 5, 5);
		gbc_btnAnadir_Correo.gridx = 5;
		gbc_btnAnadir_Correo.gridy = 9;
		panel_gestion_contacto.add(btnAnadir_Correo, gbc_btnAnadir_Correo);

		btnEliminarCorreo = new JButton("eliminar");
		GridBagConstraints gbc_btnEliminarCorreo = new GridBagConstraints();
		gbc_btnEliminarCorreo.insets = new Insets(0, 0, 5, 0);
		gbc_btnEliminarCorreo.gridx = 6;
		gbc_btnEliminarCorreo.gridy = 9;
		panel_gestion_contacto.add(btnEliminarCorreo, gbc_btnEliminarCorreo);

		btnAnadirContacto = new JButton("Anadir Contacto");

		GridBagConstraints gbc_btnAnadirContacto = new GridBagConstraints();
		gbc_btnAnadirContacto.insets = new Insets(0, 0, 0, 5);
		gbc_btnAnadirContacto.gridx = 2;
		gbc_btnAnadirContacto.gridy = 10;
		panel_gestion_contacto.add(btnAnadirContacto, gbc_btnAnadirContacto);

		btnModificarContacto_1 = new JButton("Modificar Contacto");
		GridBagConstraints gbc_btnModificarContacto_1 = new GridBagConstraints();
		gbc_btnModificarContacto_1.insets = new Insets(0, 0, 0, 5);
		gbc_btnModificarContacto_1.gridx = 5;
		gbc_btnModificarContacto_1.gridy = 10;
		panel_gestion_contacto.add(btnModificarContacto_1, gbc_btnModificarContacto_1);

		btnSalir = new JButton("Salir");
		GridBagConstraints gbc_btnSalir = new GridBagConstraints();
		gbc_btnSalir.gridx = 6;
		gbc_btnSalir.gridy = 10;
		panel_gestion_contacto.add(btnSalir, gbc_btnSalir);

		// acciones --------------------------------------------------
		comboBoxTipoContacto.addItem("Persona");
		comboBoxTipoContacto.addItem("Apodo");
		comboBoxTipoContacto.addItem("Empresa");
	}

	public void eventos() {

		btnAnadirTelefono.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				EventQueue.invokeLater(new Runnable() {
					@Override
					public void run() {
						try {

							pedirtel();
						} catch (Exception e) {
							e.printStackTrace();
						}
					}
				});
			}
		});

		btnEliminarTelefono.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				EventQueue.invokeLater(new Runnable() {
					@Override
					public void run() {
						try {

							borrarTelefono();

						} catch (Exception e) {
							e.printStackTrace();
						}
					}
				});
			}
		});

		btnAnadir_Correo.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				EventQueue.invokeLater(new Runnable() {
					@Override
					public void run() {
						try {

							pedirCorreo();

						} catch (Exception e) {
							e.printStackTrace();
						}
					}
				});
			}
		});

		btnEliminarCorreo.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				EventQueue.invokeLater(new Runnable() {
					@Override
					public void run() {
						try {

							borrarCorreo();

						} catch (Exception e) {
							e.printStackTrace();
						}
					}
				});
			}
		});

		btnAnadir_Aficion.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				EventQueue.invokeLater(new Runnable() {
					@Override
					public void run() {
						try {

							pedirAficion();

						} catch (Exception e) {
							e.printStackTrace();
						}
					}
				});
			}
		});

		btnEliminarAficion.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				EventQueue.invokeLater(new Runnable() {
					@Override
					public void run() {
						try {

							borrarAficionContacto();

						} catch (Exception e) {
							e.printStackTrace();
						}
					}
				});
			}
		});

		btnSalir.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				ventanaAnadir_modificar.dispose();
			}
		});

		btnAnadirContacto.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {

				String sexo = "";
				String apodo = texto_Apodo.getText();
				String nombre = texto_nombre.getText();
				String apellido = texto_Apellidos.getText();
				String tipoContacto = comboBoxTipoContacto.getSelectedItem().toString();
				String notas = texto_Notas.getText();
				int fila = comboBoxTipoContacto.getSelectedIndex();

				TipoContacto tipo = new TipoContacto(fila + 1, tipoContacto);

				if (tipoContacto.equalsIgnoreCase("Persona")) {
					sexo = comboBoxSexo.getSelectedItem().toString();
					ContactoPersona contactoNuevo = new ContactoPersona();
					contactoNuevo.setNombre(nombre);
					contactoNuevo.setApellidos(apellido);
					contactoNuevo.setSexo(sexo);
					contactoNuevo.setTipoContacto(tipo);
					contactoNuevo.setNotas(notas);
					contactoNuevo.setIdContacto(0);
					contactoNuevo.setListaAficiones(lAficiones);
					contactoNuevo.setListaCorreos(lCor);
					contactoNuevo.setListaTelefonos(ltel);
					baseDeDatosContacto.anadirContacto(contactoNuevo);
				}

				if (tipoContacto.equalsIgnoreCase("apodo")) {
					sexo = comboBoxSexo.getSelectedItem().toString();
					ContactoApodo contactoNuevo = new ContactoApodo();
					contactoNuevo.setApodo(apodo);
					;
					contactoNuevo.setSexo(sexo);
					contactoNuevo.setTipoContacto(tipo);
					contactoNuevo.setNotas(notas);
					contactoNuevo.setIdContacto(0);
					contactoNuevo.setListaAficiones(lAficiones);
					contactoNuevo.setListaCorreos(lCor);
					contactoNuevo.setListaTelefonos(ltel);
					baseDeDatosContacto.anadirContacto(contactoNuevo);
				}

				if (tipoContacto.equalsIgnoreCase("Empresa")) {

					ContactoEmpresa contactoNuevo = new ContactoEmpresa();
					contactoNuevo.setNombre(nombre);

					contactoNuevo.setTipoContacto(tipo);
					contactoNuevo.setNotas(notas);
					contactoNuevo.setIdContacto(0);
					contactoNuevo.setListaAficiones(lAficiones);
					contactoNuevo.setListaCorreos(lCor);
					contactoNuevo.setListaTelefonos(ltel);
					baseDeDatosContacto.anadirContacto(contactoNuevo);
				}

				ventanaMadre.rellenarJTableContactos();

				ventanaAnadir_modificar.dispose();

			}
		});

		btnModificarContacto_1.addActionListener(new ActionListener() {
			@Override

			public void actionPerformed(ActionEvent arg0) {
				EventQueue.invokeLater(new Runnable() {
					@Override
					public void run() {
						try {

							String sexo = "";
							String apodo = texto_Apodo.getText();
							String nombre = texto_nombre.getText();
							String apellido = texto_Apellidos.getText();
							String tipoContacto = comboBoxTipoContacto.getSelectedItem().toString();
							String notas = texto_Notas.getText();
							int fila = comboBoxTipoContacto.getSelectedIndex();
							TipoContacto tipo = new TipoContacto(fila + 1, tipoContacto);

							if (tipoContacto.equalsIgnoreCase("Persona")) {
								sexo = comboBoxSexo.getSelectedItem().toString();
								clases.ContactoPersona contactoNuevo = new clases.ContactoPersona();
								contactoNuevo.setNombre(nombre);
								contactoNuevo.setApellidos(apellido);
								contactoNuevo.setSexo(sexo);
								contactoNuevo.setTipoContacto(tipo);
								contactoNuevo.setNotas(notas);
								contactoNuevo.setIdContacto(contactoRecibido.getIdContacto());
								contactoNuevo.setListaAficiones(lAficiones);
								contactoNuevo.setListaCorreos(lCor);
								contactoNuevo.setListaTelefonos(ltel);
								baseDeDatosContacto.modificarContacto(contactoNuevo);
							}

							if (tipoContacto.equalsIgnoreCase("apodo")) {
								sexo = comboBoxSexo.getSelectedItem().toString();
								clases.ContactoApodo contactoNuevo = new clases.ContactoApodo();
								contactoNuevo.setApodo(apodo);
								contactoNuevo.setSexo(sexo);
								contactoNuevo.setTipoContacto(tipo);
								contactoNuevo.setNotas(notas);
								contactoNuevo.setIdContacto(contactoRecibido.getIdContacto());
								contactoNuevo.setListaAficiones(lAficiones);
								contactoNuevo.setListaCorreos(lCor);
								contactoNuevo.setListaTelefonos(ltel);
								baseDeDatosContacto.modificarContacto(contactoNuevo);
							}

							if (tipoContacto.equalsIgnoreCase("Empresa")) {

								clases.ContactoEmpresa contactoNuevo = new clases.ContactoEmpresa();
								contactoNuevo.setNombre(nombre);

								contactoNuevo.setTipoContacto(tipo);
								contactoNuevo.setNotas(notas);
								contactoNuevo.setIdContacto(contactoRecibido.getIdContacto());
								contactoNuevo.setListaAficiones(lAficiones);
								contactoNuevo.setListaCorreos(lCor);
								contactoNuevo.setListaTelefonos(ltel);
								baseDeDatosContacto.modificarContacto(contactoNuevo);
							}

							ventanaMadre.rellenarJTableContactos();

							ventanaAnadir_modificar.dispose();

						} catch (Exception e) {
							System.out.println("hello");
							e.printStackTrace();
						}
					}
				});
			}
		});

		comboBoxTipoContacto.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				elegirVisibilidad();
			}
		});

	}

	public void pintarDatosContacto() {
		// comboBoxSexo.setSelectedItem(contacto.getSexo());
		// comboBoxTipoContacto.setSelectedItem(contacto.getTipoContacto().getTipo());
		if (contactoRecibido != null) {
			ltel = contactoRecibido.getListaTelefonos();
			lCor = contactoRecibido.getListaCorreos();
			lAficiones = contactoRecibido.getListaAficiones();

			if (contactoRecibido.getTipoContacto().getTipo().equalsIgnoreCase("persona")) {
				clases.ContactoPersona cp = (clases.ContactoPersona) contactoRecibido;
				texto_nombre.setText(cp.getNombre());
				texto_Apellidos.setText(cp.getApellidos());
				texto_Notas.setText(cp.getNotas());
				comboBoxSexo.setSelectedItem(cp.getSexo());
				comboBoxTipoContacto.setSelectedIndex(0);
			}
			if (contactoRecibido.getTipoContacto().getTipo().equals("apodo")) {
				clases.ContactoApodo ca = (clases.ContactoApodo) contactoRecibido;
				texto_Apodo.setText(ca.getApodo());
				texto_Notas.setText(ca.getNotas());
				comboBoxSexo.setSelectedItem(ca.getSexo());
				comboBoxTipoContacto.setSelectedIndex(1);
			}
			if (contactoRecibido instanceof clases.ContactoEmpresa) {
				clases.ContactoEmpresa ce = (clases.ContactoEmpresa) contactoRecibido;
				texto_nombre.setText(ce.getNombre());
				texto_Notas.setText(ce.getNotas());
				comboBoxTipoContacto.setSelectedIndex(2);
			}
		}
	}

	// ---------------------------TABlaTelefonos-----------------------//

	private void rellenarJTableTel() {
		// JTABLE TELEFONOS

		String[] cabeceraTelefono = { "Numero", "Tipo" };
		String[][] datosTel = new String[ltel.size()][2];
		for (int i = 0; i < ltel.size(); i++) {
			datosTel[i][0] = ltel.get(i).getTelefono();
			datosTel[i][1] = ltel.get(i).getTipoTelefono().getTipo();
		}
		tableTelefonos = new JTable(datosTel, cabeceraTelefono);
		tableTelefonos.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		scrollPaneTelefonos.setViewportView(tableTelefonos);
	}

	public void anadirTelefono(clases.Telefono t) {
		ltel.add(t);
		rellenarJTableTel();
	}

	public void pedirtel() {

		DefaultComboBoxModel<String> cbmodel = new DefaultComboBoxModel<>();
		cbmodel.addElement("Fijo");
		cbmodel.addElement("Movil");
		JComboBox comboBoxTipoTelefono = new JComboBox(cbmodel);

		JTextField numero = new JTextField();
		JLabel labeltipo = new JLabel("Tipo");
		JLabel labelnumero = new JLabel("Numero");
		final JComponent[] inputs = new JComponent[] { labeltipo, comboBoxTipoTelefono, labelnumero, numero };
		int result = JOptionPane.showConfirmDialog(null, inputs, "Datos del telefono", JOptionPane.PLAIN_MESSAGE);
		if (result == JOptionPane.OK_OPTION) {
			clases.TipoTelefono objetotipotel;
			if (comboBoxTipoTelefono.getSelectedItem().equals("Fijo")) {
				objetotipotel = new clases.TipoTelefono(1, "Fijo"); // no se si es el indice 1, comprobar
			} else {
				objetotipotel = new clases.TipoTelefono(2, "Movil"); // no se si es el indice 1, comprobar
			}
			String num = numero.getText();
			clases.Telefono t = new clases.Telefono(0, num, objetotipotel);
			anadirTelefono(t);
			rellenarJTableTel();
		}
	}

	public void borrarTelefono() {
		int telefonoPosicion = tableTelefonos.getSelectedRow();
		String telefono = tableTelefonos.getValueAt(telefonoPosicion, 0).toString();
		boolean borra = baseDeDatosContacto.borrarTelefono(telefono);
		System.out.println(borra);
		ltel.remove(telefonoPosicion);
		rellenarJTableTel();
	}

	// ---------------------Tabla Correos------------------------------------/

	public void anadirCorreo(clases.Correo c) {
		// contacto.getListaTelefonos().add(c);
		lCor.add(c);
		rellenarJTableCorreo();
	}

	private void rellenarJTableCorreo() {
		// JTABLE CORREOS

		String[] cabeceraCorreos = { "Nombre Correo" };
		String[][] datosCorr = new String[lCor.size()][1];
		for (int i = 0; i < lCor.size(); i++) {
			datosCorr[i][0] = lCor.get(i).getTextoCorreo();
		}
		tableCorreos = new JTable(datosCorr, cabeceraCorreos);
		scrollPaneCorreos.setViewportView(tableCorreos);
	}

	public void pedirCorreo() {

		JTextField nombre = new JTextField();
		JLabel labeltipo = new JLabel("nombre correo");
		final JComponent[] inputs = new JComponent[] { labeltipo, nombre };
		int result = JOptionPane.showConfirmDialog(null, inputs, "Alta/modificacion Correo", JOptionPane.PLAIN_MESSAGE);
		if (result == JOptionPane.OK_OPTION) {

			String nombreCorreo = nombre.getText();
			clases.Correo t = new clases.Correo(0, nombreCorreo);
			anadirCorreo(t);
		}
	}

	public void borrarCorreo() {
		int correoPosicion = tableCorreos.getSelectedRow();
		String correo = tableCorreos.getValueAt(correoPosicion, 0).toString();
		boolean borra = baseDeDatosContacto.borrarCorreoContacto(correo);
		System.out.println(borra);
		lCor.remove(correoPosicion);
		rellenarJTableCorreo();
	}

	// ---------------------Tabla Aficiones------------------------------------/

	private void rellenarJTableAficiones() {

		String[] cabeceraAficion = { "Aficion" };
		String[][] datosAficion = new String[lAficiones.size()][1];
		for (int i = 0; i < lAficiones.size(); i++) {
			datosAficion[i][0] = lAficiones.get(i).getNombreAficion();
		}
		tableAficiones = new JTable(datosAficion, cabeceraAficion);
		scrollPaneAficiones.setViewportView(tableAficiones);
	}

	public void anadirAficion(clases.Aficion a) {
		lAficiones.add(a);
		rellenarJTableAficiones();
	}

	public void pedirAficion() {
		DefaultComboBoxModel<String> cbmodel = new DefaultComboBoxModel<>();
		listaaficionesmaestras = baseDeDatosAficiones.mostrarAficiones();
		for (clases.Aficion a : listaaficionesmaestras) {
			cbmodel.addElement(a.getNombreAficion());
		}
		JComboBox comboBoxAfiiones = new JComboBox(cbmodel);

		JLabel labelnombre = new JLabel("Aficion:");
		final JComponent[] inputs = new JComponent[] { labelnombre, comboBoxAfiiones };
		int result = JOptionPane.showConfirmDialog(null, inputs, "Alta/modificacion aficion",
				JOptionPane.PLAIN_MESSAGE);
		if (result == JOptionPane.OK_OPTION) {
			clases.Aficion a = new clases.Aficion(comboBoxAfiiones.getSelectedIndex() + 1,
					comboBoxAfiiones.getSelectedItem().toString());
			anadirAficion(a);
		}
	}

	public void borrarAficionContacto() {
		int aficionPosicion = tableAficiones.getSelectedRow();
		String aficion = tableAficiones.getValueAt(aficionPosicion, 0).toString();
		// boolean borra=baseDeDatos.borrarAficion(aficion);
		// System.out.println(borra);
		lAficiones.remove(aficionPosicion);
		rellenarJTableAficiones();
	}

	public void pedirTipoContacto() {

		String[] messageStrings = { "Persona", "Apodo", "Empresa" };

		/*
		 * comboBoxTipoContacto= new JComboBox(messageStrings); comboBoxTipoContacto.setSelectedIndex(3);
		 */
	}

	public void elegirVisibilidad() {
		String elegido = comboBoxTipoContacto.getSelectedItem().toString();
		if (elegido.equals("Persona")) {
			texto_nombre.setEnabled(true);
			texto_Apellidos.setEnabled(true);
			comboBoxSexo.setEnabled(true);
			texto_Apodo.setEnabled(false);
			texto_Notas.setEnabled(true);
		}

		if (elegido.equals("Empresa")) {
			texto_nombre.setEnabled(true);
			texto_Apellidos.setEnabled(false);
			comboBoxSexo.setEnabled(false);
			texto_Apodo.setEnabled(false);
			texto_Notas.setEnabled(true);
		}

		if (elegido.equals("Apodo")) {
			texto_nombre.setEnabled(false);
			texto_Apellidos.setEnabled(false);
			comboBoxSexo.setEnabled(true);
			texto_Apodo.setEnabled(true);
			texto_Notas.setEnabled(true);
		}

		if (modo == ventanas.VentanaInicial2.MODIFICAR) {
			btnAnadirContacto.setVisible(false);
			btnModificarContacto_1.setVisible(true);
			comboBoxTipoContacto.setEnabled(false);
		}
		if (modo == ventanas.VentanaInicial2.AGREGAR) {
			btnAnadirContacto.setVisible(true);
			btnModificarContacto_1.setVisible(false);
			comboBoxTipoContacto.setEnabled(true);
		}
	}

}
