package CARLOS_Agenda.basedeDatos;

import java.io.File;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class BasedeDatosPrincipal {
	private Connection conn;

	public Connection conectar() {
		boolean respuesta = true;

		try {
			// Class.forName("org.sqlite.JDBC");
			conn = DriverManager.getConnection("jdbc:sqlite:Agenda.sqlite");
			conn.setAutoCommit(true); // enviar automatica y directamente a bases de datos

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.getMessage();
			respuesta = false;
		}
		return conn;
	}

	public boolean desconectar() {
		boolean respuesta = true;
		try {
			conn.close();
		} catch (SQLException e) {
			System.out.println("error al cerrar la BBDD");
			respuesta = false;
		}
		return respuesta;
	}

	public void crearTablas() {
		File f = new File("Agenda.sqlite");
		if (!f.exists()) {

			try {
				conectar();
				String sql = "CREATE TABLE  Aficion (" + "	idAficion	INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,"
						+ "	nombreAficion	TEXT" + ");";

				Statement st = conn.createStatement();
				st.executeUpdate(sql);

				////// ---------------------------------------------------------------
				sql = "CREATE TABLE  TipoContacto (" + "	idTipoContacto	INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,"
						+ "	tipo	TEXT" + ");";
				st = conn.createStatement();
				st.executeUpdate(sql);

				sql = "CREATE TABLE  TipoTelefono (" + "	idTipoTelefono	INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,"
						+ "	tipo	TEXT" + ");";
				st = conn.createStatement();
				st.executeUpdate(sql);

				sql = "CREATE TABLE Contacto (" + "	idContacto	INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,"
						+ "	idTipoContacto	INTEGER NOT NULL," + "	apodo	TEXT," + "	nombre	TEXT,"
						+ "	apellidos	TEXT," + "	sexo	TEXT," + "	notas	TEXT,"
						+ "	FOREIGN KEY(idTipoContacto) REFERENCES TipoContacto(idTipoContacto)" + ");";
				st = conn.createStatement();
				st.executeUpdate(sql);

				sql = "CREATE TABLE ContactoAficion (" + "	idAficion	INTEGER NOT NULL,"
						+ "	idContacto	INTEGER NOT NULL," + "	FOREIGN KEY(idAficion) REFERENCES Aficion(idAficion),"
						+ "	FOREIGN KEY(idContacto) REFERENCES Contacto(idContacto),"
						+ "	PRIMARY KEY(idAficion,idContacto)" + ");";
				st = conn.createStatement();
				st.executeUpdate(sql);

				sql = "CREATE TABLE  Correo (" + "	idCorreo	INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,"
						+ "	textoCorreo	TEXT," + "	idContacto	INTEGER,"
						+ "	FOREIGN KEY(idContacto) REFERENCES Contacto(idContacto)" + ");";
				st = conn.createStatement();
				st.executeUpdate(sql);

				sql = "CREATE TABLE  Telefono (" + "	idTelefono	INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,"
						+ "	numeroTelefono	TEXT," + "	IdContacto	INTEGER," + "	idTipoTelefono	INTEGER,"
						+ "	FOREIGN KEY(idTipoTelefono) REFERENCES TipoTelefono(idTipoTelefono),"
						+ "	FOREIGN KEY(IdContacto) REFERENCES Contacto(idContacto)" + ");";
				st = conn.createStatement();
				st.executeUpdate(sql);

				String sql2 = "INSERT INTO aficion (nombreAficion) Values('pescar')";
				Statement st2 = conn.createStatement();
				st2.executeUpdate(sql2);

				sql2 = "INSERT INTO aficion (nombreAficion) Values('leer')";
				st2 = conn.createStatement();
				st2.executeUpdate(sql2);

				sql2 = "INSERT INTO aficion (nombreAficion) Values('bailar')";
				st2 = conn.createStatement();
				st2.executeUpdate(sql2);

				sql2 = "INSERT INTO TipoTelefono (tipo) Values('fijo')";
				st2 = conn.createStatement();
				st2.executeUpdate(sql2);

				sql2 = "INSERT INTO TipoTelefono (tipo) Values('movil')";
				st2 = conn.createStatement();
				st2.executeUpdate(sql2);

				sql2 = "INSERT INTO TipoContacto (tipo) Values('persona')";
				st2 = conn.createStatement();
				st2.executeUpdate(sql2);

				sql2 = "INSERT INTO TipoContacto (tipo) Values('apodo')";
				st2 = conn.createStatement();
				st2.executeUpdate(sql2);

				sql2 = "INSERT INTO TipoContacto (tipo) Values('empresa')";
				st2 = conn.createStatement();
				st2.executeUpdate(sql2);

				sql2 = "INSERT INTO Contacto (idTipoContacto,apodo,nombre,apellidos,sexo,notas) Values(1,'','Pepe','Santos Lopez','hombre','fontanero')";
				st2 = conn.createStatement();
				st2.executeUpdate(sql2);

				sql2 = "INSERT INTO Contacto (idTipoContacto,apodo,nombre,apellidos,sexo,notas) Values(3,'','Logista','','','empresa de logistica')";
				st2 = conn.createStatement();
				st2.executeUpdate(sql2);

				sql2 = "INSERT INTO Contacto (idTipoContacto,apodo,nombre,apellidos,sexo,notas) Values(2,'el chino','','','hombre','primo de mi tia')";
				st2 = conn.createStatement();
				st2.executeUpdate(sql2);

				sql2 = "INSERT INTO telefono (numeroTelefono,idContacto,idTipoTelefono) Values(643289047,1,2)";
				st2 = conn.createStatement();
				st2.executeUpdate(sql2);

				sql2 = "INSERT INTO telefono (numeroTelefono,idContacto,idTipoTelefono) Values(913045678,2,1)";
				st2 = conn.createStatement();
				st2.executeUpdate(sql2);

				sql2 = "INSERT INTO telefono (numeroTelefono,idContacto,idTipoTelefono) Values(6890179,3,2)";
				st2 = conn.createStatement();
				st2.executeUpdate(sql2);

				sql2 = "INSERT INTO correo (textoCorreo,idContacto) Values('pepesan@gmail.com',1)";
				st2 = conn.createStatement();
				st2.executeUpdate(sql2);

				sql2 = "INSERT INTO correo (textoCorreo,idContacto) Values('logista.rrhh@gmail.com',2)";
				st2 = conn.createStatement();
				st2.executeUpdate(sql2);

				sql2 = "INSERT INTO correo (textoCorreo,idContacto) Values('elchino.jerez@hotmail.com',3)";
				st2 = conn.createStatement();
				st2.executeUpdate(sql2);

				sql2 = "INSERT INTO contactoAficion (idAficion,idContacto) Values(1,1)";
				st2 = conn.createStatement();
				st2.executeUpdate(sql2);

				sql2 = "INSERT INTO contactoAficion (idAficion,idContacto) Values(2,3)";
				st2 = conn.createStatement();
				st2.executeUpdate(sql2);

			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			desconectar();
		}
	}

}
