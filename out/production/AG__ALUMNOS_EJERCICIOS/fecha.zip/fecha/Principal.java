package fecha;


public class Principal {

    public static void main(String[] args) {
        Fecha f1 = new Fecha(enumMes.AGOSTO);
        f1.setDia(12);
        f1.setAnio(2021);
        System.out.println(f1.toString());
        boolean esdenavidad = f1.isChristmas();
        String mensaje = esdenavidad ? "Es navidad" : "No es navidad";
        System.out.println(mensaje);


        Fecha f2 = new Fecha(12,enumMes.AGOSTO,2012);
        System.out.println(f2.getMes());
        System.out.println(f1.toString());
        boolean esdenavidad2 = f2.isChristmas();
        String mensaje2 = esdenavidad2 ? "Es navidad" : "No es navidad";
        System.out.println(mensaje2);



    }




}
