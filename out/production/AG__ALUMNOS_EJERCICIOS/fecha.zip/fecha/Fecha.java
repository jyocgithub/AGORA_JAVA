package fecha;

enum enumMes { ENERO, FEBRERO, MARZO, ABRIL, MAYO, JUNIO, JULIO, AGOSTO, SEPTIEMBRE, OCTUBRE, NOVIEMBRE,DICIEMBRE}

public class Fecha {
     private int dia;
     private enumMes mes;
     private int anio;

    public Fecha(int dia, enumMes mes, int anio) {
        this.dia = dia;
        this.mes = mes;
        this.anio = anio;
    }
    public Fecha(enumMes mes) {
        this.dia = 0;
        this.mes = mes;
        this.anio = 0;

    }

    public boolean isChristmas(){
        boolean esNavidad =  dia==25   &&  mes == enumMes.DICIEMBRE;
        boolean esReyes =  dia==6   &&  mes == enumMes.ENERO;
        boolean esChristmas = esNavidad || esReyes;
        return esChristmas;
    }

    @Override
    public String toString() {
        String mensaje =  mes+ " " + dia + ", " + anio;
        return mensaje;
    }

    public int getDia() {
        return dia;
    }

    public void setDia(int dia) {
        this.dia = dia;
    }

    public enumMes getMes() {
        return mes;
    }

    public void setMes(enumMes mes) {
        this.mes = mes;
    }

    public int getAnio() {
        return anio;
    }

    public void setAnio(int anio) {
        this.anio = anio;
    }
}
