package com.gildaniel.ra6_crudasignaturas.dao;

import com.gildaniel.ra6_crudasignaturas.aplicacion.Aplicacion;
import com.gildaniel.ra6_crudasignaturas.pojos.Asignatura;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.*;

/**
 *
 * @author danie
 */
public class AsignaturaDAO {
//                                     "jdbc:mariadb://127.0.0.1:3306/alumnos";

    private static String conexionDB = "jdbc:mysql://127.0.0.1:3306/";  // esto es para usar MySql
    private static String nombreBD = "ra6_crudasignaturas";  // aqui viene el nombre de la base de datos
    private static String usuarioDB = "root";  // usuariode bbdd
    private static String passwordDB = "";   // pwd de la bbdd
    private static String opcionesBD = "";  // opcional
    private static Connection miConexion;
    private static DatabaseMetaData dbmd;

    /**
     * **************************************************************************************************************
     * CONECTAR Establece una conexion a la bbdd y la asigna al atributo
     * conexion Usa los atributos antes indicados para configurar correctamente
     * la conexion
     */
    public void conectar() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }

        try {
            if (Aplicacion.miConexion == null) {
                Aplicacion.miConexion = DriverManager.getConnection(conexionDB + nombreBD + opcionesBD, usuarioDB, passwordDB);
            }
            miConexion = Aplicacion.miConexion;
//            miConexion = DriverManager.getConnection(conexionDB + nombreBD + opcionesBD, usuarioDB, passwordDB);
        } catch (SQLException ex) {
            // DA ERROR  No suitable driver found for jdbc:mariadb://127.0.0.1:3306/ra6_crudasignaturas

            System.out.println("ERROR CONEXION " + ex.getMessage());
            ex.printStackTrace();
        }
    }

    /**
     * **************************************************************************************************************
     * DESCONECTAR
     */
    public void desconectar() {
        try {
            miConexion.close();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    public List<Asignatura> listarAsignaturas(String orden) {
        conectar();
        List<Asignatura> asignaturas = new ArrayList<>();
        try (PreparedStatement ps = miConexion.prepareStatement("SELECT * FROM asignatura a order by "+orden );
                ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                asignaturas.add(new Asignatura(rs.getInt("id"), rs.getString("nombre"), rs.getString("codigo")));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        //  desconectar();
        return asignaturas;
    }

    public Asignatura consultarUnaAsignatura(int idbuscado) {
        conectar();
        try (PreparedStatement ps = miConexion.prepareStatement("SELECT * FROM asignatura WHERE id=?")) {
            ps.setInt(1, idbuscado);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {

                Asignatura as = new Asignatura(rs.getInt("id"), rs.getString("nombre"), rs.getString("codigo"));
              //  desconectar();
                return as;

            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        // desconectar();
        return null;
    }

    public void insertarAsignatura(Asignatura asignatura) {
        conectar();
        try (PreparedStatement ps = miConexion.prepareStatement("INSERT INTO asignatura (nombre, codigo) VALUES( ?,  ?) ")) {
            ps.setString(1, asignatura.getNombre());
            ps.setString(2, asignatura.getCodigo());
            ps.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
        //  desconectar();
    }
    // Métodos para editar y eliminar...

    public void modificarAsignatura(Asignatura asignatura) {
        conectar();
        try (PreparedStatement ps = miConexion.prepareStatement("UPDATE asignatura SET nombre=?, codigo=? WHERE id=? ")) {
            ps.setString(1, asignatura.getNombre());
            ps.setString(2, asignatura.getCodigo());
            ps.setInt(3, asignatura.getId());
            ps.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
        // desconectar();
    }

    public boolean borrarAsignatura(int idbuscado) {
        conectar();
        int cuantos = 0;
        try (PreparedStatement ps = miConexion.prepareStatement("DELETE FROM asignatura WHERE id=? ")) {
            ps.setInt(1, idbuscado);
            cuantos = ps.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
        if (cuantos == 0) {
            return false;
        } else {
            return true;
        }
        // desconectar();
    }
}
