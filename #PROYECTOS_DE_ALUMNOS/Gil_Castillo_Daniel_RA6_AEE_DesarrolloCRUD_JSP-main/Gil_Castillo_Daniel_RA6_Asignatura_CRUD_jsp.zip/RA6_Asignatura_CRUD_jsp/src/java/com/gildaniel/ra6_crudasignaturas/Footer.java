package aplicacion;

public class Footer {
	public String navbar;

	public Footer() {
		String res = "";
		res += "<footer>";
		res += "  <div class='fixed-bottom text-center bg-success text-light p-2 border-top'>";
		res += "    (c) Daniel Gil 2025";
		res += "  </div>";
		res += "</footer>";
		this.navbar = res;
	}

	public String toString() {
		return this.navbar;
	}
}
