/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.gildaniel.ra6_crudasignaturas.pojos;

import java.util.ArrayList;
import java.util.Objects;

/**
 *
 * @author danie
 */
public class Asignatura {

    private int id;
    private String nombre;
    private String codigo;
    private ArrayList<Resultado> listaResultados = new ArrayList<>();
    private ArrayList<Criterio> listaCriterios = new ArrayList<>();

    public Asignatura(int id, String nombre, String codigo) {
        this.id = id;
        this.nombre = nombre;
        this.codigo = codigo;
    }

    public Asignatura() {
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        return hash;
    }

    public ArrayList<Resultado> getListaResultados() {
        return listaResultados;
    }

    public void setListaResultados(ArrayList<Resultado> listaResultados) {
        this.listaResultados = listaResultados;
    }

    public ArrayList<Criterio> getListaCriterios() {
        return listaCriterios;
    }

    public void setListaCriterios(ArrayList<Criterio> listaCriterios) {
        this.listaCriterios = listaCriterios;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Asignatura other = (Asignatura) obj;
        if (this.id != other.id) {
            return false;
        }

        return true;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    @Override
    public String toString() {
        String res = "";
        res += "<div class='container'>";
        res += "  <div class='row border border-light rounded text-dark align-items-center fila'>";
        res += "    <div class='col-1 text-center'>" + this.id + "</div>";
        res += "    <div class='col-4'>" + this.nombre + "</div>";
        res += "    <div class='col-1 text-start'>" + this.codigo + "</div>";
        res += "    <div class='col-2 text-center'>";
        res += "      <form action='asignatura.jsp' method='POST'>";
        res += "        <input type='hidden' name='op' value='consultarAsignatura'>";
        res += "        <input type='hidden' name='id' value='" + this.getId() + "'>";
        res += "        <button class='btn btn-dark btn-sm m-1' type='submit'>";
        res += "          <i class='fa fa-id-card' aria-hidden='true'></i> Ver";
        res += "        </button>";
        res += "      </form>";
        res += "    </div>";
        res += "  </div>";
        res += "</div>";
        return res;
    }
}
