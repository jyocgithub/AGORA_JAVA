/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.gildaniel.ra6_crudasignaturas.pojos;

import com.gildaniel.ra6_crudasignaturas.dao.AsignaturaDAO;
import com.gildaniel.ra6_crudasignaturas.dao.ResultadoDAO;
import java.util.Objects;

/**
 *
 * @author danie
 */
public class Criterio {

    private int id;
    private String texto;
    private int id_resultado;

    public Criterio(int id, String texto, int id_resultado) {
        this.id = id;
        this.texto = texto;
        this.id_resultado = id_resultado;
    }

    public Criterio() {
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTexto() {
        return texto;
    }

    public void setTexto(String texto) {
        this.texto = texto;
    }

    public int getId_resultado() {
        return id_resultado;
    }

    public void setId_resultado(int id_resultado) {
        this.id_resultado = id_resultado;
    }

    @Override
    public int hashCode() {
        int hash = 3;
        hash = 53 * hash + this.id;
        hash = 53 * hash + Objects.hashCode(this.texto);
        hash = 53 * hash + this.id_resultado;
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Criterio other = (Criterio) obj;
        return this.id == other.id;
    }

    @Override
    public String toString() {

        ResultadoDAO adao = new ResultadoDAO();
        Resultado r = adao.consultarUnResultado(this.id_resultado);
        String textodelresultado = r.getTexto();
        if (r.getTexto().length() > 31) {
            textodelresultado = r.getTexto().substring(0, 30)+"...";
        }
        String res = "";
        res += "<div class='container'>";
        res += "  <div class='row border border-light rounded text-dark align-items-center fila'>";
        res += "    <div class='col-1 text-center'>" + this.id + "</div>";
        res += "    <div class='col-4'>" + this.texto + "</div>";
        res += "    <div class='col-5 text-start'>" + textodelresultado + "</div>";
        res += "    <div class='col-2 text-center'>";
        res += "      <form action='criterio.jsp' method='POST'>";
        res += "        <input type='hidden' name='op' value='consultarCriterio'>";
        res += "        <input type='hidden' name='id' value='" + this.getId() + "'>";
        res += "        <button class='btn btn-dark btn-sm m-1' type='submit'>";
        res += "          <i class='fa fa-id-card' aria-hidden='true'></i> Ver";
        res += "        </button>";
        res += "      </form>";
        res += "    </div>";
        res += "  </div>";
        res += "</div>";
        return res;
    }

}
