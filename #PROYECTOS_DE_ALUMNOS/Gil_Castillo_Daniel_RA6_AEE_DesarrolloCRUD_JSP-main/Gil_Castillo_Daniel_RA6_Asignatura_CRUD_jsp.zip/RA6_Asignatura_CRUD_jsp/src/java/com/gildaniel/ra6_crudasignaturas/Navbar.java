package com.gildaniel.ra6_crudasignaturas;

public class Navbar {
	public String navbar;

	public Navbar(String opcion) {
		String activoAsignaturas = "<li class='nav-item'>";
		String activoCriterios = "<li class='nav-item'>";
		String activaResultado = "<li class='nav-item'>";
		switch (opcion) {
			case "asignaturas":
				activoAsignaturas = "<li class='nav-item active'>";
				break;
			case "criterios":
				activoCriterios =  "<li class='nav-item active'>";
				break;
			case "resultados":
				activaResultado =  "<li class='nav-item active'>";
				break;
		}
		String res = "";
		res += "<nav class='navbar navbar-expand-lg navbar-dark bg-success sticky-top'>";
		res += "  <a class='navbar-brand'>";
		res += "    <a class='navbar-brand font-weight-bold' href='index.jsp'>";
		res += "      <img src='assets/img/logo.png' class='d-inline-block mx-2' width='30' height='30' alt=''>DANI_RA6</a>";
		res += "        <button class='navbar-toggler' type='button' data-toggle='collapse'";
		res += "          data-target='#navbarSupportedContent' aria-controls='navbarSupportedContent'";
		res += "          aria-expanded='false' aria-label='Toggle navigation'>";
		res += "          <span class='navbar-toggler-icon'></span>";
		res += "        </button>";
		res += "      <div class='collapse navbar-collapse' id='navbarSupportedContent'>";
		res += "    <ul class='navbar-nav mr-auto'>";
                
		res += activoAsignaturas;
		res += "        <a class='nav-link' href='asignaturas.jsp?orden=id'>Asignaturas</a>";
		res += "      </li>";
                
                res += activaResultado;
		res += "        <a class='nav-link' href='resultados.jsp?orden=id'>Resultados de Aprendizaje</a>";
		res += "      </li>";
                
		res += activoCriterios;
		res += "        <a class='nav-link' href='criterios.jsp?orden=id'>Criterios de Valoración</a>";
		res += "      </li>";
                

		res += "    </ul>";
		res += "  </div>";
		res += "</nav>";
		this.navbar = res;
	}

	public String toString() {
		return this.navbar;
	}
}
