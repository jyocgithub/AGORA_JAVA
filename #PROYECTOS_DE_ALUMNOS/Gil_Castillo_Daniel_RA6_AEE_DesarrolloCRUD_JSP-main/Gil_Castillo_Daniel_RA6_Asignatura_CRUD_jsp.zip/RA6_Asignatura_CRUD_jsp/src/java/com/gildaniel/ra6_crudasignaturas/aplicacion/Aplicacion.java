package com.gildaniel.ra6_crudasignaturas.aplicacion;

import com.gildaniel.ra6_crudasignaturas.dao.AsignaturaDAO;
import com.gildaniel.ra6_crudasignaturas.dao.CriterioDAO;
import com.gildaniel.ra6_crudasignaturas.dao.ResultadoDAO;

import com.gildaniel.ra6_crudasignaturas.pojos.Asignatura;
import com.gildaniel.ra6_crudasignaturas.pojos.Criterio;
import com.gildaniel.ra6_crudasignaturas.pojos.Resultado;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;
//import alumnos.*;
//import criterio.*;

//import connection.ConnectionPool;
public class Aplicacion {

    // Configuración de la conexión a la base de datos
    public static Connection miConexion;
    private static String url = "jdbc:mysql://127.0.0.1:3306/alumnos";
    private static String usuario = "root";
    private static String clave = "";
    public static Scanner sc = new Scanner(System.in);
    public final String centrado = "d-flex justify-content-center";
    public String orden = "apellidos";
    private AsignaturaDAO asignaturadao = new AsignaturaDAO();
    private CriterioDAO criteriodao = new CriterioDAO();
    private ResultadoDAO resultadodao = new ResultadoDAO();

    public Aplicacion() throws SQLException {
    }

    // ***************** CREAR ********************************************
    public int crearAsignatura(Asignatura as) throws SQLException, ClassNotFoundException {
        this.asignaturadao.insertarAsignatura(as);
        return (int) as.getId();
    }

    public int crearCriterio(Criterio cr) throws SQLException, ClassNotFoundException {
        this.criteriodao.insertarCriterio(cr);
        return (int) cr.getId();
    }

    public int crearResultado(Resultado r) throws SQLException, ClassNotFoundException {
        this.resultadodao.insertarResultado(r);
        return (int) r.getId();
    }

    public ArrayList<Asignatura> consultarTodasLasAsignaturas(String orden) throws SQLException, ClassNotFoundException {
        ArrayList<Asignatura> asignaturas = (ArrayList<Asignatura>) this.asignaturadao.listarAsignaturas(orden);
        return asignaturas;
    }

    public ArrayList<Criterio> consultarTodosLosCriterios(String orden) throws SQLException, ClassNotFoundException {
        ArrayList<Criterio> criterios = (ArrayList<Criterio>) this.criteriodao.listarCriterios(orden);
        return criterios;
    }

    public ArrayList<Resultado> consultarTodosLosResultados(String orden) throws SQLException, ClassNotFoundException {
        ArrayList<Resultado> lista = (ArrayList<Resultado>) this.resultadodao.listarResultados(orden);
        return lista;
    }

    public int modificarAsignatura(Asignatura as) throws SQLException, ClassNotFoundException {
        this.asignaturadao.modificarAsignatura(as);
        return (int) as.getId();
    }

    public int modificarCriterio(Criterio as) throws SQLException, ClassNotFoundException {
        this.criteriodao.modificarCriterio(as);
        return (int) as.getId();
    }

    public int modificarResultado(Resultado as) throws SQLException, ClassNotFoundException {
        this.resultadodao.modificarResultado(as);
        return (int) as.getId();
    }

    public String eliminarAsignatura(int id) throws SQLException, ClassNotFoundException {
//		alumnosAbreConexion();
        Boolean borrado = this.asignaturadao.borrarAsignatura(id);
//		cierraConexion();
        String res = "";
        if (borrado == true) {
            res = alerta("Asignatura eliminada correctamente", "success");
        } else {
            res = alerta("No se puede eliminar una asignatura que tiene Resultador de Aprendizaje asociados", "danger");
        }
        return res;
    }

    public String eliminarCriterio(int id) throws SQLException, ClassNotFoundException {
//		alumnosAbreConexion();
        Boolean borrado = this.criteriodao.borrarCriterio(id);
//		cierraConexion();
        String res = "";
        if (borrado == true) {
            res = alerta("Criterio eliminado correctamente", "success");
        } else {
            res = alerta("Criterio no encontrado", "danger");
        }
        return res;
    }

    public String eliminarResultado(int id) throws SQLException, ClassNotFoundException {
//		alumnosAbreConexion();
        Boolean borrado = this.resultadodao.borrarResultado(id);
//		cierraConexion();
        String res = "";
        if (borrado == true) {
            res = alerta("Resultado eliminado correctamente", "success");
        } else {
            res = alerta("No se puede eliminar un Resultado de Aprendizaje so tiene Criterios asociados", "danger");
        }
        return res;
    }

    // ****************** MENUS *******************************************
    public String inicioCabeceraFilas() {
        String res = "";
        res += "<div class='container alert alert-secondary mt-2 mb-0 font-weight-bold p-1'>";
        res += "<div class='row mx-0'>";
        return res;
    }

    public String cierreCabeceraFilas() {
        return "</div></div>";
    }

    public String muestraTodosLasASignaturas(String orden) throws ClassNotFoundException, SQLException {
        String res = "";
        res += inicioCabeceraFilas();
        res += botonCabeceraAsignaturas(1, "text-center", "a.id", "ID");
        res += botonCabeceraAsignaturas(4, "text-start", "a.nombre", "Nombre");
        res += botonCabeceraAsignaturas(1, "text-start", "a.codigo", "Código");
        res += "<div class='col-2 text-center'>";
        res += "  <form action='asignatura.jsp' method='POST'>";
        res += "    <input type='hidden' name='op' value='crearAsignatura'>";
        res += "    <button class='btn btn-dark' type='submit'><i class='fa fa-plus' aria-hidden='true'></i> Asignatura</button>";
        res += "  </form>";
        res += "</div>";
        res += cierreCabeceraFilas();
        ArrayList<Asignatura> lista = consultarTodasLasAsignaturas(orden);
        res += "<div class='container mb-5 p-0'>";
        for (Asignatura as : lista) {
            res += as;
        }
        res += "</div>";
        return res;
    }

    public String muestraTodosLosCriterios(String orden) throws ClassNotFoundException, SQLException {
        String res = "";
        res += inicioCabeceraFilas();
        res += botonCabeceraCriterios(1, "text-center", "c.id", "ID");
        res += botonCabeceraCriterios(4, "text-start", "c.texto", "Texto");
        res += botonCabeceraCriterios(5, "text-start", "c.id_resultado", "Resultado");
        res += "<div class='col-2 text-center'>";
        res += "  <form action='criterio.jsp' method='POST'>";
        res += "    <input type='hidden' name='op' value='crearCriterio'>";
        res += "    <button class='btn btn-dark' type='submit'><i class='fa fa-plus' aria-hidden='true'></i> Criterio</button>";
        res += "  </form>";
        res += "</div>";
        res += cierreCabeceraFilas();
        ArrayList<Criterio> lista = consultarTodosLosCriterios(orden);
        res += "<div class='container mb-5 p-0'>";
        for (Criterio as : lista) {
            res += as;
        }
        res += "</div>";
        return res;
    }

    public String muestraTodosLosResultados(String orden) throws ClassNotFoundException, SQLException {
        String res = "";
        res += inicioCabeceraFilas();
        res += botonCabeceraResultados(1, "text-center", "r.id", "ID");
        res += botonCabeceraResultados(5, "text-start", "r.texto", "Texto");
        res += botonCabeceraResultados(4, "text-start", "r.id_asignatura", "Asignatura");
        res += "<div class='col-2 text-center'>";
        res += "  <form action='resultado.jsp' method='POST'>";
        res += "    <input type='hidden' name='op' value='crearResultado'>";
        res += "    <button class='btn btn-dark' type='submit'><i class='fa fa-plus' aria-hidden='true'></i> Resultado</button>";
        res += "  </form>";
        res += "</div>";
        res += cierreCabeceraFilas();
        ArrayList<Resultado> lista = consultarTodosLosResultados(orden);
        res += "<div class='container mb-5 p-0'>";
        for (Resultado as : lista) {
            res += as;
        }
        res += "</div>";
        return res;
    }

    public String botonCabecera(int col, String alineacion, String link, String orden, String textoBoton) {
        String res = "";
        res += "<div class='col-" + col + " " + alineacion + "'>";
        res += "<a href='" + link + ".jsp?orden=" + orden + "'>";
        res += "<button class='btn btn-link'>";
        res += textoBoton;
        res += "</button></a></div>";
        return res;
    }

    public String botonCabeceraAsignaturas(int col, String alineacion, String orden, String textoBoton) {
        return (botonCabecera(col, alineacion, "asignaturas", orden, textoBoton));
    }

    public String botonCabeceraCriterios(int col, String alineacion, String orden, String textoBoton) {
        return (botonCabecera(col, alineacion, "criterios", orden, textoBoton));
    }

    public String botonCabeceraResultados(int col, String alineacion, String orden, String textoBoton) {
        return (botonCabecera(col, alineacion, "resultados", orden, textoBoton));
    }

    public String alerta(String mensaje, String color) {
        String res = "";
        res += "<div class='container p-0 mt-3 mb-3'>";
        res += "<div class='alert alert-" + color;
        res += " text-center' role='alert'>" + mensaje + "</div>";
        res += "</div>";
        return res;
    }

    public String muestraUnaAsignatura(int id, String modo) throws ClassNotFoundException, SQLException {
        System.out.println("Muestra un asignaturta");
        Asignatura asignatura = new Asignatura();
        if (id != 0) {
            asignatura = this.asignaturadao.consultarUnaAsignatura(id);
        }
        String mensaje = "";
        switch (modo) {
            case "consultar":
                mensaje = alerta("Consulta de asignatura", "primary");
                break;
            case "crear":
                mensaje = alerta("Alta de nueva asignatura", "warning");
                asignatura.setCodigo("");
                asignatura.setNombre("");
                break;
            case "creado":
                mensaje = alerta("Nueva asignatura creada correctamente", "success");
                break;
            case "modificado":
                mensaje = alerta("Datos de la asignatura actualizados correctamente", "success");
                break;
        }
//		ArrayList<Grupo> criterio = consultarTodosCriterio("nombre");
        String res = "";
        res += "<div class='container px-5 w-50 my-5'>";
        res += "  <form action='asignatura.jsp' method='POST'>";
        res += mensaje;
        res += "    <div class='row form-group mb-3'>";
        res += "      <label for='nombre' class='col-sm-2 col-form-label'>Nombre</label>";
        res += "      <div class='col-sm-10'>";
        res += "        <input class='form-control' name='nombre' type='text' placeholder='Nombre' required value='"
                + asignatura.getNombre() + "'/>";
        res += "      </div>";
        res += "    </div>";
        res += "    <div class='row form-group mb-3'>";
        res += "        <label for='apellidos' class='col-sm-2 col-form-label'>Código</label>";
        res += "      <div class='col-sm-10'>";
        res += "        <input class='form-control' name='codigo' type='text' placeholder='codigo' required value='"
                + asignatura.getCodigo() + "'>";
        res += "      </div>";
        res += "    </div>";
//		res += "    <div class='row form-group mb-3'>";
//		res += "      <label for='nombre' class='col-sm-2 col-form-label'>Grupo</label>";
//		res += "      <div class='col-sm-10'>";
//		res += "        <select class='form-control' name='grupoId' aria-label='Nombre de la clase' required>";
//		res += "          <option value=''>Seleccione una clase</option>";
////		for (Grupo grupo : criterio) {
////			String mode = grupo.getId() == alumno.getGrupoId() ? " selected " : "";
////			res += "        <option value='" + grupo.getId() + "' " + mode + ">" + grupo.getCurso() + " "
////					+ grupo.getNombre() + "</option>";
////		}
//		res += "        </select>";
//		res += "      </div>";
//		res += "    </div>";
        res += "    <div class='container p-0'>";
        res += "      <div class='row mx-0 justify-content-between'>";
        res += "        <div class='col-3'>";
        res += "        </div>";
        res += "        <div class='col-6 row justify-content-center'>";
        // Botonera consulta
        // Botonera alta de alumno
        if (id == 0) {
            res += creaBotonAsignatura("creadaAsignatura", "<i class='fa fa-user-plus' aria-hidden='true'></i> Dar de alta",
                    asignatura, "dark", "crear");
        } else {
            res += creaBotonAsignatura("modificarAsignatura", "<i class='fa fa-pencil' aria-hidden='true'></i> Actualizar",
                    asignatura, "dark", "actualizar"); // actualizar
        }
        System.out.println("xxxx codigo en muestraUnaAsignatura" + asignatura.getCodigo());
        if (id != 0) {
            res += creaBotonAsignatura("eliminarAsignatura", "<i class='fa fa-trash' aria-hidden='true'></i> Eliminar",
                    asignatura, "danger", "eliminar");
        }
        res += "        </div>";
        res += "        <div class='col-3 text-right'>";
        res += "          <a href='asignaturas.jsp?orden=codigo'>";
        res += "            <button class='btn btn-dark text-right' type='button'><i class='fa fa-times' aria-hidden='true'></i> Cerrar</button>";
        res += "          </a>";
        res += "        </div>";
        res += "      </div>";
        res += "    </div>";
        res += "  </form>";
        res += "</div>";
        return res;
    }

    public String muestraUnCriterio(int id, String modo) throws ClassNotFoundException, SQLException {
        System.out.println("Muestra un criterio");
        Criterio criterio = new Criterio();
        ArrayList<Resultado> listaresultados = (ArrayList<Resultado>) this.resultadodao.listarResultados("r.id");

        if (id != 0) {
            criterio = this.criteriodao.consultarUnaCriterio(id);
        }
        String mensaje = "";
        switch (modo) {
            case "consultar":
                mensaje = alerta("Consulta de criterio", "primary");
                break;
            case "crear":
                mensaje = alerta("Alta de nueva criterio", "warning");
                criterio.setTexto("");
                criterio.setId_resultado(0);
                break;
            case "creado":
                mensaje = alerta("Nuevo criterio creado correctamente", "success");
                break;
            case "modificado":
                mensaje = alerta("Datos del criterio actualizado correctamente", "success");
                break;
        }
        String res = "";
        res += "<div class='container px-5 w-50 my-5'>";
        res += "  <form action='criterio.jsp' method='POST'>";
        res += mensaje;
        res += "    <div class='row form-group mb-3'>";
        res += "      <label for='Texto' class='col-sm-2 col-form-label'>Nombre</label>";
        res += "      <div class='col-sm-10'>";
        res += "        <input class='form-control' name='texto' type='text' placeholder='Texto' required value='"
                + criterio.getTexto() + "'/>";
        res += "      </div>";
        res += "    </div>";
        res += "    <div class='row form-group mb-3'>";
        res += "      <label for='nombre' class='col-sm-2 col-form-label'>Grupo</label>";
        res += "      <div class='col-sm-10'>";
        res += "        <select class='form-control' name='selectresultado' aria-label='Nombre de la clase' required>";
        for (Resultado unresultado : listaresultados) {
            String mode = criterio.getId_resultado() == unresultado.getId() ? " selected " : "";
            String textodelresultado= unresultado.getTexto();
            if(unresultado.getTexto().length()>31){
                textodelresultado= unresultado.getTexto().substring(0, 30)+"...";
            }
            res += "        <option value='" + unresultado.getId() + "' " + mode + ">" + " "
                    + textodelresultado + "</option>";
        }
        res += "        </select>";
        res += "      </div>";
        res += "    </div>";
        res += "    <div class='container p-0'>";
        res += "      <div class='row mx-0 justify-content-between'>";
        res += "        <div class='col-3'>";
        res += "        </div>";
        res += "        <div class='col-6 row justify-content-center'>";

        if (id == 0) {
            res += creaBotonCriterio("creadoCriterio", "<i class='fa fa-user-plus' aria-hidden='true'></i> Dar de alta",
                    criterio, "dark", "crear");
        } else {
            res += creaBotonCriterio("modificarCriterio", "<i class='fa fa-pencil' aria-hidden='true'></i> Actualizar",
                    criterio, "dark", "actualizar"); // actualizar
        }
        if (id != 0) {
            res += creaBotonCriterio("eliminarCriterio", "<i class='fa fa-trash' aria-hidden='true'></i> Eliminar",
                    criterio, "danger", "eliminar");
        }
        res += "        </div>";
        res += "        <div class='col-3 text-right'>";
        res += "          <a href='criterios.jsp?orden=codigo'>";
        res += "            <button class='btn btn-dark text-right' type='button'><i class='fa fa-times' aria-hidden='true'></i> Cerrar</button>";
        res += "          </a>";
        res += "        </div>";
        res += "      </div>";
        res += "    </div>";
        res += "  </form>";
        res += "</div>";
        return res;
    }

    public String muestraUnResultado(int id, String modo) throws ClassNotFoundException, SQLException {

        Resultado resultado = new Resultado();
        if (id != 0) {
            // ESTO ES NULL PUES MODIFICAFR HA DEBIDO DE FALLAR
            resultado = this.resultadodao.consultarUnResultado(id);
        }

        ArrayList<Asignatura> listaasignaturas = (ArrayList<Asignatura>) this.asignaturadao.listarAsignaturas("a.id");

        String mensaje = "";
        switch (modo) {
            case "consultar":
                mensaje = alerta("Consulta de Resultado", "primary");
                break;
            case "crear":
                mensaje = alerta("Alta de nuevo resultado", "warning");
                resultado.setTexto("");
                resultado.setId_asignatura(0);
                break;
            case "creado":
                mensaje = alerta("Nuevo resultado creado correctamente", "success");
                break;
            case "modificado":
                mensaje = alerta("Datos del resultado actualizado correctamente", "success");
                break;
        }
//		ArrayList<Grupo> criterio = consultarTodosCriterio("nombre");
        String res = "";
        res += "<div class='container px-5 w-50 my-5'>";
        res += "  <form action='resultado.jsp' method='POST'>";
        res += mensaje;
        res += "    <div class='row form-group mb-3'>";
        res += "      <label for='Texto' class='col-sm-2 col-form-label'>Nombre</label>";
        res += "      <div class='col-sm-10'>";
        res += "        <input class='form-control' name='texto' type='text' placeholder='Texto' required value='"
                + resultado.getTexto() + "'/>";
        res += "      </div>";
        res += "    </div>";
//        res += "    <div class='row form-group mb-3'>";
//        res += "        <label for='id_asignatura' class='col-sm-2 col-form-label'>Asignatura</label>";
////        res += "      <div class='col-sm-10'>";
//////        res += "        <input class='form-control' name='id_asignatura' type='text' placeholder='id_asignatura' required value='"
//////                + resultado.getId_asignatura() + "'>";
////        res += "      </div>";
//        res += "    </div>";
        res += "    <div class='row form-group mb-3'>";
        res += "      <label for='nombre' class='col-sm-2 col-form-label'>Grupo</label>";
        res += "      <div class='col-sm-10'>";
        res += "        <select class='form-control' name='selectasignatura' aria-label='Nombre de la clase' required>";
//		res += "          <option value=''>Seleccione una AsignaturaA</option>";
        for (Asignatura a : listaasignaturas) {
            String mode = resultado.getId_asignatura() == a.getId() ? " selected " : "";
            res += "        <option value='" + a.getId() + "' " + mode + ">" + " "
                    + a.getNombre() + "</option>";
        }
        res += "        </select>";
        res += "      </div>";
        res += "    </div>";
        res += "    <div class='container p-0'>";
        res += "      <div class='row mx-0 justify-content-between'>";
        res += "        <div class='col-3'>";
        res += "        </div>";
        res += "        <div class='col-6 row justify-content-center'>";
        // Botonera consulta

        if (id == 0) {
            res += creaBotonResultado("creadoResultado", "<i class='fa fa-user-plus' aria-hidden='true'></i> Dar de alta",
                    resultado, "dark", "crear");
        } else {
            res += creaBotonResultado("modificarResultado", "<i class='fa fa-pencil' aria-hidden='true'></i> Actualizar",
                    resultado, "dark", "actualizar"); // actualizar
        }
        if (id != 0) {
            res += creaBotonResultado("eliminarResultado", "<i class='fa fa-trash' aria-hidden='true'></i> Eliminar",
                    resultado, "danger", "eliminar");
        }
        res += "        </div>";
        res += "        <div class='col-3 text-right'>";
        res += "          <a href='resultados.jsp?orden=codigo'>";
        res += "            <button class='btn btn-dark text-right' type='button'><i class='fa fa-times' aria-hidden='true'></i> Cerrar</button>";
        res += "          </a>";
        res += "        </div>";
        res += "      </div>";
        res += "    </div>";
        res += "  </form>";
        res += "</div>";
        return res;
    }

    public String creaBotonAsignatura(String operacion, String textoBoton, Asignatura pasignatura, String color, String modo) {
        String res = "";
        res += "<form action='asignatura.jsp?' method='POST'>";
        res += "<input type='hidden' name='op' value='" + operacion + "'>";
        res += "<input type='hidden' name='id' value='" + pasignatura.getId() + "'>";
        if (!modo.equals("actualizar")) {
            res += "<input type='hidden' name='nombre' value='" + pasignatura.getNombre() + "'>";
            res += "<input type='hidden' name='codigo' value='" + pasignatura.getCodigo() + "'>";
            res += "<input type='hidden' name='Id' value='" + pasignatura.getId() + "'>";
        }
        res += "<button class='btn btn-" + color + " mx-1' type='submit'>" + textoBoton + "</button>";
        res += "</form>";
        System.out.println("xxxx codigo en crear boton" + pasignatura.getCodigo());
        return res;
    }

    public String creaBotonCriterio(String operacion, String textoBoton, Criterio pcriterio, String color, String modo) {
        String res = "";
        res += "<form action='criterio.jsp?' method='POST'>";
        res += "<input type='hidden' name='op' value='" + operacion + "'>";
        res += "<input type='hidden' name='id' value='" + pcriterio.getId() + "'>";
        if (!modo.equals("actualizar")) {
            res += "<input type='hidden' name='texto' value='" + pcriterio.getTexto() + "'>";
            res += "<input type='hidden' name='id_asignatura' value='" + pcriterio.getId_resultado() + "'>";
//            res += "<input type='hidden' name='id' value='" + pcriterio.getId() + "'>";
        }
        res += "<button class='btn btn-" + color + " mx-1' type='submit'>" + textoBoton + "</button>";
        res += "</form>";

        return res;
    }

    public String creaBotonResultado(String operacion, String textoBoton, Resultado presultado, String color, String modo) {
        String res = "";
        res += "<form action='resultado.jsp?' method='POST'>";
        res += "<input type='hidden' name='op' value='" + operacion + "'>";
        res += "<input type='hidden' name='id' value='" + presultado.getId() + "'>";
        if (!modo.equals("actualizar")) {
            res += "<input type='hidden' name='texto' value='" + presultado.getTexto() + "'>";
            res += "<input type='hidden' name='id_asignatura' value='" + presultado.getId_asignatura() + "'>";
            res += "<input type='hidden' name='id' value='" + presultado.getId() + "'>";
        }
        res += "<button class='btn btn-" + color + " mx-1' type='submit'>" + textoBoton + "</button>";
        res += "</form>";

        return res;
    }

}
