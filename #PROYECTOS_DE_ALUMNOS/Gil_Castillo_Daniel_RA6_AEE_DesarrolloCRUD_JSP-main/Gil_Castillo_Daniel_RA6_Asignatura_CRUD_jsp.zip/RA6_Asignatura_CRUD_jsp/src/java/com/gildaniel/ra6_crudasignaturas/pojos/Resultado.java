/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.gildaniel.ra6_crudasignaturas.pojos;

import com.gildaniel.ra6_crudasignaturas.dao.AsignaturaDAO;
import java.util.Objects;

/**
 *
 * @author danie
 */
public class Resultado {

    private int id;
    private String texto;
    private int id_asignatura;

    public Resultado(int id, String texto, int id_asignatura) {
        this.id = id;
        this.texto = texto;
        this.id_asignatura = id_asignatura;
    }

    public Resultado() {
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTexto() {
        return texto;
    }

    public void setTexto(String texto) {
        this.texto = texto;
    }

    public int getId_asignatura() {
        return id_asignatura;
    }

    public void setId_asignatura(int id_asignatura) {
        this.id_asignatura = id_asignatura;
    }

    @Override
    public int hashCode() {
        int hash = 3;
        hash = 53 * hash + this.id;
        hash = 53 * hash + Objects.hashCode(this.texto);
        hash = 53 * hash + this.id_asignatura;
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Resultado other = (Resultado) obj;
        return this.id == other.id;
    }

    @Override
    public String toString() {
        
        AsignaturaDAO adao = new AsignaturaDAO();
        Asignatura a = adao.consultarUnaAsignatura(this.id_asignatura);

        String res = "";
        res += "<div class='container'>";
        res += "  <div class='row border border-light rounded text-dark align-items-center fila'>";
        res += "    <div class='col-1 text-center'>" + this.id + "</div>";
        res += "    <div class='col-5'>" + this.texto + "</div>";
        res += "    <div class='col-4 text-start'>" + a.getNombre()+ "</div>";
        res += "    <div class='col-2 text-center'>";
        res += "      <form action='resultado.jsp' method='POST'>";
        res += "        <input type='hidden' name='op' value='consultarResultado'>";
        res += "        <input type='hidden' name='id' value='" + this.getId() + "'>";
        res += "        <button class='btn btn-dark btn-sm m-1' type='submit'>";
        res += "          <i class='fa fa-id-card' aria-hidden='true'></i> Ver";
        res += "        </button>";
        res += "      </form>";
        res += "    </div>";
        res += "  </div>";
        res += "</div>";
        return res;
    }

}
