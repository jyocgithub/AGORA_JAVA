package ventanas;

import java.awt.CardLayout;
import java.awt.EventQueue;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.border.EmptyBorder;

import basedeDatos.BasedeDatosAficiones;
import basedeDatos.BasedeDatosContacto;
import basedeDatos.BasedeDatosPrincipal;
import clases.Aficion;
import clases.Contacto;
import clases.ContactoApodo;
import clases.ContactoEmpresa;
import clases.ContactoPersona;
import clases.Correo;
import clases.Telefono;

public class VentanaInicial2 {

	private JPanel contentPane;
	BasedeDatosPrincipal baseDeDatosPrincipal;
	BasedeDatosContacto baseDeDatosContacto;
	BasedeDatosAficiones baseDeDatosAficiones;

	private JFrame frame;
	private JButton btnAnadirContacto;
	public static final int AGREGAR = 1;
	public static final int MODIFICAR = 2;
	public static final int CONSULTAR = 3;
	private JScrollPane scrollPaneContactos;
	private JTable tableContactos;
	private JScrollPane scrollPaneAficiones;
	private JTable tableAficiones;
	private JButton btnAnadirAficion;
	private JButton btnBorrarAficion;
	VentanaInicial2 ventanaMadre;
	private JButton btnModificarAficion;
	private JButton btnBuscarContacto;
	private JLabel lblNombre;
	private JLabel lblApodo;
	private JTable tableTelefonos;
	private JScrollPane scrollPaneTelefonos;
	private JTable tableCorreos;
	private JScrollPane scrollPaneCorreos;
	private JTable tableAfi;
	private JScrollPane scrollPaneAfi;
	private JButton btnSalir_1;
	private JButton btnModificarContacto;
	String[][] datosContacto;
	private JButton btnSalir;
	private JButton btnBorrarContacto;
	private JTextField textField_nombreaBuscar;
	// private ArrayList<Telefono> ltel;
	String idContacto;
	ArrayList<Contacto> listaCont = new ArrayList<>();
	private JLabel lblNumeroTelefono;
	private JTextField textField_numeroTelefono;
	private JTextField textField_Apodo;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {

		EventQueue.invokeLater(new Runnable() {
			@Override
			public void run() {
				try {
					VentanaInicial2 ventana = new VentanaInicial2();
					ventana.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public VentanaInicial2() {

		baseDeDatosPrincipal = new BasedeDatosPrincipal();
		baseDeDatosAficiones = new BasedeDatosAficiones();
		baseDeDatosContacto = new BasedeDatosContacto();
		baseDeDatosPrincipal.crearTablas();
		initialize();
		rellenarJTableAficiones();
		rellenarJTableContactos();
		rellenarJTableTelefonosContacto();
		rellenarJTableCorreosContacto();
		rellenarJTableAficionesContacto();
		eventos();
		ventanaMadre = this;
	}

	public void eventos() {
		btnAnadirContacto.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				EventQueue.invokeLater(new Runnable() {
					@Override
					public void run() {
						try {
							VentanaAnadir_modificarContacto window = new VentanaAnadir_modificarContacto(null, AGREGAR,
									ventanaMadre);
							window.setVisible(true);

						} catch (Exception e) {
							System.out.println("ola");
							e.printStackTrace();
						}
					}
				});
			}
		});

		btnAnadirAficion.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				pedirAficion();
			}
		});

		btnBorrarAficion.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				try {
					borrarAficion();
				} catch (ArrayIndexOutOfBoundsException aioob) {
					JOptionPane.showMessageDialog(null, "debes seleccionar antes una aficion de la tabla",
							"imposible realizar operacion", JOptionPane.ERROR_MESSAGE);
				}
			}
		});

		btnModificarAficion.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					modificarAficion();
				} catch (ArrayIndexOutOfBoundsException aioob) {

					JOptionPane.showMessageDialog(null, "debes seleccionar antes una aficion de la tabla",
							"imposible realizar operacion", JOptionPane.ERROR_MESSAGE);
				}
			}
		});

		btnBuscarContacto.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				String nombre = textField_nombreaBuscar.getText();
				String apodo = textField_Apodo.getText();
				String telefono = textField_numeroTelefono.getText();

				if (nombre.isEmpty() && apodo.isEmpty() && telefono.isEmpty()) {
					rellenarJTableContactos();
				} else if (!nombre.isEmpty()) {
					listaCont = baseDeDatosContacto.buscarContactosPorNombre(nombre);
					rellenarJTableBusquedaContactos();
					textField_nombreaBuscar.setText("");
					textField_Apodo.setText("");
					textField_numeroTelefono.setText("");
				} else if (!apodo.isEmpty()) {
					listaCont = baseDeDatosContacto.buscarContactosPorApodo(apodo);
					rellenarJTableBusquedaContactos();
					textField_nombreaBuscar.setText("");
					textField_Apodo.setText("");
					textField_numeroTelefono.setText("");
				} else if (!telefono.isEmpty()) {
					listaCont = baseDeDatosContacto.buscarContactosPorTelefono(telefono);
					rellenarJTableBusquedaContactos();
					textField_nombreaBuscar.setText("");
					textField_Apodo.setText("");
					textField_numeroTelefono.setText("");
				}

			}
		});

		btnModificarContacto.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {

				EventQueue.invokeLater(new Runnable() {
					@Override
					public void run() {
						try {
							int fila = tableContactos.getSelectedRow();
							int id = Integer.parseInt(datosContacto[fila][6]);
							Contacto uncontacto = baseDeDatosContacto.buscarContactoPorIdContacto(id);
							VentanaAnadir_modificarContacto window = new VentanaAnadir_modificarContacto(uncontacto,
									MODIFICAR, ventanaMadre);
							window.setVisible(true);

						} catch (ArrayIndexOutOfBoundsException aioob) {

							JOptionPane.showMessageDialog(null, "debes seleccionar antes un conacto de la tabla",
									"imposible realizar operacion", JOptionPane.ERROR_MESSAGE);

						} catch (Exception e) {
							System.out.println("hola");
							e.printStackTrace();
						}

					}
				});

			}
		});

		btnBorrarContacto.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				try {
					borrarContacto();
				} catch (ArrayIndexOutOfBoundsException aioob) {

					JOptionPane.showMessageDialog(null, "debes seleccionar antes un conacto de la tabla",
							"imposible realizar operacion", JOptionPane.ERROR_MESSAGE);
				}
			}

		});

		btnSalir.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				System.exit(0);
			}
		});

	}

	public void eventosTablaContactos() {
		tableContactos.addMouseListener(new MouseAdapter() {

			@Override
			public void mouseClicked(MouseEvent arg0) {
				int posicionColumna = tableContactos.getSelectedRow();
				idContacto = tableContactos.getValueAt(posicionColumna, 6).toString();

				rellenarJTableTelefonosContacto();
				rellenarJTableCorreosContacto();
				rellenarJTableAficionesContacto();

			}
		});
	}

	public void initialize() {
		frame = new JFrame();
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setBounds(100, 100, 921, 652);
		frame.setLocationRelativeTo(null);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		frame.setContentPane(contentPane);
		contentPane.setLayout(new CardLayout(0, 0));

		JTabbedPane tabbedPane = new JTabbedPane(JTabbedPane.TOP);
		contentPane.add(tabbedPane, "name_82963512468109");

		JPanel panel_menu = new JPanel();
		tabbedPane.addTab("Mostrar contactos", null, panel_menu, null);
		GridBagLayout gbl_panel_menu = new GridBagLayout();
		gbl_panel_menu.columnWidths = new int[] { 93, 87, 73, 105, 90, 0 };
		gbl_panel_menu.rowHeights = new int[] { 0, 0, 27, 185, 0, 35, 0 };
		gbl_panel_menu.columnWeights = new double[] { 0.0, 1.0, 1.0, 1.0, 1.0, Double.MIN_VALUE };
		gbl_panel_menu.rowWeights = new double[] { 0.0, 0.0, 0.0, 1.0, 1.0, 0.0, Double.MIN_VALUE };
		panel_menu.setLayout(gbl_panel_menu);

		btnAnadirContacto = new JButton("Anadir");

		lblNombre = new JLabel("nombre");
		GridBagConstraints gbc_lblNombre = new GridBagConstraints();
		gbc_lblNombre.anchor = GridBagConstraints.EAST;
		gbc_lblNombre.insets = new Insets(0, 0, 5, 5);
		gbc_lblNombre.gridx = 0;
		gbc_lblNombre.gridy = 0;
		panel_menu.add(lblNombre, gbc_lblNombre);

		textField_nombreaBuscar = new JTextField();
		GridBagConstraints gbc_textField_nombreaBuscar = new GridBagConstraints();
		gbc_textField_nombreaBuscar.insets = new Insets(0, 0, 5, 5);
		gbc_textField_nombreaBuscar.fill = GridBagConstraints.HORIZONTAL;
		gbc_textField_nombreaBuscar.gridx = 1;
		gbc_textField_nombreaBuscar.gridy = 0;
		panel_menu.add(textField_nombreaBuscar, gbc_textField_nombreaBuscar);
		textField_nombreaBuscar.setColumns(10);

		btnBuscarContacto = new JButton("buscar");
		GridBagConstraints gbc_btnBuscarContacto = new GridBagConstraints();
		gbc_btnBuscarContacto.insets = new Insets(0, 0, 5, 5);
		gbc_btnBuscarContacto.gridx = 2;
		gbc_btnBuscarContacto.gridy = 0;
		panel_menu.add(btnBuscarContacto, gbc_btnBuscarContacto);

		lblApodo = new JLabel("apodo");
		GridBagConstraints gbc_lblApodo = new GridBagConstraints();
		gbc_lblApodo.anchor = GridBagConstraints.EAST;
		gbc_lblApodo.insets = new Insets(0, 0, 5, 5);
		gbc_lblApodo.gridx = 0;
		gbc_lblApodo.gridy = 1;
		panel_menu.add(lblApodo, gbc_lblApodo);

		textField_Apodo = new JTextField();
		GridBagConstraints gbc_textField_Apodo = new GridBagConstraints();
		gbc_textField_Apodo.insets = new Insets(0, 0, 5, 5);
		gbc_textField_Apodo.fill = GridBagConstraints.HORIZONTAL;
		gbc_textField_Apodo.gridx = 1;
		gbc_textField_Apodo.gridy = 1;
		panel_menu.add(textField_Apodo, gbc_textField_Apodo);
		textField_Apodo.setColumns(10);

		lblNumeroTelefono = new JLabel("num telefono");
		GridBagConstraints gbc_lblNumeroTelefono = new GridBagConstraints();
		gbc_lblNumeroTelefono.anchor = GridBagConstraints.EAST;
		gbc_lblNumeroTelefono.insets = new Insets(0, 0, 5, 5);
		gbc_lblNumeroTelefono.gridx = 0;
		gbc_lblNumeroTelefono.gridy = 2;
		panel_menu.add(lblNumeroTelefono, gbc_lblNumeroTelefono);

		textField_numeroTelefono = new JTextField();
		GridBagConstraints gbc_textField_numeroTelefono = new GridBagConstraints();
		gbc_textField_numeroTelefono.insets = new Insets(0, 0, 5, 5);
		gbc_textField_numeroTelefono.fill = GridBagConstraints.HORIZONTAL;
		gbc_textField_numeroTelefono.gridx = 1;
		gbc_textField_numeroTelefono.gridy = 2;
		panel_menu.add(textField_numeroTelefono, gbc_textField_numeroTelefono);
		textField_numeroTelefono.setColumns(10);
		scrollPaneContactos = new JScrollPane();
		GridBagConstraints gbc_scrollPaneContactos = new GridBagConstraints();
		gbc_scrollPaneContactos.gridwidth = 5;
		gbc_scrollPaneContactos.fill = GridBagConstraints.BOTH;
		gbc_scrollPaneContactos.insets = new Insets(0, 0, 5, 0);
		gbc_scrollPaneContactos.gridx = 0;
		gbc_scrollPaneContactos.gridy = 3;
		panel_menu.add(scrollPaneContactos, gbc_scrollPaneContactos);

		scrollPaneTelefonos = new JScrollPane();
		GridBagConstraints gbc_scrollPaneTelefonos = new GridBagConstraints();
		gbc_scrollPaneTelefonos.gridwidth = 2;
		gbc_scrollPaneTelefonos.fill = GridBagConstraints.BOTH;
		gbc_scrollPaneTelefonos.insets = new Insets(0, 0, 5, 5);
		gbc_scrollPaneTelefonos.gridx = 0;
		gbc_scrollPaneTelefonos.gridy = 4;
		panel_menu.add(scrollPaneTelefonos, gbc_scrollPaneTelefonos);

		scrollPaneCorreos = new JScrollPane();
		GridBagConstraints gbc_scrollPaneCorreos = new GridBagConstraints();
		gbc_scrollPaneCorreos.gridwidth = 2;
		gbc_scrollPaneCorreos.fill = GridBagConstraints.BOTH;
		gbc_scrollPaneCorreos.insets = new Insets(0, 0, 5, 5);
		gbc_scrollPaneCorreos.gridx = 2;
		gbc_scrollPaneCorreos.gridy = 4;
		panel_menu.add(scrollPaneCorreos, gbc_scrollPaneCorreos);

		scrollPaneAfi = new JScrollPane();
		GridBagConstraints gbc_scrollPaneAfi = new GridBagConstraints();
		gbc_scrollPaneAfi.fill = GridBagConstraints.BOTH;
		gbc_scrollPaneAfi.insets = new Insets(0, 0, 5, 0);
		gbc_scrollPaneAfi.gridx = 4;
		gbc_scrollPaneAfi.gridy = 4;
		panel_menu.add(scrollPaneAfi, gbc_scrollPaneAfi);
		GridBagConstraints gbc_btnAnadirContacto = new GridBagConstraints();
		gbc_btnAnadirContacto.insets = new Insets(0, 0, 0, 5);
		gbc_btnAnadirContacto.gridx = 0;
		gbc_btnAnadirContacto.gridy = 5;
		panel_menu.add(btnAnadirContacto, gbc_btnAnadirContacto);

		btnModificarContacto = new JButton("Modificar");

		GridBagConstraints gbc_btnModificarContacto = new GridBagConstraints();
		gbc_btnModificarContacto.insets = new Insets(0, 0, 0, 5);
		gbc_btnModificarContacto.gridx = 1;
		gbc_btnModificarContacto.gridy = 5;
		panel_menu.add(btnModificarContacto, gbc_btnModificarContacto);

		btnBorrarContacto = new JButton("Borrar");
		GridBagConstraints gbc_btnBorrarContacto = new GridBagConstraints();
		gbc_btnBorrarContacto.insets = new Insets(0, 0, 0, 5);
		gbc_btnBorrarContacto.gridx = 2;
		gbc_btnBorrarContacto.gridy = 5;
		panel_menu.add(btnBorrarContacto, gbc_btnBorrarContacto);

		btnSalir = new JButton("salir");
		GridBagConstraints gbc_btnSalir = new GridBagConstraints();
		gbc_btnSalir.gridx = 4;
		gbc_btnSalir.gridy = 5;
		panel_menu.add(btnSalir, gbc_btnSalir);

		JPanel panel_aficiones = new JPanel();
		tabbedPane.addTab("Aficiones", null, panel_aficiones, null);
		GridBagLayout gbl_panel_aficiones = new GridBagLayout();
		gbl_panel_aficiones.columnWidths = new int[] { 0, 41, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
				0 };
		gbl_panel_aficiones.rowHeights = new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
		gbl_panel_aficiones.columnWeights = new double[] { 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
				0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0, Double.MIN_VALUE };
		gbl_panel_aficiones.rowWeights = new double[] { 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0,
				0.0, 0.0, Double.MIN_VALUE };
		panel_aficiones.setLayout(gbl_panel_aficiones);

		scrollPaneAficiones = new JScrollPane();
		GridBagConstraints gbc_scrollPaneAficiones = new GridBagConstraints();
		gbc_scrollPaneAficiones.gridwidth = 19;
		gbc_scrollPaneAficiones.gridheight = 10;
		gbc_scrollPaneAficiones.fill = GridBagConstraints.BOTH;
		gbc_scrollPaneAficiones.insets = new Insets(0, 0, 5, 5);
		gbc_scrollPaneAficiones.gridx = 1;
		gbc_scrollPaneAficiones.gridy = 2;
		panel_aficiones.add(scrollPaneAficiones, gbc_scrollPaneAficiones);

		btnAnadirAficion = new JButton("Anadir ");

		GridBagConstraints gbc_btnAnadirAficion = new GridBagConstraints();
		gbc_btnAnadirAficion.insets = new Insets(0, 0, 5, 5);
		gbc_btnAnadirAficion.gridx = 1;
		gbc_btnAnadirAficion.gridy = 13;
		panel_aficiones.add(btnAnadirAficion, gbc_btnAnadirAficion);

		btnModificarAficion = new JButton("Modificar ");
		GridBagConstraints gbc_btnModificarAficion = new GridBagConstraints();
		gbc_btnModificarAficion.insets = new Insets(0, 0, 5, 5);
		gbc_btnModificarAficion.gridx = 4;
		gbc_btnModificarAficion.gridy = 13;
		panel_aficiones.add(btnModificarAficion, gbc_btnModificarAficion);

		btnBorrarAficion = new JButton("Borrar");
		GridBagConstraints gbc_btnBorrarAficion = new GridBagConstraints();
		gbc_btnBorrarAficion.insets = new Insets(0, 0, 5, 5);
		gbc_btnBorrarAficion.gridx = 6;
		gbc_btnBorrarAficion.gridy = 13;
		panel_aficiones.add(btnBorrarAficion, gbc_btnBorrarAficion);

		btnSalir_1 = new JButton("salir");
		GridBagConstraints gbc_btnSalir_1 = new GridBagConstraints();
		gbc_btnSalir_1.insets = new Insets(0, 0, 5, 5);
		gbc_btnSalir_1.gridx = 19;
		gbc_btnSalir_1.gridy = 13;
		panel_aficiones.add(btnSalir_1, gbc_btnSalir_1);
	}

	public void rellenarJTableContactos() {
		ArrayList<Contacto> lContactos = baseDeDatosContacto.mostrarContactos();
		String[] cabeceraContacto = { "tipo", "Nombre", "Apellido", "Apodo", "Sexo", "Notas", "id" };
		datosContacto = new String[lContactos.size()][7];
		for (int i = 0; i < lContactos.size(); i++) {
			datosContacto[i][0] = lContactos.get(i).getTipoContacto().getTipo();
			datosContacto[i][5] = lContactos.get(i).getNotas();
			datosContacto[i][6] = lContactos.get(i).getIdContacto() + "";
			if (datosContacto[i][0].equalsIgnoreCase("apodo")) {
				ContactoApodo ca = (ContactoApodo) lContactos.get(i);

				datosContacto[i][1] = "";
				datosContacto[i][2] = "";
				datosContacto[i][3] = ca.getApodo();
				datosContacto[i][4] = ca.getSexo();
			}
			if (datosContacto[i][0].equalsIgnoreCase("persona")) {
				ContactoPersona cp = (ContactoPersona) lContactos.get(i);

				datosContacto[i][1] = cp.getNombre();
				datosContacto[i][2] = cp.getApellidos();
				datosContacto[i][3] = "";
				datosContacto[i][4] = cp.getSexo();
			}
			if (datosContacto[i][0].equalsIgnoreCase("empresa")) {
				ContactoEmpresa ce = (ContactoEmpresa) lContactos.get(i);

				datosContacto[i][1] = ce.getNombre();
				datosContacto[i][2] = "";
				datosContacto[i][3] = "";
				datosContacto[i][4] = "";
			}
		}
		tableContactos = new JTable(datosContacto, cabeceraContacto);
		scrollPaneContactos.setViewportView(tableContactos);
		eventosTablaContactos();
	}

	public void rellenarJTableBusquedaContactos() {

		String[] cabeceraContacto = { "tipo", "Nombre", "Apellido", "Apodo", "Sexo", "Notas", "id" };
		datosContacto = new String[listaCont.size()][7];
		for (int i = 0; i < listaCont.size(); i++) {
			datosContacto[i][0] = listaCont.get(i).getTipoContacto().getTipo();
			datosContacto[i][5] = listaCont.get(i).getNotas();
			datosContacto[i][6] = listaCont.get(i).getIdContacto() + "";
			if (datosContacto[i][0].equalsIgnoreCase("apodo")) {
				ContactoApodo ca = (ContactoApodo) listaCont.get(i);

				datosContacto[i][1] = "";
				datosContacto[i][2] = "";
				datosContacto[i][3] = ca.getApodo();
				datosContacto[i][4] = ca.getSexo();
			}
			if (datosContacto[i][0].equalsIgnoreCase("persona")) {
				ContactoPersona cp = (ContactoPersona) listaCont.get(i);

				datosContacto[i][1] = cp.getNombre();
				datosContacto[i][2] = cp.getApellidos();
				datosContacto[i][3] = "";
				datosContacto[i][4] = cp.getSexo();
			}
			if (datosContacto[i][0].equalsIgnoreCase("empresa")) {
				ContactoEmpresa ce = (ContactoEmpresa) listaCont.get(i);

				datosContacto[i][1] = ce.getNombre();
				datosContacto[i][2] = "";
				datosContacto[i][3] = "";
				datosContacto[i][4] = "";
			}
		}
		tableContactos = new JTable(datosContacto, cabeceraContacto);
		scrollPaneContactos.setViewportView(tableContactos);
		eventosTablaContactos();
	}

	public void borrarContacto() {
		int contactoPosicion = tableContactos.getSelectedRow();
		String idContacto = tableContactos.getValueAt(contactoPosicion, 6).toString();
		boolean borra = baseDeDatosContacto.borrarContacto(idContacto);
		rellenarJTableContactos();
	}

	public void rellenarJTableTelefonosContacto() {
		ArrayList<Telefono> ltel = new ArrayList<>();
		ltel = baseDeDatosContacto.mostrarTelefonosContacto(idContacto);

		String[] cabeceraTelefono = { "Numero", "Tipo" };
		String[][] datosTel = new String[ltel.size()][2];
		for (int i = 0; i < ltel.size(); i++) {
			datosTel[i][0] = ltel.get(i).getTelefono();
			datosTel[i][1] = ltel.get(i).getTipoTelefono().getTipo();
		}
		tableTelefonos = new JTable(datosTel, cabeceraTelefono);
		tableTelefonos.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		scrollPaneTelefonos.setViewportView(tableTelefonos);
	}

	/*
	 * public void mostrarTelefonos(String id) {
	 * 
	 * }
	 */
	public String dameIdContacto(String id) {
		return id;
	}

	private void rellenarJTableCorreosContacto() {
		// JTABLE CORREOS
		ArrayList<Correo> lCor = new ArrayList<>();
		lCor = baseDeDatosContacto.mostrarCorreosContacto(idContacto);
		String[] cabeceraCorreos = { "Nombre Correo" };
		String[][] datosCorr = new String[lCor.size()][1];
		for (int i = 0; i < lCor.size(); i++) {
			datosCorr[i][0] = lCor.get(i).getTextoCorreo();
		}
		tableCorreos = new JTable(datosCorr, cabeceraCorreos);
		scrollPaneCorreos.setViewportView(tableCorreos);
	}

	private void rellenarJTableAficionesContacto() {
		ArrayList<Aficion> lAficiones = new ArrayList<>();
		lAficiones = baseDeDatosContacto.mostrarAficionesContacto(idContacto);
		String[] cabeceraAficion = { "Nombre aficion" };
		String[][] datosAficion = new String[lAficiones.size()][1];
		for (int i = 0; i < lAficiones.size(); i++) {
			datosAficion[i][0] = lAficiones.get(i).getNombreAficion();
		}
		tableAfi = new JTable(datosAficion, cabeceraAficion);
		scrollPaneAfi.setViewportView(tableAfi);
	}

	private void rellenarJTableAficiones() { // si quiero a�adir mas jtables en inicial
		ArrayList<Aficion> lAficiones = baseDeDatosAficiones.mostrarAficiones();
		String[] cabeceraAficion = { "aficion" };
		String[][] datosAficion = new String[lAficiones.size()][1];
		for (int i = 0; i < lAficiones.size(); i++) {
			// datosAficion[i][0] = lAficiones.get(i).getIdAficion();
			datosAficion[i][0] = lAficiones.get(i).getNombreAficion();
		}
		tableAficiones = new JTable(datosAficion, cabeceraAficion);
		tableAficiones.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		scrollPaneAficiones.setViewportView(tableAficiones);
	}

	private void pedirAficion() {

		JTextField nombre = new JTextField();
		JLabel labeltipo = new JLabel("aficion");
		final JComponent[] inputs = new JComponent[] { labeltipo, nombre };
		int result = JOptionPane.showConfirmDialog(null, inputs, "Anadir aficion", JOptionPane.PLAIN_MESSAGE);
		if (result == JOptionPane.OK_OPTION) {
			String nom = nombre.getText();
			Aficion a = new Aficion(0, nom);
			baseDeDatosAficiones.anadirAficion(a);
			rellenarJTableAficiones();
		}
	}

	private void borrarAficion() {
		int aficion1 = tableAficiones.getSelectedRow();
		String aficion2 = tableAficiones.getValueAt(aficion1, 0).toString();
		System.out.println(aficion2);
		boolean puedoBorrar = baseDeDatosAficiones.borrarAficion(aficion2);
		if (puedoBorrar == false) {
			JOptionPane.showMessageDialog(null, "esta aficion esta siendo usada", "imposible realizar operacion",
					JOptionPane.ERROR_MESSAGE);
		}
		rellenarJTableAficiones();
	}

	private void modificarAficion() {
		int aficionClickeada = tableAficiones.getSelectedRow();
		String nombreAficion = tableAficiones.getValueAt(aficionClickeada, 0).toString();
		boolean aficionUsada = baseDeDatosAficiones.estaUsadaAficion(nombreAficion);
		if (aficionUsada) {
			// JOptionPane.showMessageDialog(null, "la afiion esta siendo usada por algun
			// contacto, esos contactos tendran la nueva aficion", "mensaje",
			// JOptionPane.PLAIN_MESSAGE);

			int dialogResult = JOptionPane.showConfirmDialog(null,
					"Esta aficion esta siendo usada, si la cambias los contactos con esta aficion tendran la nueva aficion ,Estas seguro?",
					"Advertencia", JOptionPane.YES_NO_OPTION);
			if (dialogResult == JOptionPane.YES_OPTION) {
				JTextField texto = new JTextField();
				JLabel labeltipo = new JLabel("nuevo nombre de aficion");
				final JComponent[] inputs = new JComponent[] { labeltipo, texto };
				int result = JOptionPane.showConfirmDialog(null, inputs, "Modificacion de la aficion",
						JOptionPane.PLAIN_MESSAGE);
				if (result == JOptionPane.OK_OPTION) {
					baseDeDatosAficiones.modificarAficion(nombreAficion, texto.getText());
					rellenarJTableAficiones();
				}

			}

		} else {
			JTextField texto2 = new JTextField();
			JLabel labeltipo2 = new JLabel("nuevo nombre de aficion");
			final JComponent[] inputs2 = new JComponent[] { labeltipo2, texto2 };
			int result2 = JOptionPane.showConfirmDialog(null, inputs2, "Modificacion de la aficion",
					JOptionPane.PLAIN_MESSAGE);
			if (result2 == JOptionPane.OK_OPTION) {
				baseDeDatosAficiones.modificarAficion(nombreAficion, texto2.getText());
				rellenarJTableAficiones();
			}

		}
	}
}
