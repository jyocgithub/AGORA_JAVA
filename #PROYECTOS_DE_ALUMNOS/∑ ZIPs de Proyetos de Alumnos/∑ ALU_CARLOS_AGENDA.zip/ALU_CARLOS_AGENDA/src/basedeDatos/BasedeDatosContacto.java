package basedeDatos;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import clases.Aficion;
import clases.Contacto;
import clases.ContactoApodo;
import clases.ContactoEmpresa;
import clases.ContactoPersona;
import clases.Correo;
import clases.Telefono;
import clases.TipoContacto;
import clases.TipoTelefono;

public class BasedeDatosContacto {
	private Connection conn;
	private BasedeDatosPrincipal basedeDatosPrincipal;

	public BasedeDatosContacto() {
		super();
		this.basedeDatosPrincipal = new BasedeDatosPrincipal();
	}

	public boolean anadirContacto(Contacto c) {
		boolean anadido = true;
		conn = basedeDatosPrincipal.conectar();
		// conectar();
		String sql = "INSERT INTO contacto (idTipoContacto,apodo,nombre,apellidos,sexo,notas) VALUES(?,?,?,?,?,?)"; // metemos
		// maestra
		PreparedStatement ps;

		try {
			ps = conn.prepareStatement(sql);
			ps.setString(2, "");
			ps.setString(3, "");
			ps.setString(4, "");
			ps.setString(5, "");

			ps.setInt(1, c.getTipoContacto().getIdTipoContacto());

			if (c instanceof ContactoApodo) {
				ps.setString(2, ((ContactoApodo) c).getApodo());
			}

			if (c instanceof ContactoPersona) {
				ps.setString(3, ((ContactoPersona) c).getNombre());
				ps.setString(4, ((ContactoPersona) c).getApellidos());
				ps.setString(5, ((ContactoPersona) c).getSexo());
			}

			if (c instanceof ContactoEmpresa) {
				ps.setString(3, ((ContactoEmpresa) c).getNombre());
			}

			ps.setString(6, c.getNotas());
			ps.executeUpdate();
			sql = "Select max(idContacto) from Contacto"; // buscamos el ultimo id para ponerselo a la tabla telefono
															// (ya que alli no se sabe q id tiene )
			Statement stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery(sql);
			int IdContactoUltimo = rs.getInt(1);

			for (Telefono t : c.getListaTelefonos()) {
				sql = "INSERT INTO telefono(numeroTelefono,idContacto,idTipoTelefono)Values(?,?,?)";
				ps = conn.prepareStatement(sql);
				ps.setString(1, t.getTelefono());
				ps.setInt(2, IdContactoUltimo);
				ps.setInt(3, t.getTipoTelefono().getIdTipoTelefono());
				ps.executeUpdate();
			}

			///////////////////////// hacer lo mismo que con telefono con el resto de
			///////////////////////// arraylists(tipoTelefono,correo,aficiones etc)
			for (Correo co : c.getListaCorreos()) {
				String sql2 = "INSERT INTO correo(textoCorreo,idContacto)values (?,?)";
				ps = conn.prepareStatement(sql2);
				ps.setString(1, co.getTextoCorreo());
				ps.setInt(2, IdContactoUltimo);
				ps.executeUpdate();
			}

			for (Aficion a : c.getListaAficiones()) {
				String sql2 = "INSERT INTO ContactoAficion (idContacto, IdAficion)values (?,?)";
				ps = conn.prepareStatement(sql2);
				ps.setInt(1, IdContactoUltimo);
				ps.setInt(2, a.getIdAficion());
				ps.executeUpdate();
			}
		} catch (SQLException e) {
			anadido = false;
			e.printStackTrace();
		}
		basedeDatosPrincipal.desconectar();
		return anadido;
	}

	public boolean modificarContacto(Contacto c) {
		boolean anadido = true;
		conn = basedeDatosPrincipal.conectar();
		// conectar();
		String sql = "UPDATE contacto set idTipoContacto=?,apodo=?,nombre=?,"
				+ "apellidos=?,sexo =?,notas=? where idContacto=?"; // metemos
		// maestra
		PreparedStatement ps;

		try {
			ps = conn.prepareStatement(sql);
			ps.setString(2, "");
			ps.setString(3, "");
			ps.setString(4, "");
			ps.setString(5, "");

			ps.setInt(1, c.getTipoContacto().getIdTipoContacto());

			if (c instanceof ContactoApodo) {
				ps.setString(2, ((ContactoApodo) c).getApodo());
			}

			if (c instanceof ContactoPersona) {
				ps.setString(3, ((ContactoPersona) c).getNombre());
				ps.setString(4, ((ContactoPersona) c).getApellidos());
				ps.setString(5, ((ContactoPersona) c).getSexo());
			}

			if (c instanceof ContactoEmpresa) {
				ps.setString(3, ((ContactoEmpresa) c).getNombre());
			}

			ps.setString(6, c.getNotas());
			int id = c.getIdContacto();
			ps.setInt(7, id);
			ps.executeUpdate();

			sql = "DELETE FROM Telefono where idContacto=?";
			ps = conn.prepareStatement(sql);
			ps.setInt(1, id);
			ps.executeUpdate();

			sql = "DELETE FROM Correo where idContacto=?";
			ps = conn.prepareStatement(sql);
			ps.setInt(1, id);
			ps.executeUpdate();

			sql = "DELETE FROM ContactoAficion where idContacto=?";
			ps = conn.prepareStatement(sql);
			ps.setInt(1, id);
			ps.executeUpdate();

			for (Telefono t : c.getListaTelefonos()) {
				sql = "INSERT INTO telefono(numeroTelefono,idContacto,idTipoTelefono)Values(?,?,?)";
				ps = conn.prepareStatement(sql);
				ps.setString(1, t.getTelefono());
				ps.setInt(2, id);
				ps.setInt(3, t.getTipoTelefono().getIdTipoTelefono());
				ps.executeUpdate();
			}

			///////////////////////// hacer lo mismo que con telefono con el resto de
			///////////////////////// arraylists(tipoTelefono,correo,aficiones etc)
			for (Correo co : c.getListaCorreos()) {
				String sql2 = "INSERT INTO correo(textoCorreo,idContacto)values (?,?)";
				ps = conn.prepareStatement(sql2);
				ps.setString(1, co.getTextoCorreo());
				ps.setInt(2, id);
				ps.executeUpdate();
			}

			for (Aficion a : c.getListaAficiones()) {
				String sql2 = "INSERT INTO ContactoAficion (idContacto, IdAficion)values (?,?)";
				ps = conn.prepareStatement(sql2);
				ps.setInt(1, id);
				ps.setInt(2, a.getIdAficion());
				ps.executeUpdate();
			}
		} catch (SQLException e) {
			anadido = false;
			e.printStackTrace();
		}
		basedeDatosPrincipal.desconectar();
		return anadido;
	}

	public ArrayList<Contacto> mostrarContactos() {
		conn = basedeDatosPrincipal.conectar();
		// conectar();
		ArrayList<Contacto> listaContactos = new ArrayList<>();
		String sql = "SELECT * From Contacto";
		PreparedStatement ps = null;
		try {
			ps = conn.prepareStatement(sql);
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				int idContacto = rs.getInt("idContacto");
				int idTipoContacto = rs.getInt("idTipoContacto");
				String apodo = rs.getString("apodo");
				String nombre = rs.getString("nombre");
				String apellidos = rs.getString("apellidos");
				String sexo = rs.getString("sexo");
				String nota = rs.getString("notas");

				// ---------------------------

				sql = "SELECT tipo From TipoContacto where IdTipoContacto= ? ";
				ps = conn.prepareStatement(sql);
				ps.setInt(1, idTipoContacto);
				ResultSet rs2 = ps.executeQuery();
				String tipo = rs2.getString("tipo");
				TipoContacto tipoContacto = new TipoContacto(idTipoContacto, tipo);

				// --------------------------

				sql = "SELECT * From correo where IdContacto= ? ";
				ps = conn.prepareStatement(sql);
				ps.setInt(1, idContacto);
				ResultSet rs3 = ps.executeQuery();

				ArrayList<Correo> listaCorreos = new ArrayList();
				while (rs3.next()) {
					int idCorreo = rs3.getInt("idCorreo");
					String texto = rs3.getString("TextoCorreo");
					Correo c = new Correo(idCorreo, texto);
					listaCorreos.add(c);
				}

				// -------------------------
				ArrayList<Telefono> listaTelefonos = new ArrayList<>();
				sql = "SELECT * From Telefono where IdContacto= ? ";
				ps = conn.prepareStatement(sql);
				ps.setInt(1, idContacto);
				ResultSet rs4 = ps.executeQuery();
				while (rs4.next()) {
					int idTelefono = rs4.getInt("idTelefono");
					String telefono = rs4.getString("numerotelefono");
					int idTipoTelefono = rs4.getInt("idTipoTelefono");

					sql = "SELECT tipo From Tipotelefono where IdTipoTelefono= ? ";
					ps = conn.prepareStatement(sql);
					ps.setInt(1, idTipoTelefono);
					ResultSet rs5 = ps.executeQuery();
					String tipot = rs5.getString("tipo");
					TipoTelefono tipoTelefono = new TipoTelefono(idTipoTelefono, tipot);

					Telefono t = new Telefono(idTelefono, telefono, tipoTelefono);
					listaTelefonos.add(t);
				}

				ArrayList<Aficion> listaAficiones = new ArrayList<>();
				sql = "SELECT * From contactoAficion  where IdContacto= ? ";
				ps = conn.prepareStatement(sql);
				ps.setInt(1, idContacto);
				ResultSet rs6 = ps.executeQuery();
				while (rs6.next()) {
					int idAficion = rs6.getInt("idAficion");

					sql = "SELECT nombreAficion From aficion where IdAficion= ? ";
					ps = conn.prepareStatement(sql);
					ps.setInt(1, idAficion);
					ResultSet rs9 = ps.executeQuery();
					String nombreAficion = rs9.getString("nombreAficion");
					Aficion a = new Aficion(idAficion, nombreAficion);
					listaAficiones.add(a);

				}
				Contacto c = null;
				if (tipoContacto.getTipo().equalsIgnoreCase("apodo")) {
					c = new ContactoApodo(idContacto, tipoContacto, listaTelefonos, listaCorreos, listaAficiones, nota,
							sexo, apodo);
				}

				if (tipoContacto.getTipo().equalsIgnoreCase("empresa")) {
					c = new ContactoEmpresa(idContacto, tipoContacto, listaTelefonos, listaCorreos, listaAficiones,
							nota, nombre);
				}

				if (tipoContacto.getTipo().equalsIgnoreCase("persona")) {
					c = new ContactoPersona(idContacto, tipoContacto, listaTelefonos, listaCorreos, listaAficiones,
							nota, nombre, apellidos, sexo);
				}

				listaContactos.add(c);

			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		basedeDatosPrincipal.desconectar();
		return listaContactos;
	}

	public boolean borrarContacto(String id) {
		conn = basedeDatosPrincipal.conectar();
		// conectar();
		String sql = "DELETE FROM contacto where idContacto=?"; // metemos los campos que no se autoincrementan o no
																// tienen tabla maestra
		PreparedStatement ps;
		try {
			ps = conn.prepareStatement(sql);
			ps.setString(1, id);
			ps.executeUpdate();

			sql = "DELETE FROM Telefono where idContacto=?";
			ps = conn.prepareStatement(sql);
			ps.setString(1, id);
			ps.executeUpdate();

			sql = "DELETE FROM Correo where idContacto=?";
			ps = conn.prepareStatement(sql);
			ps.setString(1, id);
			ps.executeUpdate();

			sql = "DELETE FROM ContactoAficion where idContacto=?";
			ps = conn.prepareStatement(sql);
			ps.setString(1, id);
			ps.executeUpdate();

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}
		basedeDatosPrincipal.desconectar();
		return true;
	}

	public boolean borrarTelefono(String numTelefono) {
		conn = basedeDatosPrincipal.conectar();
		// conectar();
		String sql = "DELETE  From Telefono  where numeroTelefono= ? ";
		PreparedStatement pst = null;
		boolean borrado = true;
		try {
			pst = conn.prepareStatement(sql);
			pst.setString(1, numTelefono);
			pst.executeUpdate();

		} catch (SQLException e) {
			borrado = false;
			e.printStackTrace();
		}
		basedeDatosPrincipal.desconectar();
		return borrado;
	}

	public boolean borrarCorreoContacto(String nomCorreoo) {
		conn = basedeDatosPrincipal.conectar();
		// conectar();
		String sql = "DELETE From Correo  where TextoCorreo= ? ";
		PreparedStatement pst = null;
		boolean borrado = true;
		try {
			pst = conn.prepareStatement(sql);
			pst.setString(1, nomCorreoo);
			pst.executeUpdate();

		} catch (SQLException e) {
			borrado = false;
			e.printStackTrace();
		}
		basedeDatosPrincipal.desconectar();
		return borrado;
	}

	public Contacto buscarContactoPorIdContacto(int id) {
		conn = basedeDatosPrincipal.conectar();
		// conectar();
		Contacto c = null;
		String sql = "SELECT * From Contacto where idContacto = ?";
		PreparedStatement ps = null;
		try {
			ps = conn.prepareStatement(sql);
			ps.setInt(1, id);
			ResultSet rs = ps.executeQuery();
			if (rs.next()) {
				int idContacto = rs.getInt("idContacto");
				int idTipoContacto = rs.getInt("idTipoContacto");

				String apodo = rs.getString("apodo");
				String nombre = rs.getString("nombre");
				String apellidos = rs.getString("apellidos");
				String sexo = rs.getString("sexo");
				String nota = rs.getString("notas");

				// ---------------------------

				sql = "SELECT tipo From TipoContacto where IdTipoContacto= ? ";
				ps = conn.prepareStatement(sql);
				ps.setInt(1, idTipoContacto);
				ResultSet rs2 = ps.executeQuery();
				String tipo = rs2.getString("tipo");
				TipoContacto tipoContacto = new TipoContacto(idTipoContacto, tipo);

				// --------------------------

				sql = "SELECT * From correo where IdContacto= ? ";
				ps = conn.prepareStatement(sql);
				ps.setInt(1, idContacto);
				ResultSet rs3 = ps.executeQuery();

				ArrayList<Correo> listaCorreos = new ArrayList();
				while (rs3.next()) {
					int idCorreo = rs3.getInt("idCorreo");
					String texto = rs3.getString("TextoCorreo");
					Correo cc = new Correo(idCorreo, texto);
					listaCorreos.add(cc);
				}

				// -------------------------
				ArrayList<Telefono> listaTelefonos = new ArrayList<>();
				sql = "SELECT * From Telefono where IdContacto= ? ";
				ps = conn.prepareStatement(sql);
				ps.setInt(1, idContacto);
				ResultSet rs4 = ps.executeQuery();
				while (rs4.next()) {
					int idTelefono = rs4.getInt("idTelefono");
					String telefono = rs4.getString("numerotelefono");
					int idTipoTelefono = rs4.getInt("idTipoTelefono");

					sql = "SELECT tipo From Tipotelefono where IdTipoTelefono= ? ";
					ps = conn.prepareStatement(sql);
					ps.setInt(1, idTipoTelefono);
					ResultSet rs5 = ps.executeQuery();
					String tipot = rs5.getString("tipo");
					TipoTelefono tipoTelefono = new TipoTelefono(idTipoTelefono, tipot);

					Telefono t = new Telefono(idTelefono, telefono, tipoTelefono);
					listaTelefonos.add(t);
				}

				ArrayList<Aficion> listaAficiones = new ArrayList<>();
				sql = "SELECT * From contactoAficion  where IdContacto= ? ";
				ps = conn.prepareStatement(sql);
				ps.setInt(1, idContacto);
				ResultSet rs6 = ps.executeQuery();
				while (rs6.next()) {
					int idAficion = rs6.getInt("idAficion");

					sql = "SELECT nombreAficion From aficion where IdAficion= ? ";
					ps = conn.prepareStatement(sql);
					ps.setInt(1, idAficion);
					ResultSet rs5 = ps.executeQuery();
					String NombreAficion = rs5.getString("nombreAficion");
					Aficion a = new Aficion(idAficion, NombreAficion);
					listaAficiones.add(a);

				}

				if (tipoContacto.getTipo().equalsIgnoreCase("apodo")) {
					c = new ContactoApodo(idContacto, tipoContacto, listaTelefonos, listaCorreos, listaAficiones, nota,
							sexo, apodo);
				}

				if (tipoContacto.getTipo().equalsIgnoreCase("empresa")) {
					c = new ContactoEmpresa(idContacto, tipoContacto, listaTelefonos, listaCorreos, listaAficiones,
							nota, nombre);
				}

				if (tipoContacto.getTipo().equalsIgnoreCase("persona")) {
					c = new ContactoPersona(idContacto, tipoContacto, listaTelefonos, listaCorreos, listaAficiones,
							nota, nombre, apellidos, sexo);
				}

			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		basedeDatosPrincipal.desconectar();
		return c;
	}

	public ArrayList<Contacto> buscarContactosPorNombre(String nom) {
		conn = basedeDatosPrincipal.conectar();
		// conectar();
		ArrayList<Contacto> listaContactos = new ArrayList<>();
		String sql = "SELECT * From Contacto where nombre=?";
		PreparedStatement ps = null;
		try {
			ps = conn.prepareStatement(sql);
			ps.setString(1, nom);
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				int idContacto = rs.getInt("idContacto");
				int idTipoContacto = rs.getInt("idTipoContacto");
				String apodo = rs.getString("apodo");
				String nombre = rs.getString("nombre");
				String apellidos = rs.getString("apellidos");
				String sexo = rs.getString("sexo");
				String nota = rs.getString("notas");

				// ---------------------------

				sql = "SELECT tipo From TipoContacto where IdTipoContacto= ? ";
				ps = conn.prepareStatement(sql);
				ps.setInt(1, idTipoContacto);
				ResultSet rs2 = ps.executeQuery();
				String tipo = rs2.getString("tipo");
				TipoContacto tipoContacto = new TipoContacto(idTipoContacto, tipo);

				// --------------------------

				sql = "SELECT * From correo where IdContacto= ? ";
				ps = conn.prepareStatement(sql);
				ps.setInt(1, idContacto);
				ResultSet rs3 = ps.executeQuery();

				ArrayList<Correo> listaCorreos = new ArrayList();
				while (rs3.next()) {
					int idCorreo = rs3.getInt("idCorreo");
					String texto = rs3.getString("TextoCorreo");
					Correo c = new Correo(idCorreo, texto);
					listaCorreos.add(c);
				}

				// -------------------------
				ArrayList<Telefono> listaTelefonos = new ArrayList<>();
				sql = "SELECT * From Telefono where IdContacto= ? ";
				ps = conn.prepareStatement(sql);
				ps.setInt(1, idContacto);
				ResultSet rs4 = ps.executeQuery();
				while (rs4.next()) {
					int idTelefono = rs4.getInt("idTelefono");
					String telefono = rs4.getString("numerotelefono");
					int idTipoTelefono = rs4.getInt("idTipoTelefono");

					sql = "SELECT tipo From Tipotelefono where IdTipoTelefono= ? ";
					ps = conn.prepareStatement(sql);
					ps.setInt(1, idTipoTelefono);
					ResultSet rs5 = ps.executeQuery();
					String tipot = rs5.getString("tipo");
					TipoTelefono tipoTelefono = new TipoTelefono(idTipoTelefono, tipot);

					Telefono t = new Telefono(idTelefono, telefono, tipoTelefono);
					listaTelefonos.add(t);
				}

				ArrayList<Aficion> listaAficiones = new ArrayList<>();
				sql = "SELECT * From contactoAficion  where IdContacto= ? ";
				ps = conn.prepareStatement(sql);
				ps.setInt(1, idContacto);
				ResultSet rs6 = ps.executeQuery();
				while (rs6.next()) {
					int idAficion = rs6.getInt("idAficion");

					sql = "SELECT nombreAficion From aficion where IdAficion= ? ";
					ps = conn.prepareStatement(sql);
					ps.setInt(1, idAficion);
					ResultSet rs9 = ps.executeQuery();
					String nombreAficion = rs9.getString("nombreAficion");
					Aficion a = new Aficion(idAficion, nombreAficion);
					listaAficiones.add(a);

				}

				Contacto c = null;
				if (tipoContacto.getTipo().equalsIgnoreCase("apodo")) {
					c = new ContactoApodo(idContacto, tipoContacto, listaTelefonos, listaCorreos, listaAficiones, nota,
							sexo, apodo);
				}

				if (tipoContacto.getTipo().equalsIgnoreCase("empresa")) {
					c = new ContactoEmpresa(idContacto, tipoContacto, listaTelefonos, listaCorreos, listaAficiones,
							nota, nombre);
				}

				if (tipoContacto.getTipo().equalsIgnoreCase("persona")) {
					c = new ContactoPersona(idContacto, tipoContacto, listaTelefonos, listaCorreos, listaAficiones,
							nota, nombre, apellidos, sexo);
				}
				listaContactos.add(c);

			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		basedeDatosPrincipal.desconectar();
		return listaContactos;
	}

	public ArrayList<Contacto> buscarContactosPorApodo(String apod) {
		conn = basedeDatosPrincipal.conectar();
		// conectar();
		ArrayList<Contacto> listaContactos = new ArrayList<>();
		String sql = "SELECT * From Contacto where apodo=?";
		PreparedStatement ps = null;
		try {
			ps = conn.prepareStatement(sql);
			ps.setString(1, apod);
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				int idContacto = rs.getInt("idContacto");
				int idTipoContacto = rs.getInt("idTipoContacto");
				String apodo = rs.getString("apodo");
				String nombre = rs.getString("nombre");
				String apellidos = rs.getString("apellidos");
				String sexo = rs.getString("sexo");
				String nota = rs.getString("notas");

				// ---------------------------

				sql = "SELECT tipo From TipoContacto where IdTipoContacto= ? ";
				ps = conn.prepareStatement(sql);
				ps.setInt(1, idTipoContacto);
				ResultSet rs2 = ps.executeQuery();
				String tipo = rs2.getString("tipo");
				TipoContacto tipoContacto = new TipoContacto(idTipoContacto, tipo);

				// --------------------------

				sql = "SELECT * From correo where IdContacto= ? ";
				ps = conn.prepareStatement(sql);
				ps.setInt(1, idContacto);
				ResultSet rs3 = ps.executeQuery();

				ArrayList<Correo> listaCorreos = new ArrayList();
				while (rs3.next()) {
					int idCorreo = rs3.getInt("idCorreo");
					String texto = rs3.getString("TextoCorreo");
					Correo c = new Correo(idCorreo, texto);
					listaCorreos.add(c);
				}

				// -------------------------
				ArrayList<Telefono> listaTelefonos = new ArrayList<>();
				sql = "SELECT * From Telefono where IdContacto= ? ";
				ps = conn.prepareStatement(sql);
				ps.setInt(1, idContacto);
				ResultSet rs4 = ps.executeQuery();
				while (rs4.next()) {
					int idTelefono = rs4.getInt("idTelefono");
					String telefono = rs4.getString("numerotelefono");
					int idTipoTelefono = rs4.getInt("idTipoTelefono");

					sql = "SELECT tipo From Tipotelefono where IdTipoTelefono= ? ";
					ps = conn.prepareStatement(sql);
					ps.setInt(1, idTipoTelefono);
					ResultSet rs5 = ps.executeQuery();
					String tipot = rs5.getString("tipo");
					TipoTelefono tipoTelefono = new TipoTelefono(idTipoTelefono, tipot);

					Telefono t = new Telefono(idTelefono, telefono, tipoTelefono);
					listaTelefonos.add(t);
				}

				ArrayList<Aficion> listaAficiones = new ArrayList<>();
				sql = "SELECT * From contactoAficion  where IdContacto= ? ";
				ps = conn.prepareStatement(sql);
				ps.setInt(1, idContacto);
				ResultSet rs6 = ps.executeQuery();
				while (rs6.next()) {
					int idAficion = rs6.getInt("idAficion");

					sql = "SELECT nombreAficion From aficion where IdAficion= ? ";
					ps = conn.prepareStatement(sql);
					ps.setInt(1, idAficion);
					ResultSet rs9 = ps.executeQuery();
					String nombreAficion = rs9.getString("nombreAficion");
					Aficion a = new Aficion(idAficion, nombreAficion);
					listaAficiones.add(a);

				}

				Contacto c = null;
				if (tipoContacto.getTipo().equalsIgnoreCase("apodo")) {
					c = new ContactoApodo(idContacto, tipoContacto, listaTelefonos, listaCorreos, listaAficiones, nota,
							sexo, apodo);
				}

				if (tipoContacto.getTipo().equalsIgnoreCase("empresa")) {
					c = new ContactoEmpresa(idContacto, tipoContacto, listaTelefonos, listaCorreos, listaAficiones,
							nota, nombre);
				}

				if (tipoContacto.getTipo().equalsIgnoreCase("persona")) {
					c = new ContactoPersona(idContacto, tipoContacto, listaTelefonos, listaCorreos, listaAficiones,
							nota, nombre, apellidos, sexo);
				}
				listaContactos.add(c);

			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		basedeDatosPrincipal.desconectar();
		return listaContactos;
	}

	public ArrayList<Contacto> buscarContactosPorTelefono(String tel) {
		conn = basedeDatosPrincipal.conectar();
		// conectar();
		ArrayList<Contacto> listaContactos = new ArrayList<>();
		String sql = "SELECT * From Contacto INNER JOIN Telefono ON contacto.idContacto=Telefono.idContacto where numeroTelefono=?";
		PreparedStatement ps = null;
		try {
			ps = conn.prepareStatement(sql);
			ps.setString(1, tel);
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				int idContacto = rs.getInt("idContacto");
				int idTipoContacto = rs.getInt("idTipoContacto");
				String apodo = rs.getString("apodo");
				String nombre = rs.getString("nombre");
				String apellidos = rs.getString("apellidos");
				String sexo = rs.getString("sexo");
				String nota = rs.getString("notas");

				// ---------------------------

				sql = "SELECT tipo From TipoContacto where IdTipoContacto= ? ";
				ps = conn.prepareStatement(sql);
				ps.setInt(1, idTipoContacto);
				ResultSet rs2 = ps.executeQuery();
				String tipo = rs2.getString("tipo");
				TipoContacto tipoContacto = new TipoContacto(idTipoContacto, tipo);

				// --------------------------

				sql = "SELECT * From correo where IdContacto= ? ";
				ps = conn.prepareStatement(sql);
				ps.setInt(1, idContacto);
				ResultSet rs3 = ps.executeQuery();

				ArrayList<Correo> listaCorreos = new ArrayList();
				while (rs3.next()) {
					int idCorreo = rs3.getInt("idCorreo");
					String texto = rs3.getString("TextoCorreo");
					Correo c = new Correo(idCorreo, texto);
					listaCorreos.add(c);
				}

				// -------------------------
				ArrayList<Telefono> listaTelefonos = new ArrayList<>();
				sql = "SELECT * From Telefono where IdContacto= ? ";
				ps = conn.prepareStatement(sql);
				ps.setInt(1, idContacto);
				ResultSet rs4 = ps.executeQuery();
				while (rs4.next()) {
					int idTelefono = rs4.getInt("idTelefono");
					String telefono = rs4.getString("numerotelefono");
					int idTipoTelefono = rs4.getInt("idTipoTelefono");

					sql = "SELECT tipo From Tipotelefono where IdTipoTelefono= ? ";
					ps = conn.prepareStatement(sql);
					ps.setInt(1, idTipoTelefono);
					ResultSet rs5 = ps.executeQuery();
					String tipot = rs5.getString("tipo");
					TipoTelefono tipoTelefono = new TipoTelefono(idTipoTelefono, tipot);

					Telefono t = new Telefono(idTelefono, telefono, tipoTelefono);
					listaTelefonos.add(t);
				}

				ArrayList<Aficion> listaAficiones = new ArrayList<>();
				sql = "SELECT * From contactoAficion  where IdContacto= ? ";
				ps = conn.prepareStatement(sql);
				ps.setInt(1, idContacto);
				ResultSet rs6 = ps.executeQuery();
				while (rs6.next()) {
					int idAficion = rs6.getInt("idAficion");

					sql = "SELECT nombreAficion From aficion where IdAficion= ? ";
					ps = conn.prepareStatement(sql);
					ps.setInt(1, idAficion);
					ResultSet rs9 = ps.executeQuery();
					String nombreAficion = rs9.getString("nombreAficion");
					Aficion a = new Aficion(idAficion, nombreAficion);
					listaAficiones.add(a);

				}

				Contacto c = null;
				if (tipoContacto.getTipo().equalsIgnoreCase("apodo")) {
					c = new ContactoApodo(idContacto, tipoContacto, listaTelefonos, listaCorreos, listaAficiones, nota,
							sexo, apodo);
				}

				if (tipoContacto.getTipo().equalsIgnoreCase("empresa")) {
					c = new ContactoEmpresa(idContacto, tipoContacto, listaTelefonos, listaCorreos, listaAficiones,
							nota, nombre);
				}

				if (tipoContacto.getTipo().equalsIgnoreCase("persona")) {
					c = new ContactoPersona(idContacto, tipoContacto, listaTelefonos, listaCorreos, listaAficiones,
							nota, nombre, apellidos, sexo);
				}
				listaContactos.add(c);

			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		basedeDatosPrincipal.desconectar();
		return listaContactos;
	}

	public ArrayList<Correo> mostrarCorreosContacto(String id) {
		conn = basedeDatosPrincipal.conectar();
		// conectar();
		ArrayList<Correo> listaCorreos = new ArrayList<>();
		String sql = "SELECT idCorreo,textoCorreo From Correo where IdContacto= ? ";
		PreparedStatement ps;
		try {
			ps = conn.prepareStatement(sql);
			ps.setString(1, id);
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				int idCorreo = rs.getInt("idCorreo");
				String nombre = rs.getString("textoCorreo");

				Correo c = new Correo(idCorreo, nombre);
				listaCorreos.add(c);
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		basedeDatosPrincipal.desconectar();
		return listaCorreos;
	}

	public ArrayList<Telefono> mostrarTelefonosContacto(String id) {
		conn = basedeDatosPrincipal.conectar();
		// conectar();
		ArrayList<Telefono> listaTelefonos = new ArrayList<>();
		String sql = "SELECT * From Telefono where IdContacto= ? ";
		PreparedStatement ps;
		try {
			ps = conn.prepareStatement(sql);
			ps.setString(1, id);
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				int idTelefono = rs.getInt("idTelefono");
				String telefono = rs.getString("numerotelefono");
				int idTipoTelefono = rs.getInt("idTipoTelefono");

				sql = "SELECT tipo From Tipotelefono where IdTipoTelefono= ? ";
				ps = conn.prepareStatement(sql);
				ps.setInt(1, idTipoTelefono);
				ResultSet rs5 = ps.executeQuery();
				String tipot = rs5.getString("tipo");
				TipoTelefono tipoTelefono = new TipoTelefono(idTipoTelefono, tipot);

				Telefono t = new Telefono(idTelefono, telefono, tipoTelefono);
				listaTelefonos.add(t);
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		basedeDatosPrincipal.desconectar();
		return listaTelefonos;
	}

	public ArrayList<Aficion> mostrarAficionesContacto(String id) {
		conn = basedeDatosPrincipal.conectar();
		// conectar();
		ArrayList<Aficion> listaAficiones = new ArrayList<>();
		String sql = "SELECT * From Aficion inner join ContactoAficion "
				+ "on Aficion.idAficion=ContactoAficion.idAficion"
				+ " inner join Contacto on ContactoAficion.idContacto=Contacto.idContacto"
				+ " where Contacto.IdContacto= ? ";
		PreparedStatement ps;
		try {
			ps = conn.prepareStatement(sql);
			ps.setString(1, id);
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				int idAfic = rs.getInt("idAficion");
				String nombre = rs.getString("nombreAficion");

				Aficion c = new Aficion(idAfic, nombre);
				listaAficiones.add(c);
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		basedeDatosPrincipal.desconectar();
		return listaAficiones;
	}

}
