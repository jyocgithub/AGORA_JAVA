package basedeDatos;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import clases.Aficion;

public class BasedeDatosAficiones {
	private Connection conn;
	private BasedeDatosPrincipal basedeDatosPrincipal;

	public BasedeDatosAficiones() {
		super();
		this.basedeDatosPrincipal = new BasedeDatosPrincipal();
	}

	public boolean borrarAficion(String nombreAficionBorrar) {
		conn = basedeDatosPrincipal.conectar();
		// conectar();
		boolean puedoBorrar = true;
		String sql = "select idAficion from Aficion where nombreAficion=?"; // buscamos el id de la aficion a borrar
		PreparedStatement pst = null;
		PreparedStatement pst2 = null;
		try {
			pst = conn.prepareStatement(sql); // pst1
			pst.setString(1, nombreAficionBorrar);
			ResultSet rs = pst.executeQuery();
			if (rs.next()) {
				int ID = rs.getInt("IdAficion");
				String sql3 = "select * from ContactoAficion where idAficion=?"; // buscamos en la tabla contactoaficion
				pst2 = conn.prepareStatement(sql3); // si existe algun contacto con el id de la aficion
				pst2.setInt(1, ID);
				ResultSet rs2 = pst2.executeQuery();
				if (rs2.next()) { // si la encuetra es que esta usada por algun contacto
					puedoBorrar = false;
				}

			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		if (puedoBorrar == true) { // (!usada) // si no esta usada borrarla.
			String sql2 = "delete from Aficion where nombreAficion=?";
			PreparedStatement pst3 = null;

			try {
				pst3 = conn.prepareStatement(sql2);
				pst3.setString(1, nombreAficionBorrar);
				pst3.executeUpdate();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		basedeDatosPrincipal.desconectar();
		return puedoBorrar;
	}
	/////////////////////////////////////////////////////////////////
	// retornar el id

	public int dameIdAficion(String nombreAficion) {
		conn = basedeDatosPrincipal.conectar();
		// conectar();
		String sql = "select idAficion from Aficion where nombreAficion=?"; // buscamos el id de la aficion a borrar
		PreparedStatement pst = null;
		int ID = -1;
		try {
			pst = conn.prepareStatement(sql); // pst1
			pst.setString(1, nombreAficion);
			ResultSet rs = pst.executeQuery();
			if (rs.next()) {
				ID = rs.getInt("IdAficion");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		// desconectar();
		return ID;
	}

	public boolean estaUsadaAficion(String nombreAficion) {
		conn = basedeDatosPrincipal.conectar();
		// conectar();
		boolean usada = false;
		PreparedStatement pst = null;
		int ID = dameIdAficion(nombreAficion);
		try {
			String sql = "select * from ContactoAficion where idAficion=?"; // buscamos en la tabla contactoaficion
			pst = conn.prepareStatement(sql); // si existe algun contacto con el id de la aficion
			pst.setInt(1, ID);
			ResultSet rs = pst.executeQuery();
			if (rs.next()) { // si la encuetra es que esta usada por algun contacto
				usada = true;
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		basedeDatosPrincipal.desconectar();
		return usada;
	}

	public void modificarAficion(String nombreAficionModificar, String nombreNuevo) {
		conn = basedeDatosPrincipal.conectar();
		// conectar();
		String sql2 = "UPDATE Aficion set nombreAficion=? where idAficion=?";
		PreparedStatement pst3 = null;
		int ID = dameIdAficion(nombreAficionModificar);
		try {
			pst3 = conn.prepareStatement(sql2);
			pst3.setString(1, nombreNuevo);
			pst3.setInt(2, ID);
			pst3.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		basedeDatosPrincipal.desconectar();
	}

	public boolean anadirAficion(Aficion a) {
		conn = basedeDatosPrincipal.conectar();
		// conectar();
		boolean respuesta = true;
		String sql2 = "INSERT INTO Aficion(nombreAficion)VALUES (?)";
		PreparedStatement pst3 = null;

		try {
			pst3 = conn.prepareStatement(sql2);
			pst3.setString(1, a.getNombreAficion());
			pst3.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			respuesta = false;
			e.printStackTrace();
		}
		basedeDatosPrincipal.desconectar();
		return respuesta;
	}

	public ArrayList<Aficion> mostrarAficiones() {
		conn = basedeDatosPrincipal.conectar();
		// conectar();
		ArrayList<Aficion> ListaAficion = new ArrayList<>();
		String sql = "SELECT * From Aficion";
		try {
			PreparedStatement ps = conn.prepareStatement(sql);
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				int id = rs.getInt("idAficion");
				String nombre = rs.getString("nombreAficion");
				Aficion a = new Aficion(id, nombre);
				ListaAficion.add(a);
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		basedeDatosPrincipal.desconectar();
		return ListaAficion;
	}

}
