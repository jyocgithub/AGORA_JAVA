package clases;

import java.util.ArrayList;

import clases.Aficion;
import clases.Correo;
import clases.Telefono;
import clases.TipoContacto;

public abstract class Contacto {
	
	private int idContacto;
	private TipoContacto tipoContacto;
	private ArrayList<Telefono> listaTelefonos=new ArrayList<>();
	private ArrayList<Correo> listaCorreos=new ArrayList<>();;
	private ArrayList<Aficion> listaAficiones=new ArrayList<>();;
	private String notas;
	
	
	public Contacto() {}

	public Contacto(int idContacto, TipoContacto tipoContacto, ArrayList<Telefono> listaTelefonos,
			ArrayList<Correo> listaCorreos, ArrayList<Aficion> listaAficiones, String notas) {
		this.idContacto = idContacto;
		this.tipoContacto = tipoContacto;
		this.listaTelefonos = listaTelefonos;
		this.listaCorreos = listaCorreos;
		this.listaAficiones = listaAficiones;
		this.notas = notas;
	}
	
	
	
	
	public int getIdContacto() {
		return idContacto;
	}




	public void setIdContacto(int idContacto) {
		this.idContacto = idContacto;
	}




	public TipoContacto getTipoContacto() {
		return tipoContacto;
	}




	public void setTipoContacto(TipoContacto tipoContacto) {
		this.tipoContacto = tipoContacto;
	}




	public ArrayList<Telefono> getListaTelefonos() {
		return listaTelefonos;
	}




	public void setListaTelefonos(ArrayList<Telefono> listaTelefonos) {
		this.listaTelefonos = listaTelefonos;
	}




	public ArrayList<Correo> getListaCorreos() {
		return listaCorreos;
	}




	public void setListaCorreos(ArrayList<Correo> listaCorreos) {
		this.listaCorreos = listaCorreos;
	}




	public ArrayList<Aficion> getListaAficiones() {
		return listaAficiones;
	}




	public void setListaAficiones(ArrayList<Aficion> listaAficiones) {
		this.listaAficiones = listaAficiones;
	}




	public String getNotas() {
		return notas;
	}




	public void setNotas(String notas) {
		this.notas = notas;
	}




	public abstract String toString();
	}
	
	

