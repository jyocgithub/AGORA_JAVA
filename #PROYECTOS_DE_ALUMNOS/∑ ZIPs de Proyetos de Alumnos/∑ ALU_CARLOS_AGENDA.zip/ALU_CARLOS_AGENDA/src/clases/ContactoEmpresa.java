package clases;

import java.util.ArrayList;

import clases.Aficion;
import clases.Correo;
import clases.Telefono;
import clases.TipoContacto;

public class ContactoEmpresa extends Contacto {

	private String nombre;
	public ContactoEmpresa() {}
	
	public ContactoEmpresa(int idContacto, TipoContacto tipoContacto, ArrayList<Telefono> listaTelefonos,
			ArrayList<Correo> listaCorreos, ArrayList<Aficion> listaAficiones, String notas, String nombre) {
		super(idContacto, tipoContacto, listaTelefonos, listaCorreos, listaAficiones, notas);
		this.nombre = nombre;
	}


	public String getNombre() {
		return nombre;
	}


	public void setNombre(String nombre) {
		this.nombre = nombre;
	}




	@Override
	public String toString() {
		return "ContactoEmpresa [getIdContacto()=" + getIdContacto() + ", getNombre()=" + getNombre()
				+ ", getTipoContacto()=" + getTipoContacto() + ", getListaTelefonos()=" + getListaTelefonos()
				+ ", getListaCorreos()=" + getListaCorreos() + ", getListaAficiones()=" + getListaAficiones()
				+ ", getNotas()=" + getNotas() + "]";
	}

	
	


}
