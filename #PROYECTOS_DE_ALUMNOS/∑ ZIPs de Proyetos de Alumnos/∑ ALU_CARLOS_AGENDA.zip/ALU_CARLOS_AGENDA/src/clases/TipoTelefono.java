package clases;

public class TipoTelefono {
	private int idTipoTelefono;
	private String tipo;

	public TipoTelefono(int idTipoTelefono, String tipo) {
		this.idTipoTelefono = idTipoTelefono;
		this.tipo = tipo;
	}

	public int getIdTipoTelefono() {
		return idTipoTelefono;
	}

	public void setIdTipoTelefono(int idTipoTelefono) {
		this.idTipoTelefono = idTipoTelefono;
	}

	public String getTipo() {
		return tipo;
	}

	public void setTipo(String tipo) {
		this.tipo = tipo;
	}

}
