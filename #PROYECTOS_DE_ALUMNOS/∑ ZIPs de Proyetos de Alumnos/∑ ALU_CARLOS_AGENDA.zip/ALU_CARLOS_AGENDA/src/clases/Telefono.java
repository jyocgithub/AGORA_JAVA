package clases;

public class Telefono {
	private int idTelefono;
	private String telefono;
	private TipoTelefono tipoTelefono;

	public Telefono(int idTelefono, String telefono, TipoTelefono tipoTelefono) {
		this.idTelefono = idTelefono;
		this.telefono = telefono;
		this.tipoTelefono = tipoTelefono;
	}

	public int getIdTelefono() {
		return idTelefono;
	}

	public void setIdTelefono(int idTelefono) {
		this.idTelefono = idTelefono;
	}

	public String getTelefono() {
		return telefono;
	}

	public void setTelefono(String telefono) {
		this.telefono = telefono;
	}

	public TipoTelefono getTipoTelefono() {
		return tipoTelefono;
	}

	public void setTipoTelefono(TipoTelefono tipoTelefono) {
		this.tipoTelefono = tipoTelefono;
	}
	
}
