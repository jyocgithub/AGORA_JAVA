package gramaticas;

import java.util.Arrays;

import javax.swing.JFrame;
import javax.swing.JPanel;

import org.antlr.v4.runtime.ANTLRInputStream;
import org.antlr.v4.runtime.CharStream;
import org.antlr.v4.runtime.CommonTokenStream;
import org.antlr.v4.runtime.TokenStream;
import org.antlr.v4.runtime.tree.ParseTree;

public class TestGramatica {
	public static void main(String[] args) {
		// prepare token stream
		CharStream stream = new ANTLRInputStream("hello antlr");
		MigramaticaLexer lexer = new MigramaticaLexer(stream);
		TokenStream tokenStream = new CommonTokenStream(lexer);
		MigramaticaParser parser = new MigramaticaParser(tokenStream);
		ParseTree tree = parser.consume();

		// show AST in console
		System.out.println(tree.toStringTree(parser));

		// show AST in GUI
		JFrame frame = new JFrame("Antlr AST");
		JPanel panel = new JPanel();
		org.antlr.v4.gui.TreeViewer viewr = new org.antlr.v4.gui.TreeViewer(Arrays.asList(parser.getRuleNames()), tree);
		viewr.setScale(1.5);// scale a little
		panel.add(viewr);
		frame.add(panel);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setSize(200, 200);
		frame.setVisible(true);
	}
}