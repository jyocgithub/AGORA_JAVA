// Generated from /Users/iniaki/WorkSpaces/1.JAVA/🤖 CRISTIAN/CompiladorParserLexer/src/gramaticas/MigramaticaParser.g4 by ANTLR 4.7.1

	package gramaticas;

import org.antlr.v4.runtime.tree.ParseTreeListener;

/**
 * This interface defines a complete listener for a parse tree produced by
 * {@link MigramaticaParser}.
 */
public interface MigramaticaParserListener extends ParseTreeListener {
	/**
	 * Enter a parse tree produced by {@link MigramaticaParser#csv}.
	 * @param ctx the parse tree
	 */
	void enterCsv(MigramaticaParser.CsvContext ctx);
	/**
	 * Exit a parse tree produced by {@link MigramaticaParser#csv}.
	 * @param ctx the parse tree
	 */
	void exitCsv(MigramaticaParser.CsvContext ctx);
	/**
	 * Enter a parse tree produced by {@link MigramaticaParser#cabecera}.
	 * @param ctx the parse tree
	 */
	void enterCabecera(MigramaticaParser.CabeceraContext ctx);
	/**
	 * Exit a parse tree produced by {@link MigramaticaParser#cabecera}.
	 * @param ctx the parse tree
	 */
	void exitCabecera(MigramaticaParser.CabeceraContext ctx);
	/**
	 * Enter a parse tree produced by {@link MigramaticaParser#linea}.
	 * @param ctx the parse tree
	 */
	void enterLinea(MigramaticaParser.LineaContext ctx);
	/**
	 * Exit a parse tree produced by {@link MigramaticaParser#linea}.
	 * @param ctx the parse tree
	 */
	void exitLinea(MigramaticaParser.LineaContext ctx);
	/**
	 * Enter a parse tree produced by {@link MigramaticaParser#campo}.
	 * @param ctx the parse tree
	 */
	void enterCampo(MigramaticaParser.CampoContext ctx);
	/**
	 * Exit a parse tree produced by {@link MigramaticaParser#campo}.
	 * @param ctx the parse tree
	 */
	void exitCampo(MigramaticaParser.CampoContext ctx);
}