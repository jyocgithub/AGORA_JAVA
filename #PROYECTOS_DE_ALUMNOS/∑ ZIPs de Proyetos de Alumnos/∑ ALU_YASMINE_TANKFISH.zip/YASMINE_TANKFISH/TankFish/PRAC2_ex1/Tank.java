package PRAC2_ex1;

import java.util.Arrays;

/**
 * This class represents a Tank of UOCarium.
 * @author David Garcia Solorzano
 * @version 1.0
 */

public class Tank {

	/**
	 * Tank's name, e.g. Malaga.	
	 */	
	private String name;
	
	/**
	 * Tank's description, e.g. Acuario de Malaga.	
	 */
	private String description;
	/**
	 * Image source.
	 */	
	private String imageBackground;
	/**
	 * Tank's length.	
	 */
	private double length;
	/**
	 * Tank's height.	
	 */
	private double height;
	/**
	 * Tank's width.	
	 */
	private double width;
	/**
	 * Tank's temperature.	
	 */
	private double temperature;
	/**
	 * Tank's PH.		
	 */
	private int ph;
	/**
	 * Tank's items.		
	 */
	private Item[] items;
	
	
	
	/**
	 * Default constructor. It assigns the default value to all the instance's fields/attributes.
	 * @throws Exception When name is longer than 40 characters, length less than 0.1, width less than 0.1, height less than 0.1 or ph is not between 0 and 14.
	 */
	public Tank() throws Exception{
		this("Default", "Tank Default", 50.25, 10.55, 100.232, "./", 15, 7);
	}
	
	/**
	 * Constructor with arguments.
	 * @param name Tank's  name.
	 * @param description Tank's description.
	 * @param length Tank's length.
	 * @param height Tank's height.
	 * @param width Tank's width.
	 * @param imageBackground Source where the tank's image is.
	 * @param temperature Tank's temperature.
	 * @param ph Tank's PH.
	 * @throws Exception When name is longer than 40 characters, length less than 0.1, width less than 0.1, height less than 0.1 or ph is not between 0 and 14.
	 */
	public Tank(String name, String description, double length, double height, double width, String imageBackground, double temperature, int ph) throws Exception {
		setName(name);
		setDescription(description);
		setLength(length);
		setHeight(height);
		setWidth(width);
		setImageBackground(imageBackground);
		setTemperature(temperature);
		setPh(ph);
		items = new Item[10];
	}
	
	
	
	public void warm() {
		this.temperature = this.temperature + 0.1;
	}
	
	
	public void cool() {
		this.temperature = this.temperature - 0.1;
	}
	
	
	public void increasePH() throws Exception {
		setPh(this.ph + 1);
	}
	
	
	
	public void decreasePH() throws Exception {
		setPh(this.ph - 1);
	}
	
	public double getVolume() {
		return this.length * this.height * this.width;
	}
	
	public double getMaxLiters() {
		return getVolume()/1000;
	}
	
	public Item getItem(int index) throws Exception {
		if(index<0 || index>9) {
			throw new IndexOutOfBoundsException("[ERROR] The index is out of the range of the item list");
		}
		
		return items[index];
	}
	
	public int getNumberItems() {
		int res= 0;

		for(int i=0; i<items.length; i++) {
			if( items[i] != null ) {
				res++;
			}
		}
		return res;
	}
	
	public Item[]  empty() {
		int numAntiguos =  this.getNumberItems();
		if(numAntiguos == 0) {
			return null;
		}
		
		Item[] antiguos = new Item[numAntiguos ];
		int segundoindice = 0;
		for(int i=0; i<items.length; i++) {
			if( items[i] != null ) {
				antiguos[segundoindice] = items[i];
				segundoindice++;
				items[i].setTank(null);
				items[i] = null;
			}
		}
		
		return antiguos;
	}
	
	public boolean contains(Item elementoQueBusco) {		
		boolean existe = false;
		
		for(int i=0; i<items.length && existe==false; i++) {
			if( items[i] != null ) {
				if( items[i] == elementoQueBusco ) {
					existe = true;
				}
			}
		}	
		return existe;
	}
	
	
	
	
	public int getFirstFreePosition() {		
		int resultado = -1;	
		for(int i=0; i<items.length && resultado==-1; i++) {
			if( items[i] == null ) {
				resultado = i; 
			}
		}	
		return resultado;
	}
	
	
	
	public boolean isFull() {
		if( this.getNumberItems() == 10) {
			return true;	
		}
		return false;
	}
	
	public void addItem(Item itemQueGuardo) {
		
		if(itemQueGuardo == null) {
			throw new IndexOutOfBoundsException("[ERROR] The item must be an Item object!!");
		}
		if(this.isFull()) {
			throw new IndexOutOfBoundsException("[ERROR] Tank cannot have more than 10 items!!");
		}
		
		if(this.contains(itemQueGuardo)) {
			throw new IndexOutOfBoundsException("[ERROR] The item which you want to add is already in the tank!!");	
		}
		
		int huecolibre = this.getFirstFreePosition();
		items[huecolibre] = itemQueGuardo;
	
		itemQueGuardo.setTank(this);

	}
	
	
	public Item removeItem(int indice) {
		if(indice <0 || indice > 9) {
			throw new IndexOutOfBoundsException("[ERROR] The index is out of the range of the item list");
		}
		
		Item elquehabia = items[indice];
		items[indice] = null;
		elquehabia.setTank(null);
		return elquehabia;

		
	}
	
	
	public void removeItem(Item elementoQueBorro) {
		
		if( ! this.contains(elementoQueBorro)) {
			throw new IndexOutOfBoundsException("[ERROR] The item does not exist in the tank");	
		}

		int posicion = this.getPosition(elementoQueBorro);
		items[posicion].setTank(null);
		items[posicion] = null;
	
	}
	
	public void removeDeadItems() {
		for(int i=0; i<items.length; i++) {
			if( items[i] != null ) {
				if(items[i].isDead()==true) {
					items[i].setTank(null);
					items[i] = null;
				}
			}
		}
	}
	
	public int getPosition(Item elementoQueBusco) {		
		int posicion = -1;
		
		for(int i=0; i<items.length && posicion == -1; i++) {
			if( items[i] != null ) {
				if( items[i] == elementoQueBusco ) {
					posicion = i;
				}
			}
		}	
		return posicion;
	}
	// GETTERS Y SETTERS ------------------------------------------------
	
	public Item[] getItems() {
		return items;
	}
	
	
	
	
	/**
	 * It is name's getter.
	 * @return Tank's name.
	 */
	public String getName() {
		return name;
	}

	/**
	 * It is name's setter.
	 * @param name Tanks's name.
	 * @throws Exception When param "name" is longer than 40 characters.
	 */
	public void setName(String name) throws Exception {
		if(name.length()>40) {
			throw new Exception("[ERROR] Name cannot be longer than 40 characters!!");
		}
		this.name = name;
	}
	
	
	/**
	 * It is description's getter.
	 * @return Tank's description.
	 */
	public String getDescription() {
		return description;
	}
	
	/**
	 * It is description's setter.
	 * @param description Tank's description.
	 */
	public void setDescription(String description) {
		this.description = description;
	}

	/**
	 * It is length's getter. 
	 * @return Tank's width.
	 */
	public double getLength(){
		return length;
	}
	

	/**
	 * It is length's setter.
	 * @param length Tank's width.
	 * @throws Exception When param "length" is less than 0.1.
	 */

	public void setLength(double length) throws Exception{
		if(length < 0.1) {
			throw new Exception("[ERROR] Length cannot be less than 0.1 cm.!!");
			
		}
		this.length = length;
	}
	
	/**
	 * It is height's getter. 
	 * @return Tank's height.
	 */
	public double getHeight() {		
		return height;
	}

	/**
	 * It is height's setter.
	 * @param height Tank's height.
	 * @throws Exception When param "height" is less than 0.1.
	 */
	public void setHeight(double height) throws Exception {
		if(height < 0.1) {
			throw new Exception("[ERROR] Height cannot be less than 0.1 cm.!!");
		}
		this.height = height;
	}
	
	/**
	 * It is width's getter. 
	 * @return Tank's width.
	 */
	public double getWidth() {
		return width;
	}

	/**
	 * It is width's setter.
	 * @param width Tank's width.
	 * @throws Exception When param "width" is less than 0.1.
	 */
	public void setWidth(double width) throws Exception {
		if(width<0.1) {
			throw new Exception("[ERROR] Width cannot be less than 0.1 cm.!!");
		}
		this.width = width;
	}
	
	/**
	 * It is imageBackground's getter. 
	 * @return Source where the team's image is.
	 */
	
	public String getImageBackground() {
		return imageBackground;
	}
	
	/**
	 * It is imageBackground's setter.  
	 * @param imageBackground Source where the tank's image is.
	 */
	public void setImageBackground(String imageBackground) {
		this.imageBackground = imageBackground;
	}
	
	/**
	 * It is temperature's getter. 
	 * @return temperature Tank's temperature.
	 */
	public double getTemperature() {
		return temperature;
	}
	
	/**
	 * It is temperature setter. 
	 * @param temperature Tank's temperature.
	 */
	public void setTemperature(double temperature) {
		this.temperature = temperature;
	}
	
	/**
	 * It is ph's getter. 
	 * @return Tank's ph.
	 */
	public int getPh() {
		return ph;
	}

	/**
	 * It is ph's setter.
	 * @param ph Number of PH in the tank.
	 * @throws Exception When param "ph" is not between 0 and 14.
	 */
	public void setPh(int ph) throws Exception {
		if(ph<0 || ph>14) {
			throw new Exception("[ERROR] PH must be a value between 0 and 14");
		}
		this.ph = ph;
	}

	@Override
	public String toString() {
		String res = "";
		res = res + this.name + "\n";
		res = res + this.description + "\n";
		res = res + "Length: "+ this.length + "\n";
		res = res + "Height: "+ this.height + "\n";
		res = res + "Width: "+ this.width + "\n";
		res = res + "Temperature: "+ this.temperature + "\n";
		res = res + "Ph: "+ this.ph + "\n";
		res = res + "Items : " + "\n";
		
		for(int i=0; i<items.length; i++) {
			if( items[i] != null ) {
				res = res + "\t\t" +  items[i].toString() + "\n";
			}
			
		}
		
	
		
		return res;
	}
	
	
	
	
}