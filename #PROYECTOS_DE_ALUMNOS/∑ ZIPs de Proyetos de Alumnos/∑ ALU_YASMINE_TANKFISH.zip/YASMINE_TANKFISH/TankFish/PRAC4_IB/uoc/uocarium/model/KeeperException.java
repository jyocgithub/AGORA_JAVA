package edu.uoc.uocarium.model;

public class KeeperException extends ItemException{

	public final static String MSG_ERR_KEEPER_NUMBER_TANKS = "[ERROR] A keeper cannot take care of more than 5 tanks!!";		
	public static final String MSG_ERR_KEEPER_INITIAL_NAME = "[ERROR] A keeper's id must start with letter 'G'!!";
	public static final String MSG_ERR_KEEPER_SIZE_NAME = "[ERROR] A keeper's id must have 5 characters!!";

	public KeeperException() {
		super();
	}
	
	public KeeperException(String msg) {
		super(msg);
	}
}