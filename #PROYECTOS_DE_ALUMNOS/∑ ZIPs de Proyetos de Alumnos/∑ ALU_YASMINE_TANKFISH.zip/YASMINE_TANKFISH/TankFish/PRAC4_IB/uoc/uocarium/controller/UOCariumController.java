package YASMINE_TANKFISH.TankFish.PRAC4_IB.uoc.uocarium.controller;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Optional;
import java.util.Random;
import java.util.stream.Collectors;

import apple.laf.JRSUIConstants.Size;
import edu.uoc.uocarium.model.Animal;
import edu.uoc.uocarium.model.AnimalException;
import edu.uoc.uocarium.model.AnimalStatus;
import edu.uoc.uocarium.model.CoryDoras;
import edu.uoc.uocarium.model.Danio;
import edu.uoc.uocarium.model.Fish;
import edu.uoc.uocarium.model.Food;
import edu.uoc.uocarium.model.Gender;
import edu.uoc.uocarium.model.Item;
import edu.uoc.uocarium.model.ItemException;
import edu.uoc.uocarium.model.Keeper;
import edu.uoc.uocarium.model.Movable;
import edu.uoc.uocarium.model.MovableException;
import edu.uoc.uocarium.model.SubmarineToy;
import edu.uoc.uocarium.model.Tank;
import edu.uoc.uocarium.model.TankException;
//import edu.uoc.uocarium.model.Tetra;
//import jdk.nashorn.api.tree.ForInLoopTree;

public class UOCariumController {

	edu.uoc.uocarium.controller.Database database;
	String tankSelected ;

	public UOCariumController(String folderName) throws ItemException {
		database = new edu.uoc.uocarium.controller.Database(folderName);
		tankSelected = (database.getTanks().size()!=0)? database.getTanks().get(0).getId():null;
	}

	public String getTankSelected() {
		return tankSelected;
	}

	public void setTankSelected(String tankSelected) {
		this.tankSelected = tankSelected;
	}

	public List<Tank> getTanks(){
		List<Tank> tanks = database.getTanks();

		//TODO
		Collections.sort(tanks);

		return tanks;
	}

	public Tank getTank(String id) {
		return database.getTank(id);
	}

	public List<Item> getMovableItems(){
		//TODO
		List<Item> allItems= getItems();
		List<Item> selectedItems= new ArrayList<>();

		for( Item item : allItems) {
			if (item instanceof Movable) {
				selectedItems.add(item);
			}
		}
		return selectedItems;
	}

	public List<Item> getItems(){
		return database.getTank(getTankSelected()).getItems();
	}

	public void addFish() throws AnimalException, ItemException, MovableException, TankException{
		//TODO
		Fish fish;
		Random random = new Random();
		int fishtype = random.nextInt(10);
		int xcoord = random.nextInt(301);
		int ycoord = random.nextInt(301);
		Gender gender = random.nextInt(1)==0 ?  Gender.MALE : Gender.FEMALE   ;

		Tank actualTank = getTank(tankSelected);

		if(fishtype <3) {
			fish = new Danio( xcoord,  ycoord,  gender,  0,  100, actualTank);
		}else if( fishtype<6) {
			fish = new Tetra( xcoord,  ycoord,  gender,  0,  100, actualTank);
		}else {
			fish = new CoryDoras( xcoord,  ycoord,  gender,  0,  100,  actualTank);
		}

		actualTank.addItem(fish);
	}

	public SubmarineToy getSubmarineToy() {

		Optional<Item> op = database.getTank(getTankSelected()).getItems().stream().filter(p -> p instanceof SubmarineToy).findFirst();

		return op.isEmpty()?null:(SubmarineToy) op.get();

	}

	public boolean isSubmarineToy() {
		return getSubmarineToy() != null;
	}

	public void toggleSubmarineToy() throws ItemException, MovableException{
		//TODO
		Tank actualTank = getTank(tankSelected);
		List<Item> items =  actualTank.getItems();

		boolean exists = false;
		int i;
		for ( i = 0; i < items.size() && exists == false; i++) {
			if(items.get(i) instanceof SubmarineToy) {
				exists = true;
			}
		}
		if(exists) {
			items.remove(i);
		}else {
			items.add( new SubmarineToy(50,50,100,50, actualTank));
		}
	}

	public String getTankInfo() {
		return getTank(getTankSelected()).toString();
	}

	public List<Item> removeDeadItems(){
		//TODO
		Tank actualTank = getTank(tankSelected);
		List<Item> items =  actualTank.getItems();
		List<Item> deads = new ArrayList<>();

		Iterator<Item> it = items.iterator();

		while(it.hasNext()) {
			Item item = it.next();
			if(item instanceof Animal ) {
				Animal animal = (Animal) item;
				if(animal.getStatus() == AnimalStatus.DEAD) {
					deads.add(item);
					it.remove();
				}
			}
		}
		return deads;
	}

	public void feed() throws Exception {
		new Food((new Random()).nextInt(Movable.TANK_PANE_WIDTH-10),0,1,1,5,getTank(getTankSelected()));

	}

	public List<Keeper> getKeepers(){
		return database.getKeepers();
	}
}
