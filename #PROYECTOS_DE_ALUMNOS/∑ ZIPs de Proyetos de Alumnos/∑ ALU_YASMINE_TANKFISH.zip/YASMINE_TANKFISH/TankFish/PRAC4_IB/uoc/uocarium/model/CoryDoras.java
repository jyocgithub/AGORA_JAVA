package edu.uoc.uocarium.model;

public class CoryDoras extends Fish {

	public CoryDoras(double xCoord, double yCoord, Gender gender, int age, int energy, Tank tank)
			throws AnimalException, ItemException, MovableException {
		super(xCoord, yCoord, "./images/corydoras/corydoras", 64, 64, gender, age, 0.1, 0.5, 0.001, Color.BLUE, energy, tank);

	}

	@Override
	public int getOxygenConsumption() {
		return 18;
	}

	@Override
	public void breathe() throws AnimalException {
		if (getStatus() != AnimalStatus.DEAD) {
			if(getEnergy() <100) {
				incEnergy(1);
			}
		}
	}

	@Override
	public String toString() {
		return super.toString() + " : CoryDoras\n";
	}

}
