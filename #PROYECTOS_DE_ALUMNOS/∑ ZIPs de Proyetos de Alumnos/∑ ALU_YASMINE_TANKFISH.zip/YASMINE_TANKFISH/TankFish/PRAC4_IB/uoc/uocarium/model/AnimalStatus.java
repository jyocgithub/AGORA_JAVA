package edu.uoc.uocarium.model;

public enum AnimalStatus {
	HEALTHY, 
	SICK, 
	DEAD;
}
