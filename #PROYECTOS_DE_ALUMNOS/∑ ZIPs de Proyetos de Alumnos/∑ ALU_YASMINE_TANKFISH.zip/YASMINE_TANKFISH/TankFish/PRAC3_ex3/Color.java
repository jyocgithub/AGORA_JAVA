package PRAC3_ex3;

public enum Color {
	YELLOW ("#FFFF00"), 
	RED ("#FF0000"),
	GREEN ("#00FF00"), 
	BLUE ("#0000FF"), 
	GRAY ("#888888"), 
	WHITE ("#FFFFFF"), 
	BLACK ("#000000"), 
	ORANGE ("#FF8300"), 
	BRONZE ("#CD7F32") ,
	NOT_DEFINED ("#");
	
	String hexcode;
	Color ( String hexCode){
		this.hexcode= hexCode;
	}
	public String getHexcode() {
		return hexcode;
	}

	public Color getColor(String hexcode) {
  	  return Color.valueOf(hexcode);
	}
	
}
