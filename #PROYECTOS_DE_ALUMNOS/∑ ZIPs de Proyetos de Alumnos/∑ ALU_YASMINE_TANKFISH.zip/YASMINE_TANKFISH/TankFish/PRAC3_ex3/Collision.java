package PRAC3_ex3;

public enum Collision {
	LEFT,
	RIGHT, 
	TOP, 
	BOTTOM, 
	NO_COLLISION;
}
