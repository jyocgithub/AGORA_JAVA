package PRAC3_ex3;

public class Snail extends Animal {

	public Snail(double xCoord, double length, double height, Gender gender, int age, int energy, Tank tank) throws MovableException, ItemException {
		super(xCoord, TANK_PANE_HEIGHT - 30, "", length, height, gender, age,0.01, 0.1 ,0.00000003, energy, tank);
	}

	
	
	public void crawl() {
		Collision collision = collideWithTank();
		if (collision == Collision.LEFT || collision == Collision.RIGHT) {
			setFacingRight(!isFacingRight());
		}
		float decision = (float) Math.random();
		if (decision < 0.00000003) {
			setFacingRight(!isFacingRight());
		}
		if (isFacingRight()) {
			moveright();
		} else {
			moveLeft();
		}
		
	}
	
	@Override
	public void update() {
		crawl();
	}

	@Override
	public int getOxygenConsumption() {
		return 1;
	}

	@Override
	public void breathe() {
		// TODO 
	}
	
	
	
	
	
}
