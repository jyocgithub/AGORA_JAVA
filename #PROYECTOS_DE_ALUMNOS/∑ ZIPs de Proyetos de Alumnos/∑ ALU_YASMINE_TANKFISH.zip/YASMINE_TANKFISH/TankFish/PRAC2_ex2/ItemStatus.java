package PRAC2_ex2;

public enum ItemStatus {
	HEALTHY, 
	SICK, 
	DEAD;
}



