package PRAC3_ex2;

public class TankException extends Exception {

	

	public TankException() {
		super();
		
	}

	public TankException(String msg) {
		super(msg);
		
	}

	
	
	
}
