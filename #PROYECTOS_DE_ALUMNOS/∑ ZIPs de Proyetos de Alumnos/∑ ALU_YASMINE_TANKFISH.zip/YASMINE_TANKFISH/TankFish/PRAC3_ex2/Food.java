package PRAC3_ex2;

public class Food  extends Item{
	
	
	private double speed;
	private int energy;
	private boolean eaten;
	
	public Food(double xCoord,double yCoord,double length,double height, int energy , Tank tank) throws Exception {
		super(xCoord, yCoord, "./images/food/seed.png", length, height, tank);
		setEnergy(energy);
		setSpeed(1);
	}
	
	
	public boolean isEaten() {
		return eaten;
	}

	public void eaten() {
		this.eaten = true;
	}

	public int getEnergy() {
		return energy;
	}

	public void setEnergy(int energy) throws Exception {
		if(energy<1 || energy>10) {
			throw new Exception("[ERROR] Food cannot be less than 1 either greater than 10!!");
		}
		this.energy = energy;
	}


	public double getSpeed() {
		return speed;
	}

	public void setSpeed(double speed) throws ItemException  {
		if(speed < 0) {
			throw new ItemException(ItemException.MSG_ERR_SPEED_VALUE);
		}
		this.speed = speed;
	}

}
