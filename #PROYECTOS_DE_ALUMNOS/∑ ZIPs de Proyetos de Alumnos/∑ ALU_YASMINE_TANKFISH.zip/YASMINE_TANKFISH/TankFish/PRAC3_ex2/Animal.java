package PRAC3_ex2;

enum Gender {
	MALE, FEMALE
};

public class Animal extends Item {

	private Gender gender;
	private int age;
	private boolean facingRight;
	private double speed;
	private double requiredFoodQuantity;
	private double thresholdReverse;
	private int energy = 100;
	private AnimalStatus status;

	public Animal(double xCoord, double yCoord, String spriteImage, double length, double height, Gender gender,
			int age, double speed, double requiredFoodQuantity, double thresholdReverse, AnimalStatus status,
			int energy, Tank tank) throws ItemException {
		super(xCoord, yCoord, spriteImage, length, height, tank);

		setGender(gender);
		setAge(age);
		setFacingRight(true);
		setSpeed(speed);
		setRequiredFoodQuantity(requiredFoodQuantity);
		setThresholdReverse(thresholdReverse);
		setEnergy(energy);
		setStatus(status);

	}

	public Gender getGender() {
		return gender;
	}

	public void setGender(Gender gender) {
		this.gender = gender;
	}

	public int getAge() {
		return age;
	}

	
	public void setAge(int age) throws AnimalException{
		if(age < 0) {
			throw new AnimalException(AnimalException.MSG_ERR_AGE_VALUE);
		}
		this.age = age;
	}
	
	

	public boolean isFacingRight() {
		return facingRight;
	}

	public void setFacingRight(boolean facingRight) {
		this.facingRight = facingRight;
	}

	public double getSpeed() {
		return speed;
	}

	public void setSpeed(double speed) throws ItemException  {
		if(speed < 0) {
			throw new ItemException(ItemException.MSG_ERR_SPEED_VALUE);
		}
		this.speed = speed;
	}

	public double getRequiredFoodQuantity() {
		return requiredFoodQuantity;
	}

	public void setRequiredFoodQuantity(double requiredFoodQuantity) {
		this.requiredFoodQuantity = requiredFoodQuantity;
	}

	public double getThresholdReverse() {
		return thresholdReverse;
	}

	public void setThresholdReverse(double thresholdReverse) throws ItemException {
		if(thresholdReverse<0 || thresholdReverse>1) {
			throw new ItemException(ItemException.MSG_ERR_THRESHOLD_VALUE);
		}
		this.thresholdReverse = thresholdReverse;
	}


	
	
	public AnimalStatus getStatus() {
		return status;
	}

	private void setStatus(AnimalStatus status) {
		this.status = status;
	}

	public int getEnergy() {
		return energy;
	}

	public void setEnergy(int energy) throws AnimalException {
		if(energy<0 || energy>100) throw new AnimalException(AnimalException.MSG_ERR_ENERGY_RANGE_VALUE);
		
		if(this.energy!=0) {
			this.energy = energy;
		}else {
			throw new AnimalException(AnimalException.MSG_ERR_ENERGY_ZERO);
		}
		
		if(getEnergy()==0) {
			setStatus(AnimalStatus.DEAD);
		}else if(getEnergy()<25) {
			setStatus(AnimalStatus.SICK);
		}else {
			setStatus(AnimalStatus.HEALTHY);
		}
	}
	
	public void incEnergy(int energy) throws AnimalException{
		try{
			if(energy<0) throw new Exception("[ERROR] Incorrect value!!"); //Este error no estaba especificado en el enunciado y no hacia falta codificarlo/controlarlo
			setEnergy(getEnergy()+energy);
		}catch(Exception e) {
			try{
				setEnergy(100);
			}catch(Exception e2) {}
			throw new AnimalException(AnimalException.MSG_WARNING_ENERGY_AUTOMATIC_VALUE+100);
		}
	}
	
	public void decEnergy(int energy) throws AnimalException{
		try{
			if(energy<0) throw new Exception("[ERROR] Incorrect value!!"); //Este error no estaba especificado en el enunciado y no hacia falta codificarlo/controlarlo
			setEnergy(getEnergy()-energy);
		}catch(Exception e) {
			try{
				setEnergy(0);				
			}catch(Exception e2) {}
			throw new AnimalException(AnimalException.MSG_WARNING_ENERGY_AUTOMATIC_VALUE+0);
		}
	}
	
	public boolean isDead() {
		return (getEnergy()==0); //TAMBIEN: return getStatus()==ItemStatus.DEAD;
	}

	public void reverse() {
		setFacingRight(!this.facingRight);
	}
	
	
	
}
