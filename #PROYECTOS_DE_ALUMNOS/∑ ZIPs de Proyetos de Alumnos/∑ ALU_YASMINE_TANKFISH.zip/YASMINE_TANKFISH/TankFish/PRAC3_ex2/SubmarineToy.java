package PRAC3_ex2;

public class SubmarineToy extends Item{

	
	private double speed;
	private double thresholdReverse;
	private boolean facingRight;
	
	
	
	public SubmarineToy(double xCoord,double yCoord,double length,double height, Tank tank) throws Exception {
		super(xCoord, yCoord, "./images/submarine/submarine.png", length, height, tank);
	
		setSpeed(1);
		setThresholdReverse(0.0003);
		setFacingRight(true);
	}
	
	
	

	public boolean isFacingRight() {
		return facingRight;
	}

	public void setFacingRight(boolean facingRight) {
		this.facingRight = facingRight;
	}

	public double getSpeed() {
		return speed;
	}

	public void setSpeed(double speed) throws ItemException  {
		if(speed < 0) {
			throw new ItemException(ItemException.MSG_ERR_SPEED_VALUE);
		}
		this.speed = speed;
	}
	
	public double getThresholdReverse() {
		return thresholdReverse;
	}

	public void setThresholdReverse(double thresholdReverse) throws ItemException {
		if(thresholdReverse<0 || thresholdReverse>1) {
			throw new ItemException(ItemException.MSG_ERR_THRESHOLD_VALUE);
		}
		this.thresholdReverse = thresholdReverse;
	}

	public void reverse() {
		setFacingRight(!this.facingRight);
	}
	
	
}
