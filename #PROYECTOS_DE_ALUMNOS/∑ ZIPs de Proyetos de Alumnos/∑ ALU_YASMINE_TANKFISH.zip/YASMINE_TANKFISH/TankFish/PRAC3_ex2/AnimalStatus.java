package PRAC3_ex2;

public enum AnimalStatus {
	HEALTHY, 
	SICK, 
	DEAD;
}
