package PRAC1_ex4;

public class Keeper {
	private String name;
	private String surname;
	private String id;
	private int maxTanks;

	public Keeper(String name, String surname, String id, int maxTanks) {
		super();
		this.name = name;
		this.surname = surname;
		this.id = id;
		this.maxTanks = maxTanks;
	}

	public Keeper() {
		this(null, null, null, 0);
	}

	@Override
	// format : [ID: I, Name: N, Surname: S, Max. tanks: T]
	public String toString() {
		return " ID: " + id + ", Name: " + name + ", Surname: " + surname + ", Max. tanks: " + maxTanks;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getSurname() {
		return surname;
	}

	public void setSurname(String surname) {
		this.surname = surname;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public int getMaxTanks() {
		return maxTanks;
	}

	public void setMaxTanks(int maxTanks) {
		this.maxTanks = maxTanks;
	}

}
