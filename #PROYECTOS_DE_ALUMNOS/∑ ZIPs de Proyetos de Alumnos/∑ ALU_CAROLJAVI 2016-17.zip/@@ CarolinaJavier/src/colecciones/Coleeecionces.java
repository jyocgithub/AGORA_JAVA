package colecciones;

import java.util.ArrayList;

public class Coleeecionces {
	public static void main(String[] args) {

		ArrayList<String> lis = new ArrayList<>();
		lis.add("luis");
		lis.add("Ps");
		lis.add(3, "lis");
		lis.add("ls");
		lis.add("luis");
		lis.set(3, "ana");

		lis.remove(1);
		lis.remove("luis");
		String o = lis.get(3);
		System.out.println(lis.get(4));

		for (int i = 0; i < lis.size(); i++) {
			System.out.println(lis.get(i));
		}

		for (String k : lis) {
			System.out.println(k);
		}

		lis.contains("Luis");

	}
}
