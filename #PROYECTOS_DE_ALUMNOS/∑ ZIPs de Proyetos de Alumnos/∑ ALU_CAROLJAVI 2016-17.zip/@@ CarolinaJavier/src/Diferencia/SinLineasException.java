package Diferencia;

public class SinLineasException extends Exception {
	SinLineasException() {
		super("eL FICHERO ESTÁ VACIÓ");
	}

}
