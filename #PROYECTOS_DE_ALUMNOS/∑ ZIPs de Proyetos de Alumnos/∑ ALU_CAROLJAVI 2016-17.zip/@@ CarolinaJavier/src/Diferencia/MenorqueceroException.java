package Diferencia;

public class MenorqueceroException extends Exception {

	public MenorqueceroException() {
		super("eL NÚMERO NO PUEDE SER MENOR QUE CERO");

	}

}
