package Diferencia;

public class DiferenciaErroneaException extends Exception {
	public DiferenciaErroneaException(String aa) {
		super(aa);
	}

}
