//UN METODO QUE RECIBE DOS NUMEROS Y CALCULA LA DIFERENCIA ENTRE AMBOS
//EMITE EXCEPCIONES SI:+
//- ALGUN NUMERO ES MENOR QUE CERO (MENORQUECEROEXCEPTION) 
//- LA DIFERENCIA ES MAYOR DE 50 (DIFERENCIAERROENAEXCEPTION)
//
//
//UN METODO QUE LEE LINEAS DE UN FICHERO DE TEXTO, CUYO NOMBRE DECIBE POR PARAMETRO, Y CUENTA LAS LETRAS
//DA EXCEPCION SINLINEASEXCEPTION SI NO HAY LINEAS EN EL FICHERO

package Diferencia;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;

public class Inicio {

	public static void main(String[] args) {
		int num1 = 50;
		int num2 = 20;
		int v = 0;
		try {
			int a = CalcularDiferencia(num1, num2);
			System.out.println(a);
		} catch (MenorqueceroException | DiferenciaErroneaException e) {
			System.out.println(e.getMessage());
		}

		try {
			v = CalcularLetras("prueba.txt");
			System.out.println(v);
		} catch (SinLineasException s) {
			s.printStackTrace();
		}
	}

	public static int CalcularDiferencia(int num1, int num2) throws MenorqueceroException, DiferenciaErroneaException {
		if (num1 < 0 || num2 < 0) {
			MenorqueceroException MC = new MenorqueceroException();
			throw MC;
		}

		int dif = 0;
		dif = num1 - num2;

		if (dif > 50) {
			DiferenciaErroneaException de = new DiferenciaErroneaException("La diferencia es mayor que 50");
			throw de;
		}
		return dif;
	}

	public static int CalcularLetras(String nombref) throws SinLineasException {
		int l = 0;
		File f = new File(nombref);
		File fich = new File("copiar.txt");
		if (f.exists()) {
			FileReader fr = null;
			BufferedReader br = null;

			PrintWriter pw = null;

			try {
				fr = new FileReader(f);
				br = new BufferedReader(fr);
				String linea = br.readLine();

				pw = new PrintWriter(fich);

				while (linea != null) {
					// l += linea.length();
					for (int i = 0; i < linea.length(); i++) {
						char c = linea.charAt(i);
						if ((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z')) {
							l++;
						}
					}
					if (l > 20) {
						pw.println(linea);
					}
					linea = br.readLine();
				}

				if (l == 0) {
					SinLineasException SN = new SinLineasException();
					throw SN;
				}

			} catch (IOException io) {
				io.printStackTrace();
			} finally {
				try {
					fr.close();
					br.close();
					pw.close();
				} catch (IOException io) {
					io.printStackTrace();
				}
			}

		}

		return l;

	}

}
