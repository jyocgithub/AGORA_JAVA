package ficheros;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;

public class Main {

	public static void main(String[] args) {
		// escribirFicheroTexto();
		// leerFicheroTexto();
		duplicar();
	}

	public static void escribirFicheroTexto() {
		PrintWriter pw = null;
		try {
			pw = new PrintWriter("pruebas.txt");
			pw.println("Juan");
			pw.println("Carolina");
			pw.println("Ana");
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} finally {
			pw.close();
		}
	}

	public static void leerFicheroTexto() {

		File f = new File("pruebas.txt");
		if (f.exists()) {
			FileReader fr = null;
			BufferedReader br = null;
			try {
				fr = new FileReader("Pruebas.txt");
				String linea = "";

				br = new BufferedReader(fr);
				linea = br.readLine();
				while (linea != null) {
					System.out.println(linea);
					linea = br.readLine();
				}

			} catch (IOException e) {
				e.printStackTrace();
			} finally {
				try {
					br.close();
					fr.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}

	}

	public static void duplicar() {

		File f = new File("pruebas.txt");
		File f2 = new File("pruebas2.txt");
		if (!f.exists()) {
			System.out.println("fichero no existe");
			return;
		}

		FileReader fr = null;
		BufferedReader br = null;
		PrintWriter pw = null;
		try {
			fr = new FileReader(f);
			br = new BufferedReader(fr);
			pw = new PrintWriter(f2);

			String linea = br.readLine();
			while (linea != null) {
				if (linea.length() > 5) {
					pw.println(linea);
				}
				linea = br.readLine();
			}
		} catch (IOException ex) {
			ex.printStackTrace();
		} finally {
			try {
				fr.close();
				br.close();
				pw.close();
			} catch (IOException ex) {
				ex.printStackTrace();
			}
		}

	}

}
