package ficheros;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

public class Reinos {
	public static void main(String[] args) {
		String paises[] = { "Cuba", "Republica de Colombia", "Reino de Perú", "Nuevo Reino de Canadá",
				"Republica de Argentina", "Honduras", "Republica de Uruguay" };

		File f = new File("reinos.txt");
		escribirFicheroTexto(paises, f);
		leerFicheroTexto(f);
	}

	public static void escribirFicheroTexto(String[] paises, File f) {
		PrintWriter pw = null;
		try {
			pw = new PrintWriter(f);
			for (int i = 0; i < paises.length; i++) {
				pw.println(paises[i]);
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} finally {
			pw.close();
		}

	}

	public static void leerFicheroTexto(File f) {

		if (f.exists()) {
			FileReader fr = null;
			BufferedReader br = null;
			ArrayList<String> r = new ArrayList<>();
			try {
				fr = new FileReader(f);
				br = new BufferedReader(fr);
				String linea = "";

				linea = br.readLine();
				while (linea != null) {
					if (linea.contains("Reino")) {
						r.add(linea);
					}
					linea = br.readLine();
				}

			} catch (IOException e) {
				e.printStackTrace();
			} finally {
				try {
					br.close();
					fr.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}

			for (String s : r) {
				System.out.println(s);
			}
		}
	}
}
