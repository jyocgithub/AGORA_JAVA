import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;

public class Arrays {

	static int b;
	static int[] lista;

	public static void main(String[] args) {
		// System.out.println("Tamaño?");
		// Scanner sc = new Scanner(System.in);
		// int tam = sc.nextInt();
		// crear(tam);
		// llenar();
		// pintar();

		int ar[] = { 1, 56, 3, 4, 2, 5, 23, 5, 2 };
		String ar2[] = { "kjhkjh", "lkhjkjh", "kjhlkjh" };
		int suma = 0, cont = 0;
		int cop[] = new int[ar.length];
		for (int i = 0; i < ar.length; i++) {

			if (ar[i] % 2 != 0) {
				suma += ar[i];
				cont++;
			}

			cop[i] = ar[i] + 2;
			System.out.println(ar[i] + "  pasa a ser " + cop[i]);
		}

		System.out.println("La media de ar es " + suma / cont);

		for (int i = ar.length - 1; i > 0; i--) {
			System.out.println(ar[i]);
		}

		ArrayList<String> lis = new ArrayList<>();
		lis.add("ddfef");
		lis.add("qwef");
		lis.add("55656");
		lis.add("yert");
		String arr[] = new String[lis.size()];

		for (int i = 0; i < lis.size(); i++) {
			arr[i] = lis.get(i);
		}

		HashSet<String> con = new HashSet<>();
		con.add("kljb");
		con.add("kljb");
		con.add("kljb");
		con.add("kljb");
		con.add("kljb");

		int u = 0;
		for (String k : con) {
			arr[u] = k;
			u++;
		}

		HashMap<Integer, String> ma = new HashMap<>();
		ma.put(123, "luis");
		ma.put(13, "pablo");
		ma.put(12, "carlos");
		ma.remove(13);

		int pq = 0;
		for (Integer inte : ma.keySet()) {
			String val = ma.get(inte);
			arr[pq] = val;
			pq++;
		}

		pq = 0;
		for (String inte : ma.values()) {
			arr[pq] = inte;
			pq++;
		}

		HashMap<Integer, String> macop = new HashMap<>();
		for (Integer inte : ma.keySet()) {
			String val = ma.get(inte);
			macop.put(inte, val);
		}

		ArrayList<String> lis2 = new ArrayList<>();
		Iterator<String> it = lis2.iterator();
		while (it.hasNext()) {
			String i = it.next();
			if (i.equals("PEPE")) {
				it.remove();
			}
		}

		HashMap<Integer, String> map4 = new HashMap<>();
		Iterator<String> tt = map4.values().iterator();
		while (tt.hasNext()) {
			String i = tt.next();
			if (i.equals("PEPE")) {
				tt.remove();
			}
		}

	}

	public static void crear(int tama) {
		lista = new int[tama];
	}

	public static void llenar() {
		for (int i = 0; i < lista.length; i++) {
			int y = (int) (Math.random() * 100);
			lista[i] = y;
		}
	}

	public static void pintar() {
		for (int i = 0; i < lista.length; i++) {
			System.out.println(lista[i]);
		}
	}

}
