package Trajes3;

public class TallaNegativaException extends Exception {

	public TallaNegativaException(String mensaje) {
		super(mensaje);
	}
}
