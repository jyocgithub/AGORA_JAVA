package Trajes3;

public class TFalda extends Traje {
	private int cremalleras;

	TFalda(int t, double pvp, int p, int c) {
		super(t, pvp, p);

		cremalleras = c;
	}

	@Override
	public void aplicaRebaja(boolean rebaja) {
		double resul = 0;
		if (rebaja) {
			resul = this.getPrecio() / 100 * this.getPorcen();
			resul = this.getPrecio() - resul - 10;
			this.setPrecio(resul);
		} else {
			resul = this.getPrecio() / 100 * this.getPorcen();
			resul = this.getPrecio() + resul + 10;
			this.setPrecio(resul);
		}
	}

	@Override
	public String toString() {
		String falda;
		falda = "talla: " + this.getTalla() + " precio: " + this.getPrecio() + " cremalleras: " + cremalleras;
		return falda;
	}
}
