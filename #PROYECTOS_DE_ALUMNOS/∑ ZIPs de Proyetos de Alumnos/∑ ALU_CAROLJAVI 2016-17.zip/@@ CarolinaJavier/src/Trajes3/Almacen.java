package Trajes3;

import java.util.Iterator;
import java.util.Scanner;
import java.util.TreeSet;

public class Almacen {

	static int siguiente = 0;
	// static TFalda[] faldas = new TFalda[5];
	static TreeSet<TFalda> faldas = new TreeSet<>();

	public static void main(String[] args) {
		Util ut = new Util();
		Scanner sc = new Scanner(System.in);

		int opc = 0;

		do {
			System.out.println("1.- Añadir traje");
			System.out.println("2.- Listar trajes");
			System.out.println("3.- Borrar traje");
			System.out.println("4.- Aplicar descuento a todos los trajes");
			System.out.println("5.- Salir");

			System.out.print("> ");

			boolean seguir = true;
			do {
				try {
					opc = ut.pedirNumero("Dime opcion:");
					seguir = false;
				} catch (Exception patata) {
					System.out.println("ERRRRRRRROOOOOOOOR no pongas palabras ");
				}
			} while (seguir);

			switch (opc) {
			case 1:
				try {

					TFalda falda;
					falda = pedirFalda();
					aniadirFalda(falda);
				} catch (TallaNegativaException e) {
					System.out.println(e.getMessage());
				}
				break;
			case 2:
				listarTrajes();
				break;
			case 3:
				System.out.println("Talla a eliminar: ");
				int talla = sc.nextInt();
				borrarTraje(talla);
				break;
			case 5:
				break;
			default:
				System.out.println("Opcion incorrecta.");
				break;
			}

		} while (opc != 5);
	}

	static void aniadirFalda(TFalda f) {
		faldas.add(f);

		/*
		 * faldas[siguiente] = f; siguiente++;
		 */
	}

	static TFalda pedirFalda() throws TallaNegativaException {
		Scanner sc = new Scanner(System.in);

		System.out.println("Dame talla: ");
		int t = sc.nextInt();
		if (t < 0) {
			TallaNegativaException tn = new TallaNegativaException("mierda de talla");
			throw tn;
		}
		System.out.println("Dame precio: ");
		double pvp = sc.nextDouble();
		System.out.println("Dame porcentaje de la rebaja: ");
		int p = sc.nextInt();
		System.out.println("Dame numero de cremalleras: ");
		int c = sc.nextInt();

		TFalda f = new TFalda(t, pvp, p, c);

		return f;
	}

	static void listarTrajes() {
		for (TFalda tt : faldas) {
			System.out.println(tt);
		}
	}

	static void borrarTraje(int talla) {
		try {
			Iterator<TFalda> ite = faldas.iterator();
			while (ite.hasNext()) {
				TFalda f = ite.next();
				if (f.getTalla() == talla) {
					ite.remove();
				}
			}
		} catch (Exception ex) {
			System.out.println(ex.getMessage());

		}

	}

	static void aplicarDescuento(int porcen) {

	}

}
