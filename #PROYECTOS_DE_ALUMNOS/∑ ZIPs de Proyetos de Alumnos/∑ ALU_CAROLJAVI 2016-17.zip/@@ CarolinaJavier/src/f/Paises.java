package f;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.util.TreeSet;

public class Paises {

	public static void main(String[] args) {
		File paises = new File("paises.txt");
		leer(paises);

		TreeSet<String> ts = new TreeSet<>();
		ts = leer2(paises);

	}

	public static void leer(File paises) {
		int cont = 0;
		if (paises.exists()) {
			FileReader fr = null;
			BufferedReader br = null;
			try {
				fr = new FileReader(paises);
				br = new BufferedReader(fr);

				String linea;
				linea = br.readLine();
				while (linea != null) {
					String[] p = linea.split(" ");

					for (int i = 0; i < p.length; i++) {
						if (p[i].substring(0, 1).equals("R")) {
							cont++;
						}
					}

					linea = br.readLine();
				}

			} catch (IOException e) {
				e.printStackTrace();
			} finally {
				try {
					fr.close();
					br.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
		System.out.println(cont);
	}

	public static TreeSet leer2(File f) {

		TreeSet<String> ts = new TreeSet<>();
		if (f.exists()) {
			FileReader fr = null;
			BufferedReader br = null;
			try {
				fr = new FileReader(f);
				br = new BufferedReader(fr);

				String linea;
				linea = br.readLine();
				while (linea != null) {
					String[] p = linea.split(" ");

					for (int i = 0; i < p.length; i++) {
						if (p[i].substring(0, 1).equals("P")) {
							ts.add(p[i]);
						}
					}

					linea = br.readLine();
				}

			} catch (IOException e) {
				e.printStackTrace();
			} finally {
				try {
					fr.close();
					br.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}

		return ts;
	}

	public static void escribirB(File f, TreeSet<String> ts) {

		FileOutputStream fos = null;
		DataOutputStream dos = null;

		try {

			fos = new FileOutputStream(f);
			dos = new DataOutputStream(fos);

			for (String elem : ts) {
				dos.writeUTF(elem);
			}

		} catch (IOException e) {
			e.printStackTrace();

		} finally {
			try {
				fos.close();
				dos.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

}
