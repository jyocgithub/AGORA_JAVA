package ficherosbinariosconobjetos;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;

public class Binarios1 {

	public static void main(String[] args) {

		Vestido v = new Vestido(1000, "popo", 2017);
		Vestido v2 = new Vestido(4000, "pepe", 2016);
		Vestido v3 = new Vestido(2000, "pulpo", 2017);
		ArrayList<Vestido> lista = new ArrayList<>();
		lista.add(v);
		lista.add(v2);
		lista.add(v3);

		// escribir
		FileOutputStream outf = null;
		ObjectOutputStream dos = null;
		try {
			outf = new FileOutputStream("binariopru.dat");
			dos = new ObjectOutputStream(outf);

			dos.writeObject(v);
			dos.writeObject(v2);
			dos.writeObject(v3);
			dos.writeObject(lista);

		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				outf.close();
				dos.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}

		// leer
		FileInputStream fis = null;
		ObjectInputStream ois = null;
		try {
			fis = new FileInputStream("binariopru.dat");
			ois = new ObjectInputStream(fis);
			Vestido q = (Vestido) ois.readObject();
			Vestido q2 = (Vestido) ois.readObject();
			Vestido q3 = (Vestido) ois.readObject();
			ArrayList<Vestido> lista2 = (ArrayList<Vestido>) ois.readObject();

			System.out.println(q2.getMarca());
			System.out.println(q.getMarca());
			System.out.println(q3.getMarca());

		} catch (IOException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} finally {
			try {
				fis.close();
				ois.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}

	}

}

// --------------------------------------------------------------
class Vestido implements Serializable {

	// ATRIBUTOS
	protected int precio;
	private String marca;
	private int ano;
	static int totalvestidos;
	Almacen al;

	// METODOS

	public int getPrecio() {
		return precio;
	}

	public void setPrecio(int pre) {
		precio = pre;
	}

	public String getMarca() {
		return marca;
	}

	public void setMarca(String marca) {
		this.marca = marca;
	}

	public int getAno() {
		return ano;
	}

	public void setAno(int ano) {
		this.ano = ano;
	}

	Vestido(int p, String marca, int a) {
		precio = p;
		this.marca = marca;
		ano = a;
		totalvestidos++;
	}

	Vestido(String m, int a) {
		precio = 0;
		marca = m;
		ano = a;
	}

	public double calcularIVA() {
		double res = 0.0;
		res = precio * 0.21;
		return res;
	}

	final public double calcularIVA(double porcen) {
		double res = 0.0;
		res = precio / 100 * porcen;
		return res;
	}

}

class Almacen implements Serializable {

}