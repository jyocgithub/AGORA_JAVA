package Trajes;

import java.util.Scanner;

public class Util {
	public int pedirNumero(String mens) {
		System.out.println(mens);
		Scanner sc = new Scanner(System.in);
		int opc = sc.nextInt();
		return opc;
	}
}
