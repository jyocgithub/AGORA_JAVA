package Trajes;

import java.util.Scanner;

public class Almacen {

	static int siguiente = 0;
	static TFalda[] faldas = new TFalda[5];

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);

		int opc = 0;

		do {
			System.out.println("1.- Añadir traje");
			System.out.println("2.- Listar trajes");
			System.out.println("3.- Borrar traje");
			System.out.println("4.- Aplicar descuento a todos los trajes");
			System.out.println("5.- Salir");

			System.out.print("> ");
			opc = sc.nextInt();
			switch (opc) {
			case 1:
				if (siguiente != faldas.length) {
					TFalda falda = pedirFalda();
					aniadirFalda(falda);
				} else
					System.out.println("No se pueden añadir mas faldas.");
				break;
			case 2:
				listarTrajes();
				break;
			case 3:
				System.out.println("Talla a eliminar: ");
				int talla = sc.nextInt();
				borrarTraje(talla);
				break;
			case 4:
				break;
			default:
				System.out.println("Opcion incorrecta.");
				break;
			}

		} while (opc != 5);
	}

	static void aniadirFalda(TFalda f) {
		faldas[siguiente] = f;
		siguiente++;
	}

	static TFalda pedirFalda() {
		Scanner sc = new Scanner(System.in);

		System.out.println("Dame talla: ");
		int t = sc.nextInt();
		System.out.println("Dame precio: ");
		double pvp = sc.nextDouble();
		System.out.println("Dame porcentaje de la rebaja: ");
		int p = sc.nextInt();
		System.out.println("Dame numero de cremalleras: ");
		int c = sc.nextInt();

		TFalda f = new TFalda(t, pvp, p, c);

		return f;
	}

	static void listarTrajes() {
		for (int i = 0; i < siguiente; i++) {
			System.out.println("Falda " + i);
			System.out.println(faldas[i]);
		}
	}

	static void borrarTraje(int talla) {
		for (int i = 0; i < siguiente; i++) {
			if (faldas[i].getTalla() == talla) {
				faldas[i] = null;
				siguiente--;

				for (int j = i; j < faldas.length - 2; j++) {
					faldas[j] = faldas[j + 1];
				}

				faldas[faldas.length - 1] = null;
			}
		}

	}

	static void aplicarDescuento(int porcen) {

	}

}
