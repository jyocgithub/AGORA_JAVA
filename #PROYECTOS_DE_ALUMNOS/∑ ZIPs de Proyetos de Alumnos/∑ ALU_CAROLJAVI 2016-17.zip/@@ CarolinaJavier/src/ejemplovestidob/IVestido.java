package ejemplovestidob;

public interface IVestido {

	void ponerPrecio();

	void regalar(int n);

	abstract void abrirTemporada();

}
