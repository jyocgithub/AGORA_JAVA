package ejemplovestidob;

public class VestidoLargo extends Vestido implements IVestido {

	int largo;
	int maxdescuento;

	VestidoLargo(int p, String m, int a, int l) {
		super(p, m, a);
		largo = l;
	}

	VestidoLargo(int p, String m, int a, int l, int max) {
		this(p, m, a, l);
		maxdescuento = max;
	}

	@Override
	public double calcularIVA() {
		double res = super.calcularIVA();
		res = res + 10;
		return res;
	}

	void pintaprecio() {
		System.out.println(precio + calcularIVA());
	}

	void pintaprecio2() {
		System.out.println(precio + calcularIVA());
	}

	@Override
	public void abrirTemporada() {

	}

	@Override
	public void ponerPrecio() {
		// TODO Auto-generated method stub

	}

	@Override
	public void regalar(int n) {
		// TODO Auto-generated method stub

	}
}
