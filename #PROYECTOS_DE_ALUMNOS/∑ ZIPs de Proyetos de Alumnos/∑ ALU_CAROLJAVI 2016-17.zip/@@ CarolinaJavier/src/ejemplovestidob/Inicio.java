package ejemplovestidob;

import java.util.Iterator;
import java.util.Scanner;
import java.util.TreeSet;

public class Inicio {

	static Scanner sc = new Scanner(System.in);
	static int opcion;
	final double PI = 3.14;
	static TreeSet<Vestido> ts = new TreeSet<>();

	public static void main(String[] args) {

		// ----------------------------------------------------
		do {
			System.out.println("1.- añadir");
			System.out.println("2.- listar");
			System.out.println("3.- borrar");
			System.out.println("0.- salir");

			opcion = sc.nextInt();

			switch (opcion) {
			case 1:
				// añadir();
				break;
			case 2:
				break;
			case 3:
				break;
			case 0:
				break;
			}
		} while (opcion != 0);

	}

	public void añadir(Vestido v) {
		ts.add(v);
	}

	public void borrar(Vestido v) {

		Iterator<Vestido> i = ts.iterator();

		while (i.hasNext()) {
			Vestido v2 = i.next();
			if (v.equals(v2)) {
				i.remove();
			}
		}

	}

}
