package ArrayNumeros;

import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;

/*
 * METODO QUE RECIBE UN ARRAY DE INT QUE TIENE VALORES distintos de 0 EN ALGUNAS POSICIONES
 * Y RECIBE TAMBIEN EL NOMBRE DE UN FICHERO BINARIO QUE CONTIENE VARIOS INT 
 * EL METODO DEBE LEER LOS INT DEL FICHERO E IRLOS COLOCANDO EN LOS HUECOS Ç
 * que son 0 DEL ARRAY
 * DARA UNA EXCEOCION PERSONAOLIZADA SI NO PUEDE METERLOS TODOS
 */
public class ArrayNumeros {

	public void LeeryColocar(int[] a, String f) throws Nocabeexception {

		File Ff = new File(f);
		if (Ff.exists()) {
			FileInputStream fi = null;
			ObjectInputStream os = null;
			try {
				fi = new FileInputStream(f);
				os = new ObjectInputStream(fi);
				while (true) {
					int l = os.readInt();
					boolean entro = false;
					for (int i = 0; i < a.length && !entro; i++) {
						if (a[i] != 0) {
							a[i] = l;
							entro = true;
						}
					}
					if (!entro) {
						Nocabeexception n = new Nocabeexception();
						throw n;
					}

				}
			} catch (EOFException io) {
				System.out.println("fin de fichero conrtolado");
			} catch (IOException io) {
				io.printStackTrace();
			} finally {
				try {
					fi.close();
					os.close();
				} catch (IOException io) {
					io.printStackTrace();
				}
			}
		}

	}
}
