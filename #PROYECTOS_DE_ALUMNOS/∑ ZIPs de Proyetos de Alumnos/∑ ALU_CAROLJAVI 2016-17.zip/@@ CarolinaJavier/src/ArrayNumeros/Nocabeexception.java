package ArrayNumeros;

public class Nocabeexception extends Exception {
	public Nocabeexception() {
		super("No cabe");
	}
}
