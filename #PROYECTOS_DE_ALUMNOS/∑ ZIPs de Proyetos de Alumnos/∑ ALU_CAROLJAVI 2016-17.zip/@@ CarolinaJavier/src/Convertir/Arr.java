package Convertir;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.TreeSet;

public class Arr<T> {

	private ArrayList<T> al = new ArrayList<>();

	public void anyadir(T elem) {
		al.add(elem);
	}

	public boolean borrar(T elem) {
		boolean res = false;
		Iterator<T> it = al.iterator();

		while (it.hasNext()) {
			T var = it.next();
			if (elem.equals(var)) {
				it.remove();
			}
		}

		return res;
	}

	public TreeSet<T> convertir() {
		TreeSet<T> ts = new TreeSet<>();

		for (T e : al) {
			ts.add(e);
		}
		return ts;
	}

}
