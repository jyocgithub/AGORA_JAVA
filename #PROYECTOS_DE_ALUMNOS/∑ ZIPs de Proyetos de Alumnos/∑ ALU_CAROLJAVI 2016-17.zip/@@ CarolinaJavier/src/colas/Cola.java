package colas;

public class Cola {

	Nodo ultimo = null;
	Nodo primero = null;
	int contador = 0;

	public void añadir(Nodo nuevo) {
		if (primero == null) {
			ultimo = nuevo;
			primero = nuevo;
		} else {
			ultimo.setSiguiente(nuevo);
			ultimo = nuevo;
		}
		contador++;
	}

	public Nodo quitar() {
		Nodo res = primero;
		primero = primero.getSiguiente();
		contador--;
		return res;
	}

	public int cuantos() {
		return contador;
	}

	public void mostrarElementos() {
		Nodo actual = primero;
		while (actual != null) {
			System.out.println(actual.getContenido());
			actual = actual.getSiguiente();
		}
	}

	public boolean existeElemento(Nodo buscar) {
		Nodo actual = primero;
		boolean res = false;
		while (actual != null && !res) {
			if (actual.equals(buscar)) {
				res = true;
			}
			actual = actual.getSiguiente();
		}
		return res;
	}

}
