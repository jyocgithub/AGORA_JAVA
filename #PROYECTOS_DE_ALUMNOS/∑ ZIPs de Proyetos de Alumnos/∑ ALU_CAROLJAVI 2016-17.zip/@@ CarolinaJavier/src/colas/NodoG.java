package colas;

public class NodoG<T> {

	private T contenido;
	private NodoG siguiente;

	public NodoG(T contenido, NodoG siguiente) {
		this.contenido = contenido;
		this.siguiente = siguiente;
	}

	public T getContenido() {
		return contenido;
	}

	public void setContenido(T contenido) {
		this.contenido = contenido;
	}

	public NodoG getSiguiente() {
		return siguiente;
	}

	public void setSiguiente(NodoG siguiente) {
		this.siguiente = siguiente;
	}

	@Override
	public boolean equals(Object o) {
		boolean res = false;
		NodoG n = (NodoG) o;
		if (contenido.equals(n.getContenido())) {
			res = true;
		}

		return res;
	}

}
