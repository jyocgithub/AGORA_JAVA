package Alumno;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

public class EscribirAlFinal {

	public static void main(String[] args) {
		/*
		 * . Escribe un programa que añada al final de un fichero de texto unas líneas con las siguientes estadísticas del propio
		 * fichero: ----------------------------------------------- Número de líneas: XX Número de palabras: XX
		 */
		File f = new File("reinos.txt");
		leer(f);

	}

	public static void leer(File f) {
		int lineas = 0;
		int palabras = 0;

		if (f.exists()) {
			FileReader fr = null;
			BufferedReader br = null;
			try {
				fr = new FileReader(f);
				br = new BufferedReader(fr);
				String linea = "";

				linea = br.readLine();
				while (linea != null) {
					lineas++;

					String pal[] = linea.split(" ");
					palabras += pal.length;

					linea = br.readLine();
				}

			} catch (IOException e) {
				e.printStackTrace();
			} finally {
				try {
					br.close();
					fr.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}

		System.out.println("Número de líneas: " + lineas + " Número de palabras: " + palabras);

	}
}
