package Alumno;

import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		try {
			Alumno a = new Alumno("Pepe", 1, 4.5);
			System.out.println(a);
		} catch (EdadInferiorException e) {
			System.out.println(e.getMessage());
		}

		String w = "buenos,dias,nos,de,Dios";
		System.out.println(w);

		int y = w.length();
		char q = w.charAt(3);
		for (int i = 0; i < w.length(); i++) {
			System.out.println(w.charAt(i));
		}

		int d = w.indexOf("s");
		int d2 = w.lastIndexOf("s");

		String r = w.substring(0, 4);

		if (r.equals(w)) {

		}

		String[] m = w.split(",");
		String x = "melon";

		for (int i = 1; i < x.length() + 1; i++) {
			System.out.println(x.substring(0, i));
		}

		for (int i = 0; i < x.length(); i++) {
			System.out.println(x.substring(i, i + 1));
		}

		for (int i = x.length() - 1; i >= 0; i--) {
			System.out.println(x.substring(i, i + 1));
		}

		for (int i = x.length() - 1; i >= 0; i--) {
			System.out.println(x.substring(i, x.length()));
		}

		String e = "En un lugar de la Mancha";
		String[] pal;
		pal = e.split(" ");

		for (int i = 0; i < pal.length; i++) {
			System.out.println(pal[i]);
		}
		System.out.println(pal.length);

		String e1 = e.substring(0, e.length() / 2 + 1);
		String e2 = e.substring(e.length() / 2 + 1);
		e1 = e1.toUpperCase();
		System.out.println(e1 + e2);
		// Dado un array de países que tenga este contenido:
		// {"Cuba", "Republica de Colombia", "Reino de Perú", "Nuevo Reino de Canadá", "Republica de Argentina", "Honduras",
		// "Republica de Uruguay" };
		// Indicar cuántos son repúblicas, cuántos reinos y cuántos el resto
		int reinos = 0;
		int rep = 0;
		String paises[] = { "Cuba", "Republica de Colombia", "Reino de Perú", "Nuevo Reino de Canadá",
				"Republica de Argentina", "Honduras", "Republica de Uruguay" };
		for (int i = 0; i < paises.length; i++) {
			if (paises[i].contains("Reino")) {
				reinos++;
			}
		}

		ArrayList<String> pais = new ArrayList<>();

		for (int i = 0; i < paises.length; i++) {
			if (paises[i].contains("Reino")) {
				pais.add(paises[i]);
			}
		}

		for (String a : pais) {
			System.out.println(a);
		}

		Scanner sc = new Scanner(System.in);

		System.out.println("Introduce una frase: ");
		String frase = sc.nextLine();
		sc.nextLine();

		String[] aFrase = frase.split(" ");

		for (int i = 0; i < aFrase.length; i++) {
			if (aFrase[i].contains("lunes") || aFrase[i].contains("Lunes")) {
				aFrase[i] = aFrase[i].toUpperCase();
			}
		}

		for (int i = 0; i < aFrase.length; i++) {
			System.out.print(aFrase[i] + " ");
		}

		ArrayList<String> cadenas = new ArrayList<>();
		Scanner es = new Scanner(System.in);
		System.out.println("Introduce palabras (fin=salir): ");
		String p;
		int mayor = 0;
		String cadMayor = " ";

		do {
			p = es.nextLine();
			cadenas.add(p);
		} while (!p.equals("fin"));

		for (String s : cadenas) {
			if (s.length() >= mayor) {
				mayor = s.length();
				cadMayor = s;
			}
		}

		System.out.print(cadMayor);

	}

	public void escribirFicheroTexto() {
		PrintWriter pw = null;
		try {
			pw = new PrintWriter("pruebas.txt");
			pw.print("buenos dias");
			pw.print("buenos dias 2");
			pw.print("buenos dias 3");
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} finally {
			pw.close();
		}

	}

}
