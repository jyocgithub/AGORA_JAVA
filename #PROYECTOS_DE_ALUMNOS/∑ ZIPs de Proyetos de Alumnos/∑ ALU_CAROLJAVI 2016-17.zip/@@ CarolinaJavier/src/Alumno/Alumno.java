package Alumno;

public class Alumno {
	private String nombre;
	private int edad;
	private double nota;

	public Alumno(String n, int e, double nt) throws EdadInferiorException {
		nombre = n;
		edad = e;
		if (e < 0) {
			EdadInferiorException ei = new EdadInferiorException();
			throw ei;
		}
		nota = nt;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public int getEdad() {
		return edad;
	}

	public void setEdad(int edad) {
		this.edad = edad;
	}

	public double getNota() {
		return nota;
	}

	public void setNota(double nota) throws NotaErroneaException {
		if (nota < 0 || nota > 10) {
			NotaErroneaException ne = new NotaErroneaException();
			throw ne;
		}
		this.nota = nota;

	}

	@Override
	public String toString() {
		String res = "El alumno se llama " + nombre + " y tiene " + edad;
		return res;
	}

}

class EdadInferiorException extends Exception {
	public EdadInferiorException() {
		super("La edad no puedo ser inferior a 0");
	}
}

class NotaErroneaException extends Exception {
	public NotaErroneaException() {
		super("La nota no puede ser inferior a 0 ni superior a 10");
	}
}