package genericos;

public class Vestido {

	// ATRIBUTOS
	protected int precio;
	private String marca;
	private int ano;
	static int totalvestidos;

	// METODOS

	// @Override
	// public boolean equals(Object b) {
	// Vestido vv = (Vestido)b;
	// boolean res=false;
	// if( this.marca.equals(vv.getMarca()) && this.ano==vv.getAno() ) {
	// res=true;
	// }
	// return res;
	// }

	public int getPrecio() {
		return precio;
	}

	public void setPrecio(int pre) {
		precio = pre;
	}

	public String getMarca() {
		return marca;
	}

	public void setMarca(String marca) {
		this.marca = marca;
	}

	public int getAno() {
		return ano;
	}

	public void setAno(int ano) {
		this.ano = ano;
	}

	Vestido(int p, String marca, int a) {
		precio = p;
		this.marca = marca;
		ano = a;
		totalvestidos++;
	}

	Vestido(String m, int a) {
		precio = 0;
		marca = m;
		ano = a;
	}

	public double calcularIVA() {
		double res = 0.0;
		res = precio * 0.21;
		return res;
	}

	final public double calcularIVA(double porcen) {
		double res = 0.0;
		res = precio / 100 * porcen;
		return res;
	}

}
