package genericos;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.PrintWriter;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.TreeSet;

public class Inicio {

	public static void cambiar(int x, int[] ar, String st) {
		x = 3;
		ar[0] = 5;
		st = "hola";
	}

	public static void main(String[] args) {

		// 1
		// creamos un conjunto de String
		TreeSet<String> conjunto = new TreeSet<>();

		// añadimos Strings

		for (int i = 0; i < 4; i++) {
			conjunto.add("pepe");
		}

		// guardamos los stringd ern un fichero de TEXTO

		PrintWriter pw = null;

		try {
			pw = new PrintWriter("fichero.txt");
			for (String s : conjunto) {
				pw.println(s);
			}

		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (pw != null) {
				pw.close();
			}
		}

		// leemos los Strings y los guerdamos en un ArrayList

		File f = new File("fichero.txt");
		ArrayList<String> al = new ArrayList<>();

		if (f.exists()) {
			FileReader fr = null;
			BufferedReader br = null;
			String linea = "";
			try {
				fr = new FileReader(f);
				br = new BufferedReader(fr);

				linea = br.readLine();
				while (linea != null) {
					al.add(linea);

					linea = br.readLine();
				}

			} catch (IOException e) {
				e.printStackTrace();
			} finally {
				try {
					if (fr != null) fr.close();
					if (br != null) br.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}

		// mostramos el arrayList por pantalla

		// 2
		// creamos un conjunto de Vestidos
		// añadimos Vestidos
		// guardamos los Vestidos ern un fichero BINARIO
		// leemos los Vestidos y los guerdamos en un ArrayList
		// mostramos el arrayList por pantalla

	}

	public void crearFicheroTexto() {

		// DECLARAR EL OBJETO DE LA CLASE A USAR PARA ESCRIBIR e INICIALIZAR A NULL
		PrintWriter pw = null;

		try {
			// INSTANCIAR EL OBJETO/S DE LA CLASE PARA ESCRIBIR ANTES DECLARADA
			pw = new PrintWriter("pru.txt");

			// USAR LOS METODOS DEL OBJETO INSTANCIADO PARA ESCRIBIR (print(), println())
			pw.println("Ana");

		}
		// INCLUIR CATCH PARA CONTROLAR ERRORES DE I/O, BASTA CON INCLUIR IOEXCEPTION
		catch (IOException e) {
			System.out.println(e.getMessage());
			// INCLUIR CATCH FINAL (O UNICO) DE IOEXCEPTION
		} finally {
			if (pw != null) { // PREGUNTAR ANTES DEL CLOSE SI EL OBJETO NO ES NULL
				pw.close();
			}
		}
	}

	public void leerFicheroTexto() {
		File fil = new File("pru.txt");
		// SOLO ACTUAR SI EL FICHERO EXISTE
		if (fil.exists()) {
			// DECLARAR LOS OBJETOS DE LAS CLASES A USAR PARA LEER e INICIALIZAR A NULL
			FileReader fr = null;
			BufferedReader br = null;
			try {
				// INSTANCIAR EL OBJETO/S DE LAS CLASES PARA LEER ANTES DECLARADA
				fr = new FileReader(fil);
				br = new BufferedReader(fr);
				// USAR UN WHILE PARA LEER TODAS LAS LINEAS DEL FICHERO CON readline()
				String linea = br.readLine();
				while (linea != null) {
					System.out.println(linea);
					linea = br.readLine();
				}
			}
			// INCLUIR CATCH PARA CONTROLAR ERRORES DE I/O, BASTA CON INCLUIR IOEXCEPTION
			catch (IOException e) {
				System.out.println(e.getMessage());
			} finally {
				// CERRAR EL OBJETO DE ESCRITURA EN EL FINALLY, PERO DENTRO DE OTRO TRY CON IOEXCEPTION
				try {
					if (fr != null) { // PREGUNTAR ANTES DEL CLOSE SI EL OBJETO NO ES NULL
						fr.close();
					}
					if (br != null) { // PREGUNTAR ANTES DEL CLOSE SI EL OBJETO NO ES NULL
						br.close();
					}
				} catch (IOException e) {
					System.out.println(e.getMessage());
				}
			}
		}
	}

	public void crearFicheroBinarioObjetos() {
		// DECLARAR LOS OBJETOS DE LAS CLASES A USAR PARA ESCRIBIR e INICIALIZAR A NULL
		FileOutputStream fos = null;
		ObjectOutputStream oos = null;
		try {
			// INSTANCIAR LOS OBJETOS DE LAS CLASES PARA ESCRIBIR
			fos = new FileOutputStream("pru.txt");
			oos = new ObjectOutputStream(fos);

			// USAR METODOS PARA ESCRIBIR (writeUTF(), writeInt(), writeObject()...)
			oos.writeUTF("Ana");
			Persona per = new Persona();
			oos.writeObject(per);
		}
		// INCLUIR CATCH PARA CONTROLAR ERRORES DE I/O, BASTA CON INCLUIR IOEXCEPTION
		catch (IOException e) {
			e.printStackTrace();
		} finally {
			// CERRAR LOS OBJETOS DE ESCRITURA EN EL FINALLY, PERO DENTRO DE OTRO TRY CON IOEXCEPTION
			try {
				if (fos != null) { // PREGUNTAR ANTES DEL CLOSE SI EL OBJETO NO ES NULL
					fos.close();
				}
				if (oos != null) { // PREGUNTAR ANTES DEL CLOSE SI EL OBJETO NO ES NULL
					oos.close();
				}
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

	public void leerFicheroBinarioObjetos() {
		File file = new File("pru.txt");
		// SOLO ACTUAR SI EL FICHERO EXISTE
		if (file.exists()) {
			// DECLARAR LOS OBJETOS DE LAS CLASES A USAR PARA ESCRIBIR e INICIALIZAR A NULL
			FileInputStream fis = null;
			ObjectInputStream ois = null;
			try {
				// INSTANCIAR LOS OBJETOS DE LAS CLASES PARA LEER
				fis = new FileInputStream(file);
				ois = new ObjectInputStream(fis);
				// USAR METODOS PARA LEER (readInt(), readObject(), readUTF()...)
				String dato1 = ois.readUTF();
				Persona per = (Persona) ois.readObject();
			}
			// INCLUIR CATCH PARA CONTROLAR ERRORES DE I/O, BASTA CON INCLUIR IOEXCEPTION
			catch (IOException e) {
				e.printStackTrace();
				// INCLUIR CATCH CON CLASSNOTFOUNDEXCEPTION
			} catch (ClassNotFoundException e) {
				e.printStackTrace();
			} finally {
				// CERRAR LOS OBJETOS DE ESCRITURA EN EL FINALLY, PERO DENTRO DE OTRO TRY CON IOEXCEPTION
				try {
					if (fis != null) { // PREGUNTAR ANTES DEL CLOSE SI EL OBJETO NO ES NULL
						fis.close();
					}
					if (ois != null) { // PREGUNTAR ANTES DEL CLOSE SI EL OBJETO NO ES NULL
						ois.close();
					}
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	}

}

class Persona implements Serializable {
	String nombre;
}
