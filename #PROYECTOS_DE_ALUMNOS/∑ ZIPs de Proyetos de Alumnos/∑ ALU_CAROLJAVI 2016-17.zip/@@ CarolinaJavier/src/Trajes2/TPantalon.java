package Trajes2;

public class TPantalon extends Traje {

	private int bolsillos;

	TPantalon(int t, double pvp, int p, int b) {
		super(t, pvp, p);

		bolsillos = b;
	}

	@Override
	public void aplicaRebaja(boolean rebaja) {
		double resul = 0;
		if (rebaja) {
			resul = this.getPrecio() / 100 * this.getPorcen();
			resul = this.getPrecio() - resul;
			this.setPrecio(resul);
		} else {
			resul = this.getPrecio() / 100 * this.getPorcen();
			resul = this.getPrecio() + resul;
			this.setPrecio(resul);
		}
	}
}
