package Trajes2;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;

public class Almacen {

	static int siguiente = 0;
	// static TFalda[] faldas = new TFalda[5];
	static ArrayList<TFalda> faldas = new ArrayList<>();

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);

		int opc = 0;

		do {
			System.out.println("1.- Añadir traje");
			System.out.println("2.- Listar trajes");
			System.out.println("3.- Borrar traje");
			System.out.println("4.- Aplicar descuento a todos los trajes");
			System.out.println("5.- Salir");

			System.out.print("> ");
			opc = sc.nextInt();
			switch (opc) {
			case 1:
				TFalda falda = pedirFalda();
				aniadirFalda(falda);
				break;
			case 2:
				listarTrajes();
				break;
			case 3:
				System.out.println("Talla a eliminar: ");
				int talla = sc.nextInt();
				borrarTraje(talla);
				break;
			case 5:
				break;
			default:
				System.out.println("Opcion incorrecta.");
				break;
			}

		} while (opc != 5);
	}

	static void aniadirFalda(TFalda f) {
		faldas.add(f);

		/*
		 * faldas[siguiente] = f; siguiente++;
		 */
	}

	static TFalda pedirFalda() {
		Scanner sc = new Scanner(System.in);

		System.out.println("Dame talla: ");
		int t = sc.nextInt();
		System.out.println("Dame precio: ");
		double pvp = sc.nextDouble();
		System.out.println("Dame porcentaje de la rebaja: ");
		int p = sc.nextInt();
		System.out.println("Dame numero de cremalleras: ");
		int c = sc.nextInt();

		TFalda f = new TFalda(t, pvp, p, c);

		return f;
	}

	static void listarTrajes() {
		for (int i = 0; i < faldas.size(); i++) {
			System.out.println("Falda " + i);
			System.out.println(faldas.get(i));
		}
	}

	static void borrarTraje(int talla) {

		Iterator<TFalda> ite = faldas.iterator();
		while (ite.hasNext()) {
			TFalda f = ite.next();
			if (f.getTalla() == talla) {
				ite.remove();
			}
		}

		// DA ERROOOOOOOOOORRRRRRRR
		for (TFalda f : faldas) {
			if (f.getTalla() == talla) {
				faldas.remove(f);
			}
		}

	}

	static void aplicarDescuento(int porcen) {

	}

}
