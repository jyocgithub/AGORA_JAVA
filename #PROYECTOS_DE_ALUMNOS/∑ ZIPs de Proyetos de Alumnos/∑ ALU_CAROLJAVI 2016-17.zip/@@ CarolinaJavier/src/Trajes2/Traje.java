package Trajes2;

public abstract class Traje {
	private int talla;
	private double precio;
	private int porcen;

	Traje(int t, double pvp, int p) {
		talla = t;
		precio = pvp;
		porcen = p;
	}

	abstract void aplicaRebaja(boolean rebaja);

	public int getTalla() {
		return talla;
	}

	public void setTalla(int talla) {
		this.talla = talla;
	}

	public double getPrecio() {
		return precio;
	}

	public void setPrecio(double precio) {
		this.precio = precio;
	}

	public int getPorcen() {
		return porcen;
	}

	public void setPorcen(int porcen) {
		this.porcen = porcen;
	}

}
