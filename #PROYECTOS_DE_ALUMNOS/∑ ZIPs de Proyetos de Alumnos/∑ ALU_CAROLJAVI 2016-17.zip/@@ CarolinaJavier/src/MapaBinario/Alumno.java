package MapaBinario;

import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.HashMap;

public class Alumno implements Serializable {
	private String nombre;
	private int edad;
	private double nota;

	public Alumno(String n, int e, double nt) throws EdadInferiorException {
		nombre = n;
		edad = e;
		if (e < 0) {
			EdadInferiorException ei = new EdadInferiorException();
			throw ei;
		}
		nota = nt;
	}

	public static int guardarMapa(HashMap<String, Alumno> h) {
		int cont = 0;

		FileOutputStream fos = null;
		ObjectOutputStream oos = null;
		try {
			fos = new FileOutputStream("hola.txt");
			oos = new ObjectOutputStream(fos);

			for (Alumno a : h.values()) {
				if (a.getEdad() > 18) {
					oos.writeObject(a);
					cont++;
				}
			}

		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				fos.close();
				oos.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}

		return cont;
	}

	public static void crearMapa(File f) {

		HashMap<String, Alumno> h = new HashMap<>();
		Alumno a = null;

		if (f.exists()) {

			FileInputStream fis = null;
			ObjectInputStream ois = null;

			try {
				fis = new FileInputStream(f);
				ois = new ObjectInputStream(fis);

				while (true) {
					a = (Alumno) ois.readObject();
					h.put(a.getNombre(), a);
				}

			} catch (ClassNotFoundException e) {
				e.printStackTrace();
			} catch (EOFException e) {
				System.out.println("Fin de fichero");
			} catch (IOException e) {
				e.printStackTrace();
			} finally {
				try {
					fis.close();
					ois.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}

	}

	public static int[] posImpares(int[] a) {
		int[] res = new int[a.length];
		int libre = 0;

		for (int i = 0; i < a.length; i++) {
			if (i % 2 != 0) {
				res[libre] = a[i];
				libre++;
			}
		}

		return res;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public int getEdad() {
		return edad;
	}

	public void setEdad(int edad) {
		this.edad = edad;
	}

	public double getNota() {
		return nota;
	}

	public void setNota(double nota) throws NotaErroneaException {
		if (nota < 0 || nota > 10) {
			NotaErroneaException ne = new NotaErroneaException();
			throw ne;
		}
		this.nota = nota;

	}

	@Override
	public String toString() {
		String res = "El alumno se llama " + nombre + " y tiene " + edad;
		return res;
	}

}

class EdadInferiorException extends Exception {
	public EdadInferiorException() {
		super("La edad no puedo ser inferior a 0");
	}
}

class NotaErroneaException extends Exception {
	public NotaErroneaException() {
		super("La nota no puede ser inferior a 0 ni superior a 10");
	}
}