package JYOCJava_30_2_FabricaDeTrajes;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Scanner;

public class FabricaTrajes {

     private static HashMap<Integer, Traje> envio = null;
     private static ArrayList<Traje> trajesEnStock = null;
     private static ArrayList<Componente> componentesEnStock = null;
     private static double importeEnvio = 0;

     public static void main(String[] args) {
          new FabricaTrajes().menu();
     }

     public void menu() {
          int opc = -1;
          Scanner sc = new Scanner(System.in);

          do {
               System.out.println("1.- Añadir componente");
               System.out.println("2.- Crear traje");
               System.out.println("3.- Listar componentes");
               System.out.println("4.- Guardar componentes");
               System.out.println("5.- Recuperar componentes");
               System.out.println("6.- Guardar envio");
               System.out.println("7.- Recuperar envio");
               System.out.println("8.- Ajustes comunitarios");
               System.out.println("9.- Activar o desactivar rebaja");
               System.out.println("0.- Salir");

               opc = sc.nextInt();

               switch (opc) {
                    case 1:
                         anadirComponenteAStockDeFabrica();
                         break;
                    case 2:
                         crearTraje();

                         break;
                    case 3:
                         break;
                    case 4:
                         break;
                    case 5:
                         break;
                    case 6:
                         break;
                    case 7:
                         break;
                    case 8:
                         break;
                    case 9:
                         break;
                    default:
                         break;
               }

          } while (opc != 0);
     }

     public void anadirComponenteAStockDeFabrica() {
          String res = "", res2 = "";
          int id = 0;
          String nombre = "", talla = "", color = "", esco = "";
          boolean escomunitario = false, unboolean = false;
          double precio = 0.0;
          int nb = 0;

          Scanner sc = new Scanner(System.in);
          System.out.println("Tipo de componente (chaqueta=c , blusa=b , falda=f , pantalon=p): ");
          res = sc.nextLine();
          System.out.println("Introduzca id: ");
          id = sc.nextInt();
          System.out.println("Introduzca nombre: ");
          nombre = sc.nextLine();
          System.out.println("Introduzca talla: ");
          talla = sc.nextLine();
          System.out.println("Introduzca color: ");
          color = sc.nextLine();
          System.out.println("Comunitario? (s=si , n=no): ");
          esco = sc.nextLine();
          escomunitario = (esco.equalsIgnoreCase("S"));
          System.out.println("Introduzca precio: ");
          precio = sc.nextDouble();

          if (res.equals("c")) {
               System.out.println("Introduzca numero de botones: ");
               nb = sc.nextInt();
               Componente c = new Chaqueta(id, nombre, talla, color, escomunitario, precio, nb);
               componentesEnStock.add(c);
          } else if (res.equals("b")) {
               System.out.println("Manga larga? (s=si , n=no): ");
               res2 = sc.nextLine();
               unboolean = (res2.equalsIgnoreCase("S"));
          } else if (res.equals("f")) {
               System.out.println("Con cremallera? (s=si , n=no): ");
               res2 = sc.nextLine();
               unboolean = (res2.equalsIgnoreCase("S"));
          } else if (res.equals("p")) {
               System.out.println("Con cremallera? (s=si , n=no): ");
               res2 = sc.nextLine();
               unboolean = (res2.equalsIgnoreCase("S"));
          } else {
               System.out.println("Tipo de componente erroneo");
          }
     }

     public void crearTraje() {
          HashMap<Integer, Blusa> blusasMap = new HashMap<>();
          HashMap<Integer, Chaqueta> chaquetasMap = new HashMap<>();
          HashMap<Integer, Componente> otrosMap = new HashMap<>();
          for (Componente c : componentesEnStock) {
               if (c instanceof Blusa) {
                    chaquetasMap.put(c.getId(), (Chaqueta) c);
               } else if (c instanceof Blusa) {
                    blusasMap.put(c.getId(), (Blusa) c);
               } else {
                    otrosMap.put(c.getId(), c);
               }
          }
          // elegir chaqueta 
          System.out.println("Elija una chaqueta para el traje:");
          for (Chaqueta c : chaquetasMap.values()) {
               System.out.print((c.getId()) + ".-");
               System.out.println(c);
          }
           int op = Util.leerInt("indique el numero de la chaqueta elegida");
          Chaqueta chaquetaelegida = chaquetasMap.get(op);
          

          // elegir blkusa
          System.out.println("Elija una blusa para el traje:");
          for (Blusa c : blusasMap.values()) {
               System.out.print((c.getId()) + ".-");
               System.out.println(c);
          }
           op = Util.leerInt("indique el numero de la blusa elegida");
          Blusa blusaelegida = blusasMap.get(op);
          

          // elegir igualmente falda o pantalon
          System.out.println("Elija el numero de una falda o pantalon para el traje:");
          for (Componente c : otrosMap.values()) {
               System.out.print((c.getId()) + ".-");
               System.out.println(c);
          }
           op = Util.leerInt("indique el numero de la blusa elegida");
          Componente otroselegido = otrosMap.get(op);
          
          
          // Todos 
          
          
          
          

     }


     public void listar() {
          for (Componente c : componentesEnStock) {
               System.out.println(c.toString());
          }
     }

}
