package JYOCJava_30_2_FabricaDeTrajes;

public abstract class Componente {
	private int id;
	private String nombre;
	private String talla;
	private String color;
	private boolean escomunitario;
	private double precio;

	public Componente(int id, String nombre, String talla, String color, boolean esc, double precio) {
		this.id = id;
		this.nombre = nombre;
		this.talla = talla;
		this.color = color;
		escomunitario = esc;
		this.precio = precio;
	}

	abstract void aplicarRebaja(boolean activarDesactivar);

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getTalla() {
		return talla;
	}

	public void setTalla(String talla) {
		this.talla = talla;
	}

	public String getColor() {
		return color;
	}

	public void setColor(String color) {
		this.color = color;
	}

	public boolean isEscomunitario() {
		return escomunitario;
	}

	public void setEscomunitario(boolean escomunitario) {
		this.escomunitario = escomunitario;
	}

	public double getPrecio() {
		return precio;
	}

	public void setPrecio(double precio) {
		this.precio = precio;
	}

	@Override
	public String toString() {
		String s = nombre + " " + talla + " " + color;
		return s;
	}
}
