package JYOCJava_30_2_FabricaDeTrajes;

import java.util.Scanner;

public class Util {
	public static int leerInt(String mens) {
		System.out.println(mens);
		Scanner sc = new Scanner(System.in);
		int opc = sc.nextInt();
		return opc;
	}

	public static String leerString(String mens) {
		System.out.println(mens);
		Scanner sc = new Scanner(System.in);
		return sc.nextLine();
	}

}
