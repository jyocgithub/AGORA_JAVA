package JYOCJava_30_2_FabricaDeTrajes;

public class Traje {
	private Componente[] piezas = null;
	private int np;

	public Traje() {
		piezas = new Componente[3];
		np = 0;
	}

	public boolean anyadirPieza(Componente com) {
		boolean res = false;

		if (np < 3) {
			piezas[np] = com;
			np++;
			res = true;
		}

		return res;
	}

}
