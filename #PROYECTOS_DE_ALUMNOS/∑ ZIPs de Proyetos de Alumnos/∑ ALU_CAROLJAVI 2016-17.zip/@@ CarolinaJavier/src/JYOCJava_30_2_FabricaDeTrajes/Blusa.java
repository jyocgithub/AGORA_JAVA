package JYOCJava_30_2_FabricaDeTrajes;

public class Blusa extends Componente {

	private boolean mangaLarga;

	public Blusa(int id, String nombre, String talla, String color, boolean esc, double precio) {
		super(id, nombre, talla, color, esc, precio);
		mangaLarga = false;
	}

	public boolean isMangaLarga() {
		return mangaLarga;
	}

	public void setMangaLarga(boolean mangaLarga) {
		this.mangaLarga = mangaLarga;
	}

	@Override
	void aplicarRebaja(boolean activarDesactivar) {

	}

}
