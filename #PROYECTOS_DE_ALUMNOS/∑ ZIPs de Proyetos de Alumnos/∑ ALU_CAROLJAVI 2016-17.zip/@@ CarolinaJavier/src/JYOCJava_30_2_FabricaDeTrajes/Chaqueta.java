package JYOCJava_30_2_FabricaDeTrajes;

public class Chaqueta extends Componente {

	private int numeroBotones;

	public Chaqueta(int id, String nombre, String talla, String color, boolean esc, double precio, int nb) {
		super(id, nombre, talla, color, esc, precio);
		numeroBotones = nb;
	}

	@Override
	void aplicarRebaja(boolean activarDesactivar) {

	}

	public int getNumeroBotones() {
		return numeroBotones;
	}

	public void setNumeroBotones(int numeroBotones) {
		this.numeroBotones = numeroBotones;
	}

}
