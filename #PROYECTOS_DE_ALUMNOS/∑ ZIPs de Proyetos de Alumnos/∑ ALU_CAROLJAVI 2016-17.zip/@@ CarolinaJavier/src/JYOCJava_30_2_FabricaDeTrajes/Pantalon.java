package JYOCJava_30_2_FabricaDeTrajes;

public class Pantalon extends Componente {

	private boolean concremallera;

	public Pantalon(int id, String nombre, String talla, String color, boolean esc, double precio) {
		super(id, nombre, talla, color, esc, precio);
		concremallera = false;
	}

	@Override
	void aplicarRebaja(boolean activarDesactivar) {

	}

	public boolean isConcremallera() {
		return concremallera;
	}

	public void setConcremallera(boolean concremallera) {
		this.concremallera = concremallera;
	}

}
