
public class Bonoloto {

	public static void main(String[] args) {

		int[] boleto = new int[6];

		for (int i = 0; i < boleto.length; i++) {

			int j = (int) (Math.random() * (47 - 1) + 1);
			// mirar si existe
			int esta = 0;
			for (int k = 0; k < boleto.length; k++) {
				if (boleto[k] == j) {
					esta = 1;
				}
			}
			// si no existe, lo añado
			if (esta == 0) {
				boleto[i] = j;
				System.out.println(boleto[i]);
			} else {
				i--;
			}
		}

		int i = 0;
		while (i < boleto.length) {

			int j = (int) (Math.random() * (47 - 1) + 1);
			// mirar si existe
			int esta = 0;
			for (int k = 0; k < boleto.length; k++) {
				if (boleto[k] == j) {
					esta = 1;
				}
			}
			// si no existe, lo añado
			if (esta == 0) {
				boleto[i] = j;
				System.out.println(boleto[i]);
				i++;
			}
		}

	}

}
