
public class MayoryMenor {
	public static void main(String[] args) {
		int ar[] = { 1, 56, 3, 4, 2, 5, 23, 5, 2 };

		int mayor = -1;
		int menor;
		mayor = ar[0];

		for (int i = 0; i < ar.length; i++) {
			if (ar[i] > mayor) {
				mayor = ar[i + 1];
			}
		}
	}
}
