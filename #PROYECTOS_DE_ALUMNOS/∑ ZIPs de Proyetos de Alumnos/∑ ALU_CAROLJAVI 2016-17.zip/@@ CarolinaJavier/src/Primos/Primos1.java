package Primos;

public class Primos1 {

	public static void main(String[] args) {

		int cont = 0;
		boolean vale = true;
		System.out.println(1);
		for (int i = 2; i < 101; i++) {

			if (esPrimo(i)) {
				System.out.println(i);
			}
		}
	}

	static boolean esPrimo(int u) {
		boolean vale = true;
		for (int j = u - 1; j >= 2; j--) {
			if (u % j == 0) {
				vale = false;
			}
		}
		if (vale) {
			return true;
		}
		return false;
	}
}
