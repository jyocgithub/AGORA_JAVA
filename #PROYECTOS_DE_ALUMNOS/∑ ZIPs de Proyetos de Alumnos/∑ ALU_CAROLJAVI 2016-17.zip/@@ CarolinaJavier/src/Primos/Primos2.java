package Primos;

public class Primos2 {

	public static void main(String[] args) {
		int[] pr = new int[100];
		int cont = 0;
		int i = 0;
		while (pr[99] == 0) {
			if (esPrimo(cont)) {
				pr[i] = cont;
				System.out.println(pr[i]);
				i++;

			}
			cont++;

		}

	}

	static boolean esPrimo(int u) {
		boolean vale = true;
		for (int j = u - 1; j >= 2; j--) {
			if (u % j == 0) {
				vale = false;
			}
		}
		if (vale) {
			return true;
		}
		return false;
	}

}
