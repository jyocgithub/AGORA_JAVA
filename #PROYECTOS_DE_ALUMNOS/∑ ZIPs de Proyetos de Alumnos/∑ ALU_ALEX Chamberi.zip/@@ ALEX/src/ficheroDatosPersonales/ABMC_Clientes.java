package ficheroDatosPersonales;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class ABMC_Clientes {

	public void menu(Cliente[] aClientes) {

		// lectura inicial deo fichero de clientes
		leerClientes(aClientes);

		int opcion;
		do {
			System.out.println("MENU PRINCIPAL");
			System.out.println("----------------------");
			System.out.println("1.- Alta");
			System.out.println("2.- Modificacion");
			System.out.println("3.- Baja");
			System.out.println("4.- Consulta");
			System.out.println("5.- Consultar todos");
			System.out.println("6.- Ordenar clientes");
			System.out.println("7.- Buscar clientes");
			System.out.println("0.- Fin");
			System.out.println("----------------------");

			opcion = leerIntTeclado("Indique opcion a ejecutar:");
			switch (opcion) {
				case 1:
					alta(aClientes);
					break;
				case 2:
					modificacion(aClientes);
					break;
				case 3:
					baja(aClientes);
					break;
				case 4:
					consulta(aClientes);
					break;
				case 5:
					consultaTodos(aClientes);
					break;
				case 6:
					ordenarArray(aClientes);
					escribirTodosLosClientes(aClientes);

					System.out.println("Ordenacion hecha");

					break;
				case 7:
					leerClientes(aClientes);
					guardarTodoEnFicheroTxt(aClientes);
					break;
			}

		} while (opcion != 0);
	}

	public void consultaTodos(Cliente[] aClientes) {
		for (int i = 0; i < aClientes.length; i++) {
			if (aClientes[i] != null) {
				System.out.println(aClientes[i].toString());
			}
		}
	}

	public void consulta(Cliente[] aClientes) {
		String n = leerStringTeclado("Dame el nombre del cliente a consultar:");
		for (int i = 0; i < aClientes.length; i++) {
			if (aClientes[i] != null) {
				if (aClientes[i].getNombre().equals(n)) {
					System.out.println(aClientes[i].toString());
				}
			}
		}
	}

	// *********************************************************** leerStringTeclado
	public boolean modificacion(Cliente[] aClientes) {
		boolean secambiauncliente = false;
		String n = leerStringTeclado("Dame el nombre del cliente a modificar:");
		for (int i = 0; i < aClientes.length; i++) {
			if (aClientes[i] != null) {
				if (aClientes[i].getNombre().equals(n)) {
					secambiauncliente = true;

					// mostrar cliente actual
					System.out.println(aClientes[i].toString());

					// crear nuevo cliente
					Cliente c = crearUnCliente();
					// TODO quitar al acabar pruebas
					// Cliente c = new Cliente("123", "123", 123, "123".toCharArray(), stringToDate("12/12/98"),
					// 123, "123", "123", "123", 123, 123, "123", "123", stringToDate("12/12/98"), 123,
					// true, true,
					// "123");
					// borrar cliente actual
					aClientes[i] = null;

					// añadir cliente nuevo al array
					for (int h = 0; h < aClientes.length; h++) {
						if (aClientes[h] == null) {
							aClientes[h] = c;
							break;
						}
					}
					// guardar array en fichero
					escribirTodosLosClientes(aClientes);

					break;
				}
			}
		}

		if (!secambiauncliente) {
			System.out.println("No se encuentra el cliente, borrado cancelado");
			return false;
		}

		return secambiauncliente;
	}

	// *********************************************************** leerStringTeclado
	public boolean baja(Cliente[] aClientes) {
		boolean seborrauncliente = false;
		String n = leerStringTeclado("Dame el nombre del cliente a eliminar:");
		for (int i = 0; i < aClientes.length; i++) {
			if (aClientes[i] != null) {
				if (aClientes[i].getNombre().equals(n)) {
					seborrauncliente = true;
					aClientes[i] = null;
					break;
				}
			}
		}

		if (!seborrauncliente) {
			System.out.println("No se encuentra el cliente, borrado cancelado");
			return false;
		}

		escribirTodosLosClientes(aClientes);
		return seborrauncliente;
	}

	// *********************************************************** leerStringTeclado
	public Cliente alta(Cliente[] aClientes) {

		// crear un cliente
		Cliente c = crearUnCliente();
		// TODO quitar al acabar pruebas
		// Cliente c = new Cliente("123", "123", 123, "123".toCharArray(), stringToDate("12/12/98"),
		// 123, "123", "123", "123", 123, 123, "123", "123", stringToDate("12/12/98"), 123, true, true,
		// "123");

		// guardar el cliente en el fichero
		escribirUnCliente(c);

		// guardar el cliente en el array
		for (int i = 0; i < aClientes.length; i++) {
			if (aClientes[i] == null) {
				aClientes[i] = c;
				break;
			}
		}
		return c;
	}

	// *********************************************************** leerStringTeclado
	public Cliente crearUnCliente() {

		String n = leerStringTeclado("Dame el nombre de un cliente:");
		String a = leerStringTeclado("Dame el apellidos de un cliente:");
		boolean vale = true;

		// --------- leemos sexo
		int s;
		do {
			s = Integer.parseInt(leerStringTeclado("Dame el sexo de un cliente: (1-Hombre , 2-Mujer)"));
			if ((s == 1 || s == 2)) {
				vale = true;
			}
			else {
				System.out.println("Dato incorrecto");
				vale = false;
			}
		} while (!vale);

		// --------- leemos dni
		String d;
		do {
			d = leerStringTeclado("Dame dni de un cliente:");
			vale = validarDNI(d);
			if (!vale) System.out.println("Dato incorrecto");
		} while (!vale);

		// --------- leemos fecha nacimiento
		Date fn;
		do {
			String f = leerStringTeclado("Dame fecha nacimiento de un cliente: (dd/mm/aa)");
			fn = stringToDate(f);
			if (fn == null) {
				vale = false;
				System.out.println("Dato incorrecto");
			}

		} while (!vale);

		// --------- calculamos edad
		Date f = new Date(); // fecha de hoy
		int an = diferenciaEnAnosEntreDates(f, fn);

		String dir = leerStringTeclado("Dame direccion de un cliente:");
		String pob = leerStringTeclado("Dame poblacion de un cliente:");
		String pro = leerStringTeclado("Dame provincia de un cliente:");

		// --------- leemos cp, se valida en el propio metodo de lectura
		int cp = leerIntTeclado("Dame el CP de un cliente:");

		// --------- leemos telefono
		String t;
		do {
			t = leerStringTeclado("Dame el telefono de un cliente:");
			vale = false;
			if (t.charAt(0) == '9' || t.charAt(0) == '8' || t.charAt(0) == '7' || t.charAt(0) == '6')
			    vale = true;
			else System.out.println("Dato incorrecto");
		} while (!vale);
		int tel = Integer.parseInt(t);

		// --------- leemos mail
		String co;
		do {
			co = leerStringTeclado("Dame el e-mail de un cliente:");
			if (validarCorreo(co)) break;
			System.out.println("Dato incorrecto");
		} while (!vale);

		String sl = leerStringTeclado("Dame la situacion laboral de un cliente:");

		Date fal;
		do {
			String sfal = leerStringTeclado("Dame la fecha de alta de un cliente:");
			fal = stringToDate(sfal);
			if (fal == null) {
				vale = false;
				System.out.println("Dato incorrecto");
			}

		} while (!vale);

		int ofi = leerIntTeclado("Dame la oficina de un cliente:");
		boolean haydni = leerBooleanTeclado("Dime si adjunta copia de dni:");
		boolean hayfirma = leerBooleanTeclado("Dime si adjunta firma de contrato:");
		String obs = leerStringTeclado("Dame observaciones para el cliente:");

		Cliente c = new Cliente(n, a, s, d.toCharArray(), fn, an, dir, pob, pro, cp, tel, co, sl, fal, ofi,
		        haydni, hayfirma, obs);

		return c;

	}

	boolean escribirTodosLosClientes(Cliente[] aClientes) {
		File objetofichero1 = new File("clientes.dat");
		objetofichero1.delete();
		boolean sal = true;
		for (int i = 0; i < aClientes.length; i++) {
			if (aClientes[i] != null) {
				escribirUnCliente(aClientes[i]);
			}
		}
		return sal;
	}

	boolean escribirUnCliente(Cliente c) {
		try {

			File objetofichero1 = new File("clientes.dat");
			FileOutputStream fo = new FileOutputStream(objetofichero1, true);
			DataOutputStream dos = new DataOutputStream(fo);

			dos.writeBytes(rellenarConBlancos(c.getNombre(), 20));
			dos.writeBytes(rellenarConBlancos(c.getApellidos(), 20));
			dos.writeInt(c.getSexo());
			dos.writeBytes(rellenarConBlancos(new String(c.getDNI()), 20));
			dos.writeBytes(rellenarConBlancos(dateToString(c.getF_Nac()), 20));
			dos.writeInt(c.getEdad());
			dos.writeBytes(rellenarConBlancos(c.getDirección(), 20));
			dos.writeBytes(rellenarConBlancos(c.getPoblación(), 20));
			dos.writeBytes(rellenarConBlancos(c.getProvincia(), 20));
			dos.writeInt(c.getCP());
			dos.writeInt(c.getTeléfono());
			dos.writeBytes(rellenarConBlancos(c.getCorreoE(), 20));
			dos.writeBytes(rellenarConBlancos(c.getSLaboral(), 20));
			dos.writeBytes(rellenarConBlancos(dateToString(c.getF_Alta()), 20));
			dos.writeInt(c.getOficina());
			dos.writeBytes(rellenarConBlancos(booleanToStringSN(c.isCopiaDNI()), 20));
			dos.writeBytes(rellenarConBlancos(booleanToStringSN(c.isContratoBanco()), 20));
			dos.writeBytes(rellenarConBlancos(c.getObservaciones(), 20));

		}
		catch (FileNotFoundException e) {
			e.printStackTrace();
			return false;
		}
		catch (IOException e) {
			e.printStackTrace();
			return false;
		}

		return true;
	}

	// *************************************************** leerClientes
	boolean leerClientes(Cliente[] aClientes) {

		// calculamos cuantos clientes hay en el fichero
		File objetofichero1 = new File("clientes.dat");
		int numcli = (int) (objetofichero1.length() / 280); // 280 es el tamaño de cada registro

		// leemos tantos clientes como hay en el fichero
		for (int i = 0; i < numcli; i++) {

			try {
				FileInputStream fr = new FileInputStream(objetofichero1);
				DataInputStream br = new DataInputStream(fr);

				String n = leerStringDeFileBinario(br, 20).trim();

				String a = leerStringDeFileBinario(br, 20).trim();
				int s = br.readInt();
				String d = leerStringDeFileBinario(br, 20).trim();
				Date fn = stringToDate(leerStringDeFileBinario(br, 20).trim());
				int an = br.readInt();
				String dir = leerStringDeFileBinario(br, 20).trim();
				String pob = leerStringDeFileBinario(br, 20).trim();
				String pro = leerStringDeFileBinario(br, 20).trim();
				int cp = br.readInt();
				int tel = br.readInt();
				String co = leerStringDeFileBinario(br, 20).trim();
				String sl = leerStringDeFileBinario(br, 20).trim();
				Date fal = stringToDate(leerStringDeFileBinario(br, 20).trim());
				int ofi = br.readInt();
				boolean haydni = StringSNToBoolean(leerStringDeFileBinario(br, 20).trim());
				boolean hayfirma = StringSNToBoolean(leerStringDeFileBinario(br, 20).trim());
				String obs = leerStringDeFileBinario(br, 20).trim();

				Cliente c2 = new Cliente(n, a, s, d.toCharArray(), fn, an, dir, pob, pro, cp, tel, co, sl,
				        fal,
				        ofi,
				        haydni, hayfirma, obs);

				aClientes[i] = c2;

			}
			catch (FileNotFoundException e) {
				e.printStackTrace();
				return false;
			}
			catch (IOException e) {
				e.printStackTrace();
				return false;
			}
		}

		// eliminamos el resto de clientes de array
		for (int i = numcli; i < aClientes.length; i++) {
			aClientes[i] = null;
		}

		return true;
	}

	boolean guardarTodoEnFicheroTxt(Cliente[] aClientes) {
		File objetofichero1 = new File("clientes.dat");
		objetofichero1.delete();
		boolean sal = true;
		for (int i = 0; i < aClientes.length; i++) {
			if (aClientes[i] != null) {
				escribirUnClienteEnTxt(aClientes[i]);
			}
		}
		return sal;
	}

	boolean escribirUnClienteEnTxt(Cliente c) {
		try {

			File objetofichero1 = new File("clientes.txt");

			FileWriter fw = new FileWriter(objetofichero1);
			BufferedWriter bw = new BufferedWriter(fw);

			bw.write(rellenarConBlancos(c.getNombre(), 20));
			bw.write(rellenarConBlancos(c.getApellidos(), 20));
			bw.write(c.getSexo());
			bw.write(rellenarConBlancos(new String(c.getDNI()), 20));
			bw.write(rellenarConBlancos(dateToString(c.getF_Nac()), 20));
			bw.write(c.getEdad());
			bw.write(rellenarConBlancos(c.getDirección(), 20));
			bw.write(rellenarConBlancos(c.getPoblación(), 20));
			bw.write(rellenarConBlancos(c.getProvincia(), 20));
			bw.write(c.getCP());
			bw.write(c.getTeléfono());
			bw.write(rellenarConBlancos(c.getCorreoE(), 20));
			bw.write(rellenarConBlancos(c.getSLaboral(), 20));
			bw.write(rellenarConBlancos(dateToString(c.getF_Alta()), 20));
			bw.write(c.getOficina());
			bw.write(rellenarConBlancos(booleanToStringSN(c.isCopiaDNI()), 20));
			bw.write(rellenarConBlancos(booleanToStringSN(c.isContratoBanco()), 20));
			bw.write(rellenarConBlancos(c.getObservaciones(), 20));

		}
		catch (FileNotFoundException e) {
			e.printStackTrace();
			return false;
		}
		catch (IOException e) {
			e.printStackTrace();
			return false;
		}

		return true;

	}

	/**
	 * Metodo que convierte un Date en un String
	 * 
	 */
	public String dateToString(Date dateFecha) {
		SimpleDateFormat miFormato = new SimpleDateFormat("dd/MM/yyyy");
		Calendar cc = Calendar.getInstance();
		Date fecha = cc.getTime();
		String fechaEnTexto = miFormato.format(dateFecha);
		return fechaEnTexto;
	}

	/**
	 * Metodo que valida un mail
	 */
	public boolean validarCorreo(String strDni) {
		boolean res = true;
		if (strDni.substring(0, 1).equals("@")) return false;
		if (strDni.substring(0, 1).equals(".")) return false;
		if (!strDni.contains("@")) return false;
		if (!strDni.contains(".")) return false;
		if (strDni.indexOf('@') > strDni.indexOf('.')) return false;
		if (strDni.split(".").length > 2) return false;
		if (strDni.split("@").length > 2) return false;
		return res;
	}

	/**
	 * Metodo que convierte un String en un Date
	 */
	public Date stringToDate(String strFecha) {
		SimpleDateFormat miFormato2 = new SimpleDateFormat("dd/MM/yyyy");
		try {
			Date fecha2 = miFormato2.parse(strFecha);
			return fecha2;
		}
		catch (ParseException e) {
			e.printStackTrace();
		}
		return null;
	}

	// *********************************************************** leerStringTeclado
	public String leerStringTeclado(String mens) {
		System.out.println(mens);
		String resultado = "";
		try {
			InputStreamReader fr = new InputStreamReader(System.in);
			BufferedReader br = new BufferedReader(fr);
			resultado = br.readLine();
		}
		catch (IOException e) {
			e.printStackTrace();
		}
		return resultado;
	} // fin leerStringTeclado

	// *********************************************************** leerIntTeclado
	public int leerIntTeclado(String mens) {
		boolean seguir;
		String resultado;
		do {
			seguir = false;
			System.out.println(mens);
			resultado = "";
			try {
				InputStreamReader fr = new InputStreamReader(System.in);
				BufferedReader br = new BufferedReader(fr);
				resultado = br.readLine();
				for (int i = 0; i < resultado.length(); i++) {
					if (!(Character.isDigit(resultado.charAt(i)))) {
						seguir = true;
						break;
					}
				}
			}
			catch (IOException e) {
				e.printStackTrace();
			}

			if (seguir) System.out.println("El valor introducido no es un numero entero. Pruebe de nuevo.");

		} while (seguir);
		return Integer.parseInt(resultado);
	} // fin leerIntTeclado

	// *********************************************************** validarDNI
	public boolean validarDNI(String dniAComprobar) {

		int clave = 0;
		boolean valido;

		// Creo un array de char con las posibles letras del dni, en cada posicion
		char[] letrasDelDni = {
		        'T', 'R', 'W', 'A', 'G', 'M', 'Y', 'F', 'P', 'D', 'X', 'B', 'N', 'J', 'Z', 'S', 'Q', 'V', 'H',
		        'L', 'C', 'K', 'E'
		};

		// existen dnis con 7 u 6 digitos, rellenamos con ceros a la izda
		if (dniAComprobar.length() == 8) {
			dniAComprobar = "0" + dniAComprobar;
		}
		else if (dniAComprobar.length() == 7) {
			dniAComprobar = "00" + dniAComprobar;
		}

		// en total han de ser 9 caracteres
		if (dniAComprobar.length() != 9) return false;

		// lo ultimo ha de ser una letra
		if (!Character.isLetter(dniAComprobar.charAt(8))) return false;

		// Compruebo que lo 8 primeros digitos sean numeros
		for (int i = 0; i < 8; i++) {
			if (!Character.isDigit(dniAComprobar.charAt(i))) return false;
		}

		// calculo la posición de la letra en el array que corresponde a este dni segun el numero del mismo
		clave = Integer.parseInt(dniAComprobar.substring(0, 8)) % 23;

		// verifico que la letra del dni corresponde con la del array
		if ((Character.toUpperCase(dniAComprobar.charAt(8))) != letrasDelDni[clave]) return false;

		return true;
	} // fin validarDNI

	public int diferenciaEnAnosEntreDates(Date fechaMayor, Date fechaMenor) {
		long diferenciaEnMilisegs = fechaMayor.getTime() - fechaMenor.getTime();
		long dias = diferenciaEnMilisegs / (1000 * 60 * 60 * 24);
		return (int) (dias / 356) - 1;
	}

	// *********************************************************** esUnNumero
	public boolean esUnNumero(String strDato) {
		boolean res = true;
		for (int i = 0; i < strDato.length(); i++) {
			if (!(Character.isDigit(strDato.charAt(i)))) {
				res = false;
				break;
			}
		}
		return res;
	}

	// *********************************************************** leerBooleanTeclado
	public boolean leerBooleanTeclado(String mens) {
		boolean seguir;
		Boolean resultado;
		String res;
		do {
			seguir = false;
			System.out.println(mens);
			resultado = null;
			try {
				InputStreamReader fr = new InputStreamReader(System.in);
				BufferedReader br = new BufferedReader(fr);
				res = br.readLine();
				if (res.equalsIgnoreCase("SI") || res.equalsIgnoreCase("S") || res.equalsIgnoreCase("TRUE")) {
					resultado = true;
				}
				else if (res.equalsIgnoreCase("NO") || res.equalsIgnoreCase("N")
				        || res.equalsIgnoreCase("FALSE")) {
					resultado = false;
				}
				else {
					seguir = true;
				}
			}
			catch (IOException e) {
				e.printStackTrace();
			}

			if (seguir) System.out.println(
			        "El valor introducido no es un valor booleano (SI,NO,FALSE,TRUE,S,N). Pruebe de nuevo.");

		} while (seguir);

		return resultado;
	} // fin leerBooleanTeclad

	public String rellenarConBlancos(String cadenaARellenar, int tamano) {
		String resultado;
		int cuantos = tamano - cadenaARellenar.length();
		if (cuantos < 1 || tamano < 1) return cadenaARellenar;
		if (cadenaARellenar.length() > tamano) return cadenaARellenar.substring(tamano);
		resultado = cadenaARellenar;
		for (int i = 0; i < cuantos; i++) {
			resultado = resultado + " ";
		}
		return resultado;
	}

	public String leerStringDeFileBinario(DataInputStream di, int tamano) throws IOException {
		String bloqueleido = "";
		for (int i = 0; i < tamano; i++) {
			char c = (char) di.readByte();
			bloqueleido = bloqueleido + c;
		}
		return bloqueleido;
	}

	public String booleanToStringSN(boolean b) {
		return (b ? "S" : "N");
	}

	public boolean StringSNToBoolean(String s) {
		return (s.equals("S"));
	}

	public void ordenarArray(Cliente[] aClientes) {
		// variable auxiliar utilizada para el
		// intercambio de datos en el array
		Cliente aux;

		// recorre todas las posiciones del array
		for (int i = 0; i < aClientes.length; i++) {
			// el segundo for se utiliza para comparar el
			// valor de la posición actual con las siguientes
			for (int j = i + 1; j < aClientes.length; j++) {
				// si uno de los siguientes valores es inferior
				// al actual, procede al intercambio de las
				// posiciones del array
				if (!(aClientes[j] == null) && (aClientes[i] == null)) {
					int g = aClientes[j].getApellidos().compareTo(aClientes[i].getApellidos());
					if (g < 0) {
						aux = aClientes[i];
						aClientes[i] = aClientes[j];
						aClientes[j] = aux;
					}
				}
			}
		}

	}

}
