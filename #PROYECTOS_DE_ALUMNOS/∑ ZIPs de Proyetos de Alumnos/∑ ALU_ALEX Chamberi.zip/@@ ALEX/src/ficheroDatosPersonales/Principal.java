package ficheroDatosPersonales;

public class Principal {

	public static void main(String[] args) {

		ABMC_Clientes abmc_Clientes = new ABMC_Clientes();

		Cliente[] aClientes = new Cliente[100];

		abmc_Clientes.menu(aClientes);

	}

}
