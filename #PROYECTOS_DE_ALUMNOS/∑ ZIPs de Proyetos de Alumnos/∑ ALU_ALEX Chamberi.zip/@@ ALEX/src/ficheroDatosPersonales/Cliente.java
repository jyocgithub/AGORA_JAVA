package ficheroDatosPersonales;

import java.util.Date;

public class Cliente extends DatosPersonales {

	private String	SLaboral;		// Sólo admitirá las siguientes constantes; Desempleado, En activo, No Consta.
	private Date	F_Alta;			// Date, Fecha de alta en el banco.
	private int		Oficina;		// código de la oficina asociada al cliente. Numérico de 6 cifras.
	private boolean	CopiaDNI;		// boolean. Indicar si se ha aportado copia del DNI.
	private boolean	ContratoBanco;	// boolean. Indica si se ha realizado la firma del contrato.
	private String	Observaciones;

	public Cliente(String nombre, String apellidos, int sexo, char[] dNI, Date f_Nac, int edad,
	        String dirección, String población, String provincia, int cP, int teléfono, String correoE,
	        String sLaboral, Date f_Alta, int oficina, boolean copiaDNI, boolean contratoBanco,
	        String observaciones) {
		super(nombre, apellidos, sexo, dNI, f_Nac, edad, dirección, población, provincia, cP, teléfono,
		        correoE);
		SLaboral = sLaboral;
		F_Alta = f_Alta;
		Oficina = oficina;
		CopiaDNI = copiaDNI;
		ContratoBanco = contratoBanco;
		Observaciones = observaciones;
	}

	public String toStringadfc() {
		return SLaboral;
	}

	@Override
	public String toString() {
		return "  Informacion del Cliente: " + super.toString() + ", SLaboral=" + SLaboral + ", F_Alta="
		        + F_Alta + ", Oficina=" + Oficina + ", CopiaDNI="
		        + CopiaDNI + ", ContratoBanco=" + ContratoBanco + ", Observaciones=" + Observaciones + "]";
	}

	public String getSLaboral() {
		return SLaboral;
	}

	public void setSLaboral(String sLaboral) {
		SLaboral = sLaboral;
	}

	public Date getF_Alta() {
		return F_Alta;
	}

	public void setF_Alta(Date f_Alta) {
		F_Alta = f_Alta;
	}

	public int getOficina() {
		return Oficina;
	}

	public void setOficina(int oficina) {
		Oficina = oficina;
	}

	public boolean isCopiaDNI() {
		return CopiaDNI;
	}

	public void setCopiaDNI(boolean copiaDNI) {
		CopiaDNI = copiaDNI;
	}

	public boolean isContratoBanco() {
		return ContratoBanco;
	}

	public void setContratoBanco(boolean contratoBanco) {
		ContratoBanco = contratoBanco;
	}

	public String getObservaciones() {
		return Observaciones;
	}

	public void setObservaciones(String observaciones) {
		Observaciones = observaciones;
	}

}
