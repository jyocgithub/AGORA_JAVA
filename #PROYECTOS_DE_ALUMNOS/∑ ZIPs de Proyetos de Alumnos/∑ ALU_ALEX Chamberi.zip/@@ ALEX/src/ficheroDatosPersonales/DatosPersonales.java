package ficheroDatosPersonales;

import java.util.Arrays;
import java.util.Date;

public class DatosPersonales {

	final static int	HOMBRE	= 1;
	final static int	MUJER	= 2;

	private String		Nombre;
	private String		Apellidos;
	private int			Sexo;		// Constantes (Hombre/Mujer)
	private char[]		DNI;		// Array de caracteres de longitud 9. Hay que controlar que sólo se admiten
	// cifras (A-Z) en la primera o en la segunda posición. Realizar así mismo un
	// método que compruebe y valide la relación numérica con la letra asociada.
	private Date		F_Nac;		// Date (Día, mes y año)
	private int			Edad;		// (Autocalculado a través de la F_Nac)
	private String		Dirección;	// String (Calle y número)
	private String		Población;
	private String		Provincia;
	private int			CP;			// . Int. Controlar que sólo admita valores de 5 cifras.
	private int			Teléfono;	// Numérico de 9 cifras. Controlar que el primer número no sea
	// distinto del rango 9-6 (No podrá empezar por 5, 4, 3 ,2 ,1 o 0)
	private String		CorreoE;	// Controlar formato (identificación @ servidor . com/es/ o el que sea)

	public DatosPersonales(String nombre, String apellidos, int sexo, char[] dNI, Date f_Nac,
	        int edad, String dirección, String población, String provincia, int cP,
	        int teléfono, String correoE) {
		Nombre = nombre;
		Apellidos = apellidos;
		Sexo = sexo;
		DNI = dNI;
		F_Nac = f_Nac;
		Edad = edad;
		Dirección = dirección;
		Población = población;
		Provincia = provincia;
		CP = cP;
		Teléfono = teléfono;
		CorreoE = correoE;
	}

	@Override
	public String toString() {
		return "DatosPersonales: Nombre=" + Nombre + ", Apellidos=" + Apellidos + ", Sexo=" + Sexo + ", DNI="
		        + Arrays.toString(DNI) + ", F_Nac=" + F_Nac + ", Edad=" + Edad + ", Dirección=" + Dirección
		        + ", Población=" + Población + ", Provincia=" + Provincia + ", CP=" + CP + ", Teléfono="
		        + Teléfono + ", CorreoE=" + CorreoE + ".";
	}

	public String getNombre() {
		return Nombre;
	}

	public void setNombre(String nombre) {
		Nombre = nombre;
	}

	public String getApellidos() {
		return Apellidos;
	}

	public void setApellidos(String apellidos) {
		Apellidos = apellidos;
	}

	public int getSexo() {
		return Sexo;
	}

	public void setSexo(int sexo) {
		Sexo = sexo;
	}

	public char[] getDNI() {
		return DNI;
	}

	public void setDNI(char[] dNI) {
		DNI = dNI;
	}

	public Date getF_Nac() {
		return F_Nac;
	}

	public void setF_Nac(Date f_Nac) {
		F_Nac = f_Nac;
	}

	public int getEdad() {
		return Edad;
	}

	public void setEdad(int edad) {
		Edad = edad;
	}

	public String getDirección() {
		return Dirección;
	}

	public void setDirección(String dirección) {
		Dirección = dirección;
	}

	public String getPoblación() {
		return Población;
	}

	public void setPoblación(String población) {
		Población = población;
	}

	public String getProvincia() {
		return Provincia;
	}

	public void setProvincia(String provincia) {
		Provincia = provincia;
	}

	public int getCP() {
		return CP;
	}

	public void setCP(int cP) {
		CP = cP;
	}

	public int getTeléfono() {
		return Teléfono;
	}

	public void setTeléfono(int teléfono) {
		Teléfono = teléfono;
	}

	public String getCorreoE() {
		return CorreoE;
	}

	public void setCorreoE(String correoE) {
		CorreoE = correoE;
	}

	public int getHOMBRE() {
		return HOMBRE;
	}

	public int getMUJER() {
		return MUJER;
	}

}
