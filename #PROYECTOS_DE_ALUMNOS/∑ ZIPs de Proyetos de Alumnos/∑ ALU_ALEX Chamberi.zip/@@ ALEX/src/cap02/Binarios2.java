package cap02;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;

/*
 * Crea una aplicación que pida por teclado una cifra de números aleatorios enteros positivos y la ruta de un fichero.
 * Este fichero contendrá la cantidad de números aleatorios positivos que se ha pedido por teclado.
 * Escribe los números usando DataOutputStream y muestra por pantalla estos números leyéndolos con un DataInputStream.
 * El rango de los números aleatorios estará entre 0 y 100, ambos inclusive.
 * Cada vez que ejecutemos la aplicación añadiremos números al fichero sin borrar los anteriores, es decir,
 * si cuando creo el fichero añado 10 números y después añado otros 10 al mismo, en el fichero habrá 20 números
 * que serán mostrados por pantalla.
 */
public class Binarios2 {

	public static void main(String[] args) {

		int cuantos = Integer.parseInt(leerStringTeclado("Cuantos numeros?"));
		int num[] = new int[cuantos];
		for (int i = 0; i < cuantos; i++) {
			num[i] = intAleatorio(0, 100);
		}
		try {
			File objetofichero1 = new File("numeros.dat");

			FileOutputStream fo;
			fo = new FileOutputStream(objetofichero1, true);
			DataOutputStream dos = new DataOutputStream(fo);
			for (int i = 0; i < cuantos; i++) {
				dos.writeInt(num[i]);
			}
			dos.close();

			FileInputStream fr = new FileInputStream(objetofichero1);
			DataInputStream br = new DataInputStream(fr);

			int tamaño = br.available() / 4;
			for (int i = 0; i < tamaño; i++) {
				System.out.println(br.readInt());
			}
		}
		catch (FileNotFoundException e) {
			System.out.println("Error, fichero no encontrado");
			e.printStackTrace();
		}
		catch (IOException e) {
			System.out.println("Error, fichero no accesible");
			e.printStackTrace();
		}
	}

	public static String leerStringTeclado(String mens) {
		System.out.println(mens);
		String resultado = "";
		try {
			InputStreamReader fr = new InputStreamReader(System.in);
			BufferedReader br = new BufferedReader(fr);
			resultado = br.readLine();
		}
		catch (IOException e) {
			e.printStackTrace();
		}
		return resultado;
	}

	public static int intAleatorio(int min, int max) {
		return (int) (Math.random() * (max - min + 1) + min);
	}

}
