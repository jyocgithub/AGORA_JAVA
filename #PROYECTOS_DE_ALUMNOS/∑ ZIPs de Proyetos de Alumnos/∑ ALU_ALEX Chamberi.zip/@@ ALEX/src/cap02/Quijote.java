package cap02;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class Quijote {

	public static void main(String[] args) {

		File objetofichero1 = new File("Quixote.txt");

		FileReader isr;
		try {
			isr = new FileReader(objetofichero1);
			BufferedReader lector = new BufferedReader(isr);
			String cs = "", csanterior = "", texto = "";
			String finDeLinea = System.getProperty("line.separator");
			char c;
			int indice = 0;
			boolean salir, leermas = true;
			do {

				String bloqueleido = "";
				do {
					c = (char) lector.read();
					bloqueleido = bloqueleido + c;
					csanterior = cs;
					cs = c + "";
					// salir = cs.equals(finDeLinea) && csanterior.equals("\r");
				} while (!cs.equals(finDeLinea) && lector.ready());
				texto += bloqueleido;

				if (texto.startsWith("1 Cervan")) {
					indice = indice;
				}

				if (bloqueleido.equals("\r\n")) {
					// guardamos en nuevo fichero
					File objetoficherosalida = new File("parrafo" + indice + ".txt");
					FileWriter fw = new FileWriter(objetoficherosalida);
					BufferedWriter bw = new BufferedWriter(fw);
					bw.write(texto);
					bw.close();
					System.out.println("-->" + texto);
					indice++;
					texto = "";
				}

			} while (lector.ready());

			lector.close();
		}
		catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		catch (IOException e) {
			e.printStackTrace();
		}
	}

}
