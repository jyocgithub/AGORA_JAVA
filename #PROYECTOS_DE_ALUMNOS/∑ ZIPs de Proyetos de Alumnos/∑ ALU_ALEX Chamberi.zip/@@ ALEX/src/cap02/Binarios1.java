package cap02;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

// Crear una aplicación que copie un fichero binario a otra localización. En lugar de leer y escribir byte a byte,
// crea un array de bytes con el tamaño del fichero de origen (utiliza el método available()), copia el contenido del fichero a
// este array y escribe a partir de este array.
// Recuerda controlar las excepciones que puedan aparecer. Informar de todos los posibles errores a través de consola.

public class Binarios1 {

	public static void main(String[] args) throws IOException {

		File objetofichero1 = new File("agenda.dat");
		File objetofichero2 = new File("agenda.dat");

		FileInputStream fr = new FileInputStream(objetofichero1);

		int tam = (int) objetofichero1.length();
		byte cop[] = new byte[tam];

		fr.read(cop);

		FileOutputStream fo = new FileOutputStream(objetofichero2);
		fo.write(cop);

	}
}
