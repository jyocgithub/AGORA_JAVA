package cap02;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;

/*
 * Crear una aplicación que almacene los datos básicos de un vehículo como la matrícula (String), marca (String), tamaño del
 * depósito (double), combustible (String), potencia del motor (int) y modelo (String), en ese orden y de uno en uno usando la
 * clase DataInputStream.
 * Los datos anteriores se pedirán por teclado y se irán añadiendo al fichero (no se sobrescriben los datos) cada vez que
 * ejecutemos la aplicación.
 * El fichero siempre será el mismo, en todos los casos.
 * Finaliza el programa mostrando los datos incluidos en el fichero, separado por bloques.
 * Utilizar en todo momento los métodos que sean necesarios para la realización del mismo.
 */
public class Binarios3 {

	public static void main(String[] args) {

		String matricula = leerStringTeclado("Marticula?");
		String marca = leerStringTeclado("Marca?");
		double deposito = Double.parseDouble(leerStringTeclado("Tamaño deposito en litros?"));
		String combustible = leerStringTeclado("Combustible?");
		int potencia = Integer.parseInt(leerStringTeclado("Potencia en caballos?"));
		String modelo = leerStringTeclado("Modelo?");
		try {

			File objetofichero1 = new File("coche.dat");
			FileOutputStream fo = new FileOutputStream(objetofichero1, true);
			DataOutputStream dos = new DataOutputStream(fo);

			dos.writeBytes(rellenarConBlancos(matricula, 20));
			dos.writeBytes(rellenarConBlancos(marca, 20));
			dos.writeDouble(deposito);
			dos.writeBytes(rellenarConBlancos(combustible, 20));
			dos.writeInt(potencia);
			dos.writeBytes(rellenarConBlancos(modelo, 20));

			FileInputStream fr = new FileInputStream(objetofichero1);
			DataInputStream br = new DataInputStream(fr);

			matricula = leerStringDeFileBinario(br, 20);
			marca = leerStringDeFileBinario(br, 20);
			deposito = br.readDouble();
			combustible = leerStringDeFileBinario(br, 20);
			potencia = br.readInt();
			modelo = leerStringDeFileBinario(br, 20);

			System.out.println("Matricula :" + matricula);
			System.out.println("marca :" + marca);
			System.out.println("deposito :" + deposito);
			System.out.println("combustible :" + combustible);
			System.out.println("potencia :" + potencia);
			System.out.println("modelo :" + modelo);

		}
		catch (FileNotFoundException e) {
			System.out.println("Error, fichero no encontrado");
			e.printStackTrace();
		}
		catch (IOException e) {
			System.out.println("Error, fichero no accesible");
			e.printStackTrace();
		}
	}

	public static String leerStringTeclado(String mens) {
		System.out.println(mens);
		String resultado = "";
		try {
			InputStreamReader fr = new InputStreamReader(System.in);
			BufferedReader br = new BufferedReader(fr);
			resultado = br.readLine();
		}
		catch (IOException e) {
			e.printStackTrace();
		}
		return resultado;
	}

	public static int intAleatorio(int min, int max) {
		return (int) (Math.random() * (max - min + 1) + min);
	}

	public static String rellenarConBlancos(String cadenaARellenar, int tamano) {
		String resultado;
		int cuantos = tamano - cadenaARellenar.length();
		if (cuantos < 1 || tamano < 1) return cadenaARellenar;
		if (cadenaARellenar.length() > tamano) return cadenaARellenar.substring(tamano);
		resultado = cadenaARellenar;
		for (int i = 0; i < cuantos; i++) {
			resultado = resultado + " ";
		}
		return resultado;
	}

	public static String leerStringDeFileBinario(DataInputStream di, int tamano) throws IOException {
		String bloqueleido = "";
		for (int i = 0; i < tamano; i++) {
			char c = (char) di.readByte();
			bloqueleido = bloqueleido + c;
		}
		return bloqueleido;
	}
}
