package paqueteExamenFinal2017;

public class Control {
	public int acabado = 0;

}
