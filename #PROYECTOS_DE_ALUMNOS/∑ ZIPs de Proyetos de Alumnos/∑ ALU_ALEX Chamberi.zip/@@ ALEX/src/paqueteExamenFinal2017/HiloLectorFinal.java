package paqueteExamenFinal2017;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.concurrent.Semaphore;

public class HiloLectorFinal extends Thread {
	private String nombrefich;
	private Semaphore miSemaforo;
	private Semaphore[] semindi;
	private BufferedReader bf;
	private PrintWriter pw;

	public HiloLectorFinal(String nombrefich, Semaphore[] semindi) {
		super();
		this.nombrefich = nombrefich;
		this.semindi = semindi;
	}

	@Override
	public void run() {

		try {
			for (int i = 0; i < semindi.length; i++) {
				semindi[i].acquire();
			}
		} catch (InterruptedException e1) {
			e1.printStackTrace();
		}

		String linea = "";
		File ff = new File(nombrefich);
		if (ff.exists()) {
			try {
				System.out.println(" LINEAS DE FICHERO CONJUNTO ");
				bf = new BufferedReader(new FileReader(nombrefich));

				linea = bf.readLine();
				while (linea != null) {
					System.out.println("----" + linea);
					linea = bf.readLine();
				}

			} catch (IOException e) {
				e.printStackTrace();
			} finally {
				if (bf != null) {
					try {
						bf.close();
					} catch (IOException e) {
						e.printStackTrace();
					}
				}
			}
		} else {
			System.out.println("fichero inexistente");
		}
	}

}