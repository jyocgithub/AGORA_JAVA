package paqueteExamenFinal2017;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.concurrent.Semaphore;

public class HiloLector extends Thread {
	private String nombrefich;
	private Semaphore sema;
	private BufferedReader bf;
	private PrintWriter pw;
	private Semaphore semindividual;

	public HiloLector(String nombrefich, Semaphore semaforo, Semaphore semindividual) {
		super();
		this.nombrefich = nombrefich;
		this.sema = semaforo;
		this.semindividual = semindividual;
	}

	@Override
	public void run() {

		File fi = new File(nombrefich);
		if (fi.exists()) {

			try {
				bf = new BufferedReader(new FileReader(nombrefich));
			} catch (FileNotFoundException e1) {
				e1.printStackTrace();
			}

			String linea = "";

			try {
				semindividual.acquire();

				linea = bf.readLine();
				while (linea != null) {
					sema.acquire();

					System.out.println("Imprimiendo en fichero salida.txt :  " + linea);
					FileOutputStream ff = new FileOutputStream("salida.txt", true);

					pw = new PrintWriter(ff);
					pw.println(linea);
					pw.close();

					sema.release();

					sleep(100);
					linea = bf.readLine();
				}
				semindividual.release();

			} catch (IOException e) {
				e.printStackTrace();
			} catch (InterruptedException e1) {
				e1.printStackTrace();
			} finally {
				if (bf != null) {
					try {
						bf.close();
					} catch (IOException e) {
						e.printStackTrace();
					}
				}
			}
		} else {
			System.out.println("fichero inexistente");
		}
	}

}