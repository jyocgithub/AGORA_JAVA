package paqueteExamenFinal2017;

import java.io.File;
/*
Los datos de ventas de automoviles durante un mes se guardan en un fichero 
de texto por cada provincia.

cada linea de dicho fichero sigue la estructura: 
<marca><fecha_compra><importe>
Se quiere diseñar una infraestructura sofware para imprimir por pantalla todas las 
ventas realizadas en todas las provincias.

Debera aparecer un listado con el formato:
<marca><Fecha_compra><importe>

Dado que se pretende optimizar la recopilacion de los datos se utilizara un hilo por cada fichero.
En nuestro caso supondreomos que tenemos datos de tres provincias por lo que se utilaran tres hilos para recopilar datos.

Se propone utilizar una tabla maestra para almacenar cada uno de los registros que se van leyendo(pueden ser 100 elemnetos)
y se generara un cuarto hilo que sera el encargado de imprimir por pantalla los resultados un vez hayan 
finalizado los hilos anteriores. 

Establecer las medidas de sincronizacion que sean necesarias para evitar colisiones en la carga de la información en la tabla
maestra por parte de cada hilo. 

*/
import java.util.concurrent.Semaphore;

public class Principal {

	final static int NUMPROVINCIAS = 3;

	public static void main(String[] args) {
		Semaphore semaforoComun = new Semaphore(1);
		Semaphore[] semindi = new Semaphore[NUMPROVINCIAS];
		HiloLector h = null;

		File f = new File("salida.txt");
		if (f.exists()) {
			f.delete();
		}

		for (int i = 0; i < NUMPROVINCIAS; i++) {
			semindi[i] = new Semaphore(1);
			h = new HiloLector("ficheroprovincia" + (i + 1) + ".txt", semaforoComun, semindi[i]);
			h.start();
		}

		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		HiloLectorFinal hiloLectorFinal = new HiloLectorFinal("salida.txt", semindi);
		hiloLectorFinal.start();

	}
}
