package proyectoFinal;

import java.util.Date;

enum Parent {
	cercano, lejano;
}

public class Familiar extends Contacto {

	private Parent parentesco;



	public Familiar (String nombre, String apellidos, long telefono, String domicilio, int codpostal, String localidad, Date fechanacimiento,
	        Parent parentesco) {
		super (nombre, apellidos, telefono, domicilio, codpostal, localidad, fechanacimiento);
		this.parentesco = parentesco;
	}



	public Parent getParentesco () {
		return parentesco;
	}



	public void setParentesto (Parent parentesco) {
		this.parentesco = parentesco;
	}





}
