package proyectoFinal;

import java.util.Date;

public class Contacto {


	private String	nombre;
	private String	apellidos;
	private long	telefono;
	private String	domicilio;
	private int		codpostal;
	private String	localidad;
	private Date	fechanacimiento;

	public Contacto (String nombre, String apellidos, long telefono, String domicilio, int codpostal, String localidad, Date fechanacimiento) {
		super ();
		this.nombre = nombre;
		this.apellidos = apellidos;
		this.telefono = telefono;
		this.domicilio = domicilio;
		this.codpostal = codpostal;
		this.localidad = localidad;
		this.fechanacimiento = fechanacimiento;
	}

	public Contacto () {
		super ();
	}

	public String getNombre () {
		return nombre;
	}

	public void setNombre (String nombre) {
		this.nombre = nombre;
	}

	public String getApellidos () {
		return apellidos;
	}

	public void setApellidos (String apellidos) {
		this.apellidos = apellidos;
	}

	public long getTelefono () {
		return telefono;
	}

	public void setTelefono (long telefono) {
		this.telefono = telefono;
	}

	public String getDomicilio () {
		return domicilio;
	}

	public void setDomicilio (String domicilio) {
		this.domicilio = domicilio;
	}

	public int getCodpostal () {
		return codpostal;
	}

	public void setCodpostal (int codpostal) {
		this.codpostal = codpostal;
	}

	public String getLocalidad () {
		return localidad;
	}

	public void setLocalidad (String localidad) {
		this.localidad = localidad;
	}

	public Date getFechanacimiento () {
		return fechanacimiento;
	}

	public void setFechanacimiento (Date fechanacimiento) {
		this.fechanacimiento = fechanacimiento;
	}



	@Override
	public String toString () {
		return "Contacto : nombre=" + nombre + ", apellidos=" + apellidos + ", localidad=" + localidad;
	}






}
