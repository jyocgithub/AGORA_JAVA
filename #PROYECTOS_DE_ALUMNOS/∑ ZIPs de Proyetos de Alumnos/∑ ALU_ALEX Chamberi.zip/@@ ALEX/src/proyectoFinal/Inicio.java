package proyectoFinal;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

public class Inicio {

	Agenda ag = new Agenda ();

	public static void main (String[] args) {
		new Inicio ().menu ();
		;
	}

	public void menu () {

		int opcion = 0;

		do {
			System.out.println ("MENU");
			System.out.println ("1.- Insertar contacto");
			System.out.println ("2.- Eliminar contacto");
			System.out.println ("3.- Consultar todos los contactos");
			System.out.println ("4.- Guardar contacto");
			System.out.println ("5.- Recuperar contacto");
			System.out.println ("0.- Fin");
			opcion = leerIntTeclado ();
			switch (opcion) {
				case 1:
					Contacto ff = solicitarDatosContacto ();
					if (ff != null) ag.insertarContacto (ff);
					else System.out.println ("Contacto duplicado");
					break;
				case 2:
					Contacto tt = solicitarUnContacto ();
					if (tt != null) ag.eliminarContacto (tt);
					else System.out.println ("Contacto inexistente");
					break;
				case 3:
					// ordenar por apellidos
					for (Contacto x : ag.getContactos ()) {
						System.out.println (x);
					}
					break;
				case 4:
					ag.guardarContactos ();
					break;
				case 5:
					ArrayList s = (ArrayList) ag.cargarContactos ();
					if (s == null) System.out.println ("No existe el fichero");
					else ag.setContactos (s);
					break;
			}

		} while (opcion != 0);
	}


	public Contacto solicitarUnContacto () {
		long t = 1;
		do {
			System.out.println ("Indique telefono de contacto (0 para cancelar):");
			t = leerIntTeclado ();
			for (Contacto x : ag.getContactos ()) {
				if (x.getTelefono () == t) { return x; }
			}

		} while (t != 0);
		return null;
	}

	public Contacto solicitarDatosContacto () {

		Contacto c = null;
		int opcion = 0;
		do {
			System.out.println ("MENU ALTA CONTACTO");
			System.out.println ("1.- Familiar");
			System.out.println ("2.- Amigo");
			System.out.println ("0.- Fin");

			opcion = leerIntTeclado ();

		} while (opcion < 0 || opcion > 2);
		if (opcion == 0) return null;

		System.out.println ("Indique Datos del contacto para el alta:");

		System.out.println ("Indique nombre:");
		String n = leerStringTeclado ();
		System.out.println ("Indique apellidos:");
		String a = leerStringTeclado ();
		System.out.println ("Indique telefono:");
		long t = leerIntTeclado ();
		System.out.println ("Indique domicilio:");
		String d = leerStringTeclado ();
		System.out.println ("Indique codigo postal:");
		int p = leerIntTeclado ();
		System.out.println ("Indique localidad:");
		String l = leerStringTeclado ();
		System.out.println ("Indique fechanacimiento:");
		String fe = leerStringTeclado ();
		Date f = null;
		try {
			f = new SimpleDateFormat ("dd/MM/yyyy").parse (fe);
		}
		catch (ParseException e) {
			e.printStackTrace ();
		}

		if (opcion == 1) {
			System.out.println ("Indique parentescto (1- Cercano, 2-Lejano):");
			String pa = leerStringTeclado ();
			Parent par = Parent.cercano;
			if (pa.equals ("2")) {
				par = Parent.lejano;
			}
			c = new Familiar (n, a, t, d, p, l, f, par);
		}
		else {
			System.out.println ("Indique afinidad (de 1 a 5):");
			int af = leerIntTeclado ();
			c = new Amigo (n, a, t, d, p, l, f, af);
		}
		return c;
	}


	// *********************************************************** leerIntTeclado
	public int leerIntTeclado () {
		String resultado;
		resultado = "";
		try {
			InputStreamReader fr = new InputStreamReader (System.in);
			BufferedReader br = new BufferedReader (fr);
			resultado = br.readLine ();
		}
		catch (IOException e) {
			e.printStackTrace ();
		}
		return Integer.parseInt (resultado);
	}

	// *********************************************************** leerStringTeclado
	public String leerStringTeclado () {
		String resultado = "";
		try {
			InputStreamReader fr = new InputStreamReader (System.in);
			BufferedReader br = new BufferedReader (fr);
			resultado = br.readLine ();
		}
		catch (IOException e) {
			e.printStackTrace ();
		}
		return resultado;
	}

}
