package proyectoFinal;

import java.util.Date;

public class Amigo extends Contacto {

	private int afinidad;

	public Amigo (String nombre, String apellidos, long telefono, String domicilio, int codpostal, String localidad, Date fechanacimiento,
	        int afinidad) {
		super (nombre, apellidos, telefono, domicilio, codpostal, localidad, fechanacimiento);
		this.afinidad = afinidad;

	}

	public int getAfinidad () {
		return afinidad;
	}

	public void setAfinidad (int afinidad) {
		this.afinidad = afinidad;
	}


}
