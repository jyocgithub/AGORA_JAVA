package proyectoFinal;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class Agenda {

	private ArrayList<Contacto> contactos = new ArrayList<> ();

	public ArrayList<Contacto> getContactos () {
		return contactos;
	}

	public void setContactos (List<Contacto> contactos) {
		this.contactos = (ArrayList<Contacto>) contactos;
	}

	public boolean insertarContacto (Contacto c) {
		boolean res = true;
		for (Contacto x : contactos) {
			if (x.getTelefono () == c.getTelefono ()) return false;
		}

		contactos.add (c);
		return res;
	}

	public boolean eliminarContacto (Contacto c) {
		if (c == null) return false;
		contactos.remove (c);

		return true;
	}

	public void mostrarTodos () {


	}

	public boolean guardarContactos () {
		boolean res = false;
		File fi = new File ("datos.txt");
		PrintWriter pw = null;
		try {
			if (!fi.exists ()) fi.createNewFile ();
			pw = new PrintWriter (fi);

			pw.println (contactos.size ());

			for (Contacto c : contactos) {
				pw.println (c.getNombre ());
				pw.println (c.getApellidos ());
				pw.println (c.getTelefono ());
				pw.println (c.getDomicilio ());
				pw.println (c.getCodpostal ());
				pw.println (c.getLocalidad ());
				String fechaEnTexto = new SimpleDateFormat ("dd/MM/yyyy").format (c.getFechanacimiento ());
				pw.println (fechaEnTexto);
				if (c instanceof Familiar) {
					pw.println ("FAMILIAR");
					String elparen = ((Familiar) c).getParentesco () == Parent.lejano ? "LEJANO" : "CERCANO";
					pw.println (elparen);
				}
				else {
					pw.println ("AMIGO");
					pw.println ( ((Amigo) c).getAfinidad ());
				}
			}

		}
		catch (IOException e) {
			e.printStackTrace ();
		}
		finally {
			if (pw != null) pw.close ();
		}
		return res;
	}

	public List cargarContactos () {
		File fi = new File ("datos.txt");
		BufferedReader bf = null;
		try {
			if (!fi.exists ()) return null;
			contactos.removeAll (contactos);
			Contacto qq;
			bf = new BufferedReader (new InputStreamReader (new FileInputStream (fi)));
			String nnn = bf.readLine ();
			int num = Integer.parseInt (nnn);
			for (int i = 0; i < num; i++) {

				String no = bf.readLine ();

				String ap = bf.readLine ();
				long te = Long.parseLong (bf.readLine ());
				String dd = bf.readLine ();
				int cp = Integer.parseInt (bf.readLine ());
				String lo = bf.readLine ();
				String fe = bf.readLine ();
				Date fech = new SimpleDateFormat ("dd/MM/yyyy").parse ("21/12/2016");
				String tipo = bf.readLine ();
				String valor = bf.readLine ();
				if (tipo.equals ("FAMILIAR")) {
					Parent par = valor.equals ("LEJANO") ? Parent.lejano : Parent.cercano;
					qq = new Familiar (no, ap, te, dd, cp, lo, fech, par);
				}
				else {
					int afin = Integer.parseInt (valor);
					qq = new Amigo (no, ap, te, dd, cp, lo, fech, afin);
				}
				contactos.add (qq);
			}

		}
		catch (IOException e) {
			e.printStackTrace ();
		}
		catch (ParseException e) {
			e.printStackTrace ();
		}
		finally {
			if (bf != null) try {
				bf.close ();
			}
			catch (IOException e) {
				e.printStackTrace ();
			}
		}
		return contactos;


	}


}
