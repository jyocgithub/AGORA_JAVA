/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rssejercicio;

/**
 *
 * @author Mañana
 */
public class FeedMessage {
	String	tittle;
	String	description;
	String	link;
	String	author;
	String	guid;

	public FeedMessage () {
	}



	public FeedMessage (String tittle, String description, String link, String author, String guid) {
		this.tittle = tittle;
		this.description = description;
		this.link = link;
		this.author = author;
		this.guid = guid;
	}


	public String getTittle () {
		return tittle;
	}

	public void setTittle (String tittle) {
		this.tittle = tittle;
	}

	public String getDescription () {
		return description;
	}

	public void setDescription (String description) {
		this.description = description;
	}

	public String getLink () {
		return link;
	}

	public void setLink (String link) {
		this.link = link;
	}

	public String getAuthor () {
		return author;
	}

	public void setAuthor (String author) {
		this.author = author;
	}

	public String getGuid () {
		return guid;
	}

	public void setGuid (String guid) {
		this.guid = guid;
	}

	@Override
	public String toString () {
		return "FeedMessage: " + "Título:" + tittle + "Descripción: " + description + "\nLink: " + link + "\nAutor: " + author + "\nGuid: " + guid
		        + "\n\n";
	}


}
