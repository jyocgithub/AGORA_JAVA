/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rssejercicio;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Mañana
 */
public class Feed {
	final String			tittle;
	final String			link;
	final String			description;
	final String			language;
	final String			copyright;
	final String			pubDate;

	final List<FeedMessage>	entries	= new ArrayList ();



	public Feed (String tittle, String link, String description, String language, String copyright, String pubDate) {
		this.tittle = tittle;
		this.link = link;
		this.description = description;
		this.language = language;
		this.copyright = copyright;
		this.pubDate = pubDate;
	}

	public String getTittle () {
		return tittle;
	}

	public String getLink () {
		return link;
	}

	public String getDescription () {
		return description;
	}

	public String getLanguage () {
		return language;
	}

	public String getCopyright () {
		return copyright;
	}

	public String getPubDate () {
		return pubDate;
	}

	public List<FeedMessage> getEntries () {
		return entries;
	}

	@Override
	public String toString () {
		return "Cabecera de Feed: " + "\nTítulo: " + tittle + "\nLink: " + link + "\nDescripción: " + description + "\nLenguaje: " + language
		        + "\nCopyright: " + copyright + "\nPub Date: " + pubDate + "\nFeed Message: " + entries;
	}


}
