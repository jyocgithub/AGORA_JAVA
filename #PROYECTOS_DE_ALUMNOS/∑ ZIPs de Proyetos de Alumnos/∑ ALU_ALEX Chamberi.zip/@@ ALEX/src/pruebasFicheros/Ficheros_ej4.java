package pruebasFicheros;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class Ficheros_ej4 {

	public static void main(String[] args) {

		Scanner lector = new Scanner(System.in);

		// Leemos los nombres de los ficheros origen y del directorio destino
		System.out.println("Escriba nombre del fichero 1: ");
		String nombreFichero1 = lector.nextLine();

		System.out.println("Escriba nombre del fichero 2: ");
		String nombreFichero2 = lector.nextLine();

		System.out.println("Escriba una carpeta donde guardar el resultado: ");
		String nombreCarpeta = lector.nextLine();

		// Creamos el nombre del fichero destino con el directorio pasado y los nombres
		// de los otros ficheros. Doy una version normal (la comentada) y otra mejorada:
		// String nombreFicheroDestino = nombreCarpeta+"/"+nombreFichero1+"_"+nombreFichero2;
		String nombreFicheroDestino = nombreCarpeta + File.separator + nombreFichero1 + "_" + nombreFichero2;
		// la linea anterior usa la constante File.separator, para que el programa funcione
		// en cualquier SO ya sea el separador un "/" o un "\"

		// Creamos un objeto de File, que es una referencia a un fichero del ordenador
		// Este objeto no es el fichero en si. Con este objeto (que tiene el nombre del fichero y poco mas)
		// puedo luego crear el fichero físicamente en el disco, renombrarlo, copiarlo preguntar si existe ...
		File objetofichero1 = new File(nombreFichero1);
		File objetofichero2 = new File(nombreFichero2);
		File objetoficheroDestino = new File(nombreFicheroDestino);

		if (!objetofichero1.exists() || !objetofichero2.exists()) {
			System.out.println("Error, no existe alguno de los ficheros");
		}

		// leemos el primer fichero y lo guardamos en un String
		String textoLeidoDelFichero1 = leerDeFichero(objetofichero1);
		// leemos el segundo fichero y lo guardamos en un String
		String textoLeidoDelFichero2 = leerDeFichero(objetofichero2);
		// escribimos en el fichero destino la suma de los dos Strings
		String nuevoTexto = textoLeidoDelFichero1 + textoLeidoDelFichero2;
		escribirEnFichero(objetoficheroDestino, nuevoTexto);
		System.out.println("El contenido del fichero es :");
		System.out.println(nuevoTexto);

	}

	public static void escribirEnFichero(File parametrofichero, String parametroTexto) {
		try {
			FileWriter fr = new FileWriter(parametrofichero);
			BufferedWriter bw = new BufferedWriter(fr);
			bw.write(parametroTexto);
			bw.close();
		}
		catch (IOException e) {
			e.printStackTrace();
		}
	}

	public static String leerDeFichero(File parametrofichero) {
		String resultado = "";
		try {
			FileReader fr = new FileReader(parametrofichero);
			BufferedReader br = new BufferedReader(fr);
			resultado = br.readLine();
		}
		catch (IOException e) {
			e.printStackTrace();
		}
		return resultado;

	}

}
