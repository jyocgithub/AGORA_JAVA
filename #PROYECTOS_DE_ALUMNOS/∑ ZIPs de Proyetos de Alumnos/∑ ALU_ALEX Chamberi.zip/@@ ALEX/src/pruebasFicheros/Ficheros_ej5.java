package pruebasFicheros;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;

public class Ficheros_ej5 {

	public static void main(String[] args) {

		Scanner lector = new Scanner(System.in);

		System.out.println("Escriba nombre del fichero: ");
		String nombreFichero = lector.nextLine();

		// Creamos un objeto de File, que es una referencia a un fichero del ordenador
		// Este objeto no es el fichero en si. Con este objeto (que tiene el nombre del fichero y poco mas)
		// puedo luego crear el fichero físicamente en el disco, renombrarlo, copiarlo preguntar si existe ...
		File objetofichero = new File(nombreFichero);

		try {
			// Miramos si el fichero no existe, y si no existe, lo creamos, y si no, no se hace nada
			// se puede usar el fichero directamente.
			if (!objetofichero.exists()) {
				objetofichero.createNewFile();
			}

			// Llamo al metodo para leer el fichero, que devuelve el numero de linea que tiene

			int numLineas = contarLineasDeFichero(objetofichero);
			// imprimo por pantalla el texto leido
			System.out.println("El contenido del fichero tiene :" + numLineas + " lineas");

		}
		catch (

		IOException ioe) {
			ioe.printStackTrace();
		}
	}

	public static int contarLineasDeFichero(File parametrofichero) {
		int resultado = 0;
		String linea;
		try {
			FileReader fr = new FileReader(parametrofichero);
			BufferedReader br = new BufferedReader(fr);

			linea = br.readLine();
			while (linea != null) {
				resultado++;
				linea = br.readLine();
			}
		}
		catch (IOException e) {
			e.printStackTrace();
		}
		return resultado;
	}
}
