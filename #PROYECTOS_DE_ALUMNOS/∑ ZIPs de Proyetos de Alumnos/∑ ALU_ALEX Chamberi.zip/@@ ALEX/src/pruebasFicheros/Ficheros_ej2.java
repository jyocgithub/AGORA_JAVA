package pruebasFicheros;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class Ficheros_ej2 {

	public static void main(String[] args) {

		Scanner lector = new Scanner(System.in);

		System.out.println("Escriba nombre del fichero: ");
		String nombreFichero = lector.nextLine();

		System.out.println("Escriba texto a incluir en el fichero: ");
		String textoFichero = lector.nextLine();

		// Creamos un objeto de File, que es una referencia a un fichero del ordenador
		// Este objeto no es el fichero en si. Con este objeto (que tiene el nombre del fichero y poco mas)
		// puedo luego crear el fichero físicamente en el disco, renombrarlo, copiarlo preguntar si existe ...
		File objetofichero = new File(nombreFichero);

		try {
			// A partir del objeto File creamos el fichero físicamente
			boolean sePudoCrearFichero = objetofichero.createNewFile();
			if (sePudoCrearFichero) {
				System.out.println("El fichero se ha creado correctamente");

				// llamo al metodo para escribir en el fichero
				escribirEnFichero(objetofichero, textoFichero);
				// llamo al metodo para leer del fichero, y recojo en un String lo que devuelve el método
				// esto es, el texfo del fichero
				String textoLeidoDelFichero = leerDeFichero(objetofichero);
				// imprimo por pantalla el texto leido
				System.out.println("El contenido del fichero es :");
				System.out.println(textoLeidoDelFichero);

			}
			else {
				System.out.println("No ha podido ser creado el fichero");
			}
		}
		catch (IOException ioe) {
			ioe.printStackTrace();
		}
	}

	public static void escribirEnFichero(File parametrofichero, String parametroTexto) {
		try {
			FileWriter fr = new FileWriter(parametrofichero);
			BufferedWriter bw = new BufferedWriter(fr);
			bw.write(parametroTexto);
			bw.close();
		}
		catch (IOException e) {
			e.printStackTrace();
		}
	}

	public static String leerDeFichero(File parametrofichero) {
		String resultado = "";
		try {
			FileReader fr = new FileReader(parametrofichero);
			BufferedReader br = new BufferedReader(fr);
			resultado = br.readLine();
		}
		catch (IOException e) {
			e.printStackTrace();
		}
		return resultado;

	}

}
