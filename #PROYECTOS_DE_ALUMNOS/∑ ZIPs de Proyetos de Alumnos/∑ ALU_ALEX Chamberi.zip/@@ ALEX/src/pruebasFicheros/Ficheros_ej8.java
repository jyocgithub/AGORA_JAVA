package pruebasFicheros;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class Ficheros_ej8 {

	static int a = 0, e = 0, i = 0, o = 0, u = 0;

	public static void main(String[] args) {

		Scanner lector = new Scanner(System.in);

		System.out.println("Escriba nombre del fichero para contarle las vocales: ");
		String nombreFichero = lector.nextLine();

		// Creamos un objeto de File, que es una referencia a un fichero del ordenador
		// Este objeto no es el fichero en si. Con este objeto (que tiene el nombre del fichero y poco mas)
		// puedo luego crear el fichero físicamente en el disco, renombrarlo, copiarlo preguntar si existe ...
		File objetofichero = new File(nombreFichero);

		try {
			// Miramos si el fichero no existe, y si no existe, lo creamos, y si no, no se hace nada
			// se puede usar el fichero directamente.
			if (!objetofichero.exists()) {
				objetofichero.createNewFile();
			}

			// Llamo al metodo para leer del fichero caracter a caracter
			// Recojo en un String lo que devuelve el método, esto es, el texto del fichero
			String textoLeidoDelFichero = leerDeFicheroCharAChar(objetofichero);
			// imprimo por pantalla el texto leido
			System.out.println("El contenido del fichero tiene :");
			System.out.println(a + " apariciones de la letra A");
			System.out.println(e + " apariciones de la letra E");
			System.out.println(i + " apariciones de la letra I");
			System.out.println(o + " apariciones de la letra O");
			System.out.println(u + " apariciones de la letra U");
			System.out.println(textoLeidoDelFichero);
		}
		catch (

		IOException ioe) {
			ioe.printStackTrace();
		}
	}

	public static void escribirEnFichero(File parametrofichero, String parametroTexto) {
		try {
			FileWriter fr = new FileWriter(parametrofichero);
			BufferedWriter bw = new BufferedWriter(fr);
			bw.write(parametroTexto);
			bw.close();
		}
		catch (IOException e) {
			e.printStackTrace();
		}
	}

	public static String leerDeFicheroCharAChar(File parametrofichero) {
		String resultado = "";
		int codDeUnCHar;
		char unChar;
		try {
			FileReader fr = new FileReader(parametrofichero);
			// la linea del bufferedReader no es necesaria pues vamos a leer cher directamente,
			// y so lo puede hacer fr
			// BufferedReader br = new BufferedReader(fr);
			codDeUnCHar = fr.read();
			while (codDeUnCHar != -1) {
				unChar = (char) codDeUnCHar;
				unChar = Character.toUpperCase(unChar);
				switch (unChar) {
					case 'A':
						a++;
						break;
					case 'E':
						e++;
						break;
					case 'I':
						i++;
						break;
					case 'O':
						o++;
						break;
					case 'U':
						u++;
						break;
				}
				codDeUnCHar = fr.read();
			}
		}
		catch (IOException e) {
			e.printStackTrace();
		}
		return resultado;
	}
}
