package pruebasFicheros;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class Ficheros_ej3 {

	public static void main(String[] args) {

		Scanner lector = new Scanner(System.in);

		System.out.println("Escriba nombre del fichero: ");
		String nombreFichero = lector.nextLine();

		System.out.println("Escriba texto a incluir en el fichero: ");
		String textoFichero = lector.nextLine();

		// Creamos un objeto de File, que es una referencia a un fichero del ordenador
		// Este objeto no es el fichero en si. Con este objeto (que tiene el nombre del fichero y poco mas)
		// puedo luego crear el fichero físicamente en el disco, renombrarlo, copiarlo preguntar si existe ...
		File objetofichero = new File(nombreFichero);

		try {
			// Miramos si el fichero no existe, y si no existe, lo creamos, y si no, no se hace nada
			// se puede usar el fichero directamente.
			if (!objetofichero.exists()) {
				objetofichero.createNewFile();
			}

			// Llamo al metodo para escribir en el fichero
			escribirEnFichero(objetofichero, textoFichero);
			// Llamo al metodo para leer del fichero caracter a caracter
			// Recojo en un String lo que devuelve el métod, esto es, el texto del fichero
			String textoLeidoDelFichero = leerDeFicheroCharAChar(objetofichero);
			// imprimo por pantalla el texto leido
			System.out.println("El contenido del fichero es :");
			System.out.println(textoLeidoDelFichero);

		}
		catch (

		IOException ioe) {
			ioe.printStackTrace();
		}
	}

	public static void escribirEnFichero(File parametrofichero, String parametroTexto) {
		try {
			FileWriter fr = new FileWriter(parametrofichero);
			BufferedWriter bw = new BufferedWriter(fr);
			bw.write(parametroTexto);
			bw.close();
		}
		catch (IOException e) {
			e.printStackTrace();
		}
	}

	public static String leerDeFicheroCharAChar(File parametrofichero) {
		String resultado = "";
		int codDeUnCHar;
		char unChar;
		try {
			FileReader fr = new FileReader(parametrofichero);
			// la linea del bufferedReader no es necesaria pues vamos a leer cher directamente,
			// y so lo puede hacer fr
			// BufferedReader br = new BufferedReader(fr);

			codDeUnCHar = fr.read();
			while (codDeUnCHar != -1) {
				if (codDeUnCHar != ' ') {
					resultado += (char) codDeUnCHar;
				}
				codDeUnCHar = fr.read();
			}
		}
		catch (IOException e) {
			e.printStackTrace();
		}
		return resultado;
	}
}
