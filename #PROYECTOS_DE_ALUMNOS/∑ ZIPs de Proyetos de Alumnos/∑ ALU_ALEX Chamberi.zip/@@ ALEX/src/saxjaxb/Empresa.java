/**
 * Clase Empresa, que copntiene los atributos a enviar al xml
 * Entre los atributos hay una lista, que se desea guardar en el XML como 
 * subnivel.
 * 
 * Se indican estas anotaciones para usarse con la clase Marshaller:
 * 1.- ANTES de la declaracion de la clase hay que incluir ;
 *   - XmlRootElement: indica que nombre se usa para agrupar en una etiqueta XML
 *                 los stributos de la clase (de una persona, en este caso)
 *   - XmlType(propOrder   indica el orden en que los atributos se van a mostrar
 *                        en el xml. Deben estar TODOS los atributos de la clase
 * 
 * 2.- DELANTE del metodo get de cada atributo:
 *   - XmlAttribute(name = "xxx") para indicar que el atributo de la clase se 
 *                                tratara como un atributo en en xml
 *   - XmlElement(name = "XXX")  para indicar que el atributo de la clase se 
 *                               tratara como un elemento en en xml 
 *   - XmlElementWrapper(name = "XXX") Se ñade delante del get del atributo que 
 *                                     se va a añadir como subnivel en el XML
 */

package saxjaxb;

import java.util.ArrayList;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@XmlRootElement(name = "NodoPrincipal")
@XmlType(propOrder = {"nombreEmpresa", "numEmpleados", "listaPersonas"})
public class Empresa {
    String nombreEmpresa;
    int numEmpleados;
    ArrayList<Persona> listaPersonas = new ArrayList<>();

    public Empresa() {
    }

    public Empresa(String nombreEmpresa, int numEmpleados) {
        this.nombreEmpresa = nombreEmpresa;
        this.numEmpleados = numEmpleados;
    }
    
    @XmlElementWrapper(name = "NodoListaDePersonas")
    @XmlElement(name = "NodoDeCadaPersona")
    public ArrayList<Persona> getListaPersonas() {
        return listaPersonas;
    }


    @XmlElement(name="nombreEmpresa")
    public String getNombreEmpresa() {
        return nombreEmpresa;
    }
    
    @XmlElement(name="nunEmpleados")
    public int getNumEmpleados() {
        return numEmpleados;
    }    
    
}
