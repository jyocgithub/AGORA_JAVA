/**
 * Clase Persona, que es el contenido de una lista, lista que es un atributo 
 * de la clase Empresa, que se desea guardar en XML
 * 
 * Se indican estas anotaciones para usarse con la clase Marshaller:
 * 1.- ANTES de la declaracion de la clase hay que incluir ;
 *   - XmlRootElement: indica que nombre se usa para agrupar en una etiqueta XML
 *                 los stributos de la clase (de una persona, en este caso)
 *   - XmlType(propOrder   indica el orden en que los atributos se van a mostrar
 *                        en el xml. Deben estar TODOS los atributos de la clase
 * 
 * 2.- DELANTE del metodo get de cada atributo:
 *   - XmlAttribute(name = "xxx") para indicar que el atributo de la clase se 
 *                                tratara como un atributo en en xml
 *   - XmlElement(name = "XXX")  para indicar que el atributo de la clase se 
 *                               tratara como un elemento en en xml 
 */

package saxjaxb;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

// 
@XmlRootElement(name = "Persona")
@XmlType(propOrder = {"nif", "nombre", "telefono"})
public class Persona {

    private String nif;
    private String nombre;
    private int telefono;

    public Persona(){
        
    }
    public Persona(String nif, String nombre, int telefono) {
        this.nif = nif;
        this.nombre = nombre;
        this.telefono = telefono;
    }

    @XmlAttribute(name = "nif")
    public String getNif() {
        return nif;
    }

    public void setNif(String nif) {
        this.nif = nif;
    }

    @XmlElement(name = "nombre")
    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    @XmlElement(name = "telefono")
    public int getTelefono() {
        return telefono;
    }

    public void setTelefono(int telefono) {
        this.telefono = telefono;
    }
    

}
