package saxjaxb;
/**
 * CREACION DE FICHEROS XML A TRAVES DE UNA OBJETO JAVA
 * Se puede crfea un fichero xml a traves de los atributos que tiene un 
 * objeto Java. 
 * 
 * El obeto que se va a exporta a XML siempre ha de ser de creacion propia, 
 * pues hay que incluir en el anotaciones, con lo que no se puede usar una 
 * clase JSE, como por ejemplo ArrayList, pues no se pueden añadir anotaciones 
 * en el codigo de esta clase. 
 * 
 * En este ejercicio se va a exportar la clase Empresa, que tiene varios 
 * atributos, uno de los cuales ademas es una lista de Personas, que saldran 
 * agrupadas en subniveles del xml
 * 
 * Ante nada hay que importar varias clases que se ven en los ejemplos
 * 
 * El funcionamiento se basa en meter etiquetas en la clases cuyos atributos 
 * se van a exportar, y en una llamada al objeto de esa clase a exportar, 
 * llamada que se explica en este fichero
 * 
 */

import java.io.FileWriter;
import java.io.IOException;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;

public class Principal {

    public static void main(String[] args) throws IOException {

        try {
            // La clase que vamos a exportar a un xml es Empresa
            // Creamos un objeto de la clase y añadimos varios objetos al 
            // arrayList que contiene (el arrayList almacena objetos Persona)
            Empresa emp = new Empresa("Tuberias Lopez SL", 23);
            emp.getListaPersonas().add(new Persona ("Luis", "42323432A", 982382882));
            emp.getListaPersonas().add(new Persona ("Carlos", "332554352B", 938388923));
            emp.getListaPersonas().add(new Persona ("Pedro", "77347366C", 917738822));

            // Se crea un objeto de la clase JAXBContext con el metodo 
            // newInsrance a quien se pasa por parámetro la clase cuyos atributos
            // se van a exportar. El parámetro es el atributo .class de la clase
            JAXBContext objContext = JAXBContext.newInstance(Empresa.class);
            
            // Se crea un objeto Marshaller, y se le asigna el resultado de coger
            // el objeto JAXBContext que acabamos de crea, aplicandole el 
            // metodo .createMarshaller()
            Marshaller objMarsh = objContext.createMarshaller();

            // Este objejo marshaller tiene un metodo llamado marshal, que 
            // recibe como parametros:
            // - el objeto de Empresa que queremos exportar
            // - un objeto FileWriter con el nombre del fichero xml a crear
            // Este metodo crea directaemnte el fichero XML
            objMarsh.marshal(emp, new FileWriter("EmpresaIMS.xml"));
                         
        } catch (JAXBException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }
}
/*
 * FICHERO RESULTANTE DE LA EJECUCION DEL EJERCICIO:
<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<NodoPrincipal>
    <nombreEmpresa>Tuberias Lopez SL</nombreEmpresa>
    <nunEmpleados>23</nunEmpleados>
    <NodoListaDePersonas>
        <NodoDeCadaPersona nif="Luis">
            <nombre>42323432A</nombre>
            <telefono>982382882</telefono>
        </NodoDeCadaPersona>
        <NodoDeCadaPersona nif="Carlos">
            <nombre>332554352B</nombre>
            <telefono>938388923</telefono>
        </NodoDeCadaPersona>
        <NodoDeCadaPersona nif="Pedro">
            <nombre>77347366C</nombre>
            <telefono>917738822</telefono>
        </NodoDeCadaPersona>
    </NodoListaDePersonas>
</NodoPrincipal>
 */