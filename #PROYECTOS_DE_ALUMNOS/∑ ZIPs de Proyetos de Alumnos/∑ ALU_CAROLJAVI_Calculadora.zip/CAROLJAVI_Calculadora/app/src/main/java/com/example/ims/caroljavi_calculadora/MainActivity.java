package com.example.ims.caroljavi_calculadora;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    TextView tvArriba;
    double op1 = 0;
    double op2 = 0;
    double op2Ant;
    String operacion = "", operacionPrevia = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tvArriba = findViewById(R.id.tvCalculadora);
    }


    public void onClickOperacion(View view) {

        operacion = ((Button) view).getText().toString();
        op1 = Double.parseDouble(tvArriba.getText().toString());
        tvArriba.setText("0");

    }

    public void onClickPonerNumero(View view) {
        String x = ((Button) view).getText().toString();

        String panel = tvArriba.getText().toString();

        tvArriba.setText(panel + x);
    }


    public void onClickResta(View view) {
    }

    public void onClickBorrar(View view) {
        String res = tvArriba.getText().toString();
        if (!res.equals("")) {
            res = res.substring(0, res.length() - 1);
            tvArriba.setText(res.toString());
        }
    }

    public void onClickBorrarTodo(View view) {
        tvArriba.setText("0");
    }

    public void onClickIgual(View view) {

        double op2 = Double.parseDouble(tvArriba.getText().toString());
        if (operacion.equals("")) {
            op1 = op2Ant;
            operacion = operacionPrevia;
        } else {

            op2Ant = op2;
        }

        double resultado = 0;

        switch (operacion) {
            case "+":
                resultado = op1 + op2;
                break;
            case "-":
                resultado = op1 - op2;
                break;
            case "*":
                resultado = op1 * op2;
                break;
            case "/":
                resultado = op1 / op2;
                break;
        }

        operacionPrevia = operacion;
        operacion = "";


        String pintar = resultado + "";
        if (pintar.endsWith(".0")) {
            int r = (int) resultado;
            tvArriba.setText(r + "");
        } else {
            tvArriba.setText(pintar);
        }


    }

    public void onClickPonerDecimal(View view) {
    }


}
