package comecocos;

import com.sun.javafx.logging.Logger;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.logging.Level;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

/**
 *
 * @author alfre
 */
public class Inicio extends Comecocos {
    
    @Override
    public void start(Stage ini) throws FileNotFoundException {
        //declaro un contenedor para gestionar los espacios del frame
        VBox contenedor = new VBox();
        //contenedro de puntos
        HBox h_img = new HBox(); 
        
        //contenedor de boton jugar
        HBox h_boton = new HBox();
        
        //el boton te da acceso a jugar 
        Button btn = new Button("  JUGAR    ");
        btn.setPrefSize(250, 50);
        
        //me creo una instancia para obtener el panel principal
        FileInputStream fondo = new FileInputStream("img/inicio.jpg");
        Image img = new Image(fondo, 550, 300, false, false);
        ImageView pac = new ImageView(img);
        
        //añadiendo a los hbox la imagen de inicio y el boton jugar 
        h_img.getChildren().add(pac);
        h_boton.getChildren().add(btn);
        h_boton.setAlignment(Pos.CENTER);
        
       //añadir los hbox al contenedor vbox
       contenedor.getChildren().add(h_img);
       contenedor.getChildren().add(h_boton);
       
        StackPane principal = new StackPane();

        principal.getChildren().add(contenedor);
       

        Scene scene = new Scene(principal);

        ini.setTitle("   INICIO  ");

        //tenemos que decirle a la pantalla que tiene que mostrar
        ini.setScene(scene);

        //Sirve para mostrar nuestra primera pantalla
        ini.show();

 //       Creamos el evento del boton
        btn.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent e) {
               ini.close();
               Comecocos  ta = new Comecocos();
                try {
                    ta.start(ini);
                } catch (FileNotFoundException ex) {
                    //error 
                }
            }
        });
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        // me aseguro que las tablas estan creadas
        BBDD bbdd = new BBDD();
        bbdd.altaTablas();
        
        launch(args);
    }
    
}
