
package comecocos;

import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.ArrayList;


public class BBDD {
    
    
    String conexionDB = "jdbc:mysql://localhost:3306/";  // esto es para usar MySql
    String nombreBD = "pacman";  // aqui viene el nombre de la base de datos
    String usuarioDB = "root";  // usuariode bbdd
    String passwordDB = "";   // pwd de la bbdd
    String opcionesBD = "";  // opcional
    Connection miConexion;

    /**
     * CONECTAR
     * Establece una conexion a la bbdd y la asigna al atributo conexion
     * Usa los atributos antes indicados para configurar correctamente la conexion
     */
    public void conectar() {
        try {
            miConexion = DriverManager.getConnection(conexionDB + nombreBD + opcionesBD, usuarioDB, passwordDB);
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    /**
     * DESCONECTAR
     */
    public void desconectar() {
        try {
            miConexion.close();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

//    /**
//     * Devuelve el valor máximo de un campo de una tabla
//     * Se puede usar para saber el valor maximo de una clave cuando no es autoincremental
//     * y se necesita saber la proximo clave a insertar
//     * @return
//     */
//    public int getMaxId() {
//        try {
//            conectar();
//            String sql = "SELECT max(id_peli) FROM records";
//            ResultSet rs = miConexion.createStatement().executeQuery(sql);
//            rs.next();
//            return rs.getInt(1);
//        } catch (Exception e) {
//            return 0;
//        } finally {
//            desconectar();
//        }
//    }
    /**
     * @return
     */
    public void altaTablas() {
        String sqlCrearTablaPelicula = "CREATE TABLE IF NOT EXISTS records ( "
                + "idrecord int  AUTO_INCREMENT,  "
                + "puntuacion int , "
                + "fecha DATE , "
                + "PRIMARY KEY (idrecord))";

        conectar();
        try {
            Statement instruccion = miConexion.createStatement();
            instruccion.execute(sqlCrearTablaPelicula);
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
        desconectar();
        }
    }

    public void insertarRecord(int puntuacion) {
        conectar();
        try {
            String sql = "INSERT INTO records  VALUES ( 0,?,sysdate() )  ";

            PreparedStatement instruccion = miConexion.prepareStatement(sql);
            instruccion.setInt(1, puntuacion);
            instruccion.executeUpdate();

        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            desconectar();
        }
    }

    public ArrayList<Record> leerRecords() {
        conectar();

        ArrayList<Record> lista = new ArrayList<>();
        try {
            String sql = "SELECT * FROM records order by puntuacion desc limit 5 ";

            PreparedStatement instruccion = miConexion.prepareStatement(sql);

            ResultSet registros = instruccion.executeQuery();

            while (registros.next()) {
                int puntuacion = registros.getInt("puntuacion");
                Date fecha = registros.getDate("fecha");
        

                Record nuevo = new Record(puntuacion,  dateToString(fecha,null));

                lista.add(nuevo);
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            desconectar();
        }
        return lista;
    }
    
    public Record leerultimoregistro() {
        conectar();

        
        try {
            String sql = "SELECT * FROM records order by idrecord desc limit 1";

            PreparedStatement instruccion = miConexion.prepareStatement(sql);

            ResultSet registros = instruccion.executeQuery();

            while (registros.next()) {
                int puntuacion = registros.getInt("puntuacion");
                Date fecha = registros.getDate("fecha");
        

                Record nuevo = new Record(puntuacion, dateToString(fecha,null));

                return nuevo;
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            desconectar();
        }
        return null;
    }

    
       public static String dateToString(Date fechaEnDate, String formato) {
        if (fechaEnDate == null) {
            return null;
        }
        if (formato == null) {
            formato = "dd/MM/yyyy";
        }
        SimpleDateFormat miFormato = new SimpleDateFormat(formato);
        String fechaEnString = miFormato.format(fechaEnDate);
        return fechaEnString;
    }
      
//    /**
//     * @param codigobuscado
//     * @return
//     */
//    public ArrayList<Pelicula> consultarUnaPelicula(int codigobuscado) {
//        conectar();
//
//        ArrayList<Pelicula> peliculas = new ArrayList<>();
//        try {
//            String sql = "SELECT * FROM PELICULA WHERE COD_PELI  = ? ";
//
//            PreparedStatement instruccion = miConexion.prepareStatement(sql);
//            instruccion.setInt(1, codigobuscado);
//
//            ResultSet registros = instruccion.executeQuery();
//
//            while (registros.next()) {
//                int cod = registros.getInt("cod_peli");
//                String titulo = registros.getString("titulo");
//                // no es necesario convertir de java.sql.Date a java.util.Date
//                Date fechaestreno = registros.getDate("fechaestreno");
//
//                Pelicula nuevaPelicula = new Pelicula(cod, titulo, fechaestreno);
//
//                peliculas.add(nuevaPelicula);
//
//            }
//
//        } catch (SQLException ex) {
//            ex.printStackTrace();
//        } finally {
//            desconectar();
//
//        }
//        return peliculas;
//    }
//
//    /**
//     * @param codigobuscado
//     * @return
//     */
//    public boolean borrarUnaPeliculas(int codigobuscado) {
//        conectar();
//
//        Pelicula pelicula = null;
//        try {
//            String sql = "DELETE FROM PELICULA WHERE COD_PELI = ? ";
//
//            PreparedStatement instruccion = miConexion.prepareStatement(sql);
//            instruccion.setInt(1, codigobuscado);
//
//            int f = instruccion.executeUpdate();
//            if (f == 1) {
//
//                return true;
//            }
//        } catch (SQLException ex) {
//            ex.printStackTrace();
//        } finally {
//            desconectar();
//        }
//        return false;
//    }
//
//
//    /**
//     * public void modificarUnaPelicula(guias_java.Pelicula miPelicula) {
//     *
//     * @param miPelicula
//     */
//    public void modificarUnaPelicula(Pelicula miPelicula) {
//        conectar();
//        try {
//            String sql = "UPDATE PELICULA SET titulo=?, FECHAESTRENO=?  ";
//
//            PreparedStatement instruccion = miConexion.prepareStatement(sql);
//            instruccion.setString(1, miPelicula.getTitulo());
//
//            java.util.Date fechautil = miPelicula.getFechaestreno();
//            java.sql.Date fechasql = dateUTILtoSQL(fechautil);
//            instruccion.setDate(2, fechasql);
//
//            instruccion.executeUpdate();
//
//        } catch (SQLException ex) {
//            ex.printStackTrace();
//        } finally {
//            desconectar();
//        }
//    }


//   /**
//     * Convierte un objerto DATE-JAVA al correspondiente DATE-SQL
//     * Se necesita para guardar en una bbdd un campo DATE de java
//     * La operacion inversa (guardar un objeto DATE-SQL en un DATE-JAVA) no es necesaria, 
//     * hace un casting automatico, no hace fatla hacer nada
//     * @return
//     */
//    public static java.sql.Date dateUTILtoSQL(java.util.Date fechaEnUtil) {
//        if (fechaEnUtil == null) {
//            return null;
//        }
//        java.sql.Date fechaEnSql = null;
//        fechaEnSql = new java.sql.Date(fechaEnUtil.getTime());
//        return fechaEnSql;
//    }
    
}
