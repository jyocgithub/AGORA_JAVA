package comecocos;

import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.Timer;
import java.util.TimerTask;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyCode;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.stage.Stage;

/**
 *
 * @author fp
 */
public class Comecocos extends Application {

    ArrayList bolaPeq = new ArrayList();//esto lo usaré para almacenar cada bolita a fin de comprobar coincidencias
    ArrayList bolaGrande = new ArrayList();

    int contpuntos = 0;//declaro una contador de puntos que me servirá para cuando el pacman  se coma una bolita
    int movimientos = 0;//contador de movimientos me servirá cuando el pac se coma la bola azul
    int contvidas = 0;//vidas de nuestro pacman

    //vidas del pacman 
    int vida = 3;

    //creando las coordenadas donde se moveran cada fantasma: siendo: 0 arriba, 1 abajo, 2 izquierda, 3 derecha.
    int[] fntRojo = new int[]{2, 2, 2, 2, 2, 0, 0, 0, 0, 3, 3, 3, 3, 3, 3, 1, 1, 1, 1, 2, 2};
    int[] fntAzul = new int[]{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 2, 2, 1, 1, 1, 1, 3, 3, 3, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1};
    int[] fntRosa = new int[]{2, 2, 2, 0, 0, 2, 2, 2, 2, 3, 3, 3, 3, 3, 3, 3, 1, 1, 1};

    //variables que controlan los movimientos del panel:
    int mvRojo = 0;
    int mvAzul = 0;
    int mvRosa = 0;

    //timer nos sirve para calcular el tiempo en la escena que se moveran nuestro pacman 
    TimerTask tiempoAzul = null;
    TimerTask tiempoRojo = null;
    TimerTask tiempoRosa = null;

    boolean vulnerable = false;

    ImageView fRojo, fAzul, fRosa, vulnerable1, vulnerable2, vulnerable3, pl, pr, imvGrande;
    Image azul, rojo, rosa, imVulnerable1, imVulnerable2, imVulnerable3, pacIzq;
    Label ver_puntos, vidas;

    Stage prueba;
    Image img, imGrande, ng;
    GridPane tabla;

    /**
     * Metodo que permite mover el pacman, mover las bolitas y asignar las
     * puntuaciones por bolitas comida
     *
     * @param prueba
     * @throws FileNotFoundException
     */
    @Override
    public void start(Stage prueba) throws FileNotFoundException {
        //Me declaro un vbox contenedor. donde voy a introducir la tabla y la puntuacion
        VBox contenedor = new VBox();
        HBox h_punts = new HBox(); //contenedro de puntos
        HBox h_tab = new HBox();  //contenedro de tabla  
        HBox h_boton = new HBox();
        this.prueba = prueba;

        //   Button bter = new Button("Terminar partida");
        //Añadimos el panel
        tabla = new GridPane();
        FileInputStream fondo = new FileInputStream("img/punto.png");
        FileInputStream negro = new FileInputStream("img/negro.png");
        FileInputStream izquierda = new FileInputStream("img/pacmanLeft.gif");
        FileInputStream derecha = new FileInputStream("img/pacmanRight.gif");
        FileInputStream arriba = new FileInputStream("img/pacmanUp.gif");
        FileInputStream abajo = new FileInputStream("img/pacmanDown.gif");
        FileInputStream fantRojo = new FileInputStream("img/rojo.gif");
        FileInputStream fantAzul = new FileInputStream("img/claro.gif");

        FileInputStream fantRosa = new FileInputStream("img/rosa.gif");
        FileInputStream grande = new FileInputStream("img/puntoGrande.png");//bolita grand

        //creando el fantasmas bulnerable
        FileInputStream vuln1 = new FileInputStream("img/azul.gif");
        FileInputStream vuln2 = new FileInputStream("img/azul.gif");
        FileInputStream vuln3 = new FileInputStream("img/azul.gif");

        //creando imagenes de nuestro proyecto
        imVulnerable1 = new Image(vuln1, 40, 40, false, false);
        imVulnerable2 = new Image(vuln2, 40, 40, false, false);
        imVulnerable3 = new Image(vuln3, 40, 40, false, false);

        imGrande = new Image(grande, 40, 40, false, false);
        img = new Image(fondo, 40, 40, false, false);
        azul = new Image(fantAzul, 40, 40, false, false);
        ng = new Image(negro, 40, 40, false, false);
        pacIzq = new Image(izquierda, 40, 40, false, false);
        Image pacderecha = new Image(derecha, 40, 40, false, false);
        Image pacarriba = new Image(arriba, 40, 40, false, false);
        Image pacabajo = new Image(abajo, 40, 40, false, false);
        rojo = new Image(fantRojo, 40, 40, false, false);
        rosa = new Image(fantRosa, 40, 40, false, false);

        pl = new ImageView(pacIzq);//pacman 
        pr = new ImageView(pacIzq);//pacman derecha
        imvGrande = new ImageView(imGrande);
        fRojo = new ImageView(rojo);
        fAzul = new ImageView(azul);
        fRosa = new ImageView(rosa);

        vulnerable1 = new ImageView(imVulnerable1);
        vulnerable2 = new ImageView(imVulnerable2);
        vulnerable3 = new ImageView(imVulnerable3);

        ImageView imgnegro = new ImageView(ng);
        ImageView imgvista;
        ImageView pacIzquierda;

        rellenartabla();

        //añado una etiqueta donde almaceno los puntos   
        ver_puntos = new Label("\tPuntuacion: " + contpuntos);

        //añadiendo etiqueta vidas
        vidas = new Label("\t\t\tvidas: " + vida);

        //dentro del v_punts introduzco la puntuacion
        h_punts.getChildren().add(ver_puntos);

        //añadiendo vidas
        h_punts.getChildren().add(vidas);

        //dentro del contenedor introduzco el tablero        
        h_tab.getChildren().add(tabla);

        //  h_boton.getChildren().add(bter);//ingreso nuesto boton al hbox
        //  h_boton.setAlignment(Pos.CENTER);
        //dentro del contenedor introduzco el h_tab , h_punts  y hbton
        contenedor.getChildren().add(h_punts);
        contenedor.getChildren().add(h_tab);
        // contenedor.getChildren().add(h_boton);

        //acciones
        StackPane principal = new StackPane();

        principal.getChildren().add(contenedor);

        //Añadimos el boton y el tamaño de la ventana
        Scene scene = new Scene(principal);

//        //implementando el boton terminar
//        bter.setOnAction(new EventHandler<ActionEvent>() {
//            @Override
//            public void handle(ActionEvent event) {
//
//                //   Fin terminar = new Fin();
//                //  terminar.setVisible(true);
//                //  this.dispose();
//                //  System.out.println("Guardando resultado");
//                //cargando los puntos en el fichero
//                try {
//                    FileOutputStream outputStream = new FileOutputStream("puntuacion.txt", true);
//                    OutputStreamWriter outputStreamWriter = new OutputStreamWriter(outputStream, "UTF-8");
//                    BufferedWriter bufferedWriter = new BufferedWriter(outputStreamWriter);
//
//                    bufferedWriter.write("total puntos: " + contpuntos);
//                    bufferedWriter.newLine();
//
//                    bufferedWriter.close();
//                } catch (IOException e) {
//                    e.printStackTrace();
//                }
//            }
//
//            private void dispose() {
//                throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
//            }
//        });
        //activamos los movimientos de accion con las fechas direccionales
        scene.setOnKeyPressed(e -> {

            if (e.getCode() == KeyCode.UP) {
                String nodo = getNodeFromGridPane(tabla, GridPane.getColumnIndex(pl), GridPane.getRowIndex(pl) - 1).toString();

                if (!nodo.startsWith("Rectangle")) {

                    ImageView imgaux = (ImageView) getNodeFromGridPane(tabla, GridPane.getColumnIndex(pl), GridPane.getRowIndex(pl) - 1);
                    imgaux.setImage(ng);//insertamos una imagen negra si se come la bolita
                    GridPane.setRowIndex(pl, GridPane.getRowIndex(pl) - 1);
                    pl.setImage(pacarriba);
                    System.out.println("arriba");
                    analizarNuevaPosicion(nodo, GridPane.getColumnIndex(pl), GridPane.getRowIndex(pl));
                }

            } else if (e.getCode() == KeyCode.DOWN) {//creamos iteraccion con la tecla hacia abajo asi mover el pacman
                String nodo = getNodeFromGridPane(tabla, GridPane.getColumnIndex(pl), GridPane.getRowIndex(pl) + 1).toString();
                if (!nodo.startsWith("Rectangle")) {//si la direccion a donde se mueve comienza con Rectangle no se mueve 

                    ImageView imgaux = (ImageView) getNodeFromGridPane(tabla, GridPane.getColumnIndex(pl), GridPane.getRowIndex(pl) + 1);
                    imgaux.setImage(ng);//insertamos una imagen negra si se come la bolita
                    GridPane.setRowIndex(pl, GridPane.getRowIndex(pl) + 1);
                    pl.setImage(pacabajo);
                    analizarNuevaPosicion(nodo, GridPane.getColumnIndex(pl), GridPane.getRowIndex(pl));
                }

            } else if (e.getCode() == KeyCode.RIGHT) {
                if (GridPane.getColumnIndex(pl) == 18) {
                  if ((GridPane.getRowIndex(pl) == 9) && (GridPane.getColumnIndex(pl) == 18)) {
                        String nodo = getNodeFromGridPane(tabla, 0, GridPane.getRowIndex(pl)).toString();
                        // me salgo a la izda
                        ImageView imgaux = (ImageView) getNodeFromGridPane(tabla, GridPane.getColumnIndex(pl), GridPane.getRowIndex(pl));
                        imgaux.setImage(ng);//insertamos una imagen negra si se come la bolita
                        GridPane.setColumnIndex(pl, 0);
//                    pl.setImage(pacIzq);
                        analizarNuevaPosicion(nodo, GridPane.getColumnIndex(pl), GridPane.getRowIndex(pl));

                    }
                } else {
                    String nodo = getNodeFromGridPane(tabla, GridPane.getColumnIndex(pl) + 1, GridPane.getRowIndex(pl)).toString();

                    if (!nodo.startsWith("Rectangle")) {

                        ImageView imgaux = (ImageView) getNodeFromGridPane(tabla, GridPane.getColumnIndex(pl) + 1, GridPane.getRowIndex(pl));
                        imgaux.setImage(ng);//insertamos una imagen negra si se come la bolita
                        GridPane.setColumnIndex(pl, GridPane.getColumnIndex(pl) + 1);
                        pl.setImage(pacderecha);
                        analizarNuevaPosicion(nodo, GridPane.getColumnIndex(pl), GridPane.getRowIndex(pl));
                    }
                }

            } else if (e.getCode() == KeyCode.LEFT) {

                if (GridPane.getColumnIndex(pl) == 0) {
                    if ((GridPane.getRowIndex(pl) == 9) && (GridPane.getColumnIndex(pl) == 0)) {
                        String nodo = getNodeFromGridPane(tabla, 18, GridPane.getRowIndex(pl)).toString();
                        // me salgo a la izda
                        ImageView imgaux = (ImageView) getNodeFromGridPane(tabla, GridPane.getColumnIndex(pl) , GridPane.getRowIndex(pl));
                        imgaux.setImage(ng);//insertamos una imagen negra si se come la bolita
                        GridPane.setColumnIndex(pl, 18);
//                    pl.setImage(pacIzq);
                        analizarNuevaPosicion(nodo, GridPane.getColumnIndex(pl), GridPane.getRowIndex(pl));

                    }
                } else {
                    String nodo = getNodeFromGridPane(tabla, GridPane.getColumnIndex(pl) - 1, GridPane.getRowIndex(pl)).toString();

                    if ((GridPane.getRowIndex(pl) == 9) && (GridPane.getColumnIndex(pl) == 0)) {
                        // me salgo a la izda
                        ImageView imgaux = (ImageView) getNodeFromGridPane(tabla, GridPane.getColumnIndex(pl) - 1, GridPane.getRowIndex(pl));
                        imgaux.setImage(ng);//insertamos una imagen negra si se come la bolita
                        GridPane.setColumnIndex(pl, 18);
//                    pl.setImage(pacIzq);
                        analizarNuevaPosicion(nodo, GridPane.getColumnIndex(pl), GridPane.getRowIndex(pl));

                    } else {

                        if (!nodo.startsWith("Rectangle")) {//si la direccion a donde se mueve comienza con Rectangle no se mueve 

                            ImageView imgaux = (ImageView) getNodeFromGridPane(tabla, GridPane.getColumnIndex(pl) - 1, GridPane.getRowIndex(pl));
                            imgaux.setImage(ng);//insertamos una imagen negra si se come la bolita
                            GridPane.setColumnIndex(pl, GridPane.getColumnIndex(pl) - 1);
                            pl.setImage(pacIzq);
                            analizarNuevaPosicion(nodo, GridPane.getColumnIndex(pl), GridPane.getRowIndex(pl));
                        }
                    }
                }

            }
        });

        //si hemos comido toda las bolas detenemos el movimiento de los fantasmas
        if (bolaPeq.size() == 210) {
            tiempoAzul.cancel();
            tiempoRojo.cancel();
            tiempoRosa.cancel();

            //insertarmos la puntuacion 
            //guardo la puntuacion obtenida en el fichero
            try {
                FileOutputStream outputStream = new FileOutputStream("puntuacion.txt", true);
                OutputStreamWriter outputStreamWriter = new OutputStreamWriter(outputStream, "UTF-8");
                BufferedWriter bufferedWriter = new BufferedWriter(outputStreamWriter);

                bufferedWriter.write("total puntos: " + contpuntos);
                bufferedWriter.newLine();

                bufferedWriter.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
            //pasamos a la ventana de fin
        }
        //llamo a los movimientos
        mover_rojo(fRojo, rojo, tabla, pacIzq, pl, vidas, ver_puntos);
        mover_azul(fAzul, azul, tabla, pacIzq, pl, vidas, ver_puntos);
        mover_rosa(fRosa, rosa, tabla, pacIzq, pl, vidas, ver_puntos);

        //Le pasamos el titulo a nuestra primera pantalla
        prueba.setTitle("COME COCOS!");

        //tenemos que decirle a la pantalla que tiene que mostrar
        prueba.setScene(scene);

        //Sirve para mostrar nuestra primera pantalla
        prueba.show();
    }
    //me creo metodos para mover los fantasmas 1 metodo por cada fantasma

    public void fin() {
        try {

            // GUARDO RECORD ACTUAL
            BBDD bbdd = new BBDD();
            bbdd.insertarRecord(contpuntos);

            // cancelo los timers que mueven los fantasmas
            tiempoRojo.cancel();
            tiempoAzul.cancel();
            tiempoRosa.cancel();

            Stage s = new Stage();
            Fin f = new Fin();
            f.start(s);

            prueba.close();

        } catch (FileNotFoundException ex) {
            Logger.getLogger(Comecocos.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    /**
     * Medodo para mover el fantasma el cual obtiene la posicion y valida si es
     * una pared o no y así realiza el movimiento en la coordenadas del array
     * especificado en la parte superior
     *
     * @param fRojo
     * @param rojo
     * @param tabla
     * @param pacIzq
     * @param pl
     * @param vidas
     * @param ver_puntos
     */
    //no le paso el pac
    public void mover_rojo(ImageView fRojo, Image rojo, GridPane tabla, Image pacIzq, ImageView pl, Label vidas, Label ver_puntos) {//    
        Timer myTimer = new Timer();
        tiempoRojo = new TimerTask() {
            @Override
            public void run() {
                Platform.runLater(() -> {
                    int num = fntRojo[mvRojo];//en cada iteracion toma un indice distinto  hasta final array

                    switch (num) {
                        case 0: {
                            String nodo = getNodeFromGridPane(tabla, GridPane.getColumnIndex(fRojo), GridPane.getRowIndex(fRojo) - 1).toString();
                            if (nodo.startsWith("Rectangle")) {//si la direccion a donde se mueve comienza con Rectangle no se mueve
                                System.out.println("no te puedes mover");

                            } else {
                                GridPane.setRowIndex(fRojo, GridPane.getRowIndex(fRojo) - 1);
                                mvRojo++;
                                System.out.println(nodo);
                                if (mvRojo == fntRojo.length - 1) {//cuando llegue al final del array
                                    mvRojo = 0;//vuelta a empezar
                                }

                            }
                            break;
                        }
                        case 1: {
                            String nodo = getNodeFromGridPane(tabla, GridPane.getColumnIndex(fRojo), GridPane.getRowIndex(fRojo) + 1).toString();
                            if (nodo.startsWith("Rectangle")) {//si la direccion a donde se mueve comienza con Rectangle no se mueve
                                System.out.println("no te puedes mover");

                            } else {
                                GridPane.setRowIndex(fRojo, GridPane.getRowIndex(fRojo) + 1);
                                mvRojo++;
                                System.out.println(nodo);
                                if (mvRojo == fntRojo.length - 1) {
                                    mvRojo = 0;
                                }

                            }
                            break;
                        }
                        case 2: {
                            String nodo = getNodeFromGridPane(tabla, GridPane.getColumnIndex(fRojo) - 1, GridPane.getRowIndex(fRojo)).toString();
                            if (nodo.startsWith("Rectangle")) {//si la direccion a donde se mueve comienza con Rectangle no se mueve
                                System.out.println("no te puedes mover");

                            } else {
                                GridPane.setColumnIndex(fRojo, GridPane.getColumnIndex(fRojo) - 1);
                                mvRojo++;
                                System.out.println(nodo);
                                if (mvRojo == fntRojo.length - 1) {
                                    mvRojo = 0;
                                }
                            }
                            break;
                        }
                        case 3: {
                            String nodo = getNodeFromGridPane(tabla, GridPane.getColumnIndex(fRojo) + 1, GridPane.getRowIndex(fRojo)).toString();
                            if (nodo.startsWith("Rectangle")) {//si la direccion a donde se mueve comienza con Rectangle no se mueve
                                System.out.println("no te puedes mover");

                            } else {
                                System.out.println(nodo);
                                GridPane.setColumnIndex(fRojo, GridPane.getColumnIndex(fRojo) + 1);
                                mvRojo++;
                                if (mvRojo == fntRojo.length - 1) {
                                    mvRojo = 0;
                                }

                            }
                            break;
                        }
                    }

                    analizarChoques(fRojo, "Rojo");

                }
                );
            }
        };
        myTimer.scheduleAtFixedRate(tiempoRojo, 0, 200);//tiempo estimado para recorrrer
    }

    /**
     * Medodo para mover el fantasma el cual obtiene la posicion y valida si es
     * una pared o no y así realiza el movimiento en la coordenadas del array
     * especificado en la parte superior
     *
     * @param fAzul
     * @param azul
     * @param tabla
     * @param pacIzq
     * @param pl
     * @param vidas
     * @param ver_puntos
     */
    public void mover_azul(ImageView fAzul, Image azul, GridPane tabla, Image pacIzq, ImageView pl, Label vidas, Label ver_puntos) { //    
        Timer myTimer = new Timer();
        tiempoAzul = new TimerTask() {
            @Override
            public void run() {
                Platform.runLater(() -> {
                    int num = fntAzul[mvAzul];

                    switch (num) {
                        case 0: {
                            String nodo = getNodeFromGridPane(tabla, GridPane.getColumnIndex(fAzul), GridPane.getRowIndex(fAzul) - 1).toString();
                            if (nodo.startsWith("Rectangle")) {//si la direccion a donde se mueve comienza con Rectangle no se mueve
                                System.out.println("no te puedes mover");

                            } else {
                                GridPane.setRowIndex(fAzul, GridPane.getRowIndex(fAzul) - 1);
                                mvAzul++;
                                System.out.println(nodo);
                                if (mvAzul == fntAzul.length - 1) {
                                    mvAzul = 0;
                                }

                            }
                            break;
                        }
                        case 1: {
                            String nodo = getNodeFromGridPane(tabla, GridPane.getColumnIndex(fAzul), GridPane.getRowIndex(fAzul) + 1).toString();
                            if (nodo.startsWith("Rectangle")) {//si la direccion a donde se mueve comienza con Rectangle no se mueve
                                System.out.println("no te puedes mover");

                            } else {
                                GridPane.setRowIndex(fAzul, GridPane.getRowIndex(fAzul) + 1);
                                mvAzul++;
                                System.out.println(nodo);
                                if (mvAzul == fntAzul.length - 1) {
                                    mvAzul = 0;
                                }

                            }
                            break;
                        }
                        case 2: {
                            String nodo = getNodeFromGridPane(tabla, GridPane.getColumnIndex(fAzul) - 1, GridPane.getRowIndex(fAzul)).toString();
                            if (nodo.startsWith("Rectangle")) {//si la direccion a donde se mueve comienza con Rectangle no se mueve
                                System.out.println("no te puedes mover");
                            } else {
                                GridPane.setColumnIndex(fAzul, GridPane.getColumnIndex(fAzul) - 1);
                                mvAzul++;
                                System.out.println(nodo);
                                if (mvAzul == fntAzul.length - 1) {
                                    mvAzul = 0;
                                }
                            }
                            break;
                        }
                        case 3: {
                            String nodo = getNodeFromGridPane(tabla, GridPane.getColumnIndex(fAzul) + 1, GridPane.getRowIndex(fAzul)).toString();
                            if (nodo.startsWith("Rectangle")) {//si la direccion a donde se mueve comienza con Rectangle no se mueve
                                System.out.println("no te puedes mover");

                            } else {
                                System.out.println(nodo);
                                GridPane.setColumnIndex(fAzul, GridPane.getColumnIndex(fAzul) + 1);
                                mvAzul++;
                                if (mvAzul == fntAzul.length - 1) {
                                    mvAzul = 0;
                                }

                            }
                            break;
                        }
                    }

                    analizarChoques(fAzul, "Azul");

                }
                );
            }
        };
        myTimer.scheduleAtFixedRate(tiempoAzul, 0, 200);//tiempo estimado para recorrrer
    }

    /**
     * Medodo para mover el fantasma el cual obtiene la posicion y valida si es
     * una pared o no y así realiza el movimiento en la coordenadas del array
     * especificado en la parte superior
     *
     * @param fRosa
     * @param rosa
     * @param tabla
     * @param pacIzq
     * @param pl
     * @param vidas
     * @param ver_puntos
     */
    public void mover_rosa(ImageView fRosa, Image rosa, GridPane tabla, Image pacIzq, ImageView pl, Label vidas, Label ver_puntos) { //    
        Timer myTimer = new Timer();
        tiempoRosa = new TimerTask() {
            @Override
            public void run() {
                Platform.runLater(() -> {
                    int num = fntRosa[mvRosa];

                    switch (num) {
                        case 0: {
                            String nodo = getNodeFromGridPane(tabla, GridPane.getColumnIndex(fRosa), GridPane.getRowIndex(fRosa) - 1).toString();
                            if (nodo.startsWith("Rectangle")) {//si la direccion a donde se mueve comienza con Rectangle no se mueve
                                System.out.println("no te puedes mover");

                            } else {
                                GridPane.setRowIndex(fRosa, GridPane.getRowIndex(fRosa) - 1);
                                mvRosa++;
                                System.out.println(nodo);
                                if (mvRosa == fntRosa.length - 1) {//cuando llegue al final del array
                                    mvRosa = 0;//vuelta a empezar
                                }

                            }
                            break;
                        }
                        case 1: {
                            String nodo = getNodeFromGridPane(tabla, GridPane.getColumnIndex(fRosa), GridPane.getRowIndex(fRosa) + 1).toString();
                            if (nodo.startsWith("Rectangle")) {//si la direccion a donde se mueve comienza con Rectangle no se mueve
                                System.out.println("no te puedes mover");

                            } else {
                                GridPane.setRowIndex(fRosa, GridPane.getRowIndex(fRosa) + 1);
                                mvRosa++;
                                System.out.println(nodo);
                                if (mvRosa == fntRosa.length - 1) {
                                    mvRosa = 0;
                                }

                            }
                            break;
                        }
                        case 2: {
                            String nodo = getNodeFromGridPane(tabla, GridPane.getColumnIndex(fRosa) - 1, GridPane.getRowIndex(fRosa)).toString();
                            if (nodo.startsWith("Rectangle")) {//si la direccion a donde se mueve comienza con Rectangle no se mueve
                                System.out.println("no te puedes mover");

                            } else {
                                GridPane.setColumnIndex(fRosa, GridPane.getColumnIndex(fRosa) - 1);
                                mvRosa++;
                                System.out.println(nodo);
                                if (mvRosa == fntRosa.length - 1) {
                                    mvRosa = 0;
                                }
                            }
                            break;
                        }
                        case 3: {
                            String nodo = getNodeFromGridPane(tabla, GridPane.getColumnIndex(fRosa) + 1, GridPane.getRowIndex(fRosa)).toString();
                            if (nodo.startsWith("Rectangle")) {//si la direccion a donde se mueve comienza con Rectangle no se mueve
                                System.out.println("no te puedes mover");

                            } else {
                                System.out.println(nodo);
                                GridPane.setColumnIndex(fRosa, GridPane.getColumnIndex(fRosa) + 1);
                                mvRosa++;
                                if (mvRosa == fntRosa.length - 1) {
                                    mvRosa = 0;
                                }

                            }
                            break;
                        }
                    }
                    analizarChoques(fRosa, "Rosa");

                }
                );
            }
        };
        myTimer.scheduleAtFixedRate(tiempoRosa, 0, 200);//tiempo estimado para recorrrer
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }

    /**
     * Funcion para coger el elemento de una posicion mediante las variables
     * filas y columnas
     *
     * @param tabla
     * @param col
     * @param row
     * @return
     */
    public static Node getNodeFromGridPane(GridPane tabla, int col, int row) {
        for (Node node : tabla.getChildren()) {
            if (GridPane.getColumnIndex(node) == col && GridPane.getRowIndex(node) == row) {
                return node;
            }
        }
        return null;
    }

    public void analizarNuevaPosicion(String nodo, int col, int fil) {
        if (nodo.startsWith("Rectangle")) {//si la direccion a donde se mueve comienza con Rectangle no se mueve
            System.out.println("no te puedes mover");

        } else {
            String posicionactual = col + ":" + fil;
            // SI PASO POR UN PUNTO GORDO
            if ((GridPane.getRowIndex(pl) == 2) && (GridPane.getColumnIndex(pl) == 1)
                    || (GridPane.getRowIndex(pl) == 18) && (GridPane.getColumnIndex(pl) == 1)
                    || (GridPane.getRowIndex(pl) == 2) && (GridPane.getColumnIndex(pl) == 17)
                    || (GridPane.getRowIndex(pl) == 18) && (GridPane.getColumnIndex(pl) == 17)) {

                if (bolaGrande.contains(posicionactual)) {
                    // paso por bola gorda pero ya pase antes
                } else {
                    // paso por bola gorda pero NO pase antes
                    bolaGrande.add(posicionactual);
                    System.out.println("100 puntos");
                    contpuntos += 100;

                    vulnerable = true;
                    movimientos = 0;
                    fAzul.setImage(imVulnerable1);
                    fRojo.setImage(imVulnerable2);
                    fRosa.setImage(imVulnerable3);
                    movimientos += 1;
                }

                // SI PASO POR UN SITIO NEGRO
            } else if (bolaPeq.contains(posicionactual)) {

                // SI PASO POR UN PUNTO     
            } else {

                bolaPeq.add(posicionactual);
                contpuntos += 5;
            }

            if (vulnerable == true) {
                if (movimientos < 20) {
                    movimientos += 1;
                } else {
                    movimientos = 0;
                    System.out.println("TERMINANDO VULNERABILIDAD");
                    fAzul.setImage(azul);
                    fRojo.setImage(rojo);
                    fRosa.setImage(rosa);
                    vulnerable = false;
                }
            }
            ver_puntos.setText("\tPuntuacion: " + contpuntos + " Bolas comidas " + bolaPeq.size());//recibo la puntuacion

        }

        // SI PACMAN SE COMIO TODAS LAS BOLAS PEQUEÑAS
        if (bolaPeq.size() >= 181) {
            tiempoAzul.cancel();
            tiempoRojo.cancel();
            tiempoRosa.cancel();

            //insertarmos la puntuacion 
            //guardo la puntuacion obtenida en el fichero
            try {
                FileOutputStream outputStream = new FileOutputStream("puntuacion.txt", true);
                OutputStreamWriter outputStreamWriter = new OutputStreamWriter(outputStream, "UTF-8");
                BufferedWriter bufferedWriter = new BufferedWriter(outputStreamWriter);

                bufferedWriter.write("total puntos: " + contpuntos);
                bufferedWriter.newLine();

                bufferedWriter.close();
            } catch (IOException e) {
                e.printStackTrace();
            }

            //pasamos a la ventana de fin
            ver_puntos.setText("\tPuntuacion: " + contpuntos + " Bolas comidas " + bolaPeq.size() + " FIN ! ");//recibo la puntuacion
            fin();
        }

    }

    public void analizarChoques(ImageView imagendelfantasma, String color) {
        //control de vidas dependiendo de si el fanttasma come ala pacman o el pacman come al fantasma
        // PACMAN Y FANTSAMA SE ENCUENTRAN
        if (((GridPane.getColumnIndex(pl)) == (GridPane.getColumnIndex(imagendelfantasma))) && ((GridPane.getRowIndex(pl)) == (GridPane.getRowIndex(imagendelfantasma)))) {

            if (vulnerable == false) {
                //=========================  AQUI FANTASMA MATA A PACMAN
                vida--;
                //reflejamos las vidas
                vidas.setText("\t\t\tvidas: " + vida);
                if (vida == 0) {
                    tiempoAzul.cancel();
                    tiempoRojo.cancel();
                    tiempoRosa.cancel();
                    System.out.println(bolaPeq.size());//imprimo la cantidad de nodos para saber el total de nodos

                    //cargando los puntos en el fichero
                    try {
                        FileOutputStream outputStream = new FileOutputStream("puntuacion.txt", true);
                        OutputStreamWriter outputStreamWriter = new OutputStreamWriter(outputStream, "UTF-8");
                        BufferedWriter bufferedWriter = new BufferedWriter(outputStreamWriter);

                        bufferedWriter.write("total puntos: " + contpuntos);
                        bufferedWriter.newLine();

                        bufferedWriter.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }

                    ver_puntos.setText("\tPuntuacion: " + contpuntos + " Bolas comidas " + bolaPeq.size() + " FIN ! ");//recibo la puntuacion
                    fin();

                }
                //cada vida perdida regresa al pacman a la posición inicial
                GridPane.setColumnIndex(pl, 9);
                GridPane.setRowIndex(pl, 15);
                pl.setImage(pacIzq);
            } else {
                //=========================  AQUI PACMAN MATA A FANTASMA
                if (color.equalsIgnoreCase("Rosa")) {
                    tiempoRosa.cancel();
                    GridPane.setRowIndex(fRosa, 0);
                    GridPane.setColumnIndex(fRosa, 0);
                }
                if (color.equalsIgnoreCase("Azul")) {
                    tiempoAzul.cancel();
                    GridPane.setRowIndex(fAzul, 0);
                    GridPane.setColumnIndex(fAzul, 1);
                }
                if (color.equalsIgnoreCase("Rojo")) {
                    tiempoRojo.cancel();
                    GridPane.setRowIndex(fRojo, 0);
                    GridPane.setColumnIndex(fRojo, 2);
                }
                contpuntos += 1000;
                ver_puntos.setText("\tPuntuacion: " + contpuntos);//recibo la puntuacion
            }

        }

    }

    public void rellenartabla() {
        //Añadimos otro rectangulo de forma completa
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 0, 0);
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 1, 0);
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 2, 0);
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 3, 0);
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 4, 0);
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 5, 0);
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 6, 0);
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 7, 0);
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 8, 0);
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 9, 0);
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 10, 0);
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 11, 0);
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 12, 0);
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 13, 0);
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 14, 0);
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 15, 0);
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 16, 0);
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 17, 0);
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 18, 0);

        //Fila 1
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 0, 1);
        tabla.add(new ImageView(img), 1, 1);
        tabla.add(new ImageView(img), 2, 1);
        tabla.add(new ImageView(img), 3, 1);
        tabla.add(new ImageView(img), 4, 1);
        tabla.add(new ImageView(img), 5, 1);
        tabla.add(new ImageView(img), 6, 1);
        tabla.add(new ImageView(img), 7, 1);
        tabla.add(new ImageView(img), 8, 1);
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 9, 1);
        tabla.add(new ImageView(img), 10, 1);
        tabla.add(new ImageView(img), 11, 1);
        tabla.add(new ImageView(img), 12, 1);
        tabla.add(new ImageView(img), 13, 1);
        tabla.add(new ImageView(img), 14, 1);
        tabla.add(new ImageView(img), 15, 1);
        tabla.add(new ImageView(img), 16, 1);
        tabla.add(new ImageView(img), 17, 1);
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 18, 1);

        //fila 2
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 0, 2);
        tabla.add(new ImageView(imGrande), 1, 2);
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 2, 2);
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 3, 2);
        tabla.add(new ImageView(img), 4, 2);
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 5, 2);
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 6, 2);
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 7, 2);
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 8, 2);
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 9, 2);
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 10, 2);
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 11, 2);
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 12, 2);
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 13, 2);
        tabla.add(new ImageView(img), 14, 2);
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 15, 2);
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 16, 2);
        tabla.add(new ImageView(imGrande), 17, 2);
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 18, 2);

        //FILA 3
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 0, 3);
        tabla.add(new ImageView(img), 1, 3);
        tabla.add(new ImageView(img), 2, 3);
        tabla.add(new ImageView(img), 3, 3);
        tabla.add(new ImageView(img), 4, 3);
        tabla.add(new ImageView(img), 5, 3);
        tabla.add(new ImageView(img), 6, 3);
        tabla.add(new ImageView(img), 7, 3);
        tabla.add(new ImageView(img), 8, 3);
        tabla.add(new ImageView(img), 9, 3);
        tabla.add(new ImageView(img), 10, 3);
        tabla.add(new ImageView(img), 11, 3);
        tabla.add(new ImageView(img), 12, 3);
        tabla.add(new ImageView(img), 13, 3);
        tabla.add(new ImageView(img), 14, 3);
        tabla.add(new ImageView(img), 15, 3);
        tabla.add(new ImageView(img), 16, 3);
        tabla.add(new ImageView(img), 17, 3);
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 18, 3);
        tabla.add(fRosa, 17, 3);

        //fila 4
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 0, 4);
        tabla.add(new ImageView(img), 1, 4);
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 2, 4);
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 3, 4);
        tabla.add(new ImageView(img), 4, 4);
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 5, 4);
        tabla.add(new ImageView(img), 6, 4);
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 7, 4);
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 8, 4);
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 9, 4);
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 10, 4);
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 11, 4);
        tabla.add(new ImageView(img), 12, 4);
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 13, 4);
        tabla.add(new ImageView(img), 14, 4);
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 15, 4);
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 16, 4);
        tabla.add(new ImageView(img), 17, 4);
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 18, 4);

        //FILA 5
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 0, 5);
        tabla.add(new ImageView(img), 1, 5);
        tabla.add(new ImageView(img), 2, 5);
        tabla.add(new ImageView(img), 3, 5);
        tabla.add(new ImageView(img), 4, 5);
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 5, 5);
        tabla.add(new ImageView(img), 6, 5);
        tabla.add(new ImageView(img), 7, 5);
        tabla.add(new ImageView(img), 8, 5);
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 9, 5);
        tabla.add(new ImageView(img), 10, 5);
        tabla.add(new ImageView(img), 11, 5);
        tabla.add(new ImageView(img), 12, 5);
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 13, 5);
        tabla.add(new ImageView(img), 14, 5);
        tabla.add(new ImageView(img), 15, 5);
        tabla.add(new ImageView(img), 16, 5);
        tabla.add(new ImageView(img), 17, 5);
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 18, 5);

        //fila 6
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 0, 6);
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 1, 6);
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 2, 6);
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 3, 6);
        tabla.add(new ImageView(img), 4, 6);
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 5, 6);
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 6, 6);
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 7, 6);
        tabla.add(new ImageView(img), 8, 6);
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 9, 6);
        tabla.add(new ImageView(img), 10, 6);
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 11, 6);
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 12, 6);
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 13, 6);
        tabla.add(new ImageView(img), 14, 6);
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 15, 6);
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 16, 6);
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 17, 6);
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 18, 6);

        //fila 7
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 0, 7);
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 1, 7);
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 2, 7);
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 3, 7);
        tabla.add(new ImageView(img), 4, 7);
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 5, 7);
        tabla.add(new ImageView(img), 6, 7);
        tabla.add(new ImageView(img), 7, 7);
        tabla.add(new ImageView(img), 8, 7);
        tabla.add(new ImageView(img), 9, 7);
        tabla.add(new ImageView(img), 10, 7);
        tabla.add(new ImageView(img), 11, 7);
        tabla.add(new ImageView(img), 12, 7);
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 13, 7);
        tabla.add(new ImageView(img), 14, 7);
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 15, 7);
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 16, 7);
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 17, 7);
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 18, 7);

        //fila 89
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 0, 8);
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 1, 8);
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 2, 8);
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 3, 8);
        tabla.add(new ImageView(img), 4, 8);
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 5, 8);
        tabla.add(new ImageView(img), 6, 8);
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 7, 8);
        tabla.add(new ImageView(img), 8, 8);
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 9, 8);
        tabla.add(new ImageView(img), 10, 8);
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 11, 8);
        tabla.add(new ImageView(img), 12, 8);
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 13, 8);
        tabla.add(new ImageView(img), 14, 8);
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 15, 8);
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 16, 8);
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 17, 8);
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 18, 8);

        //fila 9
        tabla.add(new ImageView(ng), 0, 9);
        tabla.add(new ImageView(img), 1, 9);
        tabla.add(new ImageView(img), 2, 9);
        tabla.add(new ImageView(img), 3, 9);
        tabla.add(new ImageView(img), 4, 9);
        tabla.add(new ImageView(img), 5, 9);
        tabla.add(new ImageView(img), 6, 9);
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 7, 9);
        tabla.add(new ImageView(img), 8, 9);
        tabla.add(new ImageView(img), 9, 9);
        tabla.add(new ImageView(img), 10, 9);
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 11, 9);
        tabla.add(new ImageView(img), 12, 9);
        tabla.add(new ImageView(img), 13, 9);
        tabla.add(new ImageView(img), 14, 9);
        tabla.add(new ImageView(img), 15, 9);
        tabla.add(new ImageView(img), 16, 9);
        tabla.add(new ImageView(img), 17, 9);
        tabla.add(new ImageView(ng), 18, 9);

        //fila 10
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 0, 10);
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 1, 10);
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 2, 10);
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 3, 10);
        tabla.add(new ImageView(img), 4, 10);
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 5, 10);
        tabla.add(new ImageView(img), 6, 10);
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 7, 10);
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 8, 10);
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 9, 10);
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 10, 10);
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 11, 10);
        tabla.add(new ImageView(img), 12, 10);
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 13, 10);
        tabla.add(new ImageView(img), 14, 10);
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 15, 10);
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 16, 10);
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 17, 10);
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 18, 10);

        //fila 11
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 0, 11);
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 1, 11);
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 2, 11);
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 3, 11);
        tabla.add(new ImageView(img), 4, 11);
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 5, 11);
        tabla.add(new ImageView(img), 6, 11);
        tabla.add(new ImageView(img), 7, 11);
        tabla.add(new ImageView(img), 8, 11);
        tabla.add(new ImageView(img), 9, 11);
        tabla.add(new ImageView(img), 10, 11);
        tabla.add(new ImageView(img), 11, 11);
        tabla.add(new ImageView(img), 12, 11);
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 13, 11);
        tabla.add(new ImageView(img), 14, 11);
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 15, 11);
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 16, 11);
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 17, 11);
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 18, 11);
        tabla.add(fRojo, 11, 11);

        //fila 12
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 0, 12);
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 1, 12);
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 2, 12);
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 3, 12);
        tabla.add(new ImageView(img), 4, 12);
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 5, 12);
        tabla.add(new ImageView(img), 6, 12);
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 7, 12);
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 8, 12);
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 9, 12);
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 10, 12);
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 11, 12);
        tabla.add(new ImageView(img), 12, 12);
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 13, 12);
        tabla.add(new ImageView(img), 14, 12);
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 15, 12);
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 16, 12);
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 17, 12);
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 18, 12);

        //fila 13
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 0, 13);
        tabla.add(new ImageView(img), 1, 13);
        tabla.add(new ImageView(img), 2, 13);
        tabla.add(new ImageView(img), 3, 13);
        tabla.add(new ImageView(img), 4, 13);
        tabla.add(new ImageView(img), 5, 13);
        tabla.add(new ImageView(img), 6, 13);
        tabla.add(new ImageView(img), 7, 13);
        tabla.add(new ImageView(img), 8, 13);
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 9, 13);
        tabla.add(new ImageView(img), 10, 13);
        tabla.add(new ImageView(img), 11, 13);
        tabla.add(new ImageView(img), 12, 13);
        tabla.add(new ImageView(img), 13, 13);
        tabla.add(new ImageView(img), 14, 13);
        tabla.add(new ImageView(img), 15, 13);
        tabla.add(new ImageView(img), 16, 13);
        tabla.add(new ImageView(img), 17, 13);
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 18, 13);

        //fila 14
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 0, 14);
        tabla.add(new ImageView(img), 1, 14);
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 2, 14);
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 3, 14);
        tabla.add(new ImageView(img), 4, 14);
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 5, 14);
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 6, 14);
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 7, 14);
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 8, 14);
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 9, 14);
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 10, 14);
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 11, 14);
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 12, 14);
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 13, 14);
        tabla.add(new ImageView(img), 14, 14);
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 15, 14);
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 16, 14);
        tabla.add(new ImageView(img), 17, 14);
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 18, 14);
        tabla.add(fAzul, 4, 14);

        //fila 15
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 0, 15);
        tabla.add(new ImageView(img), 1, 15);
        tabla.add(new ImageView(img), 2, 15);
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 3, 15);
        tabla.add(new ImageView(img), 4, 15);
        tabla.add(new ImageView(img), 5, 15);
        tabla.add(new ImageView(img), 6, 15);
        tabla.add(new ImageView(img), 7, 15);
        tabla.add(new ImageView(img), 8, 15);
        tabla.add(new ImageView(img), 9, 15);
        tabla.add(new ImageView(img), 10, 15);
        tabla.add(new ImageView(img), 11, 15);
        tabla.add(new ImageView(img), 12, 15);
        tabla.add(new ImageView(img), 13, 15);
        tabla.add(new ImageView(img), 14, 15);
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 15, 15);
        tabla.add(new ImageView(img), 16, 15);
        tabla.add(new ImageView(img), 17, 15);
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 18, 15);

        //fila 16
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 0, 16);
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 1, 16);
        tabla.add(new ImageView(img), 2, 16);
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 3, 16);
        tabla.add(new ImageView(img), 4, 16);
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 5, 16);
        tabla.add(new ImageView(img), 6, 16);
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 7, 16);
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 8, 16);
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 9, 16);
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 10, 16);
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 11, 16);
        tabla.add(new ImageView(img), 12, 16);
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 13, 16);
        tabla.add(new ImageView(img), 14, 16);
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 15, 16);
        tabla.add(new ImageView(img), 16, 16);
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 17, 16);
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 18, 16);

        //fila 17
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 0, 17);
        tabla.add(new ImageView(img), 1, 17);
        tabla.add(new ImageView(img), 2, 17);
        tabla.add(new ImageView(img), 3, 17);
        tabla.add(new ImageView(img), 4, 17);
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 5, 17);
        tabla.add(new ImageView(img), 6, 17);
        tabla.add(new ImageView(img), 7, 17);
        tabla.add(new ImageView(img), 8, 17);
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 9, 17);
        tabla.add(new ImageView(img), 10, 17);
        tabla.add(new ImageView(img), 11, 17);
        tabla.add(new ImageView(img), 12, 17);
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 13, 17);
        tabla.add(new ImageView(img), 14, 17);
        tabla.add(new ImageView(img), 15, 17);
        tabla.add(new ImageView(img), 16, 17);
        tabla.add(new ImageView(img), 17, 17);
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 18, 17);

        //fila 18
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 0, 18);
        tabla.add(new ImageView(imGrande), 1, 18);
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 2, 18);
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 3, 18);
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 4, 18);
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 5, 18);
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 6, 18);
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 7, 18);
        tabla.add(new ImageView(img), 8, 18);
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 9, 18);
        tabla.add(new ImageView(img), 10, 18);
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 11, 18);
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 12, 18);
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 13, 18);
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 14, 18);
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 15, 18);
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 16, 18);
        tabla.add(new ImageView(imGrande), 17, 18);
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 18, 18);

        //fila 19
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 0, 19);
        tabla.add(new ImageView(img), 1, 19);
        tabla.add(new ImageView(img), 2, 19);
        tabla.add(new ImageView(img), 3, 19);
        tabla.add(new ImageView(img), 4, 19);
        tabla.add(new ImageView(img), 5, 19);
        tabla.add(new ImageView(img), 6, 19);
        tabla.add(new ImageView(img), 7, 19);
        tabla.add(new ImageView(img), 8, 19);
        tabla.add(new ImageView(img), 9, 19);
        tabla.add(new ImageView(img), 10, 19);
        tabla.add(new ImageView(img), 11, 19);
        tabla.add(new ImageView(img), 12, 19);
        tabla.add(new ImageView(img), 13, 19);
        tabla.add(new ImageView(img), 14, 19);
        tabla.add(new ImageView(img), 15, 19);
        tabla.add(new ImageView(img), 16, 19);
        tabla.add(new ImageView(img), 17, 19);
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 18, 19);

        //fila 20
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 0, 20);
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 1, 20);
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 2, 20);
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 3, 20);
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 4, 20);
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 5, 20);
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 6, 20);
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 7, 20);
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 8, 20);
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 9, 20);
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 10, 20);
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 11, 20);
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 12, 20);
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 13, 20);
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 14, 20);
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 15, 20);
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 16, 20);
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 17, 20);
        tabla.add(new Rectangle(40, 40, Color.ROYALBLUE), 18, 20);

        //posicion inicial del pacman
        tabla.add(pl, 9, 15);
    }
}
