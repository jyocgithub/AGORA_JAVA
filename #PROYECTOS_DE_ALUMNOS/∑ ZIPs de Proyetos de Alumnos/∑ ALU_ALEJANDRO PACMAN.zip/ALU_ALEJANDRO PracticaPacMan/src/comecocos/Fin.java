/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package comecocos;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.text.TextAlignment;
import javafx.stage.Stage;

/**
 *
 * @author alfre
 */
public class Fin extends Application {

    Label puntos;

    @Override
    public void start(Stage fin) throws FileNotFoundException {
        //declaro un contenedor para gestionar los espacios del frame
        VBox contenedor = new VBox();
        //contenedro de puntos
        HBox h_img = new HBox();
        // HBox p = new HBox();
        //contenedor de boton jugar
        HBox h_boton = new HBox();
//
//        p.getChildren().add(puntos);

        //el boton te da acceso a jugar
        Button btn = new Button("  JUGAR OTRA VEZ   ");
        btn.setPrefSize(250, 50);
        Button btnacabar = new Button("  ACABAR  ");
        btnacabar.setPrefSize(250, 50);
        //me creo una instancia para obtener el panel principal
        FileInputStream fondo = new FileInputStream("img/fiin.jpg");
        Image img = new Image(fondo, 550, 300, false, false);
        ImageView pac = new ImageView(img);

        //añadiendo a los hbox la imagen de inicio y el boton jugar
        h_img.getChildren().add(pac);
        h_boton.getChildren().add(btn);
        h_boton.getChildren().add(btnacabar);
        h_boton.setAlignment(Pos.CENTER);

        // preparo la lista con los records
        BBDD bbdd = new BBDD();
        ArrayList<Record> lista = bbdd.leerRecords();
        Record ultima = bbdd.leerultimoregistro();
        String texto = "ULTIMA PUNTUACION: " + ultima.toString();
        texto = texto + "\n" + "MEJORES RECORDS";

        for (Record r : lista) {
            texto = texto + "\n" + r.toString();
        }
        puntos = new Label(texto);
        puntos.setMaxWidth(Double.MAX_VALUE);
        puntos.setTextAlignment(TextAlignment.CENTER);
        puntos.setAlignment(Pos.BASELINE_CENTER);
//

        //añadir los hbox al contenedor vbox
        contenedor.getChildren().add(h_img);
        contenedor.getChildren().add(puntos);
        contenedor.getChildren().add(h_boton);

        StackPane principal = new StackPane();

        principal.getChildren().add(contenedor);

        Scene scene = new Scene(principal);

        fin.setTitle("   INICIO  ");

        //tenemos que decirle a la pantalla que tiene que mostrar
        fin.setScene(scene);

        //Sirve para mostrar nuestra primera pantalla
        fin.show();

        //        Creamos el evento del boton
        btn.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent e) {

                Comecocos com = new Comecocos();
                try {
                    fin.close();
                    com.start(new Stage());
                } catch (FileNotFoundException ex) {
                    //error
                }
            }
        });
        //        Creamos el evento del boton
        btnacabar.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent e) {

                fin.close();
                Platform.exit();

            }
        });
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }

    void setVisible(boolean b) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

}
