
package comecocos;

public class Record {
    
     private int puntuacion;
     private String fecha;
     
     
    public void Record(){
        
    }

    public Record(int puntuacion, String fecha) {
        this.puntuacion = puntuacion;
        this.fecha = fecha;
    }

    public int getPuntuacion() {
        return puntuacion;
    }

    public void setPuntuacion(int puntuacion) {
        this.puntuacion = puntuacion;
    }

    public String getFecha() {
        return fecha;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }

    @Override
    public String toString() {
        return "Record: " + puntuacion + "   Fecha :" + fecha;
    }
    
    
        
}


