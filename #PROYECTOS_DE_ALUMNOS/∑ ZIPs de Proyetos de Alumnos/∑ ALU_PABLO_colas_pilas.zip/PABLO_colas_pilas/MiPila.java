public class MiPila {

    NodoPila top, bottom;
    int size = 0;


    public void push(int information) {
        NodoPila nuevo = new NodoPila(information);
        if (size == 0) {
            nuevo.below = null;
            bottom = nuevo;
        } else {
            nuevo.below = top;
        }
        top = nuevo;
        size++;
    }


    public int pop() {
        if (size == 0) {
            return -1;
        }
        int info = top.information;
        top = top.below;
        size--;
        return info;
    }

    public void leerTodos() {
        NodoPila actual = top;
        while (actual != null) {
            System.out.println(actual.information);
            actual = actual.below;
        }
    }

    public boolean isSorted() {
        boolean ordered = true;
        NodoPila actual = top;
        NodoPila superiorAlActual = new NodoPila(-1);
        while (actual != null) {
            if(actual.information<superiorAlActual.information){
                ordered = false;
            }
            superiorAlActual= actual;
            actual = actual.below;
        }
        return ordered;
    }

    public int count(int numABuscar){
        int res= 0;
        MiPila pilatemp = new MiPila();

        NodoPila actual = this.top;
        // vaciamos la cola inicial y vemos si hay elementos como el buscado
        while (!this.isEmpty()) {
            int inf= this.pop();
            if(inf==numABuscar){
                res++;
            }
            pilatemp.push(inf);
        }
        // rellenamos de vuelta la cola inicial
        actual = pilatemp.top;
        while (!pilatemp.isEmpty()) {
            this.push(pilatemp.pop());
        }
        return res;
    }

    public boolean isEmpty(){
        return this.size ==0;
    }
}

