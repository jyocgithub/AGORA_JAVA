package listadobleenlazada;
/*
Problema 4 (2 puntos). CON GRAFOS Y CON lista de adyacencias
        La universidad desea gestionar las asignaturas que son requisito previo para cursar
        otras asignaturas. De esta manera, cuando un alumno acude a matricularse, es posible
        comprobar que ha cursado todas las asignaturas necesarias. Así, si las asignaturas
        “Cálculo” y “Programación” son requisitos para “Estructura de Datos y Algoritmos
        (EDA)” implicará que no es posible cursar EDA sin haber cursado previamente “Cálculo”
        y “Programación”.
        Suponiendo que como máximo, para unos estudios de grado determinado hay un
        máximo de 20 asignaturas.
        1) (0.25) ¿Qué estructura(s) de datos es la más adecuada para representar las
        relaciones entre las asignaturas y los pre-requisitos?. Explícalo. ¿Esas relaciones son
        simétricas?
        2) (0.25) Para implementar dicha estructura, escribe las cabeceras de las clases, los
        atributos y un método constructor que toma un array de los nombres de las
        asignaturas como parámetro de entrada. En ese constructor, no hace falta definir
        ninguna relación.
        3) (0.5) Escribe un método no estático, requiredFor, que tome el nombre de una
        asignatura como parámetro de entrada, y devuelva una lista de todas las asignaturas
        que tienen como requisito previo la asignatura de entrada. Supongamos que las
        relaciones entre las asignaturas ya han sido almacenadas en la estructura elegida.
        Por ejemplo, EDA es un requisito previo para las asignaturas "Heurística y
        optimización", "Programación orientada a objetos", "Ingeniería del conocimiento",
        "Diseño de sistemas operativos", "Lenguajes formales y teoría de autómatas".
        4) (0.5) Escribe un método no estático, getRequiredSubjectsFor, que tome el nombre
        de una asignatura como parámetro de entrada, y devuelva la lista de asignaturas que
        un alumno debería haber aprobado para poder matricularse en la asignatura de
        entrada. Por ejemplo, para matricularse en EDA, el alumno debería haber aprobado
        las asignaturas “Cálculo” y “Programación”.
        5) (0.5) Escribe un método no estático, notAllowed, que tome una lista con todas las
        asignaturas aprobadas por un alumno, y devuelva una lista con todas las asignaturas
        en las que el alumno aún no puede matricularse.
        Nota: En este problema, puedes utilizar clases de Java tales como LinkedList <String>
        o ArrayList<String> para implementar su solución.
*/


import java.util.ArrayList;

public class GrafoAsignaturasEjercicio4Examen {


    public static void main(String[] args) {
        String[] lista = {"mates", "fisica", "quimica"};

        RequirementGraph rg = new RequirementGraph(lista);



    }


}


class RequirementGraph {
    public String[] subjects;
    public int num;
    ArrayList<Integer>[] lstAdjacents;

    public RequirementGraph(String[] subjects) {
        this.subjects = subjects;
        this.num = subjects.length;
        // creamos un array de ... arraylist<Integer>   cada elemento del array es un arraylist
        ArrayList<Integer>[] lstAdjacents = new ArrayList[num];
        //we must initialize each adjacent list
        for (int i = 0; i < num; i++) {
            lstAdjacents[i] = new ArrayList();
        }
    }


    public int getIndex(String texto) {
        for (int i = 0; i < num; i++) {
            if (subjects[i].equalsIgnoreCase(texto)) {
                return i;
            }
        }
        return 0;
    }

    public String getNameSubject(int id) {
        return subjects[id];
    }

    public ArrayList<String> RequieredFor(String asignatura) {
        // sacar el numero de indice de la asignatura pedida
        int index = getIndex(asignatura);
        if (index == -1) return null;
        // Creo un arraylist de resultados para rellenarlo
        ArrayList<String> resultados = new ArrayList<String>();
        // SAaco el arraylist de adyacencias correspondiente al indice de la asignatruar pedida

        ArrayList<Integer> listaDeLaAsignaturaPedida = lstAdjacents[index];
        for (int i = 0; i < listaDeLaAsignaturaPedida.size(); i++) {
            int adj = listaDeLaAsignaturaPedida.get(i);
            String nombreAsignaturaAdyacente = getNameSubject(adj);
            resultados.add(nombreAsignaturaAdyacente);
        }
        return resultados;
    }


    public ArrayList<String> getRequiredSubjectsFor(String subject) {
        // sacar el numero de indice de la asignatura pedida
        int indexBuscado = getIndex(subject);
        if (indexBuscado == -1) return null;

        // Creo un arraylist de resultados para rellenarlo
        ArrayList<String> result = new ArrayList<String>();

        // Recorre todos los arrayList de adyacencias, con la variable i
        for (int i = 0; i < num; i++) {
            // sado del array de arraylist cada uno de los ararylist
            ArrayList<Integer> listaDeAsignaturasAdyacentes = lstAdjacents[i];
            // recorro la lista de adyacencias de la asignatura i
            for (int j = 0; j < listaDeAsignaturasAdyacentes.size(); j++) {
                // obtengo el id de cada asigantura
                int indiceDeAdyacente = listaDeAsignaturasAdyacentes.get(j);
                // si es igual al id de la buscada, añado
                if (indexBuscado == indiceDeAdyacente) {
                    String nombreAsignaturaAdyacente = getNameSubject(i);
                    result.add(nombreAsignaturaAdyacente);
                }
            }
        }
        return result;
    }


    public ArrayList<String> notAllowed(ArrayList<String> listaAprobadas) {
        if (listaAprobadas == null) return null;

        ArrayList<String> notAllow = new ArrayList<String>();

        //traverse all subjects
        for (int i = 0; i < subjects.length; i++) {
            String nombreCadaAsignaturaExistente = subjects[i];
            // Si la asignatrura que voy a analizar ya estaba aprobada, no la analizo
            if (!listaAprobadas.contains(nombreCadaAsignaturaExistente)) {
                //this subject has not been passed yet
                //we gets all required subject for this
                ArrayList<String> required = getRequiredSubjectsFor(nombreCadaAsignaturaExistente);

                boolean allowed = true;
                for (int j = 0; j < required.size() && allowed; j++) {
                    String name = required.get(j);
                    //if some of the required subject is not in the list,
                    //then this subject is not allowed
                    if (!listaAprobadas.contains(name)) allowed = false;
                }
                if (!allowed) notAllow.add(nombreCadaAsignaturaExistente);
            }
        }
        return notAllow;
    }




}