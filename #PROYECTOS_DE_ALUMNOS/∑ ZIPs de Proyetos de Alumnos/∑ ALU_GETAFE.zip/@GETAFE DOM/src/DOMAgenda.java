
import java.io.File;
import java.util.ArrayList;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class DOMAgenda {

	public static void main(String[] args) {
		File fichero = new File("personas.xml");

		ArrayList<Persona> agenda = new ArrayList<>();
		int i;
		try {
			DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder dBuilder;
			dBuilder = dbFactory.newDocumentBuilder();
			Document doc = dBuilder.parse(fichero);
			doc.getDocumentElement().normalize();

			NodeList nList = doc.getElementsByTagName("persona");
			System.out.println("Numero de personas : " + nList.getLength());

			for (i = 0; i < nList.getLength(); i++) {
				Node nodo = nList.item(i);

				if (nodo.getNodeType() == Node.ELEMENT_NODE) {
					Element eElement = (Element) nodo;
					String string_a_int = eElement.getAttribute("id");
					int id = Integer.parseInt(string_a_int);

					String nombre = eElement.getElementsByTagName("nombre").item(0).getTextContent();

					NodeList todoslosnombres = eElement.getElementsByTagName("nombre");
					if (todoslosnombres.getLength() > 0) {
						String nombrew = todoslosnombres.item(0).getTextContent();
					}

					String apellidos = eElement.getElementsByTagName("apellidos").item(0).getTextContent();
					String direccion = eElement.getElementsByTagName("direccion").item(0).getTextContent();
					int edad = Integer.parseInt(eElement.getElementsByTagName("edad").item(0).getTextContent());

					Persona agregada = new Persona(id, nombre, apellidos, direccion, edad);
					agenda.add(agregada);
					System.out.println(agregada);
				}
			}

		} catch (Exception ex) {
			ex.printStackTrace();
		}
		for (Persona personas : agenda) {
			System.out.println("nombre: " + personas.getNombre());
			System.out.println("apellidos: " + personas.getApellidos());
			System.out.println("direccion: " + personas.getDireccion());
			System.out.println("edad: " + personas.getEdad());
		}

		// AHORA SIN CONOCER EL FORMATO DEL FICHERO

	}

}
