public class NodoPila {
    int information;
    NodoPila below;
    public NodoPila(int information) {
        this.information = information;
    }
}
