package listadobleenlazada;

public class LIstDobleEnlazadaEjercicio1Examen {


    public static void main(String[] args) {

    }
}








 class DList {
     public DNode first;
     public DNode last;

     public DList() {
         first = null;
         last = null;
     }
 }

 class DNode{
    Object elem;
    DNode prev;
    DNode next;
    public DNode (Object elem){
        this.elem=elem;
    }
 }