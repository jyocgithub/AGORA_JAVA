public class PruebaCola {

    public static void main(String[] args) {

        MiPila mp  =  new MiPila();
        mp.push(99);
        mp.push(88);
        mp.push(44);
        mp.push(33);
        mp.push(33);
        mp.push(33);
        mp.push(33);
        mp.push(11);
        mp.push(9);

        mp.leerTodos();
        System.out.println("-------------------");
        System.out.println(mp.pop());
        System.out.println(mp.pop());
        System.out.println(mp.pop());
        System.out.println("-------------------");

        mp.leerTodos();

        System.out.println(mp.isSorted());

        System.out.println(mp.count(33));

    }
}
