package condicionDeCarrera_MonitorSincronizado;

public class ContadorCCMS {
	private int			valor		= 0;
	public final int	NUMVECES	= 10;
	private boolean		puedoActuar	= false;

	public ContadorCCMS(int c) {
		valor = c;
	}

	// el método incrementa ahora esta sincronizado
	synchronized public void incrementa(int n) {
		while (!puedoActuar) {
			try {
				wait();
			}
			catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		System.out.println("---- ahora puedo Incrementar...");
		valor = valor + n;
		puedoActuar = false;
		notifyAll();
	}

	// el método decrementa ahora esta sincronizado
	synchronized public void decrementa() {
		while (puedoActuar) {
			try {
				wait();
			}
			catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		System.out.println("---- ahora puedo Decrementar...");
		valor--;
		puedoActuar = true;
		notifyAll();
	}

	public int getValue() {
		return valor;
	}

}
