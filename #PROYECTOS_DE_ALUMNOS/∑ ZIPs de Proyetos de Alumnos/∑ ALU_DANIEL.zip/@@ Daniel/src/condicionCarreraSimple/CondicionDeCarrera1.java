package condicionCarreraSimple;

public class CondicionDeCarrera1 extends Thread {

	public int		contador;
	public String	nombre;

	CondicionDeCarrera1 (String n) {
		nombre = n;
	}

	@Override
	public void run () {
		try {
			for (int i = 0; i <= 10; i++) {
				Thread.sleep (300);
				System.out.println (nombre + " : " + contador++);
			}
		}
		catch (InterruptedException ie) {
		}
	}

	public static void main (String[] args) throws InterruptedException {
		CondicionDeCarrera1 hilo1 = new CondicionDeCarrera1 ("SOY UNO");
		CondicionDeCarrera1 hilo2 = new CondicionDeCarrera1 ("SOY DOS");
		hilo1.start ();
		hilo2.start ();
//		hilo1.join();
//		hilo2.join();
	}
}

