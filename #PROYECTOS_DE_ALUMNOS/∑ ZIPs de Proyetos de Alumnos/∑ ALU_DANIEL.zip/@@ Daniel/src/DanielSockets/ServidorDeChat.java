package DanielSockets;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Scanner;

/**
 * PROGRAMA SERVIDORDECHAT.java
 * 
 * Contiene cuatro clases:
 * - class ServidorDeChat: es una instancia única, que esta en un bucle infinito esperando
 * a que se comuniquen con el algun cliente, establenciendo el socket que necesita,
 * autentica a los clientes y si es correcta la password crea los hilos HiloServidorParaCadaCliente
 * 
 * - class HiloServidorParaCadaCliente : es la clase que es un hilo, hay una inbstancia para cada cliente,
 * un hilo de tipo servidor, que controla lo que envia el hilo de cada cliente (peticiones) y
 * le devuelve lo que haya pedido (gestiona sus mensajes)
 * 
 * - class Cliente: Vale para crear objetos Cliente, con sus atributos (buzones de mensaje, streem de
 * lectura y de escritura, etc)
 * 
 * - class datos : tiene datos de conexion (puerto , basicamente) para que todos los hilos cliente
 * y servidor puertos identicos
 * 
 */

/**
 * SalaDeChat
 * 
 * Es el lado del servidor de una sala de chat.
 * Permite que se le conecten tantos
 * clientes como se quiera. Para cada uno, se queda escuchando
 * en su stream de entrada y actua en consecuencia
 */
public class ServidorDeChat {

	/**
	 * main
	 * 
	 */
	public static void main (String[] args) {

		Socket socketCliente;
		int numeroPuerto = 22222;
		HiloServidorParaCadaCliente2 obHiloServidorPorCliente;
		ServerSocket serverSocket;
		PrintWriter escritor;
		BufferedReader lector;
		Cliente elCliente;
		Scanner sc = new Scanner (System.in);

		// Creamos el ServerSocket donde nos quedaremos escuchando.
		try {
			serverSocket = new ServerSocket (numeroPuerto);
		}
		catch (IOException e) {
			System.out.println ("No pude escuchar en el puerto " + numeroPuerto);
			return;
		}


		boolean seguirEnElBucle = true;
		System.out.println ("Servidor arrancado, esperando que el cliente conecte");


		// Esperamos UN cliente.
		try {
			socketCliente = serverSocket.accept ();
		}
		catch (IOException ioe) {
			System.err.println ("Error esperando clientes: " + ioe.getLocalizedMessage ());
			return;
		}
		String leido;

		// Acaba de llegarnos un nuevo cliente.
		// Obtenemos el canal para escribir en el socket, que sera el de entrada
		// a este cliente cuando cualquier otro escriba.
		try {
			//obtenemos los canales para leere y escribir en el cliente
			escritor = new PrintWriter (socketCliente.getOutputStream ());
			lector = new BufferedReader (new InputStreamReader (socketCliente.getInputStream ()));
			//elCliente = new Cliente ("Nombre Cliente", escritor, lector, socketCliente);

			escritor.println ("Hola !!!");
			escritor.flush ();
			// esperamos que el otro escriba
			while (true) {

				leido = lector.readLine ();
				System.err.println ("-- Mensaje del cliente : " + leido);
				switch (leido) {
					case "hola": {
						escritor.println ("hola a ti");
						escritor.flush ();
						break;
					}
				}

				System.out.println ("-- ¿Que responde al Cliente?");
				String enviar = sc.nextLine ();
				escritor.println (enviar);
				escritor.flush ();


			}
		}
		catch (IOException e) {
			e.printStackTrace ();
		}


	}
}


//				
////				String n = lector.readLine ();
////				escritor.println ("Indique la contraseña:");
////				escritor.flush ();
////				String p = lector.readLine ();
////				// pass ok, seguimos
//				String leido;
//				while (true) {
//
//					try {
//						leido = lector.readLine ();
//
//						if (leido == null) {
//							break;
//						}
//
//						switch (leido) {
//							case "HOLA": {
//								escritor.println ("HOLA A TI TAMBIEN");
//								escritor.flush ();
////								escribirEnCliente ("LISTADO DE MENSAJES");
////								if (elCliente.mensajes.size () == 0) {
////									escribirEnCliente ("No tiene mensajes en el buzon");
////								}
////								else {
////									for (int i = 0; i < elCliente.mensajes.size (); i++) {
////										escribirEnCliente (elCliente.mensajes.get (i));
////									}
////								}
////								break;
////							}
////							case "ADIOS": {
////								escribirEnCliente ("¿Que mensaje desea recuperar?");
////								String op = elCliente.lector.readLine ();
////								int opint = Integer.parseInt (op);
////								if (opint > elCliente.getMensajes ().size () || opint < 0) {
////									escribirEnCliente ("No existe ese mensaje");
////								}
////								else {
////									escribirEnCliente (elCliente.mensajes.get (opint));
////								}
////								break;
////							}
////							case "AYUDA": {
////								escribirEnCliente ("¿A quien envias mensaje?");
////								String destinatario = elCliente.lector.readLine ();
////								escribirEnCliente ("¿mensaje?");
////								String mens = elCliente.lector.readLine ();
////
////								for (Cliente cl : clientes) {
////									if (cl.getNombre ().equals (destinatario)) {
////										cl.getMensajes ().add (mens);
////										cl.escritor.println ("Tiene nuevo mensaje!");
////										cl.escritor.flush ();
////										break;
////									}
////								}
////
////								break;
////							}
////							case "EXIT": {
////								// Cerramos el canal de entrada. El socket se dará
////								// cuenta, y verá que el canal de salida está
////								// también cerrado (por el otro extremo) y
////								// dará error en el próximo intento de escritura.
////								try {
////									elCliente.lector.close ();
////									elCliente.escritor.close ();
////									clientes.remove (elCliente);
////								}
////								catch (IOException e) {
////									e.printStackTrace ();
////								}
////								break;
////							}
//							default: {
////								escribirEnCliente ("--- Instruccion desconocida.");
//							}
//						}

//
//				}
//
//				System.out.println (" **Fin de la hebra de entrada**");
//
////					// Lanzamos una hebra para escribir todo lo que nos llegue.
////					obHiloServidorPorCliente = new HiloServidorParaCadaCliente (c, clientes);
////					new Thread (obHiloServidorPorCliente).start ();
//
//
//			}
//			catch (IOException e) {
//				System.err.println ("No pude conseguir canal de escritura o escritura del socket.");
//				return;
//			}
//		}
//		
//	}

//	private void escribirEnCliente (String ss) {
//		cliente.escritor.println (ss);
//		cliente.escritor.flush ();
//	}


