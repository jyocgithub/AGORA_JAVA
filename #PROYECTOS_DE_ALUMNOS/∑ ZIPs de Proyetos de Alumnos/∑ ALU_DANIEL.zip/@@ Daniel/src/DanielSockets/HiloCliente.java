package DanielSockets;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

public class HiloCliente {

	BufferedReader lector;

	/**
	 * Constructor
	 * 
	 */
	HiloCliente (InputStream is) {
		lector = new BufferedReader (new InputStreamReader (is));
	}


	public void chatear () {

		String leido;

//		while (true) {
//			try {
//				leido = lector.readLine ();
//				System.out.println (leido);
//			}
//			catch (IOException e) {
//				break;
//			}
//		}

		// Cerramos el canal de entrada. El socket se da cuenta, y ve que el canal de salida
		// está también cerrado (por el otro extremo) y da error en el próximo intento de escritura.
		try {
			lector.close ();
		}
		catch (IOException e) {
			e.printStackTrace ();
		}


	}
}
