package danielSocketsChatSinSwing;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Scanner;

public class ClienteDeChat {
	public static void main (String[] args) {
		Socket socket;
		String hostname = "localhost";
		String leido = "";
		Scanner sc = new Scanner (System.in);
		PrintWriter escritor;  	// Canal de salida del socket por donde escribimos lo que enviamos al servidor
		BufferedReader lector;  // Canal de entrada del socket por donde leemos lo que se recibe del servidor

		try {
			socket = new Socket (hostname, 22222);  // Intentamos conectarnos al servidor solicitado en el puerto 22222
		}
		catch (UnknownHostException uhe) {
			System.err.println ("Error al usar localhost");
			return;
		}
		catch (IOException ioe) {
			System.err.println ("Error de E/S creando el socket: " + ioe.getLocalizedMessage ());
			return;
		}

		// Obtenemos canales de entrada y de salida donde mandaremos/leeremos los textos al servidor
		try {
			escritor = new PrintWriter (socket.getOutputStream ());
			lector = new BufferedReader (new InputStreamReader (socket.getInputStream ()));

			while (!leido.equals ("ADIOS")) {
				leido = lector.readLine ();
				System.out.println ("@@ Mensaje llegado del servidor : " + leido);
				System.err.println ("@@ ¿Que responde al Servidor?");
				String enviar = sc.nextLine ();
				escritor.println (enviar);
				escritor.flush ();
			}
		}

		catch (IOException e) {
			System.out.println ("[Error de conexión]");
			return;
		}
		finally {
			try {
				socket.close ();
			}
			catch (IOException e) {
				e.printStackTrace ();
			}
		}
	}
}