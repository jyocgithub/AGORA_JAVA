package danielSocketsChatSinSwing;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Scanner;

public class ServidorDeChat {

	public static void main (String[] args) {

		Socket socketCliente = null;
		ServerSocket serverSocket = null;
		PrintWriter escritor;
		BufferedReader lector;
		Scanner sc = new Scanner (System.in);
		String mensaje = "";
		String leido;

		// Creamos el ServerSocket donde nos quedaremos escuchando.
		try {
			serverSocket = new ServerSocket (22222);
		}
		catch (IOException e) {
			System.out.println ("No pude escuchar en el puerto elegido ");
			return;
		}

		boolean seguirEnElBucle = true;
		System.out.println ("Servidor arrancado, esperando que el cliente conecte");


		// Esperamos que "llame" un cliente.
		try {
			socketCliente = serverSocket.accept ();
		}
		catch (IOException ioe) {
			System.err.println ("Error esperando clientes: " + ioe.getLocalizedMessage ());
		}

		// Acaba de llegarnos un nuevo cliente.
		// Obtenemos el canal para escribir en el socket, que sera el de entrada
		// a este cliente cuando cualquier otro escriba.
		try {
			//obtenemos los canales para leere y escribir en el cliente
			escritor = new PrintWriter (socketCliente.getOutputStream ());
			lector = new BufferedReader (new InputStreamReader (socketCliente.getInputStream ()));
			//elCliente = new Cliente ("Nombre Cliente", escritor, lector, socketCliente);

			escritor.println ("Hola !!! Acabas de conectarte a nuestro saervidor");
			escritor.flush ();
			// esperamos que el otro escriba
			while (!mensaje.equals ("ADIOS")) {
				leido = lector.readLine ();
				System.out.println ("-- Mensaje del cliente : " + leido);
				System.err.println ("-- ¿Que responde al Cliente?");
				mensaje = sc.nextLine ();
				escritor.println (mensaje);
				escritor.flush ();
			}
		}
		catch (IOException e) {
			e.printStackTrace ();
		}
		finally {
			try {
				serverSocket.close ();
			}
			catch (IOException e) {
				e.printStackTrace ();
			}
		}
	}
}


