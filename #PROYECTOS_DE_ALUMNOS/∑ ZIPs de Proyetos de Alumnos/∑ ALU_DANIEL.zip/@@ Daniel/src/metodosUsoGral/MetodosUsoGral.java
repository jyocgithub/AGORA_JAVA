package metodosUsoGral;

public class MetodosUsoGral {

	// devuelve cuantas vocales tiene una cadena
	public int cuantasVocales (String c) {
		int res = 0;
		for (int i = 0; i < c.length (); i++) {
			String s = c.substring (i, i + 1);
			if (s.equalsIgnoreCase ("A") || s.equalsIgnoreCase ("E") || s.equalsIgnoreCase ("I") || s.equalsIgnoreCase ("O")
			        || s.equalsIgnoreCase ("U"))
			    res++;
		}
		return res;
	}

	// devuelve cuantos digitos hay en una cadena

	public int cuantosDigitos (String c) {
		int res = 0;
		for (int i = 0; i < c.length (); i++) {
			String s = c.substring (i, i + 1);
			if (s.equals ("0") || s.equals ("1") || s.equals ("2") || s.equals ("3") || s.equals ("4") || s.equals ("5") || s.equals ("6")
			        || s.equals ("7") || s.equals ("8") || s.equals ("9"))
			    res++;
		}
		return res;
	}


	// devuelve un array de String con las letras impares de una cadena
	public String[] soloLetrasImpares (String c) {
		int h = 0;
		String[] a = new String[ (c.length () / 2)];
		for (int i = 0; i < c.length (); i = i + 2) {
			a[h++] = c.substring (i, i + 1);
		}
		return a;
	}

	// devuelve un String que es la concatenacion de los elementos de un array
	public String arrayToString (String c[]) {
		String a = "";
		for (int i = 0; i < c.length; i = i + 1) {
			a += c[i];
		}
		return a;
	}

	// devuelve numero de palabras de una frase
	public int cuantasPalabras (String c) {
		int res = 0;
		res = (c.split (" ")).length;
		return res;
	}

	// devuelve cuantas veces aparece xxx en una cadena
	public int cuantasVeces (String cadenadondebuscar, String trozoquesebusca) {
		int c = 0;
		int in = cadenadondebuscar.indexOf (trozoquesebusca);

		while (in > 0) {
			c++;
			cadenadondebuscar = cadenadondebuscar.substring (in + trozoquesebusca.length ());
			in = cadenadondebuscar.indexOf (trozoquesebusca);
		}
		return c;
	}


	// devuelve una cadena invertida
	public String cadenaInvertida (String c) {
		String s = "";
		for (int i = c.length () - 1; i >= 0; i--) {
			s += c.charAt (i);
		}
		return s;
	}

	// devuelve suma de digitos de un numero
	public int sumarDigitos (int n) {
		int h = 0;
		String c = n + "";
		for (int i = 0; i < c.length (); i = i + 1) {
			h += Integer.parseInt (c.substring (i, i + 1));
		}
		return h;
	}


	// devuelve si es palindromo una cadena
	public boolean esPalindromo (String c) {
		for (int i = 1; i < c.length (); i++) {
			if (c.charAt (i) != c.charAt (c.length () - 1 - i)) return false;
		}
		return true;
	}


	// devuelve si es capicua un numero
	public boolean esCapicua (int cc) {
		String c = cc + "";
		for (int i = 1; i < c.length (); i++) {
			if (c.charAt (i) != c.charAt (c.length () - 1 - i)) return false;
		}
		return true;
	}

	/**
	 * Metodo que valida un mail de modo sencillo
	 */
	public boolean validarCorreo (String strDni) {
		boolean res = true;
		if (strDni.substring (0, 1).equals ("@")) return false;
		if (strDni.substring (0, 1).equals (".")) return false;
		if (!strDni.contains ("@")) return false;
		if (!strDni.contains (".")) return false;
		if (strDni.indexOf ('@') > strDni.indexOf ('.')) return false;
		if (strDni.split (".").length > 2) return false;
		if (strDni.split ("@").length > 2) return false;
		return res;
	}

	/**
	 * intAleatorio 
	 *
	 * DEVUELVEN UN ENTERO ALEATORIO EN UN RANGO DETERMINADO 
	 */
	public int intAleatorio (int min, int max) {
		return (int) (Math.random () * (max - min + 1) + min);
	}

	/**
	 * booleanAleatorio
	 *
	 * DEVUELVEN UN BOOLEAN ALEATORIO
	 */
	public boolean booleanAleatorio () {
		// mantenemos la formula aunque sea sin operar operandos, para recordarla
		if ((int) (Math.random () * (1 - 0 + 1) + 0) == 0) return false;
		else return true;
	}












	// metodo para probar los metodos previos
	void probar () {
		System.out.println (cuantasVeces ("oossjSSSsssjjssoo", "ss"));

	}

	public static void main (String[] args) {
		new MetodosUsoGral ().probar ();
	}



}
