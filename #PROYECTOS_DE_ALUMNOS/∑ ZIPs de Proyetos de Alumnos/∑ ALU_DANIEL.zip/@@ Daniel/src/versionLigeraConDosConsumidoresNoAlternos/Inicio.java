package versionLigeraConDosConsumidoresNoAlternos;

import java.util.concurrent.Semaphore;

public class Inicio {
	public static void main (String args[]) {

		// Creo un semaforo para pasarlo (el mismo semaforo) a productor
		// y consumidor a la vez, pues deben compartirlo
		Semaphore unSemaforo = new Semaphore (1);

		// creo un objeto del Monitor, que es quien tiene los metodos de poner y quitar
		Monitor miMonitor = new Monitor ();

		// Creo objetos de consumidor y productor, y les paso el mismo objeto del monitor
		// creado antes como parametro.
		ConsumidorMensajes conMen1 = new ConsumidorMensajes (miMonitor, 1);
		ConsumidorMensajes conMen2 = new ConsumidorMensajes (miMonitor, 2);

		ProductorMensajes proMen = new ProductorMensajes (miMonitor);

		// Como productor y consumidores son Threads, los arranco a continuacion.
		conMen1.start ();
		conMen2.start ();
		proMen.start ();
	}
}
