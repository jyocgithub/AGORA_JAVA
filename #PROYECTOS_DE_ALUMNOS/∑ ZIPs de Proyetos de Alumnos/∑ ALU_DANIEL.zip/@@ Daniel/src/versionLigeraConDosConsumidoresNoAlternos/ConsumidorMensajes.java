package versionLigeraConDosConsumidoresNoAlternos;

public class ConsumidorMensajes extends Thread {

	Monitor	monitorCompartidoPorLosHilos;
	String	mensajeSacadoDelBuffer	= "";
	int		quiensoy;																																																																								  // variable que indica la identidad del hilo consumidor

	public ConsumidorMensajes (Monitor parametroMonitor, int quiensoy) {
		// Mantiene una copia propia del objeto compartido 
		monitorCompartidoPorLosHilos = parametroMonitor;
		this.quiensoy = quiensoy;
	}

	@Override
	public void run () {


		// bucle que lee mensajes hasta que un mensaje sea 20
		do {
			mensajeSacadoDelBuffer = monitorCompartidoPorLosHilos.sacar (); 				// extraemos un mensaje del buffer
			System.out.println ("-- Soy consumidor " + quiensoy + " -- Saco el mensaje " + mensajeSacadoDelBuffer); 	// mensaje de aviso
		} while (!mensajeSacadoDelBuffer.equals ("20"));										// seguimos si no se ha enviado un mensaje FIN

		// Cuando se recibe un mensaje FIN no se acaba de leer, se leen ahora todos los mensajes que hayan podido quedar en el buffer
		boolean estaVacioElBuffer = false;
		do {
			mensajeSacadoDelBuffer = monitorCompartidoPorLosHilos.sacar ();
			System.out.println ("-- Soy consumidor " + quiensoy + " -- Saco del resto del buffer el mensaje " + mensajeSacadoDelBuffer);
			estaVacioElBuffer = monitorCompartidoPorLosHilos.isEstaVacia ();				// vemos si se esta ya vacio el buffer
			esperarUnPoco ();

		} while (!estaVacioElBuffer);

		System.out.println ("------ Fin de lecturas del consumidor " + quiensoy);
	}

	void esperarUnPoco () {
		try {
			sleep (500);
		}
		catch (InterruptedException e) {
			e.printStackTrace ();
		}
	}


}
