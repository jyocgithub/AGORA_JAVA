package versionLigera;

public class ConsumidorMensajes extends Thread {

	private Monitor objetoMonitorCompartidoPorLosHilos;

	public ConsumidorMensajes (Monitor parametroMonitor) {
		// Mantiene una copia propia del objeto compartido y un parametro de cadena de entrada
		objetoMonitorCompartidoPorLosHilos = parametroMonitor;
	}

	@Override
	public void run () {

		boolean seguirEnElBucle = true;
		String mensajeSacadoDelBuffer = "";

		// bucle que lee mensajes hasta que un mensaje ponga FIN
		do {
			mensajeSacadoDelBuffer = objetoMonitorCompartidoPorLosHilos.sacar ();
			// extraemos un mensaje del buffer
			System.out.println ("-- Saco del Monitor el mensaje " + mensajeSacadoDelBuffer); 	// mensaje de aviso
		} while (!mensajeSacadoDelBuffer.equals ("FIN"));										// seguimos si no se ha enviado un mensaje FIN


		// Cuando se recibe un mensaje FIN no se acaba de leer, se leen ahora todos los mensajes que hayan podido quedar en el buffer
		while (!objetoMonitorCompartidoPorLosHilos.isEstaVacia ()) {   // vemos si estA ya vacio el buffer
			mensajeSacadoDelBuffer = objetoMonitorCompartidoPorLosHilos.sacar ();
			System.out.println ("-- Saco del Monitor el mensaje " + mensajeSacadoDelBuffer);
		}

		System.out.println ("FIN DE SALIDAS DE MENSAJERIA");


	}
}
