package versionLigera;


public class Inicio {
	public static void main (String args[]) {

		// creo un objeto del Monitor, que es quien tiene los metodos de poner y quitar
		Monitor miMonitor = new Monitor ();

		// Creo objetos de consumidor y productor, y les paso el mismo método del monitor
		// creado antes como parametro.
		ConsumidorMensajes conMen = new ConsumidorMensajes (miMonitor);
		ProductorMensajes proMen = new ProductorMensajes (miMonitor);

		// Como productor y consumidor son Threads, los arranco a continuacion.
		conMen.start ();
		proMen.start ();
	}
}
