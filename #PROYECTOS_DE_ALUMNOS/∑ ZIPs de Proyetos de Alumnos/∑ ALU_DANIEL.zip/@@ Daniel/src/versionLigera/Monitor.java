package versionLigera;

/**
 * Clase Monitor Gestiona los hilos de entrada y salida del buffer
 * donde se almacenan los mensajes Sus principales metodos son
 * - sacar() . Metodo sincronizado para extraer mensajes del buffer
 * - poner() . Metodo sincronizado para poner mensajes en el buffer
 */
public class Monitor {

	private final String	buffer[]					= new String[10];
	private int				punteroASiguienteMensaje	= 0;
	private boolean			elBufferEstaLleno			= false;
	private boolean			elBufferEstaVacio			= true;

	// Getters necesarios (settes no son necesarios ninguno)
	public boolean isEstaLlena () {
		return elBufferEstaLleno;
	}

	public boolean isEstaVacia () {
		return elBufferEstaVacio;
	}

	/**
	 * sacar() Saca mensjes del buffer y los devuelve como String
	 */
	public synchronized String sacar () {
		// Se mira si el buffer esta vacio, si lo esta, espera
		while (elBufferEstaVacio == true) {
			try {
				// queda en espera (wait) de que alguien le de paso con un notify(). Quien lo hace sera el metodo poner 
				wait ();
			}
			catch (InterruptedException e) {
				;
			}
		}

		punteroASiguienteMensaje--;					// 1-Decrementa la cuenta, ya consumimos un mensaje
		if (punteroASiguienteMensaje == 0) {		// 2-Comprueba si se retiró el ultimo mensaje, en cuyo caso, debe poner elBufferEstaVacio a true
			elBufferEstaVacio = true;
		}
		elBufferEstaLleno = false;					// 3-El buffer no puede estar lleno, porque acabamos de sacar algo, asi que ponemos elBufferEstaLleno a false	
		notify ();									// 4-Notifico a otros metodos que esten en  espera que he metido algo en el buzon		
		return (buffer[punteroASiguienteMensaje]);	// 5- Se devuelve el mensaje del buffer al consumidor
	}

	/**
	 * poner() Mete mensajes en el buffer 
	 * Los mensajes los recibe como un parametro String
	 */
	public synchronized void poner (String ss) {
		// Se mira si el buffer esta lleno, si lo esta, se espera a que haya hueco
		while (elBufferEstaLleno == true) {
			try {
				// queda en espera (wait) de que alguien le de paso con un notify(). Quien lo hace sera el metodo poner 
				wait ();
			}
			catch (InterruptedException e) {
				e.printStackTrace ();
			}
		}

		buffer[punteroASiguienteMensaje] = ss; 				// 1-pongo el mensaje en el lugar correspondiente del array
		punteroASiguienteMensaje++;							// 2-muevo el puntero del siguiente sitio disponibl	
		elBufferEstaVacio = false;							// 3-si acabo de poner algo, elBufferEstaVacio debe ser false a la fuerza
		if (punteroASiguienteMensaje == buffer.length) {	// 4-Comprueba si el buffer está lleno, y pongo elBufferEstaLleno a true en tal caso
			elBufferEstaLleno = true;
		}
		notify ();											// 5-Notifico a otros metodos que esten en espera que he metido algo en el buzon, 
	}
}
