package versionLigera;

import java.util.Scanner;

/**
 * Clase ProductorMensajes
 * Extiende de Thread para comportarse como un hilo,
 * por lo que sobreescribira su metodo run()
 * donde esta el codigo a ejecutgar cuando se le permita por sincronizacion
 */
public class ProductorMensajes extends Thread {

	private Monitor	objetoMonitorCompartidoPorLosHilos;
	private String	mensajeQueSePoneEnElBuffer;

	/**
	 * Constructor ProductorMensajes. Recibe como parametros
	 * - un objeto del Monitor que es quien esta controlando el trafico
	 * El productor y el programa termina al recibir un mensaje "DONE"
	 */
	public ProductorMensajes (Monitor parametroMonitor) {
		objetoMonitorCompartidoPorLosHilos = parametroMonitor;
	}

	@Override
	public void run () {
		Scanner objejoScanner = new Scanner (System.in);

		do {
			System.out.println ("Escriba un mensaje:");
			mensajeQueSePoneEnElBuffer = objejoScanner.nextLine ();    	// leo un mensaje por el teclado	
			objetoMonitorCompartidoPorLosHilos.poner (mensajeQueSePoneEnElBuffer);  // LLamar al metodo poner() del monitor, pasandole el mensaje leido	
			System.out.println ("++ Puesto en Monitor el mensaje " + mensajeQueSePoneEnElBuffer); 	// mensaje por pantalla para confirmar que hemos mandado un mensaje
		} while (! (mensajeQueSePoneEnElBuffer.equals ("FIN")));

		System.out.println ("FIN DE ENTRADAS DE MENSAJERIA");
		objejoScanner.close ();
	}
}
