package versionCompleta;

import java.util.Scanner;

/**
 * Clase ProductorMensajes
 * Extiende de Thread para comportarse como un hilo,
 * por lo que sobreescribira su metodo run()
 * donde esta el codigo a ejecutgar cuando se le permita por sincronizacion
 */
public class ProductorMensajes extends Thread {

	private Monitor	objetoMonitorCompartidoPorLosHilos;
	private String	mensajeQueSePoneEnElBuffer;

	/**
	 * Constructor ProductorMensajes. Recibe como parametros
	 * - un objeto del Monitor que es quien esta controlando el trafico
	 * El productor y el programa termina al recibir un mensaje "DONE"
	 */
	public ProductorMensajes (Monitor parametroMonitor) {
		objetoMonitorCompartidoPorLosHilos = parametroMonitor;
	}

	@Override
	public void run () {
		Scanner objejoScanner = new Scanner (System.in);

		do {
			System.out.println ("Escriba un mensaje:");
			mensajeQueSePoneEnElBuffer = objejoScanner.nextLine ();

			// Se añade el atributo de clase pMensaje, que es el mensaje,
			// al buffer, con el metodo poner() del monitor
			objetoMonitorCompartidoPorLosHilos.poner (mensajeQueSePoneEnElBuffer);

			// mensaje por consola de confirmacion
			System.out.println ("++ Puesto en Monitor el mensaje " + mensajeQueSePoneEnElBuffer);

			// Espera un poco antes de añadir más letras
			// Este valor se puede cambiar para ver con que alternancia se efectuan
			// las lecturas y escrituras en el buffer, por bloqueos y esperas variables
			try {
				sleep ((int) (Math.random () * 100));
			}
			catch (InterruptedException e) {
				System.err.println ("Productor: Error al poner en el buffer " + e.getMessage ());
			}

		} while (! (mensajeQueSePoneEnElBuffer.equals ("FIN")));

		System.out.println ("FIN DE ENTRADAS DE MENSAJERIA");
		objejoScanner.close ();
	}
}
