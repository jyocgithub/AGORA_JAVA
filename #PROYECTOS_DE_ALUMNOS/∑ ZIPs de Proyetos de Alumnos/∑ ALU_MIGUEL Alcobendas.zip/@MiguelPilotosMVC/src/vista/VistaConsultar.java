package vista;

import javax.swing.JPanel;
import javax.swing.JLabel;

import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import accesoDB.PilotoPersistencia;
import controlador.ControladorPilotos;
import model.Piloto;

public class VistaConsultar extends JPanel {
	private JButton btnBorrarPiloto;
	private JScrollPane scrollPane;
	private JTable tabla;
	private DefaultTableModel dtm;
	private JButton btnModificarPiloto;
	public VistaConsultar() {
		setBounds(0, 0, 710, 462);
		setOpaque(true);
		
		inicializar();
	}
	
	public void inicializar() {
		setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Lista de Pilotos:");
		lblNewLabel.setBounds(37, 62, 122, 16);
		add(lblNewLabel);
		
		btnModificarPiloto = new JButton("Modificar Piloto");
		btnModificarPiloto.setBounds(95, 384, 122, 25);
		add(btnModificarPiloto);
		
		btnBorrarPiloto = new JButton("Borrar Piloto");
		btnBorrarPiloto.setBounds(360, 384, 113, 25);
		add(btnBorrarPiloto);
		
		scrollPane = new JScrollPane();
		scrollPane.setBounds(37, 91, 605, 268);
		add(scrollPane);
		
		tabla = new JTable();
		scrollPane.setViewportView(tabla);
	}
	
	public void cargarTabla() {
		dtm = new DefaultTableModel() {
			public boolean isCellEditable(int row, int column) {
				/*
				 * if (column == 1) { return true; } else {
				 */
				return false;
				// }
			}
		};

		tabla.setModel(dtm);

		dtm.addColumn("NUMERO");
		dtm.addColumn("NOMBRE");
		dtm.addColumn("NACIONALIDAD");
		dtm.addColumn("EDAD");
		dtm.addColumn("ESCUDERIA");

		tabla.getColumn("NUMERO").setPreferredWidth(75);
		tabla.getColumn("NOMBRE").setPreferredWidth(125);
		tabla.getColumn("NACIONALIDAD").setPreferredWidth(75);
		tabla.getColumn("EDAD").setPreferredWidth(75);
		tabla.getColumn("ESCUDERIA").setPreferredWidth(75);

		// TODO: recuperar la lista de alumnos
		PilotoPersistencia pt = new PilotoPersistencia();
		ArrayList<Piloto> listaPilotos = pt.consultaPilotos();
		Object[] fila = new Object[5];

		for (Piloto piloto : listaPilotos) {
			fila[0] = piloto.getNumero();
			fila[1] = piloto.getNombre();
			fila[2] = piloto.getNacionalidad();
			fila[3] = piloto.getEdad();
			fila[3] = piloto.getEscuderia();
			dtm.addRow(fila);
		}

	}
	public void hacerVisible() {
		setVisible(true);
		 cargarTabla() ;
	}
	public void hacerInvisible() {
		setVisible(false);
	}
	
	public void setControlador(ControladorPilotos control) {
		tabla.addMouseListener(control);
		btnBorrarPiloto.addActionListener(control);
		btnModificarPiloto.addActionListener(control);
		
	}

	public JButton getBtnBorrarPiloto() {
		return btnBorrarPiloto;
	}

	public JScrollPane getScrollPane() {
		return scrollPane;
	}

	public JTable getTabla() {
		return tabla;
	}

	public DefaultTableModel getDtm() {
		return dtm;
	}

	public JButton getBtnModificarPiloto() {
		return btnModificarPiloto;
	}
	
}
