package vista;

import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JSpinner;
import javax.swing.JTextField;

import controlador.ControladorPilotos;

public class VistaModificar extends JPanel {
	private JTextField txtNombre;
	private JTextField txtNacionalidad;
	private JTextField txtEscuderia;
	private JSpinner spnNum;
	private JSpinner spnEdad;
	private JButton btnGuardar;
	private JButton btnVolver;
	
	public VistaModificar() {
		setBounds(0, 0, 450, 400);
		setOpaque(true);
		
		inicializar();
	}
	public void inicializar() {
setLayout(null);
		
		JLabel lblNmero = new JLabel("N\u00FAmero");
		lblNmero.setBounds(49, 61, 56, 16);
		add(lblNmero);
		
		JLabel lblEdad = new JLabel("Edad");
		lblEdad.setBounds(49, 133, 56, 16);
		add(lblEdad);
		
		JLabel lblEscudera = new JLabel("Escuder\u00EDa");
		lblEscudera.setBounds(49, 202, 56, 16);
		add(lblEscudera);
		
		JLabel lblNombre = new JLabel("Nombre");
		lblNombre.setBounds(316, 61, 56, 16);
		add(lblNombre);
		
		JLabel lblNacionalidad = new JLabel("Nacionalidad");
		lblNacionalidad.setBounds(316, 133, 72, 16);
		add(lblNacionalidad);
		
		btnGuardar = new JButton("Guardar Datos");
		btnGuardar.setBounds(143, 335, 123, 25);
		add(btnGuardar);
		
		btnVolver = new JButton("Volver");
		btnVolver.setBounds(359, 335, 111, 25);
		add(btnVolver);
		
		spnNum = new JSpinner();
		spnNum.setEnabled(false);
		spnNum.setBounds(117, 58, 42, 25);
		add(spnNum);
		
		spnEdad = new JSpinner();
		spnEdad.setBounds(117, 130, 42, 22);
		add(spnEdad);
		
		txtNombre = new JTextField();
		txtNombre.setEnabled(false);
		txtNombre.setEditable(false);
		txtNombre.setBounds(384, 58, 116, 22);
		add(txtNombre);
		txtNombre.setColumns(10);
		
		txtNacionalidad = new JTextField();
		txtNacionalidad.setBounds(405, 130, 168, 22);
		add(txtNacionalidad);
		txtNacionalidad.setColumns(10);
		
		txtEscuderia = new JTextField();
		txtEscuderia.setBounds(117, 199, 149, 22);
		add(txtEscuderia);
		txtEscuderia.setColumns(10);	
	}
	
public void setControlador(ControladorPilotos control) {
		
		btnGuardar.addActionListener(control);
		btnVolver.addActionListener(control);

	}

public void hacerVisible() {
	setVisible(true);
}
public void hacerInvisible() {
	setVisible(false);
}
public JTextField getTxtNombre() {
	return txtNombre;
}
public JTextField getTxtNacionalidad() {
	return txtNacionalidad;
}
public JTextField getTxtEscuderia() {
	return txtEscuderia;
}
public JSpinner getSpnNum() {
	return spnNum;
}
public JSpinner getSpnEdad() {
	return spnEdad;
}
public JButton getBtnGuardar() {
	return btnGuardar;
}
public JButton getBtnVolver() {
	return btnVolver;
}

}
