package vista;

import javax.swing.JFrame;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.HeadlessException;
import java.awt.Toolkit;

import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JTextArea;
import javax.swing.UIManager;

import controlador.ControladorPilotos;



public class VistaPrincipal extends JFrame {
	private JMenuBar menuBar;
	private JMenuItem menuRegistrar;
	private JMenuItem menuConsultar;
	private JMenuItem menuSalir;

	// DECLARO EL OBJETO DEL JPANEL DEL PANEL DE INSERTAR (mas abajo tiene su
	// getter)
	private VistaConsultar vCons;
	private VistaModificar vMod;
	private VistaRegistrar vReg;

	public VistaPrincipal(String titulo, VistaConsultar vCons, VistaModificar vMod, VistaRegistrar vReg)
			throws HeadlessException {
		super(titulo);
		// CREAR EL OBJETO DEL JPANEL DEL PANEL DE INSERTAR QUE YA ESTABA DECLARADO
		this.vCons = vCons;
		this.vMod = vMod;
		this.vReg = vReg;

		inicializar();
	}

	public void inicializar() {
		try {
			UIManager.setLookAndFeel(UIManager.getCrossPlatformLookAndFeelClassName());
		} catch (Exception e) {
			e.printStackTrace();
		}

		setTitle("GESTI\u00D3N DE PILOTOS");
		getContentPane().setLayout(new BorderLayout(0, 0));

		menuBar = new JMenuBar();
		setJMenuBar(menuBar);

		menuRegistrar = new JMenuItem("Registrar Pilotos");
		menuBar.add(menuRegistrar);

		menuConsultar = new JMenuItem("Concultar Pilotos");
		menuBar.add(menuConsultar);

		menuSalir = new JMenuItem("Salir");
		menuBar.add(menuSalir);

		// asignamos tama�o a la ventana
		setPreferredSize(new Dimension(450, 400));

		// Se obtienen las dimensiones en pixels de la pantalla.
		Dimension pantalla = Toolkit.getDefaultToolkit().getScreenSize();

		// Se obtienen las dimensiones en pixels de la ventana.
		Dimension ventana = this.getPreferredSize();

		// Una cuenta para situar la ventana en el centro de la pantalla.
		setLocation((pantalla.width - ventana.width) / 2, (pantalla.height - ventana.height) / 2);
		
		// A�ADO EL OBJETO DEL JPANEL DEL PANEL DE INSERTAR A ESTA VENTANA
		getContentPane().add(vCons);
		getContentPane().add(vMod);
		getContentPane().add(vReg);
		
		// Y LO HAGO INVISIBLE
		vCons.setVisible(false);
		vMod.setVisible(false);
		vReg.setVisible(false);

	}
	public void hacerVisible() {
		pack();
		setVisible(true);
	}
	public void setControlador(ControladorPilotos control) {
		menuConsultar.addActionListener(control);
		menuRegistrar.addActionListener(control);
		menuSalir.addActionListener(control);
	}

	public JMenuItem getMenuRegistrar() {
		return menuRegistrar;
	}

	public JMenuItem getMenuConsultar() {
		return menuConsultar;
	}

	public JMenuItem getMenuSalir() {
		return menuSalir;
	}
	
}
