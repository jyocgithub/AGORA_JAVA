package model;

public class Piloto {
private String numero;
private String nombre;
private String nacionalidad;
private String edad;
private String escuderia;

public Piloto(String numero, String nombre, String nacionalidad, String edad, String escuderia) {
	this.numero = numero;
	this.nombre = nombre;
	this.nacionalidad = nacionalidad;
	this.edad = edad;
	this.escuderia = escuderia;
}

public String getNumero() {
	return numero;
}

public String getNombre() {
	return nombre;
}

public String getNacionalidad() {
	return nacionalidad;
}

public String getEdad() {
	return edad;
}

public String getEscuderia() {
	return escuderia;
}




}
