package controlador;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.ArrayList;

import javax.swing.JOptionPane;

import accesoDB.PilotoPersistencia;
import model.Piloto;
import vista.VistaConsultar;
import vista.VistaModificar;
import vista.VistaPrincipal;
import vista.VistaRegistrar;

public class ControladorPilotos implements ActionListener, MouseListener {

	private VistaConsultar vCons;
	private PilotoPersistencia pt;
	private VistaPrincipal vPrin;
	private VistaModificar vMod;
	private VistaRegistrar vReg;

	public ControladorPilotos(VistaConsultar vCons, VistaPrincipal vPrin, VistaModificar vMod, VistaRegistrar vReg) {
		this.vCons = vCons;
		this.vPrin = vPrin;
		this.vMod = vMod;
		this.vReg = vReg;
		pt = new PilotoPersistencia();
	}

	@Override
	public void actionPerformed(ActionEvent accion) {

		// BOTON menu principal
		if (accion.getSource().equals(vPrin.getMenuRegistrar())) {
			vReg.hacerVisible();
			vCons.hacerInvisible();
			vMod.hacerInvisible();

		}

		// BOTON menu principal
		if (accion.getSource().equals(vPrin.getMenuConsultar())) {
			vReg.hacerInvisible();
			vCons.hacerVisible();
			vMod.hacerInvisible();

		}

		// BOTON menu principal
		if (accion.getSource().equals(vPrin.getMenuSalir())) {
			int codigo = JOptionPane.showConfirmDialog(null, "Realmente desea salir?", "SALIR",
					JOptionPane.YES_NO_OPTION, 0);
			if (codigo == JOptionPane.YES_OPTION) {
				System.exit(0);
			}

		}

		// BOTON guardaR datos DESDE VENTANA INSERTAR
		if (accion.getSource().equals(vReg.getBtnGuardarDatos())) {
			String num = (String) vReg.getSpnNum().getValue();
			String nom = vReg.getTxtNombre().getText();
			String edad = (String) vReg.getSpnEdad().getValue();
			String nacion = vReg.getTxtNacionalidad().getText();
			String escud = vReg.getTxtEscuderia().getText();

			if (Integer.parseInt(num) < 0) {
				JOptionPane.showMessageDialog(null, "EL n�mero no puede ser menor que cero");
				return;
			}

			Piloto pilot = new Piloto(num, nom, edad, nacion, escud);
			pt.insertarPiloto(pilot);

		}
		// Boton limpiar
		if (accion.getSource().equals(vReg.getBtnGuardarDatos())) {
			vReg.getSpnNum().setValue(0);
			vReg.getTxtNombre().setText("");
			vReg.getSpnEdad().setValue(0);
			vReg.getTxtNacionalidad().setText("");
			vReg.getTxtEscuderia().setText("");
		}
		// Boton modificar

		if (accion.getSource().equals(vCons.getBtnModificarPiloto())) {
			vReg.hacerInvisible();
			vCons.hacerInvisible();
			vMod.hacerVisible();

			// rellenar los campos con los datos del alumno seleccionado en la tabla
			int[] filasSel = vCons.getTabla().getSelectedRows();

			String num = "";
			String nom = "";
			String nac = "";
			String edad = "";
			String escud = "";

			// el valor 0 del getValueAt(filasSel[0] es por que solo modifico el primer
			// piloto de los seleccionados
			num = (String) vCons.getTabla().getModel().getValueAt(filasSel[0], 0);
			nom = (String) vCons.getTabla().getModel().getValueAt(filasSel[0], 1);
			nac = (String) vCons.getTabla().getModel().getValueAt(filasSel[0], 2);
			edad = (String) vCons.getTabla().getModel().getValueAt(filasSel[0], 3);
			escud = (String) vCons.getTabla().getModel().getValueAt(filasSel[0], 4);

			vMod.getSpnNum().setValue(num);
			vMod.getTxtNombre().setText(nom);
			vMod.getTxtNacionalidad().setText(nac);
			vMod.getSpnEdad().setValue(edad);
			vMod.getTxtEscuderia().setText(escud);

		}

		// BOTON guardar datos DESDE VENTANA MODIFICAR
		if (accion.getSource().equals(vMod.getBtnGuardar())) {
			String num = (String) vMod.getSpnNum().getValue();
			String nom = vMod.getTxtNombre().getText();
			String nac = vMod.getTxtNacionalidad().getText();
			String edad = (String) vMod.getSpnEdad().getValue();
			String escud = vMod.getTxtEscuderia().getText();
			Piloto pilot = new Piloto(num, nom, nac, edad, escud);
			pt.modificarPiloto(pilot);
			vCons.cargarTabla();
		}

		// BOTON VOLVER DESDE VENTANA modificar
		if (accion.getSource().equals(vMod.getBtnVolver())) {
			vMod.setVisible(false);
			vCons.hacerVisible();
		}
		// BOTON ELIMINAR DESDE concultas
		if (accion.getSource().equals(vCons.getBtnBorrarPiloto())) {
			// TODO Recoger los pilotos seleccionados y eliminarlo uno a uno
			ArrayList<Piloto> listaPilotosSel = new ArrayList<>();
			int[] filasSel = vCons.getTabla().getSelectedRows();
			Piloto piloto = null;
			String num = "";
			String nom = "";
			String nac = "";
			String edad = "";
			String escud = "";
			for (int i = 0; i < filasSel.length; i++) {
				num = (String) vCons.getTabla().getModel().getValueAt(filasSel[i], 0);
				nom = (String) vCons.getTabla().getModel().getValueAt(filasSel[i], 1);
				nac = (String) vCons.getTabla().getModel().getValueAt(filasSel[i], 2);
				edad = (String) vCons.getTabla().getModel().getValueAt(filasSel[i], 3);
				edad = (String) vCons.getTabla().getModel().getValueAt(filasSel[i], 4);
				piloto = new Piloto(num, nom, nac, edad, escud);
				listaPilotosSel.add(piloto);
			}

			String msg = "";
			for (Piloto pil : listaPilotosSel) {
				msg = pt.borrarPilotoPorNum(pil.getNumero());
				JOptionPane.showMessageDialog(vCons, "Resultado de borrar el piloto " + pil.getNumero() + ": " + msg,
						"Resultado de la acci�n", JOptionPane.INFORMATION_MESSAGE);
			}
			vCons.cargarTabla();
		}
	}

	@Override
	// NOP HACER ENABLED EL BOTON SIN TENER SELECCIONADA NINGUNA FILA

	public void mouseClicked(MouseEvent e) {
		int[] filasSel = vCons.getTabla().getSelectedRows();
		if (filasSel.length > 0) {
			vCons.getBtnBorrarPiloto().setEnabled(true);
		} else {
			vCons.getBtnBorrarPiloto().setEnabled(false);
		}
	}

	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub

	}

}
