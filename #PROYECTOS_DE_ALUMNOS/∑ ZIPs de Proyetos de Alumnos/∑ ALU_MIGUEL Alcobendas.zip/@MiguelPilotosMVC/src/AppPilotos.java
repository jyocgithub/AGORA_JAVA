import java.awt.EventQueue;

import controlador.ControladorPilotos;
import vista.VistaConsultar;
import vista.VistaModificar;
import vista.VistaPrincipal;
import vista.VistaRegistrar;

public class AppPilotos {

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {

			@Override
			public void run() {
				VistaConsultar vCons = new VistaConsultar();
				VistaModificar vMod = new VistaModificar();
				VistaRegistrar vReg = new VistaRegistrar();
				VistaPrincipal vPrin = new VistaPrincipal("Gesti�n de pilotos", vCons, vMod, vReg);

				ControladorPilotos control = new ControladorPilotos(vCons, vPrin, vMod, vReg);

				vCons.setControlador(control);
				vReg.setControlador(control);
				vMod.setControlador(control);
				vPrin.setControlador(control);
				vPrin.hacerVisible();
			}
		});

	}

}
