package accesoDB;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;


import model.Piloto;

public class PilotoPersistencia {

	private AccesoDB acceso;

	public PilotoPersistencia() {
		acceso = new AccesoDB();
	}

	public ArrayList<Piloto> consultaPilotos() {
		Connection con = null;
		Statement stmt = null;
		ResultSet rslt = null;
		ArrayList<Piloto> listaPilotos = new ArrayList<Piloto>();

		try {
			con = acceso.getConexion();

			stmt = con.createStatement();
			String query = "SELECT * FROM PILOTO";

			rslt = stmt.executeQuery(query);

			String num = "";
			String nomb = "";
			String nacional = "";
			String edad = "";
			String escud = "";
			Piloto piloto = null;
			while (rslt.next()) {
				num = rslt.getString(1);
				nomb = rslt.getString(2);
				nacional = rslt.getString(3);
				edad = rslt.getString(4);
				escud = rslt.getString(5);
				piloto = new Piloto(num, nomb, nacional, edad, escud);
				listaPilotos.add(piloto);

			}

		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if (rslt != null)
					rslt.close();

				if (stmt != null)
					stmt.close();

				if (con != null)
					con.close();

			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

		return listaPilotos;
	}

	// m�todo que elimina un piloto
	// mensaje con el resultado de la acci�n
	public String borrarPilotoPorNum(String num) {
		String res = "";
		int iRes = 0;
		Connection con = null;
		PreparedStatement pstmt = null;

		try {
			con = acceso.getConexion();

			String query = "DELETE FROM PILOTO WHERE NUMERO = ?";
			pstmt = con.prepareStatement(query);
			pstmt.setString(1, num);

			iRes = pstmt.executeUpdate();

			if (iRes > 0) {
				res = "Se ha eliminado el piloto ";
			}

		} catch (ClassNotFoundException e) {
			// e.printStackTrace();
			res = "No se ha podido establecer la conexi�n con la base de datos";
		} catch (SQLException e) {
			// e.printStackTrace();
			res = "No se ha podido realizar la acci�n por un error SQl";
		} finally {
			try {
				if (pstmt != null)
					pstmt.close();

				if (con != null)
					con.close();

			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

		return res;
	}

	// m�todo que inserta un piloto
	// mensaje con el resultado de la acci�n
	public String insertarPiloto(Piloto pilotoAInsertar) {
		String res = "";
		int iRes = 0;
		Connection con = null;
		PreparedStatement pstmt = null;

		try {
			con = acceso.getConexion();

			String query = "INSERT INTO PILOTO VALUES(?,?,?,?,?)";
			pstmt = con.prepareStatement(query);

			pstmt.setString(1, pilotoAInsertar.getNumero());
			pstmt.setString(2, pilotoAInsertar.getNombre());
			pstmt.setString(3, pilotoAInsertar.getNacionalidad());
			pstmt.setString(4, pilotoAInsertar.getEdad());
			pstmt.setString(5, pilotoAInsertar.getEscuderia());

			iRes = pstmt.executeUpdate();

			if (iRes > 0) {
				res = "Se ha insertado el piloto ";
			}

		} catch (ClassNotFoundException e) {
			// e.printStackTrace();
			res = "No se ha podido establecer la conexi�n con la base de datos";
		} catch (SQLException e) {
			// e.printStackTrace();
			res = "No se ha podido realizar la acci�n por un error SQl";
		} finally {
			try {
				if (pstmt != null)
					pstmt.close();

				if (con != null)
					con.close();

			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

		return res;
	}

	// m�todo que inserta un piloto
	// mensaje con el resultado de la acci�n
	public String modificarPiloto(Piloto pilotoAModificar) {
		String res = "";
		int iRes = 0;
		Connection con = null;
		PreparedStatement pstmt = null;

		try {
			con = acceso.getConexion();
			String query = "UPDATE PILOTO SET NOMBRE=?, NACIONALIDAD=?, EDAD=?, ESCUDERIA=? WHERE NUMERO=?";
			pstmt = con.prepareStatement(query);

			pstmt.setString(1, pilotoAModificar.getNumero());
			pstmt.setString(2, pilotoAModificar.getNombre());
			pstmt.setString(3, pilotoAModificar.getNacionalidad());
			pstmt.setString(4, pilotoAModificar.getEdad());
			pstmt.setString(4, pilotoAModificar.getEscuderia());


			iRes = pstmt.executeUpdate();

			if (iRes > 0) {
				res = "Se ha modificado el piloto ";
			}

		} catch (ClassNotFoundException e) {
			// e.printStackTrace();
			res = "No se ha podido establecer la conexi�n con la base de datos";
		} catch (SQLException e) {
			// e.printStackTrace();
			res = "No se ha podido realizar la acci�n por un error SQl";
		} finally {
			try {
				if (pstmt != null)
					pstmt.close();

				if (con != null)
					con.close();

			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

		return res;
	}

}
