package CARLOS_Agenda.clases;

public class Correo {
	private int idCorreo;
	private String textoCorreo;
	
	public Correo(int idCorreo, String nombreCorreo) {
		this.idCorreo = idCorreo;
		this.textoCorreo = nombreCorreo;
	}

	public int getIdCorreo() {
		return idCorreo;
	}

	public void setIdCorreo(int idCorreo) {
		this.idCorreo = idCorreo;
	}

	public String getTextoCorreo() {
		return textoCorreo;
	}

	public void setTextoCorreo(String nombreCorreo) {
		this.textoCorreo = nombreCorreo;
	}
	
}
