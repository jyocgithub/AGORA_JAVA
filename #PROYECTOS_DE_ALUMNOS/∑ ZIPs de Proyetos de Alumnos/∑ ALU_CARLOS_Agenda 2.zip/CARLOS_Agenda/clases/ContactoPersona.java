package CARLOS_Agenda.clases;

import java.util.ArrayList;

public class ContactoPersona extends Contacto {
	private String nombre;
	private String apellidos;
	private String sexo;
	
	
	
	public ContactoPersona() {}
	
	
	public ContactoPersona(int idContacto, TipoContacto tipoContacto, ArrayList<Telefono> listaTelefonos,
			ArrayList<Correo> listaCorreos, ArrayList<Aficion> listaAficiones, String notas, String nombre,
			String apellidos, String sexo) {
		super(idContacto, tipoContacto, listaTelefonos, listaCorreos, listaAficiones, notas);
		this.nombre = nombre;
		this.apellidos = apellidos;
		this.sexo = sexo;
	}

	
	

	public String getNombre() {
		return nombre;
	}




	public void setNombre(String nombre) {
		this.nombre = nombre;
	}




	public String getApellidos() {
		return apellidos;
	}

	public void setApellidos(String apellidos) {
		this.apellidos = apellidos;
	}

	public String getSexo() {
		return sexo;
	}

	public void setSexo(String sexo) {
		this.sexo = sexo;
	}

	@Override
	public String toString() {
		return "ContactoPersona [apellidos=" + apellidos + ", sexo=" + sexo + ", getIdContacto()=" + getIdContacto()
				+ ", getNombre()=" + getNombre() + ", getTipoContacto()=" + getTipoContacto() + ", getListaTelefonos()="
				+ getListaTelefonos() + ", getListaCorreos()=" + getListaCorreos() + ", getListaAficiones()="
				+ getListaAficiones() + ", getNotas()=" + getNotas() + "]";
	}


	
	
	
	


	
	
}
