package CARLOS_Agenda.clases;

import java.util.ArrayList;

public class ContactoApodo extends Contacto {
	
	private String sexo;
	private String apodo;
	
	public ContactoApodo() {}

	public ContactoApodo(int idContacto, TipoContacto tipoContacto, ArrayList<Telefono> listaTelefonos,
			ArrayList<Correo> listaCorreos, ArrayList<Aficion> listaAficiones, String notas, String sexo,
			String apodo) {
		super(idContacto, tipoContacto, listaTelefonos, listaCorreos, listaAficiones, notas);
		this.sexo = sexo;
		this.apodo = apodo;
	}



	public String getSexo() {
		return sexo;
	}



	public void setSexo(String sexo) {
		this.sexo = sexo;
	}

	
	


	public String getApodo() {
		return apodo;
	}



	public void setApodo(String apodo) {
		this.apodo = apodo;
	}



	@Override
	public String toString() {
		return "ContactoApodo [getIdContacto()=" + getIdContacto() +" sexo  " +sexo+
				 ", getTipoContacto()=" + getTipoContacto() + ", getListaTelefonos()=" + getListaTelefonos()
				+ ", getListaCorreos()=" + getListaCorreos() + ", getListaAficiones()=" + getListaAficiones()
				+ ", getNotas()=" + getNotas() + "]";
	}



	


	
	
	
	

	
	
	
}
