package CARLOS_Agenda.clases;
//tabla maestra
public class Aficion {
	private int IdAficion;
	private String NombreAficion;

	public Aficion(int idAficion, String nombreAficion) {
		IdAficion = idAficion;
		NombreAficion = nombreAficion;
	}

	public int getIdAficion() {
		return IdAficion;
	}

	public void setIdAficion(int idAficion) {
		IdAficion = idAficion;
	}

	public String getNombreAficion() {
		return NombreAficion;
	}

	public void setNombreAficion(String nombreAficion) {
		NombreAficion = nombreAficion;
	}

}
