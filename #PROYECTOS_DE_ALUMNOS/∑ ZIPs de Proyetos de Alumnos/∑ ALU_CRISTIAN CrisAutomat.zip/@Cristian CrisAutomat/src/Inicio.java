import static java.lang.System.exit;

import java.util.Scanner;


public class Inicio {

	String lexema = "";
	int numEstados = 0;
	String datosMatriz = "";
	int numero = 0;
	boolean seguir = true;

	public static void main(String[] args) {
		new Inicio().iniciar();
	}

	public void iniciar() {

		System.out.println("Dime numero de estados del AFD");
		numEstados = new Scanner(System.in).nextInt();

		System.out.println("Introduce la matriz separando cada elemento por coma (,) Fila,comlumna,valor ");
		datosMatriz = new Scanner(System.in).nextLine();

		Automata automata = new Automata(numEstados, datosMatriz);

		while (seguir) {
			System.out.println("Introduce un estado final. -1 para abandonar bucle");
			numero = new Scanner(System.in).nextInt();
			if (numero == -1) {
				seguir = false;
			} else {
				automata.añadirEstadosFinales(numero);
				System.out.println("El numero " + numero + " ahora es una estado final.");
			}
		}

		automata.pintarMatriz();

		seguir = true;
		while (seguir) {
			System.out.println("Esperando lexema .... ");
			lexema = new Scanner(System.in).nextLine();
			if (lexema.isEmpty()) {
				seguir = false;
			} else {
				if (automata.comprobarLexema(lexema)) {
					System.out.println("El lexema " + lexema + " introducido es correcto");
					System.out.println();
				} else {
					System.out.println("El lexema " + lexema + " introducido es erroneo");
					System.out.println();
				}
			}
		}

		System.out.println("Pulse 0 para generar cadenas, cualquier otro para terminar");
		if (new Scanner(System.in).nextInt() == 0) {
			System.out.println("Introduce cantidad de cadenas a generar");
			int cantidad = new Scanner(System.in).nextInt();
			System.out.println("Introduce la longitud maxima de las cadenas");
			int longitud = new Scanner(System.in).nextInt();
			automata.generarCadenas(cantidad, longitud);

		} else {
			exit(0);
		}

	}
}
