import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Clase Automata. Controla los lexemas y cadenas que corresponden con una ER.
 */
public class Automata {

    List<Integer> estadosFinales; // Array que contiene los estados finales
    List<String> cadenasGeneradas; // Array que contiene las cadenas generadas que cumplen la ER

    int numEstados; // Cantidad de estados en total
    String datosMatriz; // Datos de la matriz para introducirlos como un String

    // Mapa que tiene numero de fila y para cada fila un mapa.
    // Ese mapa de dentro tiene el caracter de la columna y el integer que es el contenido de dentro
    HashMap<Integer, HashMap<Character, Integer>> matriz = new HashMap<>();

    public void recorrer(int fila, int indiceActual, int maximaLongitud, String cad) {
        if (indiceActual > maximaLongitud) return;
        HashMap<Character, Integer> filaactual = matriz.get(fila);
        for (int colum = 0; colum < filaactual.values().size(); colum++) {
//			if (estadosFinales.contains(fila)){
//				if(!cadenasGeneradas.contains(cad)){
//					cadenasGeneradas.add(cad);
//				}
//			}

            char letra = ((char) (97 + colum));
            int valor = filaactual.get(letra);

            if (valor != -1) {
                cad = cad + ((char) (97 + colum));
                if (estadosFinales.contains(valor))
                    if (!cadenasGeneradas.contains(cad)) {
                        cadenasGeneradas.add(cad);
                    }
                recorrer(valor, indiceActual + 1, maximaLongitud, cad);
                cad = cad.substring(0, cad.length() - 1);
            }
        }
    }

    /**
     * Constructor de la clase Automata.
     *
     * @param numEstados  : int
     * @param datosMatriz : String
     */
    public Automata(int numEstados, String datosMatriz) {
        this.numEstados = numEstados;
        this.datosMatriz = datosMatriz;
        estadosFinales = new ArrayList<>();
        cadenasGeneradas = new ArrayList<>();
        inializarMatriz();
        cargarMatriz();

    }

    // MÉTODOS REFERENTES A LOS ESTADOS:
    // *************************************************************************
    // *************************************************************************

    /**
     * Método que añade en un array los estados finales.
     *
     * @param numero : int
     */
    public void añadirEstadosFinales(int numero) {
        if (!estadosFinales.contains(numero)) {
            estadosFinales.add(numero);
        }
    }

    /**
     * Método que comprueba el estado actual y devuelve el siguiente en caso de ser distinto de -1
     *
     * @param estadoActual : int
     * @param letra        : char
     * @return res : int
     */
    public int buscarSiguienteEstado(int estadoActual, char letra) {
        int res = -1;
        HashMap<Character, Integer> aux = matriz.get(estadoActual);
        if (aux.containsKey(letra)) {
            res = aux.get(letra);
        }
        return res;
    }

    /**
     * Método que comprueba si un estado se encuentra en la lista de finales.
     *
     * @param estadoActual : int
     * @return sol : boolean
     */
    public boolean esEstadoFinal(int estadoActual) {
        boolean sol = false;
        if (estadosFinales.contains(estadoActual)) {
            sol = true;
        }
        return sol;
    }

    // MÉTODOS REFERENTES A LA MATRÍZ:
    // *************************************************************************
    // *************************************************************************

    /**
     * Metodo que crea un HashMap que contiene el alfabeto para almacenar contenidos. Rellenamos con -1 todas las posiciones
     *
     * @return modeloFila : HashMap
     */
    public HashMap<Character, Integer> crearModeloFila() {
        HashMap<Character, Integer> modeloFila = new HashMap<>();
        // Crear hashMap patron de cada fila
        for (int i = 0; i < 26; i++) {
            modeloFila.put((char) (97 + i), -1);
        }
        return modeloFila;
    }

    /**
     * Método que crea los HashMap que contienen el Integer del indice y dentro se llama a otro metodo para crear otro HashMap en
     * cada posicion.
     */
    public void inializarMatriz() {
        for (int i = 0; i < numEstados; i++) {
            matriz.put(i, crearModeloFila());
        }
    }

    /**
     * Método que rellena la matriz con los datos introducidos. Partimos de una cadena (datosMatriz)
     * "0,a,1,0,b,2,1,b,2,2,c,3,3,d,4,4,e,5,5,d,4" Dicha cadena la troceamos en trozos de 3 "0,a,1" Fila,Columna,Contenido
     * Procedemos a buscar la fila y la columna en la cual tenemos que insertar el contenido
     */
    public void cargarMatriz() {
        String[] trozos;
        trozos = datosMatriz.split(",");
        int x = 0;
        int numFila = 0;
        for (int i = 0; i < trozos.length / 3; i++) {
            HashMap<Character, Integer> lafila = matriz.get(Integer.parseInt(trozos[x]));
            lafila.put(trozos[x + 1].charAt(0), Integer.parseInt(trozos[x + 2]));
            x = x + 3;
        }
    }

    // MÉTODO REFERENTE A LA COMPROBACION DEL LEXEMA:
    // *************************************************************************
    // *************************************************************************

    /**
     * Metodo que se encarga de comprobar si un lexema es correcto o erroneo.
     *
     * @param lexema : String
     * @return res : boolean
     */
    public boolean comprobarLexema(String lexema) {
        boolean res = false;
        char letra;
        int estadoActual = 0;
        int siguienteEstado;

        for (int j = 0; j < lexema.length(); j++) {
            letra = lexema.charAt(j);
            if (estadoActual != -1) {
                siguienteEstado = buscarSiguienteEstado(estadoActual, letra);
                estadoActual = siguienteEstado;
            }
        }
        if (estadoActual != -1) {
            if (esEstadoFinal(estadoActual)) {
                res = true;
            }
        }
        return res;
    }

    // MÉTODOS REFERENTES A LA CREACION DE CADENAS:
    // *************************************************************************
    // *************************************************************************

    /**
     * Método que llama a buscarLetra y pinta las cadenas del array.
     *
     * @param cantidad : int
     * @param longitud : int
     */
    public void generarCadenas(int cantidad, int longitud) {
        int estadoInicial = 0;
        int indice = cantidad;
        System.out.println("Generando cadenas de longitud maxima: " + longitud);

        // buscarLetra(estadoInicial, 0, longitud, "");
        recorrer(estadoInicial, 0, longitud, "");

        if (cantidad > cadenasGeneradas.size()) {
            indice = cadenasGeneradas.size();
            System.out.println("No se han podido generar " + cantidad + " cadenas, la ER con longitud " + longitud
                    + " permite " + indice);
        }

        for (int i = 0; i < indice; i++) {
            System.out.println(i + " - " + cadenasGeneradas.get(i));
        }

    }

    /**
     * Método con llamadas recursivas que concatena letras. En cuanto encuentra una candidata la agrega al array de cadenas. Obtengo
     * cada fila de la matriz y la recorro con un for-each. Compruebo si son estados finales y si estoy dentro del limite
     * establecito para la cadena.
     *
     * @param estadoActual  : int
     * @param indiceActual  : int
     * @param cantidadFinal : int
     * @param cadena        : String
     */
    public void buscarLetra(int estadoActual, int indiceActual, int cantidadFinal, String cadena) {

        HashMap<Character, Integer> filaEstadoActual = matriz.get(estadoActual);
        for (Map.Entry<Character, Integer> mapa : filaEstadoActual.entrySet()) {
            if (esEstadoFinal(estadoActual) && (indiceActual <= cantidadFinal)) {
                if (!cadenasGeneradas.contains(cadena)) {
                    cadenasGeneradas.add(cadena);
                }
                if (indiceActual < cantidadFinal) {
                    if (mapa.getValue() != -1) {
                        cadena = cadena + mapa.getKey();
                        buscarLetra(mapa.getValue(), indiceActual + 1, cantidadFinal, cadena);
                        cadena = cadena.substring(0, cadena.length() - 1);
                    }
                }
            }
            if (!esEstadoFinal(estadoActual) && (indiceActual == cantidadFinal)) {
                return;
            } else if ((esEstadoFinal(estadoActual) && (indiceActual != cantidadFinal))) {
                return;
            } else {
                if (mapa.getValue() != -1) {
                    cadena = cadena + mapa.getKey();
                    buscarLetra(mapa.getValue(), indiceActual + 1, cantidadFinal, cadena);
                    cadena = cadena.substring(0, cadena.length() - 1);
                }
            }
        }

    }

    // MÉTODOS REFERENTES A PINTAR:
    // *************************************************************************
    // *************************************************************************

    /**
     * Metodo que pinta la matriz
     */
    public void pintarMatriz() {

        for (int i = 0; i < numEstados; i++) {
            System.out.print(i + "\t");
            HashMap<Character, Integer> lafila = matriz.get(i);
            for (Integer x : lafila.values()) {
                if (x != -1)
                    System.out.print(x + "\t");
                else
                    System.out.print("\t");
            }
            System.out.println();
        }
    }

    /*
     * public void buscarLetra(int estadoActual, int indiceActual, int cantidadFinal, String cadena) { if (indiceActual >
     * cantidadFinal) return;
     *
     * HashMap<Character, Integer> filaEstadoActual = matriz.get(estadoActual); for (Map.Entry<Character, Integer> mapa :
     * filaEstadoActual.entrySet()) { int valor = mapa.getValue(); if (valor != -1) { cadena = cadena + mapa.getKey(); if
     * (esEstadoFinal(estadoActual))// cadenasGeneradas.add(cadena); buscarLetra(valor, indiceActual + 1, cantidadFinal, cadena);
     * cadena = cadena.substring(0, cadena.length() - 1); } } }
     */

}
