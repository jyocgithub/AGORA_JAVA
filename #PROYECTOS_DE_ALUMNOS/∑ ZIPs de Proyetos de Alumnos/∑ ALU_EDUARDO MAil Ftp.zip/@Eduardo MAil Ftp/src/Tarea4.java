
import java.util.*;

import java.io.*;

public class Tarea4 {

	public static void main(String[] args) {

		// ----------------------------------------------------------------- FTP

		// ------------- FTP
		String servidorftp = "ftp.jyoc.heliohost.org";
		String usuarioftp = "ftp1@jyoc.heliohost.org";
		String passwordftp = "cambiarestapassword";

		MiFTPJava miftp = new MiFTPJava(servidorftp);

		// conectar el ftp
		miftp.conectar();
		// login
		miftp.login(usuarioftp, passwordftp);
		// subir el fichero con los correos
		miftp.subirFichero("correos.txt", "correossubido.txt");
		// bajar el fichero con los correos
		miftp.bajarFichero("correossubido.txt", "correos2.txt");
		// desconectar el ftp
		miftp.desconectar();

		// ----------------------------------------------------------------- SMTP

		// leer el fichero de correos y almacenarlo en un arraylist
		ArrayList<String> lista = new ArrayList<>();
		BufferedReader br = null;
		try {
			br = new BufferedReader(new FileReader("correos2.txt"));
			String linea = br.readLine();
			while (linea != null) {
				lista.add(linea);
				linea = br.readLine();
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				br.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}

		// variables de envio de correos
		String servidor = "smtp.gmail.com";
		String usuario = "origen@gmail.com";
		String asunto = "Correo de la Tarea 4";
		String mensaje = "Este es el cuerpo del mensaje";
		Scanner sc = new Scanner(System.in);

		// pedir la contraseña del servidor de correo
		System.out.println("Por seguridad no guardamos la password en el código");
		System.out.println("Por favor, indique ahora la passwoed de la cuenta de correo '" + usuario + "' :");
		String password = sc.nextLine();

		MiCorreoJava micorreojava = new MiCorreoJava(servidor, usuario, password);

		// recorrer la lista de correos
		for (String correo : lista) {
			// enviar cada correo
			micorreojava.enviarMensaje(correo, asunto, mensaje);
		}

		sc.close();
	}

}
