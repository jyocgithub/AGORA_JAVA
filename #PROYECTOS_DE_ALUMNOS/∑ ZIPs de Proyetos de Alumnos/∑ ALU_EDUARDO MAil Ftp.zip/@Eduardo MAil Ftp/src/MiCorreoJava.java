import java.io.IOException;
import java.io.Writer;

import javax.net.ssl.KeyManager;
import javax.net.ssl.KeyManagerFactory;

import org.apache.commons.net.smtp.AuthenticatingSMTPClient;
import org.apache.commons.net.smtp.AuthenticatingSMTPClient.AUTH_METHOD;
import org.apache.commons.net.smtp.SMTPReply;
import org.apache.commons.net.smtp.SimpleSMTPHeader;

public class MiCorreoJava {

	String servidor;
	String usuario;
	String password;

	public MiCorreoJava(String servidor, String usuario, String password) {
		super();
		this.servidor = servidor;
		this.usuario = usuario;
		this.password = password;
	}

	public int enviarMensaje(String maildestinio, String asunto, String mensaje) {
		int puerto = 587;
		int respuesta;

		AuthenticatingSMTPClient cliente = new AuthenticatingSMTPClient();

		try {

			KeyManagerFactory kmf = KeyManagerFactory.getInstance(KeyManagerFactory.getDefaultAlgorithm());
			kmf.init(null, null);
			KeyManager km = kmf.getKeyManagers()[0];
			cliente.connect(servidor, puerto);

			System.out.println("1. " + cliente.getReplyString());
			cliente.setKeyManager(km);

			respuesta = cliente.getReplyCode();
			if (!SMTPReply.isPositiveCompletion(respuesta)) {
				cliente.disconnect();
				System.out.println("El servicor SMTP ha rechazado la conexion");
				return 0;
			}

			cliente.ehlo(servidor);
			System.out.println("2. " + cliente.getReplyString());

			// el metoxo execTLS() inica la sesion TLS ( del protocolo de seguridad, en la capa de transporte)
			// internamente ejecuta un STARTTLS
			boolean exitoTLS = cliente.execTLS();
			if (!exitoTLS) {
				System.out.println("Fallo al intentar TLS");
				return 1;
			}

			System.out.println("3. " + cliente.getReplyString());
			if (!cliente.auth(AUTH_METHOD.XOAUTH.LOGIN, usuario, password)) {
				System.out.println("Fallo al intentar autenticacion");
				return 2;
			}

			System.out.println("4. " + cliente.getReplyString());

			// cabecera
			SimpleSMTPHeader cabecera = new SimpleSMTPHeader(usuario, maildestinio, asunto);
			cliente.setSender(usuario);
			cliente.addRecipient(maildestinio);
			System.out.println("5. " + cliente.getReplyString());

			// envio
			Writer writer = cliente.sendMessageData();

			if (writer == null) {
				System.out.println("Error al enviar mensaje");
				System.exit(3);
			}
			writer.write(cabecera.toString());
			writer.write(mensaje);
			writer.close();

			System.out.println("6. " + cliente.getReplyString());

			boolean exitosend = cliente.completePendingCommand();
			System.out.println("7. " + cliente.getReplyString());

			if (!exitosend) {
				System.out.println("Error al terminar envio");
				System.exit(4);
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (cliente != null) cliente.disconnect();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		return 0;

	}

}
