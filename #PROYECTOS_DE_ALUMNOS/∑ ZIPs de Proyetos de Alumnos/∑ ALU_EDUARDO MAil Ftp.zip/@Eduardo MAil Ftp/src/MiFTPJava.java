
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.SocketException;

import org.apache.commons.net.ftp.FTP;
import org.apache.commons.net.ftp.FTPClient;

public class MiFTPJava {

	FTPClient ftpcliente;
	String servidor;

	public MiFTPJava(String servidor) {
		this.servidor = servidor;
		ftpcliente = new FTPClient();
	}

	public void conectar() {
		try {
			ftpcliente.connect(servidor);
		} catch (SocketException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public void desconectar() {
		try {
			ftpcliente.disconnect();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public boolean login(String usuario, String password) {
		try {
			boolean loginCorrecto = ftpcliente.login(usuario, password);
			if (loginCorrecto) {
				return true;
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		return false;
	}

	public boolean subirFichero(String nombreEnEquipo, String nombreEnServidor) {
		BufferedInputStream bis = null;
		try {
			ftpcliente.setFileType(FTP.BINARY_FILE_TYPE);
			bis = new BufferedInputStream(new FileInputStream(nombreEnEquipo));
			if (ftpcliente.storeFile(nombreEnServidor, bis)) {
				System.out.println("-> Fichero subido correctamente");
			}
			return true;
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				bis.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		return false;
	}

	public boolean bajarFichero(String nombreEnServidor, String nombreEnEquipo) {
		BufferedOutputStream bos = null;
		try {
			ftpcliente.setFileType(FTP.BINARY_FILE_TYPE);
			bos = new BufferedOutputStream(new FileOutputStream(nombreEnEquipo));
			if (ftpcliente.retrieveFile(nombreEnServidor, bos)) {
				System.out.println("-> Fichero bajado correctamente");
			}
			return true;
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				bos.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		return false;
	}

}
