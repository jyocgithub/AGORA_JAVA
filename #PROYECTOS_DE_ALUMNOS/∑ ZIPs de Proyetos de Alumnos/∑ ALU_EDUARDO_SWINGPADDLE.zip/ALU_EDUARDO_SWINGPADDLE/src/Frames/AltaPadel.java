/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Frames;

import java.awt.Rectangle;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableCellEditor;

/**
 *
 * @author Eduardo
 */
public class AltaPadel extends javax.swing.JFrame {
    DefaultTableModel modelo=new DefaultTableModel();
    int contador11=0;
    int contador12=0;
    int contador13=0;
    int contador14=0;
    int contador15=0;
    int contador16=0;
    int contador17=0;
    int contador18=0;
    int contador21=0;
    int contador22=0;
    int contador23=0;
    int contador24=0;
    int contador25=0;
    int contador26=0;
    int contador27=0;
    int contador28=0;
    int contador31=0;
    int contador32=0;
    int contador33=0;
    int contador34=0;
    int contador35=0;
    int contador36=0;
    int contador37=0;
    int contador38=0;
    boolean padel11=false;
    boolean padel12=false;
    boolean padel13=false;
    boolean padel14=false;
    boolean padel15=false;
    boolean padel16=false;
    boolean padel17=false;
    boolean padel18=false;
    boolean padel21=false;
    boolean padel22=false;
    boolean padel23=false;
    boolean padel24=false;
    boolean padel25=false;
    boolean padel26=false;
    boolean padel27=false;
    boolean padel28=false;
    boolean padel31=false;
    boolean padel32=false;
    boolean padel33=false;
    boolean padel34=false;
    boolean padel35=false;
    boolean padel36=false;
    boolean padel37=false;
    boolean padel38=false;
    String pista="";
    String hora="";
    /**
     * Creates new form AltaPadel
     */
    public AltaPadel() {
        initComponents();
        jTextFieldNombre.setEnabled(false);
        jTextFieldTelefono.setEnabled(false);
        jCheckBoxSocio.setEnabled(false);
        jTextFieldCodigoPista.setVisible(false);
        jTextFieldCheckSocio.setVisible(false);
        modelo.addColumn("Nombre");
        modelo.addColumn("Teléfono");
        modelo.addColumn("Socio");
        modelo.addColumn("Pista");
        modelo.addColumn("Hora");
        modelo.addColumn("Importe");
        jTableTablaReservas.setModel(modelo);
        compPadel11.setImagenFondo(new comppadel.ImagenFondo(new java.io.File("C:/Users/Eduardo/Documents/NetBeansProjects/DI_Tarea3/src/Imagenes/rojoOcupado.jpg"),1f));
        compPadel12.setImagenFondo(new comppadel.ImagenFondo(new java.io.File("C:/Users/Eduardo/Documents/NetBeansProjects/DI_Tarea3/src/Imagenes/rojoOcupado.jpg"),1f));
        compPadel13.setImagenFondo(new comppadel.ImagenFondo(new java.io.File("C:/Users/Eduardo/Documents/NetBeansProjects/DI_Tarea3/src/Imagenes/rojoOcupado.jpg"),1f));
        compPadel14.setImagenFondo(new comppadel.ImagenFondo(new java.io.File("C:/Users/Eduardo/Documents/NetBeansProjects/DI_Tarea3/src/Imagenes/rojoOcupado.jpg"),1f));
        compPadel15.setImagenFondo(new comppadel.ImagenFondo(new java.io.File("C:/Users/Eduardo/Documents/NetBeansProjects/DI_Tarea3/src/Imagenes/rojoOcupado.jpg"),1f));
        compPadel16.setImagenFondo(new comppadel.ImagenFondo(new java.io.File("C:/Users/Eduardo/Documents/NetBeansProjects/DI_Tarea3/src/Imagenes/rojoOcupado.jpg"),1f));
        compPadel17.setImagenFondo(new comppadel.ImagenFondo(new java.io.File("C:/Users/Eduardo/Documents/NetBeansProjects/DI_Tarea3/src/Imagenes/rojoOcupado.jpg"),1f));
        compPadel18.setImagenFondo(new comppadel.ImagenFondo(new java.io.File("C:/Users/Eduardo/Documents/NetBeansProjects/DI_Tarea3/src/Imagenes/rojoOcupado.jpg"),1f));
        compPadel21.setImagenFondo(new comppadel.ImagenFondo(new java.io.File("C:/Users/Eduardo/Documents/NetBeansProjects/DI_Tarea3/src/Imagenes/rojoOcupado.jpg"),1f));
        compPadel22.setImagenFondo(new comppadel.ImagenFondo(new java.io.File("C:/Users/Eduardo/Documents/NetBeansProjects/DI_Tarea3/src/Imagenes/rojoOcupado.jpg"),1f));
        compPadel23.setImagenFondo(new comppadel.ImagenFondo(new java.io.File("C:/Users/Eduardo/Documents/NetBeansProjects/DI_Tarea3/src/Imagenes/rojoOcupado.jpg"),1f));
        compPadel24.setImagenFondo(new comppadel.ImagenFondo(new java.io.File("C:/Users/Eduardo/Documents/NetBeansProjects/DI_Tarea3/src/Imagenes/rojoOcupado.jpg"),1f));
        compPadel25.setImagenFondo(new comppadel.ImagenFondo(new java.io.File("C:/Users/Eduardo/Documents/NetBeansProjects/DI_Tarea3/src/Imagenes/rojoOcupado.jpg"),1f));
        compPadel26.setImagenFondo(new comppadel.ImagenFondo(new java.io.File("C:/Users/Eduardo/Documents/NetBeansProjects/DI_Tarea3/src/Imagenes/rojoOcupado.jpg"),1f));
        compPadel27.setImagenFondo(new comppadel.ImagenFondo(new java.io.File("C:/Users/Eduardo/Documents/NetBeansProjects/DI_Tarea3/src/Imagenes/rojoOcupado.jpg"),1f));
        compPadel28.setImagenFondo(new comppadel.ImagenFondo(new java.io.File("C:/Users/Eduardo/Documents/NetBeansProjects/DI_Tarea3/src/Imagenes/rojoOcupado.jpg"),1f));
        compPadel31.setImagenFondo(new comppadel.ImagenFondo(new java.io.File("C:/Users/Eduardo/Documents/NetBeansProjects/DI_Tarea3/src/Imagenes/rojoOcupado.jpg"),1f));
        compPadel32.setImagenFondo(new comppadel.ImagenFondo(new java.io.File("C:/Users/Eduardo/Documents/NetBeansProjects/DI_Tarea3/src/Imagenes/rojoOcupado.jpg"),1f));
        compPadel33.setImagenFondo(new comppadel.ImagenFondo(new java.io.File("C:/Users/Eduardo/Documents/NetBeansProjects/DI_Tarea3/src/Imagenes/rojoOcupado.jpg"),1f));
        compPadel34.setImagenFondo(new comppadel.ImagenFondo(new java.io.File("C:/Users/Eduardo/Documents/NetBeansProjects/DI_Tarea3/src/Imagenes/rojoOcupado.jpg"),1f));
        compPadel35.setImagenFondo(new comppadel.ImagenFondo(new java.io.File("C:/Users/Eduardo/Documents/NetBeansProjects/DI_Tarea3/src/Imagenes/rojoOcupado.jpg"),1f));
        compPadel36.setImagenFondo(new comppadel.ImagenFondo(new java.io.File("C:/Users/Eduardo/Documents/NetBeansProjects/DI_Tarea3/src/Imagenes/rojoOcupado.jpg"),1f));
        compPadel37.setImagenFondo(new comppadel.ImagenFondo(new java.io.File("C:/Users/Eduardo/Documents/NetBeansProjects/DI_Tarea3/src/Imagenes/rojoOcupado.jpg"),1f));
        compPadel38.setImagenFondo(new comppadel.ImagenFondo(new java.io.File("C:/Users/Eduardo/Documents/NetBeansProjects/DI_Tarea3/src/Imagenes/rojoOcupado.jpg"),1f));
        
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        compPadel11 = new comppadel.CompPadel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jSeparator1 = new javax.swing.JSeparator();
        jSeparator2 = new javax.swing.JSeparator();
        jSeparator3 = new javax.swing.JSeparator();
        jSeparator5 = new javax.swing.JSeparator();
        jSeparator8 = new javax.swing.JSeparator();
        jSeparator9 = new javax.swing.JSeparator();
        jSeparator10 = new javax.swing.JSeparator();
        jSeparator11 = new javax.swing.JSeparator();
        jSeparator12 = new javax.swing.JSeparator();
        jSeparator13 = new javax.swing.JSeparator();
        compPadel12 = new comppadel.CompPadel();
        compPadel13 = new comppadel.CompPadel();
        compPadel21 = new comppadel.CompPadel();
        compPadel31 = new comppadel.CompPadel();
        compPadel22 = new comppadel.CompPadel();
        compPadel32 = new comppadel.CompPadel();
        compPadel23 = new comppadel.CompPadel();
        compPadel33 = new comppadel.CompPadel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jSeparator14 = new javax.swing.JSeparator();
        jSeparator15 = new javax.swing.JSeparator();
        jSeparator16 = new javax.swing.JSeparator();
        jSeparator17 = new javax.swing.JSeparator();
        jSeparator18 = new javax.swing.JSeparator();
        jSeparator19 = new javax.swing.JSeparator();
        jSeparator20 = new javax.swing.JSeparator();
        jSeparator21 = new javax.swing.JSeparator();
        jSeparator22 = new javax.swing.JSeparator();
        jSeparator23 = new javax.swing.JSeparator();
        jSeparator24 = new javax.swing.JSeparator();
        jLabel13 = new javax.swing.JLabel();
        jSeparator25 = new javax.swing.JSeparator();
        jLabel14 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        compPadel14 = new comppadel.CompPadel();
        compPadel24 = new comppadel.CompPadel();
        compPadel34 = new comppadel.CompPadel();
        compPadel15 = new comppadel.CompPadel();
        compPadel25 = new comppadel.CompPadel();
        compPadel35 = new comppadel.CompPadel();
        compPadel16 = new comppadel.CompPadel();
        compPadel26 = new comppadel.CompPadel();
        compPadel36 = new comppadel.CompPadel();
        compPadel17 = new comppadel.CompPadel();
        compPadel37 = new comppadel.CompPadel();
        compPadel78 = new comppadel.CompPadel();
        compPadel27 = new comppadel.CompPadel();
        compPadel81 = new comppadel.CompPadel();
        compPadel18 = new comppadel.CompPadel();
        compPadel28 = new comppadel.CompPadel();
        compPadel38 = new comppadel.CompPadel();
        jLabel17 = new javax.swing.JLabel();
        jSeparator4 = new javax.swing.JSeparator();
        jLabel18 = new javax.swing.JLabel();
        jLabel19 = new javax.swing.JLabel();
        jLabel20 = new javax.swing.JLabel();
        jLabel21 = new javax.swing.JLabel();
        jLabel22 = new javax.swing.JLabel();
        jLabel23 = new javax.swing.JLabel();
        jTextFieldTelefono = new javax.swing.JTextField();
        jLabel24 = new javax.swing.JLabel();
        jTextFieldNombre = new javax.swing.JTextField();
        jCheckBoxSocio = new javax.swing.JCheckBox();
        jLabel25 = new javax.swing.JLabel();
        jButtonAceptarReserva = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jLabel26 = new javax.swing.JLabel();
        jSeparator6 = new javax.swing.JSeparator();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTableTablaReservas = new javax.swing.JTable();
        jLabel1 = new javax.swing.JLabel();
        jTextFieldCodigoPista = new javax.swing.JTextField();
        jTextFieldCheckSocio = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("CLUB DE PADEL SMASH - Alta");
        setMaximumSize(new java.awt.Dimension(1366, 768));
        setMinimumSize(new java.awt.Dimension(1366, 768));
        setPreferredSize(new java.awt.Dimension(1366, 768));
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        compPadel11.setImagenFondo(new comppadel.ImagenFondo(new java.io.File("C:/Program Files/NetBeans 8.2"),0.5f));
        compPadel11.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                compPadel11MouseClicked(evt);
            }
        });

        javax.swing.GroupLayout compPadel11Layout = new javax.swing.GroupLayout(compPadel11);
        compPadel11.setLayout(compPadel11Layout);
        compPadel11Layout.setHorizontalGroup(
            compPadel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 30, Short.MAX_VALUE)
        );
        compPadel11Layout.setVerticalGroup(
            compPadel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 30, Short.MAX_VALUE)
        );

        getContentPane().add(compPadel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 100, 30, 30));

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Pista 1");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 280, -1, -1));

        jLabel3.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("Pista 2");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 60, -1, -1));

        jLabel4.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("Tabla Reservas");
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(480, 140, 270, 30));

        jLabel5.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("15:00 a 16:30");
        getContentPane().add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 330, -1, -1));

        jLabel6.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setText("11:00 a 12:30");
        getContentPane().add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 160, -1, -1));

        jLabel7.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setText("18:00 a 19:30");
        getContentPane().add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 430, -1, -1));
        getContentPane().add(jSeparator1, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 190, 350, 10));
        getContentPane().add(jSeparator2, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 560, 350, 10));
        getContentPane().add(jSeparator3, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 310, 350, 10));
        getContentPane().add(jSeparator5, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 270, 240, 10));
        getContentPane().add(jSeparator8, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 140, 350, 10));

        jSeparator9.setOrientation(javax.swing.SwingConstants.VERTICAL);
        getContentPane().add(jSeparator9, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 310, 30, 250));

        jSeparator10.setOrientation(javax.swing.SwingConstants.VERTICAL);
        getContentPane().add(jSeparator10, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 270, 10, 290));

        jSeparator11.setOrientation(javax.swing.SwingConstants.VERTICAL);
        getContentPane().add(jSeparator11, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 50, 10, 190));

        jSeparator12.setOrientation(javax.swing.SwingConstants.VERTICAL);
        getContentPane().add(jSeparator12, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 50, 10, 190));

        jSeparator13.setOrientation(javax.swing.SwingConstants.VERTICAL);
        getContentPane().add(jSeparator13, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 50, 10, 190));

        compPadel12.setImagenFondo(new comppadel.ImagenFondo(new java.io.File("C:/Program Files/NetBeans 8.2"),0.5f));
        compPadel12.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                compPadel12MouseClicked(evt);
            }
        });

        javax.swing.GroupLayout compPadel12Layout = new javax.swing.GroupLayout(compPadel12);
        compPadel12.setLayout(compPadel12Layout);
        compPadel12Layout.setHorizontalGroup(
            compPadel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 30, Short.MAX_VALUE)
        );
        compPadel12Layout.setVerticalGroup(
            compPadel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 30, Short.MAX_VALUE)
        );

        getContentPane().add(compPadel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 150, 30, 30));

        compPadel13.setImagenFondo(new comppadel.ImagenFondo(new java.io.File("C:/Program Files/NetBeans 8.2"),0.5f));
        compPadel13.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                compPadel13MouseClicked(evt);
            }
        });

        javax.swing.GroupLayout compPadel13Layout = new javax.swing.GroupLayout(compPadel13);
        compPadel13.setLayout(compPadel13Layout);
        compPadel13Layout.setHorizontalGroup(
            compPadel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 30, Short.MAX_VALUE)
        );
        compPadel13Layout.setVerticalGroup(
            compPadel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 30, Short.MAX_VALUE)
        );

        getContentPane().add(compPadel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 200, 30, 30));

        compPadel21.setImagenFondo(new comppadel.ImagenFondo(new java.io.File("C:/Program Files/NetBeans 8.2"),0.5f));
        compPadel21.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                compPadel21MouseClicked(evt);
            }
        });

        javax.swing.GroupLayout compPadel21Layout = new javax.swing.GroupLayout(compPadel21);
        compPadel21.setLayout(compPadel21Layout);
        compPadel21Layout.setHorizontalGroup(
            compPadel21Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 30, Short.MAX_VALUE)
        );
        compPadel21Layout.setVerticalGroup(
            compPadel21Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 30, Short.MAX_VALUE)
        );

        getContentPane().add(compPadel21, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 100, 30, 30));

        compPadel31.setImagenFondo(new comppadel.ImagenFondo(new java.io.File("C:/Program Files/NetBeans 8.2"),0.5f));
        compPadel31.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                compPadel31MouseClicked(evt);
            }
        });

        javax.swing.GroupLayout compPadel31Layout = new javax.swing.GroupLayout(compPadel31);
        compPadel31.setLayout(compPadel31Layout);
        compPadel31Layout.setHorizontalGroup(
            compPadel31Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 30, Short.MAX_VALUE)
        );
        compPadel31Layout.setVerticalGroup(
            compPadel31Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 30, Short.MAX_VALUE)
        );

        getContentPane().add(compPadel31, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 100, 30, 30));

        compPadel22.setImagenFondo(new comppadel.ImagenFondo(new java.io.File("C:/Program Files/NetBeans 8.2"),0.5f));
        compPadel22.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                compPadel22MouseClicked(evt);
            }
        });

        javax.swing.GroupLayout compPadel22Layout = new javax.swing.GroupLayout(compPadel22);
        compPadel22.setLayout(compPadel22Layout);
        compPadel22Layout.setHorizontalGroup(
            compPadel22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 30, Short.MAX_VALUE)
        );
        compPadel22Layout.setVerticalGroup(
            compPadel22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 30, Short.MAX_VALUE)
        );

        getContentPane().add(compPadel22, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 150, 30, 30));

        compPadel32.setImagenFondo(new comppadel.ImagenFondo(new java.io.File("C:/Program Files/NetBeans 8.2"),0.5f));
        compPadel32.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                compPadel32MouseClicked(evt);
            }
        });

        javax.swing.GroupLayout compPadel32Layout = new javax.swing.GroupLayout(compPadel32);
        compPadel32.setLayout(compPadel32Layout);
        compPadel32Layout.setHorizontalGroup(
            compPadel32Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 30, Short.MAX_VALUE)
        );
        compPadel32Layout.setVerticalGroup(
            compPadel32Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 30, Short.MAX_VALUE)
        );

        getContentPane().add(compPadel32, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 150, 30, 30));

        compPadel23.setImagenFondo(new comppadel.ImagenFondo(new java.io.File("C:/Program Files/NetBeans 8.2"),0.5f));
        compPadel23.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                compPadel23MouseClicked(evt);
            }
        });

        javax.swing.GroupLayout compPadel23Layout = new javax.swing.GroupLayout(compPadel23);
        compPadel23.setLayout(compPadel23Layout);
        compPadel23Layout.setHorizontalGroup(
            compPadel23Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 30, Short.MAX_VALUE)
        );
        compPadel23Layout.setVerticalGroup(
            compPadel23Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 30, Short.MAX_VALUE)
        );

        getContentPane().add(compPadel23, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 200, 30, 30));

        compPadel33.setImagenFondo(new comppadel.ImagenFondo(new java.io.File("C:/Program Files/NetBeans 8.2"),0.5f));
        compPadel33.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                compPadel33MouseClicked(evt);
            }
        });

        javax.swing.GroupLayout compPadel33Layout = new javax.swing.GroupLayout(compPadel33);
        compPadel33.setLayout(compPadel33Layout);
        compPadel33Layout.setHorizontalGroup(
            compPadel33Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 30, Short.MAX_VALUE)
        );
        compPadel33Layout.setVerticalGroup(
            compPadel33Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 30, Short.MAX_VALUE)
        );

        getContentPane().add(compPadel33, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 200, 30, 30));

        jLabel8.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(255, 255, 255));
        jLabel8.setText("16:30 a 18:00");
        getContentPane().add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 380, -1, -1));

        jLabel9.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(255, 255, 255));
        jLabel9.setText("21:00 a 22:30");
        getContentPane().add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 530, -1, -1));

        jLabel10.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(255, 255, 255));
        jLabel10.setText("9:30 a 11:00");
        getContentPane().add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 110, -1, -1));

        jLabel11.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(255, 255, 255));
        jLabel11.setText("12:30 a 14:00");
        getContentPane().add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 200, -1, -1));

        jLabel12.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel12.setForeground(new java.awt.Color(255, 255, 255));
        jLabel12.setText("12:30 a 14:00");
        getContentPane().add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 200, -1, -1));

        jSeparator14.setOrientation(javax.swing.SwingConstants.VERTICAL);
        getContentPane().add(jSeparator14, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 270, 10, 290));

        jSeparator15.setOrientation(javax.swing.SwingConstants.VERTICAL);
        getContentPane().add(jSeparator15, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 270, 10, 290));

        jSeparator16.setOrientation(javax.swing.SwingConstants.VERTICAL);
        getContentPane().add(jSeparator16, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 270, 10, 290));

        jSeparator17.setOrientation(javax.swing.SwingConstants.VERTICAL);
        getContentPane().add(jSeparator17, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 50, 10, 190));
        getContentPane().add(jSeparator18, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 50, 240, 10));
        getContentPane().add(jSeparator19, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 360, 350, 10));
        getContentPane().add(jSeparator20, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 410, 350, 10));
        getContentPane().add(jSeparator21, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 460, 350, 10));

        jSeparator22.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        getContentPane().add(jSeparator22, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 90, 350, 10));

        jSeparator23.setOrientation(javax.swing.SwingConstants.VERTICAL);
        getContentPane().add(jSeparator23, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 90, 30, 150));
        getContentPane().add(jSeparator24, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 240, 350, 10));

        jLabel13.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel13.setForeground(new java.awt.Color(255, 255, 255));
        jLabel13.setText("19:30 a 21:00");
        getContentPane().add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 480, -1, -1));
        getContentPane().add(jSeparator25, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 510, 350, 10));

        jLabel14.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel14.setForeground(new java.awt.Color(255, 255, 255));
        jLabel14.setText("Pista 2");
        getContentPane().add(jLabel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 280, -1, -1));

        jLabel15.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel15.setForeground(new java.awt.Color(255, 255, 255));
        jLabel15.setText("Pista 3");
        getContentPane().add(jLabel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 280, -1, 20));

        jLabel16.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel16.setForeground(new java.awt.Color(255, 255, 255));
        jLabel16.setText("Pista 1");
        getContentPane().add(jLabel16, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 60, -1, -1));

        compPadel14.setImagenFondo(new comppadel.ImagenFondo(new java.io.File("C:/Program Files/NetBeans 8.2"),0.5f));
        compPadel14.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                compPadel14MouseClicked(evt);
            }
        });

        javax.swing.GroupLayout compPadel14Layout = new javax.swing.GroupLayout(compPadel14);
        compPadel14.setLayout(compPadel14Layout);
        compPadel14Layout.setHorizontalGroup(
            compPadel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 30, Short.MAX_VALUE)
        );
        compPadel14Layout.setVerticalGroup(
            compPadel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 30, Short.MAX_VALUE)
        );

        getContentPane().add(compPadel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 320, 30, 30));

        compPadel24.setImagenFondo(new comppadel.ImagenFondo(new java.io.File("C:/Program Files/NetBeans 8.2"),0.5f));
        compPadel24.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                compPadel24MouseClicked(evt);
            }
        });

        javax.swing.GroupLayout compPadel24Layout = new javax.swing.GroupLayout(compPadel24);
        compPadel24.setLayout(compPadel24Layout);
        compPadel24Layout.setHorizontalGroup(
            compPadel24Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 30, Short.MAX_VALUE)
        );
        compPadel24Layout.setVerticalGroup(
            compPadel24Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 30, Short.MAX_VALUE)
        );

        getContentPane().add(compPadel24, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 320, 30, 30));

        compPadel34.setImagenFondo(new comppadel.ImagenFondo(new java.io.File("C:/Program Files/NetBeans 8.2"),0.5f));
        compPadel34.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                compPadel34MouseClicked(evt);
            }
        });

        javax.swing.GroupLayout compPadel34Layout = new javax.swing.GroupLayout(compPadel34);
        compPadel34.setLayout(compPadel34Layout);
        compPadel34Layout.setHorizontalGroup(
            compPadel34Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 30, Short.MAX_VALUE)
        );
        compPadel34Layout.setVerticalGroup(
            compPadel34Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 30, Short.MAX_VALUE)
        );

        getContentPane().add(compPadel34, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 320, 30, 30));

        compPadel15.setImagenFondo(new comppadel.ImagenFondo(new java.io.File("C:/Program Files/NetBeans 8.2"),0.5f));
        compPadel15.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                compPadel15MouseClicked(evt);
            }
        });

        javax.swing.GroupLayout compPadel15Layout = new javax.swing.GroupLayout(compPadel15);
        compPadel15.setLayout(compPadel15Layout);
        compPadel15Layout.setHorizontalGroup(
            compPadel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 30, Short.MAX_VALUE)
        );
        compPadel15Layout.setVerticalGroup(
            compPadel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 30, Short.MAX_VALUE)
        );

        getContentPane().add(compPadel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 370, 30, 30));

        compPadel25.setImagenFondo(new comppadel.ImagenFondo(new java.io.File("C:/Program Files/NetBeans 8.2"),0.5f));
        compPadel25.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                compPadel25MouseClicked(evt);
            }
        });

        javax.swing.GroupLayout compPadel25Layout = new javax.swing.GroupLayout(compPadel25);
        compPadel25.setLayout(compPadel25Layout);
        compPadel25Layout.setHorizontalGroup(
            compPadel25Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 30, Short.MAX_VALUE)
        );
        compPadel25Layout.setVerticalGroup(
            compPadel25Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 30, Short.MAX_VALUE)
        );

        getContentPane().add(compPadel25, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 370, 30, 30));

        compPadel35.setImagenFondo(new comppadel.ImagenFondo(new java.io.File("C:/Program Files/NetBeans 8.2"),0.5f));
        compPadel35.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                compPadel35MouseClicked(evt);
            }
        });

        javax.swing.GroupLayout compPadel35Layout = new javax.swing.GroupLayout(compPadel35);
        compPadel35.setLayout(compPadel35Layout);
        compPadel35Layout.setHorizontalGroup(
            compPadel35Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 30, Short.MAX_VALUE)
        );
        compPadel35Layout.setVerticalGroup(
            compPadel35Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 30, Short.MAX_VALUE)
        );

        getContentPane().add(compPadel35, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 370, 30, 30));

        compPadel16.setImagenFondo(new comppadel.ImagenFondo(new java.io.File("C:/Program Files/NetBeans 8.2"),0.5f));
        compPadel16.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                compPadel16MouseClicked(evt);
            }
        });

        javax.swing.GroupLayout compPadel16Layout = new javax.swing.GroupLayout(compPadel16);
        compPadel16.setLayout(compPadel16Layout);
        compPadel16Layout.setHorizontalGroup(
            compPadel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 30, Short.MAX_VALUE)
        );
        compPadel16Layout.setVerticalGroup(
            compPadel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 30, Short.MAX_VALUE)
        );

        getContentPane().add(compPadel16, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 420, 30, 30));

        compPadel26.setImagenFondo(new comppadel.ImagenFondo(new java.io.File("C:/Program Files/NetBeans 8.2"),0.5f));
        compPadel26.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                compPadel26MouseClicked(evt);
            }
        });

        javax.swing.GroupLayout compPadel26Layout = new javax.swing.GroupLayout(compPadel26);
        compPadel26.setLayout(compPadel26Layout);
        compPadel26Layout.setHorizontalGroup(
            compPadel26Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 30, Short.MAX_VALUE)
        );
        compPadel26Layout.setVerticalGroup(
            compPadel26Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 30, Short.MAX_VALUE)
        );

        getContentPane().add(compPadel26, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 420, 30, 30));

        compPadel36.setImagenFondo(new comppadel.ImagenFondo(new java.io.File("C:/Program Files/NetBeans 8.2"),0.5f));
        compPadel36.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                compPadel36MouseClicked(evt);
            }
        });

        javax.swing.GroupLayout compPadel36Layout = new javax.swing.GroupLayout(compPadel36);
        compPadel36.setLayout(compPadel36Layout);
        compPadel36Layout.setHorizontalGroup(
            compPadel36Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 30, Short.MAX_VALUE)
        );
        compPadel36Layout.setVerticalGroup(
            compPadel36Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 30, Short.MAX_VALUE)
        );

        getContentPane().add(compPadel36, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 420, 30, 30));

        compPadel17.setImagenFondo(new comppadel.ImagenFondo(new java.io.File("C:/Program Files/NetBeans 8.2"),0.5f));
        compPadel17.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                compPadel17MouseClicked(evt);
            }
        });

        javax.swing.GroupLayout compPadel17Layout = new javax.swing.GroupLayout(compPadel17);
        compPadel17.setLayout(compPadel17Layout);
        compPadel17Layout.setHorizontalGroup(
            compPadel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 30, Short.MAX_VALUE)
        );
        compPadel17Layout.setVerticalGroup(
            compPadel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 30, Short.MAX_VALUE)
        );

        getContentPane().add(compPadel17, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 470, 30, 30));

        compPadel37.setImagenFondo(new comppadel.ImagenFondo(new java.io.File("C:/Program Files/NetBeans 8.2"),0.5f));
        compPadel37.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                compPadel37MouseClicked(evt);
            }
        });

        javax.swing.GroupLayout compPadel37Layout = new javax.swing.GroupLayout(compPadel37);
        compPadel37.setLayout(compPadel37Layout);
        compPadel37Layout.setHorizontalGroup(
            compPadel37Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 30, Short.MAX_VALUE)
        );
        compPadel37Layout.setVerticalGroup(
            compPadel37Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 30, Short.MAX_VALUE)
        );

        getContentPane().add(compPadel37, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 470, 30, 30));

        compPadel78.setImagenFondo(new comppadel.ImagenFondo(new java.io.File("C:/Program Files/NetBeans 8.2"),0.5f));
        compPadel78.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                compPadel78MouseClicked(evt);
            }
        });

        javax.swing.GroupLayout compPadel78Layout = new javax.swing.GroupLayout(compPadel78);
        compPadel78.setLayout(compPadel78Layout);
        compPadel78Layout.setHorizontalGroup(
            compPadel78Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 30, Short.MAX_VALUE)
        );
        compPadel78Layout.setVerticalGroup(
            compPadel78Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 30, Short.MAX_VALUE)
        );

        getContentPane().add(compPadel78, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 470, 30, 30));

        compPadel27.setImagenFondo(new comppadel.ImagenFondo(new java.io.File("C:/Program Files/NetBeans 8.2"),0.5f));
        compPadel27.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                compPadel27MouseClicked(evt);
            }
        });

        javax.swing.GroupLayout compPadel27Layout = new javax.swing.GroupLayout(compPadel27);
        compPadel27.setLayout(compPadel27Layout);
        compPadel27Layout.setHorizontalGroup(
            compPadel27Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 30, Short.MAX_VALUE)
        );
        compPadel27Layout.setVerticalGroup(
            compPadel27Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 30, Short.MAX_VALUE)
        );

        getContentPane().add(compPadel27, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 470, 30, 30));

        compPadel81.setImagenFondo(new comppadel.ImagenFondo(new java.io.File("C:/Program Files/NetBeans 8.2"),0.5f));
        compPadel81.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                compPadel81MouseClicked(evt);
            }
        });

        javax.swing.GroupLayout compPadel81Layout = new javax.swing.GroupLayout(compPadel81);
        compPadel81.setLayout(compPadel81Layout);
        compPadel81Layout.setHorizontalGroup(
            compPadel81Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 30, Short.MAX_VALUE)
        );
        compPadel81Layout.setVerticalGroup(
            compPadel81Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 30, Short.MAX_VALUE)
        );

        getContentPane().add(compPadel81, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 470, 30, 30));

        compPadel18.setImagenFondo(new comppadel.ImagenFondo(new java.io.File("C:/Program Files/NetBeans 8.2"),0.5f));
        compPadel18.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                compPadel18MouseClicked(evt);
            }
        });

        javax.swing.GroupLayout compPadel18Layout = new javax.swing.GroupLayout(compPadel18);
        compPadel18.setLayout(compPadel18Layout);
        compPadel18Layout.setHorizontalGroup(
            compPadel18Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 30, Short.MAX_VALUE)
        );
        compPadel18Layout.setVerticalGroup(
            compPadel18Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 30, Short.MAX_VALUE)
        );

        getContentPane().add(compPadel18, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 520, 30, 30));

        compPadel28.setImagenFondo(new comppadel.ImagenFondo(new java.io.File("C:/Program Files/NetBeans 8.2"),0.5f));
        compPadel28.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                compPadel28MouseClicked(evt);
            }
        });

        javax.swing.GroupLayout compPadel28Layout = new javax.swing.GroupLayout(compPadel28);
        compPadel28.setLayout(compPadel28Layout);
        compPadel28Layout.setHorizontalGroup(
            compPadel28Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 30, Short.MAX_VALUE)
        );
        compPadel28Layout.setVerticalGroup(
            compPadel28Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 30, Short.MAX_VALUE)
        );

        getContentPane().add(compPadel28, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 520, 30, 30));

        compPadel38.setImagenFondo(new comppadel.ImagenFondo(new java.io.File("C:/Program Files/NetBeans 8.2"),0.5f));
        compPadel38.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                compPadel38MouseClicked(evt);
            }
        });

        javax.swing.GroupLayout compPadel38Layout = new javax.swing.GroupLayout(compPadel38);
        compPadel38.setLayout(compPadel38Layout);
        compPadel38Layout.setHorizontalGroup(
            compPadel38Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 30, Short.MAX_VALUE)
        );
        compPadel38Layout.setVerticalGroup(
            compPadel38Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 30, Short.MAX_VALUE)
        );

        getContentPane().add(compPadel38, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 520, 30, 30));

        jLabel17.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel17.setForeground(new java.awt.Color(255, 255, 255));
        jLabel17.setText("Socio:");
        getContentPane().add(jLabel17, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 100, -1, 20));
        getContentPane().add(jSeparator4, new org.netbeans.lib.awtextra.AbsoluteConstraints(480, 170, 190, 20));

        jLabel18.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel18.setForeground(new java.awt.Color(255, 255, 255));
        jLabel18.setText("Pista 3");
        getContentPane().add(jLabel18, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 60, -1, 20));

        jLabel19.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel19.setForeground(new java.awt.Color(255, 255, 255));
        jLabel19.setText("Pista 3");
        getContentPane().add(jLabel19, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 60, -1, 20));

        jLabel20.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel20.setForeground(new java.awt.Color(255, 255, 255));
        jLabel20.setText("Pista 3");
        getContentPane().add(jLabel20, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 60, -1, 20));

        jLabel21.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel21.setForeground(new java.awt.Color(255, 255, 255));
        jLabel21.setText("Pista 3");
        getContentPane().add(jLabel21, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 60, -1, 20));

        jLabel22.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel22.setForeground(new java.awt.Color(255, 255, 255));
        jLabel22.setText("Pista 3");
        getContentPane().add(jLabel22, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 60, -1, 20));

        jLabel23.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel23.setForeground(new java.awt.Color(255, 255, 255));
        jLabel23.setText("Pista 3");
        getContentPane().add(jLabel23, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 60, -1, 20));
        getContentPane().add(jTextFieldTelefono, new org.netbeans.lib.awtextra.AbsoluteConstraints(870, 60, 200, -1));

        jLabel24.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel24.setForeground(new java.awt.Color(255, 255, 255));
        jLabel24.setText("Nombre:");
        getContentPane().add(jLabel24, new org.netbeans.lib.awtextra.AbsoluteConstraints(480, 60, -1, 20));
        getContentPane().add(jTextFieldNombre, new org.netbeans.lib.awtextra.AbsoluteConstraints(560, 60, 200, -1));

        jCheckBoxSocio.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jCheckBoxSocio.setForeground(new java.awt.Color(255, 255, 255));
        getContentPane().add(jCheckBoxSocio, new org.netbeans.lib.awtextra.AbsoluteConstraints(560, 100, -1, -1));

        jLabel25.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel25.setForeground(new java.awt.Color(255, 255, 255));
        jLabel25.setText("Teléfono:");
        getContentPane().add(jLabel25, new org.netbeans.lib.awtextra.AbsoluteConstraints(790, 60, -1, 20));

        jButtonAceptarReserva.setText("Aceptar Reserva");
        jButtonAceptarReserva.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonAceptarReservaActionPerformed(evt);
            }
        });
        getContentPane().add(jButtonAceptarReserva, new org.netbeans.lib.awtextra.AbsoluteConstraints(860, 620, -1, -1));

        jButton2.setText("Cancelar Reserva");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(990, 620, -1, -1));

        jLabel26.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jLabel26.setForeground(new java.awt.Color(255, 255, 255));
        jLabel26.setText("Datos Reserva");
        getContentPane().add(jLabel26, new org.netbeans.lib.awtextra.AbsoluteConstraints(480, 10, 270, 30));
        getContentPane().add(jSeparator6, new org.netbeans.lib.awtextra.AbsoluteConstraints(480, 40, 180, 20));

        jTableTablaReservas.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(jTableTablaReservas);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(480, 200, 630, 400));

        jLabel1.setBackground(new java.awt.Color(255, 255, 255));
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/alta.jpg"))); // NOI18N
        jLabel1.setMaximumSize(new java.awt.Dimension(1366, 768));
        jLabel1.setMinimumSize(new java.awt.Dimension(1366, 768));
        jLabel1.setPreferredSize(new java.awt.Dimension(1366, 768));
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, 770));

        jTextFieldCodigoPista.setEditable(false);
        getContentPane().add(jTextFieldCodigoPista, new org.netbeans.lib.awtextra.AbsoluteConstraints(820, 540, 130, -1));

        jTextFieldCheckSocio.setEditable(false);
        getContentPane().add(jTextFieldCheckSocio, new org.netbeans.lib.awtextra.AbsoluteConstraints(820, 510, 130, -1));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void compPadel11MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_compPadel11MouseClicked
        contador11++;
        pista="1";
        hora="9:30 a 11:00";
        
        if(padel11==false){
            if(contador11%2!=0){
            compPadel11.setImagenFondo(new comppadel.ImagenFondo(new java.io.File("C:/Users/Eduardo/Documents/NetBeansProjects/DI_Tarea3/src/Imagenes/verdeLibre.jpg"),1f));
            jTextFieldNombre.setEnabled(true);
            jTextFieldTelefono.setEnabled(true);
            jCheckBoxSocio.setEnabled(true);
            jTextFieldCodigoPista.setText("compPadel11");
            
            }else{
                
            compPadel11.setImagenFondo(new comppadel.ImagenFondo(new java.io.File("C:/Users/Eduardo/Documents/NetBeansProjects/DI_Tarea3/src/Imagenes/rojoOcupado.jpg"),1f));
            jTextFieldNombre.setEnabled(false);
            jTextFieldTelefono.setEnabled(false);
            jCheckBoxSocio.setEnabled(false);
                     
            }
        }else{
            for(int i=0; i<jTableTablaReservas.getRowCount(); i++){
                for(int j=0; j<jTableTablaReservas.getColumnCount(); j++){
                    if(pista.equalsIgnoreCase((String) jTableTablaReservas.getValueAt(i, 3)) && hora.equalsIgnoreCase((String) jTableTablaReservas.getValueAt(i, 4))){
                        jTableTablaReservas.requestFocus();
                        jTableTablaReservas.changeSelection(i,j,false, false);
                        
                    }
                }
            }
        }   
    }//GEN-LAST:event_compPadel11MouseClicked

    private void compPadel12MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_compPadel12MouseClicked
        contador12++;
        pista="1";
        hora="11:00 a 12:30";
        
        if(padel12==false){
            if(contador12%2!=0){
            compPadel12.setImagenFondo(new comppadel.ImagenFondo(new java.io.File("C:/Users/Eduardo/Documents/NetBeansProjects/DI_Tarea3/src/Imagenes/verdeLibre.jpg"),1f));
            jTextFieldNombre.setEnabled(true);
            jTextFieldTelefono.setEnabled(true);
            jCheckBoxSocio.setEnabled(true);
            jTextFieldCodigoPista.setText("compPadel12");
            
            }else{
                
            compPadel12.setImagenFondo(new comppadel.ImagenFondo(new java.io.File("C:/Users/Eduardo/Documents/NetBeansProjects/DI_Tarea3/src/Imagenes/rojoOcupado.jpg"),1f));
            jTextFieldNombre.setEnabled(false);
            jTextFieldTelefono.setEnabled(false);
            jCheckBoxSocio.setEnabled(false);
                     
            }
        }else{
            for(int i=0; i<jTableTablaReservas.getRowCount(); i++){
                for(int j=0; j<jTableTablaReservas.getColumnCount(); j++){
                    if(pista.equalsIgnoreCase((String) jTableTablaReservas.getValueAt(i, 3)) && hora.equalsIgnoreCase((String) jTableTablaReservas.getValueAt(i, 4))){
                        jTableTablaReservas.requestFocus();
                        jTableTablaReservas.changeSelection(i,j,false, false);
                        
                    }
                }
            }
        }    
    }//GEN-LAST:event_compPadel12MouseClicked

    private void compPadel13MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_compPadel13MouseClicked
        contador13++;
        pista="1";
        hora="12:30 a 14:00";
        
        if(padel13==false){
            if(contador13%2!=0){
            compPadel13.setImagenFondo(new comppadel.ImagenFondo(new java.io.File("C:/Users/Eduardo/Documents/NetBeansProjects/DI_Tarea3/src/Imagenes/verdeLibre.jpg"),1f));
            jTextFieldNombre.setEnabled(true);
            jTextFieldTelefono.setEnabled(true);
            jCheckBoxSocio.setEnabled(true);
            jTextFieldCodigoPista.setText("compPadel13");
            
            }else{
                
            compPadel13.setImagenFondo(new comppadel.ImagenFondo(new java.io.File("C:/Users/Eduardo/Documents/NetBeansProjects/DI_Tarea3/src/Imagenes/rojoOcupado.jpg"),1f));
            jTextFieldNombre.setEnabled(false);
            jTextFieldTelefono.setEnabled(false);
            jCheckBoxSocio.setEnabled(false);
                     
            }
        }else{
            for(int i=0; i<jTableTablaReservas.getRowCount(); i++){
                for(int j=0; j<jTableTablaReservas.getColumnCount(); j++){
                    if(pista.equalsIgnoreCase((String) jTableTablaReservas.getValueAt(i, 3)) && hora.equalsIgnoreCase((String) jTableTablaReservas.getValueAt(i, 4))){
                        jTableTablaReservas.requestFocus();
                        jTableTablaReservas.changeSelection(i,j,false, false);
                        
                    }
                }
            }
        }     
    }//GEN-LAST:event_compPadel13MouseClicked

    private void compPadel21MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_compPadel21MouseClicked
        contador21++;
        pista="2";
        hora="9:30 a 11:00";
        
        if(padel21==false){
            if(contador21%2!=0){
            compPadel21.setImagenFondo(new comppadel.ImagenFondo(new java.io.File("C:/Users/Eduardo/Documents/NetBeansProjects/DI_Tarea3/src/Imagenes/verdeLibre.jpg"),1f));
            jTextFieldNombre.setEnabled(true);
            jTextFieldTelefono.setEnabled(true);
            jCheckBoxSocio.setEnabled(true);
            jTextFieldCodigoPista.setText("compPadel21");
            
            }else{
                
            compPadel21.setImagenFondo(new comppadel.ImagenFondo(new java.io.File("C:/Users/Eduardo/Documents/NetBeansProjects/DI_Tarea3/src/Imagenes/rojoOcupado.jpg"),1f));
            jTextFieldNombre.setEnabled(false);
            jTextFieldTelefono.setEnabled(false);
            jCheckBoxSocio.setEnabled(false);
                     
            }
        }else{
            for(int i=0; i<jTableTablaReservas.getRowCount(); i++){
                for(int j=0; j<jTableTablaReservas.getColumnCount(); j++){
                    if(pista.equalsIgnoreCase((String) jTableTablaReservas.getValueAt(i, 3)) && hora.equalsIgnoreCase((String) jTableTablaReservas.getValueAt(i, 4))){
                        jTableTablaReservas.requestFocus();
                        jTableTablaReservas.changeSelection(i,j,false, false);
                        
                    }
                }
            }
        }     
    }//GEN-LAST:event_compPadel21MouseClicked

    private void compPadel31MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_compPadel31MouseClicked
        contador31++;
        pista="3";
        hora="9:30 a 11:00";
        
        if(padel31==false){
            if(contador31%2!=0){
            compPadel31.setImagenFondo(new comppadel.ImagenFondo(new java.io.File("C:/Users/Eduardo/Documents/NetBeansProjects/DI_Tarea3/src/Imagenes/verdeLibre.jpg"),1f));
            jTextFieldNombre.setEnabled(true);
            jTextFieldTelefono.setEnabled(true);
            jCheckBoxSocio.setEnabled(true);
            jTextFieldCodigoPista.setText("compPadel31");
            
            }else{
                
            compPadel31.setImagenFondo(new comppadel.ImagenFondo(new java.io.File("C:/Users/Eduardo/Documents/NetBeansProjects/DI_Tarea3/src/Imagenes/rojoOcupado.jpg"),1f));
            jTextFieldNombre.setEnabled(false);
            jTextFieldTelefono.setEnabled(false);
            jCheckBoxSocio.setEnabled(false);
                     
            }
        }else{
            for(int i=0; i<jTableTablaReservas.getRowCount(); i++){
                for(int j=0; j<jTableTablaReservas.getColumnCount(); j++){
                    if(pista.equalsIgnoreCase((String) jTableTablaReservas.getValueAt(i, 3)) && hora.equalsIgnoreCase((String) jTableTablaReservas.getValueAt(i, 4))){
                        jTableTablaReservas.requestFocus();
                        jTableTablaReservas.changeSelection(i,j,false, false);
                        
                    }
                }
            }
        }     
    }//GEN-LAST:event_compPadel31MouseClicked

    private void compPadel22MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_compPadel22MouseClicked
        contador22++;
        pista="2";
        hora="11:00 a 12:30";
        
        if(padel22==false){
            if(contador22%2!=0){
            compPadel22.setImagenFondo(new comppadel.ImagenFondo(new java.io.File("C:/Users/Eduardo/Documents/NetBeansProjects/DI_Tarea3/src/Imagenes/verdeLibre.jpg"),1f));
            jTextFieldNombre.setEnabled(true);
            jTextFieldTelefono.setEnabled(true);
            jCheckBoxSocio.setEnabled(true);
            jTextFieldCodigoPista.setText("compPadel22");
            
            }else{
                
            compPadel22.setImagenFondo(new comppadel.ImagenFondo(new java.io.File("C:/Users/Eduardo/Documents/NetBeansProjects/DI_Tarea3/src/Imagenes/rojoOcupado.jpg"),1f));
            jTextFieldNombre.setEnabled(false);
            jTextFieldTelefono.setEnabled(false);
            jCheckBoxSocio.setEnabled(false);
                     
            }
        }else{
            for(int i=0; i<jTableTablaReservas.getRowCount(); i++){
                for(int j=0; j<jTableTablaReservas.getColumnCount(); j++){
                    if(pista.equalsIgnoreCase((String) jTableTablaReservas.getValueAt(i, 3)) && hora.equalsIgnoreCase((String) jTableTablaReservas.getValueAt(i, 4))){
                        jTableTablaReservas.requestFocus();
                        jTableTablaReservas.changeSelection(i,j,false, false);
                        
                    }
                }
            }
        }     
    }//GEN-LAST:event_compPadel22MouseClicked

    private void compPadel32MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_compPadel32MouseClicked
        contador32++;
        pista="3";
        hora="11:00 a 12:30";
        
        if(padel32==false){
            if(contador32%2!=0){
            compPadel32.setImagenFondo(new comppadel.ImagenFondo(new java.io.File("C:/Users/Eduardo/Documents/NetBeansProjects/DI_Tarea3/src/Imagenes/verdeLibre.jpg"),1f));
            jTextFieldNombre.setEnabled(true);
            jTextFieldTelefono.setEnabled(true);
            jCheckBoxSocio.setEnabled(true);
            jTextFieldCodigoPista.setText("compPadel32");
            
            }else{
                
            compPadel32.setImagenFondo(new comppadel.ImagenFondo(new java.io.File("C:/Users/Eduardo/Documents/NetBeansProjects/DI_Tarea3/src/Imagenes/rojoOcupado.jpg"),1f));
            jTextFieldNombre.setEnabled(false);
            jTextFieldTelefono.setEnabled(false);
            jCheckBoxSocio.setEnabled(false);
                     
            }
        }else{
            for(int i=0; i<jTableTablaReservas.getRowCount(); i++){
                for(int j=0; j<jTableTablaReservas.getColumnCount(); j++){
                    if(pista.equalsIgnoreCase((String) jTableTablaReservas.getValueAt(i, 3)) && hora.equalsIgnoreCase((String) jTableTablaReservas.getValueAt(i, 4))){
                        jTableTablaReservas.requestFocus();
                        jTableTablaReservas.changeSelection(i,j,false, false);
                        
                    }
                }
            }
        }  
    }//GEN-LAST:event_compPadel32MouseClicked

    private void compPadel23MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_compPadel23MouseClicked
        contador23++;
        pista="2";
        hora="12:30 a 14:00";
        
        if(padel23==false){
            if(contador23%2!=0){
            compPadel23.setImagenFondo(new comppadel.ImagenFondo(new java.io.File("C:/Users/Eduardo/Documents/NetBeansProjects/DI_Tarea3/src/Imagenes/verdeLibre.jpg"),1f));
            jTextFieldNombre.setEnabled(true);
            jTextFieldTelefono.setEnabled(true);
            jCheckBoxSocio.setEnabled(true);
            jTextFieldCodigoPista.setText("compPadel23");
            
            }else{
                
            compPadel23.setImagenFondo(new comppadel.ImagenFondo(new java.io.File("C:/Users/Eduardo/Documents/NetBeansProjects/DI_Tarea3/src/Imagenes/rojoOcupado.jpg"),1f));
            jTextFieldNombre.setEnabled(false);
            jTextFieldTelefono.setEnabled(false);
            jCheckBoxSocio.setEnabled(false);
                     
            }
        }   
    }//GEN-LAST:event_compPadel23MouseClicked

    private void compPadel33MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_compPadel33MouseClicked
        contador33++;
        pista="3";
        hora="12:30 a 14:00";
        
        if(padel33==false){
            if(contador33%2!=0){
            compPadel33.setImagenFondo(new comppadel.ImagenFondo(new java.io.File("C:/Users/Eduardo/Documents/NetBeansProjects/DI_Tarea3/src/Imagenes/verdeLibre.jpg"),1f));
            jTextFieldNombre.setEnabled(true);
            jTextFieldTelefono.setEnabled(true);
            jCheckBoxSocio.setEnabled(true);
            jTextFieldCodigoPista.setText("compPadel33");
            
            }else{
                
            compPadel33.setImagenFondo(new comppadel.ImagenFondo(new java.io.File("C:/Users/Eduardo/Documents/NetBeansProjects/DI_Tarea3/src/Imagenes/rojoOcupado.jpg"),1f));
            jTextFieldNombre.setEnabled(false);
            jTextFieldTelefono.setEnabled(false);
            jCheckBoxSocio.setEnabled(false);
                     
            }
        }else{
            for(int i=0; i<jTableTablaReservas.getRowCount(); i++){
                for(int j=0; j<jTableTablaReservas.getColumnCount(); j++){
                    if(pista.equalsIgnoreCase((String) jTableTablaReservas.getValueAt(i, 3)) && hora.equalsIgnoreCase((String) jTableTablaReservas.getValueAt(i, 4))){
                        jTableTablaReservas.requestFocus();
                        jTableTablaReservas.changeSelection(i,j,false, false);
                        
                    }
                }
            }
        }     
    }//GEN-LAST:event_compPadel33MouseClicked

    private void compPadel14MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_compPadel14MouseClicked
        contador14++;
        pista="1";
        hora="15:00 a 16:30";
        
        if(padel14==false){
            if(contador14%2!=0){
            compPadel14.setImagenFondo(new comppadel.ImagenFondo(new java.io.File("C:/Users/Eduardo/Documents/NetBeansProjects/DI_Tarea3/src/Imagenes/verdeLibre.jpg"),1f));
            jTextFieldNombre.setEnabled(true);
            jTextFieldTelefono.setEnabled(true);
            jCheckBoxSocio.setEnabled(true);
            jTextFieldCodigoPista.setText("compPadel14");
            
            }else{
                
            compPadel14.setImagenFondo(new comppadel.ImagenFondo(new java.io.File("C:/Users/Eduardo/Documents/NetBeansProjects/DI_Tarea3/src/Imagenes/rojoOcupado.jpg"),1f));
            jTextFieldNombre.setEnabled(false);
            jTextFieldTelefono.setEnabled(false);
            jCheckBoxSocio.setEnabled(false);
                     
            }
        }else{
            for(int i=0; i<jTableTablaReservas.getRowCount(); i++){
                for(int j=0; j<jTableTablaReservas.getColumnCount(); j++){
                    if(pista.equalsIgnoreCase((String) jTableTablaReservas.getValueAt(i, 3)) && hora.equalsIgnoreCase((String) jTableTablaReservas.getValueAt(i, 4))){
                        jTableTablaReservas.requestFocus();
                        jTableTablaReservas.changeSelection(i,j,false, false);
                        
                    }
                }
            }
        }     
    }//GEN-LAST:event_compPadel14MouseClicked

    private void compPadel24MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_compPadel24MouseClicked
        contador24++;
        pista="2";
        hora="15:00 a 16:30";
        
        if(padel24==false){
            if(contador24%2!=0){
            compPadel24.setImagenFondo(new comppadel.ImagenFondo(new java.io.File("C:/Users/Eduardo/Documents/NetBeansProjects/DI_Tarea3/src/Imagenes/verdeLibre.jpg"),1f));
            jTextFieldNombre.setEnabled(true);
            jTextFieldTelefono.setEnabled(true);
            jCheckBoxSocio.setEnabled(true);
            jTextFieldCodigoPista.setText("compPadel24");
            
            }else{
                
            compPadel24.setImagenFondo(new comppadel.ImagenFondo(new java.io.File("C:/Users/Eduardo/Documents/NetBeansProjects/DI_Tarea3/src/Imagenes/rojoOcupado.jpg"),1f));
            jTextFieldNombre.setEnabled(false);
            jTextFieldTelefono.setEnabled(false);
            jCheckBoxSocio.setEnabled(false);
                     
            }
        }else{
            for(int i=0; i<jTableTablaReservas.getRowCount(); i++){
                for(int j=0; j<jTableTablaReservas.getColumnCount(); j++){
                    if(pista.equalsIgnoreCase((String) jTableTablaReservas.getValueAt(i, 3)) && hora.equalsIgnoreCase((String) jTableTablaReservas.getValueAt(i, 4))){
                        jTableTablaReservas.requestFocus();
                        jTableTablaReservas.changeSelection(i,j,false, false);
                        
                    }
                }
            }
        }     
    }//GEN-LAST:event_compPadel24MouseClicked

    private void compPadel34MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_compPadel34MouseClicked
        contador34++;
        pista="3";
        hora="15:00 a 16:30";
        
        if(padel34==false){
            if(contador34%2!=0){
            compPadel34.setImagenFondo(new comppadel.ImagenFondo(new java.io.File("C:/Users/Eduardo/Documents/NetBeansProjects/DI_Tarea3/src/Imagenes/verdeLibre.jpg"),1f));
            jTextFieldNombre.setEnabled(true);
            jTextFieldTelefono.setEnabled(true);
            jCheckBoxSocio.setEnabled(true);
            jTextFieldCodigoPista.setText("compPadel34");
            
            }else{
                
            compPadel34.setImagenFondo(new comppadel.ImagenFondo(new java.io.File("C:/Users/Eduardo/Documents/NetBeansProjects/DI_Tarea3/src/Imagenes/rojoOcupado.jpg"),1f));
            jTextFieldNombre.setEnabled(false);
            jTextFieldTelefono.setEnabled(false);
            jCheckBoxSocio.setEnabled(false);
                     
            }
        }else{
            for(int i=0; i<jTableTablaReservas.getRowCount(); i++){
                for(int j=0; j<jTableTablaReservas.getColumnCount(); j++){
                    if(pista.equalsIgnoreCase((String) jTableTablaReservas.getValueAt(i, 3)) && hora.equalsIgnoreCase((String) jTableTablaReservas.getValueAt(i, 4))){
                        jTableTablaReservas.requestFocus();
                        jTableTablaReservas.changeSelection(i,j,false, false);
                        
                    }
                }
            }
        }     
    }//GEN-LAST:event_compPadel34MouseClicked

    private void compPadel15MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_compPadel15MouseClicked
        contador15++;
        pista="1";
        hora="16:30 a 18:00";
        
        if(padel15==false){
            if(contador15%2!=0){
            compPadel15.setImagenFondo(new comppadel.ImagenFondo(new java.io.File("C:/Users/Eduardo/Documents/NetBeansProjects/DI_Tarea3/src/Imagenes/verdeLibre.jpg"),1f));
            jTextFieldNombre.setEnabled(true);
            jTextFieldTelefono.setEnabled(true);
            jCheckBoxSocio.setEnabled(true);
            jTextFieldCodigoPista.setText("compPadel15");
            
            }else{
                
            compPadel15.setImagenFondo(new comppadel.ImagenFondo(new java.io.File("C:/Users/Eduardo/Documents/NetBeansProjects/DI_Tarea3/src/Imagenes/rojoOcupado.jpg"),1f));
            jTextFieldNombre.setEnabled(false);
            jTextFieldTelefono.setEnabled(false);
            jCheckBoxSocio.setEnabled(false);
                     
            }
        }else{
            for(int i=0; i<jTableTablaReservas.getRowCount(); i++){
                for(int j=0; j<jTableTablaReservas.getColumnCount(); j++){
                    if(pista.equalsIgnoreCase((String) jTableTablaReservas.getValueAt(i, 3)) && hora.equalsIgnoreCase((String) jTableTablaReservas.getValueAt(i, 4))){
                        jTableTablaReservas.requestFocus();
                        jTableTablaReservas.changeSelection(i,j,false, false);
                        
                    }
                }
            }
        }     
    }//GEN-LAST:event_compPadel15MouseClicked

    private void compPadel25MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_compPadel25MouseClicked
        contador25++;
        pista="2";
        hora="16:30 a 18:00";
        
        if(padel25==false){
            if(contador25%2!=0){
            compPadel25.setImagenFondo(new comppadel.ImagenFondo(new java.io.File("C:/Users/Eduardo/Documents/NetBeansProjects/DI_Tarea3/src/Imagenes/verdeLibre.jpg"),1f));
            jTextFieldNombre.setEnabled(true);
            jTextFieldTelefono.setEnabled(true);
            jCheckBoxSocio.setEnabled(true);
            jTextFieldCodigoPista.setText("compPadel25");
            
            }else{
                
            compPadel25.setImagenFondo(new comppadel.ImagenFondo(new java.io.File("C:/Users/Eduardo/Documents/NetBeansProjects/DI_Tarea3/src/Imagenes/rojoOcupado.jpg"),1f));
            jTextFieldNombre.setEnabled(false);
            jTextFieldTelefono.setEnabled(false);
            jCheckBoxSocio.setEnabled(false);
                     
            }
        }else{
            for(int i=0; i<jTableTablaReservas.getRowCount(); i++){
                for(int j=0; j<jTableTablaReservas.getColumnCount(); j++){
                    if(pista.equalsIgnoreCase((String) jTableTablaReservas.getValueAt(i, 3)) && hora.equalsIgnoreCase((String) jTableTablaReservas.getValueAt(i, 4))){
                        jTableTablaReservas.requestFocus();
                        jTableTablaReservas.changeSelection(i,j,false, false);
                        
                    }
                }
            }
        }     
    }//GEN-LAST:event_compPadel25MouseClicked

    private void compPadel35MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_compPadel35MouseClicked
        contador35++;
        pista="3";
        hora="16:30 a 18:00";
        
        if(padel35==false){
            if(contador35%2!=0){
            compPadel35.setImagenFondo(new comppadel.ImagenFondo(new java.io.File("C:/Users/Eduardo/Documents/NetBeansProjects/DI_Tarea3/src/Imagenes/verdeLibre.jpg"),1f));
            jTextFieldNombre.setEnabled(true);
            jTextFieldTelefono.setEnabled(true);
            jCheckBoxSocio.setEnabled(true);
            jTextFieldCodigoPista.setText("compPadel35");
            
            }else{
                
            compPadel35.setImagenFondo(new comppadel.ImagenFondo(new java.io.File("C:/Users/Eduardo/Documents/NetBeansProjects/DI_Tarea3/src/Imagenes/rojoOcupado.jpg"),1f));
            jTextFieldNombre.setEnabled(false);
            jTextFieldTelefono.setEnabled(false);
            jCheckBoxSocio.setEnabled(false);
                     
            }
        }else{
            for(int i=0; i<jTableTablaReservas.getRowCount(); i++){
                for(int j=0; j<jTableTablaReservas.getColumnCount(); j++){
                    if(pista.equalsIgnoreCase((String) jTableTablaReservas.getValueAt(i, 3)) && hora.equalsIgnoreCase((String) jTableTablaReservas.getValueAt(i, 4))){
                        jTableTablaReservas.requestFocus();
                        jTableTablaReservas.changeSelection(i,j,false, false);
                        
                    }
                }
            }
        }     
    }//GEN-LAST:event_compPadel35MouseClicked

    private void compPadel16MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_compPadel16MouseClicked
        contador16++;
        pista="1";
        hora="18:00 a 19:30";
        
        if(padel16==false){
            if(contador16%2!=0){
            compPadel16.setImagenFondo(new comppadel.ImagenFondo(new java.io.File("C:/Users/Eduardo/Documents/NetBeansProjects/DI_Tarea3/src/Imagenes/verdeLibre.jpg"),1f));
            jTextFieldNombre.setEnabled(true);
            jTextFieldTelefono.setEnabled(true);
            jCheckBoxSocio.setEnabled(true);
            jTextFieldCodigoPista.setText("compPadel16");
            
            }else{
                
            compPadel16.setImagenFondo(new comppadel.ImagenFondo(new java.io.File("C:/Users/Eduardo/Documents/NetBeansProjects/DI_Tarea3/src/Imagenes/rojoOcupado.jpg"),1f));
            jTextFieldNombre.setEnabled(false);
            jTextFieldTelefono.setEnabled(false);
            jCheckBoxSocio.setEnabled(false);
                     
            }
        }else{
            for(int i=0; i<jTableTablaReservas.getRowCount(); i++){
                for(int j=0; j<jTableTablaReservas.getColumnCount(); j++){
                    if(pista.equalsIgnoreCase((String) jTableTablaReservas.getValueAt(i, 3)) && hora.equalsIgnoreCase((String) jTableTablaReservas.getValueAt(i, 4))){
                        jTableTablaReservas.requestFocus();
                        jTableTablaReservas.changeSelection(i,j,false, false);
                        
                    }
                }
            }
        }     
    }//GEN-LAST:event_compPadel16MouseClicked

    private void compPadel26MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_compPadel26MouseClicked
        contador26++;
        pista="2";
        hora="18:00 a 19:30";
        
        if(padel26==false){
            if(contador26%2!=0){
            compPadel26.setImagenFondo(new comppadel.ImagenFondo(new java.io.File("C:/Users/Eduardo/Documents/NetBeansProjects/DI_Tarea3/src/Imagenes/verdeLibre.jpg"),1f));
            jTextFieldNombre.setEnabled(true);
            jTextFieldTelefono.setEnabled(true);
            jCheckBoxSocio.setEnabled(true);
            jTextFieldCodigoPista.setText("compPadel26");
            
            }else{
                
            compPadel26.setImagenFondo(new comppadel.ImagenFondo(new java.io.File("C:/Users/Eduardo/Documents/NetBeansProjects/DI_Tarea3/src/Imagenes/rojoOcupado.jpg"),1f));
            jTextFieldNombre.setEnabled(false);
            jTextFieldTelefono.setEnabled(false);
            jCheckBoxSocio.setEnabled(false);
                     
            }
        }else{
            for(int i=0; i<jTableTablaReservas.getRowCount(); i++){
                for(int j=0; j<jTableTablaReservas.getColumnCount(); j++){
                    if(pista.equalsIgnoreCase((String) jTableTablaReservas.getValueAt(i, 3)) && hora.equalsIgnoreCase((String) jTableTablaReservas.getValueAt(i, 4))){
                        jTableTablaReservas.requestFocus();
                        jTableTablaReservas.changeSelection(i,j,false, false);
                        
                    }
                }
            }
        }     
    }//GEN-LAST:event_compPadel26MouseClicked

    private void compPadel36MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_compPadel36MouseClicked
        contador36++;
        pista="3";
        hora="18:00 a 19:30";
        
        if(padel36==false){
            if(contador36%2!=0){
            compPadel36.setImagenFondo(new comppadel.ImagenFondo(new java.io.File("C:/Users/Eduardo/Documents/NetBeansProjects/DI_Tarea3/src/Imagenes/verdeLibre.jpg"),1f));
            jTextFieldNombre.setEnabled(true);
            jTextFieldTelefono.setEnabled(true);
            jCheckBoxSocio.setEnabled(true);
            jTextFieldCodigoPista.setText("compPadel36");
            
            }else{
                
            compPadel36.setImagenFondo(new comppadel.ImagenFondo(new java.io.File("C:/Users/Eduardo/Documents/NetBeansProjects/DI_Tarea3/src/Imagenes/rojoOcupado.jpg"),1f));
            jTextFieldNombre.setEnabled(false);
            jTextFieldTelefono.setEnabled(false);
            jCheckBoxSocio.setEnabled(false);
                     
            }
        }else{
            for(int i=0; i<jTableTablaReservas.getRowCount(); i++){
                for(int j=0; j<jTableTablaReservas.getColumnCount(); j++){
                    if(pista.equalsIgnoreCase((String) jTableTablaReservas.getValueAt(i, 3)) && hora.equalsIgnoreCase((String) jTableTablaReservas.getValueAt(i, 4))){
                        jTableTablaReservas.requestFocus();
                        jTableTablaReservas.changeSelection(i,j,false, false);
                        
                    }
                }
            }
        }     
    }//GEN-LAST:event_compPadel36MouseClicked

    private void compPadel17MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_compPadel17MouseClicked
        contador17++;
        pista="1";
        hora="19:30 a 21:00";
        
        if(padel17==false){
            if(contador17%2!=0){
            compPadel17.setImagenFondo(new comppadel.ImagenFondo(new java.io.File("C:/Users/Eduardo/Documents/NetBeansProjects/DI_Tarea3/src/Imagenes/verdeLibre.jpg"),1f));
            jTextFieldNombre.setEnabled(true);
            jTextFieldTelefono.setEnabled(true);
            jCheckBoxSocio.setEnabled(true);
            jTextFieldCodigoPista.setText("compPadel17");
            
            }else{
                
            compPadel17.setImagenFondo(new comppadel.ImagenFondo(new java.io.File("C:/Users/Eduardo/Documents/NetBeansProjects/DI_Tarea3/src/Imagenes/rojoOcupado.jpg"),1f));
            jTextFieldNombre.setEnabled(false);
            jTextFieldTelefono.setEnabled(false);
            jCheckBoxSocio.setEnabled(false);
                     
            }
        }else{
            for(int i=0; i<jTableTablaReservas.getRowCount(); i++){
                for(int j=0; j<jTableTablaReservas.getColumnCount(); j++){
                    if(pista.equalsIgnoreCase((String) jTableTablaReservas.getValueAt(i, 3)) && hora.equalsIgnoreCase((String) jTableTablaReservas.getValueAt(i, 4))){
                        jTableTablaReservas.requestFocus();
                        jTableTablaReservas.changeSelection(i,j,false, false);
                        
                    }
                }
            }
        }     
    }//GEN-LAST:event_compPadel17MouseClicked

    private void compPadel37MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_compPadel37MouseClicked
        contador37++;
        pista="3";
        hora="19:30 a 21:00";
        
        if(padel37==false){
            if(contador37%2!=0){
            compPadel37.setImagenFondo(new comppadel.ImagenFondo(new java.io.File("C:/Users/Eduardo/Documents/NetBeansProjects/DI_Tarea3/src/Imagenes/verdeLibre.jpg"),1f));
            jTextFieldNombre.setEnabled(true);
            jTextFieldTelefono.setEnabled(true);
            jCheckBoxSocio.setEnabled(true);
            jTextFieldCodigoPista.setText("compPadel37");
            
            }else{
                
            compPadel37.setImagenFondo(new comppadel.ImagenFondo(new java.io.File("C:/Users/Eduardo/Documents/NetBeansProjects/DI_Tarea3/src/Imagenes/rojoOcupado.jpg"),1f));
            jTextFieldNombre.setEnabled(false);
            jTextFieldTelefono.setEnabled(false);
            jCheckBoxSocio.setEnabled(false);
                     
            }
        }else{
            for(int i=0; i<jTableTablaReservas.getRowCount(); i++){
                for(int j=0; j<jTableTablaReservas.getColumnCount(); j++){
                    if(pista.equalsIgnoreCase((String) jTableTablaReservas.getValueAt(i, 3)) && hora.equalsIgnoreCase((String) jTableTablaReservas.getValueAt(i, 4))){
                        jTableTablaReservas.requestFocus();
                        jTableTablaReservas.changeSelection(i,j,false, false);
                        
                    }
                }
            }
        }     
    }//GEN-LAST:event_compPadel37MouseClicked

    private void compPadel78MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_compPadel78MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_compPadel78MouseClicked

    private void compPadel81MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_compPadel81MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_compPadel81MouseClicked

    private void compPadel18MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_compPadel18MouseClicked
        contador18++;
        pista="1";
        hora="21:00 a 22:30";
        
        if(padel18==false){
            if(contador18%2!=0){
            compPadel18.setImagenFondo(new comppadel.ImagenFondo(new java.io.File("C:/Users/Eduardo/Documents/NetBeansProjects/DI_Tarea3/src/Imagenes/verdeLibre.jpg"),1f));
            jTextFieldNombre.setEnabled(true);
            jTextFieldTelefono.setEnabled(true);
            jCheckBoxSocio.setEnabled(true);
            jTextFieldCodigoPista.setText("compPadel18");
            
            }else{
                
            compPadel18.setImagenFondo(new comppadel.ImagenFondo(new java.io.File("C:/Users/Eduardo/Documents/NetBeansProjects/DI_Tarea3/src/Imagenes/rojoOcupado.jpg"),1f));
            jTextFieldNombre.setEnabled(false);
            jTextFieldTelefono.setEnabled(false);
            jCheckBoxSocio.setEnabled(false);
                     
            }
        }else{
            for(int i=0; i<jTableTablaReservas.getRowCount(); i++){
                for(int j=0; j<jTableTablaReservas.getColumnCount(); j++){
                    if(pista.equalsIgnoreCase((String) jTableTablaReservas.getValueAt(i, 3)) && hora.equalsIgnoreCase((String) jTableTablaReservas.getValueAt(i, 4))){
                        jTableTablaReservas.requestFocus();
                        jTableTablaReservas.changeSelection(i,j,false, false);
                        
                    }
                }
            }
        }     
    }//GEN-LAST:event_compPadel18MouseClicked

    private void compPadel28MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_compPadel28MouseClicked
        contador28++;
        pista="2";
        hora="21:00 a 22:30";
        
        if(padel28==false){
            if(contador28%2!=0){
            compPadel28.setImagenFondo(new comppadel.ImagenFondo(new java.io.File("C:/Users/Eduardo/Documents/NetBeansProjects/DI_Tarea3/src/Imagenes/verdeLibre.jpg"),1f));
            jTextFieldNombre.setEnabled(true);
            jTextFieldTelefono.setEnabled(true);
            jCheckBoxSocio.setEnabled(true);
            jTextFieldCodigoPista.setText("compPadel28");
            
            }else{
                
            compPadel28.setImagenFondo(new comppadel.ImagenFondo(new java.io.File("C:/Users/Eduardo/Documents/NetBeansProjects/DI_Tarea3/src/Imagenes/rojoOcupado.jpg"),1f));
            jTextFieldNombre.setEnabled(false);
            jTextFieldTelefono.setEnabled(false);
            jCheckBoxSocio.setEnabled(false);
                     
            }
        }else{
            for(int i=0; i<jTableTablaReservas.getRowCount(); i++){
                for(int j=0; j<jTableTablaReservas.getColumnCount(); j++){
                    if(pista.equalsIgnoreCase((String) jTableTablaReservas.getValueAt(i, 3)) && hora.equalsIgnoreCase((String) jTableTablaReservas.getValueAt(i, 4))){
                        jTableTablaReservas.requestFocus();
                        jTableTablaReservas.changeSelection(i,j,false, false);
                        
                    }
                }
            }
        }     
    }//GEN-LAST:event_compPadel28MouseClicked

    private void compPadel38MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_compPadel38MouseClicked
        contador38++;
        pista="3";
        hora="21:00 a 22:30";
        
        if(padel38==false){
            if(contador38%2!=0){
            compPadel38.setImagenFondo(new comppadel.ImagenFondo(new java.io.File("C:/Users/Eduardo/Documents/NetBeansProjects/DI_Tarea3/src/Imagenes/verdeLibre.jpg"),1f));
            jTextFieldNombre.setEnabled(true);
            jTextFieldTelefono.setEnabled(true);
            jCheckBoxSocio.setEnabled(true);
            jTextFieldCodigoPista.setText("compPadel38");
            
            }else{
                
            compPadel38.setImagenFondo(new comppadel.ImagenFondo(new java.io.File("C:/Users/Eduardo/Documents/NetBeansProjects/DI_Tarea3/src/Imagenes/rojoOcupado.jpg"),1f));
            jTextFieldNombre.setEnabled(false);
            jTextFieldTelefono.setEnabled(false);
            jCheckBoxSocio.setEnabled(false);
                     
            }
        }else{
            for(int i=0; i<jTableTablaReservas.getRowCount(); i++){
                for(int j=0; j<jTableTablaReservas.getColumnCount(); j++){
                    if(pista.equalsIgnoreCase((String) jTableTablaReservas.getValueAt(i, 3)) && hora.equalsIgnoreCase((String) jTableTablaReservas.getValueAt(i, 4))){
                        jTableTablaReservas.requestFocus();
                        jTableTablaReservas.changeSelection(i,j,false, false);
                        
                    }
                }
            }
        }     
    }//GEN-LAST:event_compPadel38MouseClicked

    private void compPadel27MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_compPadel27MouseClicked
        contador27++;
        pista="2";
        hora="19:30 a 21:00";
        
        if(padel27==false){
            if(contador27%2!=0){
            compPadel27.setImagenFondo(new comppadel.ImagenFondo(new java.io.File("C:/Users/Eduardo/Documents/NetBeansProjects/DI_Tarea3/src/Imagenes/verdeLibre.jpg"),1f));
            jTextFieldNombre.setEnabled(true);
            jTextFieldTelefono.setEnabled(true);
            jCheckBoxSocio.setEnabled(true);
            jTextFieldCodigoPista.setText("compPadel27");
            
            }else{
                
            compPadel27.setImagenFondo(new comppadel.ImagenFondo(new java.io.File("C:/Users/Eduardo/Documents/NetBeansProjects/DI_Tarea3/src/Imagenes/rojoOcupado.jpg"),1f));
            jTextFieldNombre.setEnabled(false);
            jTextFieldTelefono.setEnabled(false);
            jCheckBoxSocio.setEnabled(false);
                     
            }
        }else{
            for(int i=0; i<jTableTablaReservas.getRowCount(); i++){
                for(int j=0; j<jTableTablaReservas.getColumnCount(); j++){
                    if(pista.equalsIgnoreCase((String) jTableTablaReservas.getValueAt(i, 3)) && hora.equalsIgnoreCase((String) jTableTablaReservas.getValueAt(i, 4))){
                        jTableTablaReservas.requestFocus();
                        jTableTablaReservas.changeSelection(i,j,false, false);
                        
                    }
                }
            }
        }     
    }//GEN-LAST:event_compPadel27MouseClicked

    private void jButtonAceptarReservaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonAceptarReservaActionPerformed
        String dato[]=new String[6];
        double importe=5.0;
        boolean reservaCorrecta=true;
        
        if(jTextFieldNombre.getText().equals("")){
            JOptionPane.showMessageDialog(null, "Campo Obligatorio Nombre vacio");
            reservaCorrecta=false;
            
        }
        
        if(jTextFieldTelefono.getText().equals("")){
            JOptionPane.showMessageDialog(null, "Campo Obligatorio Teléfono vacio");
            reservaCorrecta=false;
        
        }
        
        if(reservaCorrecta){
            dato[0]=jTextFieldNombre.getText();
            dato[1]=jTextFieldTelefono.getText();
        
            if(jCheckBoxSocio.isSelected()){
                jTextFieldCheckSocio.setText("Si");
                importe=3.5;
             }else{
                jTextFieldCheckSocio.setText("No");
            }

            dato[2]=jTextFieldCheckSocio.getText();
              
            String cod=jTextFieldCodigoPista.getText().substring(9);
        
            switch(cod){
                case "11":
                    padel11=true;
                    dato[3]="1";
                    dato[4]="9:30 a 11:00";
                    importe-=1.5;
                    break;
                case "12":
                    padel12=true;
                    dato[3]="1";
                    dato[4]="11:00 a 12:30";
                    importe-=1.5;
                    break;
                case "13":
                    padel13=true;
                    dato[3]="1";
                    dato[4]="12:30 a 14:00";
                    importe-=1.5;
                    break;
                case "14":
                    padel14=true;
                    dato[3]="1";
                    dato[4]="15:00 a 16:30";
                    break;
                case "15":
                    padel15=true;
                    dato[3]="1";
                    dato[4]="16:30 a 18:00";
                    break;
                case "16":
                    padel16=true;
                    dato[3]="1";
                    dato[4]="18:00 a 19:30";
                    break;
                case "17":
                    padel17=true;
                    dato[3]="1";
                    dato[4]="19:30 a 21:00";
                    break;
                case "18":
                    padel18=true;
                    dato[3]="1";
                    dato[4]="21:00 a 22:30";
                    break;
                case "21":
                    padel21=true;
                    dato[3]="2";
                    dato[4]="9:30 a 11:00";
                    importe-=1.5;
                    break;
                case "22":
                    padel22=true;
                    dato[3]="2";
                    dato[4]="11:00 a 12:30";
                    importe-=1.5;
                    break;
                case "23":
                    padel23=true;
                    dato[3]="2";
                    dato[4]="12:30 a 14:00";
                    importe-=1.5;
                    break;
                case "24":
                    padel24=true;
                    dato[3]="2";
                    dato[4]="15:00 a 16:30";
                    break;
                case "25":
                    padel25=true;
                    dato[3]="2";
                    dato[4]="16:30 a 18:00";
                    break;
                case "26":
                    padel26=true;
                    dato[3]="2";
                    dato[4]="18:00 a 19:30";
                    break;
                case "27":
                    padel27=true;
                    dato[3]="2";
                    dato[4]="19:30 a 21:00";
                    break;
                case "28":
                    padel28=true;
                    dato[3]="2";
                    dato[4]="21:00 a 22:30";
                    break;
                case "31":
                    padel31=true;
                    dato[3]="3";
                    dato[4]="09:30 a 11:00";
                    importe-=1.5;
                    break;
                case "32":
                    padel32=true;
                    dato[3]="3";
                    dato[4]="11:00 a 12:30";
                    importe-=1.5;
                    break;
                case "33":
                    padel33=true;
                    dato[3]="3";
                    dato[4]="12:30 a 14:00";
                    importe-=1.5;
                    break;
                case "34":
                    padel34=true;
                    dato[3]="3";
                    dato[4]="15:00 a 16:30";
                    break;
                case "35":
                    padel35=true;
                    dato[3]="3";
                    dato[4]="16:30 a 18:00";
                    break;
                case "36":
                    padel36=true;
                    dato[3]="3";
                    dato[4]="18:00 a 19:30";
                    break;
                case "37":
                    padel37=true;
                    dato[3]="3";
                    dato[4]="19:30 a 21:00";
                    break;
                case "38":
                    padel38=true;
                    dato[3]="3";
                    dato[4]="21:00 a 22:30";
                    break;  

            }
        
            dato[5]=Double.toString(importe);
            modelo.addRow(dato);
        
            jTextFieldNombre.setText("");
            jTextFieldTelefono.setText("");
            jTextFieldNombre.setEnabled(false);
            jTextFieldTelefono.setEnabled(false);
            jCheckBoxSocio.setEnabled(false);
        }
        
           
    }//GEN-LAST:event_jButtonAceptarReservaActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        int numeroFilas=jTableTablaReservas.getRowCount();
        int filaSeleccionada=jTableTablaReservas.getSelectedRow();
        int posicion=0;
        String posicionPistaFinal="";
        
        if(numeroFilas==0){
            JOptionPane.showMessageDialog(null, "No hay ninguna reserva");
        }else{
            if(filaSeleccionada>=0){
                pista=(String) jTableTablaReservas.getValueAt(filaSeleccionada, 3);
                hora=(String) jTableTablaReservas.getValueAt(filaSeleccionada, 4);
                modelo.removeRow(filaSeleccionada);
            }else{
                JOptionPane.showMessageDialog(null, "Selecciona una fila");
            }
        }
        
        switch(hora){
            case "9:30 a 11:00":
                posicion=1;
                break;
            case "11:00 a 12:30":
                posicion=2;
                break;
            case "12:30 a 14:00":
                posicion=3;
                break;
            case "15:00 a 16:30":
                posicion=4;
                break;
            case "16:30 a 18:00":
                posicion=5;
                break;
            case "18:00 a 19:30":
                posicion=6;
                break;
            case "19:30 a 21:00":
                posicion=7;
                break;
            case "21:00 a 22:30":
                posicion=8;
                break;      
        }
        
        hora=String.valueOf(posicion);
        posicionPistaFinal=pista+hora;
        
        switch(posicionPistaFinal){
            case "11":
                compPadel11.setImagenFondo(new comppadel.ImagenFondo(new java.io.File("C:/Users/Eduardo/Documents/NetBeansProjects/DI_Tarea3/src/Imagenes/rojoOcupado.jpg"),1f));
                padel11=false;
                contador11=0;
                break;
            case "12":
                compPadel12.setImagenFondo(new comppadel.ImagenFondo(new java.io.File("C:/Users/Eduardo/Documents/NetBeansProjects/DI_Tarea3/src/Imagenes/rojoOcupado.jpg"),1f));
                padel12=false;
                contador12=0;
                break;
            case "13":
                compPadel13.setImagenFondo(new comppadel.ImagenFondo(new java.io.File("C:/Users/Eduardo/Documents/NetBeansProjects/DI_Tarea3/src/Imagenes/rojoOcupado.jpg"),1f));
                padel13=false;
                contador13=0;
                break;
            case "14":
                compPadel14.setImagenFondo(new comppadel.ImagenFondo(new java.io.File("C:/Users/Eduardo/Documents/NetBeansProjects/DI_Tarea3/src/Imagenes/rojoOcupado.jpg"),1f));
                padel14=false;
                contador14=0;
                break;
            case "15":
                compPadel15.setImagenFondo(new comppadel.ImagenFondo(new java.io.File("C:/Users/Eduardo/Documents/NetBeansProjects/DI_Tarea3/src/Imagenes/rojoOcupado.jpg"),1f));
                padel15=false;
                contador15=0;
                break;
            case "16":
                compPadel16.setImagenFondo(new comppadel.ImagenFondo(new java.io.File("C:/Users/Eduardo/Documents/NetBeansProjects/DI_Tarea3/src/Imagenes/rojoOcupado.jpg"),1f));
                padel16=false;
                contador16=0;
                break;
            case "17":
                compPadel17.setImagenFondo(new comppadel.ImagenFondo(new java.io.File("C:/Users/Eduardo/Documents/NetBeansProjects/DI_Tarea3/src/Imagenes/rojoOcupado.jpg"),1f));
                padel17=false;
                contador17=0;
                break;
            case "18":
                compPadel18.setImagenFondo(new comppadel.ImagenFondo(new java.io.File("C:/Users/Eduardo/Documents/NetBeansProjects/DI_Tarea3/src/Imagenes/rojoOcupado.jpg"),1f));
                padel18=false;
                contador18=0;
                break;
            case "21":
                compPadel21.setImagenFondo(new comppadel.ImagenFondo(new java.io.File("C:/Users/Eduardo/Documents/NetBeansProjects/DI_Tarea3/src/Imagenes/rojoOcupado.jpg"),1f));
                padel21=false;
                contador21=0;
                break;
            case "22":
                compPadel22.setImagenFondo(new comppadel.ImagenFondo(new java.io.File("C:/Users/Eduardo/Documents/NetBeansProjects/DI_Tarea3/src/Imagenes/rojoOcupado.jpg"),1f));
                padel22=false;
                contador22=0;
                break;
            case "23":
                compPadel23.setImagenFondo(new comppadel.ImagenFondo(new java.io.File("C:/Users/Eduardo/Documents/NetBeansProjects/DI_Tarea3/src/Imagenes/rojoOcupado.jpg"),1f));
                padel23=false;
                contador23=0;
                break;
            case "24":
                compPadel24.setImagenFondo(new comppadel.ImagenFondo(new java.io.File("C:/Users/Eduardo/Documents/NetBeansProjects/DI_Tarea3/src/Imagenes/rojoOcupado.jpg"),1f));
                padel24=false;
                contador24=0;
                break;
            case "25":
                compPadel25.setImagenFondo(new comppadel.ImagenFondo(new java.io.File("C:/Users/Eduardo/Documents/NetBeansProjects/DI_Tarea3/src/Imagenes/rojoOcupado.jpg"),1f));
                padel25=false;
                contador25=0;
                break;
            case "26":
                compPadel26.setImagenFondo(new comppadel.ImagenFondo(new java.io.File("C:/Users/Eduardo/Documents/NetBeansProjects/DI_Tarea3/src/Imagenes/rojoOcupado.jpg"),1f));
                padel26=false;
                contador26=0;
                break;
            case "27":
                compPadel27.setImagenFondo(new comppadel.ImagenFondo(new java.io.File("C:/Users/Eduardo/Documents/NetBeansProjects/DI_Tarea3/src/Imagenes/rojoOcupado.jpg"),1f));
                padel27=false;
                contador27=0;
                break;
            case "28":
                compPadel28.setImagenFondo(new comppadel.ImagenFondo(new java.io.File("C:/Users/Eduardo/Documents/NetBeansProjects/DI_Tarea3/src/Imagenes/rojoOcupado.jpg"),1f));
                padel28=false;
                contador28=0;
                break;
            case "31":
                compPadel31.setImagenFondo(new comppadel.ImagenFondo(new java.io.File("C:/Users/Eduardo/Documents/NetBeansProjects/DI_Tarea3/src/Imagenes/rojoOcupado.jpg"),1f));
                padel31=false;
                contador31=0;
                break;
            case "32":
                compPadel32.setImagenFondo(new comppadel.ImagenFondo(new java.io.File("C:/Users/Eduardo/Documents/NetBeansProjects/DI_Tarea3/src/Imagenes/rojoOcupado.jpg"),1f));
                padel32=false;
                contador32=0;
                break;
            case "33":
                compPadel33.setImagenFondo(new comppadel.ImagenFondo(new java.io.File("C:/Users/Eduardo/Documents/NetBeansProjects/DI_Tarea3/src/Imagenes/rojoOcupado.jpg"),1f));
                padel33=false;
                contador33=0;
                break;
            case "34":
                compPadel34.setImagenFondo(new comppadel.ImagenFondo(new java.io.File("C:/Users/Eduardo/Documents/NetBeansProjects/DI_Tarea3/src/Imagenes/rojoOcupado.jpg"),1f));
                padel34=false;
                contador34=0;
                break;
            case "35":
                compPadel35.setImagenFondo(new comppadel.ImagenFondo(new java.io.File("C:/Users/Eduardo/Documents/NetBeansProjects/DI_Tarea3/src/Imagenes/rojoOcupado.jpg"),1f));
                padel35=false;
                contador35=0;
                break;
            case "36":
                compPadel36.setImagenFondo(new comppadel.ImagenFondo(new java.io.File("C:/Users/Eduardo/Documents/NetBeansProjects/DI_Tarea3/src/Imagenes/rojoOcupado.jpg"),1f));
                padel36=false;
                contador36=0;
                break;
            case "37":
                compPadel37.setImagenFondo(new comppadel.ImagenFondo(new java.io.File("C:/Users/Eduardo/Documents/NetBeansProjects/DI_Tarea3/src/Imagenes/rojoOcupado.jpg"),1f));
                padel37=false;
                contador37=0;
                break;
            case "38":
                compPadel38.setImagenFondo(new comppadel.ImagenFondo(new java.io.File("C:/Users/Eduardo/Documents/NetBeansProjects/DI_Tarea3/src/Imagenes/rojoOcupado.jpg"),1f));
                padel38=false;
                contador38=0;
                break;
        }
        
       
    }//GEN-LAST:event_jButton2ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(AltaPadel.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(AltaPadel.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(AltaPadel.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(AltaPadel.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new AltaPadel().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private comppadel.CompPadel compPadel11;
    private comppadel.CompPadel compPadel12;
    private comppadel.CompPadel compPadel13;
    private comppadel.CompPadel compPadel14;
    private comppadel.CompPadel compPadel15;
    private comppadel.CompPadel compPadel16;
    private comppadel.CompPadel compPadel17;
    private comppadel.CompPadel compPadel18;
    private comppadel.CompPadel compPadel21;
    private comppadel.CompPadel compPadel22;
    private comppadel.CompPadel compPadel23;
    private comppadel.CompPadel compPadel24;
    private comppadel.CompPadel compPadel25;
    private comppadel.CompPadel compPadel26;
    private comppadel.CompPadel compPadel27;
    private comppadel.CompPadel compPadel28;
    private comppadel.CompPadel compPadel31;
    private comppadel.CompPadel compPadel32;
    private comppadel.CompPadel compPadel33;
    private comppadel.CompPadel compPadel34;
    private comppadel.CompPadel compPadel35;
    private comppadel.CompPadel compPadel36;
    private comppadel.CompPadel compPadel37;
    private comppadel.CompPadel compPadel38;
    private comppadel.CompPadel compPadel78;
    private comppadel.CompPadel compPadel81;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButtonAceptarReserva;
    private javax.swing.JCheckBox jCheckBoxSocio;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JSeparator jSeparator10;
    private javax.swing.JSeparator jSeparator11;
    private javax.swing.JSeparator jSeparator12;
    private javax.swing.JSeparator jSeparator13;
    private javax.swing.JSeparator jSeparator14;
    private javax.swing.JSeparator jSeparator15;
    private javax.swing.JSeparator jSeparator16;
    private javax.swing.JSeparator jSeparator17;
    private javax.swing.JSeparator jSeparator18;
    private javax.swing.JSeparator jSeparator19;
    private javax.swing.JSeparator jSeparator2;
    private javax.swing.JSeparator jSeparator20;
    private javax.swing.JSeparator jSeparator21;
    private javax.swing.JSeparator jSeparator22;
    private javax.swing.JSeparator jSeparator23;
    private javax.swing.JSeparator jSeparator24;
    private javax.swing.JSeparator jSeparator25;
    private javax.swing.JSeparator jSeparator3;
    private javax.swing.JSeparator jSeparator4;
    private javax.swing.JSeparator jSeparator5;
    private javax.swing.JSeparator jSeparator6;
    private javax.swing.JSeparator jSeparator8;
    private javax.swing.JSeparator jSeparator9;
    private javax.swing.JTable jTableTablaReservas;
    private javax.swing.JTextField jTextFieldCheckSocio;
    private javax.swing.JTextField jTextFieldCodigoPista;
    private javax.swing.JTextField jTextFieldNombre;
    private javax.swing.JTextField jTextFieldTelefono;
    // End of variables declaration//GEN-END:variables
}
