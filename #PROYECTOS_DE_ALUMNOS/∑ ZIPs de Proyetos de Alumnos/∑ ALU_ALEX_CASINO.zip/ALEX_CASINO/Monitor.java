package ALEX_CASINO;

import java.util.ArrayList;

public class Monitor {

    ArrayList<String> listacompartida = new ArrayList<>();

    public synchronized void meter (String algo){

    }
    public synchronized String sacar(){
        return null;
    }

}
