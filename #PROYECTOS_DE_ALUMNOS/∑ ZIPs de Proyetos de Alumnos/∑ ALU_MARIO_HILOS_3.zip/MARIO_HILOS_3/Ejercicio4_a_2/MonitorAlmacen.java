package MARIO_HILOS_3.Ejercicio4_a_2;

import java.util.ArrayList;

public class MonitorAlmacen {

    ArrayList<String> tableros = new ArrayList<>();
    ArrayList<String> patas = new ArrayList<>();

    int MAX_NUM_PATAS = 50;
    int MAX_NUM_TABLEROS = 100;

    public synchronized void añadirPatas(String nombre){
        // CONTROLAMOS SI HEMOS DE PARARNOS CON UN WHILE, Y SI HEMOS DE PARARNOS, WAIT
        while(patas.size()== MAX_NUM_PATAS){
            try {
                wait();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

        // HACEMOS NUESTRAS COSAS
        patas.add("1 pata");
        System.out.println("Productor " + nombre + " ha puesto una pata");

        // LIBRERAMOS A OTROS
        notifyAll();

    }

    public synchronized void retirarPatasyTableros(String nombre){

        // CONTROLAMOS SI HEMOS DE PARARNOS CON UN WHILE, Y SI HEMOS DE PARARNOS, WAIT
        while((tableros.size()==0) || (patas.size()<4)){
            try {
                wait();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }


        // HACEMOS NUESTRAS COSAS
        patas.remove(0);
        patas.remove(0);
        patas.remove(0);
        patas.remove(0);

        tableros.remove(0);
        System.out.println("      El prodcutor de patas " + nombre + " ha creado una pata");

        // LIBRERAMOS A OTROS
        notifyAll();


    }

    public synchronized void añadirTableros(String nombre){
        // CONTROLAMOS SI HEMOS DE PARARNOS CON UN WHILE, Y SI HEMOS DE PARARNOS, WAIT
        while(tableros.size()== MAX_NUM_TABLEROS){
            try {
                wait();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

        // HACEMOS NUESTRAS COSAS
        tableros.add( "1 tablero");
        System.out.println("Productor " + nombre + " ha puesto un tablero");

        // LIBRERAMOS A OTROS
        notifyAll();
    }


}
