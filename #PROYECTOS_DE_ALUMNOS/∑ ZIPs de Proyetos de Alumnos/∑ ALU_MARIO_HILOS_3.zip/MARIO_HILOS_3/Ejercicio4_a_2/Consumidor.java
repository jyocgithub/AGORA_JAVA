package MARIO_HILOS_3.Ejercicio4_a_2;

public class Consumidor extends Thread {
    int TIEMPO_MESA = 500;
    String nombre;
    MonitorAlmacen monitorAlmacen;

    public Consumidor(String nombre, MonitorAlmacen monitorAlmacen) {
        this.nombre = nombre;
        this.monitorAlmacen = monitorAlmacen;
    }

    @Override
    public void run() 
    {

        try {
            Thread.sleep(TIEMPO_MESA);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        for (int i = 0; i < 5; i++)
        {
            monitorAlmacen.retirarPatasyTableros(nombre);
        }

        System.out.println("Emsamblador ha hecho todas las mesas");
    }
}
