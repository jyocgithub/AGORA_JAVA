package Ejercicio4_a_11;
/*
 Una tribu de salvajes comparte una olla en la que caben X misioneros. Cuando algún salvaje quiere
comer, coge directamente un misionero de la olla, a no ser que esté vacía. Si la olla está vacía, el salvaje
despertará al cocinero y esperará a que éste haya llenado la olla con otros X misioneros. Implementar
la solución teniendo en cuenta que:
• No se debe producir interbloqueo.
• Los salvajes podrán comer siempre que haya comida en la olla.
• Solamente se despertará al cocinero cuando la olla esté vacía.

 */
public class Inicio {


    public static void main(String[] args)
    {

        MonitorOlla monitorOlla = new MonitorOlla();

        ProductorCocinero productorCocinero = new ProductorCocinero("Pepe", monitorOlla);

        ConsumidorTribu consumidorTribu = new ConsumidorTribu("EYYY",monitorOlla);

        productorCocinero.start();
        consumidorTribu.start();
    }
}
