import java.util.List;
import java.util.Scanner;

public class Inicio {

    static int[][] matriz = {
            {2, 1, 0, 0, 0},
            {0, 0, 3, 0, 0},
            {0, 1, 0, 0, 0},
            {0, 0, 0, 4, 0},
            {0, 0, 0, 0, 5},
            {0, 0, 0, 4, 0}
    };
//    static int[][] matriz = {
//            {0, 2, 1, 0,},
//            {0, 0, 1, 0,},
//            {1, 0, 1, 3,},
//            {0, 2, 0, 0,}
//    };

    static int[] filasFinales = {0, 0,0, 1,0,1};  // 0 indica no es final, otra cosa, que SI es fila (estado) final

    public static void main(String[] args) {

        int indiceActual = 1;  // segun lo he hecho debe empezar en 1
        int filaInicial = 0;
        String cadena = "";
        int maximaLongifud = 5;

        mas(filaInicial, indiceActual, maximaLongifud, cadena);
    }

    public static void mas(int fila, int indiceActual, int maximaLongitud, String cad) {
        if (indiceActual > maximaLongitud) return;

        for (int c = 0; c < matriz[fila].length; c++) {
            if (filasFinales[fila] != 0)// SOLO  PINTAMOS SI fila ES TERMINAL
                System.out.println(cad);
            int valor = matriz[fila][c];
            if (valor != 0) {
                cad = cad + ((char)(97+c));
                if (filasFinales[fila] != 0)// SOLO  PINTAMOS SI fila ES TERMINAL
                    System.out.println(  cad);
                mas(valor, indiceActual + 1, maximaLongitud, cad);
                cad = cad.substring(0, cad.length() - 1);
            }
        }
    }
}
