/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package barcos;

/**
 *
 * @author mrs123456
 */
public class Jugador {
    
    
    //metodos jugador
    private void colocarBarcos(){
        
    }
    
    private void ataque(){
        
    }
    
    //metodos jugador maquina
    
    private void colocarBarcosAleatorios(){
        
        
    }
    
    private void ataqueAdyacente (){
        
        
    }
}
