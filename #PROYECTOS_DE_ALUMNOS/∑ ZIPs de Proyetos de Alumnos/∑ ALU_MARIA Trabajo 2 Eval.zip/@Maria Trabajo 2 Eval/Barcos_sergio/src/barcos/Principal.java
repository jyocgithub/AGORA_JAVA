/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package barcos;

import java.util.Scanner;

/**
 *
 * @author mrs123456
 */
public class Principal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner entrada = new Scanner (System.in);
        
        //aqui creamos el tablero en el principal
        Tablero jugador1 = new Tablero();
        jugador1.crearTableroJugador();
        
        //Aqui asignamos las funciones especificas que tendra el tablero
        Tablero jugador = new Tablero();
        Tablero maquina = new Tablero();
        maquina.setHumano(false);
        
        jugador.crearTableroJugador();
        maquina.crearTableroJugador();
    }
     
}