/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package barcos;

import java.util.Random;
import java.util.Scanner;

/**
 *
 * @author mrs123456
 */
public class Tablero {
    
  /*en tablero recogeremos toda la informacion para consultar las partidas
 Jugadores, Ganador, Fecha y hora, Estado barcos maquina, Estado barcos jugador
 */
    char posicion[][] = new char[10][10];
    
    //Aqui le decimos si jugador es humano o no para que cargue uno u otro tablero
    //En principal lo llamaremos y para el tablero maquina diremos que Boolean humano=false
    Boolean humano = true;

    public Boolean getHumano() {
        return humano;
    }

    public void setHumano(Boolean humano) {
        this.humano = humano;
    }
    
    
    
   public void crearTableroJugador(){
        Scanner entrada = new Scanner (System.in);
        Random random = new Random();
        
        random.nextInt(10);
        
        
       int fila,columna;
   
 
        //Rellenar la matriz
        for(int x=0;x<10;x++){
            for(int y=0;y<10;y++){
                posicion[x][y] = 'o';     
            }
        }
    //introducimos los barcos
        //introducimos portaviones
        System.out.println("Introduce la fila de cabecera del 1.Portaviones: ");
        if(humano){
            fila = entrada.nextInt();
        }
        else{
            fila = random.nextInt(10);
        }
        if (fila>=1 && fila<=10){
            columna=1;
            for(int i=0;i<6;i++){
               posicion[fila-1][columna+i]='x'; 
            }  
        }else
            System.out.println("introduce una fila correcta");
        
        
      //introducimos buque
        System.out.println("Introduce la fila de cabecera del 2.buque: ");
        fila = entrada.nextInt();
        
        if (fila>=1 && fila<=10){
            columna=1;
            for(int i=0;i<4;i++){
               posicion[fila-1][columna+i]='x'; 
            }  
        }else
            System.out.println("introduce una fila correcta");
        
        
        //mostrar tablero
        System.out.println("\nTablero Jugador: \n");
        for(int x=0;x<10;x++){
            for(int y=0;y<10;y++){
                System.out.print(posicion[x][y]+" ");
            }
            System.out.println("");
        }
        System.out.println("");
                
    }
    
}
    

