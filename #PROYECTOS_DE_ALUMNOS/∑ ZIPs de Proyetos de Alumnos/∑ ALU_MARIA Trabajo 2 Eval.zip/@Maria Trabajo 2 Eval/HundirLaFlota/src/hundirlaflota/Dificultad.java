/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hundirlaflota;

import java.io.Serializable;

/**
 *
 * @author sergiojavierre
 */
public class Dificultad implements Serializable{
    
    private Integer nivel;
    
    public Dificultad(int nivel){
        this.nivel = nivel;
    }

    public Integer getNivel() {
        return nivel;
    }

    public void setNivel(Integer nivel) {
        this.nivel = nivel;
    }
    
}
