/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hundirlaflota;

import java.io.Serializable;

/**
 *
 * @author sergiojavierre
 */
public class ResultadoAtaque implements Serializable {
    
    private Boolean exito;
    private Integer fila, columna;

    public ResultadoAtaque(){
        exito = false;
        fila = 0;
        columna = 0;
    }
    
    public Boolean getExito() {
        return exito;
    }

    public void setExito(Boolean exito) {
        this.exito = exito;
    }

    public Integer getFila() {
        return fila;
    }

    public void setFila(Integer fila) {
        this.fila = fila;
    }

    public Integer getColumna() {
        return columna;
    }

    public void setColumna(Integer columna) {
        this.columna = columna;
    }
    
    
    
}
