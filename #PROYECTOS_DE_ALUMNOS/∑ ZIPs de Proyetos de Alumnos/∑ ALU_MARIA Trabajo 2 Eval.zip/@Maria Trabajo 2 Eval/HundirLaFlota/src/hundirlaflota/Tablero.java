/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hundirlaflota;

import java.io.Serializable;

/**
 *
 * @author sergiojavierre
 */
public class Tablero implements Serializable{
    
    private Barco posiciones[][];
    private Boolean visible;
    
    public final static Integer tamano = 10;

    public Tablero() {
        posiciones = new Barco[Tablero.tamano][Tablero.tamano];
    }

    public Boolean getVisible() {
        return visible;
    }

    public void setVisible(Boolean visible) {
        this.visible = visible;
    }

    public Barco[][] getPosiciones() {
        return posiciones;
    }
    
    public Boolean cabeBarco(Barco barco){
        int posFila = barco.getFila();
        int posColumna = barco.getColumna();
        int posAbsoluta = 0;
        if(barco.getOrientacion() == Orientacion.VERTICAL){
            posAbsoluta = barco.getFila() + barco.getTamano();
        }
        else{
            posAbsoluta = barco.getColumna() + barco.getTamano();
        }
        if(posAbsoluta>Tablero.tamano){
            if(visible){
                System.out.println("El barco se sale del tablero");
            }
            return false;
        }
        
        for(int i = 0; i < barco.getTamano(); i++){
            if(posiciones[posFila][posColumna]!=null){
                if(visible){
                    System.out.println("El barco no cabe ahí, ya hay otro en esas posiciones");
                }
                return false;
            }
            if(barco.getOrientacion()==Orientacion.VERTICAL){
                posFila++;
            }
            else{
                posColumna++;
            }
        }
        return true;
    }
    
    public void colocaBarco(Barco barco){
        int posFila = barco.getFila();
        int posColumna = barco.getColumna();
        for(int i = 0; i < barco.getTamano(); i++){
            this.posiciones[posFila][posColumna] = barco;
            if(barco.getOrientacion()==Orientacion.VERTICAL){
                posFila++;
            }
            else{
                posColumna++;
            }
        }
    }
    
    public void pinta(){
        System.out.print("   ");
        for(int i = 0; i < tamano; i++){
            System.out.print(" "+i+" ");
        }
        System.out.println("");
        for(int i = 0; i < tamano; i++){
            System.out.print(" "+i+" ");
            for(int j = 0; j < tamano; j++){
                Barco barco = this.posiciones[i][j];
                if(barco==null){
                    System.out.print(Colores.ANSI_BLUE+" - "+Colores.ANSI_RESET);
                }
                else{
                    if(barco.getEstado(i,j)){
                        System.out.print(" X ");
                    }
                    else{
                        System.out.print(Colores.ANSI_RED+" v "+Colores.ANSI_RESET);
                    }
                }
            }
            System.out.println("");
        }
    }
    
}
