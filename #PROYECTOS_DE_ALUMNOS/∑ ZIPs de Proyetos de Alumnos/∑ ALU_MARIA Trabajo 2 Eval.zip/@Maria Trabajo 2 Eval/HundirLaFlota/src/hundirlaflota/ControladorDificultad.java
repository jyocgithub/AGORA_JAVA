/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hundirlaflota;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author sergiojavierre
 */
public class ControladorDificultad {
    
    private Dificultad dificultad;
    
    
    public ControladorDificultad(){
        dificultad = leer();
    }

    public Dificultad getDificultad() {
        return dificultad;
    }
    
    public void elegir(){
        System.out.print("Nivel de dificultad:\n1. Fácil\n2. Normal\n3. Difícil. Elección: ");
        Scanner scanner = new Scanner(System.in);
        int nivel = Integer.parseInt(scanner.nextLine());
        if(dificultad==null){
            dificultad = new Dificultad(nivel);
        }
        else{
            dificultad.setNivel(nivel);
        }
        guardar();
    }
    
    private void guardar(){
        try {
            FileOutputStream fos = new FileOutputStream("dificultad.ser");
            ObjectOutputStream oos = new ObjectOutputStream(fos);
            oos.writeObject(dificultad);
            
        } catch (FileNotFoundException ex) {
            Logger.getLogger(ControladorDificultad.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(ControladorDificultad.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public Dificultad leer(){
        try {
            FileInputStream fis = new FileInputStream("dificultad.ser");
            ObjectInputStream ois = new ObjectInputStream(fis);
            
            dificultad = (Dificultad) ois.readObject();
            
        } catch (FileNotFoundException ex) {
            Logger.getLogger(ControladorDificultad.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(ControladorDificultad.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(ControladorDificultad.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        if(dificultad==null){
            elegir();
        }
        
        return dificultad;
    }
    
}
