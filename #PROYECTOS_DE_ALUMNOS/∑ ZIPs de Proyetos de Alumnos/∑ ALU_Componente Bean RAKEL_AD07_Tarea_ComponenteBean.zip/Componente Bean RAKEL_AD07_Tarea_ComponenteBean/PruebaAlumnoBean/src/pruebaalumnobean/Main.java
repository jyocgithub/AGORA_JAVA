
package pruebaalumnobean;
import Alumno.AlumnoBean;

/**
 *
 * @author usuario
 */
public class Main {


    public static void main(String[] args) {
        
        // RECORDAR QUE HAY QUE TENER EL JAR COMPILADO DE ALUMNOBEAN.JAR
        // AÑADIDO COMO LIBRERIA EN ESTE PROYECTO


        AccedeBD gestion = new AccedeBD();

        gestion.listado();
        gestion.anade();
    }

}
