package Matricula;

import java.beans.*;
import java.io.Serializable;
import java.sql.*;
import java.sql.Statement;
import java.util.*;
import java.sql.Date;
import java.util.logging.Level;
import java.util.logging.Logger;


public class MatriculaBean implements Serializable {

    private PropertyChangeSupport propertySupport;

    /**
     * ***************************************************
     * Propiedades del Bean. Crearemos una propiedad por cada campo de la tabla
     * de la base de datos del siguiente modo:
     *
     * DNI: String dni: String nombremodulo: String curso: double: nota
     */
    public MatriculaBean() {
        propertySupport = new PropertyChangeSupport(this);
        try {
            recargarFilas();
        } catch (ClassNotFoundException ex) {
            this.dni = "";
            this.curso = "";
            this.nombremodulo = "";
            this.nota = 0;
            Logger.getLogger(MatriculaBean.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    protected String dni;
    protected String nombremodulo;
    protected String curso;
    protected double nota;

    /**
     * ***************************************************
     * Clase auxiliar que usaremos para crear un vector privado de matriculas.
     */
    private class Matricula {

        String dni;
        String nombremodulo;
        String curso;
        double nota;

        public Matricula() {
        }

        public Matricula(String dni, String nombremodulo, String curso, double nota) {
            this.dni = dni;
            this.nombremodulo = nombremodulo;
            this.curso = curso;
            this.nota = nota;
        }
    }

    
     /**
     * *****************************************************
     * Método que añade un alumno a la base de datos añade un registro a la base
     * de datos formado a partir de los valores de las propiedades del
     * componente.
     *
     * Se presupone que se han usado los métodos set para configurar
     * adecuadamente las propiedades con los datos del nuevo registro.
     */
    public void addMatricula() throws ClassNotFoundException {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost/alumnos", "root", "");
            PreparedStatement s = con.prepareStatement("insert into matriculas values (?,?,?,?)");

            s.setString(1, dni);
            s.setString(2, nombremodulo);
            s.setString(3, curso);
            s.setDouble(4, nota);
            

            s.executeUpdate();
            recargarFilas();
            receptor.capturarBDModificada(new BDModificadaEvent(this));
        } catch (SQLException ex) {
            Logger.getLogger(MatriculaBean.class.getName()).log(Level.SEVERE, null, ex);
        }

    }
    
    /**
     * ****************************************************
     * Usaremos un vector auxiliar para cargar la información de la tabla de
     * forma que tengamos acceso a los datos sin necesidad de estar conectados
     * constantemente
     */
    private Vector Matriculas = new Vector();

    /**
     * *****************************************************
     * Actualiza el contenido de la tabla en el vector de alumnos Las
     * propiedades contienen el valor del primer elementos de la tabla
     */
    private void recargarFilas() throws ClassNotFoundException {
        Matriculas = new Vector();
        try {
            //    Class.forName("com.mysql.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost/alumnos", "root", "");
            Statement s = con.createStatement();
            ResultSet rs = s.executeQuery("select * from matriculas");
            while (rs.next()) {
                Matricula m = new Matricula(rs.getString("dni"),
                        rs.getString("nombremodulo"),
                        rs.getString("curso"),
                        rs.getDouble("nota"));

                Matriculas.add(m);
            }
            Matricula m = new Matricula();
            m = (Matricula) Matriculas.elementAt(0);
            this.dni = m.dni;
            this.nombremodulo = m.nombremodulo;
            this.curso = m.curso;
            this.nota = m.nota;
            rs.close();
            con.close();
        } catch (SQLException ex) {
            this.dni = "";
            this.nombremodulo = "";
            this.curso = "";
            this.nota = 0;
            Logger.getLogger(MatriculaBean.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public void recargarFilasPorDNI(String dnibuscado)  {
        Matriculas = new Vector();
        try {
            //    Class.forName("com.mysql.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost/alumnos", "root", "");
            Statement s = con.createStatement();
            ResultSet rs = s.executeQuery("select * from matriculas where dni = '"+dnibuscado+"'");
            while (rs.next()) {
                Matricula m = new Matricula(rs.getString("dni"),
                        rs.getString("nombremodulo"),
                        rs.getString("curso"),
                        rs.getDouble("nota"));

                Matriculas.add(m);
            }
            Matricula m = new Matricula();
            m = (Matricula) Matriculas.elementAt(0);
            this.dni = m.dni;
            this.nombremodulo = m.nombremodulo;
            this.curso = m.curso;
            this.nota = m.nota;
            rs.close();
            con.close();
        } catch (SQLException ex) {
            this.dni = "";
            this.nombremodulo = "";
            this.curso = "";
            this.nota = 0;
            Logger.getLogger(MatriculaBean.class.getName()).log(Level.SEVERE, null, ex);
        }
    }


    /**
     * ******************************************************
     *
     * @param i numero de la fila a cargar en las propiedades del componente
     */
    public void seleccionarFila(int i) {
        if (i <= Matriculas.size()) {
            Matricula m = new Matricula();
            m = (Matricula) Matriculas.elementAt(i);
            this.dni = m.dni;
            this.nombremodulo = m.nombremodulo;
            this.curso = m.curso;
            this.nota = m.nota;
        } else {
            this.dni = "";
            this.nombremodulo = "";
            this.curso = "";
            this.nota = 0;
        }
    }

    /**
     * ******************************************************
     *
     * @param nDNI DNI A buscar, se carga en las propiedades del componente
     */
    public void seleccionarDNI(String nDNI) {
        Matricula m = new Matricula();
        int i = 0;

        this.dni = "";
        this.nombremodulo = "";
        this.curso = "";
        this.nota = 0;
        while (this.dni.equals("") && i <= Matriculas.size()) {
            m = (Matricula) Matriculas.elementAt(i);
            if (m.dni.equals(nDNI)) {
                this.dni = m.dni;
                this.nombremodulo = m.nombremodulo;
                this.curso = m.curso;
                this.nota = m.nota;
            }
        }
    }

    public int tamano(){
       return Matriculas.size();
    }
    
    
    
    /**
     * *******************************************************************
     * Código para añadir un nuevo alumno a la base de datos. cada vez que se
     * modifca el estado de la BD se genera un evento para que se recargue el
     * componente.
     */
    private BDModificadaListener receptor;

    public class BDModificadaEvent extends java.util.EventObject {

        // constructor
        public BDModificadaEvent(Object source) {
            super(source);
        }
    }

    //Define la interfaz para el nuevo tipo de evento
    public interface BDModificadaListener extends EventListener {

        public void capturarBDModificada(BDModificadaEvent ev);
    }

    public void addBDModificadaListener(BDModificadaListener receptor) {
        this.receptor = receptor;
    }

    public void removeBDModificadaListener(BDModificadaListener receptor) {
        this.receptor = null;
    }


    /**
     * *****************************************************
     *
     * @param listener
     */
    public void addPropertyChangeListener(PropertyChangeListener listener) {
        propertySupport.addPropertyChangeListener(listener);
    }

    public void removePropertyChangeListener(PropertyChangeListener listener) {
        propertySupport.removePropertyChangeListener(listener);
    }


    /**
     * *******************************************************************
     * Getter y Setter
     */

    public String getDni() {
        return dni;
    }

    public void setDni(String dni) {
        this.dni = dni;
    }

    public String getNombremodulo() {
        return nombremodulo;
    }

    public void setNombremodulo(String nombremodulo) {
        this.nombremodulo = nombremodulo;
    }

    public String getCurso() {
        return curso;
    }

    public void setCurso(String curso) {
        this.curso = curso;
    }

    public double getNota() {
        return nota;
    }

    public void setNota(double nota) {
        this.nota = nota;
    }

}
