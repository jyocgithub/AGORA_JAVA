/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package pruebaMatriculabean;

//import Matricula.MatriculaBean.BDModificadaEvent;
import Matricula.MatriculaBean.BDModificadaListener;
import Matricula.MatriculaBean;
import Matricula.MatriculaBean.BDModificadaEvent;
import java.sql.Date;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author usuario
 */
public class AccedeBDMatriculas implements BDModificadaListener {

    MatriculaBean matricula;

    AccedeBDMatriculas() {
        matricula = new MatriculaBean();
        matricula.addBDModificadaListener((BDModificadaListener) this);
    }

    public void listado() {
        for (int i = 0; i < matricula.tamano(); i++) {
            matricula.seleccionarFila(i);
            System.out.println("Matricula " + i + "\n\tdni:" + matricula.getDni());
            System.out.println("\tnombremodulo: " + matricula.getNombremodulo());
            System.out.println("\tcurso: " + matricula.getCurso());
            System.out.println("\tnota: " + matricula.getNota());
        }
    }

    public void listadoPorDNI(String dni) {
        matricula.recargarFilasPorDNI(dni);
        for (int i = 0; i < matricula.tamano(); i++) {
            matricula.seleccionarFila(i);
            System.out.println("Matricula " + i + "\n\tdni:" + matricula.getDni());
            System.out.println("\tnombremodulo: " + matricula.getNombremodulo());
            System.out.println("\tcurso: " + matricula.getCurso());
            System.out.println("\tnota: " + matricula.getNota());
        }
    }

    public void consultarFila(int i) {

        matricula.seleccionarFila(i);
        System.out.println("Matricula " + i + "\n\tdni:" + matricula.getDni());
        System.out.println("\tnombremodulo: " + matricula.getNombremodulo());
        System.out.println("\tcurso: " + matricula.getCurso());
        System.out.println("\tnota: " + matricula.getNota());

    }

    void anade() {
        matricula.setDni("12345678A");
        matricula.setNombremodulo("ARABE");
        matricula.setCurso("18-19");
        matricula.setNota(7);

        try {
            matricula.addMatricula();
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(AccedeBDMatriculas.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void capturarBDModificada(BDModificadaEvent ev) {
        System.out.println("Se ha añadido un elemento a la base de datos");
    }
}
