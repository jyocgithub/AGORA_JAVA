
package pruebaMatriculabean;


public class MainMatriculas {

    public static void main(String[] args) {
        
        // RECORDAR QUE HAY QUE TENER EL JAR COMPILADO DE MATRICULABEAN.JAR
        // AÑADIDO COMO LIBRERIA EN ESTE PROYECTO

        AccedeBDMatriculas gestion = new AccedeBDMatriculas();

        gestion.listado();
        System.out.println("--------------------------");

        gestion.anade();
        gestion.listado();
        System.out.println("--------------------------");
       
        gestion.consultarFila(3);
        System.out.println("--------------------------");
       
        gestion.listadoPorDNI("12345678A");
         System.out.println("--------------------------");
    }

}
