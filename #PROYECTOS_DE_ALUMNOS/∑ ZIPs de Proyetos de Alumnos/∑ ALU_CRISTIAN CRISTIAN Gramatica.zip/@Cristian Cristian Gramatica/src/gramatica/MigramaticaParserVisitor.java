// Generated from /Users/iniaki/WorkSpaces/1.JAVA/🤖 CRISTIAN/Cristian Gramatica/src/gramatica/MigramaticaParser.g4 by ANTLR 4.7.1

	package gramatica;

import org.antlr.v4.runtime.tree.ParseTreeVisitor;

/**
 * This interface defines a complete generic visitor for a parse tree produced
 * by {@link MigramaticaParser}.
 *
 * @param <T> The return type of the visit operation. Use {@link Void} for
 * operations with no return type.
 */
public interface MigramaticaParserVisitor<T> extends ParseTreeVisitor<T> {
	/**
	 * Visit a parse tree produced by {@link MigramaticaParser#csv}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCsv(MigramaticaParser.CsvContext ctx);
	/**
	 * Visit a parse tree produced by {@link MigramaticaParser#cabecera}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCabecera(MigramaticaParser.CabeceraContext ctx);
	/**
	 * Visit a parse tree produced by {@link MigramaticaParser#linea}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitLinea(MigramaticaParser.LineaContext ctx);
	/**
	 * Visit a parse tree produced by {@link MigramaticaParser#campo}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCampo(MigramaticaParser.CampoContext ctx);
}