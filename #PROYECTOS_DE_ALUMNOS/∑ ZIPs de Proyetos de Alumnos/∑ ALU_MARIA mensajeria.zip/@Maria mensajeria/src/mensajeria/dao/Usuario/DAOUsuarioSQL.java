/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mensajeria.dao.Usuario;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import mensajeria.dao.ConfiguracionBBDD;
import mensajeria.modelo.Usuario;

/**
 *
 * @author mrs123456
 */
public class DAOUsuarioSQL implements DAOUsuario{


    @Override
    public void inserta(Usuario usuario) {
    try{
        Statement stmt = ConfiguracionBBDD.getInstance().getConnection().createStatement();
        stmt.execute("insert into Usuario (Nombre,Correo,Nick,Contrasena,Foto,Estado)"
            +"values ('"+usuario.getNombre()+
                "','"+usuario.getCorreo()+
                "','"+usuario.getNick()+
                "','"+usuario.getContrasena()+
                "','"+usuario.getFoto()+
                "','"+usuario.getEstado()+
                "')");
        
        stmt.close();
        
    }   catch (SQLException ex) {
            Logger.getLogger(DAOUsuarioSQL.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @Override
    public List<Usuario> listadoUsuarios() {
        List<Usuario> usuarios = new ArrayList <Usuario>();
        try{
            Statement stmt = ConfiguracionBBDD.getInstance().getConnection().createStatement();
            ResultSet rs = stmt.executeQuery("select * from Usuario");
            while (rs.next()){
                
                Usuario usuario = new Usuario();
                usuario.setId_usuario(rs.getString("Id_usuario"));
                usuario.setNombre(rs.getString("Nombre")); 
                //usuario.setCorreo(rs.getString("Correo"));
                //usuario.setNick(rs.getString("Nick"));
                //usuario.setContrasena(rs.getString("Contrasena"));
                //usuario.setFoto(rs.getString("Foto"));
                //usuario.setEstado(rs.getString("Estado"));
   
                usuarios.add(usuario);
                
            }
            rs.close();
            stmt.close();
        }
        
        catch (SQLException ex){
            System.err.println(ex.getMessage());
        }
        return usuarios;
        
    }
   

    @Override
    public void actualiza(Usuario actualizado) {
        
        
        try {
            Statement statement = ConfiguracionBBDD.getInstance().getConnection().createStatement();
            statement.execute("update usuario"
                    + "set Nombre='"+actualizado.getNombre()+"' "
                    + "where Id_usuario = '"+actualizado.getId_usuario()+"'");
 
            
            statement.close();
        } catch (SQLException ex) {
            Logger.getLogger(DAOUsuarioSQL.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @Override
    public void borra(Usuario usuario) {

               try {
            Statement stmt = ConfiguracionBBDD.getInstance().getConnection().createStatement();
            stmt.execute("delete from usuario "
                            + "where Id_usuario = '"+usuario.getId_usuario()+"'");
            stmt.close();
        } catch (SQLException ex) {
            Logger.getLogger(DAOUsuarioSQL.class.getName()).log(Level.SEVERE, null, ex);
        }



    }

    @Override
    public boolean iniciarSesion(Usuario usuario) {

        
        try{
                Statement stmt = ConfiguracionBBDD.getInstance().getConnection().createStatement();
                ResultSet rs= stmt.executeQuery ("select correo,contrasena from usuario where correo=? and contrasena=?");
           
            if(rs.next()){
                if(usuario.getContrasena().equals(rs.getString("contrasena"))){
 
                    
                    usuario.setCorreo(rs.getString("correo"));
                    usuario.setContrasena(rs.getString("contrasena"));

                    return true;
                }
                else{
                    return false;
                }
            }
           
            return false;
            
        }catch(Exception ex){
            return false;
        }
    }
    
    }

