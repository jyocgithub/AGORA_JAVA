/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mensajeria.dao.Usuario;

import java.util.List;
import mensajeria.modelo.Usuario;

/**
 *
 * @author mrs123456
 */
public interface DAOUsuario {
    
    public void inserta (Usuario usuario);
    public List<Usuario>listadoUsuarios();
    public void actualiza (Usuario actualizado);
    public void borra (Usuario usuario);
    
    public boolean iniciarSesion (Usuario usuario);
    
    
    
}
