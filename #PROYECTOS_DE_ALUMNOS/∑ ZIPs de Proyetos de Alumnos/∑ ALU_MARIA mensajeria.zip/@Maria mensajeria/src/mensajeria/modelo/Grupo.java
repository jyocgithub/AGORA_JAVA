/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mensajeria.modelo;

/**
 *
 * @author mrs123456
 */
public class Grupo {
    
    private String Id_grupo;
    private String Nombre_grupo;
    private String Icono;

    public String getId_grupo() {
        return Id_grupo;
    }

    public void setId_grupo(String Id_grupo) {
        this.Id_grupo = Id_grupo;
    }

    public String getNombre_grupo() {
        return Nombre_grupo;
    }

    public void setNombre_grupo(String Nombre_grupo) {
        this.Nombre_grupo = Nombre_grupo;
    }

    public String getIcono() {
        return Icono;
    }

    public void setIcono(String Icono) {
        this.Icono = Icono;
    }
    
    
    
}
