/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mensajeria.modelo;

/**
 *
 * @author mrs123456
 */
public class Amistad {
    private String Estado_amistad;
    private String Id_usuario_emisor;
    private String Id_usuario_receptor;

    public String getEstado_amistad() {
        return Estado_amistad;
    }

    public void setEstado_amistad(String Estado_amistad) {
        this.Estado_amistad = Estado_amistad;
    }

    public String getId_usuario_emisor() {
        return Id_usuario_emisor;
    }

    public void setId_usuario_emisor(String Id_usuario_emisor) {
        this.Id_usuario_emisor = Id_usuario_emisor;
    }

    public String getId_usuario_receptor() {
        return Id_usuario_receptor;
    }

    public void setId_usuario_receptor(String Id_usuario_receptor) {
        this.Id_usuario_receptor = Id_usuario_receptor;
    }
    
    
}
