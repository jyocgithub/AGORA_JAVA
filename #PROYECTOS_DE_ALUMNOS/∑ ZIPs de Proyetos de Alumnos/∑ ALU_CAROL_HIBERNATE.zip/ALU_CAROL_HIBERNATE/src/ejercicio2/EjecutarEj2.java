package ejercicio2;


public class EjecutarEj2 {

	public static void main(String[] args) {
		
		 ManejoBBDD ej2=new ManejoBBDD();
		 
		 ej2.mostrarDepartamentoConId20();
	    
		 
		System.out.println("\n** Director del departamento 10 ** ");
		System.out.println(ej2.mostrarEmpleados10Director());
	
		 
		 ej2.aumentoSalario();
		 
		 //ej2.borrarEmpleadosDept20();
		 
		 System.out.println("\n*******   Empleados de Ventas:   ***********");
		ej2.empleadosDepartamentoSales();
		
		 System.out.println("\n*******   Media de Salarios:   ***********");
		ej2.mostrarMediaSalario();
		 
		
		
		
		
		
		
		
		System.exit(0);

	}

}
