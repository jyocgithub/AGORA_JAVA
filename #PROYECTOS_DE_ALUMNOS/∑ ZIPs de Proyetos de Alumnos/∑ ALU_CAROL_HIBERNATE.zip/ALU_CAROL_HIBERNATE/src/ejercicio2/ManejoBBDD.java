package ejercicio2;

import java.math.BigDecimal;
import java.util.List;
import java.util.Set;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

import tablas.Dept;
import tablas.Emp;
import utils.SessionFactoryUtil;

public class ManejoBBDD {

	private SessionFactory sessionFactory = SessionFactoryUtil.createSessionFactory();
	private Session session = null;
	private Transaction transaction = null;

	public ManejoBBDD() {

	}

	public void mostrarDepartamentoConId20() {

		session = sessionFactory.openSession();

		try {
			transaction = session.beginTransaction();
			Dept dept = (Dept) session.createQuery("FROM Dept where deptno=20").uniqueResult();
			Set<Emp> empList = dept.getEmps();
			System.out.println(dept);
			System.out.println("Apellidos de los empleados con dept=20");
			for (Emp empleado : empList) {
				System.out.println(empleado.getEname());
			}
			transaction.commit();
		} catch (HibernateException ex) {
			// si da alguna excepcion cancelo los cambios
			if (transaction != null) {
				transaction.rollback();
			}
			// mostrar la excepcion
			ex.printStackTrace();

		} finally {
			// Close the session
			session.close();
		}

	}

	public Emp mostrarEmpleados10Director() {

		Emp empList = null;
		session = sessionFactory.openSession();

		try {
			transaction = session.beginTransaction();
			String hql = "FROM  Emp WHERE dept = 10 AND job = 'MANAGER' ";
			empList = (Emp) session.createQuery(hql).uniqueResult();
			transaction.commit();
		} catch (HibernateException ex) {
			// si da alguna excepcion cancelo los cambios
			if (transaction != null) {
				transaction.rollback();
			}
			// mostrar la excepcion
			ex.printStackTrace();

		} finally {
			// Close the session
			session.close();
		}

		return empList;

	}

	@SuppressWarnings("unchecked")
	public void aumentoSalario() {
		session = sessionFactory.openSession();
		try {

			transaction = session.beginTransaction();

			String hqlGet = "FROM Emp  WHERE ename = 'ADAMS' ";
			String hqlModificar = "UPDATE Emp emp SET sal = :updatedSal WHERE ename = 'ADAMS' ";

			// empleado Ford

			Query<Emp> query = session.createQuery(hqlGet);

			// aumentarle el sueldo
			Emp emp = (Emp) query.uniqueResult();
			BigDecimal empSal = emp.getSal();
			double updEmpSal = empSal.doubleValue() + (empSal.doubleValue() * 0.2);
			empSal = BigDecimal.valueOf(updEmpSal);

			// Ejecutar el Update
			query = session.createQuery(hqlModificar);
			query.setParameter("updatedSal", empSal);
			query.executeUpdate();

			transaction.commit();

		} catch (HibernateException ex) {

			if (transaction != null)
				transaction.rollback();
			ex.printStackTrace();

		} finally {
			// Close the session
			session.close();
		}

	}

	public void borrarEmpleadosDept20() {

		session = sessionFactory.openSession();

		try {

			transaction = session.beginTransaction();

			String hql = "DELETE Emp  WHERE deptno = '20' ";

			session.createQuery(hql).executeUpdate();

			transaction.commit();

		} catch (HibernateException ex) {

			if (transaction != null)
				transaction.rollback();
			ex.printStackTrace();

		} finally {
			// Close the session
			session.close();
		}

	}

	public void empleadosDepartamentoSales() {

		List<?> list = null;
		session = sessionFactory.openSession();

		try {

			transaction = session.beginTransaction();

			String hql = "FROM Emp emp INNER JOIN emp.dept dept WHERE dept.dname = 'SALES' AND emp.sal >= '1500'";

			list = session.createQuery(hql).list();

			for (int i = 0; i < list.size(); i++) {

				Object[] row = (Object[]) list.get(i);
				Emp emp = (Emp) row[0];
				Dept dept = (Dept) row[1];

				String empNo = String.valueOf(emp.getEmpno());
				String name = emp.getEname();
				String job = emp.getJob();

				Emp mngr = emp.getEmp();
				String mngrNo = null;
				if (mngr != null)
					mngrNo = String.valueOf(emp.getEmp().getEmpno());

				String hireDate = emp.getHiredate().toString();
				String salary = String.valueOf(emp.getSal());
				String comm = String.valueOf(emp.getComm());
				String deptName = dept.getDname();

				System.out.format(empNo + " - " + name + " - " + job + " - " + mngrNo + " - " + hireDate + " - "
						+ salary + " - " + comm + " - " + deptName);
				System.out.println();

			} // for

			transaction.commit();

		} catch (HibernateException ex) {

			if (transaction != null)
				transaction.rollback();
			ex.printStackTrace();

		} finally {
			// Close the session
			session.close();
		}

	}

	@SuppressWarnings("unchecked")
	public void mostrarMediaSalario() {

		session = sessionFactory.openSession();

		try {

			transaction = session.beginTransaction();

			String hqlDept = "FROM Dept ";
			String hqlEmp = "SELECT avg(emp.sal) FROM Emp WHERE emp.dept.deptno = :deptNo";

			List<Dept> listDept = session.createQuery(hqlDept).list();

			for (Dept dept : listDept) {

				Query<?> query2 = session.createQuery(hqlEmp);
				query2.setParameter("deptNo", dept.getDeptno());
				List<?> listEmpData = query2.list();

				System.out.println(
						dept.getDeptno() + " - " + dept.getDname() + " - " + String.valueOf(listEmpData.get(0)));

			}

			System.out.println();

			transaction.commit();

		} catch (HibernateException ex) {

			if (transaction != null)
				transaction.rollback();
			ex.printStackTrace();

		} finally {

			session.close();

		} // finally
	}
}
