package EDUARDO_practica_sax_dom.practicaaccesoadatos_ficheros;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

import java.util.ArrayList;

public class ControladorSaxLectura extends DefaultHandler {

     ArrayList<Libro> listaLibros = new ArrayList<>();
     ArrayList<Autor> listaAutores;
     Libro unLibro;
     Autor unAutor;
     String etiquetaActual = "";

     @Override
     public void startDocument() throws SAXException {
          // esto se ejecuta al comenzar a leer el documento.  
     }

     @Override
     public void endDocument() throws SAXException {
          // esto se ejecuta al finalizar de leer el documento
     }

     @Override
     public void startElement(String uri, String localName, String qname, Attributes attributes) throws SAXException {
          // debemos guardarnos qué etiqueta estamos leyendo en cada momento
          etiquetaActual = qname;
          // al emplezar a leer cada elemento, solo me interesan los elementos que tienen atributos
          if (qname.equalsIgnoreCase("libro")) {
               // como es comienzo de libro, creo un nuevo libro para darle datos
               unLibro = new Libro();
               // como es comienzo de libro, creo un nuevo array de autores para darle datos
               listaAutores = new ArrayList<>();
               // la etiqueta tiene atributo, asi que lo leo
               String elaño = attributes.getValue("año");
               // nos aseguramos que el atributo tiene valor
               if (elaño != null) {
                    unLibro.setAño(Integer.parseInt(elaño));
               }
          }
          if (qname.equalsIgnoreCase("autor")) {
               // como es comienzo de autor creo un nuevo autor para darle datos
               unAutor = new Autor();
          }
     }

     @Override
     public void characters(char[] ch, int start, int length) throws SAXException {
          // aqui entra en cuanto empieza a leerse un texo dentro de una etiqueta,
          // sabemos que etiqueta estamos leyendo, asi que cogemos el texto...
          String texto = new String(ch, start, length);
          // eliminamos los caracteres raros como los saltos de linea
          texto.replaceAll("[\n\t]", "");
          // eliminamos los espscios delante y detras del texto
          texto = texto.trim();
          // y lo asignamos al elemento del libro o autor que corresponde...
          if (etiquetaActual.equalsIgnoreCase("titulo")) {
               unLibro.setTitulo(texto);
          }
          if (etiquetaActual.equalsIgnoreCase("editorial")) {
               unLibro.setEditorial(texto);
          }
          if (etiquetaActual.equalsIgnoreCase("precio")) {
               double textoenint = Double.parseDouble(texto);
               unLibro.setPrecio(textoenint);
          }
          if (etiquetaActual.equalsIgnoreCase("apellido")) {
               unAutor.setApellido(texto);
          }
          if (etiquetaActual.equalsIgnoreCase("nombre")) {
               unAutor.setNombre(texto);
          }


          // finalmente borramos la variable etiquetaActual, pues ya hemos acabado de leer una etiqueta
          etiquetaActual = "";
     }

     @Override
     public void endElement(String uri, String localName, String name) {
          // aqui entra en cuanto se leer una etiqueta de fin 
          // ahora, ademas, vemos si la etiqueta es la ultima de un libro o un autor, 
          // y en tal caso, podemos acabar de crear un libro o autor
          if (name.equalsIgnoreCase("nombre")) {
               // al acabar de leer un autor, añadimos el autor a su arraylist
               listaAutores.add(unAutor);
          }
          if (name.equalsIgnoreCase("precio")) {
               // al acabar de leer un libro, añadimos todos los autores que se hayan creado
               unLibro.setAutores(listaAutores);

               // al acabar de leer un libro, añadimos el libro a su arraylist
               listaLibros.add(unLibro);
          }
     }

     public ArrayList<Libro> getListaLibros() {
          return listaLibros;
     }
}
