package EDUARDO_practica_sax_dom.practicaaccesoadatos_ficheros;

public class Autor {

    private String apellido;
    private String nombre;

    public Autor(String apellido, String nombre) {
        this.apellido = apellido;
        this.nombre = nombre;
    }

    public Autor() {
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

     @Override
     public String toString() {
          return "Autor{" + "apellido=" + apellido + ", nombre=" + nombre + '}';
     }
}
