/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.joserra.pruebamongopojos.modelo;

import org.bson.types.ObjectId;

/**
 *
 * @author joserra
 */
public final class Persona {
    private ObjectId id;
    private String nombre;
    private int edad;
    private Direccion direccion;

    public Persona() {
    }

    public Persona(String nombre, int edad, Direccion direccion) {
        this.nombre = nombre;
        this.edad = edad;
        this.direccion = direccion;
    }
    
    

    public ObjectId getId() {
        return id;
    }

    public void setId(ObjectId id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public Direccion getDireccion() {
        return direccion;
    }

    public void setDireccion(Direccion direccion) {
        this.direccion = direccion;
    }
    
    //Resto de la implementacion

    @Override
    public String toString() {
        return "Persona{nombre=" + nombre + ", edad=" + edad + ", direccion=" + direccion + '}';
    }
    
    
}
