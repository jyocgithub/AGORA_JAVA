/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package MARIA_hundir_la_flota;

/**
 *
 * @author mrs123456
 */
public class Dificultad {
    
    private void dificultadNormal(){
        
    }
    
    private void dificultadFacil(){
        
    }
    
    private void dificultadDificil(){
        
    }
    
}
