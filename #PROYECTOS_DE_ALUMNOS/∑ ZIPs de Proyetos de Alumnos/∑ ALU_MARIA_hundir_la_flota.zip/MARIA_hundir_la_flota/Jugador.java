/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package MARIA_hundir_la_flota;

import java.util.Scanner;

/**
 *
 * @author mrs123456
 */
public class Jugador {
    
    
    public final static int tamanioMaximo = 10;
    
          char[][] casillasAtaques = new char[tamanioMaximo][tamanioMaximo];//matriz(tablero) donde apuntaremos los ataques

    private void ataque(){
       Scanner entrada = new Scanner (System.in);
       int fila,columna;
       
        Barco barco = new Barco();
        
        System.out.println("Introduce fila: ");
        barco.setFila(entrada.nextInt());
        
        System.out.println("Introduce columna: ");
        barco.setColumna(entrada.nextInt());
        
    if(casillasAtaques[barco.getFila()][barco.getColumna()] == 'p' || 
       casillasAtaques[barco.getFila()][barco.getColumna()] == 'q' ||
       casillasAtaques[barco.getFila()][barco.getColumna()] == 's' ||
       casillasAtaques[barco.getFila()][barco.getColumna()] == 'b' ){ //añadir las letras de cada baro) //miramos si se cruzan kos barcos. si los valores introducidos estan vacios se coloca el barco que la letra que lo indica. si esta ocupada dira que coloques otra posicion
        
        
      
    }else if(casillasAtaques[barco.getFila()][barco.getColumna()]!='~'){
        
        System.out.println("agua");
    
            
            
        }
 
        
    }   
    
//metodos jugador maquina
    

private void ataqueAdyacente(){
       
        
    }

}