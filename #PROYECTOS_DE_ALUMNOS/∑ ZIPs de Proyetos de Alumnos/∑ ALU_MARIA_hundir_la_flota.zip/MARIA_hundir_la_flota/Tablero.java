/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package MARIA_hundir_la_flota;

import java.util.Random;
import java.util.Scanner;

/**
 *
 * @author mrs123456
 */
public class Tablero {
    
  /*en tablero recogeremos toda la informacion para consultar las partidas
 Jugadores, Ganador, Fecha y hora, Estado barcos maquina, Estado barcos jugador
 */
    
       //Creamos matriz para el trablero
    
    public final static int tamanioMaximo = 10;
    
          char[][] casillas = new char[tamanioMaximo][tamanioMaximo];
   
          
 public void crearTableroJugador(){
 
     Scanner entrada = new Scanner (System.in);
       int fila,columna,orientacion;
    
        //Rellenar la matriz
        for(int x=0;x<10;x++){
            for(int y=0;y<10;y++){
                 //Es el borde de las filas
                    casillas[x][y] = '~';     
            }
        }
    //introducimos los barcos
    Barco barco = new Barco();
        //introducimos portaviones
       
            
            System.out.println("Introduce la fila de cabecera del Portaviones: ");
        //introduzco la fila del portaviones
            barco.setFila(entrada.nextInt());
        
        System.out.println("Introduce la columna de cabecera");
        barco.setColumna(entrada.nextInt());;
        
        
        //Si la fila esta entre 1 y 10 le digo que me inserte la columna 
        if ((barco.getFila()>=0 && barco.getFila()<=tamanioMaximo)&& (barco.getColumna()>=0 && barco.getColumna()<=tamanioMaximo)){
            
            System.out.println("vertical (1) u horizontal (0): ");   
            orientacion=entrada.nextInt(); 
            
            if(orientacion==1){
                barco.setOrientacion(Orientacion.VERTICAL);
            }else if (orientacion == 0){
                barco.setOrientacion(Orientacion.HORIZONTAL);
            }
            else{System.out.println("introduce una posicion correcta");}
        
        } else{ System.out.println("introduce valores correctos"); }
        
        
        if(barco.getOrientacion() == Orientacion.VERTICAL){
           for(int i=0;i<6;i++){casillas[barco.getFila()+i][barco.getColumna()]='p';}
        }else if(barco.getOrientacion() == Orientacion.HORIZONTAL){//6 porque son 6 casillas las que ocupa el portaaviones
            for(int i=0;i<6;i++){casillas[barco.getFila()][barco.getColumna()+i]='p';}  
        }

        //if (barco.getFila())
       
        
        //mostrar tablero
        System.out.println("\nTablero Jugador: \n");
        for(int x=0;x<10;x++){
            for(int y=0;y<10;y++){
                System.out.print(casillas[x][y]+" ");
            }
            System.out.println("");
        }
        System.out.println("");
        
        
        //introducimos el buque
        for(int buque=0;buque<2;buque++){
            
        
        
      System.out.println("Introduce la fila de cabecera del Buque "+ (buque+1) +": ");
        //introduzco la fila del portaviones
            barco.setFila(entrada.nextInt());
        
        System.out.println("Introduce la columna de cabecera");
        barco.setColumna(entrada.nextInt());
        
        
        //Si la fila esta entre 1 y 10 le digo que me inserte la columna 
        if ((barco.getFila()>=0 && barco.getFila()<=tamanioMaximo)&& (barco.getColumna()>=0 && barco.getColumna()<=tamanioMaximo)){
            
            System.out.println("vertical (1) u horizontal (0): ");   
            orientacion=entrada.nextInt(); 
            
            if(orientacion==1){
                barco.setOrientacion(Orientacion.VERTICAL);
            }else if (orientacion == 0){
                barco.setOrientacion(Orientacion.HORIZONTAL);
            }
            else{System.out.println("introduce una posicion correcta");}
        
        } else{ System.out.println("introduce valores correctos"); }
        
        
   //aqui comprobamos que no se crucen los barcos     
   if (casillas[barco.getFila()][barco.getColumna()] == '~'){
        if(barco.getOrientacion() == Orientacion.VERTICAL){
           for(int i=0;i<4;i++){casillas[barco.getFila()+i][barco.getColumna()]='b';}
        }else if(barco.getOrientacion() == Orientacion.HORIZONTAL){//4 porque son 4 casillas las que ocupa el buque
            for(int i=0;i<4;i++){casillas[barco.getFila()][barco.getColumna()+i]='b';}  
       }
   }else if(casillas[barco.getFila()][barco.getColumna()]!='~'){
        
        System.out.println("se cruzan los barcos. Introduce de nuevo la posicion.");
        
        
    }
  
        
//mostrar tablero
        System.out.println("\nTablero Jugador: \n");
        for(int x=0;x<10;x++){
            for(int y=0;y<10;y++){
                System.out.print(casillas[x][y]+" ");
            }
            System.out.println("");
        }
        System.out.println("");
        
        }
                
    
        
 //introducimos el pesquero
        
        for(int submarino=0;submarino<3; submarino++){
        
              System.out.println("Introduce la fila de cabecera del Submarino "+(submarino+1)+": ");
        //introduzco la fila del portaviones
            barco.setFila(entrada.nextInt());
        
        System.out.println("Introduce la columna de cabecera");
        barco.setColumna(entrada.nextInt());
        
        
        //Si la fila esta entre 1 y 10 le digo que me inserte la columna 
        if ((barco.getFila()>=0 && barco.getFila()<=tamanioMaximo)&& (barco.getColumna()>=0 && barco.getColumna()<=tamanioMaximo)){
            
            System.out.println("vertical (1) u horizontal (0): ");   
            orientacion=entrada.nextInt(); 
            
            if(orientacion==1){
                barco.setOrientacion(Orientacion.VERTICAL);
            }else if (orientacion == 0){
                barco.setOrientacion(Orientacion.HORIZONTAL);
            }
            else{System.out.println("introduce una posicion correcta");}
        
        } else{ System.out.println("introduce valores correctos"); }
        
        
        if(barco.getOrientacion() == Orientacion.VERTICAL){
           for(int i=0;i<2;i++){casillas[barco.getFila()+i][barco.getColumna()]='s';}
        }else if(barco.getOrientacion() == Orientacion.HORIZONTAL){//2 porque son 2 casillas las que ocupa el buque
            for(int i=0;i<2;i++){casillas[barco.getFila()][barco.getColumna()+i]='s';}  
        }

       //mostrar tablero
        System.out.println("\nTablero Jugador: \n");
        for(int x=0;x<10;x++){
            for(int y=0;y<10;y++){
                System.out.print(casillas[x][y]+" ");
            }
            System.out.println("");
        }
        System.out.println("");
        
        }
        
        
        //introducimos el pesquero
        
        for(int pesquero=0; pesquero<4; pesquero++){
        
              System.out.println("Introduce la fila de cabecera del Pesquero"+(pesquero+1)+": ");
        //introduzco la fila del portaviones
            barco.setFila(entrada.nextInt());
        
        System.out.println("Introduce la columna de cabecera");
        barco.setColumna(entrada.nextInt());
        
        
        //Si la fila esta entre 1 y 10 le digo que me inserte la columna 
        if ((barco.getFila()>=0 && barco.getFila()<=tamanioMaximo)&& (barco.getColumna()>=0 && barco.getColumna()<=tamanioMaximo)){
            
            System.out.println("vertical (1) u horizontal (0): ");   
            orientacion=entrada.nextInt(); 
            
            if(orientacion==1){
                barco.setOrientacion(Orientacion.VERTICAL);
            }else if (orientacion == 0){
                barco.setOrientacion(Orientacion.HORIZONTAL);
            }
            else{System.out.println("introduce una posicion correcta");}
        
        } else{ System.out.println("introduce valores correctos"); }
        
        
        if(barco.getOrientacion() == Orientacion.VERTICAL){
           for(int i=0;i<1;i++){casillas[barco.getFila()+i][barco.getColumna()]='q';}
        }else if(barco.getOrientacion() == Orientacion.HORIZONTAL){//2 porque son 2 casillas las que ocupa el buque
            for(int i=0;i<1;i++){casillas[barco.getFila()][barco.getColumna()+i]='q';}  
        }

       //mostrar tablero
        System.out.println("\nTablero Jugador: \n");
        for(int x=0;x<10;x++){
            for(int y=0;y<10;y++){
                System.out.print(casillas[x][y]+" ");
            }
            System.out.println("");
        }
        System.out.println("");
        }
    }
    
 
 public boolean cabe(Barco barco){
     /*
     comprobar si el barco cabe o no cabe en el tablero y se se solapan o no con otros. retornar true o false
     */
     /*
     if (barco == barco.getTamano()){
       return true;  
     }else if ((barco != barco.getTamano()){
         return false;
         System.out.println("El barco no cabe");
     }
     */
     
     if(barco.getOrientacion()==Orientacion.VERTICAL){
        int tamanioTotal = barco.getColumna()+barco.getTamano();
        if(tamanioTotal>Tablero.tamanioMaximo){
            return false;
        }
        for(int i = 0; i < barco.getTamano();i++){
            if(
                casillas[barco.getFila()+i][barco.getColumna()]=='p' ||
                casillas[barco.getFila()+i][barco.getColumna()]=='q' ||
                casillas[barco.getFila()+i][barco.getColumna()]=='s' ||
                casillas[barco.getFila()+i][barco.getColumna()]=='b'
                ){
                return false;
            }
        }
        
     }
     else if(barco.getOrientacion()== Orientacion.HORIZONTAL){//mirarlo con la horizontal  
        int tamanioTotal=barco.getFila()+barco.getTamano();
        if(tamanioTotal>Tablero.tamanioMaximo){
            return false;
        }else if(tamanioTotal<Tablero.tamanioMaximo){
            return true;
        }
        for(int i = 0; i < barco.getTamano();i++){
            if(
                casillas[barco.getFila()][barco.getColumna()+i]=='p' ||
                casillas[barco.getFila()][barco.getColumna()+i]=='q' ||
                casillas[barco.getFila()][barco.getColumna()+i]=='s' ||
                casillas[barco.getFila()][barco.getColumna()+i]=='b'
                ){
                return false;
            }
        }
     }
     
     return true;
     
 }   

 public void crearTableroMaquina (){
     
     Scanner entrada = new Scanner (System.in);
       int fila,columna,orientacion;
              Random random = new Random();
        
        
    
        //Rellenar la matriz
        for(int x=0;x<10;x++){
            for(int y=0;y<10;y++){
                 //Es el borde de las filas
                    casillas[x][y] = '~';     
            }
        }
     
         //introducimos los barcos
    Barco barco = new Barco();
    
    //introducimos portaviones
      
        //introduzco la fila del portaviones
            barco.setFila(random.nextInt(10));
        
        //introduzco la columna del portaviones
        barco.setColumna(random.nextInt(10));
        
        
        //Si la fila esta entre 1 y 10 le digo que me inserte la columna 
        if ((barco.getFila()>=0 && barco.getFila()<=tamanioMaximo)&& (barco.getColumna()>=0 && barco.getColumna()<=tamanioMaximo)){
            
            //posicion vertical u horizontal  
            //orientacion=ranwdom.nextInt(2); 
            
            if(random.nextBoolean()){
                barco.setOrientacion(Orientacion.VERTICAL);
            }else {
                barco.setOrientacion(Orientacion.HORIZONTAL);
            }
        
        } else{ System.out.println("La maquina no ha introducido los datos correctamente"); }
        
        
        if(barco.getOrientacion() == Orientacion.VERTICAL){
           for(int i=0;i<6;i++){casillas[barco.getFila()+i][barco.getColumna()]='p';}
        }else if(barco.getOrientacion() == Orientacion.HORIZONTAL){//6 porque son 6 casillas las que ocupa el portaaviones
            for(int i=0;i<6;i++){casillas[barco.getFila()][barco.getColumna()+i]='p';}  
        }

       
     /*  
        //mostrar tablero
        System.out.println("\nTablero Maquina: \n");
        for(int x=0;x<10;x++){
            for(int y=0;y<10;y++){
                System.out.print(casillas[x][y]+" ");
            }
            System.out.println("");
        }
        System.out.println("");
       */ 
        
//introducimos buque
      
        //introduzco la fila del buque
            barco.setFila(random.nextInt(10));
        
        //introduzco la columna del buque
        barco.setColumna(random.nextInt(10));
        
        
        //Si la fila esta entre 1 y 10 le digo que me inserte la columna 
        if ((barco.getFila()>=0 && barco.getFila()<=tamanioMaximo)&& (barco.getColumna()>=0 && barco.getColumna()<=tamanioMaximo)){
            
            //posicion vertical u horizontal  
             
            
            if(random.nextBoolean()){
                barco.setOrientacion(Orientacion.VERTICAL);
            }else {
                barco.setOrientacion(Orientacion.HORIZONTAL);
            }
        
        } else{ System.out.println("La maquina no ha introducido los datos correctamente"); }
        
        
        if(barco.getOrientacion() == Orientacion.VERTICAL){
           for(int i=0;i<4;i++){casillas[barco.getFila()+i][barco.getColumna()]='b';}
        }else if(barco.getOrientacion() == Orientacion.HORIZONTAL){//4 porque son 4 casillas las que ocupa el portaaviones
            for(int i=0;i<4;i++){casillas[barco.getFila()][barco.getColumna()+i]='b';}  
        }

       /*
        
        //mostrar tablero
        System.out.println("\nTablero Maquina: \n");
        for(int x=0;x<10;x++){
            for(int y=0;y<10;y++){
                System.out.print(casillas[x][y]+" ");
            }
            System.out.println("");
        }
        System.out.println("");
       
        */
         //introducimos submarino
      
        //introduzco la fila del submarino
            barco.setFila(random.nextInt(10));
        
        //introduzco la columna del submarino
        barco.setColumna(random.nextInt(10));
        
        
        //Si la fila esta entre 1 y 10 le digo que me inserte la columna 
        if ((barco.getFila()>=0 && barco.getFila()<=tamanioMaximo)&& (barco.getColumna()>=0 && barco.getColumna()<=tamanioMaximo)){
            
            //posicion vertical u horizontal  
            
            
            if(random.nextBoolean()){
                barco.setOrientacion(Orientacion.VERTICAL);
            }else {
                barco.setOrientacion(Orientacion.HORIZONTAL);
            }
        
        } else{ System.out.println("La maquina no ha introducido los datos correctamente"); }
        
        
        if(barco.getOrientacion() == Orientacion.VERTICAL){
           for(int i=0;i<2;i++){casillas[barco.getFila()+i][barco.getColumna()]='s';}
        }else if(barco.getOrientacion() == Orientacion.HORIZONTAL){//2 porque son 2 casillas las que ocupa el portaaviones
            for(int i=0;i<2;i++){casillas[barco.getFila()][barco.getColumna()+i]='s';}  
        }

    /*   
        
        //mostrar tablero
        System.out.println("\nTablero Maquina: \n");
        for(int x=0;x<10;x++){
            for(int y=0;y<10;y++){
                System.out.print(casillas[x][y]+" ");
            }
            System.out.println("");
        }
        System.out.println("");
 */
//introducimos pesquero
      do{
     
 
        //introduzco la fila del pesquero
            barco.setFila(random.nextInt(10));
        
        //introduzco la columna del pesquero
        barco.setColumna(random.nextInt(10));
        
        
        //Si la fila esta entre 1 y 10 le digo que me inserte la columna 
        if ((barco.getFila()>=0 && barco.getFila()<=tamanioMaximo)&& (barco.getColumna()>=0 && barco.getColumna()<=tamanioMaximo)){
            
            //posicion vertical u horizontal  
            //orientacion=ranwdom.nextInt(2); 
            
            if(random.nextBoolean()){
                barco.setOrientacion(Orientacion.VERTICAL);
            }else {
                barco.setOrientacion(Orientacion.HORIZONTAL);
            }
        
        } else{ System.out.println("La maquina no ha introducido los datos correctamente"); }
      //miramos que no se solapen los barcos  
  
 
      }while(!cabe(barco));
      if(barco.getOrientacion() == Orientacion.VERTICAL){
           for(int i=0;i<1;i++){casillas[barco.getFila()+i][barco.getColumna()]='q';}
        }else if(barco.getOrientacion() == Orientacion.HORIZONTAL){//1 porque son 1 casillas las que ocupa el portaaviones
            for(int i=0;i<1;i++){casillas[barco.getFila()][barco.getColumna()+i]='q';}  
        }
      
        
     

        
       /* prueba 1 de si se cruzan los barcos 
        for (int i=0; i>barco;i++){
            if (casillas [barco.getFila()][barco.getColumna()] != NULL){
                fila+i,columna+i;
            }
        }
       */
        
        //mostrar tablero
        System.out.println("\nTablero Maquina: \n");
        for(int x=0;x<10;x++){
            for(int y=0;y<10;y++){
                System.out.print(casillas[x][y]+" ");
            }
            System.out.println("");
        }
        System.out.println("");
}
 
 
}