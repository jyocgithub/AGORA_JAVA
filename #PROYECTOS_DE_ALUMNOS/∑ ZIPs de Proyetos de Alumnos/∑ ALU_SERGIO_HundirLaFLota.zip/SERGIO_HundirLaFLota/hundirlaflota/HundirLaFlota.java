/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hundirlaflota;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author sergiojavierre
 */
public class HundirLaFlota {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        //preparación de partida
        ControladorDificultad controladorDificultad = new ControladorDificultad();
        
        
        Jugador jugadorHumano = new Jugador(null);
        jugadorHumano.setHumano(false);
        System.out.println("Jugador humano");
        jugadorHumano.eligeBarcos();
        
        Jugador jugadorMaquina = new Jugador(controladorDificultad.getDificultad());
        jugadorMaquina.setHumano(false);
        System.out.println("Jugador máquina");
        jugadorMaquina.eligeBarcos();
        
        //turnos
        jugadorHumano.setHumano(true);
        
        int numeroTurno = 1;
        
        while(jugadorHumano.vivo() && jugadorMaquina.vivo()){
            System.out.println("\n\n\nTURNO "+numeroTurno);

            System.out.println("Barcos de jugador humano: ");
            jugadorHumano.getTablero().pinta();
            
            jugadorHumano.ataca(jugadorMaquina);
            jugadorMaquina.ataca(jugadorHumano);
            System.out.println("Ataques de la máquina");
            jugadorMaquina.pintaAtaques();
            numeroTurno++;
        }
        
        if(jugadorHumano.vivo()){
            System.out.println("Enhorabuena! Has ganado");
        }
        else{
            System.out.println("Otra vez será, has perdido contra la máquina");
        }
        
        try {
            FileOutputStream fos = new FileOutputStream("jugadorHumano.ser");
            ObjectOutputStream oos = new ObjectOutputStream(fos);
            oos.writeObject(jugadorHumano);
            
        } catch (FileNotFoundException ex) {
            Logger.getLogger(ControladorDificultad.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(ControladorDificultad.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
}
