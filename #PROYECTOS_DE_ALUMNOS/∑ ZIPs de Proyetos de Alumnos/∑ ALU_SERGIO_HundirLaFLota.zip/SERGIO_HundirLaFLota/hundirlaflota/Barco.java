/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hundirlaflota;

import java.io.Serializable;

/**
 *
 * @author sergiojavierre
 */
public class Barco implements Serializable{
    
    private Integer fila, columna;
    private Orientacion orientacion;
    private Integer tamano;
    private Boolean vida[];

    public Barco(Integer tamano){
        this.tamano = tamano;
        this.vida = new Boolean[this.tamano];
        for(int i = 0; i < this.tamano; i++){
            this.vida[i] = true;
        }
    }

    public Integer getFila() {
        return fila;
    }

    public void setFila(Integer fila) {
        this.fila = fila;
    }

    public Integer getColumna() {
        return columna;
    }

    public void setColumna(Integer columna) {
        this.columna = columna;
    }

    public Orientacion getOrientacion() {
        return orientacion;
    }

    public void setOrientacion(Orientacion orientacion) {
        this.orientacion = orientacion;
    }

    public Integer getTamano() {
        return tamano;
    }

    public void setTamano(Integer tamano) {
        this.tamano = tamano;
    }

    public Boolean[] getVida() {
        return vida;
    }

    public void setVida(Boolean[] vida) {
        this.vida = vida;
    }
    
    private int getDesplazamiento(int fila, int columna){
        int desplazamiento = 0;
        if(this.getOrientacion()==Orientacion.VERTICAL){
            desplazamiento = fila - this.getFila();
        }
        else{
            desplazamiento = columna - this.getColumna();
        }
        return desplazamiento;
    }
    
    public void setDano(int fila, int columna){
        int desplazamiento = getDesplazamiento(fila, columna);
        this.vida[desplazamiento] = false;
        Boolean todoTocado = true;
        for(int i = 0; i < tamano; i++){
            if(this.vida[i]==true){
                todoTocado = false;
                break;
            }
        }
        if(todoTocado){
            System.out.println(Colores.ANSI_RED+"Barco hundido"+Colores.ANSI_RESET);
        }
    }
    
    public Boolean getEstado(int fila, int columna){
        return this.vida[getDesplazamiento(fila,columna)];
    }

    @Override
    public String toString() {
        return "Barco{" + "fila=" + fila + ", columna=" + columna + ", orientacion=" + orientacion + ", tamano=" + tamano + ", vida=" + vida + '}';
    }
    
    public String descripcionTamano(){
        return "Barco de "+this.tamano+" celdas";
    }
}
