/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hundirlaflota;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.Scanner;

/**
 *
 * @author sergiojavierre
 */
public class Jugador implements Serializable{
    
    private Tablero tablero;
    private Boolean humano = true;
    
    private List<Barco> barcosColocados;
    private Ataque[][] ataques;
    
    private Dificultad dificultad;
    private ResultadoAtaque ataqueAnterior;
    
    public Jugador(Dificultad dificultad){
        tablero = new Tablero();
        barcosColocados = new ArrayList<Barco>();
        ataques = new Ataque[Tablero.tamano][Tablero.tamano];
        for(int i = 0; i < Tablero.tamano; i++){
            for (int j = 0; j < Tablero.tamano; j++){
                ataques[i][j] = Ataque.VACIO;
            }
        }
        this.dificultad = dificultad;
        ataqueAnterior = new ResultadoAtaque();
    }

    public Boolean getHumano() {
        return humano;
    }

    public void setHumano(Boolean humano) {
        this.humano = humano;
        this.tablero.setVisible(humano);
    }

    public List<Barco> getBarcos() {
        return barcosColocados;
    }    

    public Tablero getTablero() {
        return tablero;
    }
    
    public Boolean vivo(){
        for(int i = 0;i<barcosColocados.size();i++){
            Barco barco = barcosColocados.get(i);
            for(int j = 0; j < barco.getTamano(); j++){
                if(barco.getVida()[j]){
                    return true;
                }
            }
        }
        return false;
    }

    public void eligeBarcos(){
        Barco barco6Celdas = new Barco(6);
        Barco barco4Celdas1 = new Barco(4);
        Barco barco4Celdas2 = new Barco(4);
        Barco barco2Celdas1 = new Barco(2);
        Barco barco2Celdas2 = new Barco(2);
        Barco barco2Celdas3 = new Barco(2);
        Barco barco1Celdas1 = new Barco(1);
        Barco barco1Celdas2 = new Barco(1);
        Barco barco1Celdas3 = new Barco(1);
        Barco barco1Celdas4 = new Barco(1);
        List<Barco> barcos = new ArrayList<Barco>();
        barcos.add(barco6Celdas);
        /*barcos.add(barco4Celdas1);
        barcos.add(barco4Celdas2);
        barcos.add(barco2Celdas1);
        barcos.add(barco2Celdas2);
        barcos.add(barco2Celdas3);
        barcos.add(barco1Celdas1);
        barcos.add(barco1Celdas2);
        barcos.add(barco1Celdas3);
        barcos.add(barco1Celdas4);*/
        
        Scanner scanner = new Scanner(System.in);
        
        while(barcos.size()>0){
            Barco barco;
            int pos;
            if(humano){
                tablero.pinta();
                System.out.println("Qué barco quieres colocar?");
                for(int i = 0; i < barcos.size(); i++){
                    Barco barcoMuestra = (Barco) barcos.get(i);
                    System.out.println(i+1+". "+barcoMuestra.descripcionTamano());
                }
                System.out.print("Barco: ");
                pos = Integer.parseInt(scanner.nextLine())-1;
            }
            else{
                pos = 0;
            }
            barco = barcos.get(pos);
            do{
                if(humano){
                    System.out.println("Dónde lo quieres colocar?");
                    System.out.print("Fila: ");
                    barco.setFila(Integer.parseInt(scanner.nextLine()));
                    System.out.print("Columna: ");
                    barco.setColumna(Integer.parseInt(scanner.nextLine()));
                    if(barco.getTamano()>1){
                        String orientacion;
                        do{
                        System.out.print("Orientación (v|h): ");
                        orientacion = scanner.nextLine();
                        }while(!orientacion.equals("v") && !orientacion.equals("h"));
                        if(orientacion.equals("v")){
                            barco.setOrientacion(Orientacion.VERTICAL);
                        }
                        else{
                            barco.setOrientacion(Orientacion.HORIZONTAL);
                        }
                    }
                    else{
                        barco.setOrientacion(Orientacion.HORIZONTAL);
                    }
                }
                else{
                    Random random = new Random();
                    barco.setFila(random.nextInt(Tablero.tamano));
                    barco.setColumna(random.nextInt(Tablero.tamano));
                    if(random.nextBoolean()){
                        barco.setOrientacion(Orientacion.HORIZONTAL);
                    }
                    else{
                        barco.setOrientacion(Orientacion.VERTICAL);
                    }
                }
            } while(!this.tablero.cabeBarco(barco));
            tablero.colocaBarco(barco);
            barcos.remove(pos);
            barcosColocados.add(barco);
        }
        System.out.println("Los barcos están:");
        tablero.pinta();
    }
    
    public void ataca(Jugador jugador){
        int fila, columna;
        do{
            if(this.getHumano()){
                System.out.println("Elige una celda sin atacar");
                pintaAtaques();
                Scanner scanner = new Scanner(System.in);
                System.out.println("Ataque:");
                System.out.print("Fila: ");
                fila = Integer.parseInt(scanner.nextLine());
                System.out.print("Columna: ");
                columna = Integer.parseInt(scanner.nextLine());
            }
            else{
                Random random = new Random();
                /*
                if(dificultad.getNivel()==3 && this.ataqueAnterior.getExito() == true && 
                    (ataqueAnterior.getFila()-1 > 0 && ataques[ataqueAnterior.getFila()-1][ataqueAnterior.getColumna()]==Ataque.VACIO) ||
                    (ataqueAnterior.getColumna()-1 > 0 &&ataques[ataqueAnterior.getFila()][ataqueAnterior.getColumna()-1]==Ataque.VACIO) ||
                    ataques[ataqueAnterior.getFila()+1][ataqueAnterior.getColumna()]==Ataque.VACIO ||
                    ataques[ataqueAnterior.getFila()][ataqueAnterior.getColumna()+1]==Ataque.VACIO){
*/
                if(
                        dificultad.getNivel()==3 &&
                        this.ataqueAnterior.getExito() &&
                        (
                            (ataqueAnterior.getFila()-1 > 0 && ataques[ataqueAnterior.getFila()-1][ataqueAnterior.getColumna()]==Ataque.VACIO) ||
                            (ataqueAnterior.getColumna()-1 > 0 &&ataques[ataqueAnterior.getFila()][ataqueAnterior.getColumna()-1]==Ataque.VACIO) ||
                            ataques[ataqueAnterior.getFila()+1][ataqueAnterior.getColumna()]==Ataque.VACIO ||
                            ataques[ataqueAnterior.getFila()][ataqueAnterior.getColumna()+1]==Ataque.VACIO)
                        ){
                    int posRandom = random.nextInt(4);
                    if(posRandom == 0){
                        fila = ataqueAnterior.getFila()-1;
                        columna = ataqueAnterior.getColumna();
                    }
                    else if(posRandom == 1){
                        fila = ataqueAnterior.getFila();
                        columna = ataqueAnterior.getColumna()-1;
                    }
                    else if(posRandom == 2){
                        fila = ataqueAnterior.getFila()+1;
                        columna = ataqueAnterior.getColumna();
                    }
                    else {
                        fila = ataqueAnterior.getFila();
                        columna = ataqueAnterior.getColumna()+1;
                    }
                }
                else{
                    fila = random.nextInt(Tablero.tamano);
                    columna = random.nextInt(Tablero.tamano);
                }
            }
        }while(ataques[fila][columna]!=Ataque.VACIO);
        this.ataqueAnterior.setFila(fila);
        this.ataqueAnterior.setColumna(columna);
        Tablero tableroRival = jugador.getTablero();
        if(tableroRival.getPosiciones()[fila][columna] == null){
            ataques[fila][columna] = Ataque.AGUA;
            this.ataqueAnterior.setExito(false);
        }
        else{
            ataques[fila][columna] = Ataque.TOCADO;
            Barco barco = jugador.getTablero().getPosiciones()[fila][columna];
            barco.setDano(fila, columna);
            this.ataqueAnterior.setExito(true);
        }
    }
    
    public void pintaAtaques(){
        System.out.print("   ");
        for(int i = 0; i < Tablero.tamano; i++){
            System.out.print(" "+i+" ");
        }
        System.out.println("");
        for(int i = 0; i < Tablero.tamano; i++){
            System.out.print(" "+i+" ");
            for(int j = 0; j < Tablero.tamano; j++){
                if(this.ataques[i][j]==Ataque.VACIO){
                    System.out.print(Colores.ANSI_BLUE+" - "+Colores.ANSI_RESET);
                }
                else if(this.ataques[i][j]==Ataque.TOCADO){
                    System.out.print(Colores.ANSI_RED+" X "+Colores.ANSI_RESET);
                }
                else if(this.ataques[i][j]==Ataque.AGUA){
                    System.out.print(Colores.ANSI_BLUE+" O "+Colores.ANSI_RESET);
                }
            }
            System.out.println("");
        }
    }
    
}
