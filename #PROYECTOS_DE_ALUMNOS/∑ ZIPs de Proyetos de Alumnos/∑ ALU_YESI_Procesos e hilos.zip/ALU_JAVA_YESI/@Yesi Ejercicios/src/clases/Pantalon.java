package clases;

public class Pantalon extends Ropa {

	private int numbolsillos;

	public Pantalon(String marca, String talla, double precio, int numbolsillos) {
		super(marca, talla, precio);
		this.numbolsillos = numbolsillos;
	}

	@Override
	public void rebajar() {
		precio = precio * 0.9;
	}

}
