package clases;

public class Ropa {

	// ATRIBUTOS : COMO ES EL VESTIDO
	protected String marca;
	protected String talla;
	protected double precio;

	// CONSTRUCTOR
	public Ropa(String marca, String talla, double precio) {
		this.marca = marca;
		this.talla = talla;
		this.precio = precio;
	}

	public Ropa(String m, String t) {
		marca = m;
		talla = t;
		precio = 0;
	}

	public String getMarca() {
		return marca;
	}

	public void setMarca(String marca) {
		this.marca = marca;
	}

	public String getTalla() {
		return talla;
	}

	public void setTalla(String talla) {
		this.talla = talla;
	}

	public double getPrecio() {
		return precio;
	}

	public void setPrecio(double precio) {
		if (precio > 0) {
			this.precio = precio;
		}
	}

	// METODOS : QUE HACE UN VESTIDO

	public void rebajar() {
		precio = precio / 2;
	}

	@Override
	public String toString() {
		return "Ropa [marca=" + marca + ", talla=" + talla + ", precio=" + precio + "]";
	}

}
