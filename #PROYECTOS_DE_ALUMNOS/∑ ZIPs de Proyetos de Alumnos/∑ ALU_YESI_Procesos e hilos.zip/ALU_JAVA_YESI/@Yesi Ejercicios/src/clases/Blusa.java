package clases;

public class Blusa extends Ropa {

	private int largomanga;

	public Blusa(String marca, String talla, double precio, int largomanga) {
		super(marca, talla, precio);
		this.largomanga = largomanga;
	}

	public void cambiarMarca(String nuevamarca) {
		marca = nuevamarca;
	}

	public int getLargomanga() {
		return largomanga;
	}

	public void setLargomanga(int largomanga) {
		this.largomanga = largomanga;
	}

	@Override
	public String toString() {
		String s = "Marca es " + marca + " y el precio es " + precio;
		return s;
	}

}
