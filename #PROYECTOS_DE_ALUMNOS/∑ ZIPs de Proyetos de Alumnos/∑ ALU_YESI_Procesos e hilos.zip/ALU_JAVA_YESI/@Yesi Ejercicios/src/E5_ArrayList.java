import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;

public class E5_ArrayList {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		ArrayList<Vendedor> listaVendedor = new ArrayList<>();

		int opcion;
		do {
			System.out.println("1.-Introducir Vendedor");
			System.out.println("2.-Listar vendedor");
			System.out.println("3.-Eliminar vendedor");
			System.out.println("4.-Borrar todos");
			System.out.println("5.-Mostrar numero de vendedores");
			System.out.println("6.-Buscar vendedor");
			System.out.println("0.-Salir");

			opcion = sc.nextInt();
			switch (opcion) {
			case 1:
				AñadirVendedor(listaVendedor);
				break;
			case 2:
				Listar(listaVendedor);
				break;
			case 3:
				Eliminar(listaVendedor);
				break;
			case 4:
				BorrarTodos(listaVendedor);
				break;
			case 5:
				Tamanio(listaVendedor);
				break;
			case 6:
				BuscarVendedor(listaVendedor);
				break;
			default:
				break;

			}
		} while (opcion != 0);
	}

	public static void AñadirVendedor(ArrayList<Vendedor> listaVendedor) {
		Scanner scD = new Scanner(System.in);
		Scanner scS = new Scanner(System.in);

		String nombre;
		double sueldo;

		System.out.println("Dame un vendedor");
		nombre = scS.nextLine();

		System.out.println("Dame un sueldo");
		sueldo = scD.nextDouble();

		Vendedor v = new Vendedor(nombre, sueldo);
		listaVendedor.add(v);

	}

	public static void Listar(ArrayList<Vendedor> listaVendedor) {
		for (Vendedor v : listaVendedor) {
			System.out.println(v);
		}
	}

	public static void Eliminar(ArrayList<Vendedor> listaVendedor) {
		Scanner sc = new Scanner(System.in);
		String nombreBorrar = sc.nextLine();

		Iterator<Vendedor> iter = listaVendedor.iterator();
		while (iter.hasNext()) {
			Vendedor v = iter.next();
			if (v.getNombre().equals(nombreBorrar)) {
				iter.remove();
				System.out.println("vendedor borrado");
			}
			if (v.getNombre() != (nombreBorrar)) {
				System.out.println("Ese vendedor no existe");
			}
		}

	}

	public static void BorrarTodos(ArrayList<Vendedor> listaVendedor) {
		listaVendedor.clear();
		System.out.println("lista vaciada");
	}

	public static void Tamanio(ArrayList<Vendedor> listaVendedor) {
		listaVendedor.size();
	}

	public static void BuscarVendedor(ArrayList<Vendedor> listaVendedor) {
		Scanner sc = new Scanner(System.in);
		String nombreConsultar = sc.nextLine();
		for (Vendedor v : listaVendedor) {
			if (v.getNombre().equals(nombreConsultar)) {
				System.out.println(v);
			}
		}
	}
}

class Vendedor {
	private String nombre;
	private double sueldo;

	public Vendedor(String nombre, double sueldo) {
		this.nombre = nombre;
		this.sueldo = sueldo;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public double getSueldo() {
		return sueldo;
	}

	public void setSueldo(double sueldo) {
		this.sueldo = sueldo;
	}

	@Override
	public String toString() {
		return "Vendedor [nombre=" + nombre + ", sueldo=" + sueldo + "]";
	}

}