import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.PrintWriter;
import java.util.ArrayList;

public class Ficheros {

	public static void main(String[] args) {

		escribirFicheroTexto();
		leerFicheroTexto();

	}

	public static void leerFicheroTexto() {
		// con cada linea leida la mostramos en pantall y guardamos en un arraylist
		ArrayList<String> colores = new ArrayList<>();

		try {

			File f = new File("pruebas.txt");
			if (f.exists()) {

				FileReader fr = new FileReader("pruebas.txt");
				BufferedReader br = new BufferedReader(fr);

				// leer una primera linea
				String linea = br.readLine();

				while (linea != null) {

					// hacer lo que se quiera con la linea leida

					System.out.println(linea);
					colores.add(linea);

					// leer otra linea
					linea = br.readLine();
				}

				fr.close();
				br.close();

			} else {
				System.out.println("No existe el fichero no lo puedo leer");
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public static void escribirFicheroTexto() {

		ArrayList<String> colores = new ArrayList<>();

		colores.add("ROJO");
		colores.add("AZUL");
		colores.add("VERDE");
		colores.add("NEGRO");

		try {

			// abrir
			PrintWriter pw = new PrintWriter("pruebas.txt");

			// leer o escribir
			for (String s : colores) {
				pw.println(s);
			}

			// cerrar
			pw.close();

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public static void leerFicheroTextoytrocearlinea() {
		// con cada linea leida tiene esta forma:
		// ROJO, 12, PANA
		// AZUL, 11, POLYESTER

		ArrayList<Pieza> piezas = new ArrayList<>();

		try {

			File f = new File("pruebas2.txt");
			if (f.exists()) {

				FileReader fr = new FileReader("pruebas2.txt");
				BufferedReader br = new BufferedReader(fr);

				// leer una primera linea
				String linea = br.readLine();

				while (linea != null) {

					// hacer lo que se quiera con la linea leida

					String[] trozos = linea.split(",");

					String elcolor = trozos[0];
					String elprecio = trozos[1];
					String latextura = trozos[2];

					Pieza p = new Pieza(elcolor, Integer.parseInt(elprecio), latextura);

					piezas.add(p);

					// leer otra linea
					linea = br.readLine();
				}

				fr.close();
				br.close();

			} else {
				System.out.println("No existe el fichero no lo puedo leer");
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

	}
}

class Pieza {

	String color;
	int precio;
	String textura;

	public Pieza(String color, int precio, String textura) {
		super();
		this.color = color;
		this.precio = precio;
		this.textura = textura;
	}

}
