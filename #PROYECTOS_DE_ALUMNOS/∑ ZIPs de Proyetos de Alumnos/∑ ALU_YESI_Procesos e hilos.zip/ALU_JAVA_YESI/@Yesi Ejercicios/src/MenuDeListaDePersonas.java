import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;

public class MenuDeListaDePersonas {

	public static void main(String[] args) {
		Scanner scn = new Scanner(System.in);
		Scanner scs = new Scanner(System.in);

		ArrayList<Persona> listapersonas = new ArrayList<>();

		int opcion;

		do {
			System.out.println("1.- Añadir");
			System.out.println("2.- Borrar una persona por su dni");
			System.out.println("3.- Consultar una persona por su dni");
			System.out.println("4.- Consultar todas ");
			System.out.println("5.- Borrar todas ");
			System.out.println("0.- salir");
			opcion = scn.nextInt();
			switch (opcion) {
			case 1:
				alta(listapersonas);
				break;
			case 2:
				borrar(listapersonas);
				break;
			case 3:
				consultar(listapersonas);
				break;
			case 4:
				consultarTodos(listapersonas);
				break;
			case 5:
				listapersonas.clear();
				break;
			}
		} while (opcion != 0);

	}

	public static void consultar(ArrayList<Persona> listaPersonas) {
		String dniParaConsultar;
		Scanner scs = new Scanner(System.in);
		boolean loencontre = false;

		do {
			System.out.println("Dame un dni pa consultar los datos de un pollo;");
			dniParaConsultar = scs.nextLine();
			if (dniParaConsultar.length() != 9) {
				System.out.println("dni incorrecto");
			}
		} while (dniParaConsultar.length() != 9);

		for (Persona p : listaPersonas) {
			if (p.getDni().equals(dniParaConsultar)) {
				System.out.println(p);
				loencontre = true;
			}
		}

		if (loencontre == false) {
			System.out.println("NO EXISTE ESE DNI");
		}

	}

	public static void borrar(ArrayList<Persona> listaPersonas) {
		String dniParaBorrar;
		Scanner scs = new Scanner(System.in);
		boolean loencontre = false;

		do {
			System.out.println("Dame un dni pa borrar al pollo que lo tenga");
			dniParaBorrar = scs.nextLine();
			if (dniParaBorrar.length() != 9) {
				System.out.println("dni incorrecto");
			}
		} while (dniParaBorrar.length() != 9);

		Iterator<Persona> it = listaPersonas.iterator();
		while (it.hasNext()) {
			Persona p = it.next();
			if (p.getDni().equals(dniParaBorrar)) {
				it.remove();
				loencontre = true;
			}
		}

		if (loencontre == false) {
			System.out.println("NO EXISTE ESE DNI");
		}

	}

	public static void consultarTodos(ArrayList<Persona> listaPersonas) {
		for (Persona p : listaPersonas) {
			System.out.println(p.toString());
		}
	}

	public static void alta(ArrayList<Persona> listaPersonas) {
		Scanner scn = new Scanner(System.in);
		Scanner scs = new Scanner(System.in);

		String nom, dni;
		int ed;

		System.out.println("Dame un nombre");
		nom = scs.nextLine();

		System.out.println("Dame una edad ");
		ed = scn.nextInt();

		// el dni tiene que tener 9 caracteres obligartoriamente
		do {
			System.out.println("Dame un dni");
			dni = scs.nextLine();
			if (dni.length() != 9) {
				System.out.println("dni incorrecto");
			}
		} while (dni.length() != 9);

		Persona p = new Persona(nom, ed, dni);

		listaPersonas.add(p);
	}

}

class Persona {
	private String nombre;
	private int edad;
	private String dni;

	public Persona(String nombre, int edad, String dni) {
		super();
		this.nombre = nombre;
		this.edad = edad;
		this.dni = dni;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public int getEdad() {
		return edad;
	}

	public void setEdad(int edad) {
		this.edad = edad;
	}

	public String getDni() {
		return dni;
	}

	public void setDni(String dni) {
		this.dni = dni;
	}

	@Override
	public String toString() {
		return "Persona [nombre=" + nombre + ", edad=" + edad + ", dni=" + dni + "]";
	}

}