import java.util.Scanner;

public class EjemploMetodos {

	// atributos: cualquier variable
	int k = 3;

	// metodos: miniprogramas
	public static void main(String[] args) {

		System.out.println("inicio");
		Scanner sc = new Scanner(System.in);
		System.out.println("Dame dos numeros");
		int a = sc.nextInt();
		int b = sc.nextInt();

		int res = sumar2(a, b);
		System.out.println(res);

		System.out.println("fin");

		int jj = 34;
		int mm = 24;

		res = sumar2(jj, mm);
		System.out.println(res);

		int pepe = 222;
		int ana = 111;

		res = sumar2(pepe, ana);
		System.out.println(res);

	}

	// metodo CON parametro Y QUE DA UN RESULTADO
	public static int sumar2(int xx, int yy) {
		int suma = xx + yy;
		return suma;
	}

	// metodo sin parametro ni valor de resultado
	public static void sumar() {
		int a = 4;
		int b = 3;
		int suma = a + b;
		System.out.println(suma);
	}

	// metodo CON parametro ni valor de resultado
	public static void sumar1(int a, int b) {
		int suma = a + b;
		System.out.println(suma);
	}

}
