public class Bucles {

	public static void main(String[] args) {

		String[] palabras = { "Rebeca", "eva", "Luisa", "Ana", "Maria", "Pepe" };

		int valoraborrar = 2;
		palabras[valoraborrar] = null;

		for (int i = valoraborrar; i < palabras.length - 1; i++) {
			palabras[i] = palabras[i + 1];
		}
		palabras[palabras.length - 1] = null;

		for (int i = 0; i < palabras.length; i++) {
			if (palabras[i] != null) {
				System.out.println(palabras[i].toUpperCase());
			}
		}

	}

}
