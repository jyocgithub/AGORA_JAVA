import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.TreeSet;

public class Colecciones {

	public static void main(String[] args) {

		// LISTAS _____ LIST (ARRAYLIST)____________________________________________

		ArrayList<Integer> lista = new ArrayList<>();

		lista.add(234);
		lista.add(654);
		lista.add(12);
		lista.add(954);
		lista.add(954);
		lista.add(26523);

		int dd = lista.get(2); // DEVUELVE PARA CONSULTAR el valor de la posicion 2, y me lo guardo
		System.out.println(dd);

		lista.remove(1); // ELIMINAR esa posicion

		boolean esta = lista.contains(234); // DEVUELVE TRUE si el valor esta en la lista

		if (lista.contains(234)) {

		}
		;

		int tam = lista.size(); // DEVUELVE EL TAMAÑO de la lista
		lista.clear(); // BORRA TODOS LOS ELEMENTOS

		for (int i = 0; i < lista.size(); i++) {
			int x = lista.get(i);
			System.out.println(x);

		}

		for (Integer x : lista) { // PINTA TODOS
			System.out.println(x);

		}

		// BORRA MICHOS A LA VEZ - ITERATOR
		Iterator<Integer> miIterator = lista.iterator();
		while (miIterator.hasNext()) {
			Integer x = miIterator.next();
			if (x > 100) {
				miIterator.remove();
			}
		}

		// CONJUNTOS _____ SET (TREESET)____________________________________________
		// LOS ELEMENTOS NO TIENEN POSICION

		TreeSet<Integer> conj = new TreeSet<>();
		conj.add(234);
		conj.add(654);
		conj.add(12);

		// NO TIENE GET()

		conj.remove(654); // BORRA EL ELEMENTO INDICADO; NO ESA POSICION

		int tt = conj.size();

		conj.clear(); // BORRA TODO

		if (conj.contains(654)) {

		}

		// se recorre siempre con un for-each
		for (Integer x : conj) { // PINTA TODOS
			System.out.println(x);

		}

		// tambien se usa iterator igual que con las listas

		// MAPAS
		HashMap<Integer, String> mapa = new HashMap<>();

		mapa.put(23, "ANA");
		mapa.put(6, "EVA");
		mapa.put(12, "MARIA");
		mapa.put(65, "LUISA");

		mapa.remove(65);

		String nom = mapa.get(6);

		boolean tienelaclave = mapa.containsKey(54);
		if (mapa.containsKey(6)) {

		}
		if (mapa.containsValue("EVA")) {

		}

		for (Integer x : mapa.keySet()) {
			String valor = mapa.get(x);
		}
		for (String x : mapa.values()) {
		}

		Iterator<Integer> it = mapa.keySet().iterator();
		while (it.hasNext()) {
			int clave = it.next();
			String valor = mapa.get(clave);
			System.out.println(valor);
			System.out.println(clave);
		}

	}
}
