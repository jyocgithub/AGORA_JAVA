package hilos;

import java.io.*;


import org.apache.commons.net.PrintCommandListener;
import org.apache.commons.net.ftp.FTP;
import org.apache.commons.net.ftp.FTPClient;
import org.apache.commons.net.ftp.FTPFile;

public class EnvioFTP {


//Datos del servidor FTP
	FTPClient cliente = new FTPClient(); //cliente FTP
	String servidor = "files.000webhost.com";
	String user = "dam2psp";
	//String pasw = "VMPSP2019";
	String pasw = "files.000webhost.com";
	boolean login;
	String direcInicial = "/Andres";//SergioPereyra

	public EnvioFTP() throws IOException {
		
		System.out.println("Conectandose a " + servidor);
		
	//	cliente.addProtocolCommandListener(new PrintCommandListener (new PrintWriter (System.out) )); 
		cliente.connect(servidor);
		cliente.enterLocalPassiveMode();
		login = cliente.login(user, pasw);
		
		cliente.changeWorkingDirectory(direcInicial);
		
}  
	
public synchronized boolean SubirFichero (String archivo, String nombreArchivo) throws IOException {
	
	System.out.println("Archivo : " +nombreArchivo);
	
	cliente.setFileType(FTP.BINARY_FILE_TYPE);
	BufferedInputStream in = new BufferedInputStream(new FileInputStream(archivo));
	boolean ok = false;

	if (cliente.storeFile(nombreArchivo, in)) {
		System.out.println(nombreArchivo + " Subido correctamente... ");
		
		ok = true;
	} else
		System.out.println("No se ha podido ENVIAR... " + nombreArchivo);
			
	return ok;
}// SubirFichero


}
	