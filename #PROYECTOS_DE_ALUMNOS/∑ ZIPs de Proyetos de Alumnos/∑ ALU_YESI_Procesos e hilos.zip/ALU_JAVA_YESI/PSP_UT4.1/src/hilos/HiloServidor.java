package hilos;

import java.io.*;
import java.net.*;

public class HiloServidor extends Thread {
	BufferedReader fentrada;
	PrintWriter fsalida;
	Socket socket = null;
	int numCliente;

	public HiloServidor(Socket s, int numCliente) throws IOException {// CONSTRUCTOR
		socket = s;
		// se crean flujos de entrada y salida
		fsalida = new PrintWriter(socket.getOutputStream(), true);
		fentrada = new BufferedReader(new InputStreamReader(socket.getInputStream()));
		this.numCliente = numCliente;
	}

	public void run(int w) {// tarea a realizar con el cliente

		String cadena = "";

		FileWriter f;
		BufferedWriter br = null;
		try {

			f = new FileWriter(new File("fich" + w + ".txt"));
			br = new BufferedWriter(f);
			System.out.println("COMUNICO CON: " + socket.toString());

			int z = 1;

			cadena = fentrada.readLine();
			while (!cadena.trim().equals("*")) {
				br.write(cadena);
				br.newLine();
				fsalida.println("OK");// enviar mayuscula
				cadena = fentrada.readLine();
			} // fin while

			// ENVIO DE FICHEROS
			String monbrefich = "fich" + numCliente + ".txt";
			EnvioFTP env = new EnvioFTP();
			env.SubirFichero(monbrefich, monbrefich);
			EnviarCorreo cor = new EnviarCorreo();
			cor.sendEmail(monbrefich, socket.toString());

		} catch (IOException e1) {
			e1.printStackTrace();
		} finally {
			try {
				fsalida.close();
				br.close();
				fentrada.close();
				socket.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}// Run

}// Hilo Servidor
