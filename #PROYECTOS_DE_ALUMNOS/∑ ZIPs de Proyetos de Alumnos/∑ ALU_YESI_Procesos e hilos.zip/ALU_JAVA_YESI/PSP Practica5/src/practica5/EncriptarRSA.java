package practica5;

import java.io.*;
import java.nio.file.Files;
import java.security.*;
import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;

public class EncriptarRSA {
	static private PublicKey obClavePublica;
	static private PrivateKey obClavePrivada;
	static private String midir;
	static private Cipher encriptador;
	static String ficheroParaEncriptar,ficheroencriptado;

	public static void main(String[] args) {
		ficheroParaEncriptar = "cosas.txt";
		try {
			encriptador = Cipher.getInstance("RSA/ECB/PKCS1Padding");
			generarClavePrivadaYPublica();
			escribirBytearrayEnFichero(obClavePublica.getEncoded(), "CLAVEPUBLICA.DAT", midir);
			encriptarArchivoTexto();
			desencriptarArchivoTexto();		
		} catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
		} catch (NoSuchPaddingException e) {
			e.printStackTrace();
		}
	}

	public static void generarClavePrivadaYPublica() {
		KeyPairGenerator keyPairGenerator;
		KeyPair keyPair;
		try {
			keyPairGenerator = KeyPairGenerator.getInstance("RSA");
			keyPair = keyPairGenerator.generateKeyPair();
			obClavePublica = keyPair.getPublic();
			obClavePrivada = keyPair.getPrivate();
		} catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
		}
	}

	public static void encriptarArchivoTexto() {
		String textoEncriptado = "";
		File file = new File(ficheroParaEncriptar);
		if (file.exists()) {
			try {
				String textosinencriptar = leerTextoDeFichero(ficheroParaEncriptar, ".");
				encriptador.init(Cipher.ENCRYPT_MODE, obClavePublica);
				byte[] cifradoEnBytearray = encriptador.doFinal(textosinencriptar.getBytes());
				escribirBytearrayEnFichero(cifradoEnBytearray, "encriptado" + ficheroParaEncriptar, midir);
			} catch (Exception e) {
				e.printStackTrace();
			}
		} else {
			System.out.println("No existe ese fichero");
		}
	}

	public static void desencriptarArchivoTexto() {
		String textodesencriptado = "";
		ficheroencriptado =  "encriptado" + ficheroParaEncriptar;

		File file = new File(midir, ficheroencriptado);
		if (file.exists()) {
			try {
				byte[] cifradoEnBytearray = leerBytearrayDeFichero(ficheroencriptado, ".");
				encriptador.init(Cipher.DECRYPT_MODE, obClavePrivada);
				byte[] descifradoEnBytearray = encriptador.doFinal(cifradoEnBytearray);

				textodesencriptado = new String(descifradoEnBytearray);
				System.out.println("Fichero leido tras desencriptarlo:");
				System.out.println(textodesencriptado);

				// guardo el texto encriptado en un fichero
				escribirTextoEnFichero(textodesencriptado, "desencriptado" + ficheroencriptado, midir);

			} catch (IllegalBlockSizeException e) {
				e.printStackTrace();
			} catch (BadPaddingException e) {
				e.printStackTrace();
			} catch (InvalidKeyException e) {
				e.printStackTrace();
			}
		} else {
			System.out.println("No existe ese fichero");
		}

	}

	public static void escribirBytearrayEnFichero(byte[] contenido, String nombrefichero, String pathdelfichero) {
		File fichero = new File(pathdelfichero, nombrefichero);

		FileOutputStream fos = null;
		try {
			fos = new FileOutputStream(fichero);
			fos.write(contenido);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				if (fos != null)
					fos.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

	public static byte[] leerBytearrayDeFichero(String nombrefichero, String pathdelfichero) {
		File fichero = new File(pathdelfichero, nombrefichero);
		byte[] ficheroenbytes;
		try {
			ficheroenbytes = Files.readAllBytes(fichero.toPath());
			return ficheroenbytes;
		} catch (IOException e) {
			e.printStackTrace();
		}
		return null;
	}

	public static void escribirTextoEnFichero(String texto, String nombrefichero, String pathdelfichero) {
		File fichero = new File(pathdelfichero, nombrefichero);
		PrintWriter pw = null;
		try {
			pw = new PrintWriter(fichero);
			pw.println(texto);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} finally {
			pw.close();
		}
	}

	public static String leerTextoDeFichero(String nombrefichero, String pathdelfichero) {
		File fichero = new File(pathdelfichero, nombrefichero);
		BufferedReader br = null;
		FileReader fr = null;
		String textoentero = "";
		try {
			fr = new FileReader(fichero);
			br = new BufferedReader(fr);
			String linea = br.readLine();
			while (linea != null) {
				textoentero = textoentero + linea + "\n";
				linea = br.readLine();
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		return textoentero;
	}
}
