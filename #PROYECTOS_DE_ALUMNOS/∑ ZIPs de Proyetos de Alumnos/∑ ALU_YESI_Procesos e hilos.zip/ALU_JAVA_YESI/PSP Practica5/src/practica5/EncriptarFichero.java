package practica5;

import java.io.*;
import java.nio.file.Files;
import java.security.*;
import java.util.Arrays;
import java.util.Scanner;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.xml.bind.DatatypeConverter;

public class EncriptarFichero {
	static private PublicKey obClavePublica;
	static private PrivateKey obClavePrivada;
	static private String midir;
	static private Cipher encriptador;
	static byte[] cifradoEnBytearray, cifradoEnBytearray2, descifradoEnBytearray;

	public static void main(String[] args) {
		// VOY A HACER AQUI TODas las cosas SEGUIDas COMO SI FUERA EL EMISOR Y EL
		// RECEPTOR
		try {
			File dir = new File(".");
			midir = dir.getCanonicalPath();
			try {
				encriptador = Cipher.getInstance("RSA/ECB/PKCS1Padding");
			} catch (NoSuchAlgorithmException e) {
				e.printStackTrace();
			} catch (NoSuchPaddingException e) {
				e.printStackTrace();
			}

			// COMO EMISOR:
			generarClavePrivadaYPublica();

			// SI DESE0 ESCRIBIR LA CLAVE PUBLIC AEN FICHERO.....
			escribirTextoEnFichero(obClavePublica.toString(), "CLAVEPUBLICA.TXT" ,midir);

			// COMO RECEPTOR
			encriptarArchivoTexto();

			// COMO EMISOR
			desencriptarArchivoTexto();

		} catch (IOException e) {
			e.printStackTrace();
		}

	}

	public static void generarClavePrivadaYPublica() {
		KeyPairGenerator keyPairGenerator;
		KeyPair keyPair;
		try {
			keyPairGenerator = KeyPairGenerator.getInstance("RSA");
//			keyPairGenerator.initialize(128);
			keyPair = keyPairGenerator.generateKeyPair();

			obClavePublica = keyPair.getPublic();
			obClavePrivada = keyPair.getPrivate();
		} catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
		}
	}

	public static void encriptarArchivoTexto() {
		String textoEncriptado = "";
		Scanner sc = new Scanner(System.in);
		System.out.println("Dime el nombre del fichero a encriptar");
		String ficheroParaEncriptar = sc.nextLine();
		ficheroParaEncriptar = "cosas.txt";
		File file = new File(midir, ficheroParaEncriptar);
		if (file.exists()) {
			System.out.println("procedo a encriptarlo ");
			System.out.println("leo el contenido del fichero y lo meto en un String");
			String textosinencriptar = leerTextoDeFichero(ficheroParaEncriptar, midir);
			
			try {
				encriptador.init(Cipher.ENCRYPT_MODE, obClavePublica);
				cifradoEnBytearray = encriptador.doFinal(textosinencriptar.getBytes());
			} catch (InvalidKeyException e) {
				e.printStackTrace();
			} catch (IllegalBlockSizeException e) {
				e.printStackTrace();
			} catch (BadPaddingException e) {
				e.printStackTrace();
			}
			// guardo el texto encriptado en un fichero
			escribirBytearrayEnFichero(cifradoEnBytearray, "encriptado" + ficheroParaEncriptar, midir);

		} else {
			System.out.println("No existe ese fichero");
		}
	}

	public static void desencriptarArchivoTexto() {
		String textodesencriptado = "";
		Scanner sc = new Scanner(System.in);
		System.out.println("Dime el nombre del fichero que ya esta encriptado");
		String ficheroencriptado = sc.nextLine();
		ficheroencriptado = "encriptadocosas.txt";

		File file = new File(midir, ficheroencriptado);
		if (file.exists()) {

			System.out.println("procedo a deencriptarlo ");
			System.out.println("leo el contenido del fichero encriptado y lo meto en un byte[]");
			cifradoEnBytearray2 = leerBytearrayDeFichero(ficheroencriptado, midir);
//			BufferedReader br = null;
//			FileReader fr = null;
			try {
//				fr = new FileReader(file);
//				br = new BufferedReader(fr);
//				String linea = br.readLine();
//				String textocompleto = "";
//				while (linea != null) {
//					textocompleto = textocompleto + linea;
//					linea = br.readLine();
//				}
//				System.out.println("deencripto el contenido del fichero que ya esta en un String");
//				System.out.println("Obtener la clase para desencriptar");
//
//				System.out.println(" preparo (configuro) el encriptador");
				encriptador.init(Cipher.DECRYPT_MODE, obClavePrivada);
//		        cifrado2 = textocompleto.getBytes();

				if (Arrays.equals(cifradoEnBytearray, cifradoEnBytearray2)) {
					System.out.println(" EEEQQQQQQQQQQQ");

				} else {
					System.out.println("DDIFFFFFFF");
					System.out.println(cifradoEnBytearray.length);
					System.out.println(cifradoEnBytearray2.length);

				}

//				cifrado2 = DatatypeConverter.parseHexBinary(textocompleto);
				descifradoEnBytearray = encriptador.doFinal(cifradoEnBytearray2);

				textodesencriptado = new String(descifradoEnBytearray);
				System.out.println(textodesencriptado);

				// guardo el texto encriptado en un fichero
				escribirTextoEnFichero(textodesencriptado, "desencriptado" + ficheroencriptado, midir);

			} catch (IllegalBlockSizeException e) {
				e.printStackTrace();
			} catch (BadPaddingException e) {
				e.printStackTrace();
			} catch (InvalidKeyException e) {
				e.printStackTrace();
			}
		} else {
			System.out.println("No existe ese fichero");
		}

	}

	// ESTE METODO ESCRIBE CUALQUIER ARRAY DE BYTES EN UN FICHERO
	// DENE INDICARSE EN PARAMETROS EL TEXTO Y EL NOMBRE DEL FICHERO A CREAR
	public static void escribirBytearrayEnFichero(byte[] contenido, String nombrefichero, String pathdelfichero) {
		System.out.println("como el desencriptado es un array de bytes lo paso a String y lo muestro ");
		File fichero = new File(pathdelfichero, nombrefichero);

		FileOutputStream fos = null;
		try {
			fos = new FileOutputStream(fichero);
			fos.write(contenido);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				if (fos != null)
					fos.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

	// ESTE METODO ESCRIBE CUALQUIER ARRAY DE BYTES EN UN FICHERO
	// DENE INDICARSE EN PARAMETROS EL TEXTO Y EL NOMBRE DEL FICHERO A CREAR
	public static byte[] leerBytearrayDeFichero(String nombrefichero, String pathdelfichero) {
		File fichero = new File(pathdelfichero, nombrefichero);
		byte[] ficheroenbytes;
		try {
			ficheroenbytes = Files.readAllBytes(fichero.toPath());
			return ficheroenbytes;
		} catch (IOException e) {
			e.printStackTrace();
		}
		return null;
	}

	// ESTE METODO ESCRIBE CUALQUIER TEXTO EN UN FICHERO
	// DENE INDICARSE EN PARAMETROS EL TEXTO Y EL NOMBRE DEL FICHERO A CREAR
	public static void escribirTextoEnFichero(String texto, String nombrefichero, String pathdelfichero) {
		File fichero = new File(pathdelfichero, nombrefichero);
		PrintWriter pw = null;
		try {
			pw = new PrintWriter(fichero);
			pw.println(texto);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} finally {
			pw.close();
		}
	}

	// ESTE METODO ESCRIBE CUALQUIER TEXTO EN UN FICHERO
	// DENE INDICARSE EN PARAMETROS EL TEXTO Y EL NOMBRE DEL FICHERO A CREAR
	public static String leerTextoDeFichero(String nombrefichero, String pathdelfichero) {
		File fichero = new File(pathdelfichero, nombrefichero);
		BufferedReader br = null;
		FileReader fr = null;
		String textoentero = "";
		try {
			fr = new FileReader(fichero);
			br = new BufferedReader(fr);
			String linea = br.readLine();
			while (linea != null) {
				textoentero = textoentero + linea + "\n";
				linea = br.readLine();
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		return textoentero;
	}
}
