import java.util.Random;
import java.util.Scanner;

public class Inicio {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		
		String frase = sc.nextLine();
		frase = frase.toUpperCase();
		
		System.out.println(frase);

	}

}
