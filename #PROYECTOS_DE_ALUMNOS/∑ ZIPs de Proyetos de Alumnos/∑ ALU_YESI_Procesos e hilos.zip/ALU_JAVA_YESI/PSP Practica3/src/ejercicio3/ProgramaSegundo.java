package ejercicio3;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.*;

public class ProgramaSegundo {
	public static void main(String[] args) {
		
		// ESCRIBIR
		escribir();

		// LEER
		leer();
	}

	public static void leer() {
		DatagramSocket dSocket = null;
		DatagramPacket packet;
		InetAddress inetdireccion;
		try {
			// Preparar una array de bytes donde recibir un datagrama
			byte[] arrayDondeRecibir = new byte[5000];
			// Recibir un datagrama
			packet = new DatagramPacket(arrayDondeRecibir, arrayDondeRecibir.length);
			inetdireccion = InetAddress.getByName("localhost");
			dSocket = new DatagramSocket(22004, inetdireccion);
			dSocket.receive(packet);
			// Convertir el datagrama leido como byte[] en un objeto
			String respuesta = new String(arrayDondeRecibir, "UTF-8");
			System.out.println("Programa A recibe de B : " + respuesta);
			dSocket.close();

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			dSocket.close();
		}
	}

	public static void escribir() {
		DatagramSocket dSocket = null;
		DatagramPacket dpacket;
		InetAddress inetdireccion;
		try {
			// Convertimos el string en un array de bytes
			String pregunta = "Hola";
			byte[] arraybytes = pregunta.getBytes("UTF-8");
			// Enviamos el byte[] como un Datagram normal
			inetdireccion = InetAddress.getByName("localhost");
			dpacket = new DatagramPacket(arraybytes, arraybytes.length, inetdireccion, 22003);
			dSocket = new DatagramSocket();
			dSocket.send(dpacket);
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			dSocket.close();
		}
	}
}
