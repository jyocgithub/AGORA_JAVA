package ejercicio2;

import java.io.*;
import java.net.*;

// 	EJECUTAR SERVIDOR ANTES QUE ESTE

public class Cliente {
	public static void main(String[] args) {
		Socket socket = null;
		try {
			
		
			socket = new Socket("localhost", 22222 );

			OutputStream canalDeEscrituraDelSocket = socket.getOutputStream(); // output es SALIR HACIA FUERA (out) de// mi programa, esto es, ESCRIBIR
            DataOutputStream escritor = new DataOutputStream(canalDeEscrituraDelSocket);

			InputStream canalDeLecturaDelSocket = socket.getInputStream();   // input es ENTRAR EN EL PROGRAMA (in) de mi programa, esto es, RECIBIR (LEER)
			DataInputStream lector  = new DataInputStream(canalDeLecturaDelSocket);

			// PASO 1: ESCRIBIR MENSAJE EN EL SERVIDOR
			String mensaje = "¿Como te llamas?";
			byte[] arraybytes = mensaje.getBytes("UTF-8");
			
			// escribimos uno a uno los bytes
			for( int i=0; i<arraybytes.length ;i++) {
				escritor.writeByte(arraybytes[i]);
			}
			
			
			// PASO 2: LEER MENSAJE DEL SERVIDOR
			byte[] array = new byte[1000];
			int x = 0;
			byte byteleido = lector.readByte();
			while (byteleido != '.') {
				array[x] = byteleido;
				x++;
				byteleido = lector.readByte();
			}
			array[x] = byteleido;   // añadimos el ultimo byte leido
			array = quitarCeros(array) ;  // qwuitamos los ceros del final 
			String respuesta = new String(array, "UTF-8");
			System.out.println("Me contesta el servidor: " +respuesta);
			
			
			
		} catch (UnknownHostException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				socket.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
	
	
	public static byte[] quitarCeros(byte[] original) {
		byte[] res;
		int pos = 0;
		while(original[pos]!=0) {
			pos++;
		}
		int tam = pos + 1;
		res = new byte[tam];
		for (int i = 0; i < res.length; i++) {
			res[i] = original[i];
		}
		return res;
	}
	
	
	
	
	
	
	
	
	
}
