package ejercicio2;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.*;

public class Servidor {

	public static void main(String[] args) {

		ServerSocket servidor = null;
		Socket socket = null;
		DataInputStream lector = null;
		DataOutputStream escritor = null;

		try {
			servidor = new ServerSocket(22222);
			System.out.println("Soy servidor, y me quedo en espera de que alguien me llame");
			socket = servidor.accept();

			// input es ENTRAR EN EL PROGRAMA (in) de mi programa, esto es, RECIBIR (LEER)
			InputStream canalDeLecturaDelSocket = socket.getInputStream(); 
			lector = new DataInputStream(canalDeLecturaDelSocket);

			// output es SALIR HACIA FUERA (out) de mi programa, esto es, ESCRIBIR
			OutputStream canalDeEscrituraDelSocket = socket.getOutputStream(); 
			escritor = new DataOutputStream(canalDeEscrituraDelSocket);

			// PASO 1: LEER MENSAJE DEL CLIENTE
			byte[] array = new byte[1000];
			int x = 0;
			byte byteleido = lector.readByte();
			while (byteleido != '?') {
				array[x] = byteleido;
				System.out.println(array[x]);
				x++;
				byteleido = lector.readByte();
			}
			array[x] = byteleido;   // añadimos el ultimo byte leido
			array = quitarCeros(array) ;
			
//			String mensaje = new String(array);
			String mensaje = new String(array, "UTF-8");
			System.out.println(mensaje + mensaje.length());

			
			// PASO 2: ESCRIBIR MENSAJE EN EL CLIENTE

			String respuesta ="";
//			if(mensaje.startsWith("¿Como te llamas?")) {
            if(mensaje.equals("¿Como te llamas?")) {
            	respuesta = "Me llamo ejercicio 2.";
            } else if(mensaje.equals("¿Cuántas líneas de código tienes?")) {
            	respuesta = "unas 85 aproximadamente.";
            }else {
            	respuesta = "No he entendido la pregunta.";            	
            }
//            byte[] arraybytes = respuesta.getBytes();
			byte[] arraybytes = respuesta.getBytes("UTF-8");

			// escribimos uno a uno los bytes
			for (int i = 0; i < arraybytes.length; i++) {
				escritor.writeByte(arraybytes[i]);
			}


		} catch (IOException e) {

			e.printStackTrace();
		} finally {
			try {
				lector.close();
				socket.close();
				servidor.close();
			} catch (IOException e) {
				e.printStackTrace();
			}

		}

	}
	
	
	public static byte[] quitarCeros(byte[] original) {
		byte[] res;
		int pos = 0;
		while(original[pos]!=0) {
			pos++;
		}
		int tam = pos ;
		res = new byte[tam];
		for (int i = 0; i < res.length; i++) {
			res[i] = original[i];
		}
		return res;
	}
}
