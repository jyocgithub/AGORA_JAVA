package ejercicio1;

import java.io.*;
import java.net.*;

public class ProgramaSegundo {
	public static void main(String[] args) {
		Socket socket = null;
		String linea = "";
		DataInputStream entrada = null;
		try {
			socket = new Socket("localhost", 22222);

			// input es ENTRAR EN EL PROGRAMA (in) de mi programa, esto es, RECIBIR (LEER)
			entrada = new DataInputStream(socket.getInputStream());
			String ficheroleidodelsocket = "";
			linea = entrada.readUTF();
			while (true) {
				ficheroleidodelsocket = ficheroleidodelsocket + linea;
				linea = entrada.readUTF();
			}

		} catch (EOFException e) {
			System.out.println("Me contesta el programa A: \n" + linea);

		} catch (UnknownHostException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				entrada.close();
				socket.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
}
