package ejercicio1;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.*;

public class ProgramaPrimero {

	public static void main(String[] args) {

		ServerSocket servidor = null;
		Socket socket = null;
		BufferedReader lector  = null;

		try {
			servidor = new ServerSocket(22222);
			System.out.println("Soy servidor, y me quedo en espera de que alguien me llame");
			socket = servidor.accept();
			DataOutputStream salida = new DataOutputStream(socket.getOutputStream());																// mi programa, esto es, ESCRIBIR
		
			// leer un fichero de disco y guardarlo en un String
			lector  = new BufferedReader(new FileReader("cosas.txt"));
			
			String contenidoDelficheroDeDisco = "";
			String linea = lector.readLine();
			while(linea != null) {
				contenidoDelficheroDeDisco = contenidoDelficheroDeDisco + linea + "\n";
				linea = lector.readLine();
			}
	
			salida.writeUTF(contenidoDelficheroDeDisco);

		} catch (IOException e) {

			e.printStackTrace();
		} finally {
			try {
				lector.close();
				socket.close();
				servidor.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}}

