package ejercicio4;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.*;

// 	EJECUTAR ProgramaPrimero ANTES QUE ESTE

public class ProgramaSegundo {
	public static void main(String[] args) {
		
		
		Alumno alumno = new Alumno ("Ana", 123);
		ProcesarUDP p = new ProcesarUDP();
		p.enviarObjetoUDP(alumno, "localhost", 22002);
	}
}
