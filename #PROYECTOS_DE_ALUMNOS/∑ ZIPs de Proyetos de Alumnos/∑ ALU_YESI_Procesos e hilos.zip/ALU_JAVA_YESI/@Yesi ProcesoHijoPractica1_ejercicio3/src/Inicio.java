import java.util.Random;

public class Inicio {

	public static void main(String[] args) {

		Random r = new Random ();
		
		int numero = r.nextInt(40);
		
		System.out.println(numero);

	}

}
