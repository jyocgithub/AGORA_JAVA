package ejercicio4Interrupcion;

import java.util.concurrent.Semaphore;

public class Cocinero extends Thread {
	private Pedido pedido;
	private String nombre;
	private Camarero camarero;

	@Override
	public void run() {

		while (true) {

			try {
				while (true) {
					sleep(100);
				}
			} catch (InterruptedException e) {
				System.out.println(" Cocinero: Acaban de decirme que hay un pedido");
			}

			pedido = camarero.getPedido();
			System.out.println(" Cocinero: Me pongo a cocinar " + pedido.getPlato());
			boolean estoycocinando = true;
			while (estoycocinando) {
				try {
					sleep(400);
					estoycocinando = false;
					System.out.println(" Cocinero: Plato listo");
				} catch (InterruptedException e) {
				}
			}

		}

	}

	public void setCamarero(Camarero camarero) {
		this.camarero = camarero;
	}

}
