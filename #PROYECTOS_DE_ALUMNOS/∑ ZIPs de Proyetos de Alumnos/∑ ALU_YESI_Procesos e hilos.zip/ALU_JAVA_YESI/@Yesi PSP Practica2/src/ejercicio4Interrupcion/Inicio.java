package ejercicio4Interrupcion;

import java.util.concurrent.Semaphore;

public class Inicio {

	public static void main(String[] args) {


		Cocinero coc=null;
		Camarero cam=null;

		coc = new Cocinero();
		cam = new Camarero();
		coc.setCamarero(cam);
		cam.setCocinero(coc);		
		
		cam.start();
		coc.start();

	}

}
