package ejercicio4Interrupcion;

public class Pedido {
	
	private String plato ="";
	volatile int contadorPlatos = 0;
	
	
	
	
	public String getPlato() {
		return plato;
	}
	public void setPlato(String plato) {
		this.plato = plato;
	}
	
	
	
}
