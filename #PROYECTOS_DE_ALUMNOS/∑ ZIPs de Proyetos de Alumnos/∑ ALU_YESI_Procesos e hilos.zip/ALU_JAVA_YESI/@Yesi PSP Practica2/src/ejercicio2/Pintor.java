package ejercicio2;

import java.util.concurrent.Semaphore;

public class Pintor extends Thread {
	private Pizarra pizarra;
	private int miturno;
	private String  mensaje;

	// constructor
	public Pintor(String nombre, Pizarra pizarra, int miturno, String mensaje) {
		super(nombre);
		this.pizarra = pizarra;
		this.miturno = miturno;
		this.mensaje = mensaje;
	}

	@Override
	public void run() {
		for (int i = 0; i < 10; i++) {
			pizarra.escribirEnLaPizarra(mensaje, miturno);
		}
		System.out.println(getName() + " ha finalizado");

	}

}
