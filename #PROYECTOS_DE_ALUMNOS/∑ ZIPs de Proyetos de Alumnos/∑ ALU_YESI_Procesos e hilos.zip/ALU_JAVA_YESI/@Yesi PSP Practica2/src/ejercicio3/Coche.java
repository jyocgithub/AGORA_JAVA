package ejercicio3;

import java.util.concurrent.Semaphore;

public class Coche extends Thread {
	private Garage garage;
	private String nombre ;

	// constructor
	public Coche(String nombre, Garage garage) {
		super(nombre);
		this.garage = garage;
		this.nombre = nombre;
	}

	@Override
	public void run() {
		garage.entrar(nombre);
		try {
			sleep(100);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		garage.salir(nombre);
	}

}
