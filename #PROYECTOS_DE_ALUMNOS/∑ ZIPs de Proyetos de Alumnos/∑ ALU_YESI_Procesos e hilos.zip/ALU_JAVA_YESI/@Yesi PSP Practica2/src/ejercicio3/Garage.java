package ejercicio3;

public class Garage {

	private int maximo = 10;
	private int cochesActuales = 0;

	public synchronized void entrar(String nombre) {
		try {

			while (cochesActuales >= maximo) {
				wait();
			}
			cochesActuales++ ;
			System.out.println(nombre + " entra en el garage (quedan "+(maximo-cochesActuales)+" plazas libres)");
			
			

		} catch (InterruptedException e) { 
			e.printStackTrace();
		}
	}

	public synchronized void salir(String nombre) {
			cochesActuales --;
			notifyAll();
			System.out.println(nombre + " ha salido del garage (ahora hay "+(maximo-cochesActuales)+" plazas libres)");
	
	}

}
