package ejercicio4;

import java.util.concurrent.Semaphore;

public class Inicio {

	public static void main(String[] args) {


		Cocinero coc=null;
		Camarero cam=null;
		Pedido pedido = new Pedido();

		coc = new Cocinero(pedido);
		cam = new Camarero(pedido);	
		
		cam.start();
		coc.start();

	}

}
