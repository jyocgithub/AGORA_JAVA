package ejercicio4;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintStream;
import java.util.Scanner;

public class ProcesoPadre {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		String linea="";
		boolean seguir = true;

		do {
			try {
				ProcessBuilder procesohijo = new ProcessBuilder("java", "-jar", "ProcesoHijoPractica1_ejercicio4.jar");
				Process procesoHijo = procesohijo.start();

				InputStream streamLeerDeHijo = procesoHijo.getInputStream();
				InputStreamReader canalLeerDeHijo = new InputStreamReader(streamLeerDeHijo);
				BufferedReader maquinaLeerDeHijo = new BufferedReader(canalLeerDeHijo);
				
				OutputStream streamEscribirEnHijo = procesoHijo.getOutputStream();
				PrintStream maquinaEscribirEnHijo = new PrintStream(streamEscribirEnHijo, true);

				System.out.println("Dime una frase");
				linea = sc.nextLine();
				maquinaEscribirEnHijo.println(linea);

				String mensaje = maquinaLeerDeHijo.readLine();
				System.out.println("Acabo de leer la frase en mayusculas, y es:");
				System.out.println(mensaje);
			} catch (IOException e) {
				e.printStackTrace();
			}
			if (linea.equalsIgnoreCase("FIN")) {
				seguir = false;
			}
		} while (seguir == true);
	}
}
