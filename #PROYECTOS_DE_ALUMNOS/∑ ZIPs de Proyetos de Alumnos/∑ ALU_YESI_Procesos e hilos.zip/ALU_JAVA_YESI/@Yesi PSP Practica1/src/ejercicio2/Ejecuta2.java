package ejercicio2;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

public class Ejecuta2 {
	public static void main(String[] args) {

		if (args.length == 0) {
			System.out.println("Debe recibirse algun parametro");
		} else {
			ProcessBuilder obProBuil = new ProcessBuilder(args);// creamos un proceso con un array de string q contiene
			try {
				Process obProcesoHijo = obProBuil.start();// ejecuto el proceso y a la vez me lo guardo en la variable
															// obProcesoHijo
				InputStream in = obProcesoHijo.getInputStream();
		        BufferedReader br = new BufferedReader(new InputStreamReader(in));
		        String linea = br.readLine();
		        while(linea!=null) {
		        	System.out.println(linea);
		        	linea = br.readLine();
		        }
				
				int codExit = obProcesoHijo.waitFor(); // mi programa se queda esperando a que obprocesohjo acabe. Y
														// cuando acabe me dice su codigo de salida
				if (codExit == 0) { // normalmente un codigo de salida 0 es que todo ha ido bien
					System.out.println("La ejecucion devuelve " + codExit + " , todo ha ido bien");
				} else {
					System.out.println("La ejecucion devuelve " + codExit + ", puede que sufriera un error");
				}

			} catch (IOException e) {
				System.out.println("Error en al ejecucion de su peticion");
			} catch (InterruptedException e) {
				e.printStackTrace();
			}

		}
	}
}
