package practica5_3;
import java.io.IOException;
import java.util.Scanner;


import javax.xml.parsers.ParserConfigurationException;
import javax.xml.xquery.XQConnection;
import javax.xml.xquery.XQDataSource;

import javax.xml.xquery.XQException;
import javax.xml.xquery.XQPreparedExpression;

import javax.xml.xquery.XQResultSequence;
import javax.xml.xquery.XQSequence;
import org.xmldb.api.base.XMLDBException;

import net.xqj.exist.ExistXQDataSource;

public class Main {
	
	static Scanner scI;
	static Scanner scS;
	static int opcion;
	static int dep;
	static XQuery xquery;
	private static XQDataSource server = new ExistXQDataSource();
	public static void main(String[] args) throws IOException, ParserConfigurationException, XQException,SecurityException{
		//poner nombre del servidor, el puerto, usuasrio y password. 
		 server.setProperty("serverName", "localhost");
	     server.setProperty("port", "8080");
	     server.setProperty("user", "admin");
	     server.setProperty("password", "root");

		xquery= new XQuery();
		xquery.conectar();
		scI = new Scanner(System.in);
		scS = new Scanner(System.in);
		try {
			do {
				dibujarMenu();
				System.out.print("Elige una opci�n: ");
				opcion = scI.nextInt();
					switch (opcion) {
					case 1:
						xquery.cargarProductos();
						break;
					case 2:
						try {
							stockMinimo();
						}catch(Exception e) {
							e.printStackTrace();
						}
						break;
					case 3:
						opcion3();
						break;
					case 4:
						opcion4();
						break;
					}
				}while (opcion != 0);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	static void dibujarMenu() {
		System.out.println(" 1 - Mostrar productos");//funciona
		System.out.println(" 2 - Mostrar productos con stock minimo<5");//funciona
		System.out.println(" 3 - Modificar producto");
		System.out.println(" 4 - Insertar producto");//funciona
		System.out.println(" 0 - Salir");
	}
	
	public static void opcion3() throws XMLDBException {//llama al metodo modificarProd()
		int cod_prod;
		String denominacion;
		int precio;
		int stock_actual,stock_minimo;
		int cod_zona;
		try {
			System.out.println("Introduce el codigo de producto:");
			cod_prod= scI.nextInt();
			System.out.println("Denominacion:");
			denominacion = scS.nextLine();
			System.out.println("Precio:");
			precio=scI.nextInt();
			System.out.println("Stock actual:");
			stock_actual=scI.nextInt();
			System.out.println("Stock minimo:");
			stock_minimo=scI.nextInt();
			System.out.println("cod_zona:");
			cod_zona=scI.nextInt();
			
			xquery.modificarProd(cod_prod, denominacion, precio, stock_actual, stock_minimo, cod_zona);
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
	public static void opcion4() {//llama al metodo insertarProducto()
		int cod_prod;
		String denominacion;
		int precio;
		int stock_actual,stock_minimo;
		int cod_zona;
		try {
			System.out.println("Introduce el codigo de producto:");
			cod_prod= scI.nextInt();
			System.out.println("Denominacion:");
			denominacion = scS.nextLine();
			System.out.println("Precio:");
			precio=scI.nextInt();
			System.out.println("Stock actual:");
			stock_actual=scI.nextInt();
			System.out.println("Stock minimo:");
			stock_minimo=scI.nextInt();
			System.out.println("cod_zona:");
			cod_zona=scI.nextInt();
			
			xquery.insertarProducto(cod_prod,denominacion,precio,stock_actual,stock_minimo,cod_zona);

			}catch(Exception e) {
				e.printStackTrace();
			}
	}
	public static void stockMinimo() {
		try {
			XQConnection conn = server.getConnection();
	        XQPreparedExpression consulta = conn
	                .prepareExpression("(/productos/produc[stock_minimo<5]) ");
	        XQResultSequence resultado = consulta.executeQuery();
	        resultado.next();
	        System.out.println("--------------------------------------------");
	        System.out.println("productos con stock minimo<5: " + resultado.getInt());
	        conn.close();
	    } catch (XQException ex) {
	        System.out.println("Error en las propiedades del server.");
	        System.out.println("Error al operar.");
	        ex.printStackTrace();
	    }catch(SecurityException ex) {
	    	ex.printStackTrace();
	    }
}
}

