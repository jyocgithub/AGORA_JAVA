package practica2eval;

import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.hibernate.Session;

import practica2eval.dao.ArticuloDAO;
import practica2eval.dao.ClienteDAO;
import practica2eval.dao.LineaPedidoDAO;
import practica2eval.dao.PedidoDAO;
import practica2eval.dao.exception.ExcepcionDAO;
import practica2eval.hibernate.util.HibernateUtil;
import practica2eval.model.Articulo;
import practica2eval.model.Cliente;
import practica2eval.model.IdLineaPedido;
import practica2eval.model.LineaPedido;
import practica2eval.model.Pedido;

public class CPrincipalPracticaHibernate
{

	public static void main(String[] args)
	{


		Session session = HibernateUtil.getSessionFactory().openSession();
	    session.beginTransaction();


	    //PRUEBAS - Apartados 1, 2 y 3
	    //---------------------------------------------------------------------------------------

	    //Prueba 1.- Insertar los siguientes empleados:

	    System.out.println("____________________PRUEBA 1____________________");

	    ClienteDAO cDAO = new ClienteDAO();
	    PedidoDAO pDAO = new PedidoDAO();
	    ArticuloDAO aDAO = new ArticuloDAO();
	    LineaPedidoDAO lpDAO = new LineaPedidoDAO();


	    Cliente c1 = new Cliente("11111111x", "Ram�n", "Garc�a", new Date());
	    Cliente c2 = new Cliente("22222222x", "Hulk", new Date());
	    Cliente c3 = new Cliente("33333333x", "Spiderman", new Date());
	    try
		{
			c3.setFechaAlta(new SimpleDateFormat("dd/mm/yyyy - HH:mm").parse("09/01/1992 - 17:00"));
		}
		catch (ParseException e)
		{
			e.printStackTrace();
		}
	    try
	    {
	    	cDAO.insertarCliente(c1);
	    }
	    catch(ExcepcionDAO e)
	    {
	    	System.out.println(e.getMessage());
	    }
	    try
	    {
	    	cDAO.insertarCliente(c2);
	    }
	    catch(ExcepcionDAO e)
	    {
	    	System.out.println(e.getMessage());
	    }
	    try
	    {
	    	cDAO.insertarCliente(c3);
	    }
	    catch(ExcepcionDAO e)
	    {
	    	System.out.println(e.getMessage());
	    }


//EXCEPCION//Prueba 2.- Insertar, de nuevo, un empleado con DNI 22222222x (deber� informar de que ese empleado ya existe).
		//ERROR_REGISTRO_DUPLICADO

	    System.out.println("____________________PRUEBA 2____________________");

	    try
	    {
	    	cDAO.insertarCliente(c2);
	    }
	    catch(ExcepcionDAO e)
	    {
	    	System.out.println(e.getMessage());
	    }


	    //Prueba 3.- Buscar el empleado con DNI 22222222x e imprimir por pantalla todos sus datos.

	    System.out.println("____________________PRUEBA 3____________________");

	    Cliente c4 = null;

	    try
		{
	    	c4 = cDAO.buscarCliente("22222222x");
		}
		catch (ExcepcionDAO e)
		{
			System.out.println(e.getMessage());
		}


        System.out.println("ID: " + c4.getIdCliente());
        System.out.println("DNI: " + c4.getDNI());
        System.out.println("Nombre: " + c4.getNombre());

        if(c4.getApellidos() != null)
        	System.out.println("Apellidos: " + c4.getApellidos());

        System.out.println("Fecha de alta: " + c4.getFechaAlta());


	    //Prueba 4.- Modificar el empleado con DNI 22222222x para cambiarle el nombre a "El incre�ble Hulk" y ponerle como apellidos "S�nchez".

        System.out.println("____________________PRUEBA 4____________________");

        Cliente c5 = new Cliente();
        c5.setNombre("El Increible Hulk");
        c5.setApellidos("Sanchez");

        try
		{
			cDAO.modificarCliente("22222222x", c5);
		}
		catch (ExcepcionDAO e)
		{
			System.out.println(e.getMessage());
		}



	    //Prueba 5.- Borrar el empleado con DNI 33333333x.

        System.out.println("____________________PRUEBA 5____________________");

        try
		{
			cDAO.borrarCliente("33333333x");
		}
		catch (ExcepcionDAO e)
		{
			System.out.println(e.getMessage());
		}


//EXCEPCION//Prueba 6.- Buscar el empleado 33333333x (deber�a decir que no existe).

	    	//ERROR_NULL_POINTER

        System.out.println("____________________PRUEBA 6____________________");

        Cliente c6 = null;

        try
		{
			c6 = cDAO.buscarCliente("33333333x");
			System.out.println("ID: " + c6.getIdCliente());
	        System.out.println("DNI: " + c6.getDNI());
	        System.out.println("Nombre: " + c6.getNombre());
	        if(c6.getApellidos() != null)
	        	System.out.println("Apellidos: " + c6.getApellidos());

	        System.out.println("Fecha de alta: " + c6.getFechaAlta());
		}
		catch (ExcepcionDAO e)
		{
			System.out.println(e.getMessage());
		}

	    //Prueba 7.- Insertar, de nuevo, el empleado 33333333x con los datos originales.

        System.out.println("____________________PRUEBA 7____________________");

        Cliente c7 = new Cliente("33333333x", "Spiderman", new Date());

        try
		{
			cDAO.insertarCliente(c3);
		}
		catch (ExcepcionDAO e)
		{
			System.out.println(e.getMessage());
		}

	    //Prueba 8.- Insertar los siguientes art�culos:

        System.out.println("____________________PRUEBA 8____________________");

        Articulo a1 = new Articulo("1A", "Tornillos", new BigDecimal(140.12));
        Articulo a2 = new Articulo("3A", "Chorizo", new BigDecimal(1), "Chorizo del bueno");
        Articulo a3 = new Articulo("4A", "Salchich�n", new BigDecimal(10));


        try
		{
			aDAO.insertarArticulo(a1);
		}
		catch (ExcepcionDAO e)
		{
			System.out.println(e.getMessage());
		}
        try
		{
			aDAO.insertarArticulo(a2);
		}
		catch (ExcepcionDAO e)
		{
			System.out.println(e.getMessage());
		}
        try
		{
			aDAO.insertarArticulo(a3);
		}
		catch (ExcepcionDAO e)
		{
			System.out.println(e.getMessage());
		}


//EXCEPCION//Prueba 9.- Insertar, de nuevo, un art�culo con c�digo 1A (deber� informar de que ese art�culo ya existe).
	    //ERROR_REGISTRO_DUPLICADO

        System.out.println("____________________PRUEBA 8.1____________________");

        try
		{
        	Articulo a4 = new Articulo("1A", "Queso", new BigDecimal(500), "Queso del rico");
		}
		catch (ExcepcionDAO e)
		{
			System.out.println(e.getMessage());
		}


	    //Prueba 10.- Buscar el art�culo 1A. Mostrar sus datos.

        System.out.println("____________________PRUEBA 9____________________");


        Articulo a5 = null;
        try
		{
			a5 = aDAO.buscarArticulo("1A");
		}
		catch (ExcepcionDAO e)
		{
			System.out.println(e.getMessage());
		}


	    System.out.println("ID: " + a5.getIdArticulo());
        System.out.println("Codigo: " + a5.getCodigo());
        System.out.println("Nombre: " + a5.getNombre());
        System.out.println("PVP: " + a5.getPrecio());

        if(a5.getDescripcion() != null)
        	System.out.println("Descripcion: " + a5.getDescripcion());


	    //Prueba 11.- Borrar el art�culo 3A.

		System.out.println("____________________PRUEBA 10____________________");


		try
		{
			aDAO.borrarArticulo("3A");
		}
		catch (ExcepcionDAO e)
		{
			System.out.println(e.getMessage());
		}



	    //Prueba 12.- Insertar de nuevo el art�culo 3A con los mismos datos originales.

	    System.out.println("____________________PRUEBA 11____________________");


	    Articulo a6 = new Articulo("3A", "Chorizo", new BigDecimal(1), "Chorizo del bueno");
	    try
		{
	    	aDAO.insertarArticulo(a6);
		}
		catch (ExcepcionDAO e)
		{
			System.out.println(e.getMessage());
		}


	    //Prueba 13.- Modificar el art�culo 4A para ponerle, como nombre, �Super salchich�n�.

	    System.out.println("____________________PRUEBA 12____________________");


	    Articulo a7 = new Articulo();
	    a7.setNombre("Super Salchichon");
	    a7.setPrecio(new BigDecimal(10));

	    try
		{
	    	aDAO.modificarArticulo("4A", a7);
		}
		catch (ExcepcionDAO e)
		{
			System.out.println(e.getMessage());
		}


	    //Prueba 14.- Buscar el cliente 22222222x para crear un pedido con c�digo P1.
	    //La fecha deber�a ser la actual. Posteriormente, se a�adir�n 2 tipos de art�culos: 1A (2 unidades) y 4A (1 unidad).

        System.out.println("____________________PRUEBA 13____________________");


        try
		{
        	pDAO.insertarPedido("P1", "22222222x");
		}
		catch (ExcepcionDAO e)
		{
			System.out.println(e.getMessage());
		}

        LineaPedido lp1 = new LineaPedido(pDAO.buscarPedido("P1"), aDAO.buscarArticulo("1A"), 2);
        LineaPedido lp2 = new LineaPedido(pDAO.buscarPedido("P1"), aDAO.buscarArticulo("4A"), 1);


        try
		{
        	lpDAO.insertarLineaPedido(lp1);
		}
		catch (ExcepcionDAO e)
		{
			System.out.println(e.getMessage());
		}

        try
		{
        	lpDAO.insertarLineaPedido(lp2);
		}
		catch (ExcepcionDAO e)
		{
			System.out.println(e.getMessage());
		}

	    //Prueba 15.- Borrar el pedido P1.

        System.out.println("____________________PRUEBA 14____________________");


        try
		{
        	pDAO.eliminarPedido("P1");
		}
		catch (ExcepcionDAO e)
		{
			System.out.println(e.getMessage());
		}

        //PRUEBA 15 - Volver a crear el pedido P1 con los datos originales.
        try
		{
        	pDAO.insertarPedido("P1", "22222222x");
		}
		catch (ExcepcionDAO e)
		{
			System.out.println(e.getMessage());
		}


	    //Prueba 16.- Volver a crear el pedido P1 con los datos originales.

        System.out.println("____________________PRUEBA 15____________________");


        try
		{
        	pDAO.insertarPedido("P1", "22222222x");
		}
		catch (ExcepcionDAO e)
		{
			System.out.println(e.getMessage());
		}


	    //Prueba 17.- Buscar el pedido P1 para mostrar los art�culos que tiene, sus cantidades y sus precios unitarios.

        System.out.println("____________________PRUEBA 16____________________");


        Pedido p2 = pDAO.buscarPedido("P1");
        System.out.println(p2.getCodigoPedido());

        for (LineaPedido lineaPedido : p2.getHsLineaPedido())
		{
			System.out.println();
			System.out.println(lineaPedido.getArticulo().getNombre());
			System.out.println(lineaPedido.getCantidad());
			System.out.println(lineaPedido.getPvp_unitario());
		}


	   session.getTransaction().commit();

	   session.close();


	    HibernateUtil.shutdown();
	}

}
