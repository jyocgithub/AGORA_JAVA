package practica2eval.dao;

import org.hibernate.exception.ConstraintViolationException;

import practica2eval.dao.exception.ExcepcionDAO;
import practica2eval.dao.exception.MensajeError;
import practica2eval.dao.exception.TipoProblemaDAO;
import practica2eval.model.Articulo;

public class ArticuloDAO extends DAO
{
	public void insertarArticulo(Articulo articulo)
	{
		abrirSesion();

		try
		{
			session.save(articulo);
			cerrarSesion();
		}
		catch (ConstraintViolationException e)
		{
			throw new ExcepcionDAO(MensajeError.getMensaje(TipoProblemaDAO.ERROR_REGISTRO_DUPLICADO));
		}
	}

	public void borrarArticulo(String codigo)
	{
		Articulo articulo = buscarArticulo(codigo);

		abrirSesion();

		try
		{
			session.delete(articulo);

			cerrarSesion();
		}
		catch (NullPointerException e)
		{
			throw new ExcepcionDAO(MensajeError.getMensaje(TipoProblemaDAO.ERROR_REGISTRO_NULO_O_INEXISTENTE));
		}

	}

	public Articulo buscarArticulo(String codigo)
	{
		abrirSesion();

		Articulo articulo = session.bySimpleNaturalId(Articulo.class).load(codigo);

		cerrarSesion();

		return articulo;
	}

	public void modificarArticulo(String codigo, Articulo nuevoArticulo)
	{
		Articulo articulo = buscarArticulo(codigo);

		abrirSesion();

		nuevoArticulo.setIdArticulo(articulo.getIdArticulo());
		nuevoArticulo.setCodigo(articulo.getCodigo());
		session.evict(articulo);

		try
		{
			session.update(nuevoArticulo);

			cerrarSesion();
		}
		catch (ConstraintViolationException e)
		{
			throw new ExcepcionDAO(MensajeError.getMensaje(TipoProblemaDAO.ERROR_REGISTRO_DUPLICADO));
		}
		catch (NullPointerException e)
		{
			throw new ExcepcionDAO(MensajeError.getMensaje(TipoProblemaDAO.ERROR_REGISTRO_NULO_O_INEXISTENTE));
		}

	}
}