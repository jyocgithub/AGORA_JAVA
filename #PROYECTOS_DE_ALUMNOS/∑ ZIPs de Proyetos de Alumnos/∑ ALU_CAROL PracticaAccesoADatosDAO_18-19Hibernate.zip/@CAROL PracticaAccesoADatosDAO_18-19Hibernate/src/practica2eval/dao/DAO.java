package practica2eval.dao;

import org.hibernate.HibernateException;
import org.hibernate.Session;

import practica2eval.dao.exception.TipoProblemaDAO;
import practica2eval.dao.exception.MensajeError;
import practica2eval.dao.exception.ExcepcionDAO;
import practica2eval.hibernate.util.HibernateUtil;

public class DAO
{
	protected Session session;

	public void abrirSesion()
	{
		try
		{
			session = HibernateUtil.getSessionFactory().openSession();
			session.beginTransaction();
		}
		catch(HibernateException e)
		{
			throw new ExcepcionDAO(MensajeError.getMensaje(TipoProblemaDAO.ERROR_CONEXION));
		}

	}

	public void cerrarSesion()
	{
		try
		{
			session.getTransaction().commit();
			session.close();
		}
		catch(HibernateException e)
		{
			throw new ExcepcionDAO(MensajeError.getMensaje(TipoProblemaDAO.ERROR_CONEXION));
		}

	}
}
