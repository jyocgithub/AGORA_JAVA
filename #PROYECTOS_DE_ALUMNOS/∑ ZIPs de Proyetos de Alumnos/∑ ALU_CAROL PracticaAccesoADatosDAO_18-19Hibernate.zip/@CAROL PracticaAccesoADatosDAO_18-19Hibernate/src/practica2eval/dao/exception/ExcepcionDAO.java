package practica2eval.dao.exception;

/**
 * Excepcion personalizada que controla todos los posibles errores de las clases DAO
 */
public class ExcepcionDAO extends RuntimeException
{
	private static final long serialVersionUID = 8501063947381280216L;

	/**
	 * Constructor de la excepcion personalizada
	 * 
	 * @param mensaje Mensaje de error
	 */
	public ExcepcionDAO(String mensaje)
	{
		super(mensaje);
	}
}