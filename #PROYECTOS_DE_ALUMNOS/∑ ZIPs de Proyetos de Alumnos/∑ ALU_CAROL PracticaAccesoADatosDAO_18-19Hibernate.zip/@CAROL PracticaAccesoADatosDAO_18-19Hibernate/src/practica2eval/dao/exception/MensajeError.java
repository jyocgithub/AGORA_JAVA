package practica2eval.dao.exception;

/**
 * Clase que selecciona el mensaje de error correcto segun el tipo de error
 */
public class MensajeError
{
	/**
	 * Metodo que devuelve el mensaje correspondiente al tipo de problema
	 * 
	 * @param tipoProblema El tipo de problema que ha sucedido
	 * @return El mensaje de error correspondiente
	 */
	public static String getMensaje(TipoProblemaDAO tipoProblema)
	{
		return tipoProblema.getDescripcion();
	}

	/**
	 * Metodo exclusivo para MySQL que devuelve el mensaje correspondiente al codigo de error
	 * 
	 * @param codigoErrorGestor El codigo de error
	 * @return El mensaje de error correspondiente
	 */
	public static String getMensajeMySQL(int codigoErrorGestor)
	{
		TipoProblemaDAO tipoProblema = null;

		switch (codigoErrorGestor)
		{
			case 1049:
				tipoProblema = TipoProblemaDAO.ERROR_CONEXION;
				break;
			case 1022:
			case 1062:
				tipoProblema = TipoProblemaDAO.ERROR_REGISTRO_DUPLICADO;
				break;
			default:
				tipoProblema = TipoProblemaDAO.ERROR_ACCESO_BASE_DATOS_DESCONOCIDO;
		}

		return getMensaje(tipoProblema);
	}
}