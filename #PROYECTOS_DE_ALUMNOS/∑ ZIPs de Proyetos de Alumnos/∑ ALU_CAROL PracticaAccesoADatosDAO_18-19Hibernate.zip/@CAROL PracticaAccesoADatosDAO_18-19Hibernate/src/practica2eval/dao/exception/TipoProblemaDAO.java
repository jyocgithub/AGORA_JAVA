package practica2eval.dao.exception;

/**
 * Clase que enumera los tipos de errores posibles a seleccionar, con su correspondiente mensaje de error
 */
public enum TipoProblemaDAO
{
	ERROR_CONEXION("No se puede conectar a la base de datos seleccionada"),
	ERROR_REGISTRO_DUPLICADO("El registro est� duplicado en la base de datos"),
	ERROR_ACCESO_BASE_DATOS_DESCONOCIDO("Error desconocido de acceso a la base de datos"),
	ERROR_ENTRADA_SALIDA("Error de I/O"),
	ERROR_FICHERO_NO_ENCONTRADO("El fichero no se ha encontrado o no existe"),
	ERROR_REGISTRO_NO_ENCONTRADO("El registro no existe en la base de datos"),
	ERROR_REGISTRO_NULO_O_INEXISTENTE("El registro no existe o es nulo"),
	ERROR_DE_CLAVE_UNICA("Error. Existe un objeto unico con la misma clave");

	private String descripcion;

	/**
	 * Constructor de la clase TipoProblemaDAO
	 *
	 * @param descripcion El mensaje descriptivo del tipo de problema
	 */
	TipoProblemaDAO(String descripcion)
	{
		this.descripcion = descripcion;
	}

	/**
	 * Metodo que devuelve el mensaje descriptivo del tipo de problema
	 *
	 * @return descripcion
	 */
	public String getDescripcion()
	{
		return this.descripcion;
	}
}