package practica2eval.dao;

import java.util.Date;

import org.hibernate.exception.ConstraintViolationException;

import practica2eval.dao.exception.ExcepcionDAO;
import practica2eval.dao.exception.MensajeError;
import practica2eval.dao.exception.TipoProblemaDAO;
import practica2eval.model.Cliente;

public class ClienteDAO extends DAO
{
	public void insertarCliente(Cliente cliente)
	{
		abrirSesion();

		try
		{
			session.save(cliente);
			cerrarSesion();
		}
		catch (ConstraintViolationException e)
		{
			throw new ExcepcionDAO(MensajeError.getMensaje(TipoProblemaDAO.ERROR_REGISTRO_DUPLICADO));
		}

	}

	public void borrarCliente(String dni)
	{
		Cliente cliente = buscarCliente(dni);

		abrirSesion();

		try
		{
			session.delete(cliente);

			cerrarSesion();
		}
		catch (NullPointerException e)
		{
			throw new ExcepcionDAO(MensajeError.getMensaje(TipoProblemaDAO.ERROR_REGISTRO_NULO_O_INEXISTENTE));
		}

	}

	public Cliente buscarCliente(String dni)
	{
		abrirSesion();

		Cliente cliente = null;

		cliente = session.bySimpleNaturalId(Cliente.class).load(dni);

		if(cliente == null)
		{
			throw new ExcepcionDAO(MensajeError.getMensaje(TipoProblemaDAO.ERROR_REGISTRO_NULO_O_INEXISTENTE));
		}

		cerrarSesion();
		return cliente;
	}

	public void modificarCliente(String dni, Cliente clienteNuevo)
	{
		Cliente cliente = buscarCliente(dni);

		abrirSesion();

		clienteNuevo.setIdCliente(cliente.getIdCliente());
		clienteNuevo.setDNI(cliente.getDNI());
		clienteNuevo.setFechaAlta(new Date());
		session.evict(cliente);

		try
		{
			session.update(clienteNuevo);

			cerrarSesion();
		}
		catch (ConstraintViolationException e)
		{
			throw new ExcepcionDAO(MensajeError.getMensaje(TipoProblemaDAO.ERROR_REGISTRO_DUPLICADO));
		}
		catch (NullPointerException e)
		{
			throw new ExcepcionDAO(MensajeError.getMensaje(TipoProblemaDAO.ERROR_REGISTRO_NULO_O_INEXISTENTE));
		}

	}
}