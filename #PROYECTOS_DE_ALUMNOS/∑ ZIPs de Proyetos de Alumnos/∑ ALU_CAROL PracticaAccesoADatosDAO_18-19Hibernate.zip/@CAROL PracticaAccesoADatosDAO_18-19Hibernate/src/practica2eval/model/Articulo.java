package practica2eval.model;

import java.io.Serializable;
import java.math.BigDecimal;
//import java.util.Objects;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.*;

import org.hibernate.annotations.NaturalId;

/*
 * Un art�culo contiene los siguientes datos obligatorios:
 * un identificador num�rico idArticulo (generado por la base de datos),
 * un c�digo �nico (de longitud m�xima de 25 caracteres),
 * un nombre (m�ximo 40 caracteres) y
 * un precio de venta al p�blico (16 d�gitos, de los cuales
 * 3 pertenecen a los decimales).
 * Opcionalmente podr� tener una descripci�n (m�ximo 200 caracteres).
 *
 * Se entiende que un art�culo puede pertenecer a m�s de un pedido.
 *
 * No se podr�n eliminar art�culos si pertenecen a una o m�s
 * l�neas de pedido.
 */

@Entity
@Table(name = "articulo")
public class Articulo implements Serializable
{
	/**
	 *
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int idArticulo;

	@NaturalId
	@Column(name = "codigo", length = 25, nullable = false, unique = true)
	private String codigo;

	@Column(name = "nombre", length = 40, nullable = false)
	private String nombre;

	@Column(name = "pvp", length = 16, nullable = false)
	private BigDecimal precio;

	@Column(name = "descripcion", length = 200)
	private String descripcion;

	@OneToMany(mappedBy = "pedido", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	private Set<LineaPedido> hsLineaPedido = new HashSet<>();

	public Articulo()
	{

	}

	public Articulo(String cod, String nom, BigDecimal pvp)
	{
		codigo = cod;
		nombre = nom;
		precio = pvp;
		descripcion = "";
	}

	public Articulo(String cod, String nom, BigDecimal pvp, String desc)
	{
		codigo = cod;
		nombre = nom;
		precio = pvp;
		descripcion = desc;
	}
/*
	@Override
	public boolean equals(Object o)
	{
		if ( this == o ) {
			return true;
		}
		if ( o == null || getClass() != o.getClass() ) {
			return false;
		}
		Articulo that = (Articulo) o;
		return Objects.equals( this.getIdArticulo(), that.getIdArticulo() );
	}

	@Override
	public int hashCode()
	{
		return Objects.hash(this.getIdArticulo());
	}
*/
	public int getIdArticulo()
	{
		return idArticulo;
	}

	public void setIdArticulo(int idArticulo)
	{
		this.idArticulo = idArticulo;
	}

	public String getCodigo()
	{
		return codigo;
	}

	public void setCodigo(String codigo)
	{
		this.codigo = codigo;
	}

	public String getNombre()
	{
		return nombre;
	}

	public void setNombre(String nombre)
	{
		this.nombre = nombre;
	}

	public BigDecimal getPrecio()
	{
		return precio;
	}

	public void setPrecio(BigDecimal precio)
	{
		this.precio = precio;
	}

	public String getDescripcion()
	{
		return descripcion;
	}

	public void setDescripcion(String descripcion)
	{
		this.descripcion = descripcion;
	}

	public void anadirLineaPedido(LineaPedido lp)
	{
		hsLineaPedido.add(lp);
		lp.setArticulo(this);;
	}
}
