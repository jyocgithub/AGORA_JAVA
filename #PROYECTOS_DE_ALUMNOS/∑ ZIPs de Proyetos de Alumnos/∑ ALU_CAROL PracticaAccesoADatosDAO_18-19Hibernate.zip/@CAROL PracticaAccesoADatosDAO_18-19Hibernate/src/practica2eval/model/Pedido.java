package practica2eval.model;

import java.io.Serializable;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

//import java.util.Objects;
import javax.persistence.*;
import org.hibernate.annotations.NaturalId;

/*
 * Los datos obligatorios de un pedido son:
 * n�mero de pedido (�nico y generado por la base de datos),
 * c�digo de pedido (�nico, con longitud m�xima de 40 caracteres)
 * y fecha de pedido (incluyendo hora y minutos).
 *
 * Se entiende que un pedido (que ser� siempre de un cliente)
 * estar� formado por un conjunto de l�neas de pedido
 * (art�culos, cantidad y pvp unitario)
 *
 * Se entiende que un art�culo puede pertenecer a m�s de un pedido.
 *
 * Si un pedido se elimina, se eliminar�n todas las l�neas de pedido
 * asociadas al pedido.
 */

@Entity
@Table(name = "pedido")
public class Pedido implements Serializable
{
	/**
	 *
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int numeroPedido;

	@NaturalId
	@Column(name = "codigopedido", length = 40, nullable = false, unique = true)
	private String codigoPedido;

	@Column(name = "fecha", nullable = false)//incluyendo hora y minutos????????
	private Date fechaPedido;

	@ManyToOne
	@JoinColumn(name="idCliente")
	private Cliente cliente;

	@OneToMany(mappedBy = "pedido", cascade = CascadeType.ALL, fetch = FetchType.EAGER)
	private Set<LineaPedido> hsLineaPedido = new HashSet<>();

	public int getNumeroPedido()
	{
		return numeroPedido;
	}

	public void setNumeroPedido(int numeroPedido)
	{
		this.numeroPedido = numeroPedido;
	}

	public Set<LineaPedido> getHsLineaPedido()
	{
		return hsLineaPedido;
	}

	public void setHsLineaPedido(Set<LineaPedido> hsLineaPedido)
	{
		this.hsLineaPedido = hsLineaPedido;
	}

	public Pedido()
	{

	}

	public Pedido(String cod, Date fecha)
	{
		codigoPedido = cod;
		fechaPedido = fecha;
	}
/*
	@Override
	public boolean equals(Object o)
	{
		if ( this == o ) {
			return true;
		}
		if ( o == null || getClass() != o.getClass() ) {
			return false;
		}
		Pedido that = (Pedido) o;
		return Objects.equals( this.getNumPedido(), that.getNumPedido() );
	}

	@Override
	public int hashCode()
	{
		return Objects.hash(this.getNumPedido());
	}
*/
	public Cliente getCliente()
	{
		return cliente;
	}

	public void setCliente(Cliente cliente)
	{
		this.cliente = cliente;
	}

	public int getNumPedido()
	{
		return numeroPedido;
	}

	public void setNumPedido(int numPedido)
	{
		this.numeroPedido = numPedido;
	}

	public String getCodigoPedido()
	{
		return codigoPedido;
	}

	public void setCodigoPedido(String codigoPedido)
	{
		this.codigoPedido = codigoPedido;
	}

	public Date getFechaPedido()
	{
		return fechaPedido;
	}

	public void setFechaPedido(Date fechaPedido)
	{
		this.fechaPedido = fechaPedido;
	}

	public void anadirLineaPedido(LineaPedido lp)
	{
		hsLineaPedido.add(lp);
		lp.setPedido(this);
	}
}
