package PRAC1_ex2;

/**
 * Class Tank, describes a tank of water. 
 * 
 * @author Yasmine Lamliki
 * @version 1.0
 *
 */
public class Tank {
	/**
	 * Atribute with the name of the tank
	 */
	private String name;

	/**
	 * Atribute with the description of the tank
	 */
	private String description;

	/**
	 * Atribute with the image to bw drown as a tank
	 */
	private String imageBackground;

	/**
	 * Atribute with the length of the tank, in meters
	 */
	private double length;

	/**
	 * Atribute with the height of the tank, in meters
	 */
	private double height;

	/**
	 * Atribute with the width of the tank, in meters
	 */
	private double width;

	/**
	 * Atribute with the temperature of the water in the tank, in Celsius grades
	 */
	private double temperature;

	/**
	 * Atribute with the PH of the water in the tank.
	 */
	private int ph;

	/**
	 * Constructor wihout poarameters.
	 * Takes some default values for each attribute
	 *  
	 * @throws Exception (some conditions of
	 */
	public Tank() throws Exception {
		this("Default", "Tank Default", 50.25, 10.55, 100.232, "./", 15, 7);
	}

	/**
	 * Constructor with parameters for every attribute.
	 * 
	 * @param name name given to the tank	
	 * @param description a brief description of the tank
	 * @param length lenght of the tank, messured in meters
	 * @param height height of the tank, messured in meters
	 * @param width width of the tank, messured in meters
	 * @param imageBackground an image for draw the bottom of the tank
	 * @param temperature  width of the tank, messured in meters
	 * @param ph width of the tank, messured in meters
	 * @throws Exception sended from a validation of some setter
	 */
	public Tank(String name, String description, double length, double height, double width, String imageBackground, double temperature, int ph) throws Exception {
		setName(name);
		setDescription(description);
		setImageBackground(imageBackground);
		setTemperature(temperature);
		setLength(length);
		setHeight(height);
		setWidth(width);
		setPh(ph);
	}

	/**
	 * Getter for name attribute
	 * @return the value of the name attribute
	 */
	public String getName() {
		return name;
	}

	/**
	 * Setter for Name attribute
	 * @param name  the value of the name 
	 * @throws Exception if the length of the name exceeds of 40 
	 */
	public void setName(String name) throws Exception {
		// we are not going to accept names with more than 40 chars
		if (name.length() > 40) {
			throw new Exception("[ERROR] Name cannot be longer than 40 characters!!");
		}
		this.name = name;
	}

	/**
	 * Getter for Description attribute
	 * @return the value of the Description
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * Getter for ImageBackground attribute
	 * @return the value of the ImageBackground 
	 */
	public String getImageBackground() {
		return imageBackground;
	}

	/**
	 * Getter for Length attribute
	 * @return the value of the Length 
	 */
	public double getLength() {
		return length;
	}

	/**
	 * Getter for Height attribute
	 * @return the value of the Height 
	 */
	public double getHeight() {
		return height;
	}

	/**
	 * Getter for Width attribute
	 * @return the value of the Width 
	 */
	public double getWidth() {
		return width;
	}

	/**
	 * Getter for Temperature attribute
	 * @return the value of the Temperature 
	 */
	public double getTemperature() {
		return temperature;
	}

	/**
	 * Getter for PH attribute
	 * @return the value of the PH 
	 */
	public int getPh() {
		return ph;
	}

	/**
	 * Setter for description attribute
	 * @param description   the value of the description attribute
	 */
	public void setDescription(String description) {
		this.description = description;
	}

	/**
	 * Setter for imageBackground attribute
	 * @param imageBackground   the value of the imageBackground attribute
	 */
	public void setImageBackground(String imageBackground) {
		this.imageBackground = imageBackground;
	}

	/**
	 * Setter for temperature attribute
	 * @param temperature   the value of the temperature attribute
	 */
	public void setTemperature(double temperature) {
		this.temperature = temperature;
	}

	/**
	 * Setter for length attribute
	 * @param length   the value of the length attribute
	 * @throws Exception if the length of the tank is lower than 0.1 
	 */
	public void setLength(double length) throws Exception {
		// we are not going to accept length lower than 0.1
		if (length < 0.1) {
			throw new Exception("[ERROR] XX cannot be less than 0.1 cm.!!");
		}
		this.length = length;
	}

	/**
	 * Setter for height attribute
	 * @param height   the value of the height attribute
	 * @throws Exception if the height of the tank is lower than 0.1 
	 */
	public void setHeight(double height) throws Exception {
		// we are not going to accept length lower than 0.1
		if (height < 0.1) {
			throw new Exception("[ERROR] XX cannot be less than 0.1 cm.!!");
		}
		this.height = height;
	}

	/**
	 * Setter for width attribute
	 * @param width   the value of the width attribute
	 * @throws Exception if the width of the tank is lower than 0.1 
	 */
	public void setWidth(double width) throws Exception {
		// we are not going to accept length lower than 0.1
		if (width < 0.1) {
			throw new Exception("[ERROR] XX cannot be less than 0.1 cm.!!");
		}
		this.width = width;
	}

	/**
	 * Setter for ph attribute
	 * @param ph   the value of the PH attribute
	 * @throws Exception if the ph of the water is lower than 0 or higher than 14
	 */
	public void setPh(int ph) throws Exception {
		// we are not going to accept length lower than 0.1
		if (ph > 14 || ph < 0) {
			throw new Exception("[ERROR] PH must be a value between 0 and 14!!");
		}
		this.ph = ph;
	}

}
