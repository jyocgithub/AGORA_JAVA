package PRAC3_ex3;

public enum AnimalStatus {
	HEALTHY, 
	SICK, 
	DEAD;
}
