package PRAC3_ex3;

public interface Movable {

	final int TANK_PANE_WIDTH = 404;
	final int TANK_PANE_HEIGHT = 364;

	void moveLeft();

	void moveright();

	void moveup();

	void movedown();

	Collision collideWithTank();

	void update() throws AnimalException ;

	double getSpeed();

	void setSpeed(double speed) throws MovableException;

	double getThresholdReverse();

	void setThresholdReverse(double thresholdReverse) throws MovableException;
	
	boolean isFacingRight();
	
	void reverse();

}
