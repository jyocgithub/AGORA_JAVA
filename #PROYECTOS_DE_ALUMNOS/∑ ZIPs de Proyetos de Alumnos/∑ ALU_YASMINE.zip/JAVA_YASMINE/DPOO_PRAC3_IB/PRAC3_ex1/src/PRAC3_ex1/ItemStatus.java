package PRAC3_ex1;

public enum ItemStatus {
	HEALTHY, 
	SICK, 
	DEAD;
}
