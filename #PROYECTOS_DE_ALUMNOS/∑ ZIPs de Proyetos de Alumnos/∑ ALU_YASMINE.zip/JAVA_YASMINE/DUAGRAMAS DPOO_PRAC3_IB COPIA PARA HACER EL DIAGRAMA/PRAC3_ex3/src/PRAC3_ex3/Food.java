package PRAC3_ex3;

public class Food  extends Item implements Movable{
	
	
	private double speed;
	private int energy;
	private boolean eaten;
	
	public Food(double xCoord,double yCoord,double length,double height, int   energy , Tank tank) throws MovableException,  Exception {
		super(xCoord, yCoord, "./images/food/seed.png", length, height, tank);
		setEnergy(energy);
		setSpeed(1);
	}
	
	
	public boolean isEaten() {
		return eaten;
	}

	public void eaten() {
		this.eaten = true;
	}

	public int getEnergy() {
		return energy;
	}

	public void setEnergy(int energy) throws Exception {
		if(energy<1 || energy>10) {
			throw new Exception("[ERROR] Food cannot be less than 1 either greater than 10!!");
		}
		this.energy = energy;
	}


	public double getSpeed() {
		return speed;
	}

	public void setSpeed(double speed) throws MovableException  {
		if(speed < 0) {
			throw new MovableException(MovableException.MSG_ERR_SPEED_VALUE);
		}
		this.speed = speed;
	}

	private void sink()  {
		if(collideWithTank()== Collision.NO_COLLISION) {
			movedown();
		}
	}

	@Override
	public void moveLeft() {
	}


	@Override
	public void    moveright() {
	}


	@Override
	public void moveup() {
	}


	@Override
	public void movedown() {
		setYCoord(getYCoord() + speed);
		// y ++
		// TODO must go down
	}


	@Override
	public Collision collideWithTank() {
	
		if (getYCoord() + getHeight() > getTank().getHeight() - 20) {
			return Collision.BOTTOM;
		}

		return Collision.NO_COLLISION;
	}

	@Override
	public void update() {
		
		sink();
	}


	@Override
	public double getThresholdReverse() {
		return 0;
	}


	@Override
	public void setThresholdReverse(double thresholdReverse) throws MovableException {
	}


	@Override
	public boolean isFacingRight() {
		return false;
	}


	@Override
	public void reverse() {
	}

}
