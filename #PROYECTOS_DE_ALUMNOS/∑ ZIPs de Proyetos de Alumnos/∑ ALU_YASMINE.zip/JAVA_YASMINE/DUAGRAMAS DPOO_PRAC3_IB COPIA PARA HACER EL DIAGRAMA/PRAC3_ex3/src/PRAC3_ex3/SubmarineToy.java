package PRAC3_ex3;

public class SubmarineToy extends Item implements Movable {

	private double speed;
	private double thresholdReverse;
	private boolean facingRight;
	private int balanceMove = 0;
	private final int TURN_BALANCE_MOVE = 100;

	public SubmarineToy(double xCoord, double yCoord, double length, double height, Tank tank) throws Exception {
		super(xCoord, yCoord, "./images/submarine/submarine.png", length, height, tank);

		setSpeed(1);
		setThresholdReverse(0.0003);
		setFacingRight(true);
	}

	public boolean isFacingRight() {
		return facingRight;
	}

	public void setFacingRight(boolean facingRight) {
		this.facingRight = facingRight;
	}

	public double getSpeed() {
		return speed;
	}

	public void setSpeed(double speed) throws MovableException {
		if (speed < 0) {
			throw new MovableException(MovableException.MSG_ERR_SPEED_VALUE);
		}
		this.speed = speed;
	}

	public double getThresholdReverse() {
		return thresholdReverse;
	}

	public void setThresholdReverse(double thresholdReverse) throws MovableException {
		if (thresholdReverse < 0 || thresholdReverse > 1) {
			throw new MovableException(MovableException.MSG_ERR_THRESHOLD_VALUE);
		}
		this.thresholdReverse = thresholdReverse;
	}

	public void reverse() {
		setFacingRight(!this.facingRight);
	}

	@Override
	public Collision collideWithTank() {
		if (facingRight) {
			if (getXCoord() + getLength() > getTank().getWidth() - 3) {
				return Collision.LEFT;
			}
		} else {
			if (getXCoord() < 3) {
				return Collision.LEFT;
			}
		}
		if (getYCoord() + getHeight() > getTank().getHeight() - 45) {
			return Collision.BOTTOM;
		}
		if (getYCoord() < 5) {
			return Collision.TOP;
		}
		return Collision.NO_COLLISION;
	}

	@Override
	public void moveLeft() {
		// x--
		setXCoord(getXCoord() - speed);
	}

	@Override
	public void moveright() {
		// X++
		setXCoord(getXCoord() + speed);
	}

	@Override
	public void moveup() {
		// y--
		setYCoord(getYCoord() - speed);
		// TODO must go up
	}

	@Override
	public void movedown() {
		setYCoord(getYCoord() + speed);
		// y ++
		// TODO must go down
	}

	@Override
	public void update() {
		move();
	}

	private void move() {

		// check if there's a collision
		Collision collision = collideWithTank();

		if (balanceMove > 0) {
			movedown();
			balanceMove--;
		}
		if (balanceMove < 0) {
			moveup();
			balanceMove++;
		}
		if (balanceMove == 0) {
			if (collision == Collision.LEFT || collision == Collision.RIGHT) {
				setFacingRight(!facingRight);
			} else if (collision == Collision.TOP) {
				this.balanceMove = TURN_BALANCE_MOVE;
			} else if (collision == Collision.BOTTOM) {
				this.balanceMove = -TURN_BALANCE_MOVE;
			} else {
				float decision = (float) Math.random();
				if (decision<thresholdReverse) {
					facingRight =! facingRight;
				}else {
					decision = (float) Math.random();
					if(decision<0.48) {
						movedown();
					}else {
						moveup();
					}
				}
				
			}

		}
		
		// TODO What if theres collision and not balancemove == 0 ????

	}
}
