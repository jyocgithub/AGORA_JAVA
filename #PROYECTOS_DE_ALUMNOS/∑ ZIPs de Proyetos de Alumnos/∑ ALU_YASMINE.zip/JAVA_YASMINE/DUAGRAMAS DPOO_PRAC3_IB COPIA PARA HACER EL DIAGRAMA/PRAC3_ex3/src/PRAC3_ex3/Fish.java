package PRAC3_ex3;

public class Fish extends Animal {

	private Color color;

	protected Fish(double xCoord, double yCoord, String    spriteImage, double length, double  height, Gender gender,
			int age, double speed, double requiredFoodQuantity, float thresholdReverse, AnimalStatus     status, int     energy,
			Color color, Tank tank) throws MovableException, ItemException {
		super(xCoord, yCoord, spriteImage, length, height, gender, age, speed, requiredFoodQuantity, thresholdReverse,
				energy, tank);
		this.color = color;

	}

	public Color getColor() {
		return color;
	}

	public void    setColor(Color color) {
		this.color = color;
	}

	public void update() throws AnimalException {
		swim();
		eat();
	}

	public void swim() {

		Collision collision = collideWithTank();

		if (getStatus() == AnimalStatus.DEAD) {
			// TODO a fich collision with botton is really near the bottom ?
			if (collision != Collision.BOTTOM) {
				movedown();
			}
		} else {
			if (collision == Collision.LEFT || collision == Collision.RIGHT) {
				setFacingRight(!isFacingRight());
			} else if (collision != Collision.TOP) {
				movedown();
			} else if (collision != Collision.BOTTOM) {
				movedown();
			} else {
				float decision = (float) Math.random();
				if (decision < getThresholdReverse()) {
					setFacingRight(!isFacingRight());
				} else {
					decision = (float) Math.random();
					if (decision >= 0.9) {
						movedown();
					} else if (decision >= 0.8 && decision < 0.9) {
						moveup();
					} else {
						if (isFacingRight()) {
							moveright();
						} else {
							moveLeft();
						}
					}
				}

			}
		}

	}
	@Override
	public String toString() {
		StringBuilder str = new StringBuilder("(" + getXCoord() + ",  " + getYCoord() + ") ");

		if (isFacingRight()) {
			str.append(getId() + "R ");
		} else {
			str.append(getId() + "L ");
		}
		if (getGender()== Gender.FEMALE) {
			str.append(getId() + "F : ");
		} else {
			str.append(getId() + "M : ");
		}
		str.append(color);
		return str.toString();
	}
	@Override
	public int getOxygenConsumption() {
		return 0;
	}

	@Override
	public void breathe() {
	}
	
}
