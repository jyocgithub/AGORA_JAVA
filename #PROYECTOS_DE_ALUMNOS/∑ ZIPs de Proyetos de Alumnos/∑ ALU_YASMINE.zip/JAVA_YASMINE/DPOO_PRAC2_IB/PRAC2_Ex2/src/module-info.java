module PRAC2_Ex1 {
}