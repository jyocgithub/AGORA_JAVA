package PRAC2_ex1;

public class Item {
	private String id;
	private double xCoord;
	private double yCoord;
	private String spriteImage;
	private double length;
	private double height;
	private int energy;
	private static int numeroSecuencial = -1;
	private Tank tank;
	private ItemStatus status;

	public Item(double xCoord, double yCoord, String spriteImage, double length, double height, int energy, Tank tank) throws Exception {
		setLocation( xCoord, yCoord);
		setLength(length);
		setHeight(height);
		this.energy = energy;
		setSpriteImage ( spriteImage);
		setTank (tank);
		numeroSecuencial++;
		setId("I" + numeroSecuencial);

	}

	public void setLocation(double xCoord, double yCoord) {
		this.xCoord = xCoord;
		this.yCoord = yCoord;

	}

	public double getXCoord() {
		return xCoord;
	}

	public double getYCoord() {
		return yCoord;
	}

	public double getLength() {
		return length;
	}

	public void setLength(double length) throws Exception {
		if (length <= 0) {
			throw new Exception("[ERROR]: Item's length cannot negative either 0!!");
		}
		this.length = length;
	}

	public double getHeight() {

		return height;
	}

	public void setHeight(double height) throws Exception {
		if (height <= 0) {
			throw new Exception("[ERROR]: Item's height cannot negative either 0!!");
		}
		this.height = height;
	}

	public String getSpriteImage() {
		return spriteImage;
	}

	public void setSpriteImage(String spriteImage) {
		this.spriteImage = spriteImage;
	}

	public String getId() {
		return id;
	}

	private void setId(String id) {
		this.id = id;
	}

	public ItemStatus getStatus() {
		return status;
	}

	private void setStatus(ItemStatus status) {
		this.status = status;
	}

	public int getEnergy() {
		return energy;
	}

	public void setEnergy(int energy) throws Exception {
		if (energy < 0 || energy > 100) {
			throw new Exception("[ERROR]: Item's energy cannot negative either greather than 100!!");
		}
		if (this.energy == 0) {
			throw new Exception("[ERROR] Item's energy is zero. This value cannot be modified!!");
		}

		this.energy = energy;

		if (energy == 0) {
			setStatus(ItemStatus.DEAD);
		} else if (energy < 25) {
			setStatus(ItemStatus.SICK);
		} else {
			setStatus(ItemStatus.HEALTHY);
		}

	}

	public void incEnergy(int energy) throws Exception {
		if (this.energy == 0) {
			throw new Exception("[ERROR] Item's energy is zero. This value cannot be modified!!");
		}

		this.energy = this.energy + energy;
		if (this.energy > 100) {
			this.energy = 100;
			throw new Exception("[Warning]: Item's energy has been assigned to 100");
		}

	}

	public void decEnergy(int energy) throws Exception {
		if (this.energy == 0) {
			throw new Exception("[ERROR] Item's energy is zero. This value cannot be modified!!");
		}

		this.energy = this.energy - energy;
		if (this.energy < 0) {
			this.energy = 0;
			throw new Exception("[Warning]: Item's energy has been assigned to 0");
		}

	}

	public boolean isDead() {
		if (energy == 0) {
			return true;
		}
		return false;
		
		// return energy==0;
 	
	}

	public Tank getTank() {
		return tank;
	}

	public void setTank(Tank tank) {
		this.tank = tank;
		if(tank!=null) {
			if (! tank.contains(this)) {
					tank.addItem(this);
			}	
		}
	}
	
	@Override
	public String toString() {
		String res = "";
		res = res + "(" + xCoord + "," + yCoord+ ") ";
		res = res + id + " ";
		res = res + energy + " ";
		res = res + status + " ";
		if(tank == null) {
			res = res + " No Tank";
		}else {
			res = res + tank.getDescription() + " ";
		}
		
		return res;
	}



}
