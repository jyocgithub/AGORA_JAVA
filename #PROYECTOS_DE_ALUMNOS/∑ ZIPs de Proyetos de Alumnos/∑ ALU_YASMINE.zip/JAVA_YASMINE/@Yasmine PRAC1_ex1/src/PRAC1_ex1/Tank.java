package PRAC1_ex1;

//Class Tank, describes a tank of water. 
public class Tank {

	// Atribute with the name of the tank
	private String name;

	// Atribute with the description of the tank
	private String description;

	// Atribute with the image to bw drown as a tank
	private String imageBackground;

	// Atribute with the length of the tank, in meters
	private double length;

	// Atribute with the height of the tank, in meters
	private double height;

	// Atribute with the width of the tank, in meters
	private double width;

	// Atribute with the temperature of the water in the tank, in Celsius grades
	private double temperature;

	// Atribute with the PH of the water in the tank.
	private int ph;

	// Constructor wihout poarameters.
	// Give some default values for each attribute
	public Tank() throws Exception {
		this("Default", "Tank Default", 50.25, 10.55, 100.232, "./", 15, 7);
	}

	// Constructor with parameters for every attribute. 
	// Uses calls to setters methods for better coherence
	public Tank(String name, String description, double length, double height, double width, String imageBackground, double temperature, int ph) throws Exception {
		setName(name);
		setDescription(description);
		setImageBackground(imageBackground);
		setTemperature(temperature);
		setLength(length);
		setHeight(height);
		setWidth(width);
		setPh(ph);
	}

	// Getter for name attribute
	public String getName() {
		return name;
	}

	// Setter for Name attribute
	public void setName(String name) throws Exception {
		// we are not going to accept names with more than 40 chars
		if (name.length() > 40) {
			throw new Exception("[ERROR] Name cannot be longer than 40 characters!!");
		}
		this.name = name;
	}

	// Getter for Description attribute
	public String getDescription() {
		return description;
	}

	// Getter for ImageBackground attribute
	public String getImageBackground() {
		return imageBackground;
	}

	// Getter for Length attribute
	public double getLength() {
		return length;
	}

	// Getter for Height attribute
	public double getHeight() {
		return height;
	}

	// Getter for Width attribute
	public double getWidth() {
		return width;
	}

	// Getter for Temperature attribute
	public double getTemperature() {
		return temperature;
	}

	// Getter for PH attribute
	public int getPh() {
		return ph;
	}

	// Setter for description attribute
	public void setDescription(String description) {
		this.description = description;
	}

	// Setter for imageBackground attribute
	public void setImageBackground(String imageBackground) {
		this.imageBackground = imageBackground;
	}

	// Setter for temperature attribute
	public void setTemperature(double temperature) {
		this.temperature = temperature;
	}

	// Setter for length attribute
	public boolean setLength(double length) {
		if (length < 0.1) {
			return false;
		}
		this.length = length;
		return true;
	}

	// Setter for height attribute
	public boolean setHeight(double height) {
		if (height < 0.1) {
			return false;
		}
		this.height = height;
		return true;
	}

	// Setter for width attribute
	public boolean setWidth(double width) {
		if (width < 0.1) {
			return false;
		}
		this.width = width;
		return true;
	}

	// Setter for ph attribute
	public boolean setPh(int ph) {
		if (ph > 14 || ph < 0) {
			return false;
		}
		this.ph = ph;
		return true;
	}

}
