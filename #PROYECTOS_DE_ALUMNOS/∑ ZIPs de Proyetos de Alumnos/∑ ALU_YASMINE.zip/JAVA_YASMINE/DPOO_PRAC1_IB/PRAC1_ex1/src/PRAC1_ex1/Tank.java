package PRAC1_ex1;

public class Tank {

	private String name, description, imageBackground;
	private double length, height, width, temperature;
	private int ph;
	
	public Tank() throws Exception {
		name = "Default";
		description = "Tank Default";
		imageBackground = "./";
		temperature = 15;
		length = 50.25;
		height = 10.55;
		width = 100.232;
		ph = 7;	
	}

	public String getName() {
		return name;
	}

	public void setName(String nameNew) throws Exception{
		if(nameNew.length()>40) {
			throw new Exception("[ERROR] Name cannot be longer than 40 characters!!");
		}
		name = nameNew;
	}
	
}
