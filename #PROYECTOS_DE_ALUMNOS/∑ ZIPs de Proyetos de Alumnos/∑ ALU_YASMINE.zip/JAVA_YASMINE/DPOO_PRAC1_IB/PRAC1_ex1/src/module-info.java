module PRAC1_ex1 {
}