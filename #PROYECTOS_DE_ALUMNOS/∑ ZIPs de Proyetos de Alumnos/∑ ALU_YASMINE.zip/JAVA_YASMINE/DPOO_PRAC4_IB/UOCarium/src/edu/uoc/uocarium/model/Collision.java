package edu.uoc.uocarium.model;

public enum Collision {
	LEFT,
	RIGHT,
	TOP,
	BOTTOM,
	NO_COLLISION;
}
