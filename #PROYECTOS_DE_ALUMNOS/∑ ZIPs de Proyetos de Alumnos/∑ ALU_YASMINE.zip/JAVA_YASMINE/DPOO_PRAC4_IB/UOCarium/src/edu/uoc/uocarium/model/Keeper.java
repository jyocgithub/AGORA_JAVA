package edu.uoc.uocarium.model;

import java.util.ArrayList;
import java.util.List;

public class Keeper {
	private String id;
	private String name;
	private String surname;
	private List<Tank> tanks;
	
	private final int MAX_TANKS = 5;
	
	public Keeper(String id, String name, String surname) {
		super();
		this.id = id;
		this.name = name;
		this.surname = surname;
		tanks = new ArrayList<>();
	}

	public void addTank(Tank tank) throws KeeperException {
		if(tanks.size()==5) {
			throw new KeeperException(KeeperException.MSG_ERR_KEEPER_NUMBER_TANKS);			
		}
		if(! tanks.contains(tank)) {
			tanks.add(tank);
		}
	}
	public String getId() {
		return id;
	}

	public void setId(String id) throws KeeperException {
		if(id==null) {
			throw new NullPointerException();
		}
		if(! id.startsWith("G")) {
			throw new KeeperException(KeeperException.MSG_ERR_KEEPER_INITIAL_NAME);			
		}
		if( id.length() != 5) {
			throw new KeeperException(KeeperException.MSG_ERR_KEEPER_SIZE_NAME);			
		}
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getSurname() {
		return surname;
	}

	public void setSurname(String surname) {
		this.surname = surname;
	}

	public List<Tank> getTanks() {
		return tanks;
	}

	public void setTanks(List<Tank> tanks) {
		this.tanks = tanks;
	}

	@Override
	public String toString() {
		String res = "[" + id + "]" + surname + "," + name + ":\n" ;
		for(Tank t : tanks) {
			res += "\t" + t.getName()+ "\n";
		}
		return res;
	}

	
	
	
	
	
}
