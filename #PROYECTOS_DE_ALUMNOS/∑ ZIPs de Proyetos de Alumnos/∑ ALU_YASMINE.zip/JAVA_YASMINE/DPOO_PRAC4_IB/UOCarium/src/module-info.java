/*
module UOCarium {
}
*/