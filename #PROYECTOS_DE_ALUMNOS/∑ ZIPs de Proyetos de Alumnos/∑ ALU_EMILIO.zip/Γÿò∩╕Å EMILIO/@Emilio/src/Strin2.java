import java.util.Scanner;
//Escribir un programa que pide al usuario una frase por teclado. Posteriormente el programa informa por consola de los siguientes datos:

//
//• Numero total de caracteres de la cadena
//
//• Numero total de espacios en blanco que tiene la cadena
//
//• La misma cadena pero toda en mayusculas
//
//• El carácter inicial de la cadena

//6.a.3. Escribir un programa que pida al usuario por teclado la hora en notación de 24 horas y que imprima en notación de 12; por ejemplo, si la entrada es 13:45, la salida será 1:45 pm. El programa debe solicitar al usuario que introduzca exactamente cinco caracteres para especiﬁcar una hora; por ejemplo, las 9 en punto se debe introducir así: 09:00
public class Strin2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String cadenas;
		Scanner sc = new Scanner(System.in);
		System.out.println("escribe la horas 24");
		cadenas = sc.nextLine();
		if (cadenas.length() > 5 && cadenas.length() < 5) {

			System.out.println("Error escriba bien la hora ");
		}
		String hora = cadenas.substring(0, 2);
		int i = Integer.parseInt(hora);
		if (i > 12) {
			int hora12;
			hora12 = i - 12;
			if (hora12 < 10) {
				System.out.println("0" + hora12 + ":" + cadenas.substring(3, 5));

			} else {
				System.out.println(hora12 + ":" + cadenas.substring(3, 5));

			}

		}

	}

}
