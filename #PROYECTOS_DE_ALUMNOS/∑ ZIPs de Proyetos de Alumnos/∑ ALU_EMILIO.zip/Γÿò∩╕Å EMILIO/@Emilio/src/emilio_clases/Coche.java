package emilio_clases;

public class Coche {   //CLASE 
     // ATRIBUTOS  
     
     private String marca;
     private double precio;

      
     // CONSTRUCTOR
     public Coche(String marca, int precio){ 
          this.marca = marca;
          this.precio = precio;   
     } 
     
     public Coche( int p){ 
          precio = p;   
     }  

     public Coche(){           // SOBRECARGA - 
     }  
     
     
     // METODOS
     public void rebajar(){
          precio = precio / 2;
     }
     
     public void rebajar(int cuanto){
          precio = precio -cuanto;
     }

     public String getMarca() {
          return marca;
     }

     public void setMarca(String marca) {
          this.marca = marca;
     }

     public double getPrecio() {
          return precio;
     }

     public void setPrecio(double precio) {
          this.precio = precio;
     }
     
}

