package emilio_clases;

public class Persona {

     private String nombre;
     private String dni;
     private int edad;

     public Persona(String nombre, String dni, int edad) {
          this.nombre = nombre;
          this.edad = edad;
          this.dni = dni;

     }

     public Persona() {


     }

     public String getNombre() {
          return nombre;
     }

     public void setNombre(String nombre) {
          this.nombre = nombre;
     }

     public String getDni() {
          return dni;
     }

     public void setDni(String dni) {
          this.dni = dni;
     }

     public int getEdad() {
          return edad;
     }

     public void setEdad(int edad) {
          this.edad = edad;
     }

     public boolean validardni() {
          boolean validardni = true;
          if (dni.length() != 9) {
               validardni = false;
          } else {
               char c = dni.charAt(7);

               if (c >= 'A' && c <= 'Z' ) {
                    validardni = true;
               } else {
                    validardni = false;

               }

          }
          return validardni;

     }
     public boolean mayorEdad(){
          boolean mayorEdad=true;
          if (edad<18)
          {
               mayorEdad=true;
          }else {
               mayorEdad=false;
          }
          return mayorEdad;
     }
    public boolean jubilado(){
             boolean jubilado=true;
          if (edad>65)
          {
               jubilado=true;
          }else {
              jubilado=false;
          }
          return jubilado;
     }
    
    
    public boolean jubilado(int jubilacion){
              boolean jubilado=true;
          if (edad>jubilacion)
          {
               jubilado=true;
          }else {
              jubilado=false;
          }
          return jubilado;
      
    }

    public int cuantoJubila(int jubilacion){
        int  cuantos;
         cuantos=jubilacion-edad;
         return cuantos;
    }
}
