package emilio_clases;

public class EmilioClases {

     public static void main(String[] args) {

          int x = 4;
          double p = 4.6;
     
          
          final double NUMERODEMESES = 12;
         
          Coche k = new Coche();  // OBJETOS o INSTANCIA
          
          Coche tre = new Coche();

     
          Coche coche1 = new Coche("SEAT", 10000);
          
          k.setPrecio(-1);
     
      Persona persona1 =new Persona();
      Persona  persona2 =new Persona("Luis", "09845456d",23); 
          System.out.println(persona1.getEdad()+" "+ persona1.getNombre());
          System.out.println(persona2.getEdad()+" "+ persona2.getNombre());
          System.out.println(persona2.validardni());
          System.out.println(persona2.jubilado(15));
          System.out.println("la persona le falta "+ persona2.cuantoJubila(64));
     }
     
}
