package emilio_clases;

/**
 * Crensurador
 *
 * @author ims
 */
public class Crensurador {

}
