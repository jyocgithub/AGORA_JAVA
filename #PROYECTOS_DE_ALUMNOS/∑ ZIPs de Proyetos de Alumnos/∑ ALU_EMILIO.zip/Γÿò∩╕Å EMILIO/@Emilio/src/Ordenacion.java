
public class Ordenacion {

	public static void main(String[] args) {

		int[] pepearray = { 56, 3, 5, 1201, 6, 376 };
		quicksortdeint(pepearray, 0, 5);

		for (int i = 0; i < pepearray.length; i++) {
			System.out.println(pepearray[i]);
		}

		String[] miarraydecurro = { "iuy", "aay", "pop" };
		burbujadeString(miarraydecurro);

	}

	public static void burbujadeint(int arrnum[]) {
		// BURBUJA CON ARRAY DE NUMEROS
		// --------------------------------------------
		// un bucle normal de recorrer el array , hasta i < arrnum.length
		for (int i = 0; i < arrnum.length; i++) {
			// un bucle normal de recorrer el array , PERO hasta i < arrnum.length -1
			for (int j = 0; j < arrnum.length - 1; j++) {

				// comparamos un elmento con el SIGUIENTE
				if (arrnum[j] > arrnum[j + 1]) {
					// si cumplen la condicion, se INTERCAMBIAN CON AYUDA DE UN AUXILIAR
					int aux = arrnum[j];
					arrnum[j] = arrnum[j + 1];
					arrnum[j + 1] = aux;
				}
			}
		}
	}

	public static void burbujadeString(String arrstr[]) {
		// BURBUJA CON STRINGS
		// --------------------------------------------
		for (int i = 0; i < arrstr.length; i++) {
			for (int j = 0; j < arrstr.length - 1; j++) {
				// AHORA COMPARAMOS CON COMPARETO......
				if (arrstr[j].compareToIgnoreCase(arrstr[j + 1]) > 0) {
					String aux = arrstr[j];
					arrstr[j] = arrstr[j + 1];
					arrstr[j + 1] = aux;
				}
			}
		}
	}

	public static void ejemplosdeburbujadeobjetos(String arrstr[]) {

		// BURBUJA CON ARRAY DE OBJETOS
		Alumno a = new Alumno("Pepe", 21);
		Alumno a2 = new Alumno("Victoria", 29);
		Alumno a3 = new Alumno("Luis", 45);
		Alumno a4 = new Alumno("Ana", 11);
		Alumno a5 = new Alumno("Carmen", 17);

		// CREAMOS EL ARRAY (DE ALUMNOS)
		Alumno[] miarray = new Alumno[5];
		miarray[0] = a;
		miarray[1] = a2;
		miarray[2] = a3;
		miarray[3] = a4;
		miarray[4] = a5;

		// ORDENANDO POR UN ATRIBUTO QUE SEA STRING (p.e. NOMBRE)
		for (int i = 0; i < miarray.length; i++) {
			for (int j = 0; j < miarray.length - 1; j++) {
				if (miarray[j].getNombre().compareToIgnoreCase(miarray[j + 1].getNombre()) > 0) {
					Alumno c = miarray[j];
					miarray[j] = miarray[j + 1];
					miarray[j + 1] = c;
				}
			}
		}

		// BURBUJA CON OBJETOS , ORDENANDO POR UN ATRIBUTO QUE SEA INT (p.e. EDAD)
		for (int i = 0; i < miarray.length; i++) {
			for (int j = 0; j < miarray.length - 1; j++) {
				if (miarray[j].getEdad() > miarray[j + 1].getEdad()) {
					Alumno c = miarray[j];
					miarray[j] = miarray[j + 1];
					miarray[j + 1] = c;
				}
			}
		}
	}

	// Cuando llamemos a este metodo, los valores de izq y de der
	// son los elementos de la primera posicion y de ultiuma posicoin
	// DE LA PARTE QUE QUERAMOS ORDENAR
	// Si es por ejemplo todo un array de 10 elementos,
	// el valor para izq es 0 y el valor para der es 9
	public static void quicksortdeint(int A[], int izq, int der) {
		int pivote = A[izq]; // tomamos primer elemento como pivote
		int i = izq; // i realiza la búsqueda de izquierda a derecha
		int j = der; // j realiza la búsqueda de derecha a izquierda
		int aux;
		while (i < j) { // mientras no se crucen las búsquedas
			while (A[i] <= pivote && i < j) {
				i++; // busca elemento mayor que pivote
			}
			while (A[j] > pivote) {
				j--; // busca elemento menor que pivote
			}
			if (i < j) { // si no se han cruzado
				aux = A[i]; // los intercambia
				A[i] = A[j];
				A[j] = aux;
			}
		}
		A[izq] = A[j]; // se coloca el pivote en su lugar de forma que tendremos
		A[j] = pivote; // los menores a su izquierda y los mayores a su derecha
		if (izq < j - 1) {
			quicksortdeint(A, izq, j - 1); // ordenamos subarray izquierdo
		}
		if (j + 1 < der) {
			quicksortdeint(A, j + 1, der); // ordenamos subarray derecho
		}
	}

	public static void quicksortdeString(String A[], int izq, int der) {
		String pivote = A[izq]; // tomamos primer elemento como pivote
		int i = izq; // i realiza la búsqueda de izquierda a derecha
		int j = der; // j realiza la búsqueda de derecha a izquierda
		String aux;
		while (i < j) { // mientras no se crucen las búsquedas
			while (A[i].compareToIgnoreCase(pivote) < 0 && i < j) {
				i++; // busca elemento mayor que pivote
			}
			while (A[j].compareToIgnoreCase(pivote) > 0) {
				j--; // busca elemento menor que pivote
			}
			if (i < j) { // si no se han cruzado
				aux = A[i]; // los intercambia
				A[i] = A[j];
				A[j] = aux;
			}
		}
		A[izq] = A[j]; // se coloca el pivote en su lugar de forma que tendremos
		A[j] = pivote; // los menores a su izquierda y los mayores a su derecha
		if (izq < j - 1) {
			quicksortdeString(A, izq, j - 1); // ordenamos subarray izquierdo
		}
		if (j + 1 < der) {
			quicksortdeString(A, j + 1, der); // ordenamos subarray derecho
		}
	}

}

class Alumno {
	private String nombre;
	private int edad;

	public Alumno(String nombre, int edad) {
		super();
		this.nombre = nombre;
		this.edad = edad;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public int getEdad() {
		return edad;
	}

	public void setEdad(int edad) {
		this.edad = edad;
	}

}