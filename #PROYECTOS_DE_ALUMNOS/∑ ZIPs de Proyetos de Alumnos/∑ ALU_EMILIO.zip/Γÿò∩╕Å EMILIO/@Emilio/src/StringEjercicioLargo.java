import java.util.Scanner;

public class StringEjercicioLargo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String nombre, apellido, apellido2, codigo, letra;
		Scanner sc = new Scanner(System.in);
		// .Escribir un programa que va a leer los nombres y
		// primer apellido de varias personas.
		//
		// Termina cuando el nombre de una persona es “FIN”.
		//
		// Para cada una de las persona genera un código con
		// la primera letra del nombre y las tres primeras del apellido.
		// Si dicho apellido tiene una longitud inferior a 3, se le pide
		// además al usuario el segundo apellido de la persona, y se usa
		// para el código cogiendo sus tres primeras letras. Si éste segundo
		// apellido también tiene una longitud inferior a 3, se genera el
		// código con la primera letra del nombre y el apellido completo que
		// sea más largo de los dos.

		do {
			System.out.println("Escribe un nombre ");
			nombre = sc.nextLine();
			System.out.println("Escribe primer apellido ");
			apellido = sc.nextLine();
			codigo = generarCodigo(nombre, apellido);
			if (apellido.length() < 3) {

				System.out.println("Escriba su segundo apellido ");
				apellido2 = sc.nextLine();
				codigo = generarCodigo(nombre, apellido2);

				if (apellido2.length() < 3) {
					letra = nombre.substring(0, 1);
					if (apellido.length() < apellido2.length()) {

						codigo = letra + apellido2;
					} else
						codigo = letra + apellido;

				}

			}

		} while (nombre.equalsIgnoreCase("fin"));

	}

	public static String generarCodigo(String nombre, String apellido) {
		String codigo;
		String letra = nombre.substring(0, 1);
		String apen = apellido.substring(0, 3);
		codigo = letra + apen;

		return codigo;

	}

}
