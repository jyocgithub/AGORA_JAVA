/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package emilioexa;

import java.util.*;

/**
 *
 * @author ims
 */
public class EmilioExa {

     /**
      * @param args the command line arguments
      */
     public static void main(String[] args) {
          char vehiculo;
          double precio;
          int diesel = 500, gasolina = 500, carburante, litros, billetes;
          boolean validarVeh = true, validarCar = true, validarL = true, haySuficiente;
          Scanner sc = new Scanner(System.in);

          do {


               do {
                    System.out.println("Que vehiculo es o quiere salir ?");
                    vehiculo = sc.nextLine().charAt(0);

                    validarVeh = validarVehiculo(vehiculo);
                    if (validarVeh == false) {
                         System.out.println("El vehiculo es incorrecto ponga otro ");
                    }
               } while (validarVeh == false);


               do {
                    System.out.println("Que carburante deseas 1.diesel o 2.gasolina");
                    carburante = sc.nextInt();
                    validarCar = validarCarburante(carburante);
                    if (validarCar == false) {
                         System.out.println("El carburante es incorrecto ponga otro ");
                    }
               } while (validarCar == false);


               do {
                    System.out.println("¿Cuantos litros quiere repostar");
                    haySuficiente = true;
                    litros = sc.nextInt();
                    validarL = validarLitros(litros);
                    if (validarL == false) {
                         System.out.println("la cantidad de litros es incorrecta vuelva a poner otra cantidad  ");
                    } else {
                         if (carburante == 1) {
                              if (litros > diesel) {
                                   haySuficiente = false;
                                   System.out.println("Insuficiencia de deposito");
                              }
                         } else if (carburante == 2) {
                              if (litros > gasolina) {
                                   haySuficiente = false;
                                   System.out.println("insuficiencia de deposito ");
                              }
                         }
                    }
                    if (haySuficiente == false) {
                         System.out.println("¿Quiere elegir otro vehiculo (V) o poner otra cantidad? (otra cosa) ");
                         sc.nextLine();
                         char opcion = sc.nextLine().charAt(0);
                         if (opcion == 'C') {
                              continue;
                         } else {
                              break;
                         }
                    }

               } while (validarL == false);


               if (haySuficiente == false) {
                    continue;
               }

               precio = devolverImporte(vehiculo, carburante, litros);

               if (precio > 10) {

                    System.out.println("Tiene que pagar " + precio + "€");
                    System.out.println("¿Desea pagarlo con tarjeto o en efectivo?");
                    
               } else {
                    System.out.println("tiene que pagar en efectivo" + precio + "€");
                    System.out.println("¿que billetes pagas");
                    int pagado = sc.nextInt();
                    devolucion(precio, pagado);
                   
               }


          } while (vehiculo !='S' && vehiculo != 's'     &&   gasolina != 0 && diesel!=0 );

     }

     public static boolean validarVehiculo(char vehiculo) {

          if (vehiculo == 'F' || vehiculo == 'f') {
               return true;
          } else if (vehiculo == 'C' || vehiculo == 'c') {
               return true;
          } else if (vehiculo == 'T' || vehiculo == 't') {
               return true;
          } else if (vehiculo == 'S' || vehiculo == 's') {
               return true;
          } else {
               return false;
          }


     }

     public static boolean validarCarburante(int carburante) {

          if (carburante == 1) {
               return true;
          } else if (carburante == 2) {
               return true;

          } else {
               return false;
          }
     }

     public static boolean validarLitros(int litros) {
          if (litros > 0 && litros < 100) {
               return true;
          } else
               return false;
     }

     public static double devolverImporte(char vehiculo, int carburante, int litros) {
          double precio = 0;
          double descuento = 0.10;
          int litrosRegal = 0;


          if (carburante == 1) {
               if (vehiculo == 'C' || vehiculo == 'F') {
                    precio = 1.40;
                    precio = precio * litros;
                    precio = precio - precio * descuento;

               } else {
                    precio = 1.40;
                    precio = precio * litros;

               }
          }

          if (carburante == 2) {
               precio = 1.30;
               if (litros > 50) {
                    litrosRegal = litros / 10;
                    litros = litros - litrosRegal;
               }

               precio = precio * litros;

          }
          return precio;

     }


     public static void devolucion(double precio, double pagado) {
          int bill20, bill50, bill10, bill5, mon1, mon2;
          double vuelta;
          vuelta = pagado - precio;   // vuelta es 48
          bill50 = (int) (vuelta / 50);
          vuelta = vuelta - (bill50 * 50);

          bill20 = (int) (vuelta / 20);
          vuelta = vuelta - (bill20 * 20);

          bill10 = (int) (vuelta / 10);
          vuelta = vuelta - (bill10 * 10);

          bill5 = (int) (vuelta / 5);
          vuelta = vuelta - (bill5 * 5);

          mon1 = (int) (vuelta / 1);
          vuelta = vuelta - (mon1 * 1);

          mon2 = (int) (vuelta / 2);
          vuelta = vuelta - (mon2 * 2);

          System.out.println("Billetes de cincuenta devueltos: " + bill50);
          System.out.println("Billetes de veinte devueltos: " + bill20);
          System.out.println("Billetes de diez devueltos: " + bill10);
          System.out.println("Billetes de cinco devueltos: " + bill5);
          System.out.println("Monedas de 1 euro  devueltos: " + mon1);
          System.out.println("Monedas de 2 euro  devueltos: " + mon2);
     }
}
