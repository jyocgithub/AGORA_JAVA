package examenenero;

import java.util.Scanner;

public class Examen {

	static Scanner sci = new Scanner(System.in);
	static Scanner scs = new Scanner(System.in);
	static int contadorvecesqueseharebajado = 0;
	static double recaudado = 0;

	public static void main(String[] args) {

		Trayecto[] lista = new Trayecto[10];
		char seguir = ' ';
		int contador = 0;
		String mail, or, de;
		int npla, pre;
		do {
			System.out.println("origen?");
			or = scs.nextLine();
			System.out.println("destino?");
			de = scs.nextLine();

			do {
				System.out.println("num plazas?");
				npla = sci.nextInt();
				if (npla < 1) {
					System.out.println("numero erroneo");
				}
			} while (npla < 1);

			boolean estabien;
			do {
				System.out.println("mail?");
				mail = scs.nextLine();
				estabien = mailValido(mail);
				if (estabien == false) {
					System.out.println("mail erroneo");
				}
			} while (estabien == false);

			System.out.println("precio?");
			pre = sci.nextInt();

			Trayecto t = new Trayecto(or, de, npla, mail, pre);
			lista[contador] = t;

			System.out.println("SEGUIR?");
			seguir = sci.nextLine().charAt(0);

		} while (seguir != 'S');

		int opcion;

		// MENU
		boolean vacio;
		do {
			System.out.println("1. buscar");
			System.out.println("2. rebajar");
			System.out.println("3. hacer reserva");
			System.out.println("4. recudado");

			opcion = sci.nextInt();
			switch (opcion) {

			case 1:
				buscarTrayectos(lista);
				break;
			case 2:
				if (contadorvecesqueseharebajado == 0) {
					rebajar(lista);
					contadorvecesqueseharebajado++;
				} else {
					System.out.println("ya se rebajo una vez ...... ");
				}
				break;
			case 3:
				hacerreserva(lista);

				break;
			case 4:
				System.out.println(recaudado);

				break;
			}

			vacio = arrayVacio(lista);
		} while (vacio = false);

	}

	public static String hacerreserva(Trayecto[] lista) {

		String codigo = "";

		System.out.println("num tray?");
		int tray = sci.nextInt();
		System.out.println("plazas a resevar?");
		int numplazas = sci.nextInt();

		for (int i = 0; i < lista.length; i++) {
			if (lista[i] != null) {

				if (lista[i].getNumerodetrayecto() == tray) {
					int loquehaylibre = lista[i].getPlazasofertadas();
					if (loquehaylibre < numplazas) {
						System.out.println("no hay tantas plazas");
					} else {
						lista[i].setPlazasofertadas(loquehaylibre - numplazas);
						// cada plaza reservada la aplicación se lleva un 10% del importe,
						if (contadorvecesqueseharebajado == 0) {
							double porcen = lista[i].getPrecioporplaza() * 0.10 * numplazas;
							recaudado += porcen;
						} else {
							double porcen = lista[i].getPrecioporplaza() * 0.05 * numplazas;
							recaudado += porcen;
						}

						codigo = lista[i].getOrigen().substring(0, 2) + lista[i].getDestino().substring(0, 2)
								+ lista[i].getNumerodetrayecto();
						if (lista[i].getPlazasofertadas() == 0) {
							lista[i] = null;
						}
					}
				}
			}
		}
		return codigo;

	}

	public static void rebajar(Trayecto[] lista) {

		for (int i = 0; i < lista.length; i++) {
			if (lista[i] != null) {

				if (lista[i].getPlazasofertadas() == 1) {
					double nuevo = lista[i].getPrecioporplaza() / 2;
					lista[i].setPrecioporplaza(nuevo);
				}
			}
		}

	}

	public static void buscarTrayectos(Trayecto[] lista) {
		Trayecto[] copia = new Trayecto[10];
		// crear nuevo array
		int contadornuevo = 0;
		String or, de;
		int pre;

		System.out.println("origen?");
		or = scs.nextLine();
		System.out.println("destino?");
		de = scs.nextLine();
		System.out.println("precio?");
		pre = sci.nextInt();
		for (int i = 0; i < lista.length; i++) {
			if (lista[i] != null) {

				if (lista[i].getOrigen().equals(or) && lista[i].getDestino().equals(de)
						&& lista[i].getPrecioporplaza() <= pre) {
					copia[contadornuevo] = lista[i];
					contadornuevo++;
				}
			}
		}
		// ordenar
		for (int j = 0; j < contadornuevo; j++) {
			for (int k = 0; k < contadornuevo - 1; k++) {
				if (copia[k].getPrecioporplaza() > copia[k + 1].getPrecioporplaza()) {
					Trayecto aux = copia[k];
					copia[k] = copia[k + 1];
					copia[k + 1] = aux;
				}
			}
		}

		// mostrar ya ordenado
		for (int i = 0; i < copia.length; i++) {
			System.out.println(copia[i]);
		}

	}

	public static boolean arrayVacio(Trayecto[] lista) {
		boolean vacio = true;
		for (int i = 0; i < lista.length; i++) {
			if (lista[i] != null) {
				vacio = false;
			}
		}
		return vacio;
	}

	public static boolean mailValido(String mail) {
		boolean res = true;

		// OPCION 1 de hacerlo
		String[] trozos = mail.split("@");
		if (trozos.length != 2) {
			return false;
		}
		if (trozos[0].length() < 3) {
			return false;
		}
		String[] trox = trozos[1].split(".");
		if (trox.length != 2) {
			return false;
		}
		if (trox[0].length() < 3) {
			return false;
		}
		if (trox[1].length() < 2 || trox[1].length() > 3) {
			return false;
		}

		return res;
	}

}
