package examenenero;

public class Trayecto {
	private int numerodetrayecto;
	private static int contadorTryectos = 0;
	private String origen;
	private String destino;
	private int plazasofertadas;
	private String conductor;
	private double precioporplaza;

	public Trayecto(String origen, String destino, int plazasofertadas, String conductor, double precioporplaza) {
		this.origen = origen;
		this.destino = destino;
		this.plazasofertadas = plazasofertadas;
		this.conductor = conductor;
		this.precioporplaza = precioporplaza;
		this.numerodetrayecto = contadorTryectos;
		contadorTryectos++;
	}

	public int getNumerodetrayecto() {
		return numerodetrayecto;
	}

	public void setNumerodetrayecto(int numerodetrayecto) {
		this.numerodetrayecto = numerodetrayecto;
	}

	public static int getContadorTryectos() {
		return contadorTryectos;
	}

	public static void setContadorTryectos(int contadorTryectos) {
		Trayecto.contadorTryectos = contadorTryectos;
	}

	public String getOrigen() {
		return origen;
	}

	public void setOrigen(String origen) {
		this.origen = origen;
	}

	public String getDestino() {
		return destino;
	}

	public void setDestino(String destino) {
		this.destino = destino;
	}

	public int getPlazasofertadas() {
		return plazasofertadas;
	}

	public void setPlazasofertadas(int plazasofertadas) {
		this.plazasofertadas = plazasofertadas;
	}

	public String getConductor() {
		return conductor;
	}

	public void setConductor(String conductor) {
		this.conductor = conductor;
	}

	public double getPrecioporplaza() {
		return precioporplaza;
	}

	public void setPrecioporplaza(double precioporplaza) {
		this.precioporplaza = precioporplaza;
	}

	@Override
	public String toString() {
		return "Trayecto [numerodetrayecto=" + numerodetrayecto + ", origen=" + origen + ", destino=" + destino
				+ ", plazasofertadas=" + plazasofertadas + ", conductor=" + conductor + ", precioporplaza="
				+ precioporplaza + "]";
	}

}
