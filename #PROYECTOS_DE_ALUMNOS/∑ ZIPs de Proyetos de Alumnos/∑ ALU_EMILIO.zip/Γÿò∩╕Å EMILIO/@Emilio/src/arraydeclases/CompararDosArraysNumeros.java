package arraydeclases;

import java.util.Scanner;

public class CompararDosArraysNumeros {

	public static void main(String[] args) {
		// Leed de teclado 2 arrays de 5 números. Decid:

		Scanner scnumeros = new Scanner(System.in);

		int[] arr1 = new int[5];
		int[] arr2 = new int[5];

		for (int i = 0; i < arr1.length; i++) {

			System.out.println("Dime nuevo precio");
			int num = scnumeros.nextInt();
			arr1[i] = num;

			System.out.println("Dime nuevo precio");
			int num2 = scnumeros.nextInt();
			arr2[i] = num2;

		}
		// a. Qué números están en los dos arrays.
		for (int i = 0; i < arr1.length; i++) {
			boolean encontrado = false;
			for (int k = 0; k < arr2.length && encontrado == false; k++) {
				if (arr1[i] == arr2[k]) {
					encontrado = true;
					System.out.println(arr1[k] + " esta en los dos arrays");
				}
			}
		}
		// b. Qué números aparecen sólo en el primer array.
		for (int i = 0; i < arr1.length; i++) {
			boolean encontrado = false;
			for (int k = 0; k < arr2.length; k++) {
				if (arr1[i] == arr2[k]) {
					encontrado = true;
				}
			}

			if (encontrado == false) {
				System.out.println(arr1[i] + " aparece solo en el primer array");
			}

		}

	}

}
