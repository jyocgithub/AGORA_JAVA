package arraydeclases;

import java.util.Scanner;

public class Principal {

	public static void main(String[] args) {
		Scanner scnumeros = new Scanner(System.in);
		Scanner scstrings = new Scanner(System.in);

		Vehiculo[] coches = new Vehiculo[5];

		Vehiculo v1 = new Vehiculo("11111", "FORD", 1, 120);
		Vehiculo v2 = new Vehiculo("22222", "KIA", 2, 60);
		Vehiculo v3 = new Vehiculo("33333", "SEAT", 1, 80);
		coches[0] = v1;
		coches[1] = v2;
		coches[2] = v3;

		int opcion = 0;
		do {
			System.out.println("MENU");
			System.out.println("1.- ALTA");
			System.out.println("2.- BAJA");
			System.out.println("3.- CONSULTAR PRECIO DE UN COCHE");
			System.out.println("4.- CONSULTAR TODOS");
			System.out.println("5.- ALQUILAR");
			System.out.println("6.- CAMBIAR PRECIO");
			System.out.println("7.- ORDENAR POR PRECIO");
			System.out.println("0.- SALIR");
			opcion = scnumeros.nextInt();
			switch (opcion) {
			case 1:
				alta(coches);
				break;
			case 2:
				baja(coches);
				break;
			case 3:
				consultarPrecio(coches);
				break;
			case 4:
				consultarTodos(coches);
				break;
			case 5:
				break;
			case 6:
				modificarPrecio(coches);
				break;
			case 7:
				ordenar(coches);
				break;
			}

		} while (opcion != 0);
	}

	public static void consultarTodos(Vehiculo[] albondigas) {

		for (int i = 0; i < albondigas.length; i++) {
			if (albondigas[i] != null) {
				System.out.println(albondigas[i].toString());
			}
		}
	}

	public static void modificarPrecio(Vehiculo[] albondigas) {
		Scanner scnumeros = new Scanner(System.in);
		Scanner scstrings = new Scanner(System.in);
		System.out.println("Dime matricula");
		String matri = scstrings.nextLine();
		System.out.println("Dime nuevo precio");
		int nuevoprecio = scstrings.nextInt();

		for (int i = 0; i < albondigas.length; i++) {
			if (albondigas[i] != null) {
				if (albondigas[i].getMatricula().equals(matri)) {
					albondigas[i].setPrecio(nuevoprecio);
				}
			}
		}
	}

	public static void consultarPrecio(Vehiculo[] albondigas) {
		Scanner scstrings = new Scanner(System.in);
		System.out.println("Dime matricula");
		String matri = scstrings.nextLine();

		for (int i = 0; i < albondigas.length; i++) {
			if (albondigas[i] != null) {
				if (albondigas[i].getMatricula().equals(matri)) {
					System.out.println(albondigas[i].getPrecio());
				}
			}
		}
	}

	public static void baja(Vehiculo[] albondigas) {
		Scanner scstrings = new Scanner(System.in);
		System.out.println("Dime matricula");
		String matri = scstrings.nextLine();

		for (int i = 0; i < albondigas.length; i++) {
			if (albondigas[i] != null) {
				if (albondigas[i].getMatricula().equals(matri)) {
					albondigas[i] = null;
				}
			}
		}
	}

	public static void alta(Vehiculo[] albondigas) {
		Scanner scnumeros = new Scanner(System.in);
		Scanner scstrings = new Scanner(System.in);

		System.out.println("Dime matricula");
		String matricula = scstrings.nextLine();

		System.out.println("Dime marca");
		String marca = scstrings.nextLine();

		System.out.println("Dime categoria");
		int categoria = scnumeros.nextInt();

		System.out.println("Dime precio");
		double precio = scnumeros.nextDouble();

		Vehiculo v = new Vehiculo(matricula, marca, categoria, precio);

		boolean haysitio = false;

		for (int i = 0; i < albondigas.length && haysitio == false; i++) {
			if (albondigas[i] == null) {
				albondigas[i] = v;
				haysitio = true;
			}
		}

		if (haysitio == false) {
			System.out.println("Esta lleno no hay sitio");
		} else {
			System.out.println("COCHE GUARDADO");
		}

	}

	public static void ordenar(Vehiculo[] albondigas) {

		// ORDENAR POR ATRIBUTOS QUE SEAN INT
		for (int i = 0; i < albondigas.length; i++) {
			for (int k = 0; k < albondigas.length - 1; k++) {
				if (albondigas[k].getPrecio() > albondigas[k + 1].getPrecio()) {
					Vehiculo aux = albondigas[k];
					albondigas[k] = albondigas[k + 1];
					albondigas[k + 1] = aux;
				}
			}
		}

		// ORDENAR POR ATRIBUTOS QUE SEAN STRING
		for (int i = 0; i < albondigas.length; i++) {
			for (int k = 0; k < albondigas.length - 1; k++) {
				if (albondigas[k].getMatricula().compareTo(albondigas[k + 1].getMatricula()) > 0) {
					Vehiculo aux = albondigas[k];
					albondigas[k] = albondigas[k + 1];
					albondigas[k + 1] = aux;
				}
			}
		}

	}

}
