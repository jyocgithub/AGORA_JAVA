package arraydeclases;

import java.util.Scanner;

public class ArrayDeContadores {

	public static void main(String[] args) {

		// Leed números de teclado del 0 al 9 hasta que lo desee el usuario. Mostrad al
		// finalizar cuántos números se han leído de cada uno. Usad un array de
		// frecuencias.

		int[] frecuencias = new int[10];

		Scanner scnumeros = new Scanner(System.in);
		int num = 0;
		do {
			System.out.println("Dime nuevo numero");
			num = scnumeros.nextInt();
			frecuencias[num]++;

			// if (num == 0) {
			// frecuencias[0]++;
			// }
			// if (num == 1) {
			// frecuencias[1]++;
			// }
			// if (num == 2) {
			// frecuencias[2]++;
			// }
			// if (num == 3) {
			// frecuencias[3]++;
			// }

		} while (num < 10);

		for (int i = 0; i < frecuencias.length; i++) {
			System.out.print(frecuencias[i] + "  ");
		}

	}

}
