package arraydeclases;

public class Vehiculo {

	private String matricula;
	private String marca;
	private int categoria;
	private double precio;
	private boolean alquilado;

	public Vehiculo(String matricula, String marca, int categoria, double precio) {
		super();
		this.matricula = matricula;
		this.marca = marca;
		this.categoria = categoria;
		this.precio = precio;
		this.alquilado = false;
	}

	public Vehiculo() {
		super();
	}

	public String getMatricula() {
		return matricula;
	}

	public void setMatricula(String matricula) {
		this.matricula = matricula;
	}

	public String getMarca() {
		return marca;
	}

	public void setMarca(String marca) {
		this.marca = marca;
	}

	public int getCategoria() {
		return categoria;
	}

	public void setCategoria(int categoria) {
		this.categoria = categoria;
	}

	public double getPrecio() {
		return precio;
	}

	public void setPrecio(double precio) {
		this.precio = precio;
	}

	@Override
	public String toString() {
		return "Vehiculo [matricula=" + matricula + ", marca=" + marca + ", categoria=" + categoria + ", precio="
				+ precio + "]";
	}

}
