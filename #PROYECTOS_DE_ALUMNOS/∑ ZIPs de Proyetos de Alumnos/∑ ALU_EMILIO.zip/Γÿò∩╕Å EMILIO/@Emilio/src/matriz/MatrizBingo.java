package matriz;

import java.util.Random;

public class MatrizBingo {

	public static void main(String[] args) {

		int x = 4;
		int z[] = new int[3];
		z[0] = 3;

		int m[][] = new int[2][3];
		m[0][1] = 3;

		Random r = new Random();
		int[][] carton = new int[3][9];

		// RELLENO
		for (int f = 0; f < carton.length; f++) {
			for (int c = 0; c < carton[0].length; c++) {
				carton[f][c] = r.nextInt(100);
			}

		}

		// PINTAR MATRIZ
		for (int f = 0; f < carton.length; f++) {
			for (int c = 0; c < carton[0].length; c++) {
				if (carton[f][c] < 10) {
					System.out.print("0" + carton[f][c] + "\t");
				} else {
					System.out.print(carton[f][c] + "\t");
				}

			}
			System.out.println("");
		}

		// BUSCAMOS EL NUMERO 37
		for (int f = 0; f < carton.length; f++) {
			for (int c = 0; c < carton[0].length; c++) {
				if (carton[f][c] == 37) {
					System.out.println("encontrado");
				}
			}
		}

		// // MATRIZ DE STRINGS
		// String[][] matstring = new String[3][5];
		// Scanner sc = new Scanner(System.in);
		// System.out.println("Vaya dando valor a las celdas, son textos");
		//
		// for (int f = 0; f < matstring.length; f++) {
		// for (int c = 0; c < matstring[0].length; c++) {
		// matstring[f][c] = sc.nextLine();
		// }
		// }
		//
		// // PINTAR MATRIZ
		// for (int f = 0; f < matstring.length; f++) {
		// for (int c = 0; c < matstring[0].length; c++) {
		// System.out.print(matstring[f][c] + "\t");
		// }
		// System.out.println("");
		// }
		//
		// // BUSCAMOS EL TEXTO "pepe"
		// for (int f = 0; f < matstring.length; f++) {
		// for (int c = 0; c < matstring[0].length; c++) {
		// if (matstring[f][c].equals("pepe")) {
		// System.out.println("encontrado");
		// }
		// }
		// }

		// EJRCICIOS *************************
		// EJRCICIOS *************************
		// EJRCICIOS *************************
		// EJRCICIOS *************************
		// EJRCICIOS *************************

		// CREAR UNA MATRIZ 3x3 CON LA DIAGONAL PRINCIPAL QUE SEAN 1
		// Y EL RESTO 0
		int[][] mat = new int[3][3];

		for (int f = 0; f < mat.length; f++) {
			for (int c = 0; c < mat[0].length; c++) {
				if (f == c) {
					mat[f][c] = 1;
				} else {
					mat[f][c] = 0;
				}
			}
		}
		pintarMatrizEnteros(mat);

		// CREAR UNA MATRIZ DE ENTEROS AL AZAR Y
		// DECIR LA SUMA DE TODOS LOS VALORES PARES QUE CONTENGA
		int[][] nums = new int[3][3];
		for (int f = 0; f < nums.length; f++) {
			for (int c = 0; c < nums[0].length; c++) {
				nums[f][c] = r.nextInt(100);
			}
		}

		pintarMatrizEnteros(nums);
		int suma = 0;
		for (int f = 0; f < nums.length; f++) {
			for (int c = 0; c < nums[0].length; c++) {
				if (nums[f][c] % 2 == 0) {
					suma = suma + nums[f][c];
				}
			}
		}
		System.out.println(suma);

		// CREAR UNA MATRIZ DE ENTEROS AL AZAR Y
		// DECIR LA SUMA DE CADA FILA
		int[][] matrix = new int[3][3];
		for (int f = 0; f < matrix.length; f++) {
			for (int c = 0; c < matrix[0].length; c++) {
				matrix[f][c] = r.nextInt(100);
			}
		}
		pintarMatrizEnteros(matrix);
		for (int f = 0; f < matrix.length; f++) {
			int sumafila = 0;
			for (int c = 0; c < matrix[0].length; c++) {
				sumafila = sumafila + matrix[f][c];
			}
			System.out.println("*" + sumafila);
		}

		// INVERTIR UNA MATRIZ
		int[][] mmm = new int[3][3];
		for (int f = 0; f < mmm.length; f++) {
			for (int c = 0; c < mmm[0].length; c++) {
				mmm[f][c] = r.nextInt(100);
			}
		}
		pintarMatrizEnteros(mmm);

		for (int f = 0; f < mmm.length; f++) {
			for (int c = 0; c < mmm[0].length; c++) {
				mmm[f][c] = mmm[c][f];
			}
		}
		pintarMatrizEnteros(mmm);

		// CREAR UNA MATRIZ 4X4 CON NUMEROS AL AZAR DE CEROS Y UNOS
		// Y DECIR SI LA DIAGONAL MAYOR SON TODO UNOS

		int cont = 0;
		int[][] nnn = new int[3][3];
		for (int f = 0; f < nnn.length; f++) {
			for (int c = 0; c < mmm[0].length; c++) {
				nnn[f][c] = r.nextInt(2);
			}
		}
		pintarMatrizEnteros(nnn);
		for (int f = 0; f < nnn.length; f++) {
			for (int c = 0; c < nnn[0].length; c++) {
				if (f == c) {
					if (nnn[f][c] == 1) {
						cont++;
					}
				}
			}
		}
		if (cont == nnn.length) {
			System.out.println("toda la diagonal son iguales ");

		}

		// HACER UNA MATRIZ 4X4 QUE TODO EL "MARCO" SEAN 1
		// Y EL RESTO SEAN 0

		int[][] sss = new int[4][4];
		for (int f = 0; f < sss.length; f++) {
			for (int c = 0; c < sss[0].length; c++) {
				if (f == 0 || c == 0 || f == sss.length - 1 || c == sss.length - 1) {
					sss[f][c] = 1;
				}

			}
		}
		pintarMatrizEnteros(sss);

		// ARRAY DE 3 COCHES
		// METER 3 COCHES Y LUEGO DECIR CUANDO VALEN TODOS JUNTOS
		Coche coches[] = new Coche[3];
		Coche c = new Coche("Audi", 765);
		Coche c1 = new Coche("mercedes", 764);
		Coche c2 = new Coche("Ciutroen ", 365);
		coches[0] = c;
		coches[1] = c1;
		coches[2] = c2;
		int sumas = 0;
		for (int i = 0; i < coches.length; i++) {

			sumas = coches[i].precio + sumas;

		}
		System.out.println("La suma total es " + sumas);

	}

	// ***********************************
	public static void pintarMatrizEnteros(int[][] XXX) {
		for (int f = 0; f < XXX.length; f++) {
			for (int c = 0; c < XXX[0].length; c++) {
				// if (XXX[f][c] < 10) {
				// System.out.print("0" + XXX[f][c] + "\t");
				// } else {
				System.out.print(XXX[f][c] + "\t");
				// }

			}
			System.out.println("");
		}
	}

}

// **********************************************
// **********************************************
// **********************************************

class Concierto {
	String grupo;
	int dia;
	int mes;
	String codigo;

	public Concierto(String grupo, int dia, int mes) {

		this.grupo = grupo;
		if (dia > 31) {
			System.out.println("mierda de dia");
		} else {
			this.dia = dia;
		}
		this.mes = mes;
		String mesbueno;
		if (mes < 10) {
			mesbueno = "0" + mes;
		} else {
			mesbueno = mes + "";
		}
		this.codigo = grupo.substring(0, 3) + "_" + dia + "_" + mesbueno;
	}

}

class Coche {
	String marca;
	int precio;

	public Coche(String marca, int precio) {
		super();
		this.marca = marca;
		this.precio = precio;
	}

	public String getMarca() {
		return marca;
	}

	public void setMarca(String marca) {
		this.marca = marca;
	}

	public int getPrecio() {
		return precio;
	}

	public void setPrecio(int precio) {
		this.precio = precio;
	}

}