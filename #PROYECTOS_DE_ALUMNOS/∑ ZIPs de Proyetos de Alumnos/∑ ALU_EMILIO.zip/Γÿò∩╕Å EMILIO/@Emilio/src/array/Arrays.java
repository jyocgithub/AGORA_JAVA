package array;

import java.util.Random;
import java.util.Scanner;

public class Arrays {

     public static void main(String[] args) {

          int x = 1;

          int[] a = new int[5];

          a[2] = 3;
          int j = a[2] + 3 - 5;
//          System.out.println(a[2]);
          // 0 1 2 3 4 5 6 7 
          int[] b = {4, 6, 3, 4, 5};
//          System.out.println(b[2]);

          int k = 3;


//          System.out.println(b[0]);
//          System.out.println(b[1]);
//          System.out.println(b[2]);
//          System.out.println(b[3]);
//          System.out.println(b[4]);

          Random ran = new Random();

          for (int i = 0; i < 5; i++) {
               b[i]
          }

          // no se lo que tiene el vestido, de atributos, 
          // pero me imagino que tienen precio y marca
          Ropa[] aRopa = new Ropa[5];
          Scanner sc = new Scanner(System.in);
          for (int i = 0; i < aRopa.length; i++) {
               System.out.println("Dime la marca"); // pido atributos
               String marca = sc.nextLine();

               System.out.println("Dime el precio");
               int precio = sc.nextInt();

               Ropa r = new Ropa(marca, precio); //creo un objeto
               aRopa[i] = r;                     // añado objeto al array
          }
          
          
          
          
          int az = (int) (Math.random()*20);
          
          
          
          
          
          
          
          
          
          
          
          
          
          
          
          
          

     }


}


class Ropa {
Ropa(String b, int e){
     
}
}
