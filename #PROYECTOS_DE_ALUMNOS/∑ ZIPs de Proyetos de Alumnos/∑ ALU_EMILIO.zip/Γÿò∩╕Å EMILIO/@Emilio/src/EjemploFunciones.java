
import java.util.Scanner;


public class EjemploFunciones {

     public static void main(String[] args) {
          System.out.println("PRIMERA LINEA DEL PROGRAMA ");
          System.out.println("PRIMERA LINEA DEL PROGRAMA ");
                  
          sumar(4743,5238);
          
          int u = 4;
          int p = 5;
          
          
          int res = sumar(u,p);
          
              
          
          
          Scanner sc = new Scanner(System.in);
          int horas = sc.nextInt();
          int preciohora = sc.nextInt();
          
          
          calcularSalario(horas, preciohora);
          
          System.out.println("PRIMERA LINEA DEL PROGRAMA ");
          System.out.println("PRIMERA LINEA DEL PROGRAMA ");
          
          
          double result = dividir(4,2);
          System.out.println("PRIMERA LINEA DEL PROGRAMA ");
                  
            
     }
     
     public static void calcularSalario(int h,int p){
          int res = h+p;
          System.out.println(res);
     }
     
     
     public static int sumar(int a,int b){

          int suma = a+b;

          return suma;
     }
     
     public static  double dividir(int a, int b){
          
          
          double xxx = a/b;
          return xxx;
         
     }
     
     
     
}
