package listas;

import java.util.ArrayList;
import java.util.Vector;

public class Listas {

	public static void main(String[] args) {

		Vector<String> vec = new Vector<>();
		ArrayList<String> alis = new ArrayList<>();

		// añadir elementos al vector

		String ss = "juan";
		vec.add(ss);
		vec.add("ana");
		vec.add("luis");
		vec.add("ana");

		// insertar en medio elementos al vector
		vec.add(2, "lolo");

		// tamaño de la lista
		int tam = vec.size();

		// borrar
		vec.remove(2);

		// obtener un valor
		String d = vec.get(2);
		System.out.println(vec.get(1));

		// modificar
		vec.set(2, "Pepi");

		// borrar todo
		vec.clear();

		// saber si la lisat contiene un valor
		if (vec.contains("luis")) {

		}

		// --------------------- RECORRER
		// -- for tradicional
		for (int i = 0; i < vec.size(); i++) {
			String s = vec.get(i);
			if (s.equals("ana")) {
				System.out.println("esta ana !!!!!");
			}
			System.out.println(s);
		}

		// -- foreach o for resumido
		for (String s : vec) {
			if (s.equals("ana")) {
				System.out.println("esta ana !!!!!");
			}
			System.out.println(s);
		}

		// WRAPPERS
		/*
		 * double Double float Float long Long int Integer char Character boolean Boolean
		 */

	}

}
