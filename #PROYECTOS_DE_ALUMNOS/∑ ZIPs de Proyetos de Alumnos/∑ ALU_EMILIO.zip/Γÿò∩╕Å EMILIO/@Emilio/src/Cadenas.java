import java.util.Scanner;

public class Cadenas {

	public static void main(String[] args) {

		// 012345
		String cad1 = "Melon";
		String cad2 = "Pera";

		int tamno = cad1.length();
		String cvcc = cad1.toUpperCase();

		// if(cad1 == cad2) { // NOOOOOOOOOOOOOOO
		if (cad1.equals(cad2)) {

		}

		// if(cad1 > cad2) { // NOOOOOOOOOOOOOO
		if (cad1.compareTo(cad2) > 0) {

		}

		int indice = cad1.indexOf("el"); // indice vale 1
		char c = cad1.charAt(3); // c vale o

		String trozo1 = cad1.substring(2, 4); // trozo1 vale lo
		String trozo2 = cad1.substring(2); // trozo2 vale lon

		// ------------------ escribir una palabra letra a letra

		Scanner sc = new Scanner(System.in);
		System.out.println("dime una palabra");
		String palabra = sc.nextLine();

		// 01234
		// palabra = "melon";

		// System.out.println(palabra.substring(0, 1));
		// System.out.println(palabra.substring(0, 2));
		// System.out.println(palabra.substring(0, 3));
		// System.out.println(palabra.substring(0, 4));
		// System.out.println(palabra.substring(0, 5));

		for (int i = 1; i <= palabra.length(); i++) {

			System.out.println(palabra.substring(0, i));
		}

		// System.out.println(palabra.charAt(0));
		// System.out.println(palabra.charAt(1));
		// System.out.println(palabra.charAt(2));
		// System.out.println(palabra.charAt(3));

		for (int i = 0; i < palabra.length(); i++) {
			System.out.println(palabra.charAt(i));
		}

		// System.out.println(palabra.substring(0, 1));
		// System.out.println(palabra.substring(1, 2));
		// System.out.println(palabra.substring(2, 3));
		// System.out.println(palabra.substring(3, 4));
		// System.out.println(palabra.substring(4, 5));

		for (int i = 0; i < palabra.length(); i++) {
			System.out.println(palabra.substring(i, 1 + i));
		}

	}

	public static boolean validarMatri(String matricula) {
		if (matricula.length() > 7 && matricula.length() < 7) {
			return false;
		}

		// if (matricula.charAt(0) < '0' || matricula.charAt(0) > '9') {
		// return false;
		// }
		// if (matricula.charAt(1) < '0' || matricula.charAt(1) > '9') {
		// return false;
		// }
		// if (matricula.charAt(2) < '0' || matricula.charAt(2) > '9') {
		// return false;
		// }
		// if (matricula.charAt(3) < '0' || matricula.charAt(3) > '9') {
		// return false;
		// }

		for (int i = 0; i <= 3; i++) {
			if (matricula.charAt(i) < '0' || matricula.charAt(i) > '9') {
				return false;
			}

		}

		String cade = matricula.substring(4, 7);
		cade = cade.toUpperCase();
		for (int i = 0; i <= 3; i++) {
			if (cade.charAt(i) < 'A' || cade.charAt(i) > 'Z') {
				return false;
			}

		}
		return false;

	}

	public void ordenacionBurbuja() {
		
		int[] 
		
		
		
		
		
	}

}
