import java.util.Scanner;

public class EjercicioLeerCadenasHastaPonerFin {

	public static void main(String[] args) {

		Scanner entrada = new Scanner(System.in);
		String linea = "";
		do {

			System.out.println("escribe una cadena:");
			linea = entrada.nextLine();
			System.out.println(linea.toUpperCase());
		} while (!linea.equalsIgnoreCase("fin"));

	}

}
