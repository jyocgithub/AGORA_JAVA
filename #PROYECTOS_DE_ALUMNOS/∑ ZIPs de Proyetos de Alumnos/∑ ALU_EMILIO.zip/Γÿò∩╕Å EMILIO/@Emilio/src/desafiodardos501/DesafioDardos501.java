/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package desafiodardos501;

import java.util.*;

/**
 *
 * @author admin
 */
public class DesafioDardos501 {

     /**
      * @param args the command line arguments
      */
     public static void main(String[] args) {
          int jugador1 = 501, jugador2 = 501, n, puntuacion1, puntuacion2;
          Scanner sc = new Scanner(System.in);
          sc.useLocale(Locale.ENGLISH);
          // TODO code application logic here 
           
          boolean seguir = true;

          n = 0;
          while (seguir == true) {
               // JUG 1 
               int dardo1 = (int) (Math.random() * 20);
               int doble1 = (int) (Math.random() * 3);
               System.out.println("El Jugador 1 a lanzado ");
               System.out.println("Dardo 1: " + dardo1 + " tipo: " + doble1);

               int dardo2 = (int) (Math.random() * 20);
               int doble2 = (int) (Math.random() * 3);
               System.out.println("Dardo 2: " + dardo2 + " tipo: " + doble2);

               int dardo3 = (int) (Math.random() * 20);
               int doble3 = (int) (Math.random() * 3);
               System.out.println("Dardo 3: " + dardo3 + " tipo: " + doble3);


               // JUG 2 
               int dardo1J2 = (int) (Math.random() * 20);
               int doble1J2 = (int) (Math.random() * 3);
               System.out.println("El Jugador 2 a lanzado ");
               System.out.println("Dardo 1: " + dardo1J2 + " tipo: " + doble1J2);

               int dardo2J2 = (int) (Math.random() * 20);
               int doble2J2 = (int) (Math.random() * 3);
               System.out.println("Dardo 2: " + dardo2J2 + " tipo: " + doble2J2);

               int dardo3J2 = (int) (Math.random() * 20);
               int doble3J2 = (int) (Math.random() * 3);
               System.out.println("Dardo 3: " + dardo3J2 + " tipo: " + doble3J2);

               if (doble1 == 1)
                    dardo1 = dardo1 * 2;
               else if (doble1 == 2)
                    dardo1 = dardo1 * 3;
               if (doble2 == 1)
                    dardo2 = dardo2 * 2;
               else if (doble2 == 2)
                    dardo2 = dardo2 * 3;
               if (doble3 == 1)
                    dardo3 = dardo3 * 2;
               else if (doble3 == 2)
                    dardo3 = dardo3 * 3;
               if (doble1J2 == 1)
                    dardo1J2 = dardo1J2 * 2;
               else if (doble1J2 == 2)
                    dardo1J2 = dardo1J2 * 3;
               if (doble2J2 == 1)
                    dardo2J2 = dardo2J2 * 2;
               else if (doble2J2 == 2)
                    dardo2J2 = dardo2J2 * 3;
               if (doble3J2 == 1)
                    dardo3J2 = dardo3J2 * 2;
               else if (doble3J2 == 2)
                    dardo3J2 = dardo3J2 * 3;

               int loqueteniaantesdeempezarestaronda = jugador1;

               jugador1 = jugador1 - dardo1;
               if (jugador1 < 0) {
                    jugador1 = loqueteniaantesdeempezarestaronda;
               } else {
                    jugador1 = jugador1 - dardo2;
                    if (jugador1 < 0) {
                         jugador1 = loqueteniaantesdeempezarestaronda;
                    } else {
                         jugador1 = jugador1 - dardo3;
                         if (jugador1 < 0) {
                              jugador1 = loqueteniaantesdeempezarestaronda;
                         }
                    }
               }

               loqueteniaantesdeempezarestaronda = jugador2;
               jugador2 = jugador2 - dardo1J2;
               if (jugador2 < 0) {
                    jugador2 = loqueteniaantesdeempezarestaronda;
               } else {
                    jugador2 = jugador2 - dardo2J2;
                    if (jugador2 < 0) {
                         jugador2 = loqueteniaantesdeempezarestaronda;
                    } else {
                         jugador2 = jugador2 - dardo3J2;
                         if (jugador2 < 0) {
                              jugador2 = loqueteniaantesdeempezarestaronda;
                         }
                    }
               }

               if (jugador1 == 0) {
                    System.out.println("Felicidades has ganado jugador 1");
                    seguir = false;
               }
               if (jugador2 == 0) {
                    System.out.println("Felicidades has ganado jugador 2");
                    seguir = false;
               }
               if (n == 20) {
                    seguir = false;
               }
               n++;
               System.out.println("---------- RONDA: " + n +"-------------------");
               System.out.println("JUGADOR 1 LE QUEDAN: " + jugador1);
               System.out.println("JUGADOR 2 LE QUEDAN: " + jugador2);

          }


          if (jugador1 < jugador2)
               System.out.println("Felicidades ha ganado el jugador 1 por menos puntuos");
          else if (jugador1 > jugador2)
               System.out.println("Felicidades ha ganado el jugador 2 por menos puntuos");
          else if (jugador1 == jugador2)
               System.out.println("Hay empate");

     }

}
