
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
//package emiliojesuscedeñosoledispa1;

import java.util.Locale;
import java.util.Scanner;

/**
 *
 * @author admin
 */
public class EmilioJesusCedeñoSoledispa1 {

	/**
	 * @param args
	 *            the command line arguments
	 */
	public static void main(String[] args) {
		int numero, pizzas, ingre, cont = 0;
		String tamaño;
		char ingredientes;
		boolean validarNum = true, validarIgre = true;

		Scanner sc = new Scanner(System.in);
		sc.useLocale(Locale.ENGLISH);
		// TODO code application logic here

		do {
			do {
				System.out.println("¿Que número de telefono quieres poner ?");
				numero = sc.nextInt();
				validarNum = validarNum(numero);
				if (validarNum == false) {
					System.out.println("Número incorrecto vuelva a escribir otro ");
				}
			} while (validarNum == false);
			System.out.println("¿Cuantas pizzas quiere?");
			pizzas = sc.nextInt();
			for (int i = 1; i <= pizzas; i++) {
				System.out.println("Vamos con la pizza numero " + i + ", ¿que tamaño desea?");
				sc.nextLine();
				tamaño = sc.nextLine();

				System.out.println("¿Cuantos ingredientes quiere?");
				ingre = sc.nextInt();
				cont = 0;
				do {
					cont++;
					System.out.println("Indique el ingrediente numero " + cont + " (o escriba S si quiere salir)");
					ingredientes = sc.next().charAt(0);
					validarIgre = validarIngredientes(ingredientes);
					if (ingredientes == 'S') {
						break;
					}
					if (validarIgre == false) {
						System.out.println("Ingrediente erroneo !! Intente otra vez, solo valen P, A, C o E");
						cont--;
					}
				} while (cont < ingre);

			}

		} while (numero != 0 && pizzas > 10);

	}

	public static boolean validarNum(int num) {
		int numero;
		numero = num / 100000000;
		if (numero != 9 && numero != 6) {
			return false;
		}

		if (num > 111111111 && num < 999999999) {
			return true;
		} else {
			return false;
		}

	}

	public static boolean validarIngredientes(char ingredientes) {
		if (ingredientes == 'P' || ingredientes == 'A' || ingredientes == 'C' || ingredientes == 'E'
				|| ingredientes == 'S') {
			return true;

		} else {
			return false;
		}
	}

	public static void calcularPrecio(double precio) {

	}
}
