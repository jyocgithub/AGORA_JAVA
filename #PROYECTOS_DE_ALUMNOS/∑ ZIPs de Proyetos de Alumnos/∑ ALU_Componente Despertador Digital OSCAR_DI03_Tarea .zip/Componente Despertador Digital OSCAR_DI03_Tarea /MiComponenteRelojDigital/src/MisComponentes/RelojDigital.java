
package MisComponentes;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Timer;
import java.util.TimerTask;
import javax.swing.BorderFactory;
import javax.swing.JLabel;

/**
 *
 * @author Oscar
 */
public class RelojDigital extends JLabel implements ActionListener, Serializable {

    public RelojDigital() {

        formatoLabel();

        Timer timer = new Timer();
        timer.schedule(new TimerTask() {

            @Override
            public void run() {
                Date horaActual = new Date();
                if (formatoHora) {
                    setText(formato24h.format(horaActual));
                } else {
                    setText(formato12h.format(horaActual));
                }
                if (activarAlarma) {
                    if (fijarHora == horaActual.getHours() && fijarMinuto == horaActual.getMinutes() && horaActual.getSeconds() == 0) {

                        if (alarma != null) {

                            alarma.alarmaSonando();
                        }
                    }
                }
            }
        }, 0, 1000);
    }

    private void formatoLabel() {
        this.setFont(new Font("Broadway", Font.BOLD, 32));
        this.setForeground(new Color(31, 118, 144));
        this.setOpaque(true);
        this.setBackground(new Color(30, 30, 30));
        this.setBorder(BorderFactory.createLineBorder(new Color(52, 123, 103), 3));
        this.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        this.setPreferredSize(new Dimension(200, 100));
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        alarma.alarmaSonando();
    }

    //Implementacion de escuchador
    public void addAlarmaListener(AlarmaSuena alarma) {
        this.alarma = alarma;
    }

    public void removeAlarmaListener(AlarmaSuena alarma) {
        this.alarma = null;
    }

    //Getter-Setter Fijar mensaje de Alarma
    public String getMensajeAlarma() {
        return mensajeAlarma;
    }

    public void setMensajeAlarma(String mensajeAlarma) {
        this.mensajeAlarma = mensajeAlarma;
    }

    //Getter-Setter fijarHora/fijarMinuto
    public int getFijarHora() {
        return fijarHora;
    }

    public void setFijarHora(int fijarHora) {
        this.fijarHora = fijarHora;
        repaint();
    }

    public int getFijarMinuto() {
        return fijarMinuto;
    }

    public void setFijarMinuto(int fijarMinuto) {
        this.fijarMinuto = fijarMinuto;
        repaint();
    }

    //Getter-Setter Activar / Desactivar Alarma
    public boolean isActivaAlarma() {
        return activarAlarma;
    }

    public void setActivaAlarma(boolean activaAlarma) {
        this.activarAlarma = activaAlarma;
    }

    //Getter-Setter formatoHora 12/24
    public boolean isFormatoHora() {
        return formatoHora;
    }

    public void setFormatoHora(boolean formatoHora) {
        this.formatoHora = formatoHora;
    }

    private SimpleDateFormat formato12h = new SimpleDateFormat("HH:mm:ss");
    private SimpleDateFormat formato24h = new SimpleDateFormat("hh:mm:ss");

    private AlarmaSuena alarma;
    private boolean formatoHora, activarAlarma;
    private int fijarHora, fijarMinuto;
    private String mensajeAlarma;

}
