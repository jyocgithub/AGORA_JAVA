package ALVARO_fichas;

import java.util.Arrays;

public class Ficha {
    private String index;
    private String internationalChemicalIdentification;
    private String EC;
    private String CAS;
    private String[] hazardClass;
    private String[] hazardStatCode;

    public Ficha(String index, String internationalChemicalIdentification, String eC, String cAS, String[] hazardClass,
                 String[] hazardStatCode) {
        super();
        this.index = index;
        this.internationalChemicalIdentification = internationalChemicalIdentification;
        EC = eC;
        CAS = cAS;
        this.hazardClass = hazardClass;
        this.hazardStatCode = hazardStatCode;
    }

    public Ficha() {
        super();
    }

    public String getIndex() {
        return index;
    }

    public void setIndex(String index) {
        this.index = index;
    }

    public String getInternationalChemicalIdentification() {
        return internationalChemicalIdentification;
    }

    public void setInternationalChemicalIdentification(String internationalChemicalIdentification) {
        this.internationalChemicalIdentification = internationalChemicalIdentification;
    }

    public String getEC() {
        return EC;
    }

    public void setEC(String eC) {
        EC = eC;
    }

    public String getCAS() {
        return CAS;
    }

    public void setCAS(String cAS) {
        CAS = cAS;
    }

    public String[] getHazardClass() {
        return hazardClass;
    }

    public void setHazardClass(String[] hazardClass) {
        this.hazardClass = hazardClass;
    }

    public String[] getHazardStatCode() {
        return hazardStatCode;
    }

    public void setHazardStatCode(String[] hazardStatCode) {
        this.hazardStatCode = hazardStatCode;
    }

    @Override
    public String toString() {
        return "Ficha{" +
                "index='" + index + '\'' +
                ", internationalChemicalIdentification='" + internationalChemicalIdentification + '\'' +
                ", EC='" + EC + '\'' +
                ", CAS='" + CAS + '\'' +
                ", hazardClass='" + Arrays.toString(hazardClass)






                + '\'' +
                ", hazardStatCode='" + Arrays.toString(hazardStatCode)




                + '\'' +
                '}';
    }
}
