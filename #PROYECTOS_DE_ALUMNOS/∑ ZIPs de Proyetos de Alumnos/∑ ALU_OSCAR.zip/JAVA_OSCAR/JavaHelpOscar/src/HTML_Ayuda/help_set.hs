<?xml version='1.0' encoding='ISO-8859-1'?>

<?TestTarget this is data for the test target?>

<helpset version="1.0">

  <!-- title -->
  <title>Ayuda ventana principal</title>

  <!-- maps -->
  <maps>
    <homeID>aplicacion</homeID>
    <mapref location="map_file.jhm" />
  </maps>

  <!-- views -->
  <view>
    <name>Tabla de contenidos</name>
    <label>Tabla contenidos</label>
    <type>javax.help.TOCView</type>
    <data>toc.xml</data>
  </view>

  <view>
    <name>Indice</name>
    <label>Index</label>
    <type>javax.help.IndexView</type>
    <data>indice.xml</data>
  </view>

  <view>
    <name>Buscar</name>
    <label>Search</label>
    <type>javax.help.SearchView</type>
    <data engine="com.sun.java.help.search.DefaultSearchEngine">
      JavaHelpSearch
    </data>
  </view>
</helpset>