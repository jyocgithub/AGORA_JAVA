package almacenxml;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Scanner;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Result;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Text;

class GeneradorDOM {
    final private Document document;
    Scanner ent = new Scanner(System.in);
    private String opcion;
    ArrayList<String> desc = new ArrayList<>();
    ArrayList<Double> prec = new ArrayList<>();
    ArrayList<String> uni = new ArrayList<>();
    
    public GeneradorDOM() throws ParserConfigurationException{
        DocumentBuilderFactory factoria = DocumentBuilderFactory.newInstance();
        DocumentBuilder builder = factoria.newDocumentBuilder();
        document = builder.newDocument();
    }
    
    public void generarDocument(){
        Element pedido = document.createElement("pedido");
        document.appendChild(pedido);
        
        for(int i=0; i< desc.size(); i++){
        
            Element productoP = document.createElement("productoPedido");
            pedido.appendChild(productoP);

            Element producto = document.createElement("producto");
            productoP.appendChild(producto);

            Element descrip = document.createElement("descripcion");
            Text textProduct = document.createTextNode(desc.get(i));
            descrip.appendChild(textProduct);
            producto.appendChild(descrip);

            Element precio = document.createElement("precio");
            Text precProd = document.createTextNode(Double.toString(prec.get(i)));
            precio.appendChild(precProd);
            producto.appendChild(precio);

            Element unidad = document.createElement("unidades");
            Text uniProd = document.createTextNode(uni.get(i));
            unidad.appendChild(uniProd);
            productoP.appendChild(unidad);
        }
    }
    
    public void generarXml() throws TransformerConfigurationException, IOException, TransformerException{
        TransformerFactory factoria = TransformerFactory.newInstance();
        Transformer transformer = factoria.newTransformer();
        
        Source source = new DOMSource(document);
        File file = new File("archivo.xml");
        FileWriter fw = new FileWriter(file);
        PrintWriter pw = new PrintWriter(fw);
        Result result = new StreamResult(pw);
        
        transformer.transform(source, result);
        //pw.close();
    }
    
    public void secuencia(){
        
        boolean continuar;
        System.out.println("Introduccion de pedidos");
        do{
            System.out.print("Introduce la descripcion del Producto: ");
            desc.add(ent.nextLine());
            System.out.print("Introduce el precio del Prodcuto: ");
            prec.add(ent.nextDouble());
            ent.nextLine();                                                 //salto de linea para liberar buffer
            System.out.print("Introduce las unidades del Producto: ");
            uni.add(ent.nextLine());
            do{
                System.out.print("¿Desea continuar (S/N)?: ");
                opcion = ent.nextLine();
                if(opcion.equalsIgnoreCase("S")){
                    continuar = true;
                }
                else if(opcion.equalsIgnoreCase("N")){
                    continuar = false;
                }
                else{
                    System.out.println("Debe introducir S o N");
                }
            }
            while(!opcion.equalsIgnoreCase("S") && !opcion.equalsIgnoreCase("N"));
        }
        while(continuar = true);
    }
}