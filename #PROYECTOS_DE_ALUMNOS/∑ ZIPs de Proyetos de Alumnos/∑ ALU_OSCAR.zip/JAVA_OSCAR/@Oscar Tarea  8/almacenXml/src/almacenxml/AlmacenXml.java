package almacenxml;

public class AlmacenXml {

    public static void main(String[] args) throws Exception{
        
        GeneradorDOM generadorDOM = new GeneradorDOM();
        generadorDOM.secuencia();
        generadorDOM.generarDocument();
        generadorDOM.generarXml();
        
    }
}