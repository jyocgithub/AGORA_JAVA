package gestionclient;

import java.io.*;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Gestion {

    String nombreFichero;

    public Gestion(String nombreFichero) {
        this.nombreFichero = nombreFichero;
    }

    public void gestiona() {
        int opcion;

        do {
            opcion = menu();
            switch (opcion) {
                case 1:
                    creaFichero();
                    break;
                case 2:
                    creaCliente();
                    break;
                case 3:
                    litarClientes();
                    break;
                case 4:
                    borrarArchivo();
                    break;
                case 5:
                    break;
            }
        } while (opcion != 5);
    }

    private int menu() {
        Scanner ent = new Scanner(System.in);
        int opcion;

        System.out.println("GESTION DE CLIENTES");
        System.out.println("====================");
        System.out.println("");
        System.out.println("[1].- Crear fichero.");
        System.out.println("[2].- Añadir clientes.");
        System.out.println("[3].- Listar clientes.");
        System.out.println("[4].- Eliminar fichero.");
        System.out.println("[5].- Salir.");

        do {
            opcion = ent.nextInt();
        } while (opcion < 1 || opcion > 5);
        return opcion;
    }

    private void creaFichero() {
        File archivo = new File(nombreFichero);
        try {
            if (archivo.exists()) {
                System.out.println("Ya existia el fichero. Borrelo si desea crearlo desde cero.");

            } else {
                if (archivo.createNewFile()) {
                    System.out.println("Archivo " + nombreFichero + " Creado.");
                } else {
                    System.out.println("El archivo ya existe");
                }
            }
        } catch (Exception e) {
            System.out.println("El archivo no se ha creado correctamente");
        }
    }

    private void creaCliente() {
        Cliente cliente = new Cliente();
        //   final String ruta = nombreFichero;
        Scanner ent = new Scanner(System.in);
        ObjectOutputStream escribe = null;
        String continuar;

        try {

            do {
                escribe = new ObjectOutputStream(new FileOutputStream(nombreFichero, true));

                boolean seguir = true;
                do {
                    System.out.println("Introduzca el NIF: ");
                    String nif = ent.nextLine();
                    if (Cliente.compruebaNif(nif)) {
                        cliente.setNIF(nif);
                        seguir = false;
                    }
                } while (seguir); //escribe.writeUnshared(nif);

                System.out.println("Introduzca el Nombre: ");
                String nombre = ent.nextLine();
                cliente.setNombre(nombre);

                System.out.println("Introduzca la Direccion: ");
                String direccion = ent.nextLine();
                cliente.setDireccion(direccion);

                System.out.println("Introduzca el Telefono: ");
                int telefono = ent.nextInt();
                cliente.setTelefono(telefono);

                seguir = true;
                do {
                    System.out.println("Introduzca la deuda: ");
                    double deuda = ent.nextDouble();
                    if (cliente.compruebaDeuda(deuda)) {
                        cliente.setDeuda(deuda);
                        seguir = false;
                    }
                } while (seguir); //escribe.writeUnshared(nif);

                escribe.writeUTF(cliente.getNif());
                escribe.writeUTF(cliente.getNombre());
                escribe.writeUTF(cliente.getDireccion());
                escribe.writeDouble(cliente.getDeuda());
                escribe.writeInt(cliente.getTelefono());

//                escribe.writeObject(cliente);     //para objetos
                escribe.flush();
                System.out.println("Desea continual (S/N): ");
                ent.nextLine();         //duplicado de nextline para limpiar salto de línea del buffer

                continuar = ent.nextLine();
            } while (!continuar.equals("N"));

        } catch (Exception e) {
            System.out.println("Error al escribir en el archivo");
        } finally {
            try {
                if (escribe != null) {
                    escribe.close();
                }
            } catch (IOException ex) {
                System.out.println(ex.getMessage());
            }
        }
    }

    private void litarClientes() {
        ObjectInputStream lee = null;

        File archivo = new File(nombreFichero);

        if (archivo.exists()) {
            try {
                lee = new ObjectInputStream(new FileInputStream(nombreFichero));
                System.out.println("NIF     Nombre  Telefono    Direccion   Deuda");
                while (true) {

                    String nif = lee.readUTF();
                    String nombre = lee.readUTF();
                    String direccion = lee.readUTF();
                    double deuda = lee.readDouble();
                    int telefono = lee.readInt();

                    Cliente cli = new Cliente ( nif, nombre,telefono, direccion, deuda);
                    System.out.print(cli);
                }
            } catch (EOFException e) {
                System.out.println("\n\nFin de fichero alcanzado");
            } catch (IOException e) {
                System.out.println("Error al leer el archivo");
            
            } finally {
                try {
                    if (lee != null) {
                        lee.close();
                    }
                } catch (IOException ex) {
                    System.out.println(ex.getMessage());
                }
            }
        } else {
            System.out.println("El fichero no existe");
        }
    }

//    private void litarClientes() {
//        ObjectInputStream lee = null;
//
//        File archivo = new File(nombreFichero);
//
//        if (archivo.exists()) {
//            try {
//                lee = new ObjectInputStream(new FileInputStream(nombreFichero));
//                System.out.println("NIF     Nombre  Telefono    Direccion   Deuda");             
//                while(true){                    
//                    Cliente cli =  (Cliente) lee.readObject();                    
//                    System.out.print(cli);
//                }
//            }  
//            catch (EOFException e) {
//                System.out.println("\n\nFin de fichero alcanzado");
//            }catch (IOException e) {
//                System.out.println("Error al leer el archivo");
//            } catch (ClassNotFoundException ex) {
//                Logger.getLogger(Gestion.class.getName()).log(Level.SEVERE, null, ex);
//            } finally {
//                try {
//                    if (lee != null) {
//                        lee.close();
//                    }
//                } catch (IOException ex) {
//                    System.out.println(ex.getMessage());
//                }
//            }
//        } else {
//            System.out.println("El fichero no existe");
//        }
//    }
    private void borrarArchivo() {
        File archivo = new File(nombreFichero);

        try {
            if (archivo.exists()) {
                if(archivo.delete()){
                               System.out.println("El archivo fue eliminado.");     
                }else{
                      System.out.println("Problema al borrar el fichero, puede estar en uso.");     
                }
                    

            } else {
                System.out.println("El archivo no existe");
            }
        } catch (Exception e) {
            System.out.println("Error al elimirar el archivo");
        }
    }
}
