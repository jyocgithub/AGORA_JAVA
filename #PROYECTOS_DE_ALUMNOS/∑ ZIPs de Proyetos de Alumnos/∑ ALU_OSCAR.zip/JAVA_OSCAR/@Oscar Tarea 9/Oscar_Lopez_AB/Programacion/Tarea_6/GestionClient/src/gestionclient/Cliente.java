package gestionclient;

import java.io.Serializable;


public class Cliente implements Serializable{
    private String nif;
    private String nombre;
    private int telefono;
    private String direccion;
    private double deuda;
    
    //métodos constructores

    public Cliente(){
    }

    public Cliente(String nif, String nombre, int telefono, String direccion, double deuda) {
        this.nif = nif;
        this.nombre = nombre;
        this.telefono = telefono;
        this.direccion = direccion;
        this.deuda = deuda;
    }
    
   //métodos configuración de variables
    public void setNIF(String nif){
        if(compruebaNif(nif)){
            this.nif = nif;
        }
    }
    public void setNombre(String nombre){
        this.nombre = nombre;
    }
    public void setTelefono(int telefono){
        this.telefono = telefono;
    }
    public void setDireccion(String direccion){
        this.direccion = direccion;
    }
    public void setDeuda(double deuda){
        if(compruebaDeuda(deuda)){
            this.deuda = deuda;
        }
    }

    public String getNif() {
        return nif;
    }

    public String getNombre() {
        return nombre;
    }

    public int getTelefono() {
        return telefono;
    }

    public String getDireccion() {
        return direccion;
    }

    public double getDeuda() {
        return deuda;
    }
   
    //métodos obteción de datos
    public static boolean compruebaNif(String nif){
        if(nif.matches("^[0-9]{8}[A-Za-z]{1}$")){
            return true;
        }
        else return false;
    }
    
    public boolean compruebaDeuda(double deuda){
        return deuda > 0;
    }
    
    @Override
    public String toString(){
        String lectura;
        lectura = this.nif + "\t" + this.nombre + " \t" + this.telefono + "\t    " + this.direccion + "\t" + this.deuda;
        return lectura;
    }
    
    public void datos(){
        
    }

}
