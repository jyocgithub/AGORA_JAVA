package gestionclient;

public class GestionClient {

    public static void main(String[] args) {
        
     Gestion cliente = new Gestion("cliente.dat");
     
     cliente.gestiona();
        
    }
    
}
