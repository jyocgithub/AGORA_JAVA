package pkginterface;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JPasswordField;


public class Ventana extends JFrame{
    JPanel panel;
    JPasswordField pass;
    JButton boton1;
    JButton boton2;
    JButton boton3;
    JButton boton4;
    JButton boton5;
    JButton boton6;
    JButton boton7;
    JButton boton8;
    JButton boton9;
    JButton firmar;
    JButton borrar;
    
    
    public Ventana(){
        panel = new JPanel();
        pass = new JPasswordField(4);
        pass.setBounds(20, 10, 530, 30);
        boton1 = new JButton ("1");
        boton1.setBounds(20, 50, 50, 30);
        boton2 = new JButton ("2");
        boton2.setBounds(80, 50, 50, 30);
        boton3 = new JButton ("3");
        boton3.setBounds(140, 50, 50, 30);
        boton4 = new JButton ("4");
        boton4.setBounds(200, 50, 50, 30);
        boton5 = new JButton ("5");
        boton5.setBounds(260, 50, 50, 30);
        boton6 = new JButton ("6");
        boton6.setBounds(320, 50, 50, 30);
        boton7 = new JButton ("7");
        boton7.setBounds(380, 50, 50, 30);
        boton8 = new JButton ("8");
        boton8.setBounds(440, 50, 50, 30);
        boton9 = new JButton ("9");
        boton9.setBounds(500, 50, 50, 30);
        firmar = new JButton ("Firmar");
        firmar.setBounds(290, 100, 80, 30);
        borrar = new JButton ("Borrar");
        borrar.setBounds(200, 100, 80, 30);
        
        panel.add(pass);
        panel.add(boton1);
        panel.add(boton2);
        panel.add(boton3);
        panel.add(boton4);
        panel.add(boton5);
        panel.add(boton6);
        panel.add(boton7);
        panel.add(boton8);
        panel.add(boton9);
        panel.add(firmar);
        panel.add(borrar);
        
        pack();
        show();
        
        
//        Oyente escucha = new Oyente();
//        borrar.addMouseListener((MouseListener) escucha);
//        firmar.addMouseListener(escucha);
//        boton1.addMouseListener(escucha);
//        boton2.addMouseListener(escucha);
//        boton3.addMouseListener(escucha);
//        boton4.addMouseListener(escucha);
//        boton5.addMouseListener(escucha);
//        boton6.addMouseListener(escucha);
//        boton7.addMouseListener(escucha);
//        boton8.addMouseListener(escucha);
//        boton9.addMouseListener(escucha);
//        
//    }
//    
    
    }
    public static void obtenPuntos(String uno){
        pass.setText(uno);
    }
}
