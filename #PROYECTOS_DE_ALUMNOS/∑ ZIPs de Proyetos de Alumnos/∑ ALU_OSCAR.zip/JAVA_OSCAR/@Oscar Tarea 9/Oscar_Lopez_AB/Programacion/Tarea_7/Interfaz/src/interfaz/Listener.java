package interfaz;

import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import javax.swing.*;

public class Listener  implements MouseListener{
    
    String CLAVE = "1234";
    String almClave = "";

    @Override
    public void mouseClicked(MouseEvent evento) {
        JButton recurso = (JButton)evento.getSource();
        if(recurso.getText().equals("Borrar")){
            JOptionPane.showMessageDialog(recurso, "Borra datos");
            almClave = "";
            Interfaz.obtenPuntos(almClave);
        }
        if(recurso.getText().equals("Firmar")){
            if(almClave.equals(CLAVE)){
                JOptionPane.showMessageDialog(recurso, "Clave correcta");
            }
            else{
                JOptionPane.showMessageDialog(recurso, "Clave incorrecta");
                almClave = "";
                Interfaz.obtenPuntos(almClave);
            }
        }
        if(recurso.getText().equals("1")){
            almClave += "1";
            Interfaz.obtenPuntos(almClave);     //llamada a clase estática externa
            //JOptionPane.showMessageDialog(recurso, "Almacena 1");
        }
        if(recurso.getText().equals("2")){
            almClave += "2";
            Interfaz.obtenPuntos(almClave);     //llamada a clase estática externa
            //JOptionPane.showMessageDialog(recurso, "Almacena 2");
        }
        if(recurso.getText().equals("3")){
            almClave += "3";
            Interfaz.obtenPuntos(almClave);     //llamada a clase estática externa
            //JOptionPane.showMessageDialog(recurso, "Almacena 3");
        }
        if(recurso.getText().equals("4")){
            almClave += "4";
            Interfaz.obtenPuntos(almClave);     //llamada a clase estática externa
            //JOptionPane.showMessageDialog(recurso, "Almacena 4");
        }
        if(recurso.getText().equals("5")){
            almClave += "5";
            Interfaz.obtenPuntos(almClave);     //llamada a clase estática externa
            //JOptionPane.showMessageDialog(recurso, "Almacena 5");
        }
        if(recurso.getText().equals("6")){
            almClave += "6";
            Interfaz.obtenPuntos(almClave);     //llamada a clase estática externa
            //JOptionPane.showMessageDialog(recurso, "Almacena 6");
        }
        if(recurso.getText().equals("7")){
            almClave += "7";
            Interfaz.obtenPuntos(almClave);     //llamada a clase estática externa
            //JOptionPane.showMessageDialog(recurso, "Almacena 7");
        }
        if(recurso.getText().equals("8")){
            almClave += "8";
            Interfaz.obtenPuntos(almClave);     //llamada a clase estática externa
            //JOptionPane.showMessageDialog(recurso, "Almacena 8");
        }
        if(recurso.getText().equals("9")){
            almClave += "9";
            Interfaz.obtenPuntos(almClave);     //llamada a clase estática externa
            //JOptionPane.showMessageDialog(recurso, "Almacena 9");
        }
        System.out.println(almClave);
    }

    @Override
    public void mousePressed(MouseEvent e) {
    }

    @Override
    public void mouseReleased(MouseEvent e) {
    }

    @Override
    public void mouseEntered(MouseEvent e) {
    }

    @Override
    public void mouseExited(MouseEvent e) {
    }
}