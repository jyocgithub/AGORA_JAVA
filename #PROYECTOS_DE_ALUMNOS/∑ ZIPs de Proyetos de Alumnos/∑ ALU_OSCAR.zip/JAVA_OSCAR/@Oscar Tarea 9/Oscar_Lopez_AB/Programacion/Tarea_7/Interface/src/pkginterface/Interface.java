package pkginterface;

import javax.swing.JFrame;


public class Interface {


    public static void main(String[] args) {
        
        Ventana ventana = new Ventana();
        ventana.setTitle("Acceso mediante clave numerica");
        ventana.setSize(600, 200);
        ventana.setVisible(true);
        ventana.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
    }
    
}
