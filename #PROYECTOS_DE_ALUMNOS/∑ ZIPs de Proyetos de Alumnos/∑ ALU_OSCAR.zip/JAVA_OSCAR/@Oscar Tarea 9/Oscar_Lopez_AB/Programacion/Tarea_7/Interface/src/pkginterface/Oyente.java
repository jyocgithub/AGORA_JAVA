package pkginterface;

import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import javax.swing.JButton;
import javax.swing.JOptionPane;


public abstract class Oyente implements ActionListener{

    String CLAVE = "1234";
    String almClave = "";
    
    
    public void MouseEvent(MouseEvent evento){
        JButton recurso = (JButton)evento.getSource();
        if(recurso.getText().equals("Borrar")){
            JOptionPane.showMessageDialog(recurso, "Borra datos");
            almClave = "";
            Ventana.obtenPuntos(almClave);
        }
        if(recurso.getText().equals("Firmar")){
            if(almClave.equals(CLAVE)){
                JOptionPane.showMessageDialog(recurso, "Clave correcta");
            }
            else{
                JOptionPane.showMessageDialog(recurso, "Clave incorrecta");
                almClave = "";
                Ventana.obtenPuntos(almClave);
            }
        }
        if(recurso.getText().equals("1")){
            almClave += "1";
            Ventana.obtenPuntos(almClave);     //llamada a clase estática externa
            //JOptionPane.showMessageDialog(recurso, "Almacena 1");
        }
        if(recurso.getText().equals("2")){
            almClave += "2";
            Ventana.obtenPuntos(almClave);     //llamada a clase estática externa
            //JOptionPane.showMessageDialog(recurso, "Almacena 2");
        }
        if(recurso.getText().equals("3")){
            almClave += "3";
            Ventana.obtenPuntos(almClave);     //llamada a clase estática externa
            //JOptionPane.showMessageDialog(recurso, "Almacena 3");
        }
        if(recurso.getText().equals("4")){
            almClave += "4";
            Ventana.obtenPuntos(almClave);     //llamada a clase estática externa
            //JOptionPane.showMessageDialog(recurso, "Almacena 4");
        }
        if(recurso.getText().equals("5")){
            almClave += "5";
            Ventana.obtenPuntos(almClave);     //llamada a clase estática externa
            //JOptionPane.showMessageDialog(recurso, "Almacena 5");
        }
        if(recurso.getText().equals("6")){
            almClave += "6";
            Ventana.obtenPuntos(almClave);     //llamada a clase estática externa
            //JOptionPane.showMessageDialog(recurso, "Almacena 6");
        }
        if(recurso.getText().equals("7")){
            almClave += "7";
            Ventana.obtenPuntos(almClave);     //llamada a clase estática externa
            //JOptionPane.showMessageDialog(recurso, "Almacena 7");
        }
        if(recurso.getText().equals("8")){
            almClave += "8";
            Ventana.obtenPuntos(almClave);     //llamada a clase estática externa
            //JOptionPane.showMessageDialog(recurso, "Almacena 8");
        }
        if(recurso.getText().equals("9")){
            almClave += "9";
            Ventana.obtenPuntos(almClave);     //llamada a clase estática externa
            //JOptionPane.showMessageDialog(recurso, "Almacena 9");
        }
        System.out.println(almClave);
    }
   
    public void mousePressed(MouseEvent e) {
    }

   
    public void mouseReleased(MouseEvent e) {
    }

    
    public void mouseEntered(MouseEvent e) {
    }

    
    public void mouseExited(MouseEvent e) {
    }
    
    
}
