package interfaz;

import javax.swing.*;

public class Interfaz {

    static JPasswordField pass;
    
    public static void main(String[] args) {
        
        JFrame ventana = new JFrame();
        ventana.setTitle("Acceso mediante clave numerica");          //configura el título de la ventana
        ventana.setSize(600,200);                                     //tamaño de la ventana
        //ventana.setLocation(2000,500);                              //localización de la ventana
        ventana.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);       //cerrar el programa al cerrar la ventana
        ventana.setVisible(true);                                    //hacer la ventana visible
        Emplazamiento(ventana);
    }
    
    private static void Emplazamiento(JFrame ventana){
        //ventana.setLayout(null);

        pass = new JPasswordField(4);
        pass.setBounds(20, 10, 530, 30);
        ventana.add(pass);
        
        JButton boton1 = new JButton("1");
        boton1.setBounds(20, 50, 50, 30);
        ventana.add(boton1);
        
        JButton boton2 = new JButton("2");
        boton2.setBounds(80, 50, 50, 30);
        ventana.add(boton2);
        
        JButton boton3 = new JButton("3");
        boton3.setBounds(140, 50, 50, 30);
        ventana.add(boton3);
        
        JButton boton4 = new JButton("4");
        boton4.setBounds(200, 50, 50, 30);
        ventana.add(boton4);
        
        JButton boton5 = new JButton("5");
        boton5.setBounds(260, 50, 50, 30);
        ventana.add(boton5);
        
        JButton boton6 = new JButton("6");
        boton6.setBounds(320, 50, 50, 30);
        ventana.add(boton6);
        
        JButton boton7 = new JButton("7");
        boton7.setBounds(380, 50, 50, 30);
        ventana.add(boton7);
        
        JButton boton8 = new JButton("8");
        boton8.setBounds(440, 50, 50, 30);
        ventana.add(boton8);
        
        JButton boton9 = new JButton("9");
        boton9.setBounds(500, 50, 50, 30);
        ventana.add(boton9);
        
        JButton borrar = new JButton("Borrar");
        borrar.setBounds(200, 100, 80, 30);
        ventana.add(borrar);
        
        JButton firmar = new JButton("Firmar");
        firmar.setBounds(290, 100, 80, 30);
        ventana.add(firmar);

        
        Listener escucha = new Listener();
        borrar.addMouseListener(escucha);
        firmar.addMouseListener(escucha);
        boton1.addMouseListener(escucha);
        boton2.addMouseListener(escucha);
        boton3.addMouseListener(escucha);
        boton4.addMouseListener(escucha);
        boton5.addMouseListener(escucha);
        boton6.addMouseListener(escucha);
        boton7.addMouseListener(escucha);
        boton8.addMouseListener(escucha);
        boton9.addMouseListener(escucha);
    }
    
    public static void obtenPuntos(String uno){
        pass.setText(uno);
    }
}

