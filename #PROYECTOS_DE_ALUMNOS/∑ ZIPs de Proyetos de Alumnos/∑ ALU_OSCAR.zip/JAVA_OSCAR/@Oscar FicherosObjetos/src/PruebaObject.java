import java.io.*;

/**
 * 
 */

/**
 * @author inaki
 *
 */
public class PruebaObject {

	/**
	 * @param args
	 */
	public static void main(String[] args) throws Exception {

		//		Cliente cli1 = new Cliente("12312312q", "ana", 123, "OCA 1", 123.123);
		//		Cliente cli2 = new Cliente("345345454q", "eva", 345, "OCA 2", 345.345);
		//		Cliente cli3 = new Cliente("78978978k", "ines", 789, "OCA 3", 789.789);
		//
		//		ObjectOutputStream escribe = new ObjectOutputStream(new FileOutputStream("Prueba.dat"));
		//		escribe.writeObject(cli1);
		//		escribe.flush();
		//
		//		escribe.writeObject(cli2);
		//
		//		escribe.flush();
		//		escribe.writeObject(cli3);
		//		escribe.flush();
		//		escribe.close();

		ObjectInputStream leer = new ObjectInputStream(new FileInputStream("cliente.dat"));
		Cliente s1 = (Cliente) leer.readObject();
		System.out.println(s1);

		Cliente s2 = (Cliente) leer.readObject();
		System.out.println(s2);

		Cliente s3 = (Cliente) leer.readObject();
		System.out.println(s3);

	}

}
