/*
 * Universidad Carlos III de Madrid (UC3M)
 * Programacion 2015-2016
 */
package miniciv;

/**
 * One of the players that is playing with MiniCiv.
 * @author Planning and Learning Group (PLG)
 */
public class Player {  
    //NOTE: New fields and methods can be created.
	//ARRAY OF RESOURCES: CONSTANTS.NUM_RESOURCES length
	//ARRAY OF CITIES: CONSTANTS.NUM_PLAYER_CITIES length
	
	//private int settledPopulation; 
	//private int neededPopulation; 
	private int availablePopulation; 
    private int [] resources = new int [6];
	private City [] arrayOfCities = new City[Constants.MAX_PLAYER_CITIES];
	private int id;

	
    /**
     * Constructor of the Player class.
     * @param id Unique identifier.
     */
    public Player(int id){
        System.out.println("**********************************************************NOT IMPLEMENTED Player: Player(int id)");
        this.id=id;
        
        resources = getResources();
        
        ///++ puestos fijos por ahora
    	//settledPopulation = 120;
    	//neededPopulation = 20;
    	//availablePopulation = 20; 
        
        resources [Constants.RS_WOOD] = 1000; //wood
        resources [Constants.RS_GOLD] = 500; //gold
        resources [Constants.RS_FOOD] = 500; //food
        resources [Constants.RS_CULTURE] = 1000; //culture
        resources [Constants.RS_POPULATION_SETTLED] = 0; //population settled
        resources [Constants.RS_POPULATION_NEEDED] = 0; //pop needed
        
    }

    public void setCity (City city){
        arrayOfCities [0] = city;
    }
    
    /**
     * Returns the resources stored by the player.
     * @return Array with all resources stored by the player.
     */
    public int[] getResources(){
        ///++System.out.println("NOT IMPLEMENTED Player: int[] getResources()");
//        
//        resources [Constants.RS_WOOD] = 1000; //wood
//        resources [Constants.RS_GOLD] = 500; //gold
//        resources [Constants.RS_FOOD] = 500; //food
//        resources [Constants.RS_CULTURE] = 1000; //culture
//        resources [Constants.RS_POPULATION_SETTLED] = 0; //population settled
//        resources [Constants.RS_POPULATION_NEEDED] = 0; //pop needed
        
        /*
        NOTE: Each resource must be represented by a certain index of the array:
            Index of wood = 0
            Index of gold = 1
            Index of food = 2;
            Index of culture = 3;
            Index of population = 4;
        */
        return resources;
    }


    /**
     * Returns a city founded by a player.
     * @param idCity Unique identifier of the city to obtain.
     * @return The city which has the unique identifier.
     */
    public City getCity(int idCity){
        System.out.println("NOT IMPLEMENTED Player: City getCity(int idCity)");
        return arrayOfCities[idCity];
    }
    
  
    /**
     * Returns the total available population of the player, which is the difference between the total settled population and the total needed population.
     * @return The total available population of the player.
     */
    public int getPopulationAvailable(){
        ///++ System.out.println("NOT IMPLEMENTED Player: int getPopulationAvailable()");
        //availablePopulation = resources [Constants.RS_POPULATION_SETTLED] - resources [Constants.RS_POPULATION_NEEDED];
        return resources [Constants.RS_POPULATION_SETTLED] - resources [Constants.RS_POPULATION_NEEDED];
    }

    /**
     * Returns the total settled population in the buildings of every city founded by the player.
     * @return The total settled population of the player.
     */
    public int getPopulationSettled(){
        ///++System.out.println("NOT IMPLEMENTED Player: int getPopulationSettled()");
        return resources [Constants.RS_POPULATION_SETTLED];
    }

    /**
     * Returns the total needed population to maintain all constructions working in all cities of the player.
     * @return The total needed population of the player.
     */
    public int getPopulationNeeded(){
        ///++System.out.println("NOT IMPLEMENTED Player: int getPopulationNeeded()");
        return resources [Constants.RS_POPULATION_NEEDED];
    }
    
}
