/*
 * Universidad Carlos III de Madrid (UC3M)
 * Programacion 2015-2016
 */
package miniciv;

/**
 * A city which has several unlocked squares.
 * @author Planning and Learning Group (PLG)
 */
public class City {    
    // NOTE: New fields and methods can be created.
	private String name;
	private int levelBarracks;
	
    /**
     * Constructor for a city that includes the name.
     * @param name The name of the city.
     */
    public City(String name){
        System.out.println("NOT IMPLEMENTED City: City(String name)");

        this.name = name;
        ///++ puesto fijo a ver que sale 
        levelBarracks = 10;
    }    

    /**
     * Returns the name of the city.
     * @return The name of the city.
     */
    public String getName(){
        System.out.println("NOT IMPLEMENTED City: String getName()");
        return name;
    }

    /**
     * Returns the highest level of all barracks of the city.
     * @return The level.
     */
    public int getLevelBarracks(){
        System.out.println("NOT IMPLEMENTED City: int getLevelBarracks()");
        return levelBarracks;
    }

}

