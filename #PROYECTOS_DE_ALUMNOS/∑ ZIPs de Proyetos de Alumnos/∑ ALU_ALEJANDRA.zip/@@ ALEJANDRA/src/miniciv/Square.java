/*
 * Universidad Carlos III de Madrid (UC3M)
 * Programación 2015-2016
 */
package miniciv;

/**
 * One of the cells in which the map of the game is divided.
 * It can represent a construction or a certain terrain without anything built.
 * @author Planning and Learning Group (PLG)
 */
public class Square {
    // NOTE: New fields and methods can be created.
	
	private int id;
	private String nameIcon;
	private int type;
	private boolean locked;
	private int level;
	private byte health;
    private int [] buildingCost;
    private int [] reparationCost;
    private int [] maintenanceCost;
    private int [] resourcesProduced;

    /**
     * The constructor of the square. It receives an int as a parameter to change all
     * characteristics of the square depending on the type.
     * @param idTypeSquare Identifier of the type of the square.
     */
    public Square(int idTypeSquare) {
    	///++        System.out.println("NOT IMPLEMENTED Square: Square(int idTypeSquare)");

    	locked = true;

    	/*NOTE: idTypeSquare must have these values depending on the type of the square:
        Plain = 0;
        Forest = 1;
        Water = 2;
        Mountain = 3;
        Jungle = 4;
	        Barracks = 10;
	        School = 11;    
	        Farm = 12;
	        Mine = 13;
	        Sawmill = 14;
	        Boat = 15;
	        House = 16;
	        Market = 17;

        // For the optional part of creating new buildings/terrains
        Custom 1 = 101;
        Custom 2 = 102;
        Custom 3 = 103;
        Custom 4 = 104;
        Custom 5 = 105;
         */
    	
        
        // LOS ATRIBUTOS ARRAYS ESTAN SOLO DECLARADOS, AQUI LOS CREAMOS REALMENTE, AL SER EL CONSTRUCTOR, ES SU SITIO
        // AUNQUE EL VALOR QUE TENGAN SE LO VA A DAR LOS METODOS getCostsBuild Y SIMILARES DE MAS ABAJO
        buildingCost = new int[Constants.NUM_COSTS];
        reparationCost= new int[Constants.NUM_COSTS];
        maintenanceCost= new int[Constants.NUM_COSTS];
        resourcesProduced= new int[Constants.NUM_COSTS];   // SU TAMAÑO PUEDE SER MENOR PERO ASI NO IMPORTA
     
        
        // DAMOS VALOR AL ATRIBUTO ID
    	id =  idTypeSquare;
    	
    	// EJECUTAMOS CHANGETYPE PARA EL TIPO DE SQUARE QUE SOMOS 
    	// CHANGETYPE SE EJECUTA TAMBIEN CUANDO XXXXXXXXXXXXXXXXX
    	changeType(idTypeSquare);

    	// AL SER EL CONSTRUCTOR, DOY VALOR INICIAL A LEVEL, QUE SEGUN ENUCIADO, DEBE SER 
        level = 0;
        health = 1;
        
        // HAY QUE ANALIZAR DONDE CAMBIA EN EL FUTURO EL LEVEL
 	
    }   

    /**
     * Returns the identifier of the type of this square.
     * @return Identifier of this square.
     */
    public int getType(){
    	///++    System.out.println("NOT IMPLEMENTED Square: int getType()");
        
    	return  id;
    }

    /**
     * Returns the name of the file which has the icon associated to this type of square to be drawn in the interface.
     * @return Name of the icon file of the square.
     */
    public String getNameIcon() {
    	///++    System.out.println("NOT IMPLEMENTED Square: String getNameIcon()");
        return nameIcon;
    }

    /**
     * Returns if the square is locked.
     * @return True if the square is locked and false otherwise.
     */
    public boolean isLocked(){
    	///++    System.out.println("NOT IMPLEMENTED Square: boolean isLocked()");
        return locked;
    }
    
    public void setLocked (boolean locked){
        	this.locked = locked;
    }    

    /**
     * Returns the current level of this square.
     * @return The level of the square.
     */
    public int getLevel(){
    	///++    System.out.println("NOT IMPLEMENTED Square: int getLevel()");
        return level;
    }

    /**
     * Returns the remaining health (hit points) of this construction.
     * @return Real number between 0 and 1 representing the remaining health (hit points) of this construction.
     */
    public float getHealth() {
    	///++    System.out.println("NOT IMPLEMENTED Square: float getHealth()");
        return health;
    }    

    public void setHealth(byte health) {
		this.health = health;
	}

	/**
     * Sets the level of the square to the provided one, if it does not exceed the maximum allowed.
     * @param level The new level for the square.
     */
    public void setLevel(int l) {
    	///++    System.out.println("NOT IMPLEMENTED Square: void setLevel(int level)");
	     if (level>=0 && level<=2){
	    	 level=l;
	     }
    
    }

    /**
     * Returns all construction costs (or upgrading costs) of resources and population for this square, depending on the provided level.
     * @param level The level of the square in which we want to obtain the costs.
     * @return Array of ints with the build costs of every resource and the new population settled and needed by the building.
     */
    public int[] getCostsBuild(int level){
        ///++ System.out.println("NOT IMPLEMENTED Square: int[] getCostsBuild(int level)");
        return buildingCost;
       }

    /**
     * Returns all repairing costs of resources and population for this square.
     * @return Array of ints with the repair costs of every resource and the new population settled and needed 
     * after the reparation of the building.
     */
    public int[] getCostsRepair() {
    	///++ System.out.println("NOT IMPLEMENTED Square: int[] getCostsRepair()");
        return buildingCost;

    }    

    /**
     * Returns all maintenance costs per turn for this square.
     * @return Array of ints with the maintenance costs of every resource per turn.
     */
    public int[] getCostsPerTurn() {
        ///++ System.out.println("NOT IMPLEMENTED Square: int[] getCostsPerTurn()");
        return maintenanceCost; 

    }

    /**
     * Returns all earnings per turn of this square.
     * @return Array of ints with the earnings of every resource per turn.
     */
    public int[] getProductionPerTurn() {
        ///++ System.out.println("NOT IMPLEMENTED Square: int[] getProductionPerTurn()");
        return resourcesProduced; 

    }
    
    public void changeType(int idTypeSquare) {
    
    	///++ System.out.println("NOT IMPLEMENTED Square: void changeType(int idTypeSquare)");

        switch(idTypeSquare){

	        case Constants.TE_PLAIN: { 
	        	nameIcon = "plains.jpg";
	        }break;

	        case Constants.TE_FOREST: {
	        	nameIcon = "forest.png";
	        }break;

	        case Constants.TE_WATER: {
	        	nameIcon = "mar.jpg";
	        }break;

	        case Constants.TE_MOUNTAIN: {
	        	nameIcon = "mountain.png";
	        }break;
	        
	        case Constants.TE_JUNGLE: {
	            nameIcon = "jungle.png";
	        }break;
        
	        case Constants.CO_BARRACKS: {
	
	            nameIcon = "barracks.png";
	            //building
	            buildingCost[Constants.RS_WOOD] = 3000;
	            buildingCost[Constants.RS_GOLD] = 3000;
	            
	            //reparation
	            reparationCost [Constants.RS_WOOD] =  (buildingCost[Constants.RS_WOOD]/2);
	            reparationCost [Constants.RS_GOLD] =  (buildingCost[Constants.RS_GOLD]/2);
	            
	            //maintenance
	            maintenanceCost [Constants.RS_WOOD] = 30;
	            maintenanceCost [Constants.RS_GOLD] = 50;
	            maintenanceCost [Constants.RS_FOOD] = 60;
	            
	            //resources is all zero
	
	        }break;
	        
	        case Constants.CO_SCHOOL: {
	
	            nameIcon = "school.png";
	            
	            //building
	            buildingCost[Constants.RS_WOOD] = 1500;
	            buildingCost[Constants.RS_GOLD] = 1500;
	            
	            //reparation
	            reparationCost [Constants.RS_WOOD] =  (buildingCost[Constants.RS_WOOD]/2);
	            reparationCost [Constants.RS_GOLD] =  (buildingCost[Constants.RS_GOLD]/2);
	            
	            //maintenance
	            maintenanceCost [Constants.RS_WOOD] = 8;
	            maintenanceCost [Constants.RS_GOLD] = 15;
	            maintenanceCost [Constants.RS_FOOD] = 60;
	            
	            //resources
	            resourcesProduced [Constants.RS_CULTURE] = 80;
	            
	
	        }break;
	        
	        case Constants.CO_FARM: {
	
	            nameIcon = "farm.png";
	            
	            //building
	            buildingCost[Constants.RS_WOOD] = 300;
	            buildingCost[Constants.RS_GOLD] = 150;
	            
	            reparationCost [Constants.RS_WOOD] =  (buildingCost[Constants.RS_WOOD]/2);
	            reparationCost [Constants.RS_GOLD] =  (buildingCost[Constants.RS_GOLD]/2);
	            
	            //maintenance
	            maintenanceCost [Constants.RS_WOOD] = 3;
	            maintenanceCost [Constants.RS_GOLD] = 5;
	            
	            //resources
	            resourcesProduced [Constants.RS_FOOD] = 50;
	
	        }break;
	        
	        case Constants.CO_MINE: {
	
	            nameIcon = "mine.png";
	            
	            //building
	            buildingCost[Constants.RS_WOOD] = 200;
	            buildingCost[Constants.RS_GOLD] = 100;
	            
	            //reparation
	            reparationCost [Constants.RS_WOOD] =  (buildingCost[Constants.RS_WOOD]/2);
	            reparationCost [Constants.RS_GOLD] =  (buildingCost[Constants.RS_GOLD]/2);
	            
	            //maintenance
	            maintenanceCost [Constants.RS_WOOD] = 2;
	            maintenanceCost [Constants.RS_FOOD] = 10;
	            
	            //resources
	            resourcesProduced [Constants.RS_GOLD] = 80;
	
	        }break;
	        
	        case Constants.CO_SAWMILL: {
	
	            nameIcon = "sawmill.png";
	            
	            //building
	            buildingCost[Constants.RS_WOOD] = 200;
	            buildingCost[Constants.RS_GOLD] = 100;
	            
	            //reparation
	            reparationCost [Constants.RS_WOOD] =  (buildingCost[Constants.RS_WOOD]/2);
	            reparationCost [Constants.RS_GOLD] =  (buildingCost[Constants.RS_GOLD]/2);
	            
	            //maintenance
	            maintenanceCost [Constants.RS_GOLD] = 2;
	            maintenanceCost [Constants.RS_FOOD] = 10;
	            
	            //resources
	            resourcesProduced [Constants.RS_WOOD] = 80;
	
	        }break;
	        
	        case Constants.CO_BOAT: {
	
	            nameIcon = "boat.png";
	            
	            //building
	            buildingCost[Constants.RS_WOOD] = 400;
	            buildingCost[Constants.RS_GOLD] = 200;
	            
	            //reparation
	            reparationCost [Constants.RS_WOOD] =  (buildingCost[Constants.RS_WOOD]/2);
	            reparationCost [Constants.RS_GOLD] =  (buildingCost[Constants.RS_GOLD]/2);
	            
	            //maintenance
	            maintenanceCost [Constants.RS_WOOD] = 8;
	            maintenanceCost [Constants.RS_GOLD] = 8;
	            
	            //resources
	            resourcesProduced [Constants.RS_FOOD] = 100;
	           
	
	        }break;
	        
	        case Constants.CO_HOUSE: {
	
	            nameIcon = "house.png";
	            
	            //building
	            buildingCost[Constants.RS_WOOD] = 300;
	            buildingCost[Constants.RS_GOLD] = 100;
	            
	            //reparation
	            reparationCost [Constants.RS_WOOD] =  (buildingCost[Constants.RS_WOOD]/2);
	            reparationCost [Constants.RS_GOLD] =  (buildingCost[Constants.RS_GOLD]/2);
	            
	            //maintenance
	            maintenanceCost [Constants.RS_WOOD] = 8;
	            maintenanceCost [Constants.RS_GOLD] = 4;
	            maintenanceCost [Constants.RS_FOOD] = 15;
	            
	            //resources (its all zero)
	       
	            
	        }break;
	        
	        case Constants.CO_MARKET: {
	
	            nameIcon = "market.png";
	            
	          //building
	            buildingCost[Constants.RS_WOOD] = 200;
	            buildingCost[Constants.RS_GOLD] = 100;
	            
	            //reparation
	            reparationCost [Constants.RS_WOOD] =  (buildingCost[Constants.RS_WOOD]/2);
	            reparationCost [Constants.RS_GOLD] =  (buildingCost[Constants.RS_GOLD]/2);
	            
	            //maintenance 
	            maintenanceCost [Constants.RS_FOOD] = 60;
	            
	            //resources
	            resourcesProduced [Constants.RS_WOOD] = 15;
	            resourcesProduced  [Constants.RS_GOLD] = 15;
	           
	
	        }break;

        }
    }
    
    
    
    
}
