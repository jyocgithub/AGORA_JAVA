/*
 * Universidad Carlos III de Madrid (UC3M)
 * Programacion 2015-2016
 */
package miniciv;

/**
 * A game of MiniCiv.
 * @author Planning and Learning Group (PLG)
 */
public class Game {
    // NOTE: New fields and methods can be created.
    
    private Square [][] map;
    private Square [][] originalMap;
    
	private Player [] arrayOfPlayers = new Player [Constants.NUM_PLAYERS];
	private int turnNumberCurrent;
	
    /**
     * Constructor which initializes the game and the map.
     */
    public Game(){   
        ///++ System.out.println("NOT IMPLEMENTED Game: Game()");
        
		Player p1 = new Player(1);
        arrayOfPlayers [0] = p1;
        turnNumberCurrent = 0;

        // Initialize the board
		map = new Square[Constants.MAP_WIDTH][Constants.MAP_HEIGHT];
		originalMap = new Square[Constants.MAP_WIDTH][Constants.MAP_HEIGHT];
		
		// Filling the board with plain.
		for (int ii = 0; ii < Constants.MAP_WIDTH; ii++) {
			for (int jj = 0; jj < Constants.MAP_HEIGHT; jj++) {
				map[ii][jj] = new Square(Constants.TE_PLAIN);
			}
		}

		// Filling other surfaces 
		fillOcean();
		fillJungle();
		fillLake();
		fillMountain();
		fillForest();
		
		
		// create a copy of original map.
		for (int ii = 0; ii < Constants.MAP_WIDTH; ii++) {
			for (int jj = 0; jj < Constants.MAP_HEIGHT; jj++) {
				originalMap[ii][jj] = map[ii][jj];
			}
		}

	}

	public void fillOcean () {

		// We create an int that decides if the Ocean is on the right, left,
		// upper or lower side.
		int randomOceanSide = (int) (Math.random() * 4 + 1);

		// Another one for both sides of the symmetry.
		int randomOceanSide1 = (int) (Math.random() * 2 + 1);

		// Then another for the number of squares on second line of ocean.
		int randomOceanSide2 = (int) (Math.random() * 2 + 5);

		// Finally one that creates ocean in a third line so the number of
		// squares is not more than 20%.
		int randomOceanSide3 = ((Constants.MAP_WIDTH * Constants.MAP_HEIGHT * 20 / 100)
				- (Constants.MAP_WIDTH * Constants.MAP_HEIGHT * 20 / 100 / 2) - 1) - randomOceanSide2;

		switch (randomOceanSide) {

		case 1: {
			for (int ii = 0; ii < Constants.MAP_WIDTH; ii++) {
				map[ii][0] = new Square(Constants.TE_WATER);

			}
			if (randomOceanSide1 == 1) {
				for (int ii = 0; ii < randomOceanSide2; ii++) {
					map[ii][1] = new Square(Constants.TE_WATER);

				}
				for (int ii = 0; ii < randomOceanSide3; ii++) {
					map[ii][2] = new Square(Constants.TE_WATER);
					map[0][3] = new Square(Constants.TE_WATER);
				}
			}

			else {
				for (int ii = 9; ii > randomOceanSide3; ii--) {
					map[ii][1] = new Square(Constants.TE_WATER);

				}
				for (int ii = 9; ii > randomOceanSide2; ii--) {
					map[ii][2] = new Square(Constants.TE_WATER);
					map[9][3] = new Square(Constants.TE_WATER);
				}

			}

		}
			break;

		case 2: {
			for (int ii = 0; ii < Constants.MAP_WIDTH; ii++) {
				map[0][ii] = new Square(Constants.TE_WATER);
			}

			if (randomOceanSide1 == 1) {
				for (int ii = 0; ii < randomOceanSide2; ii++) {
					map[1][ii] = new Square(Constants.TE_WATER);
				}
				for (int ii = 0; ii < randomOceanSide3; ii++) {
					map[2][ii] = new Square(Constants.TE_WATER);
					map[3][0] = new Square(Constants.TE_WATER);

				}
			} else {
				for (int ii = 9; ii > randomOceanSide3; ii--) {
					map[1][ii] = new Square(Constants.TE_WATER);
				}
				for (int ii = 9; ii > randomOceanSide2; ii--) {
					map[2][ii] = new Square(Constants.TE_WATER);
					map[3][9] = new Square(Constants.TE_WATER);

				}
			}

		}
			break;

		case 3: {
			for (int ii = 0; ii < Constants.MAP_WIDTH; ii++) {
				map[ii][9] = new Square(Constants.TE_WATER);

			}
			if (randomOceanSide1 == 1) {
				for (int ii = 0; ii < randomOceanSide2; ii++) {
					map[ii][8] = new Square(Constants.TE_WATER);
				}
				for (int ii = 0; ii < randomOceanSide3; ii++) {
					map[ii][7] = new Square(Constants.TE_WATER);
					map[0][6] = new Square(Constants.TE_WATER);
				}
			} else {
				for (int ii = 9; ii > randomOceanSide3; ii--) {
					map[ii][8] = new Square(Constants.TE_WATER);
				}
				for (int ii = 9; ii > randomOceanSide2; ii--) {
					map[ii][7] = new Square(Constants.TE_WATER);
					map[9][6] = new Square(Constants.TE_WATER);

				}
			}

		}
			break;

		case 4: {
			for (int ii = 0; ii < Constants.MAP_WIDTH; ii++) {
				map[9][ii] = new Square(Constants.TE_WATER);

			}
			if (randomOceanSide1 == 1) {
				for (int ii = 0; ii < randomOceanSide2; ii++) {
					map[8][ii] = new Square(Constants.TE_WATER);
				}
				for (int ii = 0; ii < randomOceanSide3; ii++) {
					map[7][ii] = new Square(Constants.TE_WATER);
					map[6][0] = new Square(Constants.TE_WATER);

				}
			} else {
				for (int ii = 9; ii > randomOceanSide3; ii--) {
					map[8][ii] = new Square(Constants.TE_WATER);
				}
				for (int ii = 9; ii > randomOceanSide2; ii--) {
					map[7][ii] = new Square(Constants.TE_WATER);
					map[6][9] = new Square(Constants.TE_WATER);

				}
			}
		}
			break;

		}

	}

	public void fillLake() {
		boolean bol = true;
		int ii = (int) (Math.random() * Constants.MAP_WIDTH);
		int jj = (int) (Math.random() * Constants.MAP_HEIGHT);
		do {
			if (map[ii][jj].getType() == Constants.TE_PLAIN) {
				map[ii][jj] = new Square(Constants.TE_WATER);
				bol = false;
			}
			else {
				ii = (int) (Math.random() * Constants.MAP_WIDTH);
				jj = (int) (Math.random() * Constants.MAP_HEIGHT);
			}
		} while (bol == true);
	}

	public void fillMountain(){
		int counter = 0;
		int ii = (int) (Math.random() * Constants.MAP_WIDTH);
		int jj = (int) (Math.random() * Constants.MAP_HEIGHT);
		do {
			if (map[ii][jj].getType() == Constants.TE_PLAIN) {
				map[ii][jj] = new Square(Constants.TE_MOUNTAIN);
				counter++;
			}
			else {
				ii = (int) (Math.random() * Constants.MAP_WIDTH);
				jj = (int) (Math.random() * Constants.MAP_HEIGHT);
			}
		} while (counter<(Constants.MAP_WIDTH * Constants.MAP_HEIGHT * 10/100));

	}
	
	public void fillForest(){
		int counter = 0;
		int ii = (int) (Math.random() * Constants.MAP_WIDTH);
		int jj = (int) (Math.random() * Constants.MAP_HEIGHT);
		do {
			if (map[ii][jj].getType() == Constants.TE_PLAIN) {
				map[ii][jj] = new Square(Constants.TE_FOREST);
				counter++;
			}
			else {
				ii = (int) (Math.random() * Constants.MAP_WIDTH);
				jj = (int) (Math.random() * Constants.MAP_HEIGHT);
			}
		} while (counter<(Constants.MAP_WIDTH * Constants.MAP_HEIGHT * 15/100));

	}
	
	public void fillJungle () {


		for (int ii = 1; ii < Constants.MAP_HEIGHT - 1; ii++) {
			for (int jj = 1; jj < Constants.MAP_WIDTH - 1; jj++) {
				if (map[ii][jj].getType() == Constants.TE_PLAIN) {
					if (map[ii + 1][jj].getType() == Constants.TE_WATER) {
						map[ii][jj] = new Square(Constants.TE_JUNGLE);
					}
					if (map[ii - 1][jj].getType() == Constants.TE_WATER) {
						map[ii][jj] = new Square(Constants.TE_JUNGLE);
					}
					if (map[ii][jj + 1].getType() == Constants.TE_WATER) {
						map[ii][jj] = new Square(Constants.TE_JUNGLE);
					}
					if (map[ii][jj - 1].getType() == Constants.TE_WATER) {
						map[ii][jj] = new Square(Constants.TE_JUNGLE);
					}

					if (((map[ii - 1][0]).getType()) == (Constants.TE_PLAIN)
							&& ((map[ii][0]).getType()) == (Constants.TE_WATER)) {
						map[ii - 1][0] = new Square(Constants.TE_JUNGLE);
					}
					if (((map[ii - 1][0]).getType()) == (Constants.TE_WATER)
							&& ((map[ii][0]).getType()) == (Constants.TE_PLAIN)) {
						map[ii][0] = new Square(Constants.TE_JUNGLE);
					}
					if (((map[ii + 1][0]).getType()) == (Constants.TE_PLAIN)
							&& ((map[ii][0]).getType()) == (Constants.TE_WATER)) {
						map[ii + 1][0] = new Square(Constants.TE_JUNGLE);
					}
					if (((map[ii + 1][0]).getType()) == (Constants.TE_WATER)
							&& ((map[ii][0]).getType()) == (Constants.TE_PLAIN)) {
						map[ii][0] = new Square(Constants.TE_JUNGLE);
					}
					if (((map[ii - 1][Constants.MAP_HEIGHT - 1]).getType()) == (Constants.TE_PLAIN)
							&& ((map[ii][Constants.MAP_HEIGHT - 1]).getType()) == (Constants.TE_WATER)) {
						map[ii - 1][Constants.MAP_HEIGHT - 1] = new Square(Constants.TE_JUNGLE);
					}
					if (((map[ii - 1][Constants.MAP_HEIGHT - 1]).getType()) == (Constants.TE_WATER)
							&& ((map[ii][Constants.MAP_HEIGHT - 1]).getType()) == (Constants.TE_PLAIN)) {
						map[ii][Constants.MAP_HEIGHT - 1] = new Square(Constants.TE_JUNGLE);
					}
					if (((map[ii + 1][Constants.MAP_HEIGHT - 1]).getType()) == (Constants.TE_PLAIN)
							&& ((map[ii][Constants.MAP_HEIGHT - 1]).getType()) == (Constants.TE_WATER)) {
						map[ii + 1][Constants.MAP_HEIGHT - 1] = new Square(Constants.TE_JUNGLE);
					}
					if (((map[ii + 1][Constants.MAP_HEIGHT - 1]).getType()) == (Constants.TE_WATER)
							&& ((map[ii][Constants.MAP_HEIGHT - 1]).getType()) == (Constants.TE_PLAIN)) {
						map[ii][Constants.MAP_HEIGHT - 1] = new Square(Constants.TE_JUNGLE);
					}
					if (((map[0][ii - 1]).getType()) == (Constants.TE_PLAIN)
							&& ((map[0][ii]).getType()) == (Constants.TE_WATER)) {
						map[0][ii - 1] = new Square(Constants.TE_JUNGLE);
					}
					if (((map[0][ii - 1]).getType()) == (Constants.TE_WATER)
							&& ((map[0][ii]).getType()) == (Constants.TE_PLAIN)) {
						map[0][ii] = new Square(Constants.TE_JUNGLE);
					}
					if (((map[0][ii + 1]).getType()) == (Constants.TE_PLAIN)
							&& ((map[0][ii]).getType()) == (Constants.TE_WATER)) {
						map[0][ii + 1] = new Square(Constants.TE_JUNGLE);
					}
					if (((map[0][ii + 1]).getType()) == (Constants.TE_WATER)
							&& ((map[0][ii]).getType()) == (Constants.TE_PLAIN)) {
						map[0][ii] = new Square(Constants.TE_JUNGLE);
					}
					if (((map[Constants.MAP_WIDTH - 1][ii - 1]).getType()) == (Constants.TE_PLAIN)
							&& ((map[Constants.MAP_WIDTH - 1][ii]).getType()) == (Constants.TE_WATER)) {
						map[Constants.MAP_WIDTH - 1][ii - 1] = new Square(Constants.TE_JUNGLE);
					}
					if (((map[Constants.MAP_WIDTH - 1][ii - 1]).getType()) == (Constants.TE_WATER)
							&& ((map[Constants.MAP_WIDTH - 1][ii]).getType()) == (Constants.TE_PLAIN)) {
						map[Constants.MAP_WIDTH - 1][ii] = new Square(Constants.TE_JUNGLE);
					}
					if (((map[Constants.MAP_WIDTH - 1][ii + 1]).getType()) == (Constants.TE_PLAIN)
							&& ((map[Constants.MAP_WIDTH - 1][ii]).getType()) == (Constants.TE_WATER)) {
						map[Constants.MAP_WIDTH - 1][ii + 1] = new Square(Constants.TE_JUNGLE);
					}
					if (((map[Constants.MAP_WIDTH - 1][ii + 1]).getType()) == (Constants.TE_WATER)
							&& ((map[Constants.MAP_WIDTH - 1][ii]).getType()) == (Constants.TE_PLAIN)) {
						map[Constants.MAP_WIDTH - 1][ii] = new Square(Constants.TE_JUNGLE);
					}
				}
			}
		}
	}	    
	
	
	/**
     * Returns the current turn number.
     * @return The current turn number.
     */
    public int getTurnNumberCurrent(){
        ///++ System.out.println("NOT IMPLEMENTED Game: int getTurnNumberCurrent()");
        return turnNumberCurrent;
    }

    /**
     * Returns a square of the map.
     * @param x X coordinate of the square to be returned.
     * @param y Y coordinate of the square to be returned.
     * @return The asked square.
     */
    public Square getSquare(int x, int y) {
    	///++    System.out.println("NOT IMPLEMENTED Game: Square getSquare(int x, int y)");
        return map[x][y];
    }

    /**
     * Returns the player with the provided identifier.
     * @param idPlayer Unique identifier of the player.
     * @return The player with the provided identifier.
     */
    public Player getPlayer(int idPlayer) {
        ///++System.out.println("NOT IMPLEMENTED Game: Player getPlayer(int idPlayer)");
        return arrayOfPlayers[0];
    }

    /**
     * Founds a new city, unlocking the selected square and the 8 squares around it (if they exist).
     * @param idPlayer The identifier of the player who wants to found a new city.
     * @param nameCity The name of the new city.
     * @param x X coordinate of the square in which the player wants to found the city.
     * @param y Y coordinate of the square in which the player wants to found the city.
     */
    public void foundCity(int idPlayer, String nameCity, int x, int y) {
    	///++ System.out.println("NOT IMPLEMENTED Game: void foundCity(int idPlayer, String nameCity, int x, int y)");
        
        City c1 = new City (nameCity);
        arrayOfPlayers [0].setCity(c1);
                
        // unblock every square around the selected
        // CENTER
        if ((x<Constants.MAP_WIDTH-1 && x>0)&&(y<Constants.MAP_HEIGHT-1 && y>0)){
    		map [x][y].setLocked(false);
    		map [x+1][y].setLocked(false);
    		map [x-1][y].setLocked(false);
    		map [x][y+1].setLocked(false);
    		map [x][y-1].setLocked(false);
    		map [x+1][y+1].setLocked(false);
    		map [x-1][y-1].setLocked(false);
    		map [x+1][y-1].setLocked(false);
    		map [x-1][y+1].setLocked(false);
    	}
        
        // TOP LEFT CORNER
    	else if (x==0 && y==0){
    		map [x][y].setLocked(false);
    		map [x+1][y].setLocked(false);
    		map [x][y+1].setLocked(false);
    		map [x+1][y+1].setLocked(false);
    	}
  		// TOP NO CORNER
      	else if (x>0 && x<Constants.MAP_WIDTH-1 && y==0){
      		map [x][y].setLocked(false);
      		map [x+1][y].setLocked(false);
      		map [x-1][y].setLocked(false);
      		map [x][y+1].setLocked(false);
      		map [x+1][y+1].setLocked(false);
      		map [x-1][y+1].setLocked(false);	
      	}
        // TOP RIGHT CORNER
    	else if (x==Constants.MAP_WIDTH-1 && y==0){
    		map [x][y].setLocked(false);
    		map [x-1][y].setLocked(false);
    		map [x][y+1].setLocked(false);
    		map [x-1][y+1].setLocked(false);
    	}
        
        // BOTTOM LEFT CORNER
    	else if ((x==0)&&(y==Constants.MAP_HEIGHT-1)){
    		map [x][y].setLocked(false);
    		map [x][y-1].setLocked(false);
    		map [x+1][y].setLocked(false);
    		map [x+1][y-1].setLocked(false);
    	}
        // BOTTOM NO CORNER
    	else if ((x<Constants.MAP_WIDTH-1 && x>0)&& y==Constants.MAP_HEIGHT-1){
    		map [x][y].setLocked(false);
    		map [x+1][y].setLocked(false);
    		map [x-1][y].setLocked(false);
    		map [x][y-1].setLocked(false);
    		map [x-1][y-1].setLocked(false);
    		map [x+1][y-1].setLocked(false);
    	}
        // BOTTOM RIGHT CORNER
    	else if ((x==Constants.MAP_WIDTH-1)&&(y==Constants.MAP_HEIGHT-1)){
    		map [x][y].setLocked(false);
    		map [x-1][y].setLocked(false);
    		map [x-1][y-1].setLocked(false);
    		map [x][y-1].setLocked(false);
    	}

        // LEFT NO CORNER
    	else if (x==0 && y<Constants.MAP_HEIGHT-1 && y>0){
    		map [x][y].setLocked(false);
    		map [x][y-1].setLocked(false);
    		map [x][y+1].setLocked(false);
    		map [x+1][y].setLocked(false);
    		map [x+1][y-1].setLocked(false);
    		map [x+1][y+1].setLocked(false);
    	}

        // RIGHT NO CORNER
    	else if ((x==Constants.MAP_WIDTH-1)&& y<Constants.MAP_HEIGHT-1 && y>0){
    		map [x][y].setLocked(false);
    		map [x][y+1].setLocked(false);
    		map [x][y-1].setLocked(false);
    		map [x-1][y].setLocked(false);
    		map [x-1][y+1].setLocked(false);
    		map [x-1][y-1].setLocked(false);
    	}
    }   
    
    /**
     * Checks if a player can build something in a certain square if he has enough resources.
     * @param player The player who wants to build.
     * @param square The square in which the player wants to build the construction.
     * @param idConstruction The type of construction that the player wants to build.
     * @return True in case that he can and false otherwise.
     */
    public boolean canBuild(Player player, Square square, int idConstruction) {
        ///++System.out.println("NOT IMPLEMENTED Game: boolean canBuild(Player player, Square square, int idConstruction)");
 
    	// Checks if it is possible to build in this square the indicated construction type and if the player has enough
        //resources and available population to build.
        boolean can = false;
        
        
        if (square.isLocked()) return false;
        
        int [] resources = player.getResources();
        int [] costsToBuild = square.getCostsBuild(square.getLevel());
        int n =0;

        if (square.getType()== Constants.TE_PLAIN){  //square represents map[ii][jj]
        	if ( idConstruction == Constants.CO_HOUSE || idConstruction == Constants.CO_FARM || idConstruction == Constants.CO_SCHOOL || 
        			idConstruction == Constants.CO_MARKET || idConstruction == Constants.CO_BARRACKS){
        		for( int ii = 0; ii<resources.length; ii++){
        			if( resources[ii]>= costsToBuild[ii] ){ can = true; }
        			else if(can == false){ n++;}}
        		if (n>=1){ can = false;}
        		else { can = true; }}
        	else { can = false;} 
        }

        else if (square.getType()== Constants.TE_WATER){
        	if ( idConstruction == Constants.CO_BOAT){
        		for( int ii = 0; ii<resources.length; ii++){
        			if( resources[ii]>= costsToBuild[ii] ){ can = true; }
        			else if(can == false){ n++;}}
        		if (n>=1){ can = false;}
        		else { can = true; }}
        	else { can = false;} 
        }

        else if (square.getType()== Constants.TE_FOREST){
        	if ( idConstruction == Constants.CO_HOUSE || idConstruction == Constants.CO_SAWMILL){
        		for( int ii = 0; ii<resources.length; ii++){
        			if( resources[ii]>= costsToBuild[ii] ){ can = true; }
        			else if(can == false){ n++;}}
        		if (n>=1){ can = false;}
        		else { can = true; }}
        	else { can = false;} 
        }

        else if (square.getType()== Constants.TE_MOUNTAIN){
        	if ( idConstruction == Constants.CO_HOUSE || idConstruction == Constants.CO_MINE || idConstruction == Constants.CO_BARRACKS){
        		for( int ii = 0; ii<resources.length; ii++){
        			if( resources[ii]>= costsToBuild[ii] ){ can = true; }
        			else if(can == false){ n++;}}
        		if (n>=1){ can = false;}
        		else { can = true; }}
        	else { can = false;} 
        }

        else if (square.getType()== Constants.TE_JUNGLE){
        	can = false;
        }

        else {
        	can = false; }
        return can;

    }
   
    /**
     * Builds a construction in a certain square for a player.
     * @param player The player who wants to build.
     * @param square The square in which the player wants to build the construction.
     * @param idConstruction The type of construction that the player wants to build.
     */
    public void build(Player player, Square square, int idConstruction) {
        System.out.println("NOT IMPLEMENTED Game: void build(Player player, Square square, int idConstruction)");
        
        	int [] actualresources = player.getResources();
            int [] costsToBuild = square.getCostsBuild(square.getLevel());
                  
        	switch (idConstruction) {
        	case Constants.CO_MARKET:{
            	square.changeType(Constants.CO_MARKET);
     		} break;
    		case Constants.CO_HOUSE:{
    			square.changeType(Constants.CO_HOUSE);
    		} break;
    		case Constants.CO_BOAT:{
    			square.changeType(Constants.CO_BOAT);
    		} break;
    		case Constants.CO_SAWMILL:{
    			square.changeType(Constants.CO_SAWMILL);
    		} break;
    		case Constants.CO_MINE:{
                //square.changeType(Constants.CO_MINE);
    			square.changeType(Constants.CO_MINE);
    		} break;
    		case Constants.CO_FARM:{
               //	square.changeType(Constants.CO_MINE);
    			square.changeType(Constants.CO_FARM);
    		} break;
    		case Constants.CO_SCHOOL:{
              //  square.changeType(Constants.CO_MINE);
    			square.changeType(Constants.CO_SCHOOL);
    		} break;
    		case Constants.CO_BARRACKS:{
    			square.changeType(Constants.CO_BARRACKS);
    		} break;
    		
        	}	
     		
        	switch (idConstruction) {
        	case Constants.CO_MARKET:{
            	actualresources[Constants.RS_WOOD] = actualresources[Constants.RS_WOOD] - costsToBuild[Constants.RS_WOOD];
    			actualresources[Constants.RS_GOLD] = actualresources[Constants.RS_GOLD] - costsToBuild[Constants.RS_GOLD];
    			actualresources[Constants.RS_POPULATION_SETTLED] = actualresources[Constants.RS_POPULATION_SETTLED]
    					- costsToBuild[Constants.RS_POPULATION_NEEDED];
    		} break;
    		case Constants.CO_HOUSE:{
    			actualresources[Constants.RS_WOOD] = actualresources[Constants.RS_WOOD] - costsToBuild[Constants.RS_WOOD];
    			actualresources[Constants.RS_GOLD] = actualresources[Constants.RS_GOLD] - costsToBuild[Constants.RS_GOLD];
    			
    			actualresources[Constants.RS_POPULATION_SETTLED] = actualresources[Constants.RS_POPULATION_SETTLED]+30;
    			
    		
    		} break;
    		case Constants.CO_BOAT:{
    			actualresources[Constants.RS_WOOD] = actualresources[Constants.RS_WOOD] - costsToBuild[Constants.RS_WOOD];
    			actualresources[Constants.RS_GOLD] = actualresources[Constants.RS_GOLD] - costsToBuild[Constants.RS_GOLD];
    			actualresources[Constants.RS_POPULATION_SETTLED] = actualresources[Constants.RS_POPULATION_SETTLED]
    					- costsToBuild[Constants.RS_POPULATION_NEEDED];
    		} break;
    		case Constants.CO_SAWMILL:{
    			actualresources[Constants.RS_WOOD] = actualresources[Constants.RS_WOOD] - costsToBuild[Constants.RS_WOOD];
    			actualresources[Constants.RS_GOLD] = actualresources[Constants.RS_GOLD] - costsToBuild[Constants.RS_GOLD];
    			actualresources[Constants.RS_POPULATION_SETTLED] = actualresources[Constants.RS_POPULATION_SETTLED]
    					- costsToBuild[Constants.RS_POPULATION_NEEDED];
    		} break;
    		case Constants.CO_MINE:{
    			actualresources[Constants.RS_WOOD] = actualresources[Constants.RS_WOOD] - costsToBuild[Constants.RS_WOOD];
    			actualresources[Constants.RS_GOLD] = actualresources[Constants.RS_GOLD] - costsToBuild[Constants.RS_GOLD];
    			actualresources[Constants.RS_POPULATION_SETTLED] = actualresources[Constants.RS_POPULATION_SETTLED]
    					- costsToBuild[Constants.RS_POPULATION_NEEDED];
    		} break;
    		case Constants.CO_FARM:{
    			actualresources[Constants.RS_WOOD] = actualresources[Constants.RS_WOOD] - costsToBuild[Constants.RS_WOOD];
    			actualresources[Constants.RS_GOLD] = actualresources[Constants.RS_GOLD] - costsToBuild[Constants.RS_GOLD];
    			actualresources[Constants.RS_POPULATION_SETTLED] = actualresources[Constants.RS_POPULATION_SETTLED]
    					- costsToBuild[Constants.RS_POPULATION_NEEDED];
    		} break;
    		case Constants.CO_SCHOOL:{
    			actualresources[Constants.RS_WOOD] = actualresources[Constants.RS_WOOD] - costsToBuild[Constants.RS_WOOD];
    			actualresources[Constants.RS_GOLD] = actualresources[Constants.RS_GOLD] - costsToBuild[Constants.RS_GOLD];
    			actualresources[Constants.RS_POPULATION_SETTLED] = actualresources[Constants.RS_POPULATION_SETTLED]
    					- costsToBuild[Constants.RS_POPULATION_NEEDED];
    		} break;
    		case Constants.CO_BARRACKS:{
    			actualresources[Constants.RS_WOOD] = actualresources[Constants.RS_WOOD] - costsToBuild[Constants.RS_WOOD];
    			actualresources[Constants.RS_GOLD] = actualresources[Constants.RS_GOLD] - costsToBuild[Constants.RS_GOLD];
    			actualresources[Constants.RS_POPULATION_SETTLED] = actualresources[Constants.RS_POPULATION_SETTLED]
    					- costsToBuild[Constants.RS_POPULATION_NEEDED];
    		} break;
        	}
  	
    }
    
    

    /**
     * Destroys the previous construction, reverting the square to the original terrain before the building.
     * @param x X coordinate of the square with the construction that the player wants to demolish.
     * @param y Y coordinate of the square with the construction that the player wants to demolish.
     */
    public void destroyConstruction(int x, int y){
        System.out.println("NOT IMPLEMENTED Game: void destroyConstruction(int x, int y)");
        if  ( (map[x][y].getType()==Constants.CO_FARM) ||
				(map[x][y].getType()==Constants.CO_MARKET) ||
				(map[x][y].getType()==Constants.CO_HOUSE) ||
				(map[x][y].getType()==Constants.CO_BOAT) ||
				(map[x][y].getType()==Constants.CO_SAWMILL) ||
				(map[x][y].getType()==Constants.CO_MINE) ||
				(map[x][y].getType()==Constants.CO_FARM) ||
				(map[x][y].getType()==Constants.CO_SCHOOL) ||
				(map[x][y].getType()==Constants.CO_BARRACKS) ){
        	     map[x][y] = originalMap[x][y];
        }
    } 
    /**
     * Checks if a city can expand its border to a certain square.
     * @param player The player who wants to expand the border.
     * @param nameCity The name of the city which wants to annex the new square.
     * @param x X coordinate of the square that the player wants to annex.
     * @param y Y coordinate of the square that the player wants to annex.
     * @return True in case that he can and false otherwise.
     */
    public boolean canExpandBorder(Player player, String nameCity, int x, int y) {        
        System.out.println("NOT IMPLEMENTED Game: boolean canExpandBorder(Player player, String nameCity, int x, int y)");        
        
        
        // if the actual square is in the city, return false 
        if (!map [x][y].isLocked()) return false;
             
        // Check if the player has enough resources to expand the border.        
        // SEEMS TO BE NECESARY 1500 CULTURE UNITS TO EXPAND  
        int [] actualresources = player.getResources();
        
        
        
        if (actualresources [Constants.RS_CULTURE]<1500   )   	return false;
     
        
        // Check if the square that we want to expand is adjacent to other of the city "nameCity". 
        // Squares in diagonal are not valid.
        // see if there is unblocked square around a square selected (a square in a city)
        // CENTER
    	if ((x<Constants.MAP_WIDTH-1 && x>0)&&(y<Constants.MAP_HEIGHT-1 && y>0)){
        	// If a square up or down or left or right is unlocked, return true 
      		if  (  	(!map [x][y-1].isLocked()) ||
    				(!map [x][y+1].isLocked()) ||
    				(!map [x+1][y].isLocked()) ||
    				(!map [x-1][y].isLocked()))	return true;
    	}
        // TOP LEFT CORNER
    	else if (x==0 && y==0){
      		if  (  	(!map [x][y+1].isLocked()) ||
    				(!map [x+1][y].isLocked()))	return true;
    	}
  		// TOP NO CORNER
      	else if (x>0 && x<Constants.MAP_WIDTH-1 && y==0){
      		if  (   (!map [x][y+1].isLocked()) ||
    				(!map [x+1][y].isLocked()) ||
    	     		(!map [x-1][y].isLocked()))	return true;
      	}
        // TOP RIGHT CORNER
    	else if (x==Constants.MAP_WIDTH-1 && y==0){
      		if  (  	(!map [x][y+1].isLocked()) ||
    				(!map [x-1][y].isLocked()))	return true;
    	}
        
        // BOTTOM LEFT CORNER
    	else if ((x==0)&&(y==Constants.MAP_HEIGHT-1)){
      		if  (  	(!map [x][y-1].isLocked()) ||
    				(!map [x+1][y].isLocked()) )	return true;
    	}
        // BOTTOM NO CORNER
    	else if ((x<Constants.MAP_WIDTH-1 && x>0)&& y==Constants.MAP_HEIGHT-1){
      		if  (  	(!map [x][y-1].isLocked()) ||
    				(!map [x+1][y].isLocked()) ||
    				(!map [x-1][y].isLocked()))	return true;
    	}
        // BOTTOM RIGHT CORNER
    	else if ((x==Constants.MAP_WIDTH-1)&&(y==Constants.MAP_HEIGHT-1)){
      		if  (  	(!map [x][y-1].isLocked()) ||
    				(!map [x-1][y].isLocked()))	return true;
    	}

        // LEFT NO CORNER
    	else if (x==0 && y<Constants.MAP_HEIGHT-1 && y>0){
      		if  (  	 (!map [x][y-1].isLocked()) ||
    				 (!map [x][y+1].isLocked()) ||
    				 (!map [x+1][y].isLocked())) return true;    	
    	}
        // RIGHT NO CORNER
    	else if ((x==Constants.MAP_WIDTH-1)&& y<Constants.MAP_HEIGHT-1 && y>0){
      		if  (  	 (!map [x][y-1].isLocked()) ||
    				 (!map [x][y+1].isLocked()) ||
    				 (!map [x-1][y].isLocked()))	return true;
    	}
        
        return false;
    }

    
    
    
    /**
     * Expand the border of a city by annexing a locked square.
     * @param player The player who wants to expand the border.
     * @param nameCity The name of the city which wants to annex the new square.
     * @param x X coordinate of the square that the player wants to annex.
     * @param y Y coordinate of the square that the player wants to annex.
     */
    public void expandBorder(Player player, String nameCity, int x, int y) {
        System.out.println("NOT IMPLEMENTED Game: void expandBorder(Player player, String nameCity, int x, int y)");
  
        this.getSquare(x, y).setLocked(false);
        int [] res = player.getResources();
        
        //loosing 1500 at expanding 
        res[Constants.RS_CULTURE] -= Constants.COST_EXPAND_SQUARE;

        
    }        

    
    
    /**
     * Checks if a player can upgrade the level of a construction in a certain square if he has enough resources.
     * @param player The player who wants to upgrade.
     * @param square The square in which the player wants to upgrade the construction.
     * @return True in case that he can and false otherwise.
     */
    public boolean canUpgradeLevel(Player player, Square square){
        System.out.println("NOT IMPLEMENTED Game: boolean canUpgradeLevel(Player player, Square square)");
        // Check if the construction can be upgraded.
        // Check if the player has enough resources and available population to upgrade the construction.
        return false;
    }

    /**
     * Upgrades the level of a construction in a certain square if the player has enough resources.
     * @param player The player who wants to upgrade.
     * @param square The square in which the player wants to upgrade the construction.
     */
    public void upgradeLevel(Player player, Square square){
        System.out.println("NOT IMPLEMENTED Game: void upgradeLevel(Player player, Square square)");    
    }
    
    /**
     * Checks if a player can repair something in a certain square if he has enough resources.
     * @param player The player who wants to repair.
     * @param square The square in which the player wants to repair the construction.
     * @return True in case that he can and false otherwise.
     */
    public boolean canRepair(Player player, Square square) {
        System.out.println("NOT IMPLEMENTED Game: boolean canRepair(Player player, Square square)");
        // Check if the construction can be repaired.
        // Check if the player has enough resources and available population to repair the construction.
        return false;
    }
    
    /**
     * Repairs something in a certain square if the player has enough resources.
     * @param player The player who wants to repair.
     * @param square The square in which the player wants to repair the construction.
     */
    public void repair(Player player, Square square) {
        System.out.println("NOT IMPLEMENTED Game: void repair(Player player, Square square)");
    }

    /**
     * Checks if the player has a construction with the maximum level in every buildable square of the map.
     * @param player The player to check if he has reached the global domination.
     * @return True in case that he has the global domination and false otherwise.
     */
    public boolean isGlobalDomination(Player player){
        System.out.println("NOT IMPLEMENTED Game: boolean isGlobalDomination(Player player)");
        return false;
    }

    /**
     * Executes a turn.
     * @return Identifier of the situation which indicates if the game continues or the type of victory/defeat.
     */
    /*
    NOTE: The return value of this method tells the interface if the game continues or if some end-game condition has been achieved.
    These are the values that this method must return, depending on the situation:
        The game continues = 0;
        The player loses because the available population is too low = 1;
        The player loses because the gold is too low = 11;
        The player loses because the wood is too low = 12;
        The player loses because the food is too low = 13;
        The player wins by global domination = 14;
    */
    public int executeTurn(){
        System.out.println("NOT IMPLEMENTED Game: int executeTurn()");
        turnNumberCurrent++;
        
        // Check victory conditions.
        
        
        // Determine damage to constructions.
        
//        Each turn there is a certain probability that the city receives an external attack (pCityAttack). If there are no
//        barracks this probability is 0.5. If there are barracks the probability is calculated as follows (Formula 3), where
//        barracksLevel and barracksHealth correspond to the barracks with the highest values.
//        pCityAttack = (ver en el pdf)
//        Even if the city is attacked not all the buildings are damaged. The probability that a building is damaged is
//        0.5, and can be reduced if there are barracks, according to Formula 4, where barracksLevel corresponds to the
//        barracks with the highest value.
//        pBuildingAttack =       0.5       barracksLevel − buildingLevel + 3 
//        If a building is damaged, the total damage will be a random value lower than 40% of its current health.

        
        int [] recursos = arrayOfPlayers[0].getResources();

        // ATTACKS
        // calculate how many barracks there are
        int numOfBarracks = 0, maxHealthInBarracks= 0, maxLevelInBarracks = 0;
        
    	for (int ii = 0; ii < Constants.MAP_WIDTH; ii++) {
			for (int jj = 0; jj < Constants.MAP_HEIGHT; jj++) {
				if (map[ii][jj].getType() == Constants.CO_BARRACKS ) {
					numOfBarracks ++ ;
					if (map[ii][jj].getHealth() > maxHealthInBarracks) maxHealthInBarracks = (int) map[ii][jj].getHealth();
					if (map[ii][jj].getLevel() > maxLevelInBarracks) maxLevelInBarracks = (int) map[ii][jj].getLevel();
				}
			}
		}
        
    	double pCityAttack = 0.0;
        if (numOfBarracks==0){
        	pCityAttack = Constants.PROBABILITY_ATTACK;
        } else{
        	pCityAttack = (0.5) /  (maxLevelInBarracks + 1) * (maxHealthInBarracks + 1); 
        }
        
        int rand = (int) ((Math.random() * 100) + 1);
        boolean cityAttacked = false;
        if (rand < Constants.PROBABILITY_ATTACK) cityAttacked = true;
        
        // Count the population again after the attacks.
        
        // Add earnings and subtract maintenance costs.
        for (int ii = 0; ii < Constants.MAP_WIDTH; ii++) {
			for (int jj = 0; jj < Constants.MAP_HEIGHT; jj++) {
				
				// is a square with building
				if  ( (map[ii][jj].getType()==Constants.CO_FARM) ||
						(map[ii][jj].getType()==Constants.CO_MARKET) ||
						(map[ii][jj].getType()==Constants.CO_HOUSE) ||
						(map[ii][jj].getType()==Constants.CO_BOAT) ||
						(map[ii][jj].getType()==Constants.CO_SAWMILL) ||
						(map[ii][jj].getType()==Constants.CO_MINE) ||
						(map[ii][jj].getType()==Constants.CO_FARM) ||
						(map[ii][jj].getType()==Constants.CO_SCHOOL) ||
						(map[ii][jj].getType()==Constants.CO_BARRACKS) ){
								// is a attack in the city
								if (cityAttacked) {
									int rand2 = (int) ((Math.random() * 100) + 1);
								    boolean buildingAttacked = false;
								    if (rand2 < Constants.PROBABILITY_DAMAGE_CONSTRUCTION) buildingAttacked = true;
									// is a square with attack
								    if (buildingAttacked){
										byte rand3 = (byte) ((Math.random() * 40) + 1);
										byte healthAntigua = (byte) (map[ii][jj].getHealth());
										byte perdida = (byte) (healthAntigua /100 * rand3)   ;
										byte newHealth = perdida  ;
									    map[ii][jj].setHealth(newHealth);
								    }
							}
				}
				
		        int [] producido = map[ii][jj].getProductionPerTurn();
				recursos[Constants.RS_CULTURE] += producido [Constants.RS_CULTURE] ;
				recursos[Constants.RS_WOOD] += producido [Constants.RS_WOOD] ;
				recursos[Constants.RS_FOOD] += producido [Constants.RS_FOOD] ;
				recursos[Constants.RS_GOLD] += producido [Constants.RS_GOLD] ;

		        int [] consumido = map[ii][jj].getCostsPerTurn();
				recursos[Constants.RS_CULTURE] -= consumido [Constants.RS_CULTURE] ;
				recursos[Constants.RS_WOOD] -= consumido [Constants.RS_WOOD] ;
				recursos[Constants.RS_FOOD] -= consumido [Constants.RS_FOOD] ;
				recursos[Constants.RS_GOLD] -= consumido [Constants.RS_GOLD] ;
			}
		}	
        
        // Everything ends is 
        // the quantity of any of the basic resources (gold, wood or food) is lower than 100.
        if  ( (recursos[Constants.RS_GOLD]<100)){
        	return Constants.END_GOLD;
        }else if ( (recursos[Constants.RS_WOOD]<100)){
        	return Constants.END_WOOD;
        } else if ( (recursos[Constants.RS_FOOD]<100)){
        	return Constants.END_FOOD;
        }
        return 0;
    }
}
