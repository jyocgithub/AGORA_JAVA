package miniciv;

public class Info {
//1st - Generate the map.
//2nd - City/Player - Resources bar.
// Square class - exceptions
// costs in square arrays of integers
	
	
	
	//quitar los comentqrios a los syso
}
