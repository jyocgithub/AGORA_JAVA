package practica1eval;

import practica1eval.dao.FileBDAlumnoDAO;
import practica1eval.model.Alumno;
import practica1eval.dao.XMLBDAlumnoDAO;

import org.w3c.dom.Document;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class CPrincipalPractica
{
	public static FileBDAlumnoDAO bd = null;
	public static Map<String, Alumno> hm = new HashMap<>();
	public static Scanner sc = new Scanner(System.in);

	public static void main(String[] args)
	{

		bd = new FileBDAlumnoDAO("alumnosDAO.txt");

		menu();

		/*//Crear un XML --- NO FUNCIONA
		 *
		 * HashMap<String, String> map = new HashMap<>();
		 * map = bd.devuelveAlumnos();
		 *
		 * System.out.println("Nombre del XML:");
		 * String nombreXML = sc.nextLine();
		 *
		 * Document documento = XMLBDAlumnoDAO.crearDocumento(map, nombreXML);
		 * XMLBDAlumnoDAO.guardarDocumentoDOMcomoXML(documento, nombreXML + ".xml");
		 *
		 * sc.close();
		 *
		 */
	}

	private static void menu()
	{
		boolean salir = false;
		String opc = "";
		String nombre = "";
		String DNI = "";

		do{
			System.out.println("1.- Insertar alumno" + "\n"
							+ "2.- Borrar alumno" + "\n"
							+ "3.- Buscar alumno" + "\n"
							+ "4.- Modificar alumno" + "\n"
							+ "5.- Listar alumnos" + "\n"
							+ "6.- Salir");
			System.out.print(">");
			opc = sc.nextLine();
			System.out.println();

			switch(opc)
			{
				case "1":	System.out.print("Nombre: ");
							nombre = sc.nextLine();
							System.out.print("DNI: ");
							DNI = sc.nextLine();
							System.out.println();

							bd.insertaAlumno(new Alumno(DNI,nombre));
					break;
				case "2":	System.out.println("\nIntroduce DNI del alumno a borrar: ");
				 			DNI = sc.nextLine();
				 			System.out.println();

				 			if(bd.borraAlumno(DNI) != null)
				 			{
				 				System.out.println("El alumno " +(bd.borraAlumno(DNI)).getNombre() + " ha sido borrado\n");
				 			}
				 			else System.out.println("El alumno no se ha borrado\n");
					break;
				case "3":	System.out.println("\nIntroduce DNI del alumno a buscar: ");
	 						DNI = sc.nextLine();
	 						System.out.println();

	 						if(bd.buscaAlumno(DNI) != null)
	 						{
	 							System.out.println("\nEl alumno " + (bd.buscaAlumno(DNI)).getNombre() + " est� en el Fichero");
	 						}
	 						else System.out.println("\nEl alumno no se encuentra en el fichero");
					break;
				case "4":	System.out.println("\nIntroduce DNI del alumno a modificar: ");
							DNI = sc.nextLine();
							System.out.println();

							System.out.println("\nNuevo nombre: ");
							nombre = sc.nextLine();
							System.out.println();

							if(bd.modificaAlumno(DNI, new Alumno(DNI,nombre)))
							{
								System.out.println("\nLos datos del alumno se han modificado con exito\n");
							}
							else System.out.println("\nLos datos no se han podido modificar\n");
					break;
				case "5":	mostrarFichero(bd);
					break;
				case "6":	System.out.println("Fin del programa\n");
					salir = true;
					break;
				default: System.out.println("Opcion incorrecta");
						 System.out.println();
			}

		}while(!salir);
	}

	private static void mostrarFichero(FileBDAlumnoDAO f)
	{
		hm = f.listadoMapAlumnos();

		if(!hm.isEmpty())
		{
			for (String DNI : hm.keySet())
			{
				System.out.println(DNI + "#" + (hm.get(DNI)).getNombre());
			}
		}
		else System.out.println("No hay alumnos");

		System.out.println();
	}

	private static void mostrarAlumno(Alumno alumno)
	{
		if(alumno != null)
			System.out.println("Nombre: " + alumno.getNombre() + "\nDNI: " + alumno.getDni() + "\n");

		else System.out.println("No existe alumno con ese DNI\n");
	}
}
