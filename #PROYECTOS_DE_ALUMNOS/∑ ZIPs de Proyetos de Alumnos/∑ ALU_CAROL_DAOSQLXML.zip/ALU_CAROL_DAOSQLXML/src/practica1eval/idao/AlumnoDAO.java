package practica1eval.idao;

import java.util.List;
import java.util.Map;

import practica1eval.model.Alumno;

public interface AlumnoDAO {
	/**
	 * Inserta un alumno en la base de datos siempre que
	 * el DNI del alumno a insertar no exista en la base de datos
	 *
	 * @param alumno 	objeto alumno a insertar
	 *
	 * @return 			true si el alumno ha sido insertado.
	 * false en caso de que el alumno ya existiese en la base
	 * de datos (por medio del DNI)
	 */
	public boolean insertaAlumno(Alumno alumno);

	/**
	 * Borra un alumno por medio del DNI pasado como par�metro
	 * En caso de encontrarse, lo borrar� y devolver� el objeto
	 * alumno borrado. En caso de no encontrarse, devolver�
	 * null
	 *
	 * @param DNI	DNI del alumno a borrar
	 *
	 * @return		el objeto de tipo Alumno borrado. null en caso
	 * de que no haya sido encontrado
	 */
	public Alumno borraAlumno(String DNI);

	/**
	 * Busca un objeto Alumno por medio del DNI. Dicho objeto ser�
	 * devuelto en caso de ser encontrado.
	 *
	 * @param DNI	DNI del alumno a buscar
	 *
	 * @return		el objeto Alumno que se ha encontrado.
	 * null en caso contrario
	 */
	public Alumno buscaAlumno(String DNI);

	/**
	 * Modifica un alumno existente en la base de datos por
	 * medio del par�metro DNI. Si lo encuentra,
	 * lo sustituye por el objeto alumno pasado como par�metro
	 *
	 * @param DNI		DNI a buscar
	 * @param alumno	datos del alumno nuevo
	 *
	 * @return			true si se ha modificado con �xito.
	 * false en caso de que el alumno no existiese (DNI inexistente)
	 */
	public boolean modificaAlumno(String DNI, Alumno alumno);

	/**
	 * Devuelve un List de todos los alumnos existentes.
	 *
	 * @return	una lista de tipo List con los alumnos existentes
	 */
	public List<Alumno> listadoAlumnos();

	/**
	 * Devuelve un Map con todos los alumnos existentes,
	 * cuyas claves son los DNI y, los valores, los objeto Alumno
	 *
	 * @return Map con clave DNI y dato Alumno
	 */
	public Map<String,Alumno> listadoMapAlumnos();
}