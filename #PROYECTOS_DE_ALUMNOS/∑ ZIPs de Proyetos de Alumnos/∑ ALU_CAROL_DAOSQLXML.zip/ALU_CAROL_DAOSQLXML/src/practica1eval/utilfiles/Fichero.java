package practica1eval.utilfiles;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.HashMap;

import practica1eval.model.Alumno;

/**
 * Clase Fichero que hereda de la clase abstracta Estructura de Datos
 *
 * @author Carolina
 *
 */
public class Fichero extends ED
{
	private BufferedReader br = null;
	private BufferedWriter bw = null;
	private Fichero fAux = null;

	public Fichero(String ruta)
	{
		super(ruta);
	}

	/**
	 * Crea un fichero de texto con la ruta si aun no existia. Si ya existia no
	 * hace nada
	 *
	 * @param crear
	 */
	@Override
	public void crearFichero() throws IOException
	{
		f.createNewFile();
	}

	/**
	 * Si existe el fichero de texto, lo abre para lectura y sino no hace nada
	 *
	 * @return BufferedReader si el fichero ya existia y null si no existia
	 */
	private BufferedReader abrirFicheroTextoL() throws FileNotFoundException
	{
		return new BufferedReader(new FileReader(f));
	}

	/**
	 * Si existe alg�n BufferedReader o BufferedWriter lo cierra, lo cual hace
	 * que tambien se cierre el fichero al que hacen referencia.
	 *
	 * @throws IOException
	 */
	private void cerrarFicheroTexto() throws IOException
	{
		if (br != null)
			br.close();
		if (bw != null)
			bw.close();
	}

	/**
	 * Lee un fichero de texto, lo copia en otro y lo devuelve.
	 *
	 * @return Fichero
	 * @throws FileNotFoundException
	 * @throws IOException
	 */
	public Fichero leerCopiarFicheroTexto() throws FileNotFoundException, IOException
	{
		br = abrirFicheroTextoL();
		String linea = "";

		while ((linea = br.readLine()) != null)
		{
			fAux.insertarLineaAlFinal(linea);
		}

		cerrarFicheroTexto();

		return fAux;
	}

	/**
	 * Lee un fichero de texto, lo copia en un HashMap y lo devuelve.
	 *
	 * @return Un HashMap con clave primer elemento de la linea y valor segundo elemento
	 * @throws FileNotFoundException
	 * @throws IOException
	 */
	public HashMap<String,Alumno> copiarFicheroAHashMap() throws FileNotFoundException, IOException
	{
		HashMap<String, Alumno> hmAlumnos = new HashMap<>();
		br = abrirFicheroTextoL();
		String linea = "";
		String[] datos = null;

		while ((linea = br.readLine()) != null)
		{
			datos = linea.split("#");
			hmAlumnos.put(datos[0], new Alumno(datos[0], datos[1]));
		}

		cerrarFicheroTexto();

		return hmAlumnos;
	}

	/**
	 * Escribe una linea al final de un fichero de texto que ya existe.
	 *
	 *
	 * @param linea
	 * @return Devuelve true si se ha insertado con �xito, sino false.
	 * @throws IOException
	 */
	public boolean insertarLineaAlFinal(String linea) throws IOException
	{
		boolean exito = false;

		if (f.exists()) /*Si el fichero existe*/
		{
			bw = new BufferedWriter(new FileWriter(f, true)); /*Abre el fichero para a�adir al final*/
			bw.write(linea);
			bw.newLine();
			exito = true;
		}

		cerrarFicheroTexto();

		return exito;
	}

	/**
	 * M�todo que busca una l�nea en el fichero.
	 *
	 * @param buscar
	 * @return Devuelve true si existe la l�nea en el fichero, sino false.
	 * @throws IOException
	 */
	public boolean buscarLinea(String buscar) throws IOException
	{
		boolean esta = false;
		String linea = "";

		br = abrirFicheroTextoL();

		while ((linea = br.readLine()) != null)
		{
			if (linea.equals(buscar))
				esta = true;
		}

		cerrarFicheroTexto();

		return esta;
	}

	/**
	 * M�todo que busca una subcadena dentro de un fichero de texto. Si la
	 * encuentra, devuelve su l�nea.
	 *
	 * @param cadena
	 * @return La linea si est�. Si no est� devuelve una cadena vac�a "".
	 * @throws IOException
	 */
	public String buscarSubcadena(String cadena) throws IOException
	{
		String resultado = "";
		boolean salir = false;
		String linea = "";
		String[] datos = null;

		br = abrirFicheroTextoL();

		// Pasamos por cada l�nea del fichero
		while ((linea = br.readLine()) != null && !salir)
		{
			datos = linea.split("#");

			// Buscamos la subcadena
			for (int i = 0; i < datos.length; i++)
			{
				if (datos[i].equals(cadena))
				{
					resultado = linea; /*Guardamos la linea y paramos de leer lineas*/
					salir = true;
				}
			}
		}

		cerrarFicheroTexto();

		return resultado;
	}

	/**
	 * Recibe un String con la clave de la linea que queremos borrar, lo busca y
	 * borra su linea completa.
	 *
	 * @param clave
	 * @return devuelve la l�nea borrada
	 * @throws FileNotFoundException
	 * @throws IOException
	 */
	public String borrarLinea(String clave) throws IOException
	{
		String resul = "";
		String linea = null;
		Fichero fAux = new Fichero("temp.txt");

		fAux.crearFichero();

		BufferedReader br = abrirFicheroTextoL();
		BufferedWriter bw = new BufferedWriter(new FileWriter(fAux.getFile()));


		while ((linea = br.readLine()) != null)
		{
			if (buscarSubcadena(clave).equals(linea))/*Si se encuentra la linea con esa clave se guarda la linea pero no se escribe*/
			{
				resul = linea;
			}
			else						/*Si no se encuentra se escribe la linea*/
			{
				bw.write(linea);
				bw.newLine(); // \n
			}
		}

		bw.close();
		cerrarFicheroTexto();

		renombrar(fAux.getFile());

		return resul;
	}

	/**
	 * Si el fichero existe vacia su contenido y si no existe lo crea (por tanto
	 * estar� vacio al estar recien creado)
	 */
	public void vaciarFichero() throws IOException
	{
		if (f.exists())
		{
			f.delete();
		}

		f.createNewFile();
	}

	/**
	 * Busca la linea que contiene el String "antiguo" y lo modifica por el
	 * String "nuevo".
	 *
	 * @param dni
	 * @param nuevo
	 * @return true si se ha modificado correctamente
	 * @throws FileNotFoundException
	 * @throws IOException
	 */
	public boolean modificarFicheroTexto(String clave, String nombre) throws FileNotFoundException, IOException
	{
		boolean exito = false;
		String linea = null;
		String[] trozos = null;
		Fichero fAux = new Fichero("temp.txt");
		fAux.crearFichero();

		BufferedReader br = abrirFicheroTextoL();
		BufferedWriter bw = new BufferedWriter(new FileWriter(fAux.getFile()));


		while ((linea = br.readLine()) != null)
		{
			trozos = linea.split("#");

			if (trozos[0].equals(clave))	/*Si se encuentra se cambia la subcadena clave por nombre y se escribe*/
			{
				bw.write(trozos[0] + "#" + nombre);
				bw.newLine(); // \n
				exito = true;
			}
			else							/*Si no se encuentra escribe la linea como est�*/
			{
				bw.write(linea);
				bw.newLine(); // \n
			}
		}

		bw.close();
		cerrarFicheroTexto();

		renombrar(fAux.getFile());	//Renombramos el fichero temporal con el nombre que tenia nuestro fichero de alumnos

		return exito;
	}

}
