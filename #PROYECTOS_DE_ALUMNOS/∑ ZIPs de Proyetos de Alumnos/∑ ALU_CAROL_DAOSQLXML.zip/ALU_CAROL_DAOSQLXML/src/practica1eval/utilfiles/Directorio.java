package practica1eval.utilfiles;
import java.io.*;
import java.util.*;

/**
 * Clase directorio que hereda de la clase abstracta Estructura de Datos
 * @author Carolina
 *
 */

public class Directorio extends ED
{

	public Directorio(String ruta)
	{
		super(ruta);
	}

	/**
	 * Crea un directorio si no existia. Si ya existia mira el booleano
	 * crear, si es true se borra y se vuelve a crear (se sobreescribe), si es
	 * false no se hace nada.
	 * @param crear
	 */
	@Override
	public void crearFichero()
	{
		if (f.exists())
		{
			f.delete();
			f.mkdir();
		}
		f.mkdir();
	}

	/**
	 * Devuelve un ArrayList<String> con el nombre de los ficheros que contiene
	 * el directorio actual
	 *
	 * @return ArrayList<String>
	 */
	public ArrayList<String> devolverNombreFicheros()
	{
		File[] todo = f.listFiles();
		ArrayList<String> alf = new ArrayList<>();

		for (File fichero : todo)
		{
			if (fichero.isFile())
			{
				alf.add(fichero.getName());
			}
		}

		return alf;
	}

	/**
	 * Devuelve un ArrayList<File> con todos los ficheros y directorios que
	 * contiene el directorio actual
	 *
	 * @return ArrayList<File>
	 */
	public ArrayList<File> devuelveTodo()
	{
		File[] todo = f.listFiles();
		ArrayList<File> alf = new ArrayList<>(Arrays.asList(todo));
		return alf;
	}

	/**
	 * Devuelve un ArrayList<File> con todos los ficheros que contiene el
	 * directorio actual
	 *
	 * @return ArrayList<File>
	 */
	public ArrayList<File> devuelveSoloFicheros()
	{
		File[] todo = f.listFiles();// listFiles devuelve un array con ficheros
									// y directorios, incluso los ocultos
		ArrayList<File> alf = new ArrayList<>();

		for (File fichero : todo)
		{
			if (fichero.isFile())
			{
				alf.add(fichero);
			}
		}

		return alf;
	}

	/**
	 * Devuelve un ArrayList<File> solo con los ficheros que no sean ocultos que
	 * contiene el directorio actual
	 *
	 * @return ArrayList<File>
	 */
	public ArrayList<File> devuelveSoloFicherosVisibles()
	{
		File[] todo = f.listFiles();// listFiles devuelve un array con ficheros
									// y directorios, incluso los ocultos
		ArrayList<File> alf = new ArrayList<>();

		for (File fichero : todo)
		{
			if (fichero.isFile() && !f.isHidden())
			{
				alf.add(fichero);
			}
		}

		return alf;
	}

	/**
	 * Devuelve un ArrayList<File> con todos los directorios que contiene el
	 * directorio actual
	 *
	 * @return ArrayList<File>
	 */
	public ArrayList<File> devuelveSoloDirectorios()
	{
		File[] todo = f.listFiles();// listFiles devuelve un array con ficheros
									// y directorios, incluso los ocultos
		ArrayList<File> alf = new ArrayList<>();

		for (File fichero : todo)
		{
			if (fichero.isDirectory())
			{
				alf.add(fichero);
			}
		}

		return alf;
	}


}