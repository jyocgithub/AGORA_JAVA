package practica1eval.dao;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import practica1eval.dao.exception.MensajeError;
import practica1eval.idao.AlumnoDAO;
import practica1eval.dao.exception.ExcepcionDAO;
import practica1eval.model.Alumno;

//TODO

public class MySqlBDAlumnoDAO implements AlumnoDAO
{
	HashMap<String, String> hm = null;
	Connection conexion = null;

	public MySqlBDAlumnoDAO() throws IOException
	{

		//fichero.crear(false);
		hm = new HashMap<>();
	}

	public void conectar()
	{
		try
		{
			Class.forName("com.mysql.jdbc.Driver");
			conexion = DriverManager.getConnection("jdbc:mysql://localhost:3306/BDAlumnos", "root", "");
		}
		catch (ClassNotFoundException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		catch (SQLException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void cerrar()
	{
		try
		{
			if (conexion != null)
				conexion.close();
		}
		catch (SQLException e)
		{
			// throw new MiException(.....);
			e.printStackTrace();
		}
	}

	/**
	 * Guarda los datos de un alumno en una linea del fichero con el formato
	 * nombre#DNI
	 *
	 * @param alu
	 */
	public void guardarAlumno(Alumno alu) throws IOException
	{

		try
		{
			conectar();
			Statement instruccion = conexion.createStatement();
			String sql = "insert into alumno values('" + alu.getNombre() + "')";
			instruccion.executeUpdate(sql);
		}
		catch (SQLException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			cerrar();
		}

	}


	public List<Alumno> listadoAlumnos(){
		ArrayList<Alumno> lista = new ArrayList<>();
		try
		{
			conectar();
			Statement instruccion = conexion.createStatement();
			String sql = "select * from Alumnos";
			ResultSet cursor = instruccion.executeQuery(sql);

			while(cursor.next()){
				int id = cursor.getInt("id");
				String nombre = cursor.getString("nombre");
				Alumno a = new Alumno(id+"",nombre);
				lista.add(a);
			}
		}
		catch (SQLException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			cerrar();

		}
		return lista;

	}




	/**
	 * Almacena las lineas de un fichero en un ArrayList<String> y lo devuelve
	 *
	 * @return
	 */
	public Map<String, Alumno> listadoMapAlumnos() throws ExcepcionDAO
	{
		HashMap<String,Alumno> mapa = new HashMap<>();
		try
		{
			conectar();
			Statement instruccion = conexion.createStatement();
			String sql = "select * from Alumnos";
			ResultSet cursor = instruccion.executeQuery(sql);

			while(cursor.next()){
				int id = cursor.getInt("id");
				String nombre = cursor.getString("nombre");
				Alumno a = new Alumno(id+"",nombre);
				mapa.put(id+"", a);
			}
		}
		catch (SQLException e)
		{
		  throw new ExcepcionDAO(MensajeError.getMensajeMySQL(e.getErrorCode()) + " \nCodigo de error: " + e.getErrorCode());
		}
		finally
		{
			cerrar();

		}
		return mapa;
	}

	/**
	 * Borra la linea de la BD en la que se encuentra el alumno con el DNI
	 * pasado como parametro.
	 *
	 * @param linea
	 */
	public void borrarAlumno(String dni) throws FileNotFoundException, IOException
	{
		//fichero.borrarLineaFicheroTexto(dni);
	}

	/**
	 * Busca un objeto alumno por DNI y lo devuelve
	 *
	 * @param dni
	 * @return
	 */
	public Alumno buscarAlumno(String dni)
	{
		return new Alumno(dni, hm.get(dni));
	}

	/**
	 * M�todo que reemplaca una linea por otra en un fichero
	 *
	 * @param antiguo
	 * @param nuevo
	 */
	public void modificarAlumno(String dni, String nuevo) throws FileNotFoundException, IOException
	{
		//fichero.modificarFicheroTexto(dni, nuevo);
	}




	@Override
	public boolean insertaAlumno(Alumno alumno)
	{
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Alumno borraAlumno(String DNI)
	{
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Alumno buscaAlumno(String DNI)
	{
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean modificaAlumno(String DNI, Alumno alumno)
	{
		// TODO Auto-generated method stub
		return false;
	}
}
