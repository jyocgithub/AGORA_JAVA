package practica1eval.dao;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import practica1eval.dao.exception.ExcepcionDAO;
import practica1eval.dao.exception.MensajeError;
import practica1eval.dao.exception.TipoProblemaDAO;
import practica1eval.idao.AlumnoDAO;
import practica1eval.model.Alumno;
import practica1eval.utilfiles.Fichero;


public class FileBDAlumnoDAO implements AlumnoDAO
{
	private Fichero fichero = null;
	HashMap<String, Alumno> hm = null;

	public FileBDAlumnoDAO(String ruta)
	{
		fichero = new Fichero(ruta);
		try
		{
			fichero.crearFichero();
		}
		catch (IOException e)
		{
			throw new ExcepcionDAO(MensajeError.getMensaje(TipoProblemaDAO.ERROR_IO));
		}
		hm = new HashMap<>();
	}

	public Fichero getFichero()
	{
		return fichero;
	}

	@Override
	public boolean insertaAlumno(Alumno alumno)
	{
		boolean insertado = false;
		try
		{
			if(fichero.buscarSubcadena(alumno.getDni()) == "")	/*Si no existe ese DNI en el fichero, se guarda el alumno*/
			{
				fichero.insertarLineaAlFinal(alumno.getDni() + "#" + alumno.getNombre());
				insertado = true;
			}
		}
		catch (IOException e)
		{
			throw new ExcepcionDAO(MensajeError.getMensaje(TipoProblemaDAO.ERROR_IO));
		}

		return insertado;
	}

	//TODO
	@Override
	public Alumno borraAlumno(String DNI)
	{
		try
		{
			String[] datosAlumno = fichero.borrarLinea(DNI).split("#");
			return new Alumno(datosAlumno[0], datosAlumno[1]);
		}
		catch (IOException e)
		{
			throw new ExcepcionDAO(MensajeError.getMensaje(TipoProblemaDAO.ERROR_IO));
		}
	}

	@Override
	public Alumno buscaAlumno(String DNI)
	{
		Alumno alumno = null;

		try
		{
			String lineaAlumno = fichero.buscarSubcadena(DNI);

			if(!lineaAlumno.equals(""))
			{
				alumno = new Alumno(lineaAlumno.split("#")[0], lineaAlumno.split("#")[1]);
			}

			return alumno;
		}
		catch (IOException e)
		{
			throw new ExcepcionDAO(MensajeError.getMensaje(TipoProblemaDAO.ERROR_IO));
		}
	}
	//TODO REVISAR
	@Override
	public boolean modificaAlumno(String DNI, Alumno alumno)
	{
		try
		{
			return fichero.modificarFicheroTexto(DNI, alumno.getNombre());
		}
		catch (FileNotFoundException e)
		{
			throw new ExcepcionDAO(MensajeError.getMensaje(TipoProblemaDAO.ERROR_FICHERO_NO_ENCONTRADO));
		}
		catch (IOException e)
		{
			throw new ExcepcionDAO(MensajeError.getMensaje(TipoProblemaDAO.ERROR_IO));
		}
	}

	@Override
	public List<Alumno> listadoAlumnos()
	{
		return null;
	}

	@Override
	public Map<String, Alumno> listadoMapAlumnos()
	{

		try
		{
			hm = fichero.copiarFicheroAHashMap();
		}
		catch (FileNotFoundException e)
		{
			throw new ExcepcionDAO(MensajeError.getMensaje(TipoProblemaDAO.ERROR_FICHERO_NO_ENCONTRADO));
		}
		catch (IOException e)
		{
			throw new ExcepcionDAO(MensajeError.getMensaje(TipoProblemaDAO.ERROR_IO));
		}

		return hm;
	}
}
