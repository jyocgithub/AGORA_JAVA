package practica1eval.dao.exception;
public class ExcepcionDAO extends RuntimeException {
	/**
	 *
	 */
	private static final long serialVersionUID = 8501063947381280216L;

	public ExcepcionDAO(String mensaje) {
		super(mensaje);
	}
}