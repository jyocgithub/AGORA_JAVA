package utils;

public class Settings {
	
	
	public static final String STARS_FILE = "data/custom_stars.csv";
	
	public static final String SPECIES_FILE = "/data/custom_species.csv";

	
	

}
