package utils;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.net.URL;
import java.util.Optional;
import java.util.Random;

import entities.Star;
import javafx.application.Platform;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Dialog;
import javafx.scene.control.DialogPane;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.control.TextInputDialog;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class FXUtils {

	
	 /**
     * INICIA SCENE Construye una escena en el stage indicado, y arranca dicha
     * escena
	 * Esta sobrecargado, esta opcion recibe el Stage, si se conoce
     *
     * @param esteStage
     * @param pFicheroControllerFXML
     * @param pTituloVentana
     * @throws IOException
     */
    public static void iniciaScene(Stage esteStage, String pFicheroControllerFXML, String pTituloVentana)
            throws IOException {

        URL recurso = FXUtils.class.getResource(pFicheroControllerFXML);
        FXMLLoader fxmlLoader = new FXMLLoader(recurso);
        Parent parent = fxmlLoader.load();
//      pStage.initModality(Modality.APPLICATION_MODAL);  // si queremos que la ventana sea modal
//      pStage.initStyle(StageStyle.UNDECORATED);         // si no queremos title bar en la nueva ventana
//		Scene scene = new Scene(parentRoot, 300, 275);    // si queremos un tamaño especifico de la scene
        Scene scene = new Scene(parent);
        esteStage.setScene(scene);
        esteStage.setTitle(pTituloVentana);
        esteStage.show();
    }

    /**
     * INICIA SCENE Construye una escena en el stage indicado, y arranca dicha escena
     * Esta sobrecargado, esta opcion no recibe el Stage, sino un objeto Node para sacar de ahi el Stage actual
     * Node es la madre de casi todos los controles y layouts, se necesita recibir un objeto de cualquier cosa hija de
     * Node para sacar de ahi el Stage actual
     *
     * @param cualquiernodo
     * @param pFicheroControllerFXML
     * @param pTituloVentana
     * @throws IOException
     */
    public static void iniciaScene(Node cualquiernodo, String pFicheroControllerFXML, String pTituloVentana)
            throws IOException {

        Stage esteStage =(Stage) cualquiernodo.getScene().getWindow();
		// mejor llamar desde aqui al otro método sobrecargado, si se usan los dos en el proyecto
		// si no, continuar con las lineas siguientes

        URL recurso = FXUtils.class.getResource(pFicheroControllerFXML);
        FXMLLoader fxmlLoader = new FXMLLoader(recurso);
        Parent parent = fxmlLoader.load();
//      pStage.initModality(Modality.APPLICATION_MODAL);  // si queremos que la ventana sea modal
//      pStage.initStyle(StageStyle.UNDECORATED);         // si no queremos title bar en la nueva ventana
//		Scene scene = new Scene(parentRoot, 300, 275);    // si queremos un tamaño especifico de la scene
        Scene scene = new Scene(parent);
        esteStage.setScene(scene);
        esteStage.setTitle(pTituloVentana);
        esteStage.show();
    }
	
    /**
     * ADD FFML TO PANE  Añade un FXML no como una escena, sino dentro de un Pane cualquiera,
     * AnchorPane preferiblemente (pues todo el congtenido del FXML se agrega en bloque,
     * y se supone que tiene su propia estructura interna)
     * Buena opcion para añadir FXML a una página previa que contiene algo comun a varios
     * FXML, como un menu por ejemplo.
     *
     * @param pFicheroControllerFXML
     * @param pane
     * @return el node creado a partir del FXML y que se ha añadido al Pane
     */
    public static Node addFXMLtoAnchorPane(String pFicheroControllerFXML, Pane pane) {
        Parent parent = null;
        try {
            URL recurso = FXUtils.class.getResource(pFicheroControllerFXML);
            FXMLLoader fxmlLoader = new FXMLLoader(recurso);
            parent = fxmlLoader.load();
            pane.getChildren().clear();
            pane.getChildren().add(parent);

        } catch (IOException e) {
            e.printStackTrace();
        }
        return parent;
    }
	
	
    public static boolean confirmationMessage(String texto) {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Message");
        alert.setContentText(texto);
//        alert.showAndWait();

        Optional<ButtonType> result = alert.showAndWait();
        if (result.get() == ButtonType.OK) {
          
            alert.close();
            return true;
        } else {
            // ... cuando eligen no o cancelan el dialog
            
            alert.close();
            return false;
        }
    }
	
    public static String inputMessage(String texto) {

        TextInputDialog dialog = new TextInputDialog("");
        dialog.setContentText(texto);

        Optional<String> result = dialog.showAndWait();
        if (result.isPresent()) {
            return result.get();
        }
        return null;

    }

    public static String randomString() {
        Random random = new Random();

        char[] word = new char[random.nextInt(8) + 3]; // words of length 3 through 10. (1 and 2 letter words are
        // boring.)
        for (int j = 0; j < word.length; j++) {
            word[j] = (char) ('a' + random.nextInt(26));
        }
        return new String(word);

    }

    public static void message(String pTexto, String pTitulo) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(pTitulo);
        alert.setContentText(pTexto);
        alert.showAndWait();
    }
	
   public static  void newStar() {

		Dialog<Star> dialog = new Dialog<>();
		dialog.setTitle("Create a Star");
		dialog.setHeaderText("Complete the fields below;");
		DialogPane dialogPane = dialog.getDialogPane();
		dialogPane.getButtonTypes().addAll(ButtonType.OK, ButtonType.CANCEL);

		// añadir labels y textfields
		Label label1 = new Label("Nombre");
		TextField textFieldName = new TextField("");
		Label label2 = new Label("Type");
		TextField textFieldType = new TextField("");
		Label label3 = new Label("temperatureSequence");
		TextField textFieldtemperatureSequence = new TextField("");
		Label label4 = new Label("luminosityClass");
		TextField textFieldluminosityClass = new TextField("");
		Label label5 = new Label("distanceInParsecs");
		TextField textFielddistanceInParsecs = new TextField("");
		Label label6 = new Label("longitudeInDecimalDegrees");
		TextField textFieldlongitudeInDecimalDegrees = new TextField("");
		Label label7 = new Label("lattitudeInDecimalHours");
		TextField textFieldlattitudeInDecimalHours = new TextField("");

		dialogPane.setContent(new VBox(8, label1, textFieldName, label2, textFieldType, label3,
				textFieldtemperatureSequence, label4, textFieldluminosityClass, label5, textFielddistanceInParsecs,
				label6, textFieldlongitudeInDecimalDegrees, label7, textFieldlattitudeInDecimalHours));

		// Platform.runLater(textField1::requestFocus);
		dialog.setResultConverter((ButtonType button) -> {
			if (button == ButtonType.OK) {
				Star star = new Star(textFieldName.getText(), textFieldType.getText(),
						Integer.parseInt(textFieldtemperatureSequence.getText()), textFieldluminosityClass.getText(),
						Double.parseDouble(textFielddistanceInParsecs.getText()),
						Double.parseDouble(textFieldlongitudeInDecimalDegrees.getText()),
						Double.parseDouble(textFieldlattitudeInDecimalHours.getText())

				);

				return star;

			}
			return null;
		});
		Optional<Star> optionalResult = dialog.showAndWait();
		optionalResult.ifPresent((Star star) -> {
			saveStarInCSV(star);
		});
   }
	public static  void saveStarInCSV(Star star) {
		BufferedWriter bw = null;
		try {
			bw = new BufferedWriter(new FileWriter(Settings.STARS_FILE, true));

			bw.newLine();

			bw.write(star.toString());

		} catch (IOException ex) {
			ex.printStackTrace();
		} finally {
			try {
				bw.close();
			} catch (IOException ex) {
				ex.printStackTrace();
			}
		}

	}
	
	
	
	
}
