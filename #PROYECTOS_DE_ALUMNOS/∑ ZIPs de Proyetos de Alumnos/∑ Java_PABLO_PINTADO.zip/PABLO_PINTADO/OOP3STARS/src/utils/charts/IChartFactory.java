package utils.charts;

import javafx.scene.chart.PieChart;
import javafx.scene.layout.VBox;

public interface IChartFactory {

    void addData(String name, String data);
    public VBox getChart();
    
}
