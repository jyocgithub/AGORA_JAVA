package utils.charts;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Pos;
import javafx.scene.chart.PieChart;
import javafx.scene.layout.VBox;

import java.util.ArrayList;

public class MyChart {
    String title;
    ArrayList<String> dataname = new ArrayList<>();
    ArrayList<String> datavalue = new ArrayList<>();

    public MyChart(String title) {
        this.title = title;
    }

}
