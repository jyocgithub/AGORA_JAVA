package utils.charts;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Pos;
import javafx.scene.chart.CategoryAxis;
import javafx.scene.chart.LineChart;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart;
import javafx.scene.layout.VBox;

public class MyLineChart extends MyChart implements IChartFactory {

    ObservableList<LineChart.Data> barChartData = FXCollections.observableArrayList();
    //    final LineChart chart = new LineChart(barChartData);
    final CategoryAxis xAxis = new CategoryAxis();
    final NumberAxis yAxis = new NumberAxis();
    final LineChart<String, Number> chart = new LineChart<String, Number>(xAxis, yAxis);
    XYChart.Series series1 = new XYChart.Series();  // puede haber mas de una serie
    XYChart.Series series2 = new XYChart.Series();  // puede haber mas de una serie

    private String axisxname, axisyname, seriename;

    public MyLineChart(String title) {
        super(title);
        chart.setTitle(title);
        chart.getData().addAll(series1, series2);
    }

    public void addData(String name, String data) {
            series1.getData().add(new XYChart.Data(name, Double.parseDouble(data)));
    }

    public void addDataBySerie(String name, String data, int serienumber) {
        if (serienumber == 1) {
            series1.getData().add(new XYChart.Data(name, Double.parseDouble(data)));
        }
        if (serienumber == 2) {
            series2.getData().add(new XYChart.Data(name, Double.parseDouble(data)));
        }
    }

    public VBox getChart() {
        VBox vbox = new VBox(chart);
        vbox.setAlignment(Pos.CENTER);
        return vbox;
    }


    public String getAxisxname() {
        return axisxname;
    }

    public void setAxisxname(String axisxname) {
        this.axisxname = axisxname;
        xAxis.setLabel(axisxname);
    }

    public String getAxisyname() {
        return axisyname;
    }

    public void setAxisyname(String axisyname) {
        this.axisyname = axisyname;
        yAxis.setLabel(axisyname);
    }

    public String getSeriename() {
        return seriename;
    }

    public void setSeriename(String seriename) {
        this.seriename = seriename;
        series1.setName(seriename);
    }
}
