package utils.charts;


public class ChartFactory {

    public static IChartFactory getChartType(String type, String title)
    {
        if ( type.equals("pie"))
            return new MyPieChart(title);
        else if ( type.equals("bar") )
            return new MyBarChart(title);
        else if ( type.equals("line") )
            return new MyLineChart(title);

        return null;
    }



}
