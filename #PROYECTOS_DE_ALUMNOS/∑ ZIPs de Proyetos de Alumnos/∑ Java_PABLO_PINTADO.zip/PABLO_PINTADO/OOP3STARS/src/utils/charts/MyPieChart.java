package utils.charts;

import java.util.ArrayList;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Pos;
import javafx.scene.chart.PieChart;
import javafx.scene.layout.VBox;

public class MyPieChart extends  MyChart implements IChartFactory{

    ObservableList<PieChart.Data> pieChartData = FXCollections.observableArrayList();
    final PieChart chart = new PieChart(pieChartData);

    public MyPieChart(String title) {
        super(title);
        chart.setTitle(title);
    }

    public void addData(String name, String data){
        pieChartData.add(new PieChart.Data(name, Double.parseDouble(data)));
    }


    public VBox getChart(){
        VBox vbox = new VBox(chart);
        vbox.setAlignment(Pos.CENTER);
        return vbox;
    }
}
