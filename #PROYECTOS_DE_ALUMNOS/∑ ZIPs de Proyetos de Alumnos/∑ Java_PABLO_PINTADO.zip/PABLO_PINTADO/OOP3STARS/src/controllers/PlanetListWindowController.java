package controllers;

import javafx.fxml.FXML;

import javafx.scene.control.Button;

import javafx.scene.control.TextField;
import utils.FXUtils;

import java.io.IOException;

import javax.imageio.metadata.IIOMetadataController;

import entities.DataCollections;
import entities.Star;
import javafx.event.ActionEvent;

import javafx.scene.control.ListView;

import javafx.scene.control.Label;

public class PlanetListWindowController {
	@FXML
	private ListView idlistofplanets2;
	@FXML
	private Label idlistofplanets;
	@FXML
	private TextField idnumberofplanets2;
	@FXML
	private Button iddetails;
	@FXML
	private Button idadd;
	@FXML
	private Button iddelete;
	@FXML
	private Label ifnumberofplanets;

	public static Star selectedStar = null;

	@FXML
	void initialize() {

		// put stars on list
		for (Star star : DataCollections.listStar) {
			idlistofplanets2.getItems().add(star.getName());
		}

		idlistofplanets2.setOnMouseClicked(event -> {
			int position = idlistofplanets2.getSelectionModel().getSelectedIndex();
			if (position >= 0) {
				Star star = DataCollections.listStar.get(position);
				int numberofplanets = star.getListOfPlanets().size();

				idnumberofplanets2.setText(numberofplanets + "");
				selectedStar =  star;
			}
		});
	}

	// Event Listener on Button[#iddetails].onAction
	@FXML
	public void onDetails(ActionEvent event) {
		FXUtils.addFXMLtoAnchorPane("/views/DetailsWindow.fxml", 	DataCollections.centerPaneReference);
	}

	// Event Listener on Button[#idadd].onAction
	@FXML
	public void onAdd(ActionEvent event) {
		FXUtils.newStar();
		DataCollections.listStar.clear();
		for (Star star : DataCollections.listStar) {
			idlistofplanets2.getItems().add(star.getName());
		}
	}

	// Event Listener on Button[#iddelete].onDelete
	@FXML
	public void onDelete(ActionEvent event) {

		int position = idlistofplanets2.getSelectionModel().getSelectedIndex();
		if (position >= 0) {
			DataCollections.listStar.remove(position);
			initialize();

		}
	}
}
