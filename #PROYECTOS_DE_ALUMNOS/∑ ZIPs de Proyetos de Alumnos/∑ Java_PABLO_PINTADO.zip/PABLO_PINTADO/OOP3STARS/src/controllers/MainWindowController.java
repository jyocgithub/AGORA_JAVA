package controllers;

import com.sun.tools.javadoc.Start;
import entities.DataCollections;
import entities.Planet;
import entities.Star;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.MenuItem;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.VBox;
import utils.FXUtils;
import utils.Settings;
import utils.charts.*;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.Random;

public class MainWindowController {

    @FXML
    private MenuItem idbar;

    @FXML
    private MenuItem idpie;

    @FXML
    private MenuItem idscatter;

    @FXML
    public AnchorPane centerPane;

    @FXML
    private AnchorPane anchorMain;

    @FXML
    private MenuItem itemabout;

    @FXML
    private MenuItem itemcreatespecies;

    @FXML
    private MenuItem itemcreatestar;

    @FXML
    private MenuItem itemexit;

    @FXML
    private MenuItem itemloadspecies;

    @FXML
    private MenuItem itemloadstar;

    @FXML
    private MenuItem itemnewspecies;

    @FXML
    private MenuItem itemnewstar;

    @FXML
    private MenuItem itemshowspecies;

    @FXML
    private MenuItem itemshowstar;


    @FXML
    void initialize() {
        readStarsFile(Settings.STARS_FILE);
    }


    @FXML
    void onLoadStar(ActionEvent event) {

        readStarsFile(Settings.STARS_FILE);

        System.out.println("Fichero leido y metido en lista");

        boolean yesornot = FXUtils.confirmationMessage("Desea añadir estrellas desde otro ficero?");
        if (yesornot) {
            // add new stars

            String filename = FXUtils.inputMessage("Name of file with stars:");
            if (filename != null) {
                readStarsFile(filename);
            }

        }

    }

    public void readStarsFile(String filename) {
        File archivo = new File(filename);
        DataCollections.listStar.clear();

        if (archivo.exists()) {
            BufferedReader br = null;
            try {
                br = new BufferedReader(new FileReader(archivo));

                String linea = br.readLine();
                linea = br.readLine();
                while (linea != null) {
                    if (!linea.isEmpty()) {
                        String trozos[] = linea.split(";");
                        Star star = new Star(trozos[0], trozos[1], Integer.parseInt(trozos[2]), trozos[3],
                                Double.parseDouble(trozos[4]), Double.parseDouble(trozos[5]),
                                Double.parseDouble(trozos[6]));
                        // add planets to the star
                        fillPlanets(star);
                        DataCollections.listStar.add(star);
                        System.out.println(star);
                    }
                    linea = br.readLine();
                }
            } catch (IOException ex) {
                ex.printStackTrace();
            } finally {
                try {
                    br.close();
                } catch (IOException ex) {
                    ex.printStackTrace();
                }
            }
        }
    }

    public void fillPlanets(Star star) {
        Random random = new Random();
        int number = random.nextInt(9);
        for (int i = 0; i < number; i++) {
            int diameter = random.nextInt(2000) + 50;
            Planet p = new Planet(FXUtils.randomString(), diameter);
            star.getListOfPlanets().add(p);
        }
    }


    @FXML
    void onHelp(ActionEvent event) {
        String text = "This is an exmple of help message";
        FXUtils.message(text, "HELP");
    }

    @FXML
    void onNewStar(ActionEvent event) {
        FXUtils.newStar();
        onLoadStar(event);
    }


    @FXML
    void onShowStars(ActionEvent event) {
        DataCollections.centerPaneReference = centerPane;
        FXUtils.addFXMLtoAnchorPane("/views/PlanetListWindow.fxml", DataCollections.centerPaneReference);
    }

    @FXML
    void onPie(ActionEvent event) {
        IChartFactory ch = ChartFactory.getChartType("pie", "Temperature");
        if (ch != null) {
            for(Star star : DataCollections.listStar){
                System.out.println(star.getName());
                     ch.addData(star.getName(), star.getTemperatureSequence()+"");
            }
            VBox boxchar = ch.getChart();
            centerPane.getChildren().clear();
            centerPane.getChildren().add(boxchar);
        }
    }

    @FXML
    void onScatter(ActionEvent event) {
        IChartFactory ch = ChartFactory.getChartType("line", "Lattitude of stars");
        if (ch != null) {
            MyLineChart bh = (MyLineChart) ch;
            bh.setAxisxname("Stars name");
            bh.setAxisyname("Lattitude/Longitude");
            bh.setSeriename("");

            for(Star start : DataCollections.listStar){
                bh.addDataBySerie(start.getName(), start.getLattitudeInDecimalHours()+"",1);
                bh.addDataBySerie(start.getName(), start.getLongitudeInDecimalDegrees()+"",2);
            }
            VBox boxchar = ch.getChart();
            centerPane.getChildren().clear();
            centerPane.getChildren().add(boxchar);
        }
    }

    @FXML
    void onExit(ActionEvent event) {
        Platform.exit();
    }

    @FXML
    void onBar(ActionEvent event) {
        IChartFactory ch = ChartFactory.getChartType("bar", "Distance of stars");
        if (ch != null) {
            MyBarChart bh = (MyBarChart) ch;
            bh.setAxisxname("Stars name");
            bh.setAxisyname("Parsecs");
            bh.setSeriename("");

            for(Star start : DataCollections.listStar){
                ch.addData(start.getName(), start.getDistanceInParsecs()+"");
            }
            VBox boxchar = ch.getChart();
            centerPane.getChildren().clear();
            centerPane.getChildren().add(boxchar);
        }
    }
}
