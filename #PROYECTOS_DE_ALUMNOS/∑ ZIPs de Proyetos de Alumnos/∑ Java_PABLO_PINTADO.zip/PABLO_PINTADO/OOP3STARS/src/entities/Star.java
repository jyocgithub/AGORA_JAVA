package entities;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class Star {
	private String name;	
	private String type;
	private int temperatureSequence;
	private String luminosityClass;
	private double distanceInParsecs;	
	private double longitudeInDecimalDegrees;	
	private double lattitudeInDecimalHours;
	
	private List<Planet> listOfPlanets ;
	
	/**
	 * @param name
	 * @param type
	 * @param temperatureSequence
	 * @param luminosityClass
	 * @param distanceInParsecs
	 * @param longitudeInDecimalDegrees
	 * @param lattitudeInDecimalHours
	 */
	public Star(String name, String type, int temperatureSequence, String luminosityClass, double distanceInParsecs,
			double longitudeInDecimalDegrees, double lattitudeInDecimalHours) {
		super();
		this.name = name;
		this.type = type;
		this.temperatureSequence = temperatureSequence;
		this.luminosityClass = luminosityClass;
		this.distanceInParsecs = distanceInParsecs;
		this.longitudeInDecimalDegrees = longitudeInDecimalDegrees;
		this.lattitudeInDecimalHours = lattitudeInDecimalHours;
		this.listOfPlanets = new ArrayList<>();

	}
	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}
	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}
	/**
	 * @return the type
	 */
	public String getType() {
		return type;
	}
	/**
	 * @param type the type to set
	 */
	public void setType(String type) {
		this.type = type;
	}
	/**
	 * @return the temperatureSequence
	 */
	public int getTemperatureSequence() {
		return temperatureSequence;
	}
	/**
	 * @param temperatureSequence the temperatureSequence to set
	 */
	public void setTemperatureSequence(int temperatureSequence) {
		this.temperatureSequence = temperatureSequence;
	}
	/**
	 * @return the luminosityClass
	 */
	public String getLuminosityClass() {
		return luminosityClass;
	}
	/**
	 * @param luminosityClass the luminosityClass to set
	 */
	public void setLuminosityClass(String luminosityClass) {
		this.luminosityClass = luminosityClass;
	}
	/**
	 * @return the distanceInParsecs
	 */
	public double getDistanceInParsecs() {
		return distanceInParsecs;
	}
	/**
	 * @param distanceInParsecs the distanceInParsecs to set
	 */
	public void setDistanceInParsecs(double distanceInParsecs) {
		this.distanceInParsecs = distanceInParsecs;
	}
	/**
	 * @return the longitudeInDecimalDegrees
	 */
	public double getLongitudeInDecimalDegrees() {
		return longitudeInDecimalDegrees;
	}
	/**
	 * @param longitudeInDecimalDegrees the longitudeInDecimalDegrees to set
	 */
	public void setLongitudeInDecimalDegrees(double longitudeInDecimalDegrees) {
		this.longitudeInDecimalDegrees = longitudeInDecimalDegrees;
	}
	/**
	 * @return the lattitudeInDecimalHours
	 */
	public double getLattitudeInDecimalHours() {
		return lattitudeInDecimalHours;
	}
	/**
	 * @param lattitudeInDecimalHours the lattitudeInDecimalHours to set
	 */
	public void setLattitudeInDecimalHours(double lattitudeInDecimalHours) {
		this.lattitudeInDecimalHours = lattitudeInDecimalHours;
	}
	@Override
	public String toString() {
		return name + ";" + type + ";" + temperatureSequence + ";" + luminosityClass + ";"+ distanceInParsecs
				+ ";"+ longitudeInDecimalDegrees + ";" +lattitudeInDecimalHours ;
	}
	@Override
	public int hashCode() {
		return Objects.hash(distanceInParsecs, lattitudeInDecimalHours, longitudeInDecimalDegrees, luminosityClass,
				name, temperatureSequence, type);
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Star other = (Star) obj;
		return Double.doubleToLongBits(distanceInParsecs) == Double.doubleToLongBits(other.distanceInParsecs)
				&& Double.doubleToLongBits(lattitudeInDecimalHours) == Double
						.doubleToLongBits(other.lattitudeInDecimalHours)
				&& Double.doubleToLongBits(longitudeInDecimalDegrees) == Double
						.doubleToLongBits(other.longitudeInDecimalDegrees)
				&& Objects.equals(luminosityClass, other.luminosityClass) && Objects.equals(name, other.name)
				&& Objects.equals(temperatureSequence, other.temperatureSequence) && type == other.type;
	}
	/**
	 * @return the listOfPlanets
	 */
	public List<Planet> getListOfPlanets() {
		return listOfPlanets;
	}
	/**
	 * @param listOfPlanets the listOfPlanets to set
	 */
	public void setListOfPlanets(List<Planet> listOfPlanets) {
		this.listOfPlanets = listOfPlanets;
	}
	
	
}
