package entities;
import java.util.Objects;

public class Species {
	private String name;
	private String planetOfOrigin;
	private String intelligence;
	private String technicalLevel;
	private String preferredPlanetType;
	private String preferredClimate;
	private int colonies;
	private String chanceInMixedPopulation;
	private String maxPercentageOnMixedWorlds;
	private String ciadanPresence;	
	private String accessLevel;	
	private String councilRelations;
	private String playable;
	private String description;
	/**
	 * @param name
	 * @param planetOfOrigin
	 * @param intelligence
	 * @param technicalLevel
	 * @param preferredPlanetType
	 * @param preferredClimate
	 * @param colonies
	 * @param chanceInMixedPopulation
	 * @param maxPercentageOnMixedWorlds
	 * @param ciadanPresence
	 * @param accessLevel
	 * @param councilRelations
	 * @param playable
	 * @param description
	 */
	public Species(String name, String planetOfOrigin, String intelligence, String technicalLevel,
			String preferredPlanetType, String preferredClimate, int colonies, String chanceInMixedPopulation,
			String maxPercentageOnMixedWorlds, String ciadanPresence, String accessLevel, String councilRelations,
			String playable, String description) {
		super();
		this.name = name;
		this.planetOfOrigin = planetOfOrigin;
		this.intelligence = intelligence;
		this.technicalLevel = technicalLevel;
		this.preferredPlanetType = preferredPlanetType;
		this.preferredClimate = preferredClimate;
		this.colonies = colonies;
		this.chanceInMixedPopulation = chanceInMixedPopulation;
		this.maxPercentageOnMixedWorlds = maxPercentageOnMixedWorlds;
		this.ciadanPresence = ciadanPresence;
		this.accessLevel = accessLevel;
		this.councilRelations = councilRelations;
		this.playable = playable;
		this.description = description;
	}
	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}
	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}
	/**
	 * @return the planetOfOrigin
	 */
	public String getPlanetOfOrigin() {
		return planetOfOrigin;
	}
	/**
	 * @param planetOfOrigin the planetOfOrigin to set
	 */
	public void setPlanetOfOrigin(String planetOfOrigin) {
		this.planetOfOrigin = planetOfOrigin;
	}
	/**
	 * @return the intelligence
	 */
	public String getIntelligence() {
		return intelligence;
	}
	/**
	 * @param intelligence the intelligence to set
	 */
	public void setIntelligence(String intelligence) {
		this.intelligence = intelligence;
	}
	/**
	 * @return the technicalLevel
	 */
	public String getTechnicalLevel() {
		return technicalLevel;
	}
	/**
	 * @param technicalLevel the technicalLevel to set
	 */
	public void setTechnicalLevel(String technicalLevel) {
		this.technicalLevel = technicalLevel;
	}
	/**
	 * @return the preferredPlanetType
	 */
	public String getPreferredPlanetType() {
		return preferredPlanetType;
	}
	/**
	 * @param preferredPlanetType the preferredPlanetType to set
	 */
	public void setPreferredPlanetType(String preferredPlanetType) {
		this.preferredPlanetType = preferredPlanetType;
	}
	/**
	 * @return the preferredClimate
	 */
	public String getPreferredClimate() {
		return preferredClimate;
	}
	/**
	 * @param preferredClimate the preferredClimate to set
	 */
	public void setPreferredClimate(String preferredClimate) {
		this.preferredClimate = preferredClimate;
	}
	/**
	 * @return the colonies
	 */
	public int getColonies() {
		return colonies;
	}
	/**
	 * @param colonies the colonies to set
	 */
	public void setColonies(int colonies) {
		this.colonies = colonies;
	}
	/**
	 * @return the chanceInMixedPopulation
	 */
	public String getChanceInMixedPopulation() {
		return chanceInMixedPopulation;
	}
	/**
	 * @param chanceInMixedPopulation the chanceInMixedPopulation to set
	 */
	public void setChanceInMixedPopulation(String chanceInMixedPopulation) {
		this.chanceInMixedPopulation = chanceInMixedPopulation;
	}
	/**
	 * @return the maxPercentageOnMixedWorlds
	 */
	public String getMaxPercentageOnMixedWorlds() {
		return maxPercentageOnMixedWorlds;
	}
	/**
	 * @param maxPercentageOnMixedWorlds the maxPercentageOnMixedWorlds to set
	 */
	public void setMaxPercentageOnMixedWorlds(String maxPercentageOnMixedWorlds) {
		this.maxPercentageOnMixedWorlds = maxPercentageOnMixedWorlds;
	}
	/**
	 * @return the ciadanPresence
	 */
	public String getCiadanPresence() {
		return ciadanPresence;
	}
	/**
	 * @param ciadanPresence the ciadanPresence to set
	 */
	public void setCiadanPresence(String ciadanPresence) {
		this.ciadanPresence = ciadanPresence;
	}
	/**
	 * @return the accessLevel
	 */
	public String getAccessLevel() {
		return accessLevel;
	}
	/**
	 * @param accessLevel the accessLevel to set
	 */
	public void setAccessLevel(String accessLevel) {
		this.accessLevel = accessLevel;
	}
	/**
	 * @return the councilRelations
	 */
	public String getCouncilRelations() {
		return councilRelations;
	}
	/**
	 * @param councilRelations the councilRelations to set
	 */
	public void setCouncilRelations(String councilRelations) {
		this.councilRelations = councilRelations;
	}
	/**
	 * @return the playable
	 */
	public String getPlayable() {
		return playable;
	}
	/**
	 * @param playable the playable to set
	 */
	public void setPlayable(String playable) {
		this.playable = playable;
	}
	/**
	 * @return the description
	 */
	public String getDescription() {
		return description;
	}
	/**
	 * @param description the description to set
	 */
	public void setDescription(String description) {
		this.description = description;
	}
	@Override
	public int hashCode() {
		return Objects.hash(accessLevel, chanceInMixedPopulation, ciadanPresence, colonies, councilRelations,
				description, intelligence, maxPercentageOnMixedWorlds, name, planetOfOrigin, playable, preferredClimate,
				preferredPlanetType, technicalLevel);
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Species other = (Species) obj;
		return Objects.equals(accessLevel, other.accessLevel)
				&& Objects.equals(chanceInMixedPopulation, other.chanceInMixedPopulation)
				&& Objects.equals(ciadanPresence, other.ciadanPresence) && colonies == other.colonies
				&& Objects.equals(councilRelations, other.councilRelations)
				&& Objects.equals(description, other.description) && Objects.equals(intelligence, other.intelligence)
				&& Objects.equals(maxPercentageOnMixedWorlds, other.maxPercentageOnMixedWorlds)
				&& Objects.equals(name, other.name) && Objects.equals(planetOfOrigin, other.planetOfOrigin)
				&& Objects.equals(playable, other.playable) && Objects.equals(preferredClimate, other.preferredClimate)
				&& Objects.equals(preferredPlanetType, other.preferredPlanetType)
				&& Objects.equals(technicalLevel, other.technicalLevel);
	}
	@Override
	public String toString() {
		return "Species [name=" + name + ", planetOfOrigin=" + planetOfOrigin + ", intelligence=" + intelligence
				+ ", technicalLevel=" + technicalLevel + ", preferredPlanetType=" + preferredPlanetType
				+ ", preferredClimate=" + preferredClimate + ", colonies=" + colonies + ", chanceInMixedPopulation="
				+ chanceInMixedPopulation + ", maxPercentageOnMixedWorlds=" + maxPercentageOnMixedWorlds
				+ ", ciadanPresence=" + ciadanPresence + ", accessLevel=" + accessLevel + ", councilRelations="
				+ councilRelations + ", playable=" + playable + ", description=" + description + "]";
	}
	
	
}
