package entities;

import java.util.ArrayList;
import java.util.List;

import javafx.scene.layout.AnchorPane;

public class DataCollections {
	
		public static List<Star> listStar = new ArrayList<Star>();
	    public static AnchorPane centerPaneReference;

}
