package comparators;

import java.util.Comparator;
import entities.MailUser;
/**
 * This class is used to create a comparator for the MailUser class
 * in this case it compares the email address
 * implements comparator
 * @author pablo
 *
 */
public class ComparatorMailUserByEmailadress implements Comparator<MailUser> {
	/**
	 * compares two MailUser objects by the email address 
	 * checks if email address  is null on both objects.
	 * @param o1 first MailUser object
	 * @param o2 second MailUser object 
	 * @returns negative int if the o1<o2, positive int if o1>o2 or 0 if they are equal
	 */
	@Override
	public int compare(MailUser o1, MailUser o2) {
		if (o1.getEmailaddress() == null || o2.getEmailaddress() == null) {
			return -1;
		}

		if (o1.getEmailaddress().compareTo(o2.getEmailaddress()) == 0) {

			return o1.getUsername().compareTo(o2.getUsername());

		} else {

			return o1.getEmailaddress().compareTo(o2.getEmailaddress());
		}

	}

}
