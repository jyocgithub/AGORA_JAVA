package comparators;

import java.util.Comparator;
import entities.MailUser;
/**
 * This class is used to create a comparator for the MailUser class
 * in this case it compares the date of birth
 * implements comparator
 * @author pablo
 *
 */
public class ComparatorMailUserByDateofbirth implements Comparator<MailUser>{

	/**
	 * compares two MailUser objects by the date of birth 
	 * checks if date of birth is null on both objects.
	 * @param o1 first MailUser object
	 * @param o2 second MailUser object 
	 * @returns negative int if the o1<o2, positive int if o1>o2 or 0 if they are equal
	 */
	@Override
	public int compare(MailUser o1, MailUser o2) {
		if(o1.getDateofbirth()==null || o2.getDateofbirth() == null) {
			return -1;
		}   
	    return o1.getDateofbirth().compareTo(o2.getDateofbirth());
		
	
	
	}

}
