package entities;
import java.math.BigInteger;
import java.net.InetAddress;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Objects;
import java.util.Observable;
import java.util.Random;
/**
 * Defines the user to send mails
 * it inherent from the class Observable 
 * @author pablo
 *
 */
public class MailUser extends Observable {
	private String username;
	private String emailaddress;
	private InetAddress ipaddress;
	private int portnumber;
	private String firstname;
	private String lastname;
	private LocalDate dateofbirth;
	private ArrayList<Key> listKeys = new ArrayList<>();
	
	/**
	 * constructor only using one parameter 
	 * @param username
	 */
	public MailUser(String username) {
		super();
		this.username = username;
		for (int i = 0; i < 10; i++) {
			BigInteger a = BigInteger.probablePrime(10, new Random());
			BigInteger b = BigInteger.probablePrime(10, new Random());
			BigInteger c = BigInteger.probablePrime(10, new Random());
			this.listKeys.add( new Key(a,b,c));
		}
		
	}
	
		
	/**
	 * another constructor using username, emailaddress, firstname, lastname and dateofbirth
	 * @param username
	 * @param emailaddress
	 * @param firstname
	 * @param lastname
	 * @param dateofbirth
	 */
	public MailUser(String username, String emailaddress, String firstname, String lastname, LocalDate dateofbirth) {
		super();
		this.username = username;
		this.emailaddress = emailaddress;
		this.firstname = firstname;
		this.lastname = lastname;
		this.dateofbirth = dateofbirth;
		
		for (int i = 0; i < 10; i++) {
			BigInteger a = BigInteger.probablePrime(10, new Random());
			BigInteger b = BigInteger.probablePrime(10, new Random());
			BigInteger c = BigInteger.probablePrime(10, new Random());
			this.listKeys.add( new Key(a,b,c));
		}
		

	}


	/**
	 * @return the username
	 */
	public String getUsername() {
		return username;
	}
	/**
	 * @param username the username to set
	 */
	public void setUsername(String username) {
		this.username = username;
	}
	/**
	 * @return the emailaddress
	 */
	public String getEmailaddress() {
		return emailaddress;
	}
	/**
	 * @param emailaddress the emailadsress to set
	 */
	public void setEmailaddress(String emailaddess) {
		this.emailaddress = emailaddress;
	}
	/**
	 * @return the ipaddress
	 */
	public InetAddress getIpaddress() {
		return ipaddress;
	}
	/**
	 * @param ipadsress the ipaddress to set
	 */
	public void setIpaddress(InetAddress ipaddress) {
		this.ipaddress = ipaddress;
	}
	/**
	 * @return the portnumber
	 */
	public int getPortnumber() {
		return portnumber;
	}
	/**
	 * @param portnumber the portnumber to set
	 */
	public void setPortnumber(int portnumber) {
		this.portnumber = portnumber;
	}
	/**
	 * @return the firstname
	 */
	public String getFirstname() {
		return firstname;
	}
	/**
	 * @param firstname the firstname to set
	 */
	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}
	/**
	 * @return the lastname
	 */
	public String getLastname() {
		return lastname;
	}
	/**
	 * @param lastname the lastname to set
	 */
	public void setLastname(String lastname) {
		this.lastname = lastname;
	}
	/**
	 * @return the dateofbirth
	 */
	public LocalDate getDateofbirth() {
		return dateofbirth;
	}
	/**
	 * @param dateofbirth the dateofbirth to set
	 */
	public void setDateofbirth(LocalDate dateofbirth) {
		this.dateofbirth = dateofbirth;
	}
	
	
	/**
	 * this method it to renew the Key after a mail was sent 
	 */
	public void mailSent() {
		this.listKeys.remove(0);
		BigInteger a = BigInteger.probablePrime(10, new Random());
		BigInteger b = BigInteger.probablePrime(10, new Random());
		BigInteger c = BigInteger.probablePrime(10, new Random());
		this.listKeys.add( new Key(a,b,c));
	}
	
	@Override
	public String toString() {
		return "MailUser [username=" + username + ", emailaddress=" + emailaddress + ", ipaddress=" + ipaddress
				+ ", portnumber=" + portnumber + ", firstname=" + firstname + ", lastname=" + lastname
				+ ", dateofbirth=" + dateofbirth + ", listKeys=" + listKeys + "]";
	}
	@Override
	public int hashCode() {
		return Objects.hash(username);
	}
	
	/**
	 * the equelas uses the username to compare
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		MailUser other = (MailUser) obj;
		return Objects.equals(username, other.username);
	}
	
	

	
	
	

}
