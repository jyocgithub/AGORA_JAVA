package entities;

import java.util.ArrayList;
import java.util.Iterator;

import comparators.ComparatorMailUserByDateofbirth;
import comparators.ComparatorMailUserByEmailadress;
import comparators.ComparatorMailUserByName;
/**
 * class that maintain a collection of MailUser
 * 
 * @author pablo
 *
 */
public class ContactList {

	// MailUser collection using DynamicSortedSet
	private DynamicSortedSet<MailUser> list;

	/**
	 * constructor that by default orders the collection by name
	 */
	public ContactList() {
		super();
		ComparatorMailUserByName comp = new ComparatorMailUserByName();
		list = new DynamicSortedSet<MailUser>(comp);
	}

	/**
	 * add a MailUser to the collection
	 * checks if the new mailUser is already in the collection, it checks by name or email address
	 * @param mailuser the MailUser that wants to be added
	 * @return true if it was added, or false if it wasnt added
	 */
	public boolean addMailUser(MailUser mailuser) {

		Iterator<MailUser> it = list.getIterator();
		while (it.hasNext()) {
			MailUser user = it.next();
			if (user.getUsername().equals(mailuser.getUsername())) {
				return false;
			}
			if (user.getEmailaddress() != null && mailuser.getEmailaddress() != null) {
				if (user.getEmailaddress().equals(mailuser.getEmailaddress())) {
					return false;
				}

			}
		}

		list.add(mailuser);
		return true;
	}
/**
 * remove a MailUser from the collection
 * @param username the name of the MailUser to be removed
 * @return true if it was removed, or false if it didnt exist
 */
	public boolean removeMailUser(String username) {

		Iterator<MailUser> it = list.getIterator();
		while (it.hasNext()) {
			MailUser user = it.next();
			if (user.getUsername().equals(username)) {
				it.remove();
				return true;
			}
		}

		return false;

	}
/**
 * changes the order of the collection to be ordered by name
 */
	public void changeOrderToName() {
		ComparatorMailUserByName comparatorName = new ComparatorMailUserByName();
		list.setComparator(comparatorName);
	}
	/**
	 * changes the order of the collection to be ordered by date of birth
	 */
	public void changeOrderToDateofbirth() {
		ComparatorMailUserByDateofbirth comparatorDate = new ComparatorMailUserByDateofbirth();
		list.setComparator(comparatorDate);
	}
	/**
	 * changes the order of the collection to be ordered by email address
	 */
	public void changeOrderToEmailadress() {
		ComparatorMailUserByEmailadress comparatorEmail = new ComparatorMailUserByEmailadress();
		list.setComparator(comparatorEmail);
	}
/**
 * generates an arraylist with all the MailUsers
 * @return the list of MailUser as a arrayList
 */
	public ArrayList<MailUser> getMailUserList() {

		ArrayList<MailUser> arraylist = new ArrayList<>();

		Iterator<MailUser> it = list.getIterator();
		while (it.hasNext()) {
			MailUser user = it.next();
			arraylist.add(user);
		}

		return arraylist;

	}
/**
 * returns a MailUser from a name given
 * @param usernamesearched name of the MailUser that wants to be returned
 * @return a MailUser or null if the name doesnt exist
 */
	public MailUser getMailUser(String usernamesearched) {
		Iterator<MailUser> it = list.getIterator();
		while (it.hasNext()) {
			MailUser user = it.next();
			if (user.getUsername().equals(usernamesearched)) {
				return user;
			}

		}
		return null;

	}

}
