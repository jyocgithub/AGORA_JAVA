package entities;
import java.math.BigInteger;
import java.time.LocalDate;
import java.util.Date;
/**
 * defines the key used when and email is sent 
 * @author pablo
 *
 */
public class Key {

	private BigInteger b1 ;
	private BigInteger b2 ;
	private BigInteger b3 ;
	private LocalDate timestamp;
	/**
	 * Getter for value of b1
	 * @return the b1
	 */
	public BigInteger getB1() {
		return b1;
	}
	/**
	 * Getter for value of b2
	 * @return the b2
	 */
	public BigInteger getB2() {
		return b2;
	}
	/**
	 * Getter for value of b3
	 * @return the b3
	 */
	public BigInteger getB3() {
		return b3;
	}
	
	
	
	/**
	 * Getter for value of Timestamp
	 * @return the timestamp
	 */
	public LocalDate getTimestamp() {
		return timestamp;
	}
	/**
	 * Constructor that had b1, b2 and b3 as parameter that are assigned to the attributes, 
	 * the value of Timestamp is the time at which the class is created. 
	 * @param b1
	 * @param b2
	 * @param b3
	 */
	public Key(BigInteger b1, BigInteger b2, BigInteger b3) {
		super();
		this.b1 = b1;
		this.b2 = b2;
		this.b3 = b3;
		this.timestamp = LocalDate.now();
	}

	
	
}
