package entities;
import java.util.Comparator;
import java.util.Iterator;
import java.util.Observable;
import java.util.Observer;
import java.util.TreeSet;


/**
 * class that implements a collection from a TreeSet
 * implements observer
 * this a generic class and defines the content of the class
 * 
 * @author pablo
 *
 * @param <T> class to be stored 
 */
public class DynamicSortedSet <T extends Observable> implements Observer {
	private Comparator comparator;
	private TreeSet<T> myset;
	
	/**
	 * adds a generic object T to the collection 
	 * @param something object to be added
	 */
    public void add(T something) {
      boolean success = myset.add(something);
    }
    /**
     * removes a generic object T to the collection
     * @param something something object to be removed
     */
    public void remove(T something) {
    	myset.remove(something);
    }
    /**
     * erases all content of the collection
     */
    public void clear() {
    	myset.clear();
    }
    /**
     * returns an iterator of the collection
     * @return an iterator
     */
    public Iterator<T> getIterator() {
    	return myset.iterator();
    }

	/**
	 * Constructor from the collection that applies a comparator 
	 * @param comparator the comparator to be used
	 */
	public DynamicSortedSet(Comparator comparator) {
		super();
		this.comparator = comparator;
		this.myset = new TreeSet<>(comparator);
	}


	/**
	 * Getter of Comparator field
	 * @return the comparator
	 */
	public Comparator getComparator() {
		return comparator;
	}


	/**
	 * Method that assigns a new comparator and transfers the 
	 * data from the old TreeSet(myset) to the new TreeSet (newSet) 
	 * @param comparator the comparator to set
	 */
	public void setComparator(Comparator newComparator) {
		TreeSet newSet = new TreeSet<>(newComparator);
		newSet.addAll(this.myset);
		this.myset = newSet;
	}


	@Override
	public void update(Observable o, Object arg) {
		// TODO Auto-generated method stub
		
	}

    
    
}
