package main;

import java.time.LocalDate;
import java.util.ArrayList;

import entities.ContactList;
import entities.MailUser;

public class MainClass {

	public static void main(String[] args) {
		
		
		ContactList c = new ContactList();

		MailUser mailuser1 = new MailUser("steve122", "steveemail", "steve", "howking", LocalDate.of(2000, 12, 7));
		c.addMailUser(mailuser1);
		
		MailUser mailuser2 = new MailUser("John", "johnemail", "john", "ed", LocalDate.of(2004, 10, 7));
		c.addMailUser(mailuser2);
		
		MailUser mailuser3 = new MailUser("Sven", "svenemail", "sven", "son", LocalDate.of(2000, 9, 17));
		c.addMailUser(mailuser3);
		
		MailUser mailuser4 = new MailUser("Steve122", "steveemail", "Steve", "Howking", LocalDate.of(2000, 12, 7));
		c.addMailUser(mailuser4);
		
		MailUser mailuser5 = new MailUser("Peter", "peteremail", "peter", "pan", LocalDate.of(1999, 2, 27));
		c.addMailUser(mailuser5);
		
		ArrayList<MailUser> listMailUser = c.getMailUserList();
		
		for ( MailUser m  :listMailUser) {
			System.out.println(m);

		}
		
	
		System.out.println("...................................");
		c.removeMailUser("Sven");
	
	   	listMailUser = c.getMailUserList();
		
		for ( MailUser m  :listMailUser) {
			System.out.println(m);

		}
		
		System.out.println("...................................");
		
		c.changeOrderToEmailadress();
		
	   	listMailUser = c.getMailUserList();
		
		for ( MailUser m  :listMailUser) {
			System.out.println(m);

		}
		
		System.out.println("...................................");
		MailUser mailuser = c.getMailUser("Peter");
		System.out.println(mailuser);
		
		 mailuser = c.getMailUser("Peterparker");
		System.out.println(mailuser);
		
		
		
		
		
		
		
	}

}
