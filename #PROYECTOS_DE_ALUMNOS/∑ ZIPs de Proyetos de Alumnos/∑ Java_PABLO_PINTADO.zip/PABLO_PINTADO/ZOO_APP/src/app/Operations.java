package app;

import entities.Caretaker;
import entities.areas.Pen;
import entities.areas.Zone;
import entities.animals.Animal;
import entities.animals.AnimalFactory;
import entities.animals.IAnimalFactory;
import entities.animals.Mammal;
import entities.areas.Zoo;
import entities.species.Species;
import entities.species.SpeciesCollection;
import plugintill.TillOperations;


import java.lang.reflect.InvocationTargetException;
import java.net.StandardSocketOptions;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class Operations {

    public static void main(String[] args) {
        new Operations();
    }

    public Operations() {
        // Do basic initializations

        // Create a Zoo consisting of zones, subzones, subsubzones and pens

        // Create a bunch of Caretakers. Keep track of all Caretakers in some Collection
        // so you can loop over it

        // Initialize an AnimalFactory using an anonymous inner class and get animals from it TODO
        // Then add the animals to the Zoo

        // Have several caretakers feed some animals. Use lambda expressions in that
        // Loop over all animals to pass time and see that their Caretakers get informed about
        // their pets getting hungry

        // Implement a plugin for acquiring new animals. The strategy used for that is to clone an existing animal.
        // Cloning has a fixed price defined in the plugin code itself
        // Run the test with the plugin as well


        Zoo zoo = new Zoo();
        Zone mainlevel = new Zone();
        zoo.addZone(mainlevel);
        Zone<Mammal> mammalarea = new Zone();
        mainlevel.addZone(mammalarea);

        Pen p1 = new Pen(2);
        Pen p2 = new Pen(2);
        Pen p3 = new Pen(2);

        mammalarea.addZone(p1);
        mammalarea.addZone(p2);
        mammalarea.addZone(p3);

        Caretaker ct1 = new Caretaker("Paul");
        Caretaker ct2 = new Caretaker("Sue");
        zoo.addCaretaker(ct1);
        zoo.addCaretaker(ct2);

        Species tiger1 = SpeciesCollection.instance().get("Tiger");
        Species panda1 = SpeciesCollection.instance().get("Panda");

        IAnimalFactory ani1 = AnimalFactory.getAnimal("tiger", ct1, tiger1, "Fran", LocalDate.now(), Animal.Gender.MALE, 12);
        IAnimalFactory ani2 = AnimalFactory.getAnimal("tiger", ct2, tiger1, "Joe", LocalDate.now(), Animal.Gender.MALE, 13);
        IAnimalFactory ani3 = AnimalFactory.getAnimal("panda", ct1, panda1, "Isabelle", LocalDate.now(), Animal.Gender.FEMALE, 1);

        zoo.addAnimal((Animal) ani1);
        zoo.addAnimal((Animal) ani2);
        zoo.addAnimal((Animal) ani3);

        Animal animal1= (Animal) ani1;
        if(zoo.isPresent(animal1)){
            System.out.println("\nConfirmed, "+animal1.getName()+" lives in this zoo\n");
        }

        ani1.feed(() -> 3,ct1);
        for (int i = 0; i < 100; i++) {
            ani1.timePasses();
        }
        ani1.feed(() -> 3,ct1);

        for (Caretaker c : zoo.getListCaretaker()) {
        	System.out.println("\n==== Information of caretaker "+ c.getName());
            for (Animal a : c.getPets()) {
                for (int i = 0; i < 20; i++) {
                    a.timePasses();
                }
            }
        }

        for (Caretaker c : zoo.getListCaretaker()) {
        	System.out.println("\n---- Time of feeding: Carataker "+ c.getName());

            for (Animal a : c.getPets()) {
                a.feed(() -> 3, c);
            }
        }

        System.out.println("\n");

        // a strange is feeding....
        animal1.feed(() -> 3, null);

    }









}
