package entities.species;


import java.math.BigDecimal;
import java.util.*;

import entities.animals.Animal;
import entities.species.Species.Type;

//
//There can be only one SpeciesCollection ever!
//
public class SpeciesCollection implements Set<Species>{
	private Map<String, Species> mapOfSpecies;

	// Applies Singleton Pattern
	private static SpeciesCollection  speciesCollectionInstance ;

	public static SpeciesCollection instance() {
		if(speciesCollectionInstance == null){
			speciesCollectionInstance = new SpeciesCollection();
		}
		return speciesCollectionInstance;
	}
	
	public SpeciesCollection() {
		this.mapOfSpecies =  new HashMap<>();
		readSpeciesFromStorage();
	}

	// The following implementation is inefficient. Improve this class so the looping is not necessary.
	// As part of that you will need to implement a custom iterator using an inner class.
	public Species get(String commonName) {
		return mapOfSpecies.get(commonName);
	}

	@Override
	public int size() {
		return mapOfSpecies.size();
	}

	@Override
	public boolean isEmpty() {
		return mapOfSpecies.isEmpty();
	}

	@Override
	public boolean contains(Object o) {
		return mapOfSpecies.containsValue(o);
	}

	@Override
	public Iterator<Species> iterator() {
		return new SpeciesIterator();
	}

	@Override
	public Object[] toArray() {
		return mapOfSpecies.values().toArray();
	}

	@Override
	public <T> T[] toArray(T[] a) {
		return mapOfSpecies.values().toArray(a);
	}

	@Override
	public boolean add(Species e) {
		mapOfSpecies.put(e.getCommonName(),e);
		return true;
	}

	@Override
	public boolean remove(Object o) {
		return mapOfSpecies.remove(((Species)o).getCommonName()) != null;

	}

	@Override
	public boolean containsAll(Collection<?> c) {
		return mapOfSpecies.keySet().containsAll(c);
	}

	@Override
	public boolean addAll(Collection<? extends Species> c) {
		for (Object o: c) {
			Species sp = (Species) o;
			mapOfSpecies.put(sp.getCommonName(), sp);
		}
		return true;
	}

	@Override
	public boolean retainAll(Collection<?> c) {
		boolean result = false;
		SpeciesIterator speciesIterator = new SpeciesIterator();
		while (speciesIterator.hasNext()) {
			Species s = speciesIterator.next();
			if (!c.contains(s)) {
				speciesIterator.remove();
				result = true;
			}
		}
		return result;
	}

	@Override
	public boolean removeAll(Collection<?> c) {
		boolean result = false;
		for (Object o: c) {
			if (mapOfSpecies.remove((Species) o).getCommonName()!=null) {
				result = true;
			}
		}
		return result;
	}

	@Override
	public void clear() {
		mapOfSpecies.clear();
	}
	
	//
	// Feel free to add more species yourself here
	// Feel free to create specific subclasses of Animal to make the
	// application more versatile
	//
	private void readSpeciesFromStorage() {
		add(new Species("Tiger", 8, 550, new BigDecimal("15000"), Species.Type.SCARY,Animal.Gender.FEMALE  , Animal.Gender.FEMALE));
		add(new Species("Polar Bear", 777, 9, new BigDecimal("15000"), Species.Type.SCARY, Animal.Gender.MALE, Animal.Gender.FEMALE));
		add(new Species("Panda", 18, 333, new BigDecimal("1500"), Species.Type.FLUFFY, Animal.Gender.MALE, Animal.Gender.FEMALE));
		add(new Species("Tarantula", 1, 1, new BigDecimal("15"), Species.Type.CREEPY, Animal.Gender.MALE, Animal.Gender.FEMALE));
		add(new Species("Cobra", 3, 2, new BigDecimal("22"), Species.Type.CREEPY, Animal.Gender.MALE, Animal.Gender.FEMALE));
	}


	private class SpeciesIterator implements Iterator<Species> {
		private Iterator<Map.Entry<String, Species>> iterator;

		public SpeciesIterator() {
			iterator = mapOfSpecies.entrySet().iterator();
		}

		@Override
		public boolean hasNext() {
			return iterator.hasNext();
		}

		@Override
		public Species next() {
			return iterator.next().getValue();
		}

		@Override
		public void remove() {
			iterator.remove();
		}
	}

}
