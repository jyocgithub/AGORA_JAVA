package entities;


import entities.animals.Animal;
import entities.areas.Zone;
import entities.areas.Zoo;

import java.math.BigInteger;
import java.util.*;

//
// A Caretaker is a person who cleans Pens and feeds the animals
// Each Caretaker knows what Animals to take care of
// If an Animal in his care is being fed by someone else the Caretaker wants to know
// If an Animal in his care reaches maximum hungriness he also wants to know
//
// Anytime a pet is added the Animal should update its Caretaker.
// Anytime a pet is removed the Animal should set its Caretaker to null, unless the
// Animal just died (then there is no caretaker anymore.)
//
public class Caretaker implements Observer {
    private final int id;
    private String name;
    private static BigInteger currentId = new BigInteger("100057");
    private Set<Animal> pets;
    private Zone myZoo;

    public Caretaker(String name) {
        super();
        this.name = name;
        currentId = currentId.nextProbablePrime();
        this.id = currentId.intValue();
        this.pets = new HashSet<>();
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getId() {
        return id;
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }

    public boolean addPet(Animal animal) {
        animal.setCaretaker(this);
        // the animal is added to the set "pets" in method update  ( the observer area)
        return true;
    }

    public boolean removePet(Animal animal) {
        animal.setCaretaker(null);
        // the animal is removed to the set "pets" in method update  ( the observer area)
        return true;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        Caretaker other = (Caretaker) obj;
        return id == other.id;
    }

    @Override
    public String toString() {
        return "Caretaker [id=" + id + ", name=" + name + "]";
    }

    @Override
    public void update(Observable o, Object arg) {
        if (arg.equals(Animal.NEW_CARETAKER)) {
            Animal a = (Animal) o;

            if (!pets.contains(a)) {
                pets.add(a);
                System.out.println("I've got a new animal to care !! Welcome  " + a.getName());
            } else {
                System.out.println("The animal " + a.getName() + " already exists in my pets !!");
            }
        }
        if (arg.equals(Animal.MISS_CARETAKER)) {
            Animal a = (Animal) o;
            if (pets.contains(a)) {
                pets.remove(a);
                System.out.println("I'm loosing a old friend, " + a.getName());

            } else {
                System.out.println("I don't have any animal like " + a.getName());
            }
        }
        if (arg.equals(Animal.FEEDING)) {
            Animal a = (Animal) o;
            System.out.println(a.getName() + " is feeding... he is " + a.getHungriness() + " hungry!");
            a.checkHungriness();


        }
        if (arg.equals(Animal.TOO_HUNGRY)) {
            Animal a = (Animal) o;
            System.out.println(a.getName() + " needs help !!, he is " + a.getHungriness() + " hungry!");
            a.feed(() -> 10, this);
            System.out.println(a.getName() + " well, now he is " + a.getHungriness() + " hungry.");
        }
        if (arg.equals(Animal.FEEDING_ALIEN)) {
            Animal a = (Animal) o;
            System.out.println(a.getName() + " is feeding BY A STRANGE !!!!!!!!! ... he is " + a.getHungriness() + " hungry!");
            Zoo zoo = (Zoo) a.getCaretaker().myZoo;
            zoo.alertCaretakers(a);
            System.out.println("I'm " + name + " and notice that " + a.getName() + " is feeding BY A STRANGE !!!!!!!!! Call " + a.getCaretaker().getName() + " immediately !!!!");
        }
    }

    public Set<Animal> getPets() {
        return pets;
    }

    public Zone getMyZoo() {
        return myZoo;
    }

    public void setMyZoo(Zone myZoo) {
        this.myZoo = myZoo;
    }
}
