package entities.areas;




import entities.Caretaker;
import entities.animals.Animal;
import entities.species.Species;
import plugintill.Till;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

//
// 			A Zone can contain other Zones and / or Pens.
//			 Only animals of one Species can be put in a Zone. For the sake of simplicity it is 
//			 parameterized with an Animal (or subclass thereof); the species of that animal determines
//			 what can be put in the pen.
//			This could potentially lead to conflicts due to a Pen allowing a broader category
//			 of inhabitants than the Zone it is in. You can ignore this possibility for this assignment.

// Please note parts of this code are incorrect and need to be corrected for a good
// implementation of the assignment
//
//
public class Zone<T extends Animal> {
    private ArrayList<Zone> listzones = new ArrayList<>();



    public Zone() {
        super();
    }

    //
    //             If the animal is already present do not add it

    //              If the zone is completely full do not add the animal
    //            If there is room check whether there already is a Pen with room
    //              for that animal containing the same species; if so, add it there
    //             If not check for an empty Pen and add it there
    //            If this fails return false
    //           Return true if adding was succesfull, false otherwise
    //
    public boolean addAnimal(T newanimal) {
        if (isPresent(newanimal)) {
            return false;
        }
        boolean added = false;
        Animal a = (Animal) newanimal;
        Pen pok = getAvailablePen(a.getSpecies());
        if (pok != null) {
            System.out.println("...Found a EXISTING Pen for "+a);
            pok.addAnimal(newanimal);
            return true;
        }

        // no se ha metido, asi que busco UNA JAULA VACIA
        Pen p = getEmptyPen();
        if (p == null) {
            return false;
        }

            System.out.println("...Found a EMPTY Pen for "+a);
        p.addAnimal(newanimal);
        return true;

    }

    //
    // Remove the animal if it is present
    //
    public boolean removeAnimal(T animal) {

        for (int i = 0; i < this.listzones.size(); i++) {
            if (this.listzones.get(i) instanceof Pen) {
                Pen p = (Pen) listzones.get(i);
                Iterator it = p.getInhabitants().iterator();
                while (it.hasNext()) {
                    Animal a = (Animal) it.next();
                    if (a.equals(animal)) {
                        it.remove();
                        return true;
                    }
                }
            }
        }
        return false;
    }

    //
    // Check whether the animal is present in the Zone or any of its subzones or
    // Pens
    //
    public boolean isPresent(T animal) {

        for (int i = 0; i < this.listzones.size(); i++) {
            if (this.listzones.get(i) instanceof Pen) {
                Pen p = (Pen) listzones.get(i);
                if (p.isPresent(animal)) {
                    return true;
                }
            }else{
              return this.listzones.get(i).isPresent(animal) ;
            }
        }
        return false;
    }

    //
    // Return a Pen with the same species and room for another animal, or null if
    // absent
    // Might need some adaptation
    //
    public Pen<T> getAvailablePen(Species species) {
        for (int i = 0; i < this.listzones.size(); i++) {

            if (this.listzones.get(i) instanceof Pen) {
                Pen p = (Pen) listzones.get(i);

                if(p.getAvailablePen(species)!=null){
                    return p;
                }

            }else{
            	Pen p = this.listzones.get(i).getAvailablePen(species);
            	if(p!=null){
            		return p;
            	}
            }
        }
        return null;
    }

    //
    // Return an empty Pen or null of no such Pen exists
    // Might need some adaptation
    //
    public Pen<T> getEmptyPen() {
        for (int i = 0; i < this.listzones.size(); i++) {

            if (this.listzones.get(i) instanceof Pen) {
                Pen p = (Pen) listzones.get(i);
                if (p.getEmptyPen() != null) {
                    return p;
                }
            }else{
               Pen p =  this.listzones.get(i).getEmptyPen();
               if(p!=null) {
            	   return p;
               }
            }
        }
        return null;
    }

    public boolean addZone(Zone z) {
        if (listzones.contains(z)) {
            return false;
        }
        listzones.add(z);
        return true;
    }
}
