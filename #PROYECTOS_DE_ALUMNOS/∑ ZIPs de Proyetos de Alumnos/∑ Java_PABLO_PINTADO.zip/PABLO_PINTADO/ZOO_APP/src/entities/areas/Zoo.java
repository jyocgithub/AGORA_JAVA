package entities.areas;


import entities.Caretaker;
import entities.animals.Animal;
import plugintill.Till;
import plugintill.TillOperations;

import java.util.ArrayList;
import java.util.List;
import java.util.Observer;

public class Zoo extends Zone {

    TillOperations ope = new TillOperations();
    private Till zooTill;
    private List<Caretaker> listCaretaker = new ArrayList<>();

    @Override
    public boolean addAnimal(Animal b) {
        if (super.addAnimal((Animal) b)) {
            ope.addAnimal();
            System.out.println("Zoo funds----> " + ope.getFounds());
            return true;
        }
        return false;
    }

    @Override
    public boolean removeAnimal(Animal b) {
        if (super.removeAnimal((Animal) b)) {
            ope.addAnimal();
            System.out.println(ope.getFounds());
            return true;
        }
        return false;
    }


    public void alertCaretakers(Animal a) {
        for (Caretaker c : listCaretaker) {
            // using indirectly observer pattern
            c.update(a,Animal.GLOBAL_FEED_ALERT);
        }
    }


    public void addCaretaker(Caretaker c) {
        c.setMyZoo(this);
        listCaretaker.add(c);
    }


    public List<Caretaker> getListCaretaker() {
        return listCaretaker;
    }
}
