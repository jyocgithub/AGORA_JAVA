package entities.animals;




import entities.Caretaker;
import entities.species.Species;

import java.time.LocalDate;

public class Panda extends Mammal implements IAnimalFactory{

    public Panda(Caretaker caretaker, Species species, String name, LocalDate dateOfBirth, Gender gender, int weight) {
        super(caretaker, species, name, dateOfBirth, gender, weight);
    }

}
