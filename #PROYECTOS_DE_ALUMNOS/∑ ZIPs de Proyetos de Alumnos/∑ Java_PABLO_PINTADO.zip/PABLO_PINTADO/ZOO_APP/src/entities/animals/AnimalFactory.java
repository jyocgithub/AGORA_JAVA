package entities.animals;



import entities.Caretaker;
import entities.species.Species;

import java.time.LocalDate;

public class AnimalFactory {
    public static IAnimalFactory getAnimal(String kind, Caretaker caretaker, Species species, String name, LocalDate dateOfBirth, Animal.Gender gender, int weight) {
        if (kind.equals("panda"))
            return new Panda(caretaker, species, name,dateOfBirth, gender, weight);
        else if (kind.equals("tiger"))
            return new Tiger(caretaker, species, name,dateOfBirth, gender, weight);
        return null;
    }


}
