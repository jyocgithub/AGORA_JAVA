package entities.animals;


import entities.Caretaker;
import entities.IFood;

public interface IAnimalFactory {

    void feed(IFood food, Caretaker caretaker);

    void timePasses();

    void die();
}

