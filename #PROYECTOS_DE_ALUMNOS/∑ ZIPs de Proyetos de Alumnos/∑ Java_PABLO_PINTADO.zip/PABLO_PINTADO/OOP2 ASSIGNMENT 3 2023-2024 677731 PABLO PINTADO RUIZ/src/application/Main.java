package application;
	
import javafx.application.Application;
import javafx.stage.Stage;
import utils.FXUtils;
import javafx.scene.Scene;
import javafx.scene.layout.BorderPane;

/**
 * 
 * Main class which starts the application
 * @author pablo
 *
 */
public class Main extends Application {
	
	/**
	 * Automatically Starts method, this method open the main scene, 
	 * @primaryStage stage where the scene is located
	 */
	@Override
	public void start(Stage primaryStage) {
		try {
			
			FXUtils.iniciaScene(primaryStage,"/views/MainWindow.fxml", "MAIN MENU");

		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public static void main(String[] args) {
		// executes start method like a thread
		launch(args);
	}
}
