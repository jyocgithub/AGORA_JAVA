package entities;

import java.util.Objects;
/**
 * Javabean class to model a planet 
 * this contains the typical javabean methods like getter,s setters, constructor, equals, tostring...
 * @author pablo
 *
 */
public class Planet {
    private String name;
    private int diameter;
	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}
	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}
	/**
	 * @return the diameter
	 */
	public int getDiameter() {
		return diameter;
	}
	/**
	 * @param diameter the diameter to set
	 */
	public void setDiameter(int diameter) {
		this.diameter = diameter;
	}
	/**
	 * @param name
	 * @param diameter
	 */
	public Planet(String name, int diameter) {
		super();
		this.name = name;
		this.diameter = diameter;
	}
	@Override
	public int hashCode() {
		return Objects.hash(diameter, name);
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Planet other = (Planet) obj;
		return diameter == other.diameter && Objects.equals(name, other.name);
	}
	@Override
	public String toString() {
		return "Planet [name=" + name + ", diameter=" + diameter + "]";
	}
    
    
    
}
