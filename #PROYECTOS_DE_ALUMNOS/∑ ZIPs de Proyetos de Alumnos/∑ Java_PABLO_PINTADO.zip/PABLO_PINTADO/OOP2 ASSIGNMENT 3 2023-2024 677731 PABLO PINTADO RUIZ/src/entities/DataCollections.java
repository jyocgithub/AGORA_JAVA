package entities;

import java.util.ArrayList;
import java.util.List;

import javafx.scene.layout.AnchorPane;


/**
 * class that contains the collections and nodes shared throut all the scenes
 * @author pablo
 *
 */
public class DataCollections {
	
		public static List<Star> listStar = new ArrayList<Star>();
		public static List<Species> listSpecies = new ArrayList<Species>();

	    public static AnchorPane centerPaneReference;

}
