package controllers;


import entities.Planet;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
/**
 * class controller for the details scene
 * @author pablo
 */
public class DetailsWindowController {

	//  all of these are the nodes in the scene
    @FXML
    private TextField iddistancebox;

    @FXML
    private TextField idlattitidebox;

    @FXML
    private TextField idlongitudebox;

    @FXML
    private TextField idluminositybox;

    @FXML
    private Label idname;

    @FXML
    public  AnchorPane manipane;

    @FXML
    private TextField idtemperaturebox;

    @FXML
    private TextField idtypebox;
    

    @FXML
    private ListView    idplanetlistbox;
    
    /**
     * this method is executed when the scene is created 
     */
   	@FXML
	void initialize() {
		idname.setText("Details od star : "+ PlanetListWindowController.selectedStar.getName()) ;
		idtypebox.setText(PlanetListWindowController.selectedStar.getType());
		iddistancebox.setText(PlanetListWindowController.selectedStar.getDistanceInParsecs()+"");
		idlongitudebox.setText(PlanetListWindowController.selectedStar.getLongitudeInDecimalDegrees()+"");
		idluminositybox.setText(PlanetListWindowController.selectedStar.getLuminosityClass()+"");
		idtemperaturebox.setText(PlanetListWindowController.selectedStar.getTemperatureSequence()+"");
        idlattitidebox.setText(PlanetListWindowController.selectedStar.getLattitudeInDecimalHours()+"");

		String text ="";
		for( Planet p  : PlanetListWindowController.selectedStar.getListOfPlanets()      ) {
		     idplanetlistbox.getItems().add(p.getName());
		}
	}
}