package controllers;

import javafx.fxml.FXML;

import javafx.scene.control.Button;

import javafx.scene.control.TextField;
import utils.FXUtils;

import java.io.IOException;

import javax.imageio.metadata.IIOMetadataController;

import entities.DataCollections;
import entities.Star;
import javafx.event.ActionEvent;

import javafx.scene.control.ListView;

import javafx.scene.control.Label;

/**
 * class controller for the planet list window scene
 * 
 * @author pablo
 */
public class PlanetListWindowController {
	//  all of these are the nodes in the scene

	@FXML
	private ListView idlistofplanets2;
	@FXML
	private Label idlistofplanets;
	@FXML
	private TextField idnumberofplanets2;
	@FXML
	private Button iddetails;
	@FXML
	private Button idadd;
	@FXML
	private Button iddelete;
	@FXML
	private Label ifnumberofplanets;

	public static Star selectedStar = null;

	/**
     * this method is executed when the scene is created 
     * in this case it creates the list of stars 
     * and adds a listener to each star to show the number of planets
     */
	@FXML
	void initialize() {

		// put stars on list
		for (Star star : DataCollections.listStar) {
			idlistofplanets2.getItems().add(star.getName());
		}

		idlistofplanets2.setOnMouseClicked(event -> {
			int position = idlistofplanets2.getSelectionModel().getSelectedIndex();
			if (position >= 0) {
				Star star = DataCollections.listStar.get(position);
				int numberofplanets = star.getListOfPlanets().size();

				idnumberofplanets2.setText(numberofplanets + "");
				selectedStar =  star;
			}
		});
	}

	/**
	 * listener to show the detail window of a star
	 * @param event
	 */
	// Event Listener on Button[#iddetails].onAction
	@FXML
	public void onDetails(ActionEvent event) {
		FXUtils.addFXMLtoAnchorPane("/views/DetailsWindow.fxml", 	DataCollections.centerPaneReference);
	}

	/**
	 * Listener to add starts to the stars collection
	 * @param event
	 */
	// Event Listener on Button[#idadd].onAction
	@FXML
	public void onAdd(ActionEvent event) {
		FXUtils.newStar();
		DataCollections.listStar.clear();
		for (Star star : DataCollections.listStar) {
			idlistofplanets2.getItems().add(star.getName());
		}
	}
	/**
	 * listener to delete selected stars from the stars collection
	 * @param event
	 */
	// Event Listener on Button[#iddelete].onDelete
	@FXML
	public void onDelete(ActionEvent event) {

		int position = idlistofplanets2.getSelectionModel().getSelectedIndex();
		if (position >= 0) {
			DataCollections.listStar.remove(position);
			initialize();

		}
	}
}
