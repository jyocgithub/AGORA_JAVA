package controllers;

import entities.DataCollections;
import entities.Planet;
import entities.Species;
import entities.Star;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.MenuItem;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.VBox;
import utils.FXUtils;
import utils.Settings;
import utils.charts.*;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.Random;

/**
 * class controller for the main scene, including the menu
 * 
 * @author pablo
 */
public class MainWindowController {

//  all of these are the nodes in the scene
	@FXML
	private MenuItem idbar;

	@FXML
	private MenuItem idpie;

	@FXML
	private MenuItem idscatter;

	@FXML
	public AnchorPane centerPane;

	@FXML
	private AnchorPane anchorMain;

	@FXML
	private MenuItem itemabout;

	@FXML
	private MenuItem itemcreatespecies;

	@FXML
	private MenuItem itemcreatestar;

	@FXML
	private MenuItem itemexit;

	@FXML
	private MenuItem itemloadspecies;

	@FXML
	private MenuItem itemloadstar;

	@FXML
	private MenuItem itemnewspecies;

	@FXML
	private MenuItem itemnewstar;

	@FXML
	private MenuItem itemshowspecies;

	@FXML
	private MenuItem itemshowstar;

	/**
	 * this method is executed when the scene is created it automatically reads the
	 * Stars file so I don´t have to keep loading the starts file
	 */
	@FXML
	void initialize() {
		readStarsFile(Settings.STARS_FILE);
	}

	/**
	 * reads the Species file and allows you to read any other files
	 * 
	 * @param event
	 */
	@FXML
	void onLoadSpecies(ActionEvent event) {
		readSpeciesFile(Settings.SPECIES_FILE);

		boolean yesornot = FXUtils.confirmationMessage("Would you like to read any other files");
		if (yesornot) {
			// add new species

			String filename = FXUtils.inputMessage("Name of file with species:");
			if (filename != null) {
				readSpeciesFile(filename);
			}

		}

	}

	/**
	 * reads the Stars file and allows you to read any other files
	 * 
	 * @param event
	 */
	@FXML
	void onLoadStar(ActionEvent event) {
		DataCollections.listStar.clear();

		readStarsFile(Settings.STARS_FILE);

		boolean yesornot = FXUtils.confirmationMessage("Would you like to to readd any other files?");
		if (yesornot) {
			// add new stars

			String filename = FXUtils.inputMessage("Name of file with stars:");
			if (filename != null) {
				readStarsFile(filename);
			}

		}

	}

	/**
	 * method that reads the stars file and fills the stars array
	 * 
	 * @param filename this is the name of the field from which to read the stars
	 */
	public void readStarsFile(String filename) {
		File archivo = new File(filename);

		if (archivo.exists()) {
			BufferedReader br = null;
			try {
				br = new BufferedReader(new FileReader(archivo));

				String linea = br.readLine();
				linea = br.readLine();
				while (linea != null) {
					if (!linea.isEmpty()) {
						String trozos[] = linea.split(";");
						Star star = new Star(trozos[0], trozos[1], Integer.parseInt(trozos[2]), trozos[3],
								Double.parseDouble(trozos[4]), Double.parseDouble(trozos[5]),
								Double.parseDouble(trozos[6]));
						// add planets to the star
						fillPlanets(star);
						DataCollections.listStar.add(star);
						System.out.println(star);
					}
					linea = br.readLine();
				}
			} catch (IOException ex) {
				ex.printStackTrace();
			} finally {
				try {
					br.close();
				} catch (IOException ex) {
					ex.printStackTrace();
				}
			}
		}
	}

	/**
	 * method that reads the species file and fills the stars array
	 * 
	 * @param filename this is the name of the field from which to read the species
	 */
	public void readSpeciesFile(String filename) {
		File archivo = new File(filename);

		if (archivo.exists()) {
			BufferedReader br = null;
			try {
				br = new BufferedReader(new FileReader(archivo));

				String linea = br.readLine();
				linea = br.readLine();
				while (linea != null) {
					if (!linea.isEmpty()) {
						String trozos[] = linea.split(";");

						if (trozos.length == 14) {
							Species specie = new Species(trozos[0], trozos[1], trozos[2], trozos[3], trozos[4],
									trozos[5], Integer.parseInt(trozos[6]), trozos[7], trozos[8], trozos[9], trozos[10],
									trozos[11], trozos[12], trozos[13]);

							DataCollections.listSpecies.add(specie);
							System.out.println(specie);
						}
					}
					linea = br.readLine();
				}
			} catch (IOException ex) {
				ex.printStackTrace();
			} finally {
				try {
					br.close();
				} catch (IOException ex) {
					ex.printStackTrace();
				}
			}
		}
	}

	/**
	 * creates randomly planets and adds them to a star
	 * 
	 * @param star a star where the planets will be added to
	 */
	public void fillPlanets(Star star) {
		Random random = new Random();
		int number = random.nextInt(9);
		for (int i = 0; i < number; i++) {
			int diameter = random.nextInt(2000) + 50;
			Planet p = new Planet(FXUtils.randomString(), diameter);
			star.getListOfPlanets().add(p);
		}
	}

	/**
	 * Listener for option menu Help, it displays the message bellow
	 * 
	 * @param event
	 */
	@FXML
	void onHelp(ActionEvent event) {
		String text = "This is an application to display and add stars";
		FXUtils.message(text, "HELP");
	}

	/**
	 * Listener for option menu New Star, this creates a new star and refreshes star
	 * list
	 * 
	 * @param event
	 */
	@FXML
	void onNewStar(ActionEvent event) {
		FXUtils.newStar();
		onLoadStar(event);
	}

	/**
	 * Listener for option menu Show Star and displays all the stars
	 * 
	 * @param event
	 */
	@FXML
	void onShowStars(ActionEvent event) {
		DataCollections.centerPaneReference = centerPane;
		FXUtils.addFXMLtoAnchorPane("/views/PlanetListWindow.fxml", DataCollections.centerPaneReference);
	}

	/**
	 * Listener for option menu Pie, creates a pichart showing the stars temperature
	 * 
	 * @param event
	 */
	@FXML
	void onPie(ActionEvent event) {
		IChartFactory ch = ChartFactory.getChartType("pie", "Temperature");
		if (ch != null) {
			for (Star star : DataCollections.listStar) {
				System.out.println(star.getName());
				ch.addData(star.getName(), star.getTemperatureSequence() + "");
			}
			VBox boxchar = ch.getChart();
			centerPane.getChildren().clear();
			centerPane.getChildren().add(boxchar);
		}
	}

	/**
	 * creates a line chart with the lattitude and longitude of the stars
	 * 
	 * @param event
	 */

	@FXML
	void onLineChart(ActionEvent event) {
		IChartFactory ch = ChartFactory.getChartType("line", "Lattitude of stars");
		if (ch != null) {
			MyLineChart bh = (MyLineChart) ch;
			bh.setAxisxname("Stars name");
			bh.setAxisyname("Lattitude/Longitude");
			bh.setSeriename("");

			for (Star start : DataCollections.listStar) {
				bh.addDataBySerie(start.getName(), start.getLattitudeInDecimalHours() + "", 1);
				bh.addDataBySerie(start.getName(), start.getLongitudeInDecimalDegrees() + "", 2);
			}
			VBox boxchar = ch.getChart();
			centerPane.getChildren().clear();
			centerPane.getChildren().add(boxchar);
		}
	}

	/**
	 * this exits the application
	 * 
	 * @param event
	 */
	@FXML
	void onExit(ActionEvent event) {
		Platform.exit();
	}

	/**
	 * creates a bar chart with the distance to the stars
	 * 
	 * @param event
	 */
	@FXML
	void onBar(ActionEvent event) {
		IChartFactory ch = ChartFactory.getChartType("bar", "Distance of stars");
		if (ch != null) {
			MyBarChart bh = (MyBarChart) ch;
			bh.setAxisxname("Stars name");
			bh.setAxisyname("Parsecs");
			bh.setSeriename("");

			for (Star start : DataCollections.listStar) {
				ch.addData(start.getName(), start.getDistanceInParsecs() + "");
			}
			VBox boxchar = ch.getChart();
			centerPane.getChildren().clear();
			centerPane.getChildren().add(boxchar);
		}
	}
}
