package utils;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.net.URL;
import java.util.Optional;
import java.util.Random;

import entities.Star;
import javafx.application.Platform;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Dialog;
import javafx.scene.control.DialogPane;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.control.TextInputDialog;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class FXUtils {

	
	 /**
     * INICIA SCENE creates a scene in assigned stage given by parameter and starts the scene 
     * 
     * @param esteStage, where the scene is created
     * @param pFicheroControllerFXML,  fxml file that has the structure of the scene
     * @param pTittleWindow, tittle of the window
     * @throws IOException, exception throwed if fxml file doesnt exist
     */
    public static void iniciaScene(Stage esteStage, String pFicheroControllerFXML, String pTittleWindow)
            throws IOException {

        URL recurso = FXUtils.class.getResource(pFicheroControllerFXML);
        FXMLLoader fxmlLoader = new FXMLLoader(recurso);
        Parent parent = fxmlLoader.load();
        Scene scene = new Scene(parent);
        esteStage.setScene(scene);
        esteStage.setTitle(pTittleWindow);
        esteStage.show();
    }

  
	
    /**
     * ADD FFML TO ANCHORPANE adds a FXML not as a scene but inside a pane
     *
     * @param pFicheroControllerFXML , fxml file that has the structure of the scene
     * @param pane the pane where the fxml is added 
     * @return  the node created from fxml nad has been added to the pane  
     */
    public static Node addFXMLtoAnchorPane(String pFicheroControllerFXML, Pane pane) {
        Parent parent = null;
        try {
            URL recurso = FXUtils.class.getResource(pFicheroControllerFXML);
            FXMLLoader fxmlLoader = new FXMLLoader(recurso);
            parent = fxmlLoader.load();
            pane.getChildren().clear();
            pane.getChildren().add(parent);

        } catch (IOException e) {
            e.printStackTrace();
        }
        return parent;
    }
	
	/**
	 * message that makes a question to the user 
	 * @param text  of the question 
	 * @return true if user says yes and false if user says no
	 */
    public static boolean confirmationMessage(String text) {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Message");
        alert.setContentText(text);
//        alert.showAndWait();

        Optional<ButtonType> result = alert.showAndWait();
        if (result.get() == ButtonType.OK) {
          
            alert.close();
            return true;
        } else {
            // ... cuando eligen no o cancelan el dialog
            
            alert.close();
            return false;
        }
    }
	/**
	 * message so that user introduces a value
	 * @param texto of the question
	 * @return the text given by the user
	 */
    public static String inputMessage(String text) {

        TextInputDialog dialog = new TextInputDialog("");
        dialog.setContentText(text);

        Optional<String> result = dialog.showAndWait();
        if (result.isPresent()) {
            return result.get();
        }
        return null;

    }
/**
 * This creates a text with random letters, with a random length between 3 and 10
 * @return the text created 
 */
    public static String randomString() {
        Random random = new Random();

        char[] word = new char[random.nextInt(8) + 3]; // words of length 3 through 10. 
        for (int j = 0; j < word.length; j++) {
            word[j] = (char) ('a' + random.nextInt(26));
        }
        return new String(word);

    }
/** 
 * simple message that informs about somethig
 * @param pText, the text given
 * @param pTittle , user tittle 
 */
    public static void message(String pText, String pTittle) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(pTittle);
        alert.setContentText(pText);
        alert.showAndWait();
    }
	/**
	 * this is a dialog where the user is asked data of the Start in order to create it 
	 * and the created star is added to the stars file
	 */
   public static  void newStar() {

		Dialog<Star> dialog = new Dialog<>();
		dialog.setTitle("Create a Star");
		dialog.setHeaderText("Complete the fields below;");
		DialogPane dialogPane = dialog.getDialogPane();
		dialogPane.getButtonTypes().addAll(ButtonType.OK, ButtonType.CANCEL);

		Label label1 = new Label("Nombre");
		TextField textFieldName = new TextField("");
		Label label2 = new Label("Type");
		TextField textFieldType = new TextField("");
		Label label3 = new Label("temperatureSequence");
		TextField textFieldtemperatureSequence = new TextField("");
		Label label4 = new Label("luminosityClass");
		TextField textFieldluminosityClass = new TextField("");
		Label label5 = new Label("distanceInParsecs");
		TextField textFielddistanceInParsecs = new TextField("");
		Label label6 = new Label("longitudeInDecimalDegrees");
		TextField textFieldlongitudeInDecimalDegrees = new TextField("");
		Label label7 = new Label("lattitudeInDecimalHours");
		TextField textFieldlattitudeInDecimalHours = new TextField("");

		dialogPane.setContent(new VBox(8, label1, textFieldName, label2, textFieldType, label3,
				textFieldtemperatureSequence, label4, textFieldluminosityClass, label5, textFielddistanceInParsecs,
				label6, textFieldlongitudeInDecimalDegrees, label7, textFieldlattitudeInDecimalHours));

		// Platform.runLater(textField1::requestFocus);
		dialog.setResultConverter((ButtonType button) -> {
			if (button == ButtonType.OK) {
				Star star = new Star(textFieldName.getText(), textFieldType.getText(),
						Integer.parseInt(textFieldtemperatureSequence.getText()), textFieldluminosityClass.getText(),
						Double.parseDouble(textFielddistanceInParsecs.getText()),
						Double.parseDouble(textFieldlongitudeInDecimalDegrees.getText()),
						Double.parseDouble(textFieldlattitudeInDecimalHours.getText())

				);

				return star;

			}
			return null;
		});
		Optional<Star> optionalResult = dialog.showAndWait();
		optionalResult.ifPresent((Star star) -> {
			saveStarInCSV(star);
		});
   }
   /**
    * this adds a star to the csv file of stars
    * @param star the star to add to the csv
    */
	public static  void saveStarInCSV(Star star) {
		BufferedWriter bw = null;
		try {
			bw = new BufferedWriter(new FileWriter(Settings.STARS_FILE, true));

			bw.newLine();

			bw.write(star.toString());

		} catch (IOException ex) {
			ex.printStackTrace();
		} finally {
			try {
				bw.close();
			} catch (IOException ex) {
				ex.printStackTrace();
			}
		}

	}
	
	
	
	
}
