package utils.charts;

/**
 * factory pattern 
 * main class to create different chart types
 * @author pablo
 *
 */
public class ChartFactory {

    public static IChartFactory getChartType(String type, String title)
    {
        if ( type.equals("pie"))
            return new MyPieChart(title);
        else if ( type.equals("bar") )
            return new MyBarChart(title);
        else if ( type.equals("line") )
            return new MyLineChart(title);

        return null;
    }



}
