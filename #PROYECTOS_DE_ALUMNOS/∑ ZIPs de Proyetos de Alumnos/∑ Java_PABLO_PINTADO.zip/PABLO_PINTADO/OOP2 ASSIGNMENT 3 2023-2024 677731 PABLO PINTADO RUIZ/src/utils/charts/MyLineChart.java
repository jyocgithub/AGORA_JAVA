package utils.charts;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Pos;
import javafx.scene.chart.CategoryAxis;
import javafx.scene.chart.LineChart;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart;
import javafx.scene.layout.VBox;
/**
 * this is a class to generate line charts
 * this class contains getters, setters and implements IChartsFactory methods
 * @author pablo
 *
 */
public class MyLineChart extends MyChart implements IChartFactory {

    private ObservableList<LineChart.Data> barChartData = FXCollections.observableArrayList();
    private final CategoryAxis xAxis = new CategoryAxis();
    private final NumberAxis yAxis = new NumberAxis();
    private final LineChart<String, Number> chart = new LineChart<String, Number>(xAxis, yAxis);
    private XYChart.Series series1 = new XYChart.Series();  // puede haber mas de una serie
    private XYChart.Series series2 = new XYChart.Series();  // puede haber mas de una serie

    private String axisxname, axisyname, seriename;

    public MyLineChart(String title) {
        super(title);
        chart.setTitle(title);
        chart.getData().addAll(series1, series2);
    }

    public void addData(String name, String data) {
            series1.getData().add(new XYChart.Data(name, Double.parseDouble(data)));
    }

    public void addDataBySerie(String name, String data, int serienumber) {
        if (serienumber == 1) {
            series1.getData().add(new XYChart.Data(name, Double.parseDouble(data)));
        }
        if (serienumber == 2) {
            series2.getData().add(new XYChart.Data(name, Double.parseDouble(data)));
        }
    }

    public VBox getChart() {
        VBox vbox = new VBox(chart);
        vbox.setAlignment(Pos.CENTER);
        return vbox;
    }


    public String getAxisxname() {
        return axisxname;
    }

    public void setAxisxname(String axisxname) {
        this.axisxname = axisxname;
        xAxis.setLabel(axisxname);
    }

    public String getAxisyname() {
        return axisyname;
    }

    public void setAxisyname(String axisyname) {
        this.axisyname = axisyname;
        yAxis.setLabel(axisyname);
    }

    public String getSeriename() {
        return seriename;
    }

    public void setSeriename(String seriename) {
        this.seriename = seriename;
        series1.setName(seriename);
    }
}
