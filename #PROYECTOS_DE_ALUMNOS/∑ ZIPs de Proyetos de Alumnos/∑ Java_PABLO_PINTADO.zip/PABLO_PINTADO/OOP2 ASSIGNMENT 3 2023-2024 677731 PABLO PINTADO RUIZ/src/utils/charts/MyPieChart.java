package utils.charts;

import java.util.ArrayList;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Pos;
import javafx.scene.chart.PieChart;
import javafx.scene.layout.VBox;
/**
 * this is a class to generate pie charts
 * this class contains getters, setters and implements IChartsFactory methods
 * @author pablo
 *
 */
public class MyPieChart extends  MyChart implements IChartFactory{

	private ObservableList<PieChart.Data> pieChartData = FXCollections.observableArrayList();
	private final PieChart chart = new PieChart(pieChartData);

    public MyPieChart(String title) {
        super(title);
        chart.setTitle(title);
    }

    public void addData(String name, String data){
        pieChartData.add(new PieChart.Data(name, Double.parseDouble(data)));
    }


    public VBox getChart(){
        VBox vbox = new VBox(chart);
        vbox.setAlignment(Pos.CENTER);
        return vbox;
    }
}
