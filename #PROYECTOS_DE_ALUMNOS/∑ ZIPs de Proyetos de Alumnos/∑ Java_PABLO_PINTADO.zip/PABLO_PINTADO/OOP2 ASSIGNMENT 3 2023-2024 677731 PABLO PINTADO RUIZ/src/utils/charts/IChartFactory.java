package utils.charts;

import javafx.scene.chart.PieChart;
import javafx.scene.layout.VBox;
/**
 * interface that defines the methods that all graphs need to implement 
 * @author pablo
 *
 */
public interface IChartFactory {

	/**
	 * method to add data to a graph
	 * @param name , name of data 
	 * @param data, value of data
	 */
    void addData(String name, String data);
    /**
     * method top obtain the graph in a node
     * @return node with the graph
     */
    public VBox getChart();
    
}
