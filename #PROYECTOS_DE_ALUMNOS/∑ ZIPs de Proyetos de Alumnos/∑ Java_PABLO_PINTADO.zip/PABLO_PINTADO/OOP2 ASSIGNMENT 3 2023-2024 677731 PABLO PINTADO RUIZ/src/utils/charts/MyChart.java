package utils.charts;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Pos;
import javafx.scene.chart.PieChart;
import javafx.scene.layout.VBox;

import java.util.ArrayList;
/**
 * mother class of all graph types
 * it has two arrays of name and value of the data and the tittle
 * @author pablo
 * all attributes are protected
 */
public class MyChart {
    String title;
    ArrayList<String> dataname = new ArrayList<>();
    ArrayList<String> datavalue = new ArrayList<>();

    public MyChart(String title) {
        this.title = title;
    }

}
