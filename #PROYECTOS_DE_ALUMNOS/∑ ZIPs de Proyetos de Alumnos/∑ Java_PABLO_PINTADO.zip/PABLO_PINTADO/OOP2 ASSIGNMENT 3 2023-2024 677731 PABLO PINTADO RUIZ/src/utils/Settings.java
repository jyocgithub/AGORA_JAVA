package utils;


/**
 * class with values of system configuration
 * @author pablo
 *
 */
public class Settings {
	
	//fields defining the source of the data
	
	public static final String STARS_FILE = "data/custom_stars.csv";
	
	public static final String SPECIES_FILE = "data/custom_species.csv";

	
	

}
