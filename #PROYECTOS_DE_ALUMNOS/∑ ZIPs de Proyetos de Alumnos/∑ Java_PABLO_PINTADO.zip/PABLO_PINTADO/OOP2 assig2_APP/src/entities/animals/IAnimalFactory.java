package entities.animals;


import entities.IFood;

public interface IAnimalFactory {

    void feed(IFood food);

    void timePasses();

    void die();
}

