package entities.areas;


import entities.animals.Animal;
import plugintill.TillOperations;

public class Zoo extends Zone {

    TillOperations ope = new TillOperations();

    @Override
    public boolean addAnimal(Animal b) {
        if (super.addAnimal((Animal) b)) {
            ope.addAnimal();
            System.out.println("---->"+ope.getFounds());
            return true;
        }
        return false;
    }

    @Override
    public boolean removeAnimal(Animal b) {
        if (super.removeAnimal((Animal) b)) {
            ope.addAnimal();
            System.out.println(ope.getFounds());
            return true;
        }
        return false;
    }


}
