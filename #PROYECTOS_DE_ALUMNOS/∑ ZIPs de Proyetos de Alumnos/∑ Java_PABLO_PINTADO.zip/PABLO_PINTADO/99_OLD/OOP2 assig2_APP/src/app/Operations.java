package app;

import entities.Caretaker;
import entities.areas.Pen;
import entities.areas.Zone;
import entities.animals.Animal;
import entities.animals.AnimalFactory;
import entities.animals.IAnimalFactory;
import entities.animals.Mammal;
import entities.areas.Zoo;
import entities.species.Species;
import entities.species.SpeciesCollection;
import plugintill.TillOperations;


import java.lang.reflect.InvocationTargetException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class Operations {

    public static void main(String[] args) {
        new Operations();
    }

    public Operations() {
        // Do basic initializations

        // Create a Zoo consisting of zones, subzones, subsubzones and pens

        // Create a bunch of Caretakers. Keep track of all Caretakers in some Collection
        // so you can loop over it

        // Initialize an AnimalFactory using an anonymous inner class and get animals from it
        // Then add the animals to the Zoo

        // Have several caretakers feed some animals. Use lambda expressions in that
        // Loop over all animals to pass time and see that their Caretakers get informed about
        // their pets getting hungry

        // Implement a plugin for acquiring new animals. The strategy used for that is to clone an existing animal.
        // Cloning has a fixed price defined in the plugin code itself
        // Run the test with the plugin as well


        Zoo zoo = new Zoo();
        Zone mainlevel = new Zone();
        zoo.addZone(mainlevel);
        Zone<Mammal> mammalarea = new Zone();
        mainlevel.addZone(mammalarea);

        Pen p1 = new Pen(2);
        Pen p2 = new Pen(2);
        Pen p3 = new Pen(2);

        mammalarea.addPen(p1);
        mammalarea.addPen(p2);
        mammalarea.addPen(p3);

//	public Species(String commonName, int maxHungriness, int maxWeight, BigDecimal value, Species.Type type, Animal.Gender... genders) {

        List<Caretaker> listCaretaker = new ArrayList<>();
        Caretaker ct1 = new Caretaker("Paul");
        Caretaker ct2 = new Caretaker("Sue");
        listCaretaker.add(ct1);
        listCaretaker.add(ct2);

        Species tiger1 = SpeciesCollection.instance().get("Tiger");
        Species panda1 = SpeciesCollection.instance().get("Panda");

        IAnimalFactory b1 = AnimalFactory.getAnimal("tiger", ct1, tiger1, "Fran", LocalDate.now(), Animal.Gender.MALE, 12);
        IAnimalFactory b2 = AnimalFactory.getAnimal("tiger", ct1, tiger1, "Joe", LocalDate.now(), Animal.Gender.MALE, 13);
        IAnimalFactory b3 = AnimalFactory.getAnimal("panda", ct1, panda1, "Isabelle", LocalDate.now(), Animal.Gender.FEMALE, 1);

        zoo.addAnimal((Animal) b1);
        zoo.addAnimal((Animal) b2);
        zoo.addAnimal((Animal) b3);

        b1.feed(() -> 3);
        for (int i = 0; i < 100; i++) {
            b1.timePasses();
        }
        b1.feed(() -> 3);

        for (Caretaker c : listCaretaker) {
            for (Animal a : c.getPets()) {
                for (int i = 0; i < 20; i++) {
                    b1.timePasses();
                }
            }
        }
        for (Caretaker c : listCaretaker) {
            for (Animal a : c.getPets()) {
                a.feed(() -> 3);
            }
        }





    }
}
