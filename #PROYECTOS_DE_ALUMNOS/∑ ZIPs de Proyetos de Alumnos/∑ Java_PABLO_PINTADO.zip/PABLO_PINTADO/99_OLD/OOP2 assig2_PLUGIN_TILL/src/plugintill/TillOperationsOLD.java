package plugintill;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.ParameterizedType;
import java.math.BigDecimal;

public class TillOperationsOLD<T> {

    public static final double INITIAL_TILL = 1000;
    private static final int CLONE_PRIZE = 12000;
    private Till till;

    public TillOperationsOLD() throws InvocationTargetException, IllegalAccessException {
        this.till = Till.getInstance(new BigDecimal(INITIAL_TILL));
    }

    private Class reflectClassType() {
        return ((Class) ((ParameterizedType) getClass().getGenericSuperclass()).getActualTypeArguments()[0]);
    }

    public double getFounds(){
        return till.getFunds().doubleValue();
    }

    public T addAnimal(T oldanimal) throws InvocationTargetException, IllegalAccessException {
        Class c = reflectClassType();
        Method[] methods = c.getDeclaredMethods();

        for (Method m : methods) {
            if (m.getName().equals("clone")) {
                m.setAccessible(true);
                int maxSize = 100;
                Object anim = m.invoke(oldanimal, maxSize);
                till.deposit(new BigDecimal(CLONE_PRIZE));
                return (T) anim;
            }
        }
        return null;
    }

    public void removeAnimal(T oldanimal) throws InvocationTargetException, IllegalAccessException {
        Class c = reflectClassType();
        Method[] methods = c.getDeclaredMethods();

        for (Method m : methods) {
            if (m.getName().equals("die")) {
                m.setAccessible(true);
                int maxSize = 100;
                m.invoke(oldanimal);
                till.withdraw(new BigDecimal(CLONE_PRIZE));
            }
        }
    }
}
