package plugintill;

import java.math.BigDecimal;

public class TillOperations {

    public static final double INITIAL_TILL = 1000;
    private static final int CLONE_PRIZE = 12000;
    private Till till;

    public TillOperations(){
        this.till = Till.getInstance(new BigDecimal(INITIAL_TILL));
    }

    public double getFounds() {
        return till.getFunds().doubleValue();
    }

    public void addAnimal() {
        till.deposit(new BigDecimal(CLONE_PRIZE));
    }

    public void removeAnimal()  {
        till.withdraw(new BigDecimal(CLONE_PRIZE));
    }
}
