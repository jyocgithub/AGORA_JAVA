package plugintill;

import java.util.InputMismatchException;
import java.util.Scanner;

public class Utils {

    /**
     * leerInt Lee con scanner un numero int, precio envio de un mensaje a usuario
     *
     * @param mensaje se muestra al usuario antes de que este escribe el valor
     *                pedido
     * @return el valor int que el usuario introduce por teclado
     */
    public static int readInt(String mensaje) {
        Scanner sc = new Scanner(System.in);
        boolean seguir = true;
        int numero = 0;
        while (seguir) {
            try {
                System.out.println(mensaje);
                numero = sc.nextInt();

                seguir = false;
            } catch (NumberFormatException | InputMismatchException ex) {
                System.out.println("Only numbers accepted");
                sc.next();  // limpiar sc para que lea otra vez
            }
        }
        return numero;
    }

    /**
     * leerDouble Lee con scanner un numero double, precio envio de un mensaje a
     * usuario
     *
     * @param mensaje se muestra al usuario antes de que este escribe el valor
     *                pedido
     * @return el valor double que el usuario introduce por teclado
     */
    public static double readDouble(String mensaje) {
        Scanner sc = new Scanner(System.in);
        while (true) {
            try {
                System.out.println(mensaje);
                double numero = sc.nextDouble();
                return numero;
            } catch (NumberFormatException  | InputMismatchException ex) {
                System.out.println("Only numbers accepted");
                sc.next();  // limpiar sc para que lea otra vez
            }
        }
    }

    /**
     * leerString Lee con scanner un string, precio envio de un mensaje a usuario
     *
     * @param mensaje se muestra al usuario antes de que este escribe el valor
     *                pedido
     * @return el valor String que el usuario introduce por teclado
     */
    public static String readString(String mensaje) {
        Scanner sc = new Scanner(System.in);
        System.out.println(mensaje);
        String res = sc.nextLine();
        return res;
    }



}
