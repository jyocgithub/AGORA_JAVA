package plugintill;

import java.math.BigDecimal;

public class TillOperations {

    public static final double INITIAL_TILL = 20000;
    private static final int CLONE_PRIZE = 1200;
    private Till till;

    public TillOperations(){
        this.till = Till.getInstance(new BigDecimal(INITIAL_TILL));
    }

    public double getFounds() {
        return till.getFunds().doubleValue();
    }

    public void addAnimal() {
    	 till.withdraw(new BigDecimal(CLONE_PRIZE));
     
    }

    public void removeAnimal()  {
    	   till.deposit(new BigDecimal(CLONE_PRIZE));
    }
}
