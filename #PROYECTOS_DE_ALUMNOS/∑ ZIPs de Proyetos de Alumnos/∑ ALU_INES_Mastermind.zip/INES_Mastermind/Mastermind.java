package INES_Mastermind;

import java.io.*;
import java.text.*;
import java.util.*;

public class Mastermind{

    	public static class registroConfiguraciones { // registro para guardar las configuraciones de la solucion
		int colores_potenciales;
		int colores_combinacion;
		int intentos;

		public registroConfiguraciones() {
			this.colores_potenciales = 0;
			this.colores_combinacion = 0;
			this.intentos = 0;
		}

		public registroConfiguraciones(int colores_potenciales, int colores_combinacion, int intentos) {
			this.colores_potenciales = colores_potenciales;
			this.colores_combinacion = colores_combinacion;
			this.intentos = intentos;
		}
	}

	public static class registroEstadisticas { // registro para guardar las estadísticas de cada jugador
		int partidasGanadas;
		int partidasJugadas;
		int puntos;
		float ratioPuntos;

		public registroEstadisticas() {
			this.partidasGanadas = 0;
			this.partidasJugadas = 0;
			this.puntos = 0;
			this.ratioPuntos = 0;
		}
	}

	public static class RegistroPersona { // registro para guardar los datos del usuario
		String nombre;
		String fechaInicio;
		registroEstadisticas estadisticas;
		registroConfiguraciones configuracion;

		public RegistroPersona(String nombre) {
			this.nombre = nombre;
			this.fechaInicio = Fechas();
			this.configuracion = new registroConfiguraciones();
			this.estadisticas = new registroEstadisticas();
		}

		public RegistroPersona(String nombre, int colores, int huecos, int intentos, int partidasJugadas,
				int partidasGanadas, int puntos) {
			this.nombre = nombre; // le voy dando los valores correspondientes a los campos
			this.fechaInicio = Fechas(); // función que guarda la fecha en la que un jugador se da de alta
			this.configuracion = new registroConfiguraciones(); // creo un registro para almacenar las configuraciones
			this.configuracion.colores_potenciales = colores;
			this.configuracion.colores_combinacion = huecos;
			this.configuracion.intentos = intentos;
			this.estadisticas = new registroEstadisticas(); // creo un nuevo registro para guardar las estadisticas del
															// usuario
			this.estadisticas.partidasJugadas = partidasJugadas;
			this.estadisticas.partidasGanadas = partidasGanadas;
			this.estadisticas.puntos += puntos;
			this.estadisticas.ratioPuntos = partidasJugadas == 0 ? 0
					: (float) (partidasGanadas / partidasJugadas) * 100;
			// hace la división de las partidas ganadas entre las partidas jugadas
			// y después multiplica por 100 para tener un porcentaje.
		}

		public RegistroPersona() {
			this.nombre = "";
			this.fechaInicio = "";
			this.configuracion = new registroConfiguraciones();
			this.estadisticas = new registroEstadisticas();
		}
	}

	public static class Partida { // registro para guardar los datos de cada partida
		String fecha;
		int colores_potenciales;
		int colores_combinacion;
		int puntos;
		int intentos;
		int pistas[][];
		int resultados[][];
	}

	public static RegistroPersona cargarDatosFichero(String nombre) {
		/*
		 * Función para cargar los datos del usuario
		 * 
		 * @param String nombre
		 * 
		 * @return RegistroPersona usuario
		 */
		File directorio = new File("./Jugadores/" + nombre.toLowerCase());
		RegistroPersona usuario = new RegistroPersona(nombre);

		// Comprueba si existe una carpeta con el nombre del jugador ingresado
		if (!directorio.exists()) {
			System.out.println("El directorio no existe. No leo nada ahora");
		} else {
			// Se crean las distintas carpetas del jugador
			File configuracion = new File("./Jugadores/" + nombre.toLowerCase() + "/configuracion.txt");
			File estadisticas = new File("./Jugadores/" + nombre.toLowerCase() + "/estadisticas.txt");
			File perfil = new File("./Jugadores/" + nombre.toLowerCase() + "/perfil.txt");

			try {
				// Cargar configuración

				Scanner scannerConfiguracion = new Scanner(configuracion);

				usuario.configuracion = new registroConfiguraciones();

				String configuracionLine;
				// Se va escribiendo en el archivo de texto mientras que queden lineas por leer

				while (scannerConfiguracion.hasNextLine()) {
					configuracionLine = scannerConfiguracion.nextLine();
					// Se utiliza para que cada línea contenga un dato concreto
					// En este caso, sería por ejemplo, "Colores potenciales: 5"
					String[] parts = configuracionLine.split(": "); // pepe: 5 -> parts[0] -> pepe parts[1] -> 5
					if (parts.length >= 2) {
						String key = parts[0];
						String value = parts[1];
						if (key.equals("Colores potenciales")) {
							usuario.configuracion.colores_potenciales = Integer.parseInt(value.trim());
							// se utiliza .trim() para que no deje espacio ""
						} else if (key.equals("Colores en la combinación")) {
							usuario.configuracion.colores_combinacion = Integer.parseInt(value.trim());
						} else if (key.equals("Intentos")) {
							usuario.configuracion.intentos = Integer.parseInt(value.trim());
						}
					}
				}
				scannerConfiguracion.close();

				// Cargar estadísticas
				Scanner scannerEstadisticas = new Scanner(estadisticas);
				usuario.estadisticas = new registroEstadisticas();
				String estadisticasLine;

				while (scannerEstadisticas.hasNextLine()) {
					estadisticasLine = scannerEstadisticas.nextLine();
					String[] parts = estadisticasLine.split(": ");
					if (parts.length >= 2) {
						String key = parts[0];
						String value = parts[1];
						if (key.equals("Partidas Jugadas")) {
							usuario.estadisticas.partidasJugadas = Integer.parseInt(value);
						} else if (key.equals("Partidas Ganadas")) {
							usuario.estadisticas.partidasGanadas = Integer.parseInt(value);
						} else if (key.equals("Puntos")) {
							usuario.estadisticas.puntos = Integer.parseInt(value);
						} else if (key.equals("Ratio de Puntos")) {
							usuario.estadisticas.ratioPuntos = Float.parseFloat(value);
						}
					}
				}
				scannerEstadisticas.close();

				// Cargar perfil
				Scanner scannerPerfil = new Scanner(perfil);
				String perfilLine;
				while (scannerPerfil.hasNextLine()) {
					perfilLine = scannerPerfil.nextLine();
					String[] parts = perfilLine.split(": ");
					if (parts.length >= 2) {
						String key = parts[0];
						String value = parts[1];
						if (key.equals("Nombre")) {
							usuario.nombre = value;
						} else if (key.equals("Fecha")) {
							usuario.fechaInicio = value;
						}
					}
				}
				scannerPerfil.close();

				System.out.println("Datos cargados correctamente");
				System.out.println("Nombre: " + usuario.nombre);
			} catch (FileNotFoundException e) {
				System.out.println("Error al cargar los datos del fichero: " + e.getMessage());
			}
		}
		return usuario;

	}

	public static void guardarPartidaFichero(RegistroPersona usuario, Partida partida) {
		/*
		 * Función para guardar los datos de las partidas
		 * 
		 * @param RegistroPersona usuario y Partida partida
		 */
		File directorioPartidas = new File("./Jugadores/" + usuario.nombre.toLowerCase() + "/PARTIDAS");
		if (!directorioPartidas.exists()) { // Si el directorio no existe
			directorioPartidas.mkdirs(); // Creamos el directorio
		}

		File partidaFile = new File("./Jugadores/" + usuario.nombre.toLowerCase() + "/PARTIDAS/partida"
				+ usuario.estadisticas.partidasJugadas + ".txt");
		/*
		 * Comprueba que el archivo de la partida no existe Si no existe, crea el
		 * archivo
		 */
		if (!partidaFile.exists()) {
			try {
				partidaFile.createNewFile();
			} catch (IOException e) {
				System.out.println("Mensaje de error: " + e.getMessage());
				return;
			}
		}
		FileWriter escribirPartida = null;

		try {
			escribirPartida = new FileWriter(partidaFile, false);
			escribirPartida.write("Fecha: " + partida.fecha + "\n");
			escribirPartida.write("Colores potenciales: " + partida.colores_potenciales + "\n");
			escribirPartida.write("Colores en la combinación: " + partida.colores_combinacion + "\n");
			escribirPartida.write("Intentos: " + partida.intentos + "\n");
			escribirPartida.write("Pistas: " + "\n");
			escribirMatriz(partida.pistas, escribirPartida);
			escribirPartida.write("Resultados: " + "\n");
			escribirMatriz(partida.resultados, escribirPartida);
			escribirPartida.flush();// Sirve para asegurarse de que los datos se guardan en el archivo y
			// para forzar que cualquier salida en buffer se almacene directamente en el
			// archivo
			escribirPartida.close();

			System.out.println("Partida exportado correctamente");
		} catch (Exception e) {
			System.out.println("Error al escribir el archivo de la partida \n" + e.getMessage());
			// Mostramos un mensaje de error
		}

	}

	public static void guardarDatosFichero(RegistroPersona usuario) {

		File directorio = new File("./Jugadores/" + usuario.nombre.toLowerCase());
		if (!directorio.exists()) { // Si el directorio no existe
			directorio.mkdirs(); // Creamos el directorio
		}

		File configuracion = new File("./Jugadores/" + usuario.nombre.toLowerCase() + "/configuracion.txt");
		File estadisticas = new File("./Jugadores/" + usuario.nombre.toLowerCase() + "/estadisticas.txt");
		File perfil = new File("./Jugadores/" + usuario.nombre.toLowerCase() + "/perfil.txt");

		/*
		 * Comprueba que el archivo de configuración no existe Si no existe, crea el
		 * archivo
		 */
		if (!configuracion.exists()) {
			try {
				configuracion.createNewFile();
			} catch (IOException e) {
				System.out.println("Mensaje de error: " + e.getMessage());
			}
		}
		/*
		 * Comprueba que el archivo de las estadísticas no existe Si no existe, crea el
		 * archivo
		 */
		if (!estadisticas.exists()) {
			try {
				estadisticas.createNewFile();
			} catch (IOException e) {
				System.out.println("Mensaje de error: " + e.getMessage());
			}
		}
		/*
		 * Comprueba que el archivo del perfil no existe Si no existe, crea el archivo
		 */
		if (!perfil.exists()) {
			try {
				perfil.createNewFile();
			} catch (IOException e) {
				System.out.println("Mensaje de error: " + e.getMessage());
			}
		}

		FileWriter escribirConfiguracion = null;
		FileWriter escribirEstadisticas = null;
		FileWriter escribirPerfil = null;

		try {
			escribirConfiguracion = new FileWriter(configuracion, false);
			escribirConfiguracion.write("Configuración: \n");
			escribirConfiguracion.write("Colores potenciales: " + usuario.configuracion.colores_potenciales + "\n");
			escribirConfiguracion
					.write("Colores en la combinación: " + usuario.configuracion.colores_combinacion + "\n");
			escribirConfiguracion.write("Intentos: " + usuario.configuracion.intentos + "\n");
			escribirConfiguracion.flush();
			escribirConfiguracion.close();

			System.out.println("Configuración exportada correctamente");
		} catch (Exception e) {
			System.out.println("Error al escribir el archivo de configuración \n" + e.getMessage());
			// Mostramos un mensaje de error
		}

		try {
			escribirEstadisticas = new FileWriter(estadisticas, false);
			escribirEstadisticas.write("Estadisticas: \n");
			escribirEstadisticas.write("Partidas Jugadas: " + usuario.estadisticas.partidasJugadas + "\n");
			escribirEstadisticas.write("Partidas Ganadas: " + usuario.estadisticas.partidasGanadas + "\n");
			escribirEstadisticas.write("Puntos: " + usuario.estadisticas.puntos + "\n");
			escribirEstadisticas.write("Ratio de Puntos: " + usuario.estadisticas.ratioPuntos + "\n");
			escribirEstadisticas.flush(); // Sirve para asegurarse de que los datos se guardan en el archivo y
			// para forzar que cualquier salida en buffer se almacene directamente en el
			// archivo
			escribirEstadisticas.close();

			System.out.println("Estadisticas exportadas correctamente");
		} catch (Exception e) {
			System.out.println("Error al escribir el archivo de estadisticas \n" + e.getMessage());
			// Mostramos un mensaje de error
		}

		try {
			escribirPerfil = new FileWriter(perfil, false);
			escribirPerfil.write("Perfil: \n");
			escribirPerfil.write("Nombre: " + usuario.nombre + "\n");
			escribirPerfil.write("Fecha: " + usuario.fechaInicio + "\n");
			escribirPerfil.flush();
			escribirPerfil.close();

			System.out.println("Perfil exportado correctamente");
		} catch (Exception e) {
			System.out.println("Error al escribir el archivo del perfil \n" + e.getMessage());
			// Mostramos un mensaje de error
		}
	}

	public static void verEstadisticas(RegistroPersona usuario) {
		/*
		 * Función para visualizar por consola las estadísticas del usuario
		 * 
		 * @param RegistroPersona usuario Imprime por pantalla las líneas que están
		 * escritas en el archivo de texto
		 */
		File perfilUsuario = new File("Jugadores/" + usuario.nombre + "/estadisticas.txt");
		Scanner sc = null;
		try {
			sc = new Scanner(perfilUsuario);
			while (sc.hasNextLine()) {
				String linea = sc.nextLine();
				System.out.println(linea);
			}
		} catch (FileNotFoundException e1) {

			e1.printStackTrace();
		}

		sc.close();
		Menu(usuario, false);
	}

	public static void Salir() {
		System.out.println("Has salido del juego");
		System.exit(0); // Salir definitivamente de la ejecución
	}

	public static Partida guardarPartida(String fecha, int puntos, int intentos, int pistas[][], int resultados[][],
			int colores, int huecos) {
		/*
		 * Función para guardar las partidas de un usuario
		 * 
		 * @param fecha en la que se jugó, puntos obtenidos, número de intentos, de
		 * colores potenciales y de colores en la combinación, matriz con las pistas y
		 * la de los resultados escritos por el usuario
		 * 
		 * @return Partida partida
		 */
		Partida partida = new Partida();
		partida.fecha = fecha;
		partida.colores_potenciales = colores;
		partida.colores_combinacion = huecos;
		partida.puntos = puntos;
		partida.intentos = intentos;
		partida.pistas = pistas;
		partida.resultados = resultados;

		return partida;
	}

	public static void Inicio(RegistroPersona usuario) {
		Scanner teclado = new Scanner(System.in);
		usuario.estadisticas.partidasJugadas++;
		int huecos = 3;
		int colores = 5;
		int intentos = 7;
		String fechaPartida = Fechas();
		System.out.println();
		System.out.println("**BIENVENIDO A MASTERMIND**");
		System.out.println();
		System.out.println("El objetivo del juego es adivinar la secuencia de colores creada por el ordenador");
		System.out.println("dados unos colores posibles y un numero de intentos limitados.");
		System.out.println();
		System.out.println("Ahora debe elegir la configuracion del juego.");
		System.out.println("El numero de colores potenciales son: 5,6,7 u 8.");
		System.out.print("Colores potenciales que van a utilizar: ");
		boolean valid = false;

		while (!valid) {
			try {
				colores = Integer.parseInt(teclado.next());
			} catch (NumberFormatException e) {
				colores = 0;
			}
			if (colores >= 5 && colores <= 8) {
				valid = true;
			} else {
				System.out.println("el numero no es valido. Intentelo de nuevo");
			}
		}
		System.out.println("El numero de colores de la combinacion son: 3,4 o 5.");
		System.out.print("Colores en la combinacion que van a usar son: ");
		valid = false;
		while (!valid) {
			try {
				huecos = Integer.parseInt(teclado.next());
			} catch (NumberFormatException e) {
				huecos = 0;
			}
			if (huecos >= 3 && huecos <= 5) {
				valid = true;
			} else {
				System.out.println("el numero no es valido. Intentelo de nuevo");
			}
		}
		System.out.println("El numero de intentos son: 7,8,9,10,11 0 12.");
		System.out.print("El numero de intentos elegido es: ");
		valid = false;
		while (!valid) {
			try {
				intentos = Integer.parseInt(teclado.next());
			} catch (NumberFormatException e) {
				intentos = 0;
			}
			if (intentos >= 7 && intentos <= 12) {
				valid = true;
			} else {
				System.out.println("el numero no es valido. Intentelo de nuevo");
			}

		}
		asignacionColores(colores);
		int[] listaaleatorio = new int[huecos];
		for (int k = 0; k < listaaleatorio.length; k++) {
			int numeroaleatorio = (int) (Math.random() * colores);
			listaaleatorio[k] = numeroaleatorio;
		}
		imprimirRespuesta(listaaleatorio);
		System.out.println();

		int[][] secuencias = new int[intentos][huecos];
		int[][] resultados = new int[intentos][2];
		boolean escorrecto = false;
		int intentosusados = 0;
		int maximointentos = intentos;

		int k = 0;
		do {
			int[] secuenciausuario = new int[huecos];
			System.out.print("Introduce una secuencia de numeros de uno en uno: ");
			for (int i = 0; i < secuenciausuario.length; i++) {
				secuenciausuario[i] = teclado.nextInt();
			}
			intentosusados++;
			imprimirRespuesta(secuenciausuario);
			secuencias[k] = secuenciausuario;
			System.out.println();
			resultados[k] = compararRespuesta(secuenciausuario, listaaleatorio);
			for (int i = 0; i < resultados[k][0]; i++) {
				System.out.print("X"); // representan los colores que están en su posición
			}
			for (int i = 0; i < resultados[k][1]; i++) {
				System.out.print("O"); // represetan los colores que están en la solución, pero no están en su posición
			}
			System.out.println();

			if (Arrays.equals(secuenciausuario, listaaleatorio)) {
				escorrecto = true;
			} else
				escorrecto = false;
			k++;
		} while (intentosusados < maximointentos && escorrecto == false);

		if (escorrecto == false) {
			imprimirMatriz(secuencias);
			System.out.println("Los resultados de las secuencias introducidas son: ");
			imprimirMatriz(resultados);
			System.out.println("La primera columna son las X y la segunda los 0");
			System.out.println("Has perdido");
			int puntos = maximointentos - intentosusados;
			usuario.estadisticas.ratioPuntos = (float) usuario.estadisticas.partidasGanadas
					/ usuario.estadisticas.partidasJugadas * 100;

			System.out.println("Puntos obtenidos: " + puntos);
			usuario.estadisticas.puntos += puntos;
		} else {
			imprimirMatriz(secuencias);
			System.out.println("Los resultados de las secuencias introducidas son: ");
			imprimirMatriz(resultados);
			System.out.println("La primera columna son las X y la segunda los 0");
			System.out.println("Enhorabuena, has ganado!");
			usuario.estadisticas.partidasGanadas++;
			int puntos = maximointentos - intentosusados;
			usuario.estadisticas.ratioPuntos = (float) usuario.estadisticas.partidasGanadas
					/ usuario.estadisticas.partidasJugadas * 100;

			System.out.println("Puntos obtenidos: " + puntos);
			usuario.estadisticas.puntos += puntos;
			System.out.println();

		}
		registroConfiguraciones config = new registroConfiguraciones(colores, huecos, intentos);
		usuario.configuracion = config;
		Partida partida = guardarPartida(fechaPartida, usuario.estadisticas.puntos, intentos, resultados, secuencias,
				colores, huecos);
		guardarDatosFichero(usuario);
		guardarPartidaFichero(usuario, partida);
		Opciones();
	} // cierre de la función Inicio

	public static void imprimirRespuesta(int[] lista) {
		for (int i = 0; i < lista.length; i++) {
			System.out.print(lista[i]);
		}
	}

	// 1114--
	// 4442--

	public static int[] compararRespuesta(int[] lista, int[] solucion) {
		int[] listausuario = lista.clone();
		int[] solucionmaquina = solucion.clone();
		int[] out = new int[2];
		for (int i = 0; i < listausuario.length; i++) {
			if (listausuario[i] == solucionmaquina[i]) {
				out[0]++;
				listausuario[i] = -1;
				solucionmaquina[i] = -1;
			}
		}
		for (int i = 0; i < listausuario.length; i++) {
			for (int k = 0; k < listausuario.length; k++) {
				if (listausuario[i] != -1) {
					if (listausuario[i] == solucionmaquina[k]) {
						out[1]++;
						listausuario[i] = -1;
						solucionmaquina[k] = -1;
					}
				}
			}

		}
		return out;
	}

	public static int[] compararRespuestaANTIGUO(int[] lista, int[] solucion) {
		// Comprueba si los valores que hay en la lista en la posición y son iguales a
		// los de la
		// lista solución en la posición j
		int[] out = new int[2];
		int y = 0;
		while (y < lista.length) {
			if (lista[y] == solucion[y]) {
				out[0]++;
			} else {
				boolean colorFound = false;
				int j = 0;
				while (j < lista.length && !colorFound) {
					if (lista[y] == solucion[j]) {
						colorFound = true;
					}
					j++;
				}
				if (colorFound) {
					out[1]++;
				}
			}
			y++;
		}
		return out;
	}

	public static void imprimirMatriz(int[][] matriz) {
		for (int i = 0; i < matriz.length; i++) {
			for (int j = 0; j < matriz[0].length; j++) {
				System.out.print(matriz[i][j] + " ");
			}
			System.out.println();
		}
	}

	public static void escribirMatriz(int[][] matriz, FileWriter escribir) throws IOException {
		for (int i = 0; i < matriz.length; i++) {
			for (int j = 0; j < matriz[0].length; j++) {
				escribir.write(matriz[i][j] + " ");
			}
			escribir.write("\n");
		}
	}

	public static void asignacionColores(int colores) {
		String negro = "\033[30m";
		String rojo = "\033[31m";
		String verde = "\033[32m";
		String amarillo = "\033[33m";
		String azul = "\033[34m";
		String morado = "\033[35m";
		String cyan = "\033[36m";
		String blanco = "\033[37m";
		String reset = "\u001B[0m";

		System.out.println("debe adivinar la secuencia de colores para ganar.");
		System.out.println("debes poner el numero asociado al color que creas que es correcto");

		System.out.println(rojo + "rojo = 0" + reset);
		System.out.println(verde + "verde = 1" + reset);
		System.out.println(azul + "azul = 2" + reset);
		System.out.println(amarillo + "amarillo = 3" + reset);
		System.out.println(morado + "morado = 4" + reset);
		if (colores == 6) {
			System.out.println(cyan + "cyan = 5" + reset);
		} else if (colores == 7) {
			System.out.println(cyan + "cyan = 5" + reset);
			System.out.println(negro + "negro = 6" + reset);
		} else if (colores == 8) {
			System.out.println(cyan + "cyan = 5" + reset);
			System.out.println(negro + "negro = 6" + reset);
			System.out.println(blanco + "blanco = 7" + reset);
		}
	}

	public static boolean buscarPersona(String nombre) {
		boolean existe = false;
		File jugadores = new File("./Jugadores");
		if (jugadores.exists()) { // si no existe la carpeta jugadores, no hay jugadores dentro
			File usuarios = new File("./Jugadores/" + nombre.toLowerCase());
			if (usuarios.exists()) {
				existe = true;
			}

		}
		return existe;
	}

	public static void Opciones() {
		System.out.println("OPCIONES A ELEGIR: ");
		System.out.println("1. Jugar.");
		System.out.println("2. Crear un nuevo usuario para jugar.");
		System.out.println("3. Ver estadisticas del usuario");
		System.out.println("4. Salir");
	}

	public static void Menu(RegistroPersona usuario, boolean isFirst) {
		boolean ingresa_numero = true; // boolean para permitir que solo se puedan ingresar números en las opciones
		int opcion;
		String nickname;
		Scanner teclado = new Scanner(System.in);

		/*
		 * Primero pide que se ingrese un nombre para el usuario Después busca en los
		 * archivos si el nombre ingresado existe o no Si existe carga los datos del
		 * usuario, mientras que si es nuevo, crea un nuevo usuario para guardar su
		 * información
		 * 
		 */
		if (isFirst) {
			System.out.println("ingrese su nombre: ");
			String nombre = teclado.nextLine();

			boolean valido = true;
			boolean existe = buscarPersona(nombre);
			System.out.println(existe);
			if (!existe) {
				usuario = new RegistroPersona(nombre);
				guardarDatosFichero(usuario);
			} else
				usuario = cargarDatosFichero(nombre);
		}
		Opciones();
		while (ingresa_numero) {
			try {
				ingresa_numero = true;
				System.out.print("Opcion deseada: ");
				opcion = teclado.nextInt();
				switch (opcion) {
				case 1:
					Inicio(usuario);
					break;
				case 2:
					Menu(usuario, true);
					break;
				case 3:
					verEstadisticas(usuario);
					break;
				case 4:
					Salir();
					ingresa_numero = false;
					break;
				default:
					System.out.println("La opcion seleccionada no esta disponible");
				}
			} catch (InputMismatchException e) { // esta excepción es para el Scanner y sirve para que solo se ingrese
				// el tipo deseado
				System.out.println("Debe ingresar un numero: ");
				teclado.next(); // es necesario poner esto ya que sino se queda como en un bucle.
				ingresa_numero = false;
			} // cierre del catch
		}
		teclado.close();
	}

	public static String Fechas() {
		java.util.Date fecha = new java.util.Date();
		DateFormat formato = new SimpleDateFormat("dd/MM/YYYY - hh:mm:ss"); // muestra la fecha con el formato
		// seleccionado: día-mes-año y después
		// hora-minuto-segundo
		return formato.format(fecha); // devuelve la fecha con el formato seleccionado
	}

	public static void main(String[] args) {
		RegistroPersona usuario = new RegistroPersona();
		Menu(usuario, true);
	}

}
