/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mensajeria.dao.Mensaje;

import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import mensajeria.dao.ConfiguracionBBDD;
import mensajeria.modelo.Mensaje;

/**
 *
 * @author mrs123456
 */
public class DAOMensajeSQL implements DAOMensaje{

    @Override
    public void inserta(Mensaje mensajes) {

          try{
        Statement stmt = ConfiguracionBBDD.getInstance().getConnection().createStatement();
        stmt.execute("insert into Mensaje(Texto, fecha_hora, Conf_lectura, Id_usuario_emisor, Id_usuario_receptor, Id_grupo )"
            +"values ('"+mensajes.getTexto()
                +"','"+mensajes.getFecha_hora()
                +"','"+mensajes.getId_usuario_emisor()
                +"','"+mensajes.getId_usuario_receptor()
                +"','"+mensajes.getId_grupo()+"')");
        
        stmt.close();
        
    }   catch (SQLException ex) {
            Logger.getLogger(DAOMensajeSQL.class.getName()).log(Level.SEVERE, null, ex);
        }


    }
    
    
    
}
