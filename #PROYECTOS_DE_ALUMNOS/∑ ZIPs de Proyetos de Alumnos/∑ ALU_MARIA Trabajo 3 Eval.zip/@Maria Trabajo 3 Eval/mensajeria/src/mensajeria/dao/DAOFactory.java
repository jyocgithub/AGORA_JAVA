/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mensajeria.dao;

import mensajeria.dao.Amistad.DAOAmistad;
import mensajeria.dao.Amistad.DAOAmistadSQL;
import mensajeria.dao.Grupo.DAOGrupo;
import mensajeria.dao.Grupo.DAOGrupoSQL;
import mensajeria.dao.Mensaje.DAOMensajeSQL;
import mensajeria.dao.Usuario.DAOUsuarioSQL;
import mensajeria.dao.Mensaje.DAOMensaje;
import mensajeria.dao.Usuario.DAOUsuario;

/**
 *
 * @author mrs123456
 */
public class DAOFactory {
    
    private static DAOFactory daoFactory;
    
    private DAOUsuario daoUsuario;
    private DAOMensaje daoMensajes;
    private DAOAmistad daoAmistad;
    private DAOGrupo daoGrupo;
    
    
    private DAOFactory (){
        
    }
    
    public static DAOFactory getInstance (){
        
        if(daoFactory==null){
            daoFactory = new DAOFactory();
        }
        
        return daoFactory;
    }
    
    public DAOUsuario getDAOUsuario(){
        
                if(daoUsuario==null){
            daoUsuario = new DAOUsuarioSQL();
        }
        
        return daoUsuario;
     
        
    }
    
    public DAOGrupo getDAGrupo(){
        
        if(daoGrupo==null){
            daoGrupo = new DAOGrupoSQL();
        }
        return daoGrupo;
        
    }
    
    
    public DAOMensaje getDAOMensajes(){
        
                if(daoMensajes==null){
            daoMensajes = new DAOMensajeSQL();
        }
        
        return daoMensajes;
     
        
    }
    
        
    public DAOAmistad getDAOAmistad(){
        
                if(daoAmistad==null){
            daoAmistad = new DAOAmistadSQL();
        }
        
        return daoAmistad;
     
        
    }
}
    

