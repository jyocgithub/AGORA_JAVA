/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mensajeria.dao.Mensaje;

import java.util.List;
import mensajeria.modelo.Mensaje;

/**
 *
 * @author mrs123456
 */
public interface DAOMensaje {
    
    public void inserta (Mensaje mensajes);//ordenados por fecha y hora
    

    
}
