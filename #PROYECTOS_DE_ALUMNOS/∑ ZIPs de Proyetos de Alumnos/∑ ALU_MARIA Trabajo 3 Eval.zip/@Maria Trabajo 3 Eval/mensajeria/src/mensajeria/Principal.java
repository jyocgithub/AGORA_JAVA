/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mensajeria;

import Vista.PantallaGeneral;
import java.util.List;
import mensajeria.dao.DAOFactory;
import mensajeria.modelo.Usuario;

/**
 *
 * @author mrs123456
 */
public class Principal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        PantallaGeneral pantallaGeneral = new PantallaGeneral ();
        pantallaGeneral.setVisible(true);
        
        List<Usuario> usuarios = DAOFactory.getInstance().getDAOUsuario().listadoUsuarios();
        System.out.println("Num de usuarios: "+usuarios.size());
    }
    
}
