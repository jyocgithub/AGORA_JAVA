create database mensajeria;
use mensajeria;

create table Usuario 
(Id_usuario int(3) primary key auto_increment not null,
Nombre varchar(50), 
Correo varchar(100), 
Nick varchar (50), 
Contrasena varchar(100),
Foto varchar(100),
Estado varchar(25));

create table Grupo 
(Id_grupo int(3) primary key, 
Nombre_grupo varchar(25),
Icono varchar(100));

create table Usuarios_grupo 
(Id_usuario int(3), foreign key (Id_usuario)references Usuario (Id_usuario), 
Id_grupo int(3), foreign key (Id_grupo)references Grupo (Id_grupo));

create table Mensaje
(Id_mensaje int auto_increment primary key not null, 
Texto varchar(300), 
fecha_hora TIMESTAMP DEFAULT CURRENT_TIMESTAMP, 
Conf_lectura boolean, 
Id_usuario_emisor int(3), 
Id_usuario_receptor int(3), 
Id_grupo int(3),
foreign key(Id_usuario_emisor) references Usuario (Id_usuario),
foreign key(Id_usuario_receptor) references Usuario (Id_usuario),
foreign key(Id_grupo) references Grupo (Id_grupo)); 


create table Amistad
(Estado_amistad int(1),
Id_usuario_emisor int(3), 
Id_usuario_receptor int(3),
foreign key(Id_usuario_emisor) references Usuario (Id_usuario),
foreign key(Id_usuario_receptor) references Usuario (Id_usuario));
 
 
 drop database mensajeria;
 
 select *from usuario;
 
 delete from usuario;
 
 select correo,contrasena from usuario where correo="ariel@gmail.com";
 