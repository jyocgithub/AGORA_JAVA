package clases_proyecto;

public class Aficion {
	 private int idAficion;
	 private String nombreAficion;
	 public Aficion(String nombreAficion) {
	
	        this.nombreAficion = nombreAficion;
	    }


	    public Aficion(int idaficion, String nombreAficion) {
	        this.idAficion = idAficion;
	        this.nombreAficion = nombreAficion;
	    }

		public int getIdAficion() {
			return idAficion;
		}

		public void setIdAficion(int idAficion) {
			this.idAficion = idAficion;
		}

		public String getNombreAficion() {
			return nombreAficion;
		}

		public void setNombreAficion(String nombreAficion) {
			this.nombreAficion = nombreAficion;
		}


}
