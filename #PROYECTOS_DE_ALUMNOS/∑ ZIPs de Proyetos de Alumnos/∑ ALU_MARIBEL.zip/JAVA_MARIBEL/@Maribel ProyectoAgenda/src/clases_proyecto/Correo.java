package clases_proyecto;

public class Correo {
	private int IdCorreo;
	private String TextoCorreo;
	public Correo(String textoCorreo) {
		
		TextoCorreo = textoCorreo;
	}

	
	public Correo(int idCorreo, String textoCorreo) {
		IdCorreo = idCorreo;
		TextoCorreo = textoCorreo;
	}

	public int getIdCorreo() {
		return IdCorreo;
	}

	public void setIdCorreo(int idCorreo) {
		IdCorreo = idCorreo;
	}

	public String getTextoCorreo() {
		return TextoCorreo;
	}

	public void setTextoCorreo(String textoCorreo) {
		TextoCorreo = textoCorreo;
	}
	

}
