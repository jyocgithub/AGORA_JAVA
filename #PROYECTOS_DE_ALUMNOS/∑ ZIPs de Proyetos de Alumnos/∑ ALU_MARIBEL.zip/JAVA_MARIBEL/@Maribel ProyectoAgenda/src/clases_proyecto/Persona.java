package clases_proyecto;
import java.util.ArrayList;

public class Persona extends ContactoProyecto {
	private String Apellidos;
	private String sexo;
	
	public Persona(int idContacto, String tipoContacto, String nombre, String direccion, String notas,
			ArrayList<Aficion> listaAficiones, ArrayList<Telefono> listaTelefonos, ArrayList<Correo> listaCorreos,
			String apellidos, String sexo) {
		super(idContacto, tipoContacto, nombre, direccion, notas, listaAficiones, listaTelefonos, listaCorreos);
		this.Apellidos = apellidos;
		this.sexo = sexo;
	}

	public String getApellidos() {
		return Apellidos;
	}

	public void setApellidos(String apellidos) {
		Apellidos = apellidos;
	}

	public String getSexo() {
		return sexo;
	}

	public void setSexo(String sexo) {
		this.sexo = sexo;
	}
	

}
