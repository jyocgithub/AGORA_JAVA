package clases_proyecto;

import java.util.ArrayList;

public class Apodo extends ContactoProyecto {
		private String sexo;

		public Apodo(int idContacto, String tipoContacto, String nombre, String direccion, String notas,
				ArrayList<Aficion> listaAficiones, ArrayList<Telefono> listaTelefonos, ArrayList<Correo> listaCorreos,
				String sexo) {
			super(idContacto, tipoContacto, nombre, direccion, notas, listaAficiones, listaTelefonos, listaCorreos);
			this.sexo = sexo;
		}

		public String getSexo() {
			return sexo;
		}

		public void setSexo(String sexo) {
			this.sexo = sexo;
		}
		
		

		
		

}
