package clases_proyecto;

public class Telefono {
	 private int idTelefono;
	    private String numero;
	    private String tipoTelefono;
	    
	    public Telefono(String numero) {
	    	this.numero=numero;
	    }
		public Telefono(int idTelefono, String numero, String tipoTelefono) {
			
			this.idTelefono = idTelefono;
			this.numero = numero;
			this.tipoTelefono = tipoTelefono;
		}
		
		public int getIdTelefono() {
			return idTelefono;
		}
		public void setIdTelefono(int idTelefono) {
			this.idTelefono = idTelefono;
		}
		public String getNumero() {
			return numero;
		}
		public void setNumero(String numero) {
			this.numero = numero;
		}
		public String getTipoTelefono() {
			return tipoTelefono;
		}
		public void setTipoTelefono(String tipoTelefono) {
			this.tipoTelefono = tipoTelefono;
		}

	   

}
