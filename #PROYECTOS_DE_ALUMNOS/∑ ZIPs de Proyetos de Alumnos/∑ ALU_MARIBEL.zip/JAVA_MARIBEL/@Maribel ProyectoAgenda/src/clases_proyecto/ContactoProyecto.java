package clases_proyecto;


import java.util.ArrayList;



public class ContactoProyecto implements Comparable<ContactoProyecto> {
	    private int IdContacto;
	    private String tipoContacto;
	    private String nombre;
	    private String direccion;
	    private String notas;
	    private ArrayList<Aficion> listaAficiones;
	    private ArrayList<Telefono> listaTelefonos;
	    private ArrayList<Correo> listaCorreos;
	    
		public ContactoProyecto(int idContacto, String tipoContacto, String nombre, String direccion, String notas,
				ArrayList<Aficion> listaAficiones, ArrayList<Telefono> listaTelefonos, ArrayList<Correo> listaCorreos) {
			this.IdContacto = idContacto;
			this.tipoContacto = tipoContacto;
			this.nombre = nombre;
			this.direccion = direccion;
			this.notas = notas;
			this.listaAficiones = listaAficiones;
			this.listaTelefonos = listaTelefonos;
			this.listaCorreos = listaCorreos;
		}
		
		public int getIdContacto() {
			return IdContacto;
		}

		public void setIdContacto(int idContacto) {
			IdContacto = idContacto;
		}

		public String getTipoContacto() {
			return tipoContacto;
		}

		public void setTipoContacto(String tipoContacto) {
			this.tipoContacto = tipoContacto;
		}

		public String getNombre() {
			return nombre;
		}

		public void setNombre(String nombre) {
			this.nombre = nombre;
		}

		public String getDireccion() {
			return direccion;
		}

		public void setDireccion(String direccion) {
			this.direccion = direccion;
		}

		public String getNotas() {
			return notas;
		}

		public void setNotas(String notas) {
			this.notas = notas;
		}

		public ArrayList<Aficion> getListaAficiones() {
			return listaAficiones;
		}

		public void setListaAficiones(ArrayList<Aficion> listaAficiones) {
			this.listaAficiones = listaAficiones;
		}

		public ArrayList<Telefono> getListaTelefonos() {
			return listaTelefonos;
		}

		public void setListaTelefonos(ArrayList<Telefono> listaTelefonos) {
			this.listaTelefonos = listaTelefonos;
		}

		public ArrayList<Correo> getListaCorreos() {
			return listaCorreos;
		}

		public void setListaCorreos(ArrayList<Correo> listaCorreos) {
			this.listaCorreos = listaCorreos;
		}
		
		@Override
		public boolean equals(Object obj) {		
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			ContactoProyecto other = (ContactoProyecto) obj;
			if (nombre == null) {
				if (other.nombre != null)
					return false;
			} else if (!nombre.equals(other.nombre))
				return false;
			return true;
		}

		@Override
		public int compareTo(ContactoProyecto c) {
			return nombre.compareTo(c.getNombre());
		}
		
		

}
