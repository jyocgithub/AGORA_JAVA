package dao_proyecto;

import java.sql.*;
import java.util.*;


import clases_proyecto.ContactoProyecto;
import clases_proyecto.Aficion;
import clases_proyecto.Apodo;
import clases_proyecto.Correo;
import clases_proyecto.Persona;
import clases_proyecto.Telefono;


public class AgendaDao {

	private static Connection conn = ConexionProyecto.get();
	private ContactoProyecto c;
	private Apodo apodo;
	private Persona persona;
	private Correo correo;
	private Aficion a;
	private Telefono t;
	
	public AgendaDao(){
		apodo=null;
		persona=null;
	
		c=null;
	}
	public int getMaxIdContacto() {
		try {
			String sql = "SELECT max(idContacto) FROM contacto";
			ResultSet rs = conn.createStatement().executeQuery(sql);
			rs.next();
			return rs.getInt(1);
		} catch (Exception e) {
			return 0;
		}
	}
	
	
	public int getMaxIdCorreo() {
		try {
			String sql = "SELECT max(idCorreo) FROM correo";
			ResultSet rs = conn.createStatement().executeQuery(sql);
			rs.next();
			return rs.getInt(1);
		} catch (Exception e) {
			return 0;
		}
	}
	public int getMaxIdAficion() {
		try {
			String sql = "SELECT max(idAficion) FROM aficion";
			ResultSet rs = conn.createStatement().executeQuery(sql);
			rs.next();
			return rs.getInt(1);
		} catch (Exception e) {
			return 0;
		}
	}
	public int getMaxIdTelefono() {
		try {
			String sql = "SELECT max(idTelefono) FROM correo";
			ResultSet rs = conn.createStatement().executeQuery(sql);
			rs.next();
			return rs.getInt(1);
		} catch (Exception e) {
			return 0;
		}
	}
	public ArrayList<ContactoProyecto> obtenerTodos() {
		int idContacto=1;
		ArrayList<ContactoProyecto> al = new ArrayList<>();
		try {
			String sql = "SELECT * FROM contactoProyecto ORDER BY nombre";
			ResultSet rs = conn.createStatement().executeQuery(sql);
			while (rs.next()) {
				String sql1="select * from aficiones where idAficiones=(select idAficiones from contactoAficiones where idContacto=?)";
				PreparedStatement ps1=conn.prepareStatement(sql1);
				ps1.setInt(1,idContacto);
				ResultSet filasAfic=ps1.executeQuery();
				ArrayList<Aficion>listaAficiones= new ArrayList<>();
				while(filasAfic.next()) {
					listaAficiones.add(new Aficion(filasAfic.getInt("idAficion"),filasAfic.getString("nombreAficion")));
				}
				String sql2="select * from telefono where idTelefono=(select idTelefono from contactoTelefono where idContacto=?)";
				PreparedStatement ps2=conn.prepareStatement(sql2);
				ps2.setInt(1,c.getIdContacto());
				ResultSet filasTel=ps2.executeQuery();
				ArrayList<Telefono>listaTelefonos= new ArrayList<>();
				while(filasTel.next()) {
					listaTelefonos.add(new Telefono(filasTel.getInt("idTelefono"),filasTel.getString("numero"),filasTel.getString("tipoTelefono")));
				}
				String sql3="select * from correo where idContacto=?";
				PreparedStatement ps3=conn.prepareStatement(sql3);
				ps3.setInt(1,c.getIdContacto());
				ResultSet filasCorreo=ps3.executeQuery();
				ArrayList<Correo>listaCorreos= new ArrayList<>();
				while(filasCorreo.next()) {
					listaCorreos.add(new Correo(filasCorreo.getInt("idCorreo"), filasCorreo.getString("textoCorreo")));
					
				}
				al.add(new ContactoProyecto(rs.getInt("idContacto"),rs.getString("tipoContacto"),rs.getString("nombre"),rs.getString("direccion"),rs.getString("notas"),listaAficiones,listaTelefonos,listaCorreos));
				idContacto++;
			}
		} catch (Exception e) {
		}
		return al;
	}
	
	//obtener uno o varios contactos conociendo su aficion
	
	
	
	
	
	
	
	
	//ANADIR CONTACTO
	public void anadirContacto(ContactoProyecto c) {
		try {
			c.setIdContacto(getMaxIdContacto()+1);
			
			String sql="INSERT INTO contactoProyecto(idContacto,tipoContacto,nombre,direccion,notas)"+
					"VALUES(?,?,?,?,?)";
			PreparedStatement ps=conn.prepareStatement(sql);
			ps.setInt(1, c.getIdContacto());
			ps.setString(2, c.getTipoContacto());
			ps.setString(3,c.getNombre());
			ps.setString(4,c.getDireccion());
			ps.setString(5,c.getNotas());
		
			
				if(c.getTipoContacto().equals("a")) {
					String sql2= "INSERT INTO apodo(idContacto, sexo)"+
								  "VALUES(?,?)";
					PreparedStatement ps2=conn.prepareStatement(sql2);
					ps2.setInt(1,c.getIdContacto());
					ps2.setString(2,apodo.getSexo());
					 ps2.executeUpdate();
				}
			if(c.getTipoContacto().equals("p")) {
				String sql3= "INSERT INTO persona(idContacto,apellidos,sexo)"+
							  "VALUES(?,?,?)";
				PreparedStatement ps3=conn.prepareStatement(sql3);
				ps3.setInt(1,c.getIdContacto());
				ps3.setString(2,persona.getApellidos());
				ps3.setString(3,persona.getSexo());
			     ps3.executeUpdate();
			}
			for (Correo correo:c.getListaCorreos()) {
				correo.setIdCorreo(getMaxIdCorreo()+1);
				String sql4 ="INSERT INTO correo(idCorreo,idContacto, textoCorreo)"+
							  "VALUES(?,?,?)";
				PreparedStatement ps4=conn.prepareStatement(sql4);
				ps4.setInt(1,correo.getIdCorreo());
				ps4.setInt(2,c.getIdContacto());
				ps4.setString(3,correo.getTextoCorreo());
				 ps4.executeUpdate();
			}
			for (Telefono telefono:c.getListaTelefonos()) {
				telefono.setIdTelefono(getMaxIdTelefono()+1);
				String sql5 ="INSERT INTO telefono(idTelefono,numero, tipoTelefono)"+
							  "VALUES(?,?,?)";
				PreparedStatement ps5=conn.prepareStatement(sql5);
				ps5.setInt(1,telefono.getIdTelefono());
				ps5.setString(2,telefono.getNumero());
				ps5.setString(3, telefono.getTipoTelefono());
				 ps5.executeUpdate();
			}
			for (Aficion aficion:c.getListaAficiones()) {
				aficion.setIdAficion(getMaxIdAficion()+1);
				String sql6 ="INSERT INTO aficion(idAficion,nombreAficion)"+
							  "VALUES(?,?)";
				PreparedStatement ps6=conn.prepareStatement(sql6);
				ps.setInt(1,aficion.getIdAficion());
				ps6.setString(2,aficion.getNombreAficion());
			    ps6.executeUpdate();
				
			}
			String sql7="INSERT INTO contactoAficion(idContacto, idAficion)"+
						"VALUES(?,?)";
						PreparedStatement ps7= conn.prepareStatement(sql7);
						ps7.setInt(1,c.getIdContacto());
						ps7.setInt(2, a.getIdAficion());
						 ps7.executeUpdate();
						
		    String sql8="INSERT INTO contactoTelefono(idContacto, idTelefono)"+
					    "VALUES(?,?)";
					    PreparedStatement ps8= conn.prepareStatement(sql8);
						ps8.setInt(1, t.getIdTelefono());
						ps8.setInt(2,c.getIdContacto());
						ps8.executeUpdate();
		}catch (SQLException e) {
			 e.printStackTrace();
		}
	}
	
	
	//OBTENGO LISTA DE CONTACTOS CONOCIENDO SU NOMBRE
public ArrayList<ContactoProyecto> obtenerContacto(String nombreABuscar){
	    ArrayList<ContactoProyecto>listaContactoConsultada= new ArrayList<>();
		try {
			String sql="select * from contactoProyecto where nombre=?";
			PreparedStatement ps=conn.prepareStatement(sql);
			ps.setString(1,nombreABuscar);
			ResultSet filas=ps.executeQuery();
			while(filas.next()) {
				//datos de la tabla telefono
				String sql2="select * from telefono where idTelefono in(select idTelefono from contactoTelefono where idContacto=?)";
				PreparedStatement ps2=conn.prepareStatement(sql2);
				ps2.setInt(1,c.getIdContacto());
				ResultSet filasTel=ps2.executeQuery();
				ArrayList<Telefono>listaTelefonos= new ArrayList<>();
				while(filasTel.next()) {
					listaTelefonos.add(new Telefono(filasTel.getInt("idTelefono"),filasTel.getString("numero"),filasTel.getString("tipoTelefono")));
				}
				//datos de la tabla correo
				String sql3="select * from correo where idContacto=?";
				PreparedStatement ps3=conn.prepareStatement(sql3);
				ps3.setInt(1,c.getIdContacto());
				ResultSet filasCorreo=ps3.executeQuery();
				ArrayList<Correo>listaCorreos= new ArrayList<>();
				while(filasCorreo.next()) {
					listaCorreos.add(new Correo(filasCorreo.getInt("idCorreo"), filasCorreo.getString("textoCorreo")));
					
				}
				//datos de la tabla aficiones 
				String sql4="select * from aficiones where idAficiones in(select idAficiones from contactoAficiones where idContacto=?)";
				PreparedStatement ps4=conn.prepareStatement(sql4);
				ps2.setInt(1,c.getIdContacto());
				ResultSet filasAfic=ps4.executeQuery();
				ArrayList<Aficion>listaAficiones= new ArrayList<>();
				while(filasAfic.next()) {
					listaAficiones.add(new Aficion(filasAfic.getInt("idAficion"),filas.getString("nombreAficion")));
				}
				
				listaContactoConsultada.add(new ContactoProyecto(filas.getInt("idContacto"),filas.getString("tipoContacto"),filas.getString("nombre"),filas.getString("direccion"),filas.getString("notas"),listaAficiones,listaTelefonos,listaCorreos));
			}
			
		}catch(SQLException e) {
		}	
		
		return listaContactoConsultada;
    }
//ELIMINAR REGISTRO RECIBIENDO COMO PARAMETRO SU ID
public boolean eliminar(int id) {
	try {
		String sql = "DELETE FROM contacto WHERE idContacto = ?";
		PreparedStatement ps = conn.prepareStatement(sql);
		ps.setInt(1, id);
		return ps.executeUpdate() > 0;
	} catch (Exception e) {
		return false;
	}
}
public boolean eliminarContacto(ContactoProyecto c) {
	return eliminar(c.getIdContacto());
}
}
