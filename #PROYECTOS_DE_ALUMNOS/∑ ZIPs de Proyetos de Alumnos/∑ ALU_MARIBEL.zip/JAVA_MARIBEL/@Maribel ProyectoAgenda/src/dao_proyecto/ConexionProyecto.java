package dao_proyecto;
import java.sql.Connection;
import java.sql.DriverManager;

import java.sql.SQLException;

public class ConexionProyecto {
	
    final private String CONN_URI = "jdbc:sqlite:Agend.sqlite";
	
	private static Connection conn = null;

	public ConexionProyecto() {
		if (conn != null) return;

		try {
			conn = DriverManager.getConnection(CONN_URI);
			conn.setAutoCommit(true);
			//crearTablas();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	private void crearTablas()  {
		String sql1;
		String sql2;
		String sql3;
		String sql4;
		String sql5;
		String sql6;
		String sql7;
		String sql8;
		try {
			sql1= "CREATE TABLE IF NOT EXISTS contactoProyecto("+
					"idContacto NUMBER PRIMARY KEY NOT NULL,"+
					"tipoContacto VARCHAR(1) NOT NULL,"+
					"nombre VARCHAR(50) NOT NULL,"+
					"direccion VARCHAR2(50),"+
					"notas VARCHAR2(150))";
			conn.createStatement().executeUpdate(sql1);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		try {
			sql2= "CREATE TABLE IF NO EXISTS persona("+
					"idContacto INTEGER PRIMARY KEY NOT NULL,"+
					"apellidos VARCHAR2(50) NOT NULL,"+
					"sexo VARCHAR2(1) NOT NULL,"+
					"FOREIGN KEY(idContacto)REFERENCES contactoProyecto(idContacto))";
			conn.createStatement().executeUpdate(sql2);
		} catch (Exception e) {
			e.printStackTrace();
		}
			
		try {
			
			sql3= "CREATE TABLE IF NO EXISTS apodo("+
					"idContacto INTEGER,"+
					"sexo VARCHAR2(1) NOT NULL,"+
					"PRIMARY KEY(idContacto),"+
					"FOREIGN KEY(idContacto)REFERENCES contactoProyecto(idContacto))";
			conn.createStatement().executeUpdate(sql3);
		} catch (Exception e) {
			e.printStackTrace();
		}
			
		try {
	
			sql4 = "CREATE TABLE IF NOT EXISTS aficion (" +
					"idAficion NUMBER PRIMARY KEY NOT NULL, " +
					"nombreAficion VARCHAR(50) NOT NULL)";
			conn.createStatement().executeUpdate(sql4);
		} catch (Exception e) {
			e.printStackTrace();
		}
			
		try {
			
			sql5= "CREATE TABLE IF NOT EXISTS contactoAficion("+
					"idContacto INTEGER,"+
					"idAficion INTEGER,"+
					"PRIMARY KEY(idContacto, idAficion),"+
					"FOREIGN KEY(idAficion)REFERENCES aficion(idAficion),"+
					"FOREIGN KEY(idContacto)REFERENCES contactoProyecto(idContacto))";
			conn.createStatement().executeUpdate(sql5);

		} catch (Exception e) {
			e.printStackTrace();
		}
			
		try {

			sql6 = "CREATE TABLE IF NOT EXISTS telefono (" +
					"idTelefono INTEGER PRIMARY NOT NULL," +
					"numero VARCHAR(15),"+
					"tipoTelefono VARCHAR2(8))";
			conn.createStatement().executeUpdate(sql6);
		} catch (Exception e) {
			e.printStackTrace();
		}
			
		try {
			sql7= "CREATE TABLE IF NOT EXISTS contactoTelefono("+
					"idContacto INTEGER,"+
					"idTelefono INTEGER, "+
					"PRIMARY KEY(idContacto, idTelefono),"+
					"FOREIGN KEY(idTelefono)REFERENCES telefono(idTelefono),"+
					"FOREIGN KEY(idContacto)REFERENCES contactoProyecto(idContacto))";
			
			conn.createStatement().executeUpdate(sql7);
		} catch (Exception e) {
			e.printStackTrace();
		}
			
		try {
			sql8= "CREATE TABLE IF NOT EXISTS correo("+
					"idCorreo INTEGER PRIMARY NOT NULL,"+
					"idContacto NUMBER,"+
					"textoCorreo VARCHAR2(155),"+
					"FOREIGN KEY(idContacto)REFERENCES contactoProyecto(idContacto))";
			conn.createStatement().executeUpdate(sql8);

		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	public static Connection get() { 
		return conn;
	}

	public static void close() {
		try {
			conn.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}	
	

}

