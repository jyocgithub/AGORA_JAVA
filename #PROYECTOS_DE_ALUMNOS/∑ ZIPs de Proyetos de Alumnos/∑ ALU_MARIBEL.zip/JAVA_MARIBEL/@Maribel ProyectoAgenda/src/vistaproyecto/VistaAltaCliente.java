package vistaproyecto;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.ButtonGroup;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

import clases_proyecto.Aficion;
import clases_proyecto.Apodo;
import clases_proyecto.ContactoProyecto;
import clases_proyecto.Correo;
import clases_proyecto.Persona;
import clases_proyecto.Telefono;
import dao_proyecto.AgendaDao;
import dao_proyecto.ConexionProyecto;

public class VistaAltaCliente extends JFrame {

	private static final long serialVersionUID = 1245745L;

	private JPanel Tipo;
	private JTextField txtNombre;
	private JTextField txtApellidos;
	private JTextField txtDireccion;
	private JButton btnBuscar;
	private JButton btnAadir;
	private JButton btnModificar;
	private ContactoProyecto contacto;
	private JLabel lblNotas;
	private JTextField txtNotas;
	private JComboBox comboBox;
	JRadioButton rdbtnHombre;
	JRadioButton rdbtnMujer;
	private JButton btnTelefonos;
	private JButton btnAficiones;
	private JButton btnCorreos;
	ArrayList<Aficion> listaAficiones = new ArrayList<>();
	ArrayList<Telefono> listaTelefonos = new ArrayList<>();
	ArrayList<Correo> listaCorreos = new ArrayList<>();
	private JButton btnGuardar;

	/**
	 * Launch the application.
	 */

	/**
	 * Create the frame.
	 */
	public VistaAltaCliente() {
		iniciarComponentes();
		eventos();

	}

	private void eventos() {

		ConexionProyecto cp = new ConexionProyecto();

		comboBox.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				String combo = (String) comboBox.getSelectedItem();
				if (combo.equals("Apodo")) {
					txtApellidos.setEnabled(false);

					rdbtnMujer.setEnabled(true);
					rdbtnHombre.setEnabled(true);
				}
				if (combo.equals("Persona")) {
					txtApellidos.setEnabled(true);
					rdbtnMujer.setEnabled(true);
					rdbtnHombre.setEnabled(true);
				}
				if (combo.equals("Empresa")) {
					txtApellidos.setEnabled(false);
					rdbtnMujer.setEnabled(false);
					rdbtnHombre.setEnabled(false);
				}
			}
		});

		btnAadir.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				AgendaDao ad = new AgendaDao();
				String nombre = txtNombre.getText();
				String direccion = txtDireccion.getText();
				String notas = txtNotas.getText();

				String sexo;
				String combo = (String) comboBox.getSelectedItem();
				if (combo.equals("Apodo")) {
					if (rdbtnMujer.isSelected()) {
						sexo = "Mujer";
					} else {
						sexo = "Hombre";
					}
					Apodo ap = new Apodo(0, "a", nombre, direccion, notas, listaAficiones, listaTelefonos, listaCorreos,
							sexo);
				}
				if (combo.equals("Persona")) {
					if (rdbtnMujer.isSelected()) {
						sexo = "Mujer";
					} else {
						sexo = "Hombre";
					}
					String Apellidos = txtNotas.getText();

					Persona p = new Persona(0, "p", nombre, direccion, notas, listaAficiones, listaTelefonos,
							listaCorreos, Apellidos, sexo);
				}
				if (combo.equals("Empresa")) {
					ContactoProyecto contacto = new ContactoProyecto(0, "", nombre, direccion, notas, listaAficiones,
							listaTelefonos, listaCorreos);
					ad.anadirContacto(contacto);
				}
				// tipoContacto, , , , listaAficiones, listaTelefonos, listaCorreos)

				JOptionPane.showMessageDialog(null, "Añadido: " + nombre);

			}
		});

		btnTelefonos.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				EventQueue.invokeLater(new Runnable() {
					@Override
					public void run() {
						try {
							VistaT frame = new VistaT(listaTelefonos);
							frame.setVisible(true);
						} catch (Exception e) {
							e.printStackTrace();
						}
					}
				});
			}
		});
	}

	private void iniciarComponentes() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		Tipo = new JPanel();
		Tipo.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(Tipo);
		Tipo.setLayout(null);

		btnTelefonos = new JButton("Telefonos");
		btnTelefonos.setBounds(307, 30, 117, 29);
		Tipo.add(btnTelefonos);

		btnAficiones = new JButton("Aficiones");
		btnAficiones.setBounds(307, 65, 117, 29);
		Tipo.add(btnAficiones);

		btnCorreos = new JButton("Correos");
		btnCorreos.setBounds(307, 97, 117, 29);
		Tipo.add(btnCorreos);

		btnGuardar = new JButton("Guardar");
		btnGuardar.setBounds(327, 243, 117, 29);
		Tipo.add(btnGuardar);

		JLabel lblSexo = new JLabel("Sexo");
		lblSexo.setBounds(5, 80, 46, 14);
		Tipo.add(lblSexo);

		JLabel lblDireccin = new JLabel("Direcci\u00F3n");
		lblDireccin.setBounds(5, 103, 46, 14);
		Tipo.add(lblDireccin);

		JLabel lblNombre = new JLabel("Nombre");
		lblNombre.setBounds(5, 30, 46, 14);
		Tipo.add(lblNombre);

		JLabel lblApellidos = new JLabel("Apellidos");
		lblApellidos.setBounds(5, 55, 46, 14);
		Tipo.add(lblApellidos);

		btnBuscar = new JButton("Buscar");
		btnBuscar.setBounds(0, 227, 89, 23);
		Tipo.add(btnBuscar);

		btnAadir = new JButton("A\u00F1adir");

		btnAadir.setBounds(119, 227, 89, 23);
		Tipo.add(btnAadir);

		btnModificar = new JButton("Modificar");
		btnModificar.setBounds(205, 227, 89, 23);
		Tipo.add(btnModificar);

		txtNombre = new JTextField();
		txtNombre.setBounds(75, 27, 167, 20);
		Tipo.add(txtNombre);
		txtNombre.setColumns(10);

		txtApellidos = new JTextField();
		txtApellidos.setEnabled(false);
		txtApellidos.setBounds(75, 52, 167, 20);
		Tipo.add(txtApellidos);
		txtApellidos.setColumns(10);

		txtDireccion = new JTextField();
		txtDireccion.setBounds(75, 100, 167, 20);
		Tipo.add(txtDireccion);
		txtDireccion.setColumns(10);

		JLabel lblTipoDeC = new JLabel("Tipo de C");
		lblTipoDeC.setBounds(5, 5, 46, 14);
		Tipo.add(lblTipoDeC);

		lblNotas = new JLabel("Notas");
		lblNotas.setBounds(5, 145, 46, 14);
		Tipo.add(lblNotas);

		txtNotas = new JTextField();
		txtNotas.setBounds(75, 142, 349, 20);
		Tipo.add(txtNotas);
		txtNotas.setColumns(10);

		JList list = new JList();
		list.setBounds(252, 188, -173, -13);
		Tipo.add(list);

		DefaultComboBoxModel<String> cbmodel = new DefaultComboBoxModel<>();
		cbmodel.addElement("Apodo");
		cbmodel.addElement("Persona");
		cbmodel.addElement("Empresa");
		comboBox = new JComboBox(cbmodel);
		comboBox.setBounds(75, 2, 172, 20);
		Tipo.add(comboBox);

		rdbtnHombre = new JRadioButton("Hombre");
		rdbtnHombre.setBounds(71, 76, 71, 23);
		Tipo.add(rdbtnHombre);

		rdbtnMujer = new JRadioButton("Mujer");
		rdbtnMujer.setSelected(true);
		rdbtnMujer.setBounds(144, 76, 109, 23);
		Tipo.add(rdbtnMujer);

		ButtonGroup bg = new ButtonGroup();
		bg.add(rdbtnHombre);
		bg.add(rdbtnMujer);

	}
}
