package vistaproyecto;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

import clases_proyecto.Telefono;

public class VistaT extends JFrame {

	private JPanel contentPane;
	private JTable table;
	private JTextField txNumero;
	ArrayList<Telefono> listaTelefonos;
	String[][] datos;
	String[] cabeceras = { "Numero", "Tipo" };
	JScrollPane scrollPane;

	public VistaT(ArrayList<Telefono> listaTelefonos) {
		this.listaTelefonos = listaTelefonos;

		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 793, 400);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		JRadioButton radioFijo = new JRadioButton("FIjo");
		radioFijo.setBounds(83, 302, 141, 23);
		contentPane.add(radioFijo);

		JRadioButton radioMovil = new JRadioButton("Movil");
		radioMovil.setBounds(83, 330, 141, 23);
		contentPane.add(radioMovil);

		JButton btnAadir = new JButton("Añadir");
		btnAadir.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				String num = txNumero.getText();
				String tip;
				if (radioFijo.isSelected()) {
					tip = "Fijo";
				} else {
					tip = "Movil";
				}
				listaTelefonos.add(new Telefono(0, num, tip));
				cargarTabla();

			}
		});
		btnAadir.setBounds(246, 312, 117, 29);
		contentPane.add(btnAadir);

		JButton btnEliminar = new JButton("Eliminar");
		btnEliminar.setBounds(555, 43, 117, 29);
		contentPane.add(btnEliminar);

		JButton btnGuardar = new JButton("Guardar");
		btnGuardar.setBounds(656, 329, 117, 29);
		contentPane.add(btnGuardar);

		txNumero = new JTextField();
		txNumero.setBounds(83, 264, 130, 26);
		contentPane.add(txNumero);
		txNumero.setColumns(10);

		cargarTabla();

	}

	public void cargarTabla() {

		datos = new String[listaTelefonos.size()][2];
		for (int i = 0; i < listaTelefonos.size(); i++) {
			datos[i][0] = listaTelefonos.get(i).getNumero();
			datos[i][1] = listaTelefonos.get(i).getTipoTelefono();
		}
		table = new JTable(datos, cabeceras);
		table.setBounds(38, 223, 416, -204);
		contentPane.add(table);

		scrollPane = new JScrollPane(table);
		scrollPane.setBounds(38, 16, 427, 215);
		contentPane.add(scrollPane);

	}
}
