package mainpackage;

import dao_proyecto.ConexionProyecto;
import vistaproyecto.VistaAltaCliente;

public class Main {
	public static void main(String[] args) {
		new ConexionProyecto();
		VistaAltaCliente vista = new VistaAltaCliente();
		vista.setVisible(true);
	}

}
