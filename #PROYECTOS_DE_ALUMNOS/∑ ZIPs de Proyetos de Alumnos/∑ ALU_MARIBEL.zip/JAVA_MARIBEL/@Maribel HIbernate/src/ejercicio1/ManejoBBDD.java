package ejercicio1;

import java.util.Set;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import tablas.Dept;
import tablas.Emp;
import utils.SessionFactoryUtil;

public class ManejoBBDD {

	// private SessionFactory sessionFactory = SessionFactoryUtil.createSessionFactory();
	private SessionFactory sessionFactory = SessionFactoryUtil.getSessionFactory();
	private Session session = null;
	private Transaction transaction = null;

	public ManejoBBDD() {

	}

	public Set<Emp> mostrarEmpleadosConId(byte depno) {
		Set<Emp> listaEmps = null;
		session = sessionFactory.openSession();

		try {
			transaction = session.beginTransaction();
			Dept dept = session.load(Dept.class, depno);
			listaEmps = dept.getEmps();

			transaction.commit();

		} catch (HibernateException ex) {
			// si da alguna excepcion cancelo los cambios
			if (transaction != null) {
				transaction.rollback();
			}
			// mostrar la excepcion
			System.out.println("no existe empleado con ese id de departamento");

		} finally {
			// Close the session
			session.close();
		}

		return listaEmps;

	}

	public void crearDepartamento(byte deptno, String dname, String loc) {
		session = sessionFactory.openSession();

		try {
			transaction = session.beginTransaction();
			Dept deptt = new Dept();
			deptt.setDeptno(deptno);
			deptt.setDname(dname);
			deptt.setLoc(loc);
			session.save(deptt);
			transaction.commit();

		} catch (HibernateException ex) {
			// si da alguna excepcion cancelo los cambios
			if (transaction != null) {
				transaction.rollback();
			}
			// mostrar la excepcion
			System.out.println("el id ya existe");

		} finally {
			// Close the session
			session.close();
		}

	}

	public void borrarEmpleado(Short id) {
		session = sessionFactory.openSession();

		try {
			transaction = session.beginTransaction();
			// pedir el empleado.
			Emp empleado = session.get(Emp.class, Short.valueOf(id));
			// Borrar empleado
			session.delete(empleado);
			// hacer la transaccion
			transaction.commit();
		} catch (HibernateException | IllegalArgumentException ex) {
			// si no se hace bien deshacer la transaccion
			if (transaction != null) {
				transaction.rollback();
			}
			System.out.println("ese empleado no existe");

		} finally {
			// Close the session
			session.close();
		}

	}

}
