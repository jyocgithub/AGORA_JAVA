package servidorweb;

import java.net.ServerSocket;
import java.net.Socket;

public class ServidorWeb {

	static private final Integer PUERTO = 8000;

	public static void main(String[] args) {
		try {
			ServerSocket socketServidor = new ServerSocket(PUERTO);
			System.out.println("ServerSocket iniciado");
			while (true) {
				Socket socketCliente = socketServidor.accept();
				HiloPeticion hilo = new HiloPeticion(socketCliente);
				hilo.start();
			}
		} catch (Exception ex) {
			System.err.println("Error: " + ex.getMessage());
			System.err.println();
		}
	}

}
