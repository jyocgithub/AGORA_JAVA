package servidorweb;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.net.Socket;

public class HiloPeticion extends Thread {

	private Socket socket;
	BufferedReader input;
	DataOutputStream output;

	public HiloPeticion(Socket s) {
		socket = s;
	}

	@Override
	public void run() {
		try {
			input = new BufferedReader(new InputStreamReader(socket.getInputStream()));
			output = new DataOutputStream(socket.getOutputStream());
			responder(input, output);
		} catch (Exception ex) {
			System.err.println("Error: " + ex.getMessage());
		} finally {
			try {
				input.close();
				output.close();
				socket.close();
			} catch (Exception ex) {
				System.err.println("Error: " + ex.getMessage());
				System.err.println("No se puede cerrar la conexion.");
			}
		}
	}

	private void responder(BufferedReader input, DataOutputStream output) {
		String peticion;
		int tipoPeticion = 0;
		String nombredelfichero;
		FileInputStream archivo;
		int tipoArchivo = 0;

		// leo la primera linea de la peticion
		try {
			peticion = input.readLine(); // Ej: GET /index.html HTTP/1.1
			input.readLine(); // En blanco
		} catch (Exception ex) {
			ex.printStackTrace();
			return; // No se debe seguir adelante
		}

		// SI NO ES GET
		if (!peticion.toUpperCase().startsWith("GET")) {
			try {
				String cab = crearCabecera(501, -1);
				output.write(cab.getBytes());
				System.err.println("Se ha detectado un error 501");
				return; // No se debe seguir adelante
			} catch (Exception ex) {
				ex.printStackTrace();
			}
		} else {
			// SI QUE ES UN GET
			int ini = 0, fin = 0;
			ini = peticion.indexOf(" ");
			fin = peticion.lastIndexOf(" ");
			nombredelfichero = peticion.substring(ini + 2, fin);

			File file = new File(nombredelfichero);
			// SI EL FICHERO NO EXISTE
			if (!file.exists()) {
				try {
					System.err.println("Se ha detectado un error 404");
					String cab = crearCabecera(404, -1);
					output.write(cab.getBytes());
					return; // No se debe seguir adelante
				} catch (Exception ex2) {
					ex2.printStackTrace();
				}

			} else {
				// SI, EL FICHERO EXISTE
				nombredelfichero = nombredelfichero.toLowerCase();
				if (nombredelfichero.endsWith(".htm") || nombredelfichero.endsWith(".html")) {
					tipoArchivo = 1;
				}
				if (nombredelfichero.endsWith(".txt")) {
					tipoArchivo = 2;
				}
				if (nombredelfichero.endsWith(".gif")) {
					tipoArchivo = 3;
				}
				if (nombredelfichero.endsWith(".jpg") || nombredelfichero.endsWith(".jpeg")) {
					tipoArchivo = 4;
				}
				if (nombredelfichero.endsWith(".zip")) {
					tipoArchivo = 5;
				}
				if (nombredelfichero.endsWith(".mp4")) {
					tipoArchivo = 6;
				}
				if (nombredelfichero.endsWith(".avi")) {
					tipoArchivo = 7;
				}

				// Enviamos la cabecera
				try {
					String cab = crearCabecera(200, tipoArchivo);
					output.writeBytes(cab);
					archivo = new FileInputStream(nombredelfichero);
					int b = archivo.read();
					while (b != -1) {
						output.write(b);
						b = archivo.read();
					}
					archivo.close();
				} catch (Exception ex) {
					System.err.println("Error: " + ex.getMessage());
					return; // No se debe seguir adelante
				}
			}
		}

	}

	private String crearCabecera(int codigoRepuesta, int tipoArchivo) {
		String s = "HTTP1.0 ";

		switch (codigoRepuesta) {
		case 200:
			s = s + "200 OK";
			break;
		case 404:
			// s = s + "404 Fichero no encontrado";
			// // s = s + "404 File not found";
			// s = s + "Content-Type: text/text\r\n";
			s = s + "404 Not Found\r\n\r\n Error 404 - FICHERO NO ENCONTRADO. ";
			break;
		case 501:
			s = s + "501 Peticion no empieza por GET, no esta disponible";
			break;
		}
		s = s + "\r\n";
		// s = s + "Connection: close\r\n";

		switch (tipoArchivo) {
		case -1:
			break;
		case 1:
			s = s + "Content-Type: text/html\r\n";
			break;
		case 2:
			s = s + "Content-Type: text/plain\r\n";
			break;
		case 3:
			s = s + "Content-Type: image/gif\r\n";
			break;
		case 4:
			s = s + "Content-Type: image/jpeg\r\n";
			break;
		case 5:
			s = s + "Content-Type: application/zip\r\n";
			break;
		case 6:
			s = s + "Content-Type: video/mp4\r\n";
			break;
		case 7:
			s = s + "Content-Type: video/avi\r\n";
			break;
		}
		s = s + "\r\n";
		return s;
	}

}