package DAVID_Hotel;

import java.io.Serializable;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class Reservas implements Serializable{
	
	private int numeroreserva;
	private LocalDate fechaentrada;
	private LocalDate fechasalida;
	
	public Reservas(int numeroreserva, LocalDate fechaentrada, LocalDate fechasalida) {
		this.numeroreserva = numeroreserva;
		this.fechaentrada = fechaentrada;
		this.fechasalida = fechasalida;
	}
	
	public int getNumeroreserva() {
		return numeroreserva;
	}

	public void setNumeroreserva(int numeroreserva) {
		this.numeroreserva = numeroreserva;
	}

	public LocalDate getFechaentrada() {
		return fechaentrada;
	}

	public void setFechaentrada(LocalDate fechaentrada) {
		this.fechaentrada = fechaentrada;
	}

	public LocalDate getFechasalida() {
		return fechasalida;
	}

	public void setFechasalida(LocalDate fechasalida) {
		this.fechasalida = fechasalida;
	}

	@Override
	public String toString() {
		
		return "Reserva : numero=" + numeroreserva + 
				", fecha entrada=" + localdateToString(fechaentrada) + 
				", fecha salida=" + localdateToString(fechasalida) ;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Reservas other = (Reservas) obj;
		if (numeroreserva != other.numeroreserva)
			return false;
		return true;
	}
	
    public static String localdateToString(LocalDate fechaEnlocaldate) {
        if (fechaEnlocaldate == null) {
            return null;
        }
        return fechaEnlocaldate.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
    }
}
