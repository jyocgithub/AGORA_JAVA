package DAVID_Hotel;

import java.io.Serializable;

public class Simple extends Habitacion implements Serializable {


	private static final long serialVersionUID = 1L;
	private double m2;
	private double precio;
	
	public Simple(int numero, double m2, double precio) {
		super(numero);
		this.m2 = m2;
		this.precio = precio;
	}

	public double getM2() {
		return m2;
	}

	public void setM2(double m2) {
		this.m2 = m2;
	}

	public double getPrecio() {
		return precio;
	}

	public void setPrecio(double precio) {
		this.precio = precio;
	}

	@Override
	public String toString() {
		return super.toString()+ ": Simple , m2=" + m2 + ", precio=" + precio ;
	}

	
	
	
}
