package DAVID_Hotel;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.ArrayList;

import org.joda.time.DateTime;
import org.joda.time.Interval;

public class Hotel implements Serializable {

	private String nombre;
	private String domicilio;
	private String poblacion;
	private ArrayList<Cliente> listaClientes = new ArrayList<>();
	private ArrayList<Reservas> listaReservas = new ArrayList<>();
	private ArrayList<Habitacion> listaHabitaciones = new ArrayList<>();
	private int nuevonumeroreserva = 1;

	// ---------------------------------------------------------------------
	public Hotel(String nombre, String domicilio, String poblacion) {
		this.nombre = nombre;
		this.domicilio = domicilio;
		this.poblacion = poblacion;
		Habitacion s = new Simple(1, 8, 50);
		listaHabitaciones.add(s);
		s = new Simple(2, 8, 50);
		listaHabitaciones.add(s);
		s = new Simple(3, 8, 50);
		listaHabitaciones.add(s);
		s = new Simple(4, 8, 50);
		listaHabitaciones.add(s);
		s = new Simple(5, 8, 50);
		listaHabitaciones.add(s);
		s = new Doble(6, 12, 75, "1 cama");
		listaHabitaciones.add(s);
		s = new Doble(7, 12, 75, "1 cama");
		listaHabitaciones.add(s);
		s = new Doble(8, 12, 75, "2 cama");
		listaHabitaciones.add(s);
		s = new Doble(9, 12, 75, "2 cama");
		listaHabitaciones.add(s);
		s = new Suit(10, 12, 8, 120);
		listaHabitaciones.add(s);
		s = new Suit(11, 12, 8, 120);
		listaHabitaciones.add(s);
	}

	// ---------------------------------------------------------------------
	public boolean anadirCliente(Cliente clientenuevo) {
		boolean exito = true;
		for (Cliente cli : listaClientes) {
			if (cli.getDni().equals(clientenuevo.getDni())) {
				exito = false;
			}
		}
		if (exito == true) {
			listaClientes.add(clientenuevo);
		}
		return exito;
	}

	// ---------------------------------------------------------------------
	public boolean reservar(String tipohabitacion, LocalDate fechaentrada, LocalDate fechasalida, Cliente elcliente) {

		Habitacion habitaciondisponible = null;
		// ver si la habitacion esta ya reservada y en las fechas pedidas
		// suponer pide doble,

		for (int i = 0; i < listaHabitaciones.size() && habitaciondisponible == null; i++) {
			Habitacion laHabitacionQueAnalizo = listaHabitaciones.get(i);

			if (tipohabitacion.equals("D") && laHabitacionQueAnalizo instanceof Doble) {
				ArrayList<Reservas> reservasyahechas = laHabitacionQueAnalizo.getReservas();
				boolean ocupadoya = estaHabitacionTieneOcupadoEnEsteRango(reservasyahechas, fechaentrada, fechasalida);
				if (ocupadoya == false) {
					habitaciondisponible = laHabitacionQueAnalizo;
				}
			}
			if (tipohabitacion.equals("S") && laHabitacionQueAnalizo instanceof Simple) {
				ArrayList<Reservas> reservasyahechas = laHabitacionQueAnalizo.getReservas();
				boolean ocupadoya = estaHabitacionTieneOcupadoEnEsteRango(reservasyahechas, fechaentrada, fechasalida);
				if (ocupadoya == false) {
					habitaciondisponible = laHabitacionQueAnalizo;
				}
			}
			if (tipohabitacion.equals("SU") && laHabitacionQueAnalizo instanceof Suit) {
				ArrayList<Reservas> reservasyahechas = laHabitacionQueAnalizo.getReservas();
				boolean ocupadoya = estaHabitacionTieneOcupadoEnEsteRango(reservasyahechas, fechaentrada, fechasalida);
				if (ocupadoya == false) {
					habitaciondisponible = laHabitacionQueAnalizo;
				}
			}
		}

		if (habitaciondisponible != null) {
			// creamos la reserva con las fechas pedidas
			Reservas r = new Reservas(nuevonumeroreserva, fechaentrada, fechasalida);
			// incrementamos el numero de reserva para que la proxima reserva este preparada
			nuevonumeroreserva++;
			// agregamos la reserva en la lista de reservas del hotel
			this.listaReservas.add(r);
			// agregamos tambien la reserva en la lista de reservas de la habitacion
			habitaciondisponible.getReservas().add(r);
			// agregamos tambien la reserva en la lista de reservas del cliente
			elcliente.getListaReservas().add(r);
			System.out.println("Se le reserva esta habitacion: " + habitaciondisponible);
			return true;
		} else {
			return false;
		}

	}

	// ---------------------------------------------------------------------
	public boolean estaHabitacionTieneOcupadoEnEsteRango(ArrayList<Reservas> reservas, LocalDate fechaentrada,
			LocalDate fechasalida) {
		boolean estayareservada = false;
		for (int i = 0; i < reservas.size() && estayareservada == false; i++) {
			Reservas cadaReservasDeLaHabitacion = reservas.get(i);
			if (seSolapan(cadaReservasDeLaHabitacion.getFechaentrada(), cadaReservasDeLaHabitacion.getFechasalida(),
					fechaentrada, fechasalida)) {
				estayareservada = true;
			}
		}
		return estayareservada;
	}

	// ---------------------------------------------------------------------
	public void verDisponibles(String tipohabitacion, LocalDate fechaentrada, LocalDate fechasalida) {

		for (Habitacion laHabitacionQueAnalizo : listaHabitaciones) {

			if (tipohabitacion.equals("D") && laHabitacionQueAnalizo instanceof Doble) {
				ArrayList<Reservas> reservasyahechas = laHabitacionQueAnalizo.getReservas();
				boolean ocupadoya = estaHabitacionTieneOcupadoEnEsteRango(reservasyahechas, fechaentrada, fechasalida);
				if (ocupadoya == false) {
					System.out.println("Esta habitacion esta disponible: " + laHabitacionQueAnalizo);
				}
			}
			if (tipohabitacion.equals("S") && laHabitacionQueAnalizo instanceof Simple) {
				ArrayList<Reservas> reservasyahechas = laHabitacionQueAnalizo.getReservas();
				boolean ocupadoya = estaHabitacionTieneOcupadoEnEsteRango(reservasyahechas, fechaentrada, fechasalida);
				if (ocupadoya == false) {
					System.out.println("Esta habitacion esta disponible: " + laHabitacionQueAnalizo);
				}
			}
			if (tipohabitacion.equals("SU") && laHabitacionQueAnalizo instanceof Suit) {
				ArrayList<Reservas> reservasyahechas = laHabitacionQueAnalizo.getReservas();
				boolean ocupadoya = estaHabitacionTieneOcupadoEnEsteRango(reservasyahechas, fechaentrada, fechasalida);
				if (ocupadoya == false) {
					System.out.println("Esta habitacion esta disponible: " + laHabitacionQueAnalizo);
				}
			}
		}

	}

	// ---------------------------------------------------------------------
	public void verReservas(LocalDate fechaentrada, LocalDate fechasalida) {
		for (Habitacion laHabitacionQueAnalizo : listaHabitaciones) {
			ArrayList<Reservas> reservasyahechas = laHabitacionQueAnalizo.getReservas();
			for (Reservas res : reservasyahechas) {
				if (seSolapan(res.getFechaentrada(), res.getFechasalida(), fechaentrada, fechasalida)) {
					System.out.println(
							"Reserva encontrada: " + laHabitacionQueAnalizo);
					System.out.println("                    " + res);
				}
			}
		}
	}

	// ---------------------------------------------------------------------
	public void verReservasPorCliente() {

		for (Cliente cli : listaClientes) {
			System.out.println("Reservas del cliente " + cli.getNombre());
			for (Reservas res : cli.getListaReservas()) {
				System.out.println(" --> " + res);
			}
		}

	}

	// ---------------------------------------------------------------------
	public void listarHabitaciones() {
		for (Habitacion z : listaHabitaciones) {
			System.out.println(z);
		}
	}

	// ---------------------------------------------------------------------
	public void listarClientes() {

		for (Cliente c : listaClientes) {
			System.out.println(c);
		}

	}

	// ---------------------------------------------------------------------
	public Cliente buscarCliente(String nif) {
		Cliente cli = null;
		for (int i = 0; i < listaClientes.size() && cli == null; i++) {
			Cliente cadaclienteanalizado = listaClientes.get(i);
			if (cadaclienteanalizado.getDni().equals(nif)) {
				cli = cadaclienteanalizado;
			}
		}
		return cli;
	}

	// ---------------------------------------------------------------------
	public static boolean seSolapan(LocalDate unoInicio, LocalDate unoFinal, LocalDate dosInicio, LocalDate dosFinal) {
		unoFinal = unoFinal.plusDays(1);
		dosFinal = dosFinal.plusDays(1);
		DateTime unoIni = new DateTime(unoInicio.getYear(), unoInicio.getMonthValue(), unoInicio.getDayOfMonth(), 0, 0,
				0, 0);
		DateTime unoFin = new DateTime(unoFinal.getYear(), unoFinal.getMonthValue(), unoFinal.getDayOfMonth(), 0, 0, 0,
				0);
		DateTime dosIni = new DateTime(dosInicio.getYear(), dosInicio.getMonthValue(), dosInicio.getDayOfMonth(), 0, 0,
				0, 0);
		DateTime dosFin = new DateTime(dosFinal.getYear(), dosFinal.getMonthValue(), dosFinal.getDayOfMonth(), 0, 0, 0,
				0);
		Interval inter1 = new Interval(unoIni, unoFin);
		Interval inter2 = new Interval(dosIni, dosFin);
		boolean solucion = inter1.overlaps(inter2);
		return solucion;
	}

	// ---------------------------------------------------------------------
	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getDomicilio() {
		return domicilio;
	}

	public void setDomicilio(String domicilio) {
		this.domicilio = domicilio;
	}

	public String getPoblacion() {
		return poblacion;
	}

	public void setPoblacion(String poblacion) {
		this.poblacion = poblacion;
	}

	@Override
	public String toString() {
		return "Hotel [nombre=" + nombre + ", domicilio=" + domicilio + ", poblacion=" + poblacion + "]";
	}

	// --------------------------------------------------------------------

}