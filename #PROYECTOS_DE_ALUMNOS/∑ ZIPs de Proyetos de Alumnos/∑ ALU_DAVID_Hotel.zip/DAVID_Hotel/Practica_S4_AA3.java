package DAVID_Hotel;

import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

public class Practica_S4_AA3 {
	static Scanner entradaLet = new Scanner(System.in);
	static Scanner entradaNum = new Scanner(System.in);
	static String tipohabitacion;
	static String fechaen;
	static String fechasal;

	static LocalDate fechaentrada;
	static LocalDate fechasalida;
	static private Hotel hotel1;
	static private Cliente elcliente;

	public static void main(String[] args) {

//		hotel1 = new Hotel("LOS ALAMOS", "Calle Oca Num 2", "28030 - Madrid");
		// ... Leer hotel del fichero
		hotel1 = (Hotel) leerObjetoDeFichero("Hotel.bin");

		if (hotel1 == null) {
			// crear primero hotek y habitaciones para poder trabajar con ello
			hotel1 = new Hotel("LOS ALAMOS", "Calle Oca Num 2", "28030 - Madrid");
		}
		// ... fin Leer hotel del fichero

		int opcion = 0;

		do {
			System.out.println("======== MENU =============");
			System.out.println("1. Crear Cliente");
			System.out.println("2. Reservar Habitacion");
			System.out.println("3. Habitaciones disponibles");
			System.out.println("4. Reservas realizadas");
			System.out.println("5. Reservas por cliente");
			System.out.println("6. Listar clientes");
			System.out.println("7. Listar habitaciones");
			System.out.println("0. Salir");
			System.out.println("===========================");
			System.out.println("Escriba una opcion: ");
			opcion = entradaNum.nextInt();

			switch (opcion) {
			case 1:
				System.out.println("Dame el nombre:");
				String nombre = entradaLet.nextLine();
				System.out.println("Dame los apellidos:");
				String apellidos = entradaLet.nextLine();
				System.out.println("Dame el dni:");
				String dni = entradaLet.nextLine();
				Cliente cli = new Cliente(nombre, apellidos, dni);
				boolean exito = hotel1.anadirCliente(cli);
				if (exito == false) {
					System.out.println("Cliente no creado, dni ya existe");
				}
				// .. guardar hotel en el fichero
				guardarObjetoEnFichero(hotel1, "Hotel.bin");

				// .. fin guardar hotel en el fichero
				break;
			case 2:

				System.out.println("Dame el NIF del cliente que quiera reservar: ");
				String nif = entradaLet.nextLine();

				if (existeCliente(nif) == true) {
					if (pedirdatosTipoHabitacion() == true) {
						if (pedirdatosFechas() == true) {
							if (hotel1.reservar(tipohabitacion, fechaentrada, fechasalida, elcliente) == false) {
								System.out.println("No se puede hacer la reserva por fecha no disponible");
							}
						}
					}
				}

				// .. guardar hotel en el fichero
				guardarObjetoEnFichero(hotel1, "Hotel.bin");

				// .. fin guardar hotel en el fichero
				break;
			case 3:
				if (pedirdatosTipoHabitacion() == true) {
					if (pedirdatosFechas() == true) {
						hotel1.verDisponibles(tipohabitacion, fechaentrada, fechasalida);
					}
				}
				break;
			case 4:
				if (pedirdatosFechas() == true) {
					hotel1.verReservas(fechaentrada, fechasalida);
				}
				break;
			case 5:
				hotel1.verReservasPorCliente();
				break;
			case 6:
				hotel1.listarClientes();
				break;
			case 7:
				hotel1.listarHabitaciones();
				break;
			}

		} while (opcion != 0);

	}

	// ---------------------------------------------------------------------
	public static boolean pedirdatosTipoHabitacion() {
		System.out.println("Dame el tipo de habitacion (S/D/SU): ");
		tipohabitacion = entradaLet.nextLine();
		tipohabitacion = tipohabitacion.toUpperCase();
		if (tipohabitacion.equalsIgnoreCase("S") || tipohabitacion.equalsIgnoreCase("SU")
				|| tipohabitacion.equalsIgnoreCase("D")) {
			return true;
		}
		System.out.println("Debe elegir un tipo de habitacion correcto");
		return false;
	}

	// ---------------------------------------------------------------------
	public static boolean existeCliente(String nif) {
		elcliente = hotel1.buscarCliente(nif);
		if (elcliente == null) {
			System.out.println("No existe cliente con ese nif, debe darlo de alta");
			return false;
		}
		return true;
	}

	// ---------------------------------------------------------------------
	public static boolean pedirdatosFechas() {
		System.out.println("Dame la fecha de entrada (DD/MM/AAAA) :");
		fechaen = entradaLet.nextLine();
		System.out.println("Dame la fecha de salida (DD/MM/AAAA) :");
		fechasal = entradaLet.nextLine();
		fechaentrada = stringtoLocalDate(fechaen);
		fechasalida = stringtoLocalDate(fechasal);

		if (fechaentrada == null || fechasalida == null) {
			System.out.println("Formato de fechas no valido, debe ser DD/MM/AAAA");
			return false;
		}

		if (fechaentrada.isAfter(fechasalida)) {
			System.out.println("fecha no valida, fecha entrada debe ser anterior a la fecha de salida");
			return false;
		}
		return true;
	}

	// ---------------------------------------------------------------------
	public static LocalDate stringtoLocalDate(String fecha) {
		LocalDate resultado = null;
		if (fecha.matches("^(0[1-9]|[12][0-9]|3[01])[\\/](0[1-9]|1[012])[\\/][0-9]{4}$")) {
			resultado = LocalDate.parse(fecha, DateTimeFormatter.ofPattern("dd/MM/yyyy"));
		}
		return resultado;
	}

	// ---------------------------------------------------------------------
	// ---------------------------------------------------------------------
	// ---------------------------------------------------------------------

	public static void guardarObjetoEnFichero(Object objeto, String nombrefichero) {
		ObjectOutputStream oos = null;
		try {
			oos = new ObjectOutputStream(new FileOutputStream(nombrefichero));
			oos.writeObject(objeto);
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				if (oos != null) {
					oos.close();
				}
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

	// ---------------------------------------------------------------------
	public static Object leerObjetoDeFichero(String nombrefichero) {
		Object o = null;
		File file = new File(nombrefichero);
		if (file.exists()) {
			ObjectInputStream ois = null;
			try {
				ois = new ObjectInputStream(new FileInputStream(file));
				o = ois.readObject();
			} catch (IOException e) {
				e.printStackTrace();
			} catch (ClassNotFoundException e) {
				e.printStackTrace();
			} finally {
				try {
					if (ois != null) {
						ois.close();
					}
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
		return o;
	}

}
