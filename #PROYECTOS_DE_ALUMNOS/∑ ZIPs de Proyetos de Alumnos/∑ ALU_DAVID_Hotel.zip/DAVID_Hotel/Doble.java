package DAVID_Hotel;
import java.io.Serializable;

public class Doble extends Habitacion implements Serializable{
	private double m2;
	private double precio;
	private String tipocama;
	
	public Doble(int numero, double m2, double precio, String tipocama) {
		super(numero);
		this.m2 = m2;
		this.precio = precio;
		this.tipocama = tipocama;
	}

	public double getM2() {
		return m2;
	}

	public void setM2(double m2) {
		this.m2 = m2;
	}

	public double getPrecio() {
		return precio;
	}

	public void setPrecio(double precio) {
		this.precio = precio;
	}

	public String getTipocama() {
		return tipocama;
	}

	public void setTipocama(String tipocama) {
		this.tipocama = tipocama;
	}

	@Override
	public String toString() {
		return  super.toString()+ ": Doble, m2=" + m2 + ", precio=" + precio + ", tipocama=" + tipocama ;
	}
	
}
