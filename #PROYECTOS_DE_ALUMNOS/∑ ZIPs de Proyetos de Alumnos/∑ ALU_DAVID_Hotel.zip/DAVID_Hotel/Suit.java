package DAVID_Hotel;

import java.io.Serializable;

public class Suit extends Habitacion implements Serializable{

	private double m2dormitorio;
	private double m2sala;
	private double precio;
	
	public Suit(int numero, double m2dormitorio, double m2sala, double precio) {
		super(numero);
		this.m2dormitorio = m2dormitorio;
		this.m2sala = m2sala;
		this.precio = precio;
	}

	public double getM2dormitorio() {
		return m2dormitorio;
	}

	public void setM2dormitorio(double m2dormitorio) {
		this.m2dormitorio = m2dormitorio;
	}

	public double getM2sala() {
		return m2sala;
	}

	public void setM2sala(double m2sala) {
		this.m2sala = m2sala;
	}

	public double getPrecio() {
		return precio;
	}

	public void setPrecio(double precio) {
		this.precio = precio;
	}

	@Override
	public String toString() {
		return  super.toString()+ ": Suit , m2dormitorio=" + m2dormitorio + ", m2sala=" + m2sala + ", precio=" + precio ;
	}
	
}
