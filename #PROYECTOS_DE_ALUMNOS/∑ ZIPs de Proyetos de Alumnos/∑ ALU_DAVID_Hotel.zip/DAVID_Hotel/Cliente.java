package DAVID_Hotel;

import java.io.Serializable;
import java.util.ArrayList;

public class Cliente implements Serializable{
	
	private String nombre;
	private String apellidos;
	private String dni;
	private ArrayList<Reservas> listaReservas ;
	
	public Cliente(String nombre, String apellidos, String dni) {
		this.nombre = nombre;
		this.apellidos = apellidos;
		this.dni = dni;
		listaReservas = new ArrayList<>();	
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getApellidos() {
		return apellidos;
	}

	public void setApellidos(String apellidos) {
		this.apellidos = apellidos;
	}

	public String getDni() {
		return dni;
	}

	public void setDni(String dni) {
		this.dni = dni;
	}

	public ArrayList<Reservas> getListaReservas() {
		return listaReservas;
	}

	public void setListaReservas(ArrayList<Reservas> listaReservas) {
		this.listaReservas = listaReservas;
	}

	@Override
	public String toString() {
		return "Cliente: dni=" + dni +", nombre=" + nombre + ", apellidos=" + apellidos;
	}
	
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Cliente other = (Cliente) obj;
		if (dni == null) {
			if (other.dni != null)
				return false;
		} else if (!dni.equals(other.dni))
			return false;
		return true;
	}
	
}
