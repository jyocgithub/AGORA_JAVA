package DAVID_Hotel;
import java.io.Serializable;
import java.time.LocalDate;

import java.util.ArrayList;
abstract public class Habitacion implements Serializable{

	protected int numero;
	private ArrayList<Reservas> fechasreservadas;  

	public Habitacion(int numero) {
		this.numero = numero;
		this.fechasreservadas =  new ArrayList<>();  
	}

	public int getNumero() {
		return numero;
	}

	public void setNumero(int numero) {
		this.numero = numero;
	}
	
	@Override
	public String toString() {
		return "Habitacion numero " + numero  ;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Habitacion other = (Habitacion) obj;
		if (numero != other.numero)
			return false;
		return true;
	}

	public ArrayList<Reservas> getReservas() {
		return fechasreservadas;
	}

	public void setReservas(ArrayList<Reservas> fechasreservadas) {
		this.fechasreservadas = fechasreservadas;
	}
	
}
