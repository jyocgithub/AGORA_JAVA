package Actividad7;

import java.awt.Graphics;

public interface SuperFigura {

	public void dibujar(Graphics g);
	
	
}
