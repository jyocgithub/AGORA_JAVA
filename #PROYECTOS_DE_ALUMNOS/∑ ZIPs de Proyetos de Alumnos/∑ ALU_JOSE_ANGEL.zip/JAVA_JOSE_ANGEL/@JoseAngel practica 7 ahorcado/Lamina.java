package Actividad7;

import java.awt.Color;
import java.awt.Component;
import java.awt.Graphics;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JPanel;

public class Lamina extends JPanel {

	List<SuperFigura> lineas;
	Figura figura;
	Figura2 figura2;
	//int contador =0;

	
	public void paintComponent(Graphics g) {

		super.paintComponent(g);

		lineas = new ArrayList<>();

		figura = new Figura(100, 200, 150, 300);// Pata Derecha
		lineas.add(figura);

		figura = new Figura(100, 200, 100, 50);//poste
		lineas.add(figura);

		figura = new Figura(100, 200, 50, 300);// Pata izquierda
		lineas.add(figura);

		figura = new Figura(100, 50, 200, 50);// linea superior horizontal
		lineas.add(figura);

		figura=new Figura(100, 100, 150, 50);// linea superior vertical
		lineas.add(figura);
		
		figura=new Figura(200, 100, 200, 50);// soga
		lineas.add(figura);
		
		figura2=new Figura2(175, 100, 50, 50);//Cabeza
		lineas.add(figura2);
		
		figura=new Figura(200, 150, 200, 200); // cuerpo
		lineas.add(figura);
		
		figura=new Figura(150, 175, 250, 175); // Brazos
		lineas.add(figura);
		
		figura=new Figura(200, 200, 150, 270);// Pierna Izq
		lineas.add(figura);
		
		figura=new Figura(250, 270, 200, 200);// Pierna derecha
		lineas.add(figura);
		
		for (int i = 0; i < 11; i++) {
			//while(contador<12)
			lineas.get(i).dibujar(g);
			//contador++;
			
		}

	}
}