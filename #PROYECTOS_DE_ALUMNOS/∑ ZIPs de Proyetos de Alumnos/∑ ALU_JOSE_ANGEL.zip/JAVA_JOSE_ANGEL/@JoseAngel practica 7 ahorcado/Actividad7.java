package Actividad7;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Graphics;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.TitledBorder;

public class Actividad7 {

	public static void main(String[] args) {
		Principal principal = new Principal();
		principal.setVisible(true);

	}

}

class Principal extends JFrame {

	Lamina lamina;
	char guion = '-';

	JLabel letra, letrasFallidas;
	JTextField textopalabrasecreta, textoletrajugador, textoletraselegidas;
	JButton botonstart, botonsuerte;
	JPanel panel2, panel3, panel4, panel5;
	char[] oculta;
	String secreta;

	public Principal() {

		setLayout(new BorderLayout());
		setTitle("Ahorcado");
		setBounds(200, 200, 500, 500);
		lamina = new Lamina();

		lamina.setBorder(BorderFactory.createLineBorder(Color.BLACK));
		lamina.setBackground(Color.orange);

		panel2 = new JPanel(); // Panel Inferior

		panel2.setLayout(new BorderLayout());
		add(panel2, BorderLayout.SOUTH);

		panel3 = new JPanel();
		panel3.setLayout(new FlowLayout());

		letra = new JLabel("Secreta");
		TitledBorder tb1 = new TitledBorder("Palabra");
		letra.setBorder(tb1);

		textopalabrasecreta = new JTextField(10);
		textopalabrasecreta.setHorizontalAlignment(JTextField.CENTER);
		textopalabrasecreta.setBorder(BorderFactory.createLineBorder(Color.black));

		botonstart = new JButton();
		botonstart.setText("Comenzar");
		botonstart.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				 secreta = JOptionPane.showInputDialog("Hola!!!! Inserte la palabra secreta");
				if (secreta == null) {
					JOptionPane.showInternalMessageDialog(null, "Hasta la pr�xima!!!");
				} else {
					secreta = secreta.replace('a', guion).replace('e', guion).replace('i', guion).replace('o', guion)
							.replace('u', guion).replace('�', guion).replace('�', guion).replace('�', guion)
							.replace('�', guion).replace('�', guion).replace('A', guion).replace('E', guion)
							.replace('I', guion).replace('O', guion).replace('U', guion);

				}
				textopalabrasecreta.setText(secreta);
				oculta = secreta.toCharArray();
			//	palabrasecreta.disable();
			}
		});

		panel3.add(letra);
		panel3.add(textopalabrasecreta);
		add(botonstart, BorderLayout.NORTH);

		panel4 = new JPanel();
		panel4.setLayout(new FlowLayout());

		textoletrajugador = new JTextField(5);
		textoletrajugador.setHorizontalAlignment(JTextField.CENTER);
		textoletrajugador.setBorder(BorderFactory.createLineBorder(Color.black));

		botonsuerte = new JButton("Prueba Suerte");
		botonsuerte.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				for (int i = 0; i < oculta.length; i++) {
					if (!(oculta[i] == textoletrajugador.getText().toString().charAt(0))) {
						textopalabrasecreta.setText(String.valueOf(secreta));

					} else {
						
					}
				}
					//A�adir las letras jugadas y vaciar letra jugador en cada jugada
				textoletraselegidas.setText(textoletrajugador.getText().toString() + textoletraselegidas.getText().toString());
				textoletrajugador.setText(null);
			}

		});

		panel5 = new JPanel();
		panel5.setLayout(new GridBagLayout());

		letrasFallidas = new JLabel("Fallidas");
		TitledBorder tb = new TitledBorder("Letras");
		letrasFallidas.setBorder(tb);

		textoletraselegidas = new JTextField(15);
		textoletraselegidas.setHorizontalAlignment(JTextField.CENTER);
		textoletraselegidas.setBorder(BorderFactory.createLineBorder(Color.black));

		panel5.add(letrasFallidas);
		panel5.add(textoletraselegidas);

		panel4.add(botonsuerte);
		panel4.add(textoletrajugador);

		panel2.add(panel3, BorderLayout.CENTER);
		panel2.add(panel4, BorderLayout.SOUTH);
		
		add(panel5, BorderLayout.EAST);
		add(lamina, BorderLayout.CENTER);
	}

}
