package com.mygdx.game;

import com.badlogic.gdx.ApplicationAdapter;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.math.Vector2;

public class MyGdxGame extends ApplicationAdapter {
	SpriteBatch batch;
	Texture img;
	Texture tesela;
	TextureRegion esqueleto;
	TextureRegion rojillo;
	TextureRegion boss;
	TextureRegion vela;

	Vector2 pos;
	Vector2 velocidad;
	Vector2 velocidadHorizontal;
	Vector2 velocidadHorizontalVela;
	Vector2 velocidadVertical;
	Vector2 velocidadDiagonal;
	Vector2 velocidadGravedad;
	//Vector2 posHeroe;
	//Vector2 velocidadHeroe;

	Vector2 posEsqueleto;
	Vector2 posRojillo;
	Vector2 posBoss;
	Vector2 posVela;
	
	@Override
	public void create () {
		batch = new SpriteBatch();
	//	img = new Texture("badlogic.jpg");
		tesela=new Texture("tesela.png");

		esqueleto=new TextureRegion(tesela,0,96,16,16);
		rojillo=new TextureRegion(tesela,19,100,16,10);
		boss=new TextureRegion(tesela,112,91,17,20);
		vela=new TextureRegion(tesela,115,42,17,20);

		pos=new Vector2(100,100);
		velocidad=new Vector2(50,50);

		velocidadHorizontal=new Vector2(-75,0);
		velocidadHorizontalVela=new Vector2(75,0);
		velocidadVertical=new Vector2(0,5);
		velocidadDiagonal=new Vector2(-50,50);
		velocidadGravedad=new Vector2(0,-50);

		posEsqueleto=new Vector2(400-12,0);
		posRojillo=new Vector2(0,400-10);
		posBoss=new Vector2(400-16,400-20);
		posVela=new Vector2(0,0);

		//posHeroe=new Vector2(200,200);
		//velocidadHeroe=new Vector2(0,0);
	}

	@Override
	public void render () {
		//Poner la velocidad a 0 siempre antes de entrar al IF
	//	velocidadHeroe.x=0;
	//	velocidadHeroe.y=0;

	//	if(Gdx.input.isKeyPressed(Input.Keys.RIGHT)){
	//		velocidadHeroe.x=100;
	//	}
	//	if(Gdx.input.isKeyPressed(Input.Keys.LEFT)){
	//		velocidadHeroe.x=-100;
	//	}
	//	if(Gdx.input.isKeyPressed(Input.Keys.UP)){
	//		velocidadHeroe.y=100;
	//	}
	//	if(Gdx.input.isKeyPressed(Input.Keys.DOWN)){
	//		velocidadHeroe.y=-100;
	//	}

		float dt = Gdx.graphics.getDeltaTime();

		velocidad.scl(dt);
		pos.add(velocidad);
		velocidad.scl(1/dt);

		velocidadHorizontal.scl(dt);
		posEsqueleto.add(velocidadHorizontal);
		velocidadHorizontal.scl(1/dt);

		velocidadHorizontalVela.scl(dt);
		posVela.add(velocidadHorizontalVela);
		velocidadHorizontalVela.scl(1/dt);
//
//		velocidadHorizontal.scl(dt);
//		posRojillo.add(velocidadHorizontal);
//		velocidadHorizontal.scl(1/dt);
//
//		velocidadHorizontal.scl(dt);
//		posBoss.add(velocidadHorizontal);
//		velocidadHorizontal.scl(1/dt);
//
//		velocidadHorizontal.scl(dt);
//		posVela.add(velocidadHorizontal);
//		velocidadHorizontal.scl(1/dt);
//
//		velocidadVertical.scl(dt);
//		posEsqueleto.add(velocidadVertical);
//		velocidadVertical.scl(1/dt);
//
//		velocidadVertical.scl(dt);
//		posRojillo.add(velocidadVertical);
//		velocidadVertical.scl(1/dt);
//
//		velocidadVertical.scl(dt);
//		posBoss.add(velocidadVertical);
//		velocidadVertical.scl(1/dt);
//
//		velocidadVertical.scl(dt);
//		posVela.add(velocidadVertical);
//		velocidadVertical.scl(1/dt);
//
//		velocidadDiagonal.scl(dt);
//		posEsqueleto.add(velocidadDiagonal);
//		velocidadDiagonal.scl(1/dt);
//
//		velocidadGravedad.scl(dt);
//		posBoss.add(velocidadGravedad);
//		velocidadGravedad.scl(1/dt);

	//	velocidadHeroe.scl(dt);
	//	posHeroe.add(velocidadHeroe);
	//	velocidadHeroe.scl(1/dt);

		//Para que rebote y no se salga de la pantalla
		/*if(pos.x>400-16)
			velocidad.scl(-1);
		else if(pos.x<0)
			velocidad.scl(-1);
		else if(pos.y>400)
			velocidad.scl(-1);
		else if(pos.y<0)
			velocidad.scl(-1);*/

//		if(pos.x>400-16)
//			velocidad.x*=(-1);
//		else if(pos.x<0)
//			velocidad.x*=(-1);
//		else if(pos.y>400)
//			velocidad.y*=(-1);
//		else if(pos.y<0)
//			velocidad.y*=(-1);

		 if(posEsqueleto.x<0) {
		 	posEsqueleto.x = 400 - 12;
		 	velocidadHorizontal.x=0;
		 }else if(posVela.x>400){
		 	posVela.x=0;
		 	velocidadHorizontalVela.x=0;
		 }



		Gdx.gl.glClearColor(0,0,0,1);
		Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);
		batch.begin();
		//batch.draw(img, 75, 75);
		//batch.draw(tesela, 75, 100);

		//batch.draw(esqueleto, 400-12, 0);
		batch.draw(rojillo, 0, 400-10);
		//batch.draw(vela, 0, 0);
		batch.draw(boss, 400-16, 400-20);

//		batch.draw(boss, pos.x,pos.y);
//		batch.draw(boss, posBoss.x,posBoss.y);
		batch.draw(esqueleto, posEsqueleto.x,posEsqueleto.y);
//		batch.draw(rojillo, posRojillo.x,posRojillo.y);
		batch.draw(vela,posVela.x,posVela.y);
//		batch.draw(boss, posBoss.x,posBoss.y);


		//batch.draw(boss, posHeroe.x,posHeroe.y);


		batch.end();
	}
	
	@Override
	public void dispose () {
		batch.dispose();
		//img.dispose();
		tesela.dispose();
	}
}
