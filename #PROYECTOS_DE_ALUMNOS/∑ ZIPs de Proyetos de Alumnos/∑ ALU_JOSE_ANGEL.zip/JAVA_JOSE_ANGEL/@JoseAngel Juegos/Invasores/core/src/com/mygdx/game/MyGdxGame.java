package com.mygdx.game;

import com.badlogic.gdx.ApplicationAdapter;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.math.Rectangle;
import com.badlogic.gdx.Input.Keys;



class Personaje {
    TextureRegion imagen;
    public Vector2 posicion, velocidad;
    public Rectangle mascaraVital, mascaraAtaque;
    
    Personaje(TextureRegion img) {
        this.imagen = img;
        posicion = new Vector2(0,0);
        velocidad = new Vector2(0,0);
        mascaraVital = new Rectangle(0,0, img.getRegionWidth(), img.getRegionHeight());
    }
    
    void crearMascaraAtaque() {
        mascaraAtaque = new Rectangle(0,0, imagen.getRegionWidth(), imagen.getRegionHeight());
    }
    
    void dibujar(SpriteBatch batch) {
        batch.draw(imagen, posicion.x, posicion.y);
    }
    
    void actualizarPosicion(float dt) {
        velocidad.scl(dt);
        posicion.add(velocidad);
        velocidad.scl(1/dt);
    }
    
    void actualizarMascara() {
        mascaraVital.setPosition(posicion);
        if(mascaraAtaque != null)
            mascaraAtaque.setPosition(posicion);
    }
};

class Heroe extends Personaje {
    Heroe(TextureRegion img) {
        super(img);
    }
};

public class MyGdxGame extends ApplicationAdapter {
	SpriteBatch batch;
	Texture tesela;
	TextureRegion heroeImg, dagaImg, esqueletoImg;
	Heroe heroe;
	Personaje daga;
	Personaje enemigo[];
	
	@Override
	public void create () {
		batch = new SpriteBatch();
		tesela = new Texture("0x72_16x16DungeonTileset.v1.png");
		heroeImg = new TextureRegion(tesela, 2, 64, 13-2, 80-64);
		dagaImg = new TextureRegion(tesela, 128, 101, 135-128, 111-101);
		esqueletoImg = new TextureRegion(tesela, 2, 97, 12-2, 112-97);
		heroe = new Heroe(heroeImg);
		heroe.posicion.x = 32;
		heroe.posicion.y = 240;

		enemigo = new Personaje[10];
		for(int i=0; i < 10; i++) {
		  enemigo[i] = new Personaje(esqueletoImg);
		  enemigo[i].posicion.x = 800;
		  enemigo[i].posicion.y = 30 + i*30;
		  enemigo[i].velocidad.x = -50;
		  enemigo[i].velocidad.y = -50;
		  enemigo[i].crearMascaraAtaque();
		}
	}

	@Override
	public void render () {
        heroe.velocidad.x = 0;
        heroe.velocidad.y = 0;
        if(Gdx.input.isKeyPressed(Keys.DOWN)){
          	heroe.velocidad.y = -100;
        } else if(Gdx.input.isKeyPressed(Keys.UP)){
          	heroe.velocidad.y = 100;
        }
        if(Gdx.input.isKeyPressed(Keys.LEFT)){
          	heroe.velocidad.x = -100;
        }  else if(Gdx.input.isKeyPressed(Keys.RIGHT)){
          	heroe.velocidad.x = 100;
        }
        if(Gdx.input.isKeyPressed(Keys.SPACE)){
          	if(daga == null) {
          	 daga = new Personaje(dagaImg);
          	 daga.posicion.x = heroe.posicion.x;
          	 daga.posicion.y = heroe.posicion.y;
          	 daga.velocidad.x = 300;
          	 daga.crearMascaraAtaque();
          	}
        }
	   
	   float dt = Gdx.graphics.getDeltaTime();
	   heroe.actualizarPosicion(dt);
	   
	   if(daga != null) 
	       daga.actualizarPosicion(dt);
	       
	   for(int i=0; i < 10; i++) {
		  Personaje e = enemigo[i];
		  if(e == null)
		      continue;
		  e.actualizarPosicion(dt);
		}
	   
	   if(heroe.posicion.y < 0)
	       heroe.posicion.y = 0;
	   if(heroe.posicion.y > 480 - heroeImg.getRegionHeight())
	       heroe.posicion.y = 480 - heroeImg.getRegionHeight();
	   if(heroe.posicion.x < 0)
	       heroe.posicion.x = 0;
	   if(heroe.posicion.x > 800 - heroeImg.getRegionWidth())
	       heroe.posicion.x = 800 - heroeImg.getRegionWidth();
	   
	   if(daga != null && daga.posicion.x > 800)
	       daga = null;
	   
	   
	   for(int i=0; i < 10; i++) {
		  Personaje e = enemigo[i];
		  if(e == null)
		      continue;
		  if(e.posicion.y < 0)
		      e.velocidad.y = -e.velocidad.y;
		  if(e.posicion.y > 480  - esqueletoImg.getRegionHeight())
		      e.velocidad.y = -e.velocidad.y;
		  if(e.posicion.x < 0)
		      e.velocidad.x = -e.velocidad.x;
		  if(e.posicion.x > 800  + esqueletoImg.getRegionWidth())
		      e.velocidad.x = -e.velocidad.x;
		}
		
		// Se actualizan las máscaras
		for(int i=0; i < 10; i++) {
		  Personaje e = enemigo[i];
		  if(e == null)
		      continue;
		  e.actualizarMascara();
		}
		heroe.actualizarMascara();
		if(daga != null)
		  daga.actualizarMascara();
	   
	   // Se gestionan las colisiones
	   for(int i=0; i < 10; i++) {
		  Personaje e = enemigo[i];
		  if(e == null)
		      continue;
		  if(heroe.mascaraVital.overlaps(e.mascaraAtaque))
		      System.exit(0);
		  if(daga != null && e.mascaraVital.overlaps(daga.mascaraAtaque))
		      enemigo[i] = null;
		}
	
		Gdx.gl.glClearColor(0, 0, 0, 1);
		Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);
		batch.begin();
		heroe.dibujar(batch);
		if(daga != null)
		  daga.dibujar(batch);
		for(int i=0; i < 10; i++) {
		  Personaje e = enemigo[i];
		  if(e == null)
		      continue;
		  e.dibujar(batch);
		}
		batch.end();
	}
	
	@Override
	public void dispose () {
		batch.dispose();
		tesela.dispose();
	}
}
