package com.mygdx.game;

import com.badlogic.gdx.ApplicationAdapter;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.g2d.TextureRegion;


public class MyGdxGame extends ApplicationAdapter {
	SpriteBatch batch;
	Texture tesela;
	TextureRegion heroeImg,dagaImg,enemigoImg;
	Personaje heroe,daga;
	Personaje enemigo[][]=new Personaje[3][5];

	@Override
	public void create () {
		batch = new SpriteBatch();
		tesela=new Texture("tesela.png");

		heroeImg=new TextureRegion(tesela,112,91,17,20);
		dagaImg = new TextureRegion(tesela, 128, 101, 135-128, 111-101);
		enemigoImg = new TextureRegion(tesela, 115, 42, 17, 20);

		heroe=new Personaje(heroeImg);
		heroe.posicion.x=200;
		heroe.posicion.y=0;

		for (int f = 0; f <3 ; f++) {
			for (int c = 0; c <5 ; c++) {
				enemigo[f][c]=new Personaje(enemigoImg);
			}
		}
	}

	@Override
	public void render () {
		//Poner la velocidad a 0 siempre antes de entrar al IF
		heroe.velocidad.x=0;
		heroe.velocidad.y=0;

		if(Gdx.input.isKeyPressed(Input.Keys.RIGHT)){
			heroe.velocidad.x=100;
		}
		if(Gdx.input.isKeyPressed(Input.Keys.LEFT)){
			heroe.velocidad.x=-100;
		}
		if(Gdx.input.isKeyPressed(Input.Keys.SPACE)){
			if(daga==null){
				daga=new Personaje(dagaImg);
				daga.posicion.x=heroe.posicion.x;
				daga.posicion.y=heroe.posicion.y;
				daga.velocidad.y=200;
				daga.crearMascaraAtaque();
			}
		}
		float dt = Gdx.graphics.getDeltaTime();
		heroe.actualizarPosicion(dt);

		if(daga != null)
			daga.actualizarPosicion(dt);

		for (int f = 0; f <3 ; f++) {
			for (int c = 0; c < 5; c++) {
				Personaje e=enemigo[f][c];
				if(e==null)
					continue;
				e.actualizarPosicion(dt);
			}
		}

		if(heroe.posicion.x<0)
			heroe.posicion.x=0;
		if(heroe.posicion.x>400-heroeImg.getRegionHeight())
			heroe.posicion.y =400-heroeImg.getRegionHeight();

		if(daga != null && daga.posicion.x > 400)
			daga = null;

		for (int f = 0; f <3 ; f++) {
			for (int c = 0; c < 5; c++) {
				Personaje e = enemigo[f][c];
				if(e==null)
					continue;
				if(e.posicion.y < 0)
					e.velocidad.y = -e.velocidad.y;
				if(e.posicion.y > 400  - enemigoImg.getRegionHeight())
					e.velocidad.y = -e.velocidad.y;
				if(e.posicion.x < 0)
					e.velocidad.x = -e.velocidad.x;
				if(e.posicion.x > 400  + enemigoImg.getRegionWidth())
					e.velocidad.x = -e.velocidad.x;

			}
		}

		for (int f = 0; f <3 ; f++) {
			for (int c = 0; c < 5; c++) {
				Personaje e = enemigo[f][c];
				if(e == null)
					continue;
				e.actualizarMascara();
			}
		}
		heroe.actualizarMascara();
		if(daga != null)
			daga.actualizarMascara();


		for (int f = 0; f <3 ; f++) {
			for (int c = 0; c < 5; c++) {
			Personaje e = enemigo[f][c];
			if(e == null)
				continue;
			if(heroe.mascaraVital.overlaps(e.mascaraAtaque))
				System.exit(0);
			if(daga != null && e.mascaraVital.overlaps(daga.mascaraAtaque))
				enemigo[f][c] = null;
			}
		}

		Gdx.gl.glClearColor(0,0,0,1);
		Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);

		batch.begin();

		heroe.dibujar(batch);
		if(daga != null)
			daga.dibujar(batch);

		for (int f = 0; f <3 ; f++) {
			for (int c = 0; c <5 ; c++) {
				Personaje e = enemigo[f][c];
				if(e == null)
					continue;
				e.dibujar(batch);
			}
		}

		batch.end();
	}
	
	@Override
	public void dispose () {
		batch.dispose();
		tesela.dispose();
	}
}
