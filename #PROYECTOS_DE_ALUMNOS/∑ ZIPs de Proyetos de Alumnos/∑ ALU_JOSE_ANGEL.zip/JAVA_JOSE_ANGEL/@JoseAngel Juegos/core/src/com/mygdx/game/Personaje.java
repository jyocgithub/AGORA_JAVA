package com.mygdx.game;

import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.math.Rectangle;
import com.badlogic.gdx.math.Vector2;

public class Personaje {

    TextureRegion imagen;
    public Vector2 posicion, velocidad;
    public Rectangle mascaraVital, mascaraAtaque;

    Personaje(TextureRegion img) {
        this.imagen = img;
        posicion = new Vector2(0,0);
        velocidad = new Vector2(0,0);
        mascaraVital = new Rectangle(0,0, img.getRegionWidth(), img.getRegionHeight());
        crearMascaraAtaque();
    }

    void crearMascaraAtaque() {
        mascaraAtaque = new Rectangle(0,0, imagen.getRegionWidth(), imagen.getRegionHeight());
    }

    void dibujar(SpriteBatch batch) {
        batch.draw(imagen, posicion.x, posicion.y);
    }

    void actualizarPosicion(float dt) {
        velocidad.scl(dt);
        posicion.add(velocidad);
        velocidad.scl(1/dt);
    }

    void actualizarMascara() {
        mascaraVital.setPosition(posicion);
        if(mascaraAtaque != null)
            mascaraAtaque.setPosition(posicion);
    }
}
