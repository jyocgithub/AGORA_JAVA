package SAXSOLO;

import java.util.HashSet;

import org.xml.sax.Attributes;
import org.xml.sax.helpers.DefaultHandler;

public class MiManejador extends DefaultHandler {
	
	Banco banco;
	String etiquetaActual;
	Cuenta cuentaActual;
	Cliente clienteActual;
	
	public void startDocument() {
		banco=new Banco();
		System.out.println("Inicio documento");
	}
	public void endDocument() {
		
		System.out.println(banco);
	}

	public void startElement(String uri, String localName, String qName, Attributes atts) {
		etiquetaActual = qName;
		if(etiquetaActual.equals("cuenta")) {
			cuentaActual = new Cuenta(); 
		}
		if(etiquetaActual.equals("cliente")) {
			clienteActual = new Cliente(); 
		}
	}
	@Override
	public void endElement(String uri, String localName, String qName) { 
		if(qName.equals("cliente")){
			cuentaActual.getClientes().add(clienteActual);
		}
		if(qName.equals("cuenta")){
			banco.getCuentas().add(cuentaActual);
		}
	}
	public void characters(char[] ch, int start, int length) {
		String contenido = new String(ch, start, length);
		contenido = contenido.replaceAll("[\t\n]", "");

		if(contenido.isEmpty()) {
			return;
		}
		
		switch (etiquetaActual) {
		case "nombrebanco":
			banco.setNombre(contenido);
			break;
		case "dni":
			clienteActual.setDni(contenido);
			break;
		case "nombre":
			clienteActual.setNombre(contenido);
			break;
		case "edad":
			clienteActual.setEdad(Integer.parseInt(contenido));
			break;
		}
	}

	
	
	
}
