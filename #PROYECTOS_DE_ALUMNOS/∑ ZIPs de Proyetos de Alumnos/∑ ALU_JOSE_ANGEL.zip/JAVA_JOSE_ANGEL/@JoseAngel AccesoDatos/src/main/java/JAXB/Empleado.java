package JAXB;

import java.time.LocalDate;

import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;
import javax.xml.bind.annotation.XmlType;

import daw.com.Teclado;

@XmlRootElement
@XmlType (propOrder = { "nombre", "dept", "sueldo"})
public class Empleado {

	
	private String id;
	private String nombre;
	private String dept;
	private float sueldo;
	private LocalDate fechaNacimiento;
	

	
	
	public Empleado() 
	{
		this("","", "", 0,LocalDate.of(1980,1, 1));
	}

	public Empleado(String id, String nombre, String dept, float sueldo,LocalDate fechaNacimiento) 
	{
		this.id = id;
		this.nombre = nombre;
		this.dept = dept;
		this.sueldo = sueldo;
		this.fechaNacimiento = fechaNacimiento;
	}

	@XmlAttribute
	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getDept() {
		return dept;
	}

	public void setDept(String dept) {
		this.dept = dept;
	}

	public float getSueldo() {
		return sueldo;
	}

	public void setSueldo(float sueldo) {
		this.sueldo = sueldo;
	}
	
	//@XmlJavaTypeAdapter(LocalDateAdapter.class)
	@XmlTransient
	public LocalDate getFechaNacimiento() {
		return fechaNacimiento;
	}

	public void setFechaNacimiento(LocalDate fechaNacimiento) {
		this.fechaNacimiento = fechaNacimiento;
	}

	
	
	@Override
	public String toString() {
		return "Empleado [id=" + id + ", nombre=" + nombre + ", dept=" + dept + ", sueldo=" + sueldo
				+ ", fechaNacimiento=" + fechaNacimiento + "]";
	}

	public void leerEmpleado()
	{
		id = Teclado.leerString("ID");
		nombre = Teclado.leerString("NOMBRE");
		dept = Teclado.leerString("DEPT");
		sueldo = Teclado.leerFloat("SALARIO");
		// usa fomrato ISO año-mes-dia
		fechaNacimiento = LocalDate.parse(Teclado.leerString("FECHA NACIMIENTO"));
		
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Empleado other = (Empleado) obj;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		return true;
	}
	
	
	
}
