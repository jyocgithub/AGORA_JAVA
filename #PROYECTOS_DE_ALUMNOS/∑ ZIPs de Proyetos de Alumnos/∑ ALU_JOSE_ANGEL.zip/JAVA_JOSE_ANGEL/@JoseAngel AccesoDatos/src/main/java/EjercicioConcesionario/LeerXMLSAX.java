package EjercicioConcesionario;

import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import org.xml.sax.InputSource;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.DefaultHandler;

public class LeerXMLSAX {

	public static void main(String[]args) {
		
		try {
			
			SAXParserFactory factory=SAXParserFactory.newInstance();
			SAXParser parser=factory.newSAXParser();
			XMLReader xml=parser.getXMLReader();
			
			DefaultHandler gestor=new Manejador();
			
			xml.setContentHandler(gestor);
			
			InputSource ficheroXML=new InputSource("Concesionario.xml");
			
			xml.parse(ficheroXML);
			
			
		}catch(Exception e) {
			e.printStackTrace();
		}
	
		
	}
	
}
