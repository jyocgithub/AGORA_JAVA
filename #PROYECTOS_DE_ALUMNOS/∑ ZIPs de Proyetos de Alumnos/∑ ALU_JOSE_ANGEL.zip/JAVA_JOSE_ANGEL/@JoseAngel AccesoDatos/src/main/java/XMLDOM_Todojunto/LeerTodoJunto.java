package XMLDOM_Todojunto;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.*;
import org.xml.sax.SAXException;

import XMLDOM.Cliente;

public class LeerTodoJunto {

	public static void main(String[] args) throws ParserConfigurationException, SAXException, IOException {

		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		DocumentBuilder builder = factory.newDocumentBuilder();
		Document document = builder.parse(new File("Cuenta.xml"));

		document.getDocumentElement().normalize();

		ArrayList<Cliente> alistaClientes = new ArrayList<>();

		Node nodo_raiz = document.getDocumentElement(); // sacar del document el nodo raiz

		String nombreDelNodoRaiz = nodo_raiz.getNodeName(); // sacar el nombre del nodo raiz

		// cogemos los hijos directos de raiz

		// NODO NCC

		NodeList ncc_list = document.getElementsByTagName("ncc").item(0).getChildNodes();
		Node valornodo = ncc_list.item(0);
		String ncc = valornodo.getNodeValue();

		// NODO SALDO

		NodeList saldo_list = document.getElementsByTagName("saldo").item(0).getChildNodes();
		Node valorsaldo = saldo_list.item(0);
		String saldo = valorsaldo.getNodeValue();

		// NODO CLIENTE
		NodeList listaClientes = document.getElementsByTagName("cliente");

		for (int t = 0; t < listaClientes.getLength(); t++) {
			Node nodoCadaCliente = listaClientes.item(t);

			Element elem = (Element) nodoCadaCliente; // LOS METODOS SIGUIENTES SON DE ELEMENT, no vale node

			NodeList hijos1 = elem.getElementsByTagName("dni").item(0).getChildNodes();
			Node valorNodo = hijos1.item(0); // NODO CON EL TEXTO
			String dni = valorNodo.getNodeValue();

			NodeList hijos2 = elem.getElementsByTagName("nombre").item(0).getChildNodes();
			valorNodo = hijos2.item(0); // NODO CON EL TEXTO
			String nombre = valorNodo.getNodeValue();

			NodeList hijos3 = elem.getElementsByTagName("edad").item(0).getChildNodes();
			valorNodo = hijos3.item(0); // NODO CON EL TEXTO
			String edad = valorNodo.getNodeValue(); // getNodeValue devuelve siempreun string

			Cliente c = new Cliente(dni, nombre, Integer.parseInt(edad)); // edad necesita converrtisrse en int
			alistaClientes.add(c);
		}
		System.out.println(ncc);
		System.out.println(saldo);
		for (Cliente cc : alistaClientes) {
			System.out.println(cc);
		}

	}

}
