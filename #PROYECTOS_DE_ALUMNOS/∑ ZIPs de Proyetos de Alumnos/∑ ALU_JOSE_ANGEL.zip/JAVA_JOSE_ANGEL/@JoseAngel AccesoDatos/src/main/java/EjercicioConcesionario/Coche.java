package EjercicioConcesionario;

import daw.com.Teclado;

public class Coche {

	private String marca;
	private String modelo;
	private double cilindrada;
	
	public Coche() {
		
	}
	
	public Coche(String marca,String modelo,double cilindrada) {
		this.marca=marca;
		this.modelo=modelo;
		this.cilindrada=cilindrada;
	}

	public String getMarca() {
		return marca;
	}

	public void setMarca(String marca) {
		this.marca = marca;
	}

	public String getModelo() {
		return modelo;
	}

	public void setModelo(String modelo) {
		this.modelo = modelo;
	}

	public double getCilindrada() {
		return cilindrada;
	}

	public void setCilindrada(double cilindrada) {
		this.cilindrada = cilindrada;
	}
	
	
	public void leerCoche() {
		
		marca=Teclado.leerString("Marca");
		modelo=Teclado.leerString("Modelo");
		cilindrada=Teclado.leerFloat("Cilindrada");
		
	}

	@Override
	public String toString() {
		return "Coche [marca=" + marca + ", modelo=" + modelo + ", cilindrada=" + cilindrada + "]";
	}
	
	
}
	
