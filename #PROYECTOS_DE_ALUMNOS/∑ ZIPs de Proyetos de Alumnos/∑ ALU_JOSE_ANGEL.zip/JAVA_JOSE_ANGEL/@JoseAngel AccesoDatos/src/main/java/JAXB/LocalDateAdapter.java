package JAXB;

import java.time.LocalDate;

import javax.xml.bind.annotation.adapters.XmlAdapter;

public class LocalDateAdapter extends XmlAdapter <String, LocalDate> {

	@Override
	public LocalDate unmarshal(String v) throws Exception {
		LocalDate.parse(v);
		return null;
	}

	@Override
	public String marshal(LocalDate v) throws Exception {
		v.toString();
		return null;
	}
	

}
