package EjercicioConcesionario;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@XmlRootElement(name="concesionario")
@XmlType(propOrder = {  "coches" })
public class Concesionario {

	private Set<Coche>coches;

	public Concesionario() {
		coches=new HashSet<>();
	}

	public Set<Coche> getCoches() {
		return coches;
	}

	public void setCoches(Set<Coche> coches) {
		this.coches = coches;
	}

	public Concesionario(Set<Coche> coches) {
	
		this.coches = coches;
	}

	public String toString() {
		String res="Coches:\n ";
		for(Coche cc:coches) {
			res=res+cc.toString()+"\n";
		}
		return res;
	}
	
}
