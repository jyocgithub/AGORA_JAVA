package SAXSOLO;

import java.util.ArrayList;
import java.util.List;

public class Cuenta {

	private List<Cliente> clientes;

	public Cuenta() {
         clientes=new ArrayList<>();
	}

	public Cuenta(List<Cliente> clientes) {
		this.clientes = clientes;

	}

	public List<Cliente> getClientes() {
		return clientes;
	}

	public void setClientes(List<Cliente> clientes) {
		this.clientes = clientes;
	}

	@Override
	public String toString() {
		String res = "UNA CUENTA:\n";
		for(Cliente cli : clientes) {
			res = res + cli.toString()+"\n";
		}
		return res;

	}
	
	
	
}
