package JSONEjercicio1;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import com.google.gson.Gson;

import daw.com.Teclado;

public class EscribirJSON {

	public static void main(String[] args) throws FileNotFoundException {
		
		Gson gson=new Gson();
		
		String json;
		
		List<Cliente>clientes=new ArrayList<>();
		
		String res;
		
		do {
			Cliente cli=new Cliente();
			cli.leerCliente();
			 res=Teclado.leerString("Introducir otro Cliente(S/N)");
			clientes.add(cli);
		}while(res.equals("S"));
		
		json=gson.toJson(clientes);
		
		PrintWriter fichero=new PrintWriter(new File("clientes.json"));
		gson.toJson(clientes,fichero);
		fichero.close();
		System.out.println(json);
	}

}
