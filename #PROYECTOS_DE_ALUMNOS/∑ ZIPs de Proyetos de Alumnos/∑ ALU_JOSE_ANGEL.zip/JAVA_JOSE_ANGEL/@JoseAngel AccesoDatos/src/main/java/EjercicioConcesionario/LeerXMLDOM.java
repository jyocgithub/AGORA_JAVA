package EjercicioConcesionario;

import java.io.File;
import java.util.HashSet;
import java.util.Set;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class LeerXMLDOM {

	public static void main(String[] args) {

		Set<Coche> coches = new HashSet<>();

		try {

			DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
			DocumentBuilder builder = factory.newDocumentBuilder();
			Document documento = builder.parse(new File("Concesionario.xml"));

			documento.getDocumentElement().normalize();

			NodeList listacoches = documento.getElementsByTagName("coche");

			for (int i = 0; i < listacoches.getLength(); i++) {

				Node ncoches = listacoches.item(i);
				
				if(ncoches.getNodeType() == Node.ELEMENT_NODE) {
					Element eElement = (Element) ncoches;
					System.out.println("\nCoche id: " + eElement.getAttribute("id"));
					System.out.println("Marca: "
					+
					eElement.getElementsByTagName("marca").item(0).getTextContent());
					System.out.println("Modelo: "
					+
					eElement.getElementsByTagName("modelo").item(0).getTextContent());
					System.out.println("Cilindrada: "
					+
					eElement.getElementsByTagName("cilindrada").item(0).getTextContent());
					}
				
			/*	
				Element elem=(Element) ncoches;
				
				elem.getAttribute("id");

				NodeList nodomarca = elem.getElementsByTagName("marca").item(0).getChildNodes();
				Node valormarca = nodomarca.item(0);
				String marca = valormarca.getNodeValue();

				NodeList nodomodelo = elem.getElementsByTagName("modelo").item(0).getChildNodes();
				Node valormodelo = nodomodelo.item(0);
				String modelo = valormodelo.getNodeValue();

				NodeList nodocil = elem.getElementsByTagName("cilindrada").item(0).getChildNodes();
				Node valorcil = nodocil.item(0);
				String cilindrada = valorcil.getNodeValue();

				Coche c = new Coche(marca, modelo, Double.parseDouble(cilindrada));
				coches.add(c);
			}
*/
			for(Coche cc:coches) {
				System.out.println(cc);
			}
			
			Concesionario conce=new Concesionario(coches);
			
		} 
		}catch (Exception e) {
			e.printStackTrace();
		}
	}
}
