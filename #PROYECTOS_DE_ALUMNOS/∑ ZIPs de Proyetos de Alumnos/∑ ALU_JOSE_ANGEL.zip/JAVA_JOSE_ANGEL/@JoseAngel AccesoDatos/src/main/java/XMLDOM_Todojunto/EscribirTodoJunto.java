package XMLDOM_Todojunto;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.*;
import org.xml.sax.SAXException;

import XMLDOM.Cliente;

public class EscribirTodoJunto {
	public static void main(String[] args) {

		ArrayList<Cliente> alistaClientes = new ArrayList<>();
		// AQUI DEBERIA ESTRAR LLENA

		try {
			Document document; // Objeto Document que almacena el DOM del XML seleccionado.

			DocumentBuilderFactory builderFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder builder = builderFactory.newDocumentBuilder();
			DOMImplementation implementation = builder.getDOMImplementation();

			document = implementation.createDocument(null, "cuenta", null);

			// -- Crear los nodos de todas las etiquetas generales
			Node nodo_raiz = document.getDocumentElement();

			// Creo nodo ncc
			Node ncc = document.createElement("ncc");
			Node ncc_text = document.createTextNode(ncc.getNodeValue());
			ncc.appendChild(ncc_text);

			// Creo nodo saldo
			Node saldo = document.createElement("saldo");
			Node saldo_text = document.createTextNode(ncc.getNodeValue());
			saldo.appendChild(saldo_text);

			// recorrer el arraylist de clientes
			for (Cliente cli : alistaClientes) {

				// -- Crear los nodos de todas las etiquetas del cliente
				Node nodo_cliente = document.createElement("cliente");

				Node nodo_dni = document.createElement("dni");
				Node nodo_nombre = document.createElement("nombre");
				Node nodo_edad = document.createElement("edad");

				// -- Crear los nodos de texto con los valores de cada cliente
				Node nodo_dni_texto = document.createTextNode(cli.getDni());
				Node nodo_nombre_texto = document.createTextNode(cli.getNombre());
				Node nodo_edad_texto = document.createTextNode(cli.getEdad() + "");

				// -- Añadir cada nodo a su padre

				nodo_dni.appendChild(nodo_dni_texto);
				nodo_nombre.appendChild(nodo_nombre_texto);
				nodo_edad.appendChild(nodo_edad_texto);

				// Añadir al nodo padre

				nodo_cliente.appendChild(nodo_dni);
				nodo_cliente.appendChild(nodo_nombre);
				nodo_cliente.appendChild(nodo_edad);

				// -- Añadir cada nodo al raíz

				nodo_raiz.appendChild(nodo_cliente);
				nodo_raiz.appendChild(ncc);
				nodo_raiz.appendChild(saldo);

			}

		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
