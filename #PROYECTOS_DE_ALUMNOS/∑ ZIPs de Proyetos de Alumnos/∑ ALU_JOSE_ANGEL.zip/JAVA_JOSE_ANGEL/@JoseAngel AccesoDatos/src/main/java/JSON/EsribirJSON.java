package JSON;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import com.google.gson.Gson;

public class EsribirJSON {

	public static void main(String[] args) throws FileNotFoundException {
		// TODO Auto-generated method stub

		Gson gson = new Gson();
		String json;
		List<Empleado> empleados = new  ArrayList<>();
		
		
		Empleado e = new Empleado();
		e.leerEmpleado();
		
		json = gson.toJson(e);
		
		empleados.add(e);
		
		PrintWriter fichero=new PrintWriter(new File("empleados.json"));
		 gson.toJson(empleados,fichero);
		 fichero.close();
		
		json=gson.toJson(empleados);
		System.out.println(json);
		
	}
	
}
