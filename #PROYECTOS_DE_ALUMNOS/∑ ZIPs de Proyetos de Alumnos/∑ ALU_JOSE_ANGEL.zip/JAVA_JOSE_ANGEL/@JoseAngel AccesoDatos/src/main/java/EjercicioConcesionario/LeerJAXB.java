package EjercicioConcesionario;

import java.io.File;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;

import JAXB.Empleado;
import JAXB.Empleados;

public class LeerJAXB {

	public static void main(String[] args) {
		
		try {
			JAXBContext context = JAXBContext.newInstance(Concesionario.class);
			Unmarshaller ums = context.createUnmarshaller();

			Concesionario conce = (Concesionario) ums.unmarshal(new File("Concesionario.xml"));

			for (Coche c : conce.getCoches()) {
				System.out.println(c.toString());
			}
		} catch (JAXBException e) {
			e.printStackTrace();
		}

	}

}
