package EjercicioConcesionario;

import org.xml.sax.Attributes;
import org.xml.sax.helpers.DefaultHandler;

public class Manejador extends DefaultHandler {

	Concesionario conce;
	String elementoactual;
	Coche coche;
	

	public void startDocument() {
		conce = new Concesionario();
		System.out.println("Inicio Documento XML");
	}

	public void endDocument() {
		System.out.println(conce);
	}

	public void startElement(String uri, String localName, String qname, Attributes atts) {

		elementoactual = qname;

		if (elementoactual.equals("coche")) {
			coche = new Coche();
		}

	}
	@Override
	public void endElement(String uri,String localName,String qname) {
		
		if(qname.equals("coche")) {
			conce.getCoches().add(coche);
		}
	
	}
	
	public void characters(char[]ch,int start,int length) {
		String contenido = new String(ch, start, length);
		contenido = contenido.replaceAll("[\t\n]", "");
		
		if(contenido.isEmpty()) {
			return;
		}
	
		switch(elementoactual) {
		
		case "marca":
			coche.setMarca(contenido);break;
		
		case "modelo":
			coche.setModelo(contenido);break;
			
		case "cilindrada":
			coche.setCilindrada(Double.parseDouble(contenido));break;
		}
	
	
	}
	

}
