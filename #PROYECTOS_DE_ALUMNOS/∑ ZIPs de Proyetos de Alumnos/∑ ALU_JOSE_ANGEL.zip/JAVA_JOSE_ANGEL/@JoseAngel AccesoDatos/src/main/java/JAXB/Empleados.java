package JAXB;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@XmlRootElement(name = "empresa")
@XmlType(propOrder = { "nombreEmpresa", "lista" })
public class Empleados {

	private List<Empleado> lista;
	private String nombreEmpresa;

	public Empleados() {
		lista = new ArrayList<>();
		nombreEmpresa = "";
	}

	@XmlElementWrapper(name = "empleados")
	@XmlElement(name = "empleado")
	public List<Empleado> getLista() {
		return lista;
	}

	public void setLista(List<Empleado> lista) {
		this.lista = lista;
	}

	public String getNombreEmpresa() {
		return nombreEmpresa;
	}

	public void setNombreEmpresa(String nombreEmpresa) {
		this.nombreEmpresa = nombreEmpresa;
	}

}
