import java.util.ArrayList;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "cartelera")
public class Cartelera {
	private ArrayList<Pelicula> peliculas;

	public Cartelera(ArrayList<Pelicula> peliculas) {
		this.peliculas = peliculas;
	}

	public Cartelera() {
	}

	@Override
	public String toString() {
		String lista_de_peliculas = "";
		for (Pelicula peli : peliculas) {
			lista_de_peliculas += "\n" + peli;
		}

		return "Cartelera{" + "peliculas=" + lista_de_peliculas + '}';
	}

	@XmlElement(name = "pelicula")
	public ArrayList<Pelicula> getPeliculas() {
		return peliculas;
	}

	public void setPeliculas(ArrayList<Pelicula> peliculas) {
		this.peliculas = peliculas;
	}

}
