import java.util.ArrayList;

import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;

public class Pelicula {

	private String codigo;
	private int duracion;
	private String fecha;
	private String titulo;
	private String titulo_original;
	private String nacionalidad;
	private String genero;
	private String calificacion_edad;
	private String sinopsis;
	private String director;
	private String web;
	private String cartel;

	ArrayList<String> reparto;

	public Pelicula(String codigo, int duracion, String fecha, String titulo, String titulo_original,
			String nacionalidad, String genero, String calificacion_edad, String sinopsis, String director, String web,
			String cartel, ArrayList<String> reparto) {
		this.codigo = codigo;
		this.duracion = duracion;
		this.fecha = fecha;
		this.titulo = titulo;
		this.titulo_original = titulo_original;
		this.nacionalidad = nacionalidad;
		this.genero = genero;
		this.calificacion_edad = calificacion_edad;
		this.sinopsis = sinopsis;
		this.director = director;
		this.web = web;
		this.cartel = cartel;
		this.reparto = reparto;
	}

	public Pelicula() {
	}

	@Override
	public String toString() {

		String lista_de_reparto = "";
		for (String unActor : reparto) {
			lista_de_reparto += "\n" + unActor;
		}

		return "Pelicula{" + "codigo='" + codigo + '\'' + ", duracion=" + duracion + ", fecha='" + fecha + '\''
				+ ", titulo='" + titulo + '\'' + ", titulo_original='" + titulo_original + '\'' + ", nacionalidad='"
				+ nacionalidad + '\'' + ", genero='" + genero + '\'' + ", calificacion_edad='" + calificacion_edad
				+ '\'' + ", sinopsis='" + sinopsis + '\'' + ", director='" + director + '\'' + ", web='" + web + '\''
				+ ", cartel='" + cartel + '\'' + ", reparto=" + lista_de_reparto + '}';
	}

	@XmlAttribute(name = "codigo")
	public String getCodigo() {
		return codigo;
	}

	public void setCodigo(String codigo) {
		this.codigo = codigo;
	}

	@XmlAttribute
	public int getDuracion() {
		return duracion;
	}

	public void setDuracion(int duracion) {
		this.duracion = duracion;
	}

	@XmlAttribute
	public String getFecha() {
		return fecha;
	}

	public void setFecha(String fecha) {
		this.fecha = fecha;
	}

	@XmlElement(name = "titulo")
	public String getTitulo() {
		return titulo;
	}

	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}

	public String getTitulo_original() {
		return titulo_original;
	}

	public void setTitulo_original(String titulo_original) {
		this.titulo_original = titulo_original;
	}

	public String getNacionalidad() {
		return nacionalidad;
	}

	public void setNacionalidad(String nacionalidad) {
		this.nacionalidad = nacionalidad;
	}

	public String getGenero() {
		return genero;
	}

	public void setGenero(String genero) {
		this.genero = genero;
	}

	public String getCalificacion_edad() {
		return calificacion_edad;
	}

	public void setCalificacion_edad(String calificacion_edad) {
		this.calificacion_edad = calificacion_edad;
	}

	public String getSinopsis() {
		return sinopsis;
	}

	public void setSinopsis(String sinopsis) {
		this.sinopsis = sinopsis;
	}

	public String getDirector() {
		return director;
	}

	public void setDirector(String director) {
		this.director = director;
	}

	public String getWeb() {
		return web;
	}

	public void setWeb(String web) {
		this.web = web;
	}

	public String getCartel() {
		return cartel;
	}

	public void setCartel(String cartel) {
		this.cartel = cartel;
	}

	@XmlElementWrapper(name = "reparto")
	@XmlElement(name = "actor")
	public ArrayList<String> getReparto() {
		return reparto;
	}

	public void setReparto(ArrayList<String> reparto) {
		this.reparto = reparto;
	}
}
