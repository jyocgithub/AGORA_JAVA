import org.w3c.dom.*;
import org.xml.sax.SAXException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;

public class EjemploExamen_Cartelera_DOM {

    public static void main(String[] args) {
        try {
            leerConDom();
        } catch (ParserConfigurationException e) {
            e.printStackTrace();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (SAXException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    public static void leerConDom() throws ParserConfigurationException, IOException, SAXException {
        Document document = null;
        DocumentBuilderFactory builderFactory = DocumentBuilderFactory.newInstance();
        DocumentBuilder builder = builderFactory.newDocumentBuilder();
        document = builder.parse(new FileInputStream("cartelera.xml"));

        ArrayList<Pelicula> peliculas = new ArrayList<>();

        Element nodo_raiz = document.getDocumentElement();      // sacar del document el nodo raiz
        String nombreDelNodoRaiz = nodo_raiz.getNodeName();  // sacar el nombre del nodo raiz

        // cogemos los hijos directos de raiz
        NodeList listaHijosPelicula = nodo_raiz.getElementsByTagName("pelicula");

        for (int t = 0; t < listaHijosPelicula.getLength(); t++) {

            Node nPelicula = listaHijosPelicula.item(t);

            String codigo = getValorAtributo("codigo", nPelicula);
            String duracion = getValorAtributo("duracion", nPelicula);
            String fecha = getValorAtributo("fecha", nPelicula);

            String titulo = getValorNodoHijoSimple("titulo", nPelicula);
            String titulo_original = getValorNodoHijoSimple("titulo_original", nPelicula);
            String nacionalidad = getValorNodoHijoSimple("nacionalidad", nPelicula);
            String genero = getValorNodoHijoSimple("genero", nPelicula);
            String sinopsis = getValorNodoHijoSimple("sinopsis", nPelicula);
            String director = getValorNodoHijoSimple("director", nPelicula);
            String web = getValorNodoHijoSimple("web", nPelicula);
            String cartel = getValorNodoHijoSimple("cartel", nPelicula);

            Element ePelicula = (Element)nPelicula;
            Node nClasificacion = ePelicula.getElementsByTagName("clasificacion").item(0);
            String calificacion_edad = getValorAtributo("edad", nClasificacion);

            // cogemos los hijos directos de reparto
            Node nReparto = ePelicula.getElementsByTagName("reparto").item(0);
            NodeList listaActores = ((Element)nReparto).getElementsByTagName("actor");

            ArrayList<String> reparto = new ArrayList<>();

            for (int k = 0; k < listaActores.getLength(); k++) {
                Node nActor = listaActores.item(k);
                String actor =getValorNodo(nActor);
                reparto.add(actor);
            }

            Pelicula p = new Pelicula(codigo,
                    Integer.parseInt(duracion),
                    fecha,
                    titulo,
                    titulo_original,
                    nacionalidad,
                    genero,
                    calificacion_edad,
                    sinopsis,
                    director,
                    web, cartel, reparto);

            peliculas.add(p);

        }

        Cartelera c = new Cartelera(peliculas);
        System.out.println(c);

    }


    public static String getValorNodoHijoSimple(String etiquetaABuscar, Element elementoPadre) {
        String resultado = "";
        // sacar una lista de todos los nodo-etiqueta que se llame "etiquetaABuscar" y sea hijo de "elementoPadre"
        // con el ejemplo, esto da una lista de elementos <nombre>
        NodeList listaNodosHijos = elementoPadre.getElementsByTagName(etiquetaABuscar);
        // sacar el unico nodo-etiqueta que tiene esa lista (se sabe que el nodo es simple)
        // con el ejemplo, esto da el unico elemento <nombre> que existe
        Node nodo = listaNodosHijos.item(0);
        // sacar del nodo-etiqueta su único hijo, que es el CONTENIDO de la etiqueta (que sigue siendo un nodo...)
        // en el ejemplo, es Pepe, pero con formato de nodo
        if (nodo != null) {
            Node contenido = nodo.getFirstChild();
            // sacar del nodo-contenido su valor
            // en el ejemplo, ahora si, la cadena "Pepe"
            resultado = contenido.getNodeValue();
        }
        return resultado;
    }

    public static String getValorNodo( Node nodo) {
        String resultado = "";
        if (nodo != null) {
            Node contenido = nodo.getFirstChild();
            // sacar del nodo-contenido su valor
            // en el ejemplo, ahora si, la cadena "Pepe"
            resultado = contenido.getNodeValue();
        }
        return resultado;
    }

    public static String getValorNodoHijoSimple(String etiquetaABuscar, Node nodoPadre) { // Version sobrecargada, con Node en vez de Element
        Element elementoPadre = (Element) nodoPadre;
        return getValorNodoHijoSimple(etiquetaABuscar, elementoPadre);
    }

    public static String getValorAtributo(String atributoABuscar, Node nodoPadre) {
        String resultado = "";
        NamedNodeMap nnm = nodoPadre.getAttributes();
        Node attr = nnm.getNamedItem(atributoABuscar);
        if (attr != null) {
            resultado = attr.getNodeValue();
        }
        return resultado;
    }



}
