import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.XMLReaderFactory;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

public class EjemploExamen_Cartelera_JAXB {



    public static void main(String[] args) {

        try {
            JAXBContext jaxbContext = JAXBContext.newInstance(Cartelera.class);

            File file = new File("Cartelera.xml");

            Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();
            Cartelera cart = (Cartelera) jaxbUnmarshaller.unmarshal(file);


            System.out.println(cart);

        } catch (JAXBException e) {
            e.printStackTrace();
        }

    }


}
