import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

import java.util.ArrayList;

public class MiHandlerSax extends DefaultHandler {

    ArrayList<Pelicula> peliculas;
    ArrayList<String> actores ;
    Cartelera cartelera;
    Pelicula pelicula;
    String etiquetaActual = "";
//    boolean estamosDentroDeReparto = false;


    @Override
    public void startElement(String uri, String localName, String qname, Attributes attributes) throws SAXException {
        // debemos guardarnos qué etiqueta estamos leyendo en cada momento
        etiquetaActual = qname;

        switch(etiquetaActual){

            case "pelicula":
                pelicula = new Pelicula();
                String codigo = attributes.getValue("codigo");
                String duracion = attributes.getValue("duracion");
                String fecha = attributes.getValue("fecha");
                pelicula.setCodigo(codigo);
                pelicula.setDuracion( Integer.parseInt(duracion));
                pelicula.setFecha(fecha);
                break;
            case "reparto":
                actores = new ArrayList<>();
//                estamosDentroDeReparto = true;
                break;
        }
    }

    @Override
    public void characters(char[] ch, int start, int length) throws SAXException {
        // aqui entra en cuanto empieza a leerse un texo dentro de una etiqueta,
        // sabemos que etiqueta estamos leyendo, asi que cogemos el texto...
        String texto = new String(ch, start, length);
        texto.replaceAll("\n\t","");
        if(texto.isEmpty()){
            return;
        }
        // y lo asignamos al atributo del alumno que corresponde...
        if (etiquetaActual.equalsIgnoreCase("titulo")) {
            pelicula.setTitulo(texto);
        }
        if (etiquetaActual.equalsIgnoreCase("director")) {
            pelicula.setDirector(texto);
        }
        // añadir el resto de campos simples..-.........

        // vamoas a ver como leer varios actores:
        if (etiquetaActual.equalsIgnoreCase("actor")) {
            actores.add(texto);
        }
    }

    @Override
    public void endElement(String uri, String localName, String name) { // aqui entra en cuanto se leer una etiqueta de fin
        if (name.equalsIgnoreCase("pelicula")) {
            peliculas.add(pelicula);
        }
        if (name.equalsIgnoreCase("cartelera")) {
            cartelera.setPeliculas(peliculas);
        }
        if (name.equalsIgnoreCase("reparto")) {
//            estamosDentroDeReparto = false;
            pelicula.setReparto(actores);
        }
        etiquetaActual = "";
    }


    @Override
    public void startDocument() throws SAXException {         // esto se ejecuta al comenzar a leer el documento.
        cartelera = new Cartelera();
        peliculas = new ArrayList<>();
    }

    @Override
    public void endDocument() throws SAXException {         // esto se ejecuta al finalizar de leer el documento
        System.out.println(cartelera);
    }

}
