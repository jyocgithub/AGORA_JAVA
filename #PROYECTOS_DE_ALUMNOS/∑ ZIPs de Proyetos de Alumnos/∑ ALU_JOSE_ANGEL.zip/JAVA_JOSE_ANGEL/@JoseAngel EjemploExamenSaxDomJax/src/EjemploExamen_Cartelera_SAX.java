import org.w3c.dom.Document;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.XMLReaderFactory;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

public class EjemploExamen_Cartelera_SAX {



    public static void main(String[] args) {
        try {
            MiHandlerSax miHandler = miHandler = new MiHandlerSax();
            // Creamos un analizador de XML con una fábrica de analizadores
            XMLReader xmlreader = XMLReaderFactory.createXMLReader();
            // Añadimos nuestro handler al analizador
            xmlreader.setContentHandler(miHandler);
            // Analizamos con el analizador el xml deseado
            xmlreader.parse(new InputSource(new FileInputStream("cartelera.xml")));

        } catch (SAXException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }


}
