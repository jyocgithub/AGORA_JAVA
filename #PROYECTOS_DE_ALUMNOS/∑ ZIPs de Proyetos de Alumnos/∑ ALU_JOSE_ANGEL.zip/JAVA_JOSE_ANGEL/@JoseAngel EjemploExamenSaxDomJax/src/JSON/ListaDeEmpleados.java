package JSON;

import java.util.List;

import com.google.gson.reflect.TypeToken;

public class ListaDeEmpleados  extends TypeToken <List<Empleado>>{
	
	public ListaDeEmpleados ()
	{
		
	}

}
