package JSON;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

public class LeerJSONSinBean {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String unElemento = "{\"id\":\"001\",\"nombre\":\"Miguel\",\"dept\":\"007\",\"sueldo\":\"5000\"}";
		
		String unArray ="[{\"id\":\"001\",\"nombre\":\"Miguel\",\"dept\":\"007\",\"sueldo\":\"5000\"}"+
		",{\"id\":\"002\",\"nombre\":\"Luis\",\"dept\":\"003\",\"sueldo\":\"1300\"}]\r\n";
		
		JsonParser parser = new JsonParser();
		
		
		
		// leer un elemento
		JsonElement elementObject = parser.parse(unElemento);
		JsonObject object = elementObject.getAsJsonObject(); 
		
		String nombre = object.get("nombre").getAsString();
		
		System.out.println(nombre);
		
		
		// Leer un array
		JsonElement elementArray = parser.parse(unArray);
		JsonArray objectArray = elementArray.getAsJsonArray(); 
		
		
		for (int i = 0; i < objectArray.size(); i++)
		{
			JsonElement unElementoJson = objectArray.get(i);
			JsonObject unObject = unElementoJson.getAsJsonObject();
			float sueldo = unObject.get("sueldo").getAsFloat();
			nombre = unObject.get("nombre").getAsString();
			System.out.println(nombre + "->" + sueldo);
		}
		
		/*
		for (JsonElement unElementoJson : objectArray)
		{
			JsonObject unObject = unElementoJson.getAsJsonObject();
			float sueldo = unObject.get("sueldo").getAsFloat();
			nombre = unObject.get("nombre").getAsString();
			System.out.println(nombre + "->" + sueldo);
		}
		*/
	}

}
