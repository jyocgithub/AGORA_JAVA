package JSON;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import com.google.gson.Gson;

public class Jyoc_JSON {

	public static void main(String[] args) throws FileNotFoundException {

		// CREAR UN JSON DESDE OBJETOS JAVA

		// creamos empleados
		Empleado emp1 = new Empleado("23", "Pepe", "Compras", 12000.20f);
		Empleado emp2 = new Empleado("23", "Pepe", "Compras", 12000.20f);
		// metemos los empleados en una lista
		List<Empleado> empleados = new ArrayList<>();
		empleados.add(emp1);
		empleados.add(emp2);

		// Crear un objeto JSON
		Gson miGson = new Gson();
		// crear un JSON de un unico empleado
		String empleadoEnJson = miGson.toJson(emp1);

		// crear un JSON de una lista de empleados
		String listDeEmpleadosEnJson = miGson.toJson(empleados);
		System.out.println(listDeEmpleadosEnJson);

		// Idem de antes, pero escribiendo el json en un fichero
		PrintWriter fichero = new PrintWriter(new File("empleados.json"));
		miGson.toJson(empleados, fichero);
		fichero.close();

		// LEER UN JSON Y CREAR OBJETOS JAVA

		Empleado libroRecuperado = miGson.fromJson(empleadoEnJson, Empleado.class);

	}
}
