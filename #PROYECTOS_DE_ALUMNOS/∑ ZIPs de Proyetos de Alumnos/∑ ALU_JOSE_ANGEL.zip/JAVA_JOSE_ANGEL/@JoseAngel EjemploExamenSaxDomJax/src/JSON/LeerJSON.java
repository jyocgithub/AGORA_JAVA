package JSON;

import java.util.ArrayList;
import java.util.List;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

public class LeerJSON {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String json = "{\"id\":\"001\",\"nombre\":\"miguel\",\"dept\":\"002\",\"sueldo\":23432.0}";
		String json1 = "[{\"id\":\"001\",\"nombre\":\"miguel\",\"dept\":\"002\",\"sueldo\":23432.0}]";

		Gson gson = new Gson(); //Construyo el objeto
		
		Empleado e;
		
		List<Empleado> empleados = new ArrayList<>(); 
		
		e = gson.fromJson(json, Empleado.class); //Parseamos el json y lo convertimos a objeto
		
		
		System.out.println(e.toString());
		
		TypeToken<List<Empleado>> listaDeEmpleados = new TypeToken<List<Empleado>>() {}; //Empaqueta la lista de empleados
		
		//ListaDeEmpleados listaDeEmpleados = new ListaDeEmpleados(); // Tb puedo crear una clase ListaDeEmpleados
		
		empleados = gson.fromJson(json1, listaDeEmpleados.getType());
		
		
		//System.out.println(empleados.toString());
		
		for (Empleado emp: empleados)
			System.out.println(emp.toString());
		
	}

}
