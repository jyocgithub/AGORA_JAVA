package JSON;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import com.google.gson.Gson;

public class EsribirJSON {

	public static void main(String[] args) throws FileNotFoundException {
		// creamos empleados
		Empleado emp1 = new Empleado("23", "Pepe", "Compras", 12000.20f);
		Empleado emp2 = new Empleado("23", "Pepe", "Compras", 12000.20f);
		// metemos los empleados en una lista
		List<Empleado> empleados = new ArrayList<>();
		empleados.add(emp1);
		empleados.add(emp2);

		// Crear un objeto JSON
		Gson gson = new Gson();
		// crear un JSON de un unico empleado
		String empleadoEnJson = gson.toJson(emp1);

		// crear un JSON de una lista de empleados
		String listDeEmpleadosEnJson = gson.toJson(empleados);
		System.out.println(listDeEmpleadosEnJson);

		// Idem de antes, pero escribiendo el json en un fichero
		PrintWriter fichero = new PrintWriter(new File("empleados.json"));
		gson.toJson(empleados, fichero);
		fichero.close();

	}

}
