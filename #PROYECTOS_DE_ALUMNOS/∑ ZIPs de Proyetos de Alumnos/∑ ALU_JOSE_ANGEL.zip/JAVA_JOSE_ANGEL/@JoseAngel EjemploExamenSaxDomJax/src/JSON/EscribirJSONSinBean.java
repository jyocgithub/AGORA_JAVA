package JSON;

import java.util.Date;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;

public class EscribirJSONSinBean {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		
		// Escribir un objeto
		JsonObject object = new JsonObject();
		object.addProperty("id", "001");
		object.addProperty("nombre", "Miguel");
		object.addProperty("dept", "007");
		object.addProperty("sueldo",String.valueOf(5000));

		String json = object.toString();
		
		System.out.println(json);
		
		
		// Escribir un array de objetos
		JsonArray array = new JsonArray();
		
		JsonObject object1 = new JsonObject();
		object1.addProperty("id", "001");
		object1.addProperty("nombre", "Miguel");
		object1.addProperty("dept", "007");
		object1.addProperty("sueldo",String.valueOf(5000));
		array.add(object1); // JsonPrimitive, JsonObject o JsonArray
		
		JsonObject object2 = new JsonObject();
		object2.addProperty("id", "002");
		object2.addProperty("nombre", "Luis");
		object2.addProperty("dept", "003");
		object2.addProperty("sueldo",String.valueOf(1300));
		array.add(object2);

		String jsonArray = array.toString();
		
		System.out.println(jsonArray);
		
	}

}
