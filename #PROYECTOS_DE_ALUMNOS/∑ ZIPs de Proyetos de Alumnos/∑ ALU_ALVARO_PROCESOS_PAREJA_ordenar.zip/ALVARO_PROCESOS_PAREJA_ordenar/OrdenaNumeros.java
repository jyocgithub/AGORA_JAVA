import java.util.*;

public class OrdenaNumeros {


    public static void main(String[] args) {

        Scanner entrada = new Scanner(System.in);
        int n;
        ArrayList<Integer> lista = new ArrayList<>();


        for (int i = 0; i < 10; i++) {
            n = entrada.nextInt();
            lista.add(n);
            System.out.println("Recibido " + n);
        }

        System.out.println("ordenamos......");
        Collections.sort(lista) ;

        for (Integer num : lista) {
            System.out.println(" -->  " + num);
        }
    }


}
