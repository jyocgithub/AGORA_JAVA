package practica2eval.dao;

import org.hibernate.NonUniqueObjectException;
import org.hibernate.exception.ConstraintViolationException;

import practica2eval.dao.exception.ExcepcionDAO;
import practica2eval.dao.exception.MensajeError;
import practica2eval.dao.exception.TipoProblemaDAO;
import practica2eval.model.Articulo;
import practica2eval.model.LineaPedido;
import practica2eval.model.Pedido;

public class LineaPedidoDAO extends DAO
{
	public void insertarLineaPedido(LineaPedido lineaPedido)
	{
		abrirSesion();

		Pedido pedido = session.bySimpleNaturalId(Pedido.class).load(lineaPedido.getPedido().getCodigoPedido());
		Articulo articulo = session.bySimpleNaturalId(Articulo.class).load(lineaPedido.getArticulo().getCodigo());

		pedido.anadirLineaPedido(lineaPedido);
		articulo.anadirLineaPedido(lineaPedido);

		try
		{
			session.save(lineaPedido);
			session.update(pedido);
			session.update(articulo);

			cerrarSesion();
		}
		catch (NonUniqueObjectException e)
		{
			throw new ExcepcionDAO(MensajeError.getMensaje(TipoProblemaDAO.ERROR_DE_CLAVE_UNICA));
		}

	}

	public void eliminarLineaPedido(Pedido pedido, Articulo articulo)
	{
		abrirSesion();
		Pedido p = session.bySimpleNaturalId(Pedido.class).load(pedido.getCodigoPedido());
		Articulo a = session.bySimpleNaturalId(Articulo.class).load(articulo.getIdArticulo());

		LineaPedido lp = new LineaPedido();
		LineaPedido lineaPedido = session.get(LineaPedido.class, lp.setId(pedido, articulo));

		try
		{
			session.delete(lineaPedido);
			cerrarSesion();
		}
		catch (NullPointerException e)
		{
			throw new ExcepcionDAO(MensajeError.getMensaje(TipoProblemaDAO.ERROR_REGISTRO_NULO_O_INEXISTENTE));
		}
	}

	public void modificarLineaPedido(Pedido pedido, Articulo articulo, LineaPedido lineaPedidoModificar)
	{
		abrirSesion();

		Pedido p = session.bySimpleNaturalId(Pedido.class).load(pedido.getCodigoPedido());
		Articulo a = session.bySimpleNaturalId(Articulo.class).load(articulo.getCodigo());

		LineaPedido lp = new LineaPedido();

		LineaPedido lineaPedido = session.get(LineaPedido.class, lp.setId(pedido, articulo));
		lineaPedido.setCantidad(lineaPedidoModificar.getCantidad());

		try
		{
			session.update(lineaPedido);
		}
		catch (ConstraintViolationException e)
		{
			throw new ExcepcionDAO(MensajeError.getMensaje(TipoProblemaDAO.ERROR_REGISTRO_DUPLICADO));
		}
		catch (NullPointerException e)
		{
			throw new ExcepcionDAO(MensajeError.getMensaje(TipoProblemaDAO.ERROR_REGISTRO_NULO_O_INEXISTENTE));
		}

		cerrarSesion();
	}
}
