package practica2eval.dao;

import java.util.Date;

import org.hibernate.exception.ConstraintViolationException;

import practica2eval.dao.exception.ExcepcionDAO;
import practica2eval.dao.exception.MensajeError;
import practica2eval.dao.exception.TipoProblemaDAO;
import practica2eval.model.Cliente;
import practica2eval.model.Pedido;

public class PedidoDAO extends DAO
{
	public void insertarPedido(String codPedido, String DNIcliente)
	{
		abrirSesion();

		Cliente cliente = session.bySimpleNaturalId(Cliente.class).load(DNIcliente);
		Pedido pedido = new Pedido(codPedido, new Date());

		cliente.anadirPedido(pedido);

		try
		{
			session.save(pedido);
			session.update(cliente);

			cerrarSesion();
		}
		catch (ConstraintViolationException e)
		{
			throw new ExcepcionDAO(MensajeError.getMensaje(TipoProblemaDAO.ERROR_REGISTRO_DUPLICADO));
		}

	}

	public Pedido buscarPedido(String codPedido)
	{
		abrirSesion();

		Pedido pedido = session.bySimpleNaturalId(Pedido.class).load(codPedido);

		cerrarSesion();

		return pedido;
	}

	public void eliminarPedido(String codPedido)
	{
		Pedido pedido = buscarPedido(codPedido);

		abrirSesion();

		try
		{
			session.delete(pedido);

			cerrarSesion();
		}
		catch (NullPointerException e)
		{
			throw new ExcepcionDAO(MensajeError.getMensaje(TipoProblemaDAO.ERROR_REGISTRO_NULO_O_INEXISTENTE));
		}

	}
}
