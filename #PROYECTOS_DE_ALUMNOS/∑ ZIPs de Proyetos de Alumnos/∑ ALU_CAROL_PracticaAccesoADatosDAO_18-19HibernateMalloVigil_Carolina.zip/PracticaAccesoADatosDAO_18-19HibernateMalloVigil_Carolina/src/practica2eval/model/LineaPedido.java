package practica2eval.model;

import java.io.Serializable;
import java.math.BigDecimal;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;


/*
 * Se entiende que un pedido (que ser� siempre de un cliente)
 * estar� formado por un conjunto de l�neas de pedido
 * (art�culos, cantidad y pvp unitario)
 */


@Entity
@Table(name = "lineapedido")
public class LineaPedido implements Serializable
{
	/**
	 *
	 */
	private static final long serialVersionUID = 1L;

	/*
	 * La Primary key est� formada por el id de Articulo y el id de Pedido,
	 * por tanto creamos la clase IdLineaPedido para crear su clave compuesta
	 * en Hibernate
	 */

	@EmbeddedId
	private IdLineaPedido idLineaPedido;

	@ManyToOne
	@JoinColumn(name = "numeroPedido", insertable = false, updatable = false, nullable=false)
	private Pedido pedido; //Clave de Pedido (Fk2 de LineaPedido) - private Pedido pedido;

	@ManyToOne
	@JoinColumn(name = "idArticulo", insertable = false, updatable = false, nullable=false)
	private Articulo articulo; //Clave de Articulo (Fk1 de LineaPedido) - private Articulo articulo;

	@Column(name = "cantidad")//, length = 10, nullable = false
	private int cantidad;

	@Column(name = "pvp_unitario")//, length = 16, nullable = false
	private BigDecimal pvp_unitario;

	public LineaPedido()
	{

	}

	public LineaPedido(Pedido p, Articulo a, int cant)
	{
		this.idLineaPedido = new IdLineaPedido(a.getIdArticulo(), p.getNumPedido());
		articulo = a;
		pedido = p;
		cantidad = cant;
		pvp_unitario = a.getPrecio();
	}

	public LineaPedido(Pedido p, Articulo a, int cant, BigDecimal precio)
	{
		this.idLineaPedido = new IdLineaPedido(a.getIdArticulo(), p.getNumPedido());
		articulo = a;
		pedido = p;
		cantidad = cant;
		pvp_unitario = precio;
	}

	public Articulo getArticulo()
	{
		return articulo;
	}

	public void setArticulo(Articulo articulo)
	{
		this.articulo = articulo;
	}

	public Pedido getPedido()
	{
		return pedido;
	}

	public void setPedido(Pedido pedido)
	{
		this.pedido = pedido;
	}

	public IdLineaPedido getIdLineaPedido()
	{
		return idLineaPedido;
	}

	public IdLineaPedido setId(Pedido pedido, Articulo articulo)
	{
		return new IdLineaPedido(pedido.getNumPedido(), articulo.getIdArticulo());
	}

	public int getCantidad()
	{
		return cantidad;
	}

	public void setCantidad(int cantidad)
	{
		this.cantidad = cantidad;
	}

	public BigDecimal getPvp_unitario()
	{
		return pvp_unitario;
	}

	public void setPvp_unitario(BigDecimal pvp_unitario)
	{
		this.pvp_unitario = pvp_unitario;
	}
}
