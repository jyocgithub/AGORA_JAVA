package practica2eval.model;

import java.io.Serializable;
import java.util.Objects;

import javax.persistence.*;

@Embeddable
public class IdLineaPedido implements Serializable
{
	/**
	 *
	 */
	private static final long serialVersionUID = 1L;


	private int idArticulo; //Clave de Articulo (Fk1 de LineaPedido)

	private int numeroPedido; //Clave de Pedido (Fk2 de LineaPedido)



	public IdLineaPedido()
	{

	}

	public IdLineaPedido(int a, int p)
	{
		idArticulo = a;
		numeroPedido = p;
	}

	@Override
	public boolean equals(Object o)
	{
		if ( this == o ) {
			return true;
		}
		if ( o == null || getClass() != o.getClass() ) {
			return false;
		}
		IdLineaPedido that = (IdLineaPedido) o;
		return Objects.equals( this.idArticulo, that.idArticulo ) &&
				Objects.equals( this.numeroPedido, that.numeroPedido );
	}

	@Override
	public int hashCode()
	{
		return Objects.hash(this.idArticulo, this.numeroPedido);
	}

	public Integer getIdArticulo()
	{
		return idArticulo;
	}

	public void setIdArticulo(Integer idArticulo)
	{
		this.idArticulo = idArticulo;
	}

	public Integer getNumeroPedido()
	{
		return numeroPedido;
	}

	public void setNumeroPedido(Integer numeroPedido)
	{
		this.numeroPedido = numeroPedido;
	}


}
