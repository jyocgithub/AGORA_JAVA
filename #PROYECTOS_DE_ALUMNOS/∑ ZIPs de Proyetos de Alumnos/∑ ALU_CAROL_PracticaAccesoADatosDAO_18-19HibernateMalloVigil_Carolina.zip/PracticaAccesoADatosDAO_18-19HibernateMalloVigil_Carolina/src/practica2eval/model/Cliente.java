package practica2eval.model;

import java.io.Serializable;
import java.util.Date;
import java.util.HashSet;
//import java.util.Objects;
import java.util.Set;
import javax.persistence.*;
import org.hibernate.annotations.NaturalId;

/*Un cliente est� formado obligatoriamente por:
 * un identificador num�rico (lo generar� la base de datos),
 * un DNI (longitud fija de 9 caracteres),
 * un nombre (longitud m�xima de 50 caracteres)
 * y una fecha de alta (incluyendo la hora y los minutos).
 * Opcionalmente, por los apellidos (longitud m�xima 100 caracteres).
 *
 * No se pueden eliminar clientes si este tiene pedidos.
 */

@Entity
@Table(name = "cliente")
public class Cliente implements Serializable
{
	/**
	 *
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "idCliente")
	private int idCliente;

	@NaturalId
	@Column(name = "dni", length = 9, nullable = false, unique = true)
	private String DNI;

	@Column(name = "nombre", length = 50, nullable = false)
	private String nombre;

	@Column(name = "apellidos", length = 100)
	private String apellidos;

	@Column(name = "fechaAlta", nullable = false)
	private Date fechaAlta;

	@OneToMany(mappedBy = "cliente", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	private Set<Pedido> setPedidos = new HashSet<>();


	public Cliente()
	{

	}

	public Cliente(String dni, String nom, Date fecha)
	{
		DNI = dni;
		nombre = nom;
		fechaAlta = fecha;
	}

	public Cliente(String dni, String nom, String ape, Date fecha)
	{
		DNI = dni;
		nombre = nom;
		apellidos = ape;
		fechaAlta = fecha;
	}
/*
	@Override
	public boolean equals(Object o)
	{
		if ( this == o ) {
			return true;
		}
		if ( o == null || getClass() != o.getClass() ) {
			return false;
		}
		Cliente that = (Cliente) o;
		return Objects.equals( this.getIdCliente(), that.getIdCliente() );
	}

	@Override
	public int hashCode()
	{
		return Objects.hash(this.getIdCliente());
	}
*/
	public int getIdCliente() throws NullPointerException
	{
		return idCliente;
	}

	public void setIdCliente(int idCliente)
	{
		this.idCliente = idCliente;
	}

	public String getDNI()
	{
		return DNI;
	}

	public void setDNI(String dNI)
	{
		DNI = dNI;
	}

	public String getNombre()
	{
		return nombre;
	}

	public void setNombre(String nombre)
	{
		this.nombre = nombre;
	}

	public String getApellidos()
	{
		return apellidos;
	}

	public void setApellidos(String apellidos)
	{
		this.apellidos = apellidos;
	}

	public Date getFechaAlta()
	{
		return fechaAlta;
	}

	public void setFechaAlta(Date fechaAlta)
	{
		this.fechaAlta = fechaAlta;
	}

	public Set<Pedido> getPedidos()
	{
		return setPedidos;
	}

	public void setPedidos(Set<Pedido> pedidos)
	{
		this.setPedidos = pedidos;
	}

	public void anadirPedido(Pedido pedido){
		pedido.setCliente(this);
		setPedidos.add(pedido);
	}
}
