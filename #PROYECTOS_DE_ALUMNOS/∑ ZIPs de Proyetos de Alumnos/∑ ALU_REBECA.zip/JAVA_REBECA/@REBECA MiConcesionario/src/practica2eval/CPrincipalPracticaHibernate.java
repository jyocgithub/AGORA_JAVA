package practica2eval;

//import org.hibernate.Hibernate;
import org.hibernate.Session;
//import org.hibernate.exception.ConstraintViolationException;

import practica2eval.dao.exception.ExcepcionDAO;
import practica2eval.model.Concesionario;
import practica2eval.model.Extras;
import practica2eval.model.Proveedor;
import practica2eval.model.Vehiculo;
import practica2eval.utilfiles.HibernateUtil;

public class CPrincipalPracticaHibernate {

	public static void main(String[] args) {
		
		// FUNCIONA SIN M�TODOS
		Session session = null;
		org.hibernate.Transaction transaction = null;
		
		//tengo que meter al cliente aqui para que pueda acceder al concesionario

		try{
			session = HibernateUtil.getSessionFactory().openSession();
			transaction = session.beginTransaction();
			Concesionario e= new Concesionario();
			e.setNombre("LevelMotor");
			e.setIdConcesionario(96513);
			e.setNif("21493P");
			e.setMarca("Mercedes");
			e.setFechaRenovacion("25/10/2021");
			//e.eliminaVehiculo(vehiculo);


			Vehiculo d = new Vehiculo();
			d.setNumeroMotor("549Y");
			d.setFechaCompra("13/06/2020");
			d.setConcesionario(e);
			e.anadirVehiculo(d);
			//session.save(d);
			
			Extras x = new Extras();
			x.setIdExtras(9841);
			x.setDescripcion("Radio con WIFI");
			x.setFechaFabricacion("15/11/2010");
			x.setVehiculo(d);
			
			Proveedor p = new Proveedor();
			p.setIdProveedor(79135);
			p.setDescripcion("NISSAN");
			p.setFechaEnvio("24/03/2019");
			p.setExtras(x);

			session.save(e);


			transaction.commit();

			@SuppressWarnings("unused")
			Concesionario concesionario;
			concesionario=session.bySimpleNaturalId(Concesionario.class).load("yy00000yx");

		} catch (ExcepcionDAO e) {
			if(transaction != null){
				transaction.rollback();
			}
			e.printStackTrace();
		} finally {
			if(session != null){
				session.close();
			}
		}

		HibernateUtil.shutdown();

		
	}
}