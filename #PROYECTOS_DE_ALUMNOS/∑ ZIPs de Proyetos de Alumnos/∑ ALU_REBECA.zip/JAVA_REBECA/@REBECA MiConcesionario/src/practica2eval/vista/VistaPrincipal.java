package practica2eval.vista;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Toolkit;
import java.awt.Window;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;
import javax.swing.JTable;
import javax.swing.SwingConstants;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

import practica2eval.dao.BDConcesionarioDAO;
import practica2eval.dao.BDExtrasDAO;
import practica2eval.dao.BDProveedorDAO;
import practica2eval.dao.BDVehiculoDAO;
import practica2eval.model.Concesionario;
import practica2eval.model.Extras;
import practica2eval.model.Proveedor;
import practica2eval.model.Vehiculo;

public class VistaPrincipal {

	JFrame frame;

	public static final int ENTIDAD_CONCESIONARIO = 1, ENTIDAD_VEHICULO = 2, ENTIDAD_EXTRAS = 3, ENTIDAD_PROVEEDOR = 4;
	public static final int ACCION_ALTA = 1, ACCION_MODIFICAR = 2, ACCION_CONSULTAR = 3, ACCION_BAJA = 4;
	private JPanel panelPrincipal;
	private JPanel panelTabConcesionario;
	private JPanel panelTabVehiculo;
	private JPanel panelTabExtra;
	private JPanel panelTabProveedor;
	private JTabbedPane tabbedPane;
	private JTable tableConcesionarios;
	private List<Concesionario> listaConcesionarios;
	private List<Vehiculo> listaVehiculos;
	private List<Extras> listaExtras;
	private List<Proveedor> listaProveedores;
	private int concesionarioActual = -1;
	private int vehiculoActual = -1;
	private int extraActual = -1;
	private int proveedorActual = -1;
	private int entidadActual = -1;
	private int accionActual = -1;
	private MiModelo miModelo;
	private String[] columnasConcesionarios = { "Id", "Nombre", "Marca", "Nif", "FechaRenovacion" };
	private String[] columnasVehiculos = { "Id Concesionario", "Id Vehiculo", "Numero Motor", "Fecha compra" };
	private String[] columnasExtras = { "Id Vehiculo", "Id Extra", "Descripcion", "Fecha Fabricacion" };
	private String[] columnasProveedores = { "Id Extra", "Id Proveedor", "Descripcion", "Fecha Envio" };
	private JButton btnNuevo;
	private JButton btnConsultar;
	private JButton btnEliminar;
	private JTable tableVehiculos;
	private JTable tableExtras;
	private JTable tableProveedores;
	private VistaPrincipal vistaPrincipal;
	private JLabel titulo;

	public VistaPrincipal() {
		initialize();
		activarListeners();
		vistaPrincipal = this;
	}

	private void initialize() {
		// FRAME
		frame = new JFrame();
		frame.setBounds(100, 100, 586, 360);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);

		// PANELES
		panelPrincipal = new JPanel();
		panelPrincipal.setBounds(6, 39, 574, 293);
		frame.getContentPane().add(panelPrincipal);
		panelPrincipal.setLayout(null);

		// JTABBEDPANES
		// -- paneles del jtabbed
		panelTabConcesionario = new JPanel();
		panelTabVehiculo = new JPanel();
		panelTabExtra = new JPanel();
		panelTabProveedor = new JPanel();
		// -- pestañas del jtabbed
		tabbedPane = new JTabbedPane(JTabbedPane.TOP);
		tabbedPane.setBackground(Color.GRAY);
		tabbedPane.setBounds(42, 6, 518, 21);
		tabbedPane.addTab("Concesionarios", panelTabConcesionario);
		tabbedPane.addTab("Vehiculo", panelTabVehiculo);
		tabbedPane.addTab("Extras", panelTabExtra);
		tabbedPane.addTab("Provedores", panelTabProveedor);
		frame.getContentPane().add(tabbedPane);

		// JTABLES
		tableConcesionarios = new JTable();
		tableConcesionarios.setBackground(Color.CYAN);
		tableConcesionarios.setBounds(72, 25, 353, 241);
		panelPrincipal.add(tableConcesionarios);

		tableVehiculos = new JTable();
		tableVehiculos.setBounds(72, 25, 353, 241);
		tableVehiculos.setBackground(new Color(173, 255, 47));
		panelPrincipal.add(tableVehiculos);

		tableExtras = new JTable();
		tableExtras.setBackground(new Color(244, 164, 96));
		tableExtras.setBounds(72, 25, 353, 241);
		panelPrincipal.add(tableExtras);

		tableProveedores = new JTable();
		tableProveedores.setBackground(new Color(255, 182, 193));
		tableProveedores.setBounds(72, 25, 353, 241);
		panelPrincipal.add(tableProveedores);

		// BUTTONS
		btnNuevo = new JButton("NUEVO");

		btnNuevo.setBounds(451, 46, 102, 29);
		panelPrincipal.add(btnNuevo);

		btnConsultar = new JButton("CONSULTAR");
		btnConsultar.setBounds(451, 89, 102, 29);
		panelPrincipal.add(btnConsultar);

		btnEliminar = new JButton("ELIMINAR");

		btnEliminar.setBounds(451, 178, 102, 29);
		panelPrincipal.add(btnEliminar);

		titulo = new JLabel("New label");
		titulo.setHorizontalAlignment(SwingConstants.CENTER);
		titulo.setBounds(21, 6, 454, 16);
		panelPrincipal.add(titulo);

		entidadActual = ENTIDAD_CONCESIONARIO;
		// hacemos visible la primera pestaña
		listarConcesionarios();
		tabbedPane.setEnabledAt(0, false);
		tabbedPane.setEnabledAt(1, true);
		tabbedPane.setEnabledAt(2, false);
		tabbedPane.setEnabledAt(3, false);
		tabbedPane.setForegroundAt(0, Color.GRAY);
		tabbedPane.setForegroundAt(1, Color.BLACK);
		tabbedPane.setForegroundAt(2, Color.GRAY);
		tabbedPane.setForegroundAt(3, Color.GRAY);
		titulo.setText("LISTA DE CONCESIONARIOS");

	}

	// LISTENERS
	public void activarListeners() {
		ChangeListener changeListener = new ChangeListener() {
			@Override
			public void stateChanged(ChangeEvent changeEvent) {
				JTabbedPane sourceTabbedPane = (JTabbedPane) changeEvent.getSource();
				int index = sourceTabbedPane.getSelectedIndex();
				System.out.println("Tab changed to: " + index + " _ " + sourceTabbedPane.getTitleAt(index));

				switch (index) {
				case 0: // Pincho en Concesionario
					listarConcesionarios();
					tabbedPane.setEnabledAt(0, false);
					tabbedPane.setEnabledAt(1, true);
					tabbedPane.setEnabledAt(2, false);
					tabbedPane.setEnabledAt(3, false);
					tabbedPane.setForegroundAt(0, Color.GRAY);
					tabbedPane.setForegroundAt(1, Color.BLACK);
					tabbedPane.setForegroundAt(2, Color.GRAY);
					tabbedPane.setForegroundAt(3, Color.GRAY);
					entidadActual = ENTIDAD_CONCESIONARIO;
					tableConcesionarios.setVisible(true);
					tableExtras.setVisible(false);
					tableProveedores.setVisible(false);
					tableVehiculos.setVisible(false);
					concesionarioActual = -1;
					titulo.setText("LISTA DE CONCESIONARIOS");

					break;
				case 1: // Pincho en vehiculo
					if (concesionarioActual != -1) { // hay un concesionario elegido en la tabla
						tabbedPane.setEnabledAt(0, true);
						tabbedPane.setEnabledAt(1, false);
						tabbedPane.setEnabledAt(2, true);
						tabbedPane.setEnabledAt(3, false);
						tabbedPane.setForegroundAt(0, Color.BLACK);
						tabbedPane.setForegroundAt(1, Color.GRAY);
						tabbedPane.setForegroundAt(2, Color.BLACK);
						tabbedPane.setForegroundAt(3, Color.GRAY);
						entidadActual = ENTIDAD_VEHICULO;
						tableConcesionarios.setVisible(false);
						tableExtras.setVisible(false);
						tableProveedores.setVisible(false);
						tableVehiculos.setVisible(true);
						listarVehiculos();
						vehiculoActual = -1;
						titulo.setText("LISTA DE VEHICULOS DEL CONCESIONARIO "
								+ listaConcesionarios.get(concesionarioActual).getNombre());
					} else {
						tabbedPane.setSelectedIndex(0);
						JOptionPane.showMessageDialog(null, "Seleccione antes un concesionario", "Aviso",
								JOptionPane.ERROR_MESSAGE);
					}

					break;
				case 2: // Pincho en extra
					if (vehiculoActual != -1) { // hay un vehiculo elegido en la tabla

						tabbedPane.setEnabledAt(0, true);
						tabbedPane.setEnabledAt(1, true);
						tabbedPane.setEnabledAt(2, false);
						tabbedPane.setEnabledAt(3, true);
						tabbedPane.setForegroundAt(0, Color.BLACK);
						tabbedPane.setForegroundAt(1, Color.BLACK);
						tabbedPane.setForegroundAt(2, Color.GRAY);
						tabbedPane.setForegroundAt(3, Color.BLACK);
						entidadActual = ENTIDAD_EXTRAS;
						tableConcesionarios.setVisible(false);
						tableExtras.setVisible(true);
						tableProveedores.setVisible(false);
						tableVehiculos.setVisible(false);
						listarExtras();
						extraActual = -1;
						titulo.setText(
								"LISTA DE EXTRAS DEL VEHICULO " + listaVehiculos.get(vehiculoActual).getNumeroMotor());

					} else {
						tabbedPane.setSelectedIndex(1);
						JOptionPane.showMessageDialog(null, "Seleccione antes un vehiculo", "Aviso",
								JOptionPane.ERROR_MESSAGE);
					}
					break;
				case 3: // Pincho en proveedor
					if (extraActual != -1) { // hay un extra elegido en la tabla
						tabbedPane.setEnabledAt(0, true);
						tabbedPane.setEnabledAt(1, true);
						tabbedPane.setEnabledAt(2, true);
						tabbedPane.setEnabledAt(3, false);
						tabbedPane.setForegroundAt(0, Color.BLACK);
						tabbedPane.setForegroundAt(1, Color.BLACK);
						tabbedPane.setForegroundAt(2, Color.BLACK);
						tabbedPane.setForegroundAt(3, Color.GRAY);
						entidadActual = ENTIDAD_PROVEEDOR;
						tableConcesionarios.setVisible(false);
						tableExtras.setVisible(false);
						tableProveedores.setVisible(true);
						tableVehiculos.setVisible(false);
						listarProveedores();
						proveedorActual = -1;
						titulo.setText(
								"LISTA DE PROVEEDORES DEL EXTRA " + listaExtras.get(extraActual).getDescripcion());

					} else {
						tabbedPane.setSelectedIndex(2);
						JOptionPane.showMessageDialog(null, "Seleccione antes un extra", "Aviso",
								JOptionPane.ERROR_MESSAGE);
					}
					break;
				}

			}
		};
		tabbedPane.addChangeListener(changeListener);

		tableConcesionarios.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				JTable tabla = (JTable) e.getSource();
				int fila = tabla.getSelectedRow();
				concesionarioActual = fila;
				System.out.println(concesionarioActual);
			}
		});
		tableVehiculos.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				JTable tabla = (JTable) e.getSource();
				int fila = tabla.getSelectedRow();
				vehiculoActual = fila;
				System.out.println(vehiculoActual);
			}
		});
		tableExtras.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				JTable tabla = (JTable) e.getSource();
				int fila = tabla.getSelectedRow();
				extraActual = fila;
				System.out.println(extraActual);
			}
		});
		tableProveedores.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				JTable tabla = (JTable) e.getSource();
				int fila = tabla.getSelectedRow();
				proveedorActual = fila;
				System.out.println(proveedorActual);
			}
		});
		btnEliminar.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				switch (entidadActual) {
				case ENTIDAD_CONCESIONARIO:
					eliminarConcesionarios();
					break;
				case ENTIDAD_VEHICULO:
					eliminarVehiculo();
					break;
				case ENTIDAD_EXTRAS:
					eliminarExtra();
					break;
				case ENTIDAD_PROVEEDOR:
					eliminarProveedor();
					break;
				}

			}
		});
		btnNuevo.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				accionActual = ACCION_ALTA;
				if (entidadActual == ENTIDAD_CONCESIONARIO) {
					altaConcesionario();
					listarConcesionarios();
				} else {
					alta();
				}
			}
		});
		btnConsultar.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				accionActual = ACCION_CONSULTAR;
				if (entidadActual == ENTIDAD_CONCESIONARIO) {
					altaConcesionario();
					listarConcesionarios();
				} else {
					alta();
				}
			}
		});

	}

	public static void centrarVentana(Window frame) {
		Dimension dimension = Toolkit.getDefaultToolkit().getScreenSize();
		int x = (int) ((dimension.getWidth() - frame.getWidth()) / 2);
		int y = (int) ((dimension.getHeight() - frame.getHeight()) / 2);
		frame.setLocation(x, y);
	}

	// ******** CONCESIONARIOS ****************************
	// ********+++++++++++++++++++++++*********************
	public void altaConcesionario() {
		EventQueue.invokeLater(new Runnable() {
			@Override
			public void run() {
				try {
					EdicionConcesionario window = new EdicionConcesionario(accionActual, vistaPrincipal);
					window.frame.setVisible(true);
					centrarVentana(window.frame);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public void eliminarConcesionarios() {
		BDConcesionarioDAO bd = new BDConcesionarioDAO();
		int fila = tableConcesionarios.getSelectedRow();
		String nif = listaConcesionarios.get(fila).getNif();
		bd.eliminarPorId(nif);
		listarConcesionarios();
	}

	public void listarConcesionarios() {
		BDConcesionarioDAO bd = new BDConcesionarioDAO();
		listaConcesionarios = bd.mostrarConcesionario("");
		// JTABLE CONCESIONARIO
		miModelo = new MiModelo();
		miModelo.setColumnIdentifiers(columnasConcesionarios);
		for (Concesionario c : listaConcesionarios) {
			Object[] row = new Object[5];
			row[0] = c.getIdConcesionario() + "";
			row[1] = c.getNombre();
			row[2] = c.getMarca();
			row[3] = c.getNif();
			row[4] = c.getFechaRenovacion();
			miModelo.addRow(row);
		}
		tableConcesionarios.setModel(miModelo);
	}

	// ******** VEHICULOS ****************************
	// ********+++++++++++++++++++++++*********************

	public void alta() {
		EventQueue.invokeLater(new Runnable() {
			@Override
			public void run() {
				try {
					EdicionOtros window = new EdicionOtros(accionActual, vistaPrincipal);
					window.frame.setVisible(true);
					centrarVentana(window.frame);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public void eliminarVehiculo() {
		BDVehiculoDAO bd = new BDVehiculoDAO();
		int fila = tableVehiculos.getSelectedRow();
		String nummotor = listaVehiculos.get(fila).getNumeroMotor();
		bd.eliminar(nummotor);
		listarVehiculos();
	}

	public void listarVehiculos() {
		BDVehiculoDAO bd = new BDVehiculoDAO();
		int idconce = listaConcesionarios.get(concesionarioActual).getIdConcesionario();
		listaVehiculos = bd.mostrarVehiculos(idconce);
		miModelo = new MiModelo();
		miModelo.setColumnIdentifiers(columnasVehiculos);
		for (Vehiculo c : listaVehiculos) {
			Object[] row = new Object[4];
			row[0] = c.getConcesionario().getIdConcesionario() + "";
			row[1] = c.getIdVehiculo();
			row[2] = c.getNumeroMotor();
			row[3] = c.getFechaCompra();
			miModelo.addRow(row);
		}
		tableVehiculos.setModel(miModelo);
	}

	// ******** EXTRAS ****************************
	// ********+++++++++++++++++++++++*********************
	public void eliminarExtra() {
		BDExtrasDAO bd = new BDExtrasDAO();
		int fila = tableExtras.getSelectedRow();
		String desc = listaExtras.get(fila).getDescripcion();
		bd.eliminar(desc);
		listarExtras();
	}

	public void listarExtras() {
		BDExtrasDAO bd = new BDExtrasDAO();
		int id = listaVehiculos.get(vehiculoActual).getIdVehiculo();
		listaExtras = bd.mostrarExtras(id);
		miModelo = new MiModelo();
		miModelo.setColumnIdentifiers(columnasExtras);
		for (Extras c : listaExtras) {
			Object[] row = new Object[4];
			row[0] = c.getVehiculo().getIdVehiculo() + "";
			row[1] = c.getIdExtras();
			row[2] = c.getDescripcion();
			row[3] = c.getFechaFabricacion();
			miModelo.addRow(row);
		}
		tableExtras.setModel(miModelo);
	}

	// ******** PROVEEDORES ****************************
	// ********+++++++++++++++++++++++*********************
	public void eliminarProveedor() {
		BDProveedorDAO bd = new BDProveedorDAO();
		int fila = tableProveedores.getSelectedRow();
		String desc = listaProveedores.get(fila).getDescripcion();
		bd.eliminar(desc);
		listarProveedores();
	}

	public void listarProveedores() {
		BDProveedorDAO bd = new BDProveedorDAO();
		int id = listaExtras.get(extraActual).getIdExtras();
		listaProveedores = bd.mostrarProveedores(id);
		miModelo = new MiModelo();
		miModelo.setColumnIdentifiers(columnasProveedores);
		for (Proveedor c : listaProveedores) {
			Object[] row = new Object[4];
			row[0] = c.getExtras().getIdExtras() + "";
			row[1] = c.getIdProveedor();
			row[2] = c.getDescripcion();
			row[3] = c.getFechaEnvio();
			miModelo.addRow(row);
		}
		tableProveedores.setModel(miModelo);
	}

	public List<Concesionario> getListaConcesionarios() {
		return listaConcesionarios;
	}

	public void setListaConcesionarios(List<Concesionario> listaConcesionarios) {
		this.listaConcesionarios = listaConcesionarios;
	}

	public List<Vehiculo> getListaVehiculos() {
		return listaVehiculos;
	}

	public void setListaVehiculos(List<Vehiculo> listaVehiculos) {
		this.listaVehiculos = listaVehiculos;
	}

	public List<Extras> getListaExtras() {
		return listaExtras;
	}

	public void setListaExtras(List<Extras> listaExtras) {
		this.listaExtras = listaExtras;
	}

	public List<Proveedor> getListaProveedores() {
		return listaProveedores;
	}

	public void setListaProveedores(List<Proveedor> listaProveedores) {
		this.listaProveedores = listaProveedores;
	}

	public int getConcesionarioActual() {
		return concesionarioActual;
	}

	public void setConcesionarioActual(int concesionarioActual) {
		this.concesionarioActual = concesionarioActual;
	}

	public int getVehiculoActual() {
		return vehiculoActual;
	}

	public void setVehiculoActual(int vehiculoActual) {
		this.vehiculoActual = vehiculoActual;
	}

	public int getExtraActual() {
		return extraActual;
	}

	public void setExtraActual(int extraActual) {
		this.extraActual = extraActual;
	}

	public int getEntidadActual() {
		return entidadActual;
	}

	public void setEntidadActual(int entidadActual) {
		this.entidadActual = entidadActual;
	}
}
