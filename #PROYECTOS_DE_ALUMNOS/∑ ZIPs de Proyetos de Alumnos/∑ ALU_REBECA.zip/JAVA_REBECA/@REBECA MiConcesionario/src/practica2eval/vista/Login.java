package practica2eval.vista;

import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Toolkit;
import java.awt.Window;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

import practica2eval.dao.BDUsuarioDAO;
import practica2eval.model.Usuario;

public class Login {

	private JFrame frame;
	private JTextField tfUsuario;
	private JTextField tfPassword;
	private JButton btnAcceder;

	public void accionesIniciales() {
	}

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			@Override
			public void run() {
				try {
					Login window = new Login();
					window.frame.setVisible(true);
					centrarVentana(window.frame);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Login() {
		initialize();
		accionesIniciales();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 586, 360);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);

		JLabel lblNewLabel = new JLabel("USUARIO");
		lblNewLabel.setBounds(85, 72, 61, 16);
		frame.getContentPane().add(lblNewLabel);

		JLabel lblNewLabel_1 = new JLabel("CONTRASEÑA");
		lblNewLabel_1.setBounds(85, 117, 117, 16);
		frame.getContentPane().add(lblNewLabel_1);

		tfUsuario = new JTextField();
		tfUsuario.setBounds(255, 67, 130, 26);
		frame.getContentPane().add(tfUsuario);
		tfUsuario.setColumns(10);

		tfPassword = new JTextField();
		tfPassword.setBounds(255, 112, 130, 26);
		frame.getContentPane().add(tfPassword);
		tfPassword.setColumns(10);

		btnAcceder = new JButton("ACCEDER");
		btnAcceder.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {

				BDUsuarioDAO bd = new BDUsuarioDAO();
				String nombre = tfUsuario.getText();
				Usuario user = bd.seleccionarPorNombre(nombre);

				if (user != null && tfPassword.getText().equals(user.getPassword())
						&& tfUsuario.getText().equals(user.getNombre())) {
					EventQueue.invokeLater(new Runnable() {
						@Override
						public void run() {
							try {
								frame.dispose();
								VistaPrincipal window = new VistaPrincipal();
								window.frame.setVisible(true);
								centrarVentana(window.frame);
							} catch (Exception e) {
								e.printStackTrace();
							}
						}
					});
				} else {
					JOptionPane.showMessageDialog(null, "Usuario o contraseña erronea", "Acceso denegado",
							JOptionPane.ERROR_MESSAGE);
				}
			}
		});
		btnAcceder.setBounds(254, 162, 117, 29);
		frame.getContentPane().add(btnAcceder);
	}

	public static void centrarVentana(Window frame) {
		Dimension dimension = Toolkit.getDefaultToolkit().getScreenSize();
		int x = (int) ((dimension.getWidth() - frame.getWidth()) / 2);
		int y = (int) ((dimension.getHeight() - frame.getHeight()) / 2);
		frame.setLocation(x, y);
	}
}
