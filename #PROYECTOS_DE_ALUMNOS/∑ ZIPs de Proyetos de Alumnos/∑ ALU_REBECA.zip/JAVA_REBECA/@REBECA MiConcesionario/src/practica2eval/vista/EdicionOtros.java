package practica2eval.vista;

import java.awt.Dimension;
import java.awt.Toolkit;
import java.awt.Window;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

import practica2eval.dao.BDExtrasDAO;
import practica2eval.dao.BDProveedorDAO;
import practica2eval.dao.BDVehiculoDAO;
import practica2eval.model.Concesionario;
import practica2eval.model.Extras;
import practica2eval.model.Proveedor;
import practica2eval.model.Vehiculo;

public class EdicionOtros {

	JFrame frame;
	private JTextField texto2;
	private JButton btnCancelar;
	private JTextField texto1;
	private JLabel labelCabecera;
	private int entidadActual;
	private VistaPrincipal vistaPrincipal;
	private int accion;

	/**
	 * Create the application.
	 */
	public EdicionOtros(int accion, VistaPrincipal vistaPrincipal) {
		this.accion = accion;
		this.vistaPrincipal = vistaPrincipal;
		initialize();
	}

	public void actualizar() {

		if (texto1.getText().isEmpty() || texto2.getText().isEmpty()) {
			JOptionPane.showMessageDialog(null, "Rellene todos los campos", "Error", JOptionPane.ERROR_MESSAGE);

		} else {
			String t1 = texto1.getText();
			String t2 = texto2.getText();

			switch (vistaPrincipal.getEntidadActual()) {
			case VistaPrincipal.ENTIDAD_VEHICULO:
				Vehiculo c = new Vehiculo();
				c.setNumeroMotor(t1);
				c.setFechaCompra(t2);

				int conceactual = vistaPrincipal.getConcesionarioActual();
				Concesionario con = vistaPrincipal.getListaConcesionarios().get(conceactual);
				c.setConcesionario(con);

				BDVehiculoDAO bd = new BDVehiculoDAO();
				bd.insertar(c);
				vistaPrincipal.listarVehiculos();
				break;
			case VistaPrincipal.ENTIDAD_EXTRAS:
				Extras e = new Extras();
				e.setDescripcion(t1);
				e.setFechaFabricacion(t2);

				int vehiactual = vistaPrincipal.getVehiculoActual();
				Vehiculo ve = vistaPrincipal.getListaVehiculos().get(vehiactual);
				e.setVehiculo(ve);

				BDExtrasDAO bde = new BDExtrasDAO();
				bde.insertar(e);
				vistaPrincipal.listarExtras();

				break;
			case VistaPrincipal.ENTIDAD_PROVEEDOR:
				Proveedor p = new Proveedor();
				p.setDescripcion(t1);
				p.setFechaEnvio(t2);

				int extraactual = vistaPrincipal.getExtraActual();
				Extras ex = vistaPrincipal.getListaExtras().get(extraactual);
				p.setExtras(ex);

				BDProveedorDAO bdp = new BDProveedorDAO();
				bdp.insertar(p);
				vistaPrincipal.listarProveedores();
				break;
			}

		}
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 586, 360);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);

		labelCabecera = new JLabel("ALTA VEHICULO");
		labelCabecera.setHorizontalAlignment(SwingConstants.CENTER);
		labelCabecera.setBounds(152, 28, 275, 16);
		frame.getContentPane().add(labelCabecera);

		JLabel label2 = new JLabel("FECHA COMPRA");
		label2.setBounds(90, 151, 201, 16);
		frame.getContentPane().add(label2);

		texto2 = new JTextField();
		texto2.setBounds(339, 146, 130, 26);
		frame.getContentPane().add(texto2);
		texto2.setColumns(10);

		btnCancelar = new JButton("CANCELAR");
		btnCancelar.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {

				frame.dispose();
			}
		});

		btnCancelar.setBounds(117, 268, 117, 29);
		frame.getContentPane().add(btnCancelar);

		JLabel label1 = new JLabel("NUMERO MOTOR");
		label1.setBounds(90, 99, 117, 16);
		frame.getContentPane().add(label1);

		texto1 = new JTextField();
		texto1.setColumns(10);
		texto1.setBounds(339, 94, 130, 26);
		frame.getContentPane().add(texto1);

		JButton btnActualizar = new JButton("ACTUALIZAR");
		btnActualizar.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				actualizar();
				frame.dispose();
			}
		});
		btnActualizar.setBounds(325, 268, 117, 29);
		frame.getContentPane().add(btnActualizar);

		switch (vistaPrincipal.getEntidadActual()) {
		case VistaPrincipal.ENTIDAD_VEHICULO:
			label1.setText("Num. Motor");
			label2.setText("Fecha compra");
			break;
		case VistaPrincipal.ENTIDAD_EXTRAS:
			label1.setText("Descripcion");
			label2.setText("Fecha fabricacion");
			break;
		case VistaPrincipal.ENTIDAD_PROVEEDOR:
			label1.setText("Descripcion");
			label2.setText("Fecha envio");
			break;
		}
		if (accion == vistaPrincipal.ACCION_CONSULTAR) {

			texto1.setEditable(false);
			texto2.setEditable(false);
			btnActualizar.setVisible(false);
			btnCancelar.setText("SALIR");
			switch (vistaPrincipal.getEntidadActual()) {
			case VistaPrincipal.ENTIDAD_VEHICULO:
				labelCabecera.setText("CONSULTA DE VEHICULO");
				int vac = vistaPrincipal.getVehiculoActual();
				Vehiculo v = vistaPrincipal.getListaVehiculos().get(vac);
				texto1.setText(v.getNumeroMotor());
				texto2.setText(v.getFechaCompra());
				break;
			case VistaPrincipal.ENTIDAD_EXTRAS:
				labelCabecera.setText("CONSULTA");
				int eac = vistaPrincipal.getExtraActual();
				Extras e = vistaPrincipal.getListaExtras().get(eac);
				texto1.setText(e.getDescripcion());
				texto2.setText(e.getFechaFabricacion());
				break;
			case VistaPrincipal.ENTIDAD_PROVEEDOR:
				labelCabecera.setText("CONSULTA DE PROVEEDOR");
				int pac = vistaPrincipal.getVehiculoActual();
				Proveedor p = vistaPrincipal.getListaProveedores().get(pac);
				texto1.setText(p.getDescripcion());
				texto2.setText(p.getFechaEnvio());
				break;
			}

		} else {
			texto1.setEditable(true);
			texto2.setEditable(true);
			btnActualizar.setVisible(true);
			btnCancelar.setText("CANCELAR");
			switch (vistaPrincipal.getEntidadActual()) {
			case VistaPrincipal.ENTIDAD_VEHICULO:
				labelCabecera.setText("ALTA DE VEHICULO");
				break;
			case VistaPrincipal.ENTIDAD_EXTRAS:
				labelCabecera.setText("ALTA DE EXTRA");
				break;
			case VistaPrincipal.ENTIDAD_PROVEEDOR:
				labelCabecera.setText("ALTA DE PROVEEDOR");
				break;
			}
			texto1.setText("");
			texto2.setText("");
		}
	}

	public static void centrarVentana(Window frame) {
		Dimension dimension = Toolkit.getDefaultToolkit().getScreenSize();
		int x = (int) ((dimension.getWidth() - frame.getWidth()) / 2);
		int y = (int) ((dimension.getHeight() - frame.getHeight()) / 2);
		frame.setLocation(x, y);
	}
}
