package practica2eval.vista;

import java.awt.Dimension;
import java.awt.Toolkit;
import java.awt.Window;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

import practica2eval.dao.BDConcesionarioDAO;
import practica2eval.model.Concesionario;

public class EdicionConcesionario {

	JFrame frame;
	private JTextField tfMarca;
	private JTextField tfNIF;
	private JButton btnCancelar;
	private JTextField tfFechaRenovacion;
	private JTextField tfNombre;
	private int accion;
	private JCheckBox cbImportacion;
	// public static int idConcesionarioActual = -1;
	private VistaPrincipal vistaPrincipal;

	/**
	 * Create the application.
	 */
	public EdicionConcesionario(int accion, VistaPrincipal vistaPrincipal) {
		this.accion = accion;
		this.vistaPrincipal = vistaPrincipal;
		initialize();
	}

	public void actualizar() {

		if (tfNombre.getText().isEmpty() || tfFechaRenovacion.getText().isEmpty() || tfMarca.getText().isEmpty()
				|| tfNIF.getText().isEmpty()) {
			JOptionPane.showMessageDialog(null, "Rellene todos los campos", "Error", JOptionPane.ERROR_MESSAGE);

		} else {
			String tnombre = tfNombre.getText();
			String tmarca = tfMarca.getText();
			String tnif = tfNIF.getText();
			String tfechaRenovacion = tfFechaRenovacion.getText();
			boolean timportacion = false;
			if (cbImportacion.isSelected()) {
				timportacion = true;
			}
			Concesionario c = new Concesionario();
			c.setFechaRenovacion(tfechaRenovacion);
			c.setNif(tnif);
			c.setMarca(tmarca);
			c.setNombre(tnombre);
			c.setImportacion(timportacion);

			BDConcesionarioDAO bd = new BDConcesionarioDAO();
			if (accion == VistaPrincipal.ACCION_ALTA) {
				bd.insertar(c);
			}
		}
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 586, 360);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);

		JLabel label2 = new JLabel("MARCA");
		label2.setBounds(85, 72, 61, 16);
		frame.getContentPane().add(label2);

		JLabel label3 = new JLabel("NIF");
		label3.setBounds(85, 117, 117, 16);
		frame.getContentPane().add(label3);

		tfMarca = new JTextField();
		tfMarca.setBounds(255, 67, 130, 26);
		frame.getContentPane().add(tfMarca);
		tfMarca.setColumns(10);

		tfNIF = new JTextField();
		tfNIF.setBounds(255, 112, 130, 26);
		frame.getContentPane().add(tfNIF);
		tfNIF.setColumns(10);

		btnCancelar = new JButton("CANCELAR");
		btnCancelar.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {

				frame.dispose();
			}
		});
		btnCancelar.setBounds(113, 268, 117, 29);
		frame.getContentPane().add(btnCancelar);

		JLabel label4 = new JLabel("FECHA RENOVACION");
		label4.setBounds(85, 162, 161, 16);
		frame.getContentPane().add(label4);

		tfFechaRenovacion = new JTextField();
		tfFechaRenovacion.setColumns(10);
		tfFechaRenovacion.setBounds(255, 157, 130, 26);
		frame.getContentPane().add(tfFechaRenovacion);

		JLabel label1 = new JLabel("NOMBRE");
		label1.setBounds(85, 27, 117, 16);
		frame.getContentPane().add(label1);

		tfNombre = new JTextField();
		tfNombre.setColumns(10);
		tfNombre.setBounds(255, 22, 130, 26);
		frame.getContentPane().add(tfNombre);

		JLabel label5 = new JLabel("¿IMPORTACION?");
		label5.setBounds(85, 202, 117, 16);
		frame.getContentPane().add(label5);

		cbImportacion = new JCheckBox("");
		cbImportacion.setBounds(257, 198, 128, 23);
		frame.getContentPane().add(cbImportacion);

		JButton btnActualizar = new JButton("ACTUALIZAR");
		btnActualizar.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				actualizar();
				frame.dispose();
				vistaPrincipal.listarConcesionarios();
			}
		});
		btnActualizar.setBounds(289, 268, 117, 29);
		frame.getContentPane().add(btnActualizar);

		if (accion == VistaPrincipal.ACCION_CONSULTAR) {
			tfFechaRenovacion.setEditable(false);
			tfMarca.setEditable(false);
			tfNIF.setEditable(false);
			tfNombre.setEditable(false);
			cbImportacion.setEnabled(false);
			int aac = vistaPrincipal.getConcesionarioActual();

			Concesionario c = vistaPrincipal.getListaConcesionarios().get(aac);
			tfNombre.setText(c.getNombre());
			tfNIF.setText(c.getNif());
			tfMarca.setText(c.getMarca());
			tfFechaRenovacion.setText(c.getFechaRenovacion());
			if (c.isImportacion() == true) {
				cbImportacion.setSelected(true);
			} else {
				cbImportacion.setSelected(false);
			}
		} else {
			tfFechaRenovacion.setEditable(true);
			tfMarca.setEditable(true);
			tfNIF.setEditable(true);
			tfNombre.setEditable(true);
			cbImportacion.setEnabled(true);
		}

	}

	public static void centrarVentana(Window frame) {
		Dimension dimension = Toolkit.getDefaultToolkit().getScreenSize();
		int x = (int) ((dimension.getWidth() - frame.getWidth()) / 2);
		int y = (int) ((dimension.getHeight() - frame.getHeight()) / 2);
		frame.setLocation(x, y);
	}
}
