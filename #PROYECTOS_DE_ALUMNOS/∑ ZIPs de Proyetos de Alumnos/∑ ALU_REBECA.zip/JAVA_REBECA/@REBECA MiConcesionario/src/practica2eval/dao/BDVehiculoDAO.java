package practica2eval.dao;

import java.util.List;

//import org.hibernate.NonUniqueObjectException;
import org.hibernate.Session;
import org.hibernate.exception.ConstraintViolationException;
import org.hibernate.service.spi.ServiceException;

import practica2eval.dao.exception.ExcepcionDAO;
import practica2eval.dao.exception.MensajeError;
import practica2eval.dao.exception.TipoProblemaDAO;
import practica2eval.model.Vehiculo;
import practica2eval.utilfiles.HibernateUtil;

public class BDVehiculoDAO {

	protected Session session;

	protected void abrirSesion() // Para que se pueda a una super variables
	{
		try {
			session = HibernateUtil.getSessionFactory().openSession();
			session.beginTransaction();
		} catch (ServiceException e) {
			throw new ExcepcionDAO(MensajeError.getMensaje(TipoProblemaDAO.ERROR_ACCESO_BASE_DATOS_DESCONOCIDO));
		}
	}

	protected void commit() {
		session.getTransaction().commit();
	}

	protected void cerrarSesion() {
		session.close();
	}

	public void insertar(Vehiculo vehiculo) {
		abrirSesion();
		try {
			session.save(vehiculo);
			cerrarSesion();
		} catch (ConstraintViolationException e) {
			throw new ExcepcionDAO(MensajeError.getMensaje(TipoProblemaDAO.ERROR_REGISTRO_DUPLICADO));
		}
	}

	public Vehiculo buscar(String codigo) {

		Vehiculo vehi;
		abrirSesion();
		try {
			vehi = session.bySimpleNaturalId(Vehiculo.class).load(codigo);
			commit();
		} catch (NullPointerException e) {
			throw new ExcepcionDAO(MensajeError.getMensaje(TipoProblemaDAO.CONCESIONARIO_NO_ENCONTRADO));
		}
		cerrarSesion();

		return vehi;
	}

	public void eliminar(String codigo) {

		Vehiculo vehi = buscar(codigo);

		abrirSesion();

		try {
			session.delete(vehi);
			commit();
		} catch (NullPointerException e) {
			throw new ExcepcionDAO(MensajeError.getMensaje(TipoProblemaDAO.CONCESIONARIO_NO_ENCONTRADO));
		}
		cerrarSesion();
	}

	@SuppressWarnings("unchecked")
	public List<Vehiculo> mostrarVehiculos(int id) {
		abrirSesion();
		List<Vehiculo> vehiculos = session.createQuery("from Vehiculo where idConcesionario = :id")
				.setParameter("id", id).list();
		cerrarSesion();
		return vehiculos;
	}
}