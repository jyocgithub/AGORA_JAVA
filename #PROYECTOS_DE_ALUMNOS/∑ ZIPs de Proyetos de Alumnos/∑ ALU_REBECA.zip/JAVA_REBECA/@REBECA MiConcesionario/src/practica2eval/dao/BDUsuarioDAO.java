package practica2eval.dao;

import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.service.spi.ServiceException;

import practica2eval.dao.exception.ExcepcionDAO;
import practica2eval.dao.exception.MensajeError;
import practica2eval.dao.exception.TipoProblemaDAO;
import practica2eval.model.Usuario;
import practica2eval.utilfiles.HibernateUtil;

public class BDUsuarioDAO {

	protected Session session;

	protected void abrirSesion() {
		try {
			session = HibernateUtil.getSessionFactory().openSession();
			session.beginTransaction();
		} catch (ServiceException e) {
			throw new ExcepcionDAO(MensajeError.getMensaje(TipoProblemaDAO.ERROR_ACCESO_BASE_DATOS_DESCONOCIDO));
		}
	}

	protected void commit() {
		session.getTransaction().commit();
	}

	protected void cerrarSesion() {
		session.close();
	}

	@SuppressWarnings("unchecked")
	public List<Usuario> seleccionarUsuarios() {
		abrirSesion();
		List<Usuario> lista = session.createQuery("from Usuario").list();
		cerrarSesion();
		return lista;
	}

	@SuppressWarnings("unchecked")
	public Usuario seleccionarPorNombre(String nombre) {
		Usuario usuario = null;
		abrirSesion();
		Query query = session.createQuery("from Usuario where nombre = :nombre ");
		query.setParameter("nombre", nombre);
		List<Usuario> list = query.list();
		cerrarSesion();
		if (!list.isEmpty()) {
			usuario = list.get(0);
		}
		return usuario;

	}
	//
	// abrirSesion();
	// List list = query.list();
	// }

	public Usuario buscar(String nombre) {

		abrirSesion();
		Transaction tx = null;

		Usuario user = null;
		try {
			// tx = session.beginTransaction();
			user = session.get(Usuario.class, nombre);
			tx.commit();
		} catch (HibernateException e) {
			// if (tx != null) tx.rollback();
			e.printStackTrace();
		} finally {
			session.close();
			cerrarSesion();
		}

		// abrirSesion();
		// try {
		// user = session.bySimpleNaturalId(Usuario.class).load(nombre);
		// commit();
		// } catch (NullPointerException e) {
		// throw new ExcepcionDAO(MensajeError.getMensaje(TipoProblemaDAO.USUARIO_NO_ENCONTRADO));
		// }
		// cerrarSesion();

		return user;
	}

}
