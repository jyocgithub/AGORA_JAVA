package practica2eval.dao.exception;

public enum TipoProblemaDAO {
	USUARIO_NO_ENCONTRADO("Ese usuario no existe"),
	VEHICULO_NO_ENCONTRADO("Ese vehiculo no existe en la base de datos"),
	EXTRA_NO_ENCONTRADO("Ese extra no existe en la base de datos"),
	ERROR_AL_CREAR_STATEMENT ("No se pudo crear statment"),
	CONCESIONARIO_NO_ENCONTRADO("Ese concesionario no existe en la base de datos"),
	ERROR_REGISTRO_DUPLICADO("Registro duplicado"),
	ERROR_AL_CERRAR_CONEXION ("Error al cerrar la conexi�n"),
	ERROR_TABLA_NO_ENCONTRADA ("No se ha encontrado esa tabla en la base de datos."),
	ERROR_ACCESO_BASE_DATOS_DESCONOCIDO("Error desconocido de acceso a la base de datos");

	private String descripcion;

	TipoProblemaDAO(String descripcion) {
		this.descripcion = descripcion;
	}

	public String getDescripcion() {
		return this.descripcion;
	}
}