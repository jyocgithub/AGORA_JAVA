package practica2eval.dao;

import java.util.List;

import org.hibernate.Query;
//import org.hibernate.NonUniqueObjectException;
import org.hibernate.Session;
import org.hibernate.exception.ConstraintViolationException;
import org.hibernate.service.spi.ServiceException;

import practica2eval.dao.exception.ExcepcionDAO;
import practica2eval.dao.exception.MensajeError;
import practica2eval.dao.exception.TipoProblemaDAO;
import practica2eval.model.Concesionario;
import practica2eval.utilfiles.HibernateUtil;

public class BDConcesionarioDAO {

	protected Session session;

	public void abrirSesion() // Para que se pueda a una super variables
	{
		try {
			session = HibernateUtil.getSessionFactory().openSession();
			session.beginTransaction();
		} catch (ServiceException e) {
			throw new ExcepcionDAO(MensajeError.getMensaje(TipoProblemaDAO.ERROR_ACCESO_BASE_DATOS_DESCONOCIDO));
		}
	}

	public void commit() {
		session.getTransaction().commit();
	}

	public void cerrarSesion() {
		session.close();
	}

	public void insertar(Concesionario concesionario) {
		abrirSesion();
		try {
			session.save(concesionario);
		} catch (ConstraintViolationException e) {
			throw new ExcepcionDAO(MensajeError.getMensaje(TipoProblemaDAO.ERROR_REGISTRO_DUPLICADO));
		}
		cerrarSesion();
	}

	public Concesionario buscarPorId(String id) {
		Concesionario solucion = null;
		abrirSesion();
		Query query = session.createQuery("from Concesionario where idConcesionario = :id ");
		query.setParameter("id", id);
		List<Concesionario> list = query.list();
		cerrarSesion();
		if (!list.isEmpty()) {
			solucion = list.get(0);
		}
		return solucion;
	}

	public Concesionario buscar(String nif) {
		Concesionario con;
		abrirSesion();
		try {
			con = session.bySimpleNaturalId(Concesionario.class).load(nif);
			commit();
		} catch (NullPointerException e) {
			throw new ExcepcionDAO(MensajeError.getMensaje(TipoProblemaDAO.CONCESIONARIO_NO_ENCONTRADO));
		}
		cerrarSesion();
		return con;
	}

	public void eliminar(Concesionario concesionario) {
		abrirSesion();
		try {
			session.delete(concesionario);
			commit();
		} catch (NullPointerException e) {
			throw new ExcepcionDAO(MensajeError.getMensaje(TipoProblemaDAO.CONCESIONARIO_NO_ENCONTRADO));
		}
		cerrarSesion();
	}

	public void eliminarPorId(String codigo) {
		Concesionario con = buscar(codigo);
		abrirSesion();
		try {
			session.delete(con);
			commit();
		} catch (NullPointerException e) {
			throw new ExcepcionDAO(MensajeError.getMensaje(TipoProblemaDAO.CONCESIONARIO_NO_ENCONTRADO));
		}
		cerrarSesion();
	}

	@SuppressWarnings("unchecked")
	public List<Concesionario> mostrarConcesionario(String nombre) {
		abrirSesion();
		List<Concesionario> concesionarios = session.createQuery("from Concesionario").list();
		cerrarSesion();
		return concesionarios;
	}

}
