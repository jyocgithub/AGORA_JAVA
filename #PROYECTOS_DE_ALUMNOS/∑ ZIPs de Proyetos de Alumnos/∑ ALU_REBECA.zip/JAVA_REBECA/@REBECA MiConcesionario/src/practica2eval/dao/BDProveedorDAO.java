package practica2eval.dao;

import java.util.List;

//import org.hibernate.NonUniqueObjectException;
import org.hibernate.Session;
import org.hibernate.exception.ConstraintViolationException;
import org.hibernate.service.spi.ServiceException;

import practica2eval.dao.exception.ExcepcionDAO;
import practica2eval.dao.exception.MensajeError;
import practica2eval.dao.exception.TipoProblemaDAO;
import practica2eval.model.Proveedor;
import practica2eval.utilfiles.HibernateUtil;

public class BDProveedorDAO {

	protected Session session;

	protected void abrirSesion() // Para que se pueda a una super variables
	{
		try {
			session = HibernateUtil.getSessionFactory().openSession();
			session.beginTransaction();
		} catch (ServiceException e) {
			throw new ExcepcionDAO(MensajeError.getMensaje(TipoProblemaDAO.ERROR_ACCESO_BASE_DATOS_DESCONOCIDO));
		}
	}

	protected void commit() {
		session.getTransaction().commit();
	}

	protected void cerrarSesion() {
		session.close();
	}

	public void insertar(Proveedor proveedor) {
		abrirSesion();
		try {
			session.save(proveedor);
			cerrarSesion();
		} catch (ConstraintViolationException e) {
			throw new ExcepcionDAO(MensajeError.getMensaje(TipoProblemaDAO.ERROR_REGISTRO_DUPLICADO));
		}
	}

	public Proveedor buscar(String codigo) {

		Proveedor prov;
		abrirSesion();
		try {
			prov = session.bySimpleNaturalId(Proveedor.class).load(codigo);
			commit();
		} catch (NullPointerException e) {
			throw new ExcepcionDAO(MensajeError.getMensaje(TipoProblemaDAO.EXTRA_NO_ENCONTRADO));
		}
		cerrarSesion();

		return prov;
	}

	public void eliminar(String codigo) {

		Proveedor prov = buscar(codigo);

		abrirSesion();

		try {
			session.delete(prov);
			commit();
		} catch (NullPointerException e) {
			throw new ExcepcionDAO(MensajeError.getMensaje(TipoProblemaDAO.EXTRA_NO_ENCONTRADO));
		}
		cerrarSesion();
	}

	@SuppressWarnings("unchecked")
	public List<Proveedor> mostrarProveedores(int id) {
		abrirSesion();
		List<Proveedor> proveedores = session.createQuery("from Proveedor where idExtras = :id").setParameter("id", id)
				.list();
		cerrarSesion();
		return proveedores;
	}
}
