package practica2eval.dao.exception;

public class MensajeError {
	public static String getMensaje(TipoProblemaDAO tipoProblema) {
		return tipoProblema.getDescripcion();
	}

	public static String getMensajeMySQL(int codigoErrorGestor) {
		TipoProblemaDAO tipoProblema = null;
		switch (codigoErrorGestor) {
			case 1062:
				tipoProblema=TipoProblemaDAO.ERROR_REGISTRO_DUPLICADO;
				break;
			default:
				tipoProblema=TipoProblemaDAO.ERROR_ACCESO_BASE_DATOS_DESCONOCIDO;
		}
		return getMensaje(tipoProblema);
	}
}