package practica2eval.dao.exception;
//@SuppressWarnings("serial")
public class ExcepcionDAO extends RuntimeException {
	public ExcepcionDAO(String mensaje) {
		super(mensaje);
	}
}
