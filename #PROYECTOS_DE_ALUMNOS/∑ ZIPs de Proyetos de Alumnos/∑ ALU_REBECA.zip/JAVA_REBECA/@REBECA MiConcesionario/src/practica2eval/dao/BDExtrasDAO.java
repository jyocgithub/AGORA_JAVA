package practica2eval.dao;

import java.util.List;

//import org.hibernate.NonUniqueObjectException;
import org.hibernate.Session;
import org.hibernate.exception.ConstraintViolationException;
import org.hibernate.service.spi.ServiceException;

import practica2eval.dao.exception.ExcepcionDAO;
import practica2eval.dao.exception.MensajeError;
import practica2eval.dao.exception.TipoProblemaDAO;
import practica2eval.model.Extras;
import practica2eval.utilfiles.HibernateUtil;

public class BDExtrasDAO {

	protected Session session;

	protected void abrirSesion() // Para que se pueda a una super variables
	{
		try {
			session = HibernateUtil.getSessionFactory().openSession();
			session.beginTransaction();
		} catch (ServiceException e) {
			throw new ExcepcionDAO(MensajeError.getMensaje(TipoProblemaDAO.ERROR_ACCESO_BASE_DATOS_DESCONOCIDO));
		}
	}

	protected void commit() {
		session.getTransaction().commit();
	}

	protected void cerrarSesion() {
		session.close();
	}

	public void insertar(Extras extras) {
		abrirSesion();
		try {
			session.save(extras);
			cerrarSesion();
		} catch (ConstraintViolationException e) {
			throw new ExcepcionDAO(MensajeError.getMensaje(TipoProblemaDAO.ERROR_REGISTRO_DUPLICADO));
		}
	}

	public Extras buscar(String codigo) {

		Extras ex;
		abrirSesion();
		try {
			ex = session.bySimpleNaturalId(Extras.class).load(codigo);
			commit();
		} catch (NullPointerException e) {
			throw new ExcepcionDAO(MensajeError.getMensaje(TipoProblemaDAO.VEHICULO_NO_ENCONTRADO));
		}
		cerrarSesion();

		return ex;
	}

	public void eliminar(String codigo) {

		Extras ex = buscar(codigo);

		abrirSesion();

		try {
			session.delete(ex);
			commit();
		} catch (NullPointerException e) {
			throw new ExcepcionDAO(MensajeError.getMensaje(TipoProblemaDAO.VEHICULO_NO_ENCONTRADO));
		}
		cerrarSesion();
	}

	@SuppressWarnings("unchecked")
	public List<Extras> mostrarExtras(int id) {
		abrirSesion();
		List<Extras> extras = session.createQuery("from Extras where idVehiculo = :id").setParameter("id", id).list();
		cerrarSesion();
		return extras;
	}
}
