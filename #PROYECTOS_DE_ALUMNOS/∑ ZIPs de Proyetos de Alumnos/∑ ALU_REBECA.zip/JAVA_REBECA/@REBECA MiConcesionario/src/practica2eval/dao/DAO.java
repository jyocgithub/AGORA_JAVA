package practica2eval.dao;

import org.hibernate.Session;
import org.hibernate.service.spi.ServiceException;

import practica2eval.dao.exception.ExcepcionDAO;
import practica2eval.dao.exception.MensajeError;
import practica2eval.dao.exception.TipoProblemaDAO;
import practica2eval.utilfiles.HibernateUtil;

public abstract class DAO
{
	protected Session session;

	protected void abrirSesion() //Para que se pueda a una super variables
	{
		try
		{
			session = HibernateUtil.getSessionFactory().openSession();
			session.beginTransaction();
		}
		catch (ServiceException e)
		{
			throw new ExcepcionDAO(MensajeError.getMensaje(TipoProblemaDAO.ERROR_ACCESO_BASE_DATOS_DESCONOCIDO));
		}

	}

	protected void commit()
	{
		session.getTransaction().commit();
	}

	protected void cerrarSesion()
	{
		session.close();
	}
}