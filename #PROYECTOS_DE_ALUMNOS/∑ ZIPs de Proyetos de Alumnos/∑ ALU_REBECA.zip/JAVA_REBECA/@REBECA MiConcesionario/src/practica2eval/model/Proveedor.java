package practica2eval.model;

import javax.persistence.*;


import org.hibernate.annotations.NaturalId;


@Entity(name = "Proveedor")
@Table(name="Proveedor", uniqueConstraints={@UniqueConstraint(columnNames={"idProveedor"})})
public class Proveedor {
	@Id
    @GeneratedValue(strategy=GenerationType.IDENTITY) // Se pone ya que es una cifra que se autoincrementa
    @Column(name="idProveedor", nullable=false, unique=true, length=11)
	private int idProveedor;

	@NaturalId
	@Column(name="descripcion", length=40, nullable=false, unique=true)
	private String descripcion;

	@Column(name="fechaEnvio", nullable=false)
	private String fechaEnvio; 

	@ManyToOne //Engancha con Extras
	@JoinColumn(name="idExtras", foreignKey = @ForeignKey(name = "idExtrasfk"))
	private Extras extras;


	public Extras getExtras(){
		return extras;
	}

	public void setExtras(Extras extras){
		this.extras = extras;
	}

	public int getIdProveedor() {
		return idProveedor;
	}

	public void setIdProveedor(int idProveedor) {
		this.idProveedor = idProveedor;
	}

	public String getDescripcion() {
		return descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	public String getFechaEnvio() {
		return fechaEnvio;
	}

	public void setFechaEnvio(String fechaEnvio) {
		this.fechaEnvio = fechaEnvio;
	}

	public void remove(Proveedor proveedor) {
		// TODO Auto-generated method stub
		
	}

	public void add(Proveedor proveedor) {
		// TODO Auto-generated method stub
		
	}

}

