package practica2eval.model;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.*;


import org.hibernate.annotations.NaturalId;


@Entity(name = "Vehiculo")
@Table(name="Vehiculo", uniqueConstraints={@UniqueConstraint(columnNames={"idVehiculo"})})
public class Vehiculo {
	@Id
    @GeneratedValue(strategy=GenerationType.IDENTITY) // Se pone ya que es una cifra que se autoincrementa
    @Column(name="idVehiculo", nullable=false, unique=true, length=11)
	private int idVehiculo;

	@NaturalId
	@Column(name="numeroMotor", length=40, nullable=false, unique=true)
	private String numeroMotor;

	@Column(name="fechaCompra", nullable=false)
	private String fechaCompra; //aqui es fecha compra, no fecha renovacion
	
	@ManyToOne //Engancha con Concesionario
	@JoinColumn(name="idConcesionario", foreignKey = @ForeignKey(name = "idConcesionariofk"))
	private Concesionario concesionario;
	
	//Engancha con Extras
	@OneToMany(cascade = CascadeType.ALL, orphanRemoval = true, fetch = FetchType.LAZY) // ORPHANREMOVAL SIRVE PARA QUE REMUEVA VEHICULOS, FetchType.LAZY sirve para poner vehiculos en blanco aunque tenga
	@JoinColumn(name = "idVehiculo", foreignKey = @ForeignKey(name = "idVehiculofk")) //                                                   FetchType.EAGER para que muestre los vehiculos
	private Set<Extras> extras = new HashSet<>();
	
	public void eliminaExtras(Extras extras) {
		extras.remove(extras);
		extras.setVehiculo(null);
	}

	public void anadirExtras(Extras extras) {
		extras.add(extras);
		extras.setVehiculo(this);
	}

	public Set<Extras> getExtras() {
		return extras;
	}

	public void setExtras(Set<Extras> extras) {
		this.extras = extras;
	}

	public Concesionario getConcesionario(){
		return concesionario;
	}

	public void setConcesionario(Concesionario concesionario){
		this.concesionario = concesionario;
	}

	public int getIdVehiculo() {
		return idVehiculo;
	}

	public void setIdVehiculo(int idVehiculo) {
		this.idVehiculo = idVehiculo;
	}

	public String getNumeroMotor() {
		return numeroMotor;
	}

	public void setNumeroMotor(String numeroMotor) {
		this.numeroMotor = numeroMotor;
	}

	public String getFechaCompra() {
		return fechaCompra;
	}

	public void setFechaCompra(String fechaCompra) {
		this.fechaCompra = fechaCompra;
	}

}