package practica2eval.model;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.*;


import org.hibernate.annotations.NaturalId;


@Entity(name = "Extras")
@Table(name="Extras", uniqueConstraints={@UniqueConstraint(columnNames={"idExtras"})})
public class Extras {
	@Id
    @GeneratedValue(strategy=GenerationType.IDENTITY) // Se pone ya que es una cifra que se autoincrementa
    @Column(name="idExtras", nullable=false, unique=true, length=11)
	private int idExtras;

	@NaturalId
	@Column(name="descripcion", length=40, nullable=false, unique=true)
	private String descripcion;

	@Column(name="fechaFabricacion", nullable=false)
	private String fechaFabricacion; 

	@ManyToOne //Engancha con Vehiculo
	@JoinColumn(name="idVehiculo", foreignKey = @ForeignKey(name = "idVehiculofk"))
	private Vehiculo vehiculo;
	
	//Engancha con Proveedor
	@OneToMany(cascade = CascadeType.ALL, orphanRemoval = true, fetch = FetchType.LAZY) // ORPHANREMOVAL SIRVE PARA QUE REMUEVA VEHICULOS, FetchType.LAZY sirve para poner vehiculos en blanco aunque tenga
	@JoinColumn(name = "idExtras", foreignKey = @ForeignKey(name = "idExtrasfk")) //                                                       FetchType.EAGER para que muestre los vehiculos
	private Set<Proveedor> proveedor = new HashSet<>();
		
	public void eliminaProveedor(Proveedor proveedor) {
		proveedor.remove(proveedor);
		proveedor.setExtras(null);
	}

	public void anadirProveedor(Proveedor proveedor) {
		proveedor.add(proveedor);
		proveedor.setExtras(this);
	}

	public Set<Proveedor> getProveedor() {
		return proveedor;
	}

	public void setProveedor(Set<Proveedor> proveedor) {
		this.proveedor = proveedor;
	}	


	public Vehiculo getVehiculo(){
		return vehiculo;
	}

	public void setVehiculo(Vehiculo vehiculo){
		this.vehiculo = vehiculo;
	}

	public int getIdExtras() {
		return idExtras;
	}

	public void setIdExtras(int idExtras) {
		this.idExtras = idExtras;
	}

	public String getDescripcion() {
		return descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	public String getFechaFabricacion() {
		return fechaFabricacion;
	}

	public void setFechaFabricacion(String fechaFabricacion) {
		this.fechaFabricacion = fechaFabricacion;
	}


	public void remove(Extras extras) {
		// TODO Auto-generated method stub
		
	}

	public void add(Extras extras) {
		// TODO Auto-generated method stub
		
	}

}
