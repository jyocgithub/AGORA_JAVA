package practica2eval.model;

import java.util.HashSet;
import java.util.Set;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ForeignKey;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import org.hibernate.annotations.NaturalId;

@Entity(name = "Concesionario")
@Table(name = "Concesionario")
public class Concesionario {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "idConcesionario", nullable = false, unique = true, length = 11)
	private int idConcesionario;

	@NaturalId
	@Column(name = "nif", length = 9, nullable = false, unique = true)
	private String nif;

	@Column(name = "nombre", length = 100, nullable = false)
	private String nombre;

	@Column(name = "marca", length = 100, nullable = true)
	private String marca;

	@Column(name = "importacion", nullable = true)
	private boolean importacion;

	@Column(name = "fechaRenovacion", nullable = false) //renovacion de los precios por las temporadas
	private String fechaRenovacion;

	@OneToMany(cascade = CascadeType.ALL, orphanRemoval = true, fetch = FetchType.LAZY) // ORPHANREMOVAL SIRVE PARA QUE REMUEVA VEHICULOS, FetchType.LAZY sirve para poner vehiculos en blanco aunque tenga
	@JoinColumn(name = "idConcesionario", foreignKey = @ForeignKey(name = "idConcesionariofk")) //                                         FetchType.EAGER para que muestre los vehiculos
	private Set<Vehiculo> vehiculos = new HashSet<>();


	public void eliminaVehiculo(Vehiculo vehiculo) {
		vehiculos.remove(vehiculo);
		vehiculo.setConcesionario(null);
	}

	public void anadirVehiculo(Vehiculo vehiculo) {
		vehiculos.add(vehiculo);
		vehiculo.setConcesionario(this);
	}

	public Set<Vehiculo> getVehiculos() {
		return vehiculos;
	}

	public void setVehiculos(Set<Vehiculo> vehiculos) {
		this.vehiculos = vehiculos;
	}

	public int getIdConcesionario() {
		return idConcesionario;
	}

	public void setIdConcesionario(int idConcesionario) {
		this.idConcesionario = idConcesionario;
	}

	public String getNif() {
		return nif;
	}

	public void setNif(String nif) {
		this.nif = nif;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getMarca() {
		return marca;
	}

	public void setMarca(String marca) {
		this.marca = marca;
	}

	public boolean isImportacion() {
		return importacion;
	}

	public void setImportacion(boolean importacion) {
		this.importacion = importacion;
	}

	public String getFechaRenovacion() {
		return fechaRenovacion;
	}

	public void setFechaRenovacion(String fechaRenovacion) {
		this.fechaRenovacion = fechaRenovacion;
	}

}