package practica2eval.model;

import javax.persistence.*;


import org.hibernate.annotations.NaturalId;


@Entity(name = "Usuario")
@Table(name="Usuario", uniqueConstraints={@UniqueConstraint(columnNames={"idUsuario"})})
public class Usuario {
	@Id
    @GeneratedValue(strategy=GenerationType.IDENTITY) // Se pone ya que es una cifra que se autoincrementa
    @Column(name="idUsuario", nullable=false, unique=true, length=11)
	private int idUsuario;

	@NaturalId
	@Column(name="nombre", length=20, nullable=false, unique=true)
	private String nombre;

	@Column(name="password", nullable=false)
	private String password; 
	
	public int getIdUsuario() {
		return idUsuario;
	}

	public void setIdUsuario(int idUsuario) {
		this.idUsuario = idUsuario;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

}
