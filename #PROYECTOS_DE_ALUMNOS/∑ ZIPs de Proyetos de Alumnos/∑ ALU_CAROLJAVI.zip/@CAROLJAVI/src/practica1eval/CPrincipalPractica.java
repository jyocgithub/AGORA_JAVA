package practica1eval;

import practica1eval.dao.FileBDAlumnoDAO;
import practica1eval.model.Alumno;
import practica1eval.dao.XMLBDAlumnoDAO;

import org.w3c.dom.Document;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class CPrincipalPractica {
    public static Map<String, Alumno> hm = new HashMap<>();


    public static void main(String[] args) {

        Alumno pipi = new Alumno("22222222-B", "pipi");
        Alumno ana = new Alumno("55555555-A", "Ana");
        Alumno abel = new Alumno("77777777-B", "Abel");
        Alumno andres = new Alumno("88888888-C", "Andres");
        Alumno alvaro = new Alumno("99999999-D", "Alvaro");
        Alumno alumnoFallo = new Alumno("44444444-D", "Erroneo");

        // ------------------------------PRUEBAS DE FileBDAlumnoDAO------------------------------
        // CREAR OBJETO DE XMLDBAlumnoDAO

        XMLBDAlumnoDAO xmldao = new XMLBDAlumnoDAO();
        System.out.println("___________________________");
//
//		// INSERTAR ALUMNO - FUNCIONA
//		xmldao.insertaAlumno(abel);

        System.out.println("___________________________");

        // BORRAR ALUMNO - FUNCIONA
//		xmldao.borraAlumno("22222222-B");

//		// MODIFICA ALUMNO - FUNCIONA
//		xmldao.modificaAlumno("44444444-D", alvaro);

        System.out.println("___________________________");

        // BUSCA ALUMNO

        Alumno alu = xmldao.buscaAlumno("44444444-D");
        mostrarAlumno(alu);

        System.out.println("___________________________");
        // LISTA ALUMNOS
        ArrayList<Alumno> lista = (ArrayList<Alumno>) xmldao.listadoAlumnos();
        for (Alumno a : lista) {
            mostrarAlumno(a);
        }

        System.out.println("___________________________");
        // LISTA MAP ALUMNOS
        HashMap<String, Alumno> mapa = (HashMap<String, Alumno>) xmldao.listadoMapAlumnos();
        for (Alumno a : mapa.values()) {
            mostrarAlumno(a);
        }
        System.out.println("___________________________");


    }

    private static void mostrarFichero(FileBDAlumnoDAO fich) {
        hm = fich.listadoMapAlumnos();

        //20.11
//		if(hm.isEmpty())
        if (!hm.isEmpty()) {
            for (String DNI : hm.keySet()) {
                System.out.println(DNI + "#" + (hm.get(DNI)).getNombre());
            }
        } else System.out.println("No hay alumnos");

        System.out.println();
    }

    private static void mostrarAlumno(Alumno alumno) {
        if (alumno != null)
            System.out.println("Nombre: " + alumno.getNombre() + "\nDNI: " + alumno.getDni() + "\n");

        else System.out.println("No existe alumno con ese DNI\n");
    }
}
