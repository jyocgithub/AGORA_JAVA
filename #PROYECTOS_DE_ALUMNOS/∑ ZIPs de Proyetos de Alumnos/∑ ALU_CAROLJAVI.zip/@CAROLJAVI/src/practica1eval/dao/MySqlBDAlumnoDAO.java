package practica1eval.dao;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import practica1eval.dao.exception.MensajeError;
import practica1eval.idao.AlumnoDAO;
import practica1eval.dao.exception.ExcepcionDAO;
import practica1eval.model.Alumno;

//TODO

public class MySqlBDAlumnoDAO implements AlumnoDAO {
    HashMap<String, String> hm = null;
    Connection conexion = null;

    public MySqlBDAlumnoDAO() throws IOException {
        hm = new HashMap<>();
    }

    public void conectar() {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            conexion = DriverManager.getConnection("jdbc:mysql://localhost:3306/BDAlumnos", "root", "");
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void cerrar() {
        try {
            if (conexion != null)
                conexion.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public Alumno buscaAlumno(String DNI) {
        Alumno alumno = null;
        try {
            conectar();
            Statement instruccion = conexion.createStatement();
            String sql = "select * from alumno where dni='" + DNI + "'";
            ResultSet cursor = instruccion.executeQuery(sql);
            if (cursor.first()) {
                String eldni = cursor.getString("dni");
                String elnombre = cursor.getString("nombre");
                alumno = new Alumno(eldni, elnombre);
                return alumno;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            cerrar();
        }
        return alumno;
    }


    public List<Alumno> listadoAlumnos() {
        ArrayList<Alumno> lista = new ArrayList<>();
        try {
            conectar();
            Statement instruccion = conexion.createStatement();
            String sql = "select * from Alumnos";
            ResultSet cursor = instruccion.executeQuery(sql);

            while (cursor.next()) {
                int id = cursor.getInt("id");
                String nombre = cursor.getString("nombre");
                Alumno a = new Alumno(id + "", nombre);
                lista.add(a);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            cerrar();
        }
        return lista;
    }


    /**
     * Almacena las lineas de un fichero en un ArrayList<String> y lo devuelve
     *
     * @return
     */
    public Map<String, Alumno> listadoMapAlumnos() throws ExcepcionDAO {
        HashMap<String, Alumno> mapa = new HashMap<>();
        try {
            conectar();
            Statement instruccion = conexion.createStatement();
            String sql = "select * from Alumnos";
            ResultSet cursor = instruccion.executeQuery(sql);

            while (cursor.next()) {
                int id = cursor.getInt("id");
                String nombre = cursor.getString("nombre");
                Alumno a = new Alumno(id + "", nombre);
                mapa.put(id + "", a);
            }
        } catch (SQLException e) {
            throw new ExcepcionDAO(MensajeError.getMensajeMySQL(e.getErrorCode()) + " \nCodigo de error: " + e.getErrorCode());
        } finally {
            cerrar();
        }
        return mapa;
    }

    @Override
    public boolean insertaAlumno(Alumno alumno) {
        try {
            conectar();
            Statement instruccion = conexion.createStatement();
            String sql = "insert into alumno values('!" + alumno.getDni() + "', '" + alumno.getNombre() + "')";
            instruccion.executeUpdate(sql);
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            cerrar();
        }
        return false;
    }

    @Override
    public Alumno borraAlumno(String DNI) {
        Alumno alumno = null;
        try {
            conectar();
            Statement instruccion = conexion.createStatement();
            alumno = buscaAlumno(DNI);
            if (alumno != null) {
                String sql = "delete from alumno where dni='" + DNI + "'";
                instruccion.executeUpdate(sql);
                return alumno;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            cerrar();
        }
        return alumno;
    }


    @Override
    public boolean modificaAlumno(String DNI, Alumno alumno) {
        try {
            conectar();
            Statement instruccion = conexion.createStatement();
            alumno = buscaAlumno(DNI);
            if (alumno != null) {
                String sql = "UPDATE alumno SET (dni='" + alumno.getDni() + "', nombre = '" + alumno.getNombre() + "'";
                instruccion.executeUpdate(sql);
                return true;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            cerrar();
        }
        return false;
    }
}
