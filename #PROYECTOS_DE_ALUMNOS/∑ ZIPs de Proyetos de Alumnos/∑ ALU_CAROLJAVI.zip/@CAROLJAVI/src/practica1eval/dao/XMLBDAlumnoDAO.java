package practica1eval.dao;

import java.io.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.*;

import com.sun.org.apache.xml.internal.serialize.OutputFormat;
import com.sun.org.apache.xml.internal.serialize.XMLSerializer;

import org.xml.sax.SAXException;
import practica1eval.dao.exception.ExcepcionDAO;
import practica1eval.idao.AlumnoDAO;
import practica1eval.model.Alumno;

public class XMLBDAlumnoDAO implements AlumnoDAO {
    private String nombreFicheroXML = "Alumnos.xml";
    private Document documentEntrada, documentSalida;
    private DocumentBuilderFactory builderFactory;
    private DocumentBuilder builder;
    private Element rootElement;

    private String nombre, dni;
    private Node nodoe_raiz, nodos_raiz, nodo_alumnos, nodo_alumno, nodo_dni, nodo_nombre, nodo_nombre_texto, nodo_dni_texto;
    private Node nodos_alumno, nodos_nombre, nodos_dni, nodos_alumnos;
    private Node nodos_nombre_texto, nodos_dni_texto;


    // ***************************************************************************
    public Document leerFicheroXmlEnDocumentDOM() {


        Document document = null;
        try {
            DocumentBuilderFactory builderFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder builder = builderFactory.newDocumentBuilder();
            document = builder.parse(new FileInputStream(nombreFicheroXML));
        } catch (Exception e1) {
            e1.printStackTrace();
        }
        return document;
    }

    // ***************************************************************************
    public void guardarDocumentoDOMcomoXML(Document pdoc, String nombreFicheroXML) {
        try {
            File archivo_xml = new File(nombreFicheroXML);
            OutputFormat format = new OutputFormat(pdoc);
            format.setIndenting(true);
            XMLSerializer serializer = new XMLSerializer(new FileOutputStream(archivo_xml), format);
            serializer.serialize(pdoc);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // ***************************************************************************
    public static Document crearNuevoDocumentoDOM(String nombreNodoRaiz) {
        DocumentBuilder builder = null;
        Document document = null;
        try {
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            builder = factory.newDocumentBuilder();
            DOMImplementation implementation = builder.getDOMImplementation();
            document = implementation.createDocument(null, nombreNodoRaiz, null);
        } catch (ParserConfigurationException e) {
            e.printStackTrace();
        }
        return document;
    }


    // ***************************************************************************
    @Override
    public boolean insertaAlumno(Alumno alumnoNuevo) {
        if (crearDocuments()) {
            try {
                NodeList listaAlumnos = ((Element) nodoe_raiz).getElementsByTagName("alumno");  // cogemos los hijos directos de personal
                for (int t = 0; t < listaAlumnos.getLength(); t++) {
                    nodo_alumno = listaAlumnos.item(t);
                    nombre = getValorNodoHijoSimple("nombre", nodo_alumno);
                    dni = getValorNodoHijoSimple("dni", nodo_alumno);

                    crearNodoEnCopia();
                }
                // ahora ademas  se añade el alumno nuevo
                nombre = alumnoNuevo.getNombre();
                dni = alumnoNuevo.getDni();
                crearNodoEnCopia();
            } catch (Exception e) {
                e.printStackTrace();
            }
            File fentrada = new File(nombreFicheroXML);
            fentrada.delete();
            guardarDocumentoDOMcomoXML(documentSalida, nombreFicheroXML);
            return true;
        }
        return false;
    }


    // ***************************************************************************
    @Override
    public Alumno borraAlumno(String dniabuscar) {
            Alumno respuesta = null;
        if (leerSoloDocumentInicial()) {
            try {
                crearDocuments();
                NodeList listaAlumnos = ((Element) nodoe_raiz).getElementsByTagName("alumno");  // cogemos los hijos directos de personal
                for (int t = 0; t < listaAlumnos.getLength(); t++) {
                    nodo_alumno = listaAlumnos.item(t);

                    nombre = getValorNodoHijoSimple("nombre", nodo_alumno);
                    dni = getValorNodoHijoSimple("dni", nodo_alumno);
                    if (dni.equalsIgnoreCase(dniabuscar)) {
                        respuesta = new Alumno(dni, nombre);
                    } else {
                        crearNodoEnCopia();
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }

            File fentrada = new File(nombreFicheroXML);
            fentrada.delete();
            guardarDocumentoDOMcomoXML(documentSalida, nombreFicheroXML);
        }
        return respuesta;
    }

    @Override
    public Alumno buscaAlumno(String DNI) {
            Alumno respuesta = null;
        if (leerSoloDocumentInicial()) {

            try {
                NodeList listaAlumnos = ((Element) nodoe_raiz).getElementsByTagName("alumno");  // cogemos los hijos directos de personal

//            for (int t = 0; t < listaAlumnos.getLength(); t++) {
                for (int t = 0; t < listaAlumnos.getLength() && respuesta == null; t++) {
                    nodo_alumno = listaAlumnos.item(t);
                    nombre = getValorNodoHijoSimple("nombre", nodo_alumno);
                    dni = getValorNodoHijoSimple("dni", nodo_alumno);
                    if (dni.equalsIgnoreCase(DNI)) {
                        respuesta = new Alumno(dni, nombre);
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }

        }
        return respuesta;
    }

    @Override
    public boolean modificaAlumno(String dniabuscar, Alumno alumno) {
        boolean res = false;
        if (crearDocuments()) {
            try {
                crearDocuments();

                NodeList listaAlumnos = ((Element) nodoe_raiz).getElementsByTagName("alumno");  // cogemos los hijos directos de personal

                for (int t = 0; t < listaAlumnos.getLength(); t++) {
                    nodo_alumno = listaAlumnos.item(t);

                    nombre = getValorNodoHijoSimple("nombre", nodo_alumno);
                    dni = getValorNodoHijoSimple("dni", nodo_alumno);
                    if (dni.equalsIgnoreCase(dniabuscar)) {
//                    dni = alumno.getDni();
                        nombre = alumno.getNombre();
                        res = true;
                    }
                    crearNodoEnCopia();
                }
            } catch (Exception e) {
                e.printStackTrace();
            }

            File fentrada = new File(nombreFicheroXML);
            fentrada.delete();
            guardarDocumentoDOMcomoXML(documentSalida, nombreFicheroXML);
        }
        return res;
    }

    @Override
    public List<Alumno> listadoAlumnos() {
        ArrayList<Alumno> respuesta = new ArrayList<>();
        if (leerSoloDocumentInicial()) {
            Alumno alu;
            try {
                NodeList listaAlumnos = ((Element) nodoe_raiz).getElementsByTagName("alumno");  // cogemos los hijos directos de personal
                for (int t = 0; t < listaAlumnos.getLength(); t++) {
                    nodo_alumno = listaAlumnos.item(t);
                    nombre = getValorNodoHijoSimple("nombre", nodo_alumno);
                    dni = getValorNodoHijoSimple("dni", nodo_alumno);
                    alu = new Alumno(dni, nombre);
                    respuesta.add(alu);
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return respuesta;
    }

    @Override
    public Map<String, Alumno> listadoMapAlumnos() {
        HashMap<String, Alumno> respuesta = new HashMap<>();
        if (leerSoloDocumentInicial()) {
            Alumno alu;
            try {
                NodeList listaAlumnos = ((Element) nodoe_raiz).getElementsByTagName("alumno");  // cogemos los hijos directos de personal
                for (int t = 0; t < listaAlumnos.getLength(); t++) {
                    nodo_alumno = listaAlumnos.item(t);
                    nombre = getValorNodoHijoSimple("nombre", nodo_alumno);
                    dni = getValorNodoHijoSimple("dni", nodo_alumno);
                    alu = new Alumno(dni, nombre);
                    respuesta.put(dni, alu);
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return respuesta;
    }


    public String getValorNodoHijoSimple(String etiquetaABuscar, Element elementoPadre) {
        String resultado = "";
        // sacar una lista de todos los nodo-etiqueta que se llame "etiquetaABuscar" y sea hijo de "elementoPadre"
        // con el ejemplo, esto da una lista de elementos <nombre>
        NodeList listaNodosHijos = elementoPadre.getElementsByTagName(etiquetaABuscar);
        // sacar el unico nodo-etiqueta que tiene esa lista (se sabe que el nodo es simple)
        // con el ejemplo, esto da el unico elemento <nombre> que existe
        Node nodo = listaNodosHijos.item(0);
        // sacar del nodo-etiqueta su único hijo, que es el CONTENIDO de la etiqueta (que sigue siendo un nodo...)
        // en el ejemplo, es Pepe, pero con formato de nodo
        if (nodo != null) {
            Node contenido = nodo.getFirstChild();
            // sacar del nodo-contenido su valor
            // en el ejemplo, ahora si, la cadena "Pepe"
            resultado = contenido.getNodeValue();
        }
        return resultado;
    }

    /**
     * getNodoSimple
     * Version sobrecargada, con Node en vez de Element
     */
    public String getValorNodoHijoSimple(String etiquetaABuscar, Node nodoPadre) {
        Element elementoPadre = (Element) nodoPadre;
        return getValorNodoHijoSimple(etiquetaABuscar, elementoPadre);
    }

    public String getValorAtributo(String atributoABuscar, Node nodoPadre) {
        String resultado = "";
        NamedNodeMap nnm = nodoPadre.getAttributes();
        Node attr = nnm.getNamedItem(atributoABuscar);
        if (attr != null) {
            resultado = attr.getNodeValue();
        }
        return resultado;
    }


    public void crearNodoEnCopia() {
        nodos_alumno = documentSalida.createElement("alumno");
        nodos_nombre = documentSalida.createElement("nombre");
        nodos_dni = documentSalida.createElement("dni");

        nodos_nombre_texto = documentSalida.createTextNode(nombre);
        nodos_dni_texto = documentSalida.createTextNode(dni);

        nodos_nombre.appendChild(nodos_nombre_texto);
        nodos_dni.appendChild(nodos_dni_texto);
        nodos_alumno.appendChild(nodos_nombre);
        nodos_alumno.appendChild(nodos_dni);
        nodos_raiz.appendChild(nodos_alumno);
    }

    public boolean crearDocuments() {
        boolean respuesta = false;
        File f = new File(nombreFicheroXML);
        if (f.exists()) {
            respuesta = true;
            documentEntrada = leerFicheroXmlEnDocumentDOM();
            nodoe_raiz = documentEntrada.getDocumentElement();

            String valorNodoRaizEntrada = nodoe_raiz.getNodeName();
            documentSalida = crearNuevoDocumentoDOM(valorNodoRaizEntrada);

            nodos_raiz = documentSalida.getDocumentElement();
        }
        return respuesta;
    }

    public boolean leerSoloDocumentInicial() {
        boolean respuesta = false;
        File f = new File(nombreFicheroXML);
        if (f.exists()) {
            respuesta = true;
            documentEntrada = leerFicheroXmlEnDocumentDOM();
            nodoe_raiz = documentEntrada.getDocumentElement();
        }
        return respuesta;
    }
}
