package practica1eval.dao.exception;

public enum TipoProblemaDAO {
	ERROR_CONEXION("No se puede conectar a la base de datos seleccionada"),
	ERROR_REGISTRO_DUPLICADO("Registro duplicado"),
	ERROR_FICHERO_NO_ENCONTRADO("Fichero no encontrado"),
	ERROR_ACCESO_BASE_DATOS_DESCONOCIDO("Error desconocido de acceso a la base de datos"),
	ERROR_IO("Error de entrada/salida");

	private String descripcion;

	TipoProblemaDAO(String descripcion) {
		this.descripcion=descripcion;
	}

	public String getDescripcion() {
		return this.descripcion;
	}
}