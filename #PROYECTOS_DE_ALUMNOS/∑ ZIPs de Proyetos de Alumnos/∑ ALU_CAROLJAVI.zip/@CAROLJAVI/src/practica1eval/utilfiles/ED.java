package practica1eval.utilfiles;
import java.io.*;

/**
 * Clase Estructura de Datos.
 * Contiene un atributo File (que puede tratarse de un fichero o un directorio)
 * y un atributo String que corresponde a la ruta del File
 *
 * @author Carolina
 *
 */

public abstract class ED
{
	protected File f = null;
	protected String ruta;

	/**
	 * Constructor que recibe un String con la ruta que queremos darle al fichero o directorio,
	 * la guarda en su atributo y crea el objeto File
	 *
	 * @param r
	 */
	public ED(String r)
	{
		ruta = r;
		f = new File(r);
	}

	public File getFile()
	{
		return f;
	}

	public void setFile(File f)
	{
		this.f = f;
	}

	/**
	 * Devuelve el valor del atributo ruta
	 * @param ed
	 * @return String
	 */
	public String getRuta()
	{
		return ruta;
	}

	/**
	 * Renombra el fichero o directorio con el String que recibe como parametro.
	 *
	 * @param destino
	 * @return true si lo ha renombrado, sino false.
	 */
	public boolean renombrar(String destino)
	{//TODO REVISAR
		boolean renombrado = false;

		if (f.exists())
		{
			File fDestino = new File(destino);
			renombrado = f.renameTo(fDestino);
			actualizarRuta();
		}

		return renombrado;
	}

	/**
	 * Renombra el fichero o directorio con el nombre del fichero que recibe como parametro.
	 *
	 * @param destino
	 * @return boolean true si ha renombrado, sino false.
	 */
	public boolean renombrar(File fDestino)
	{
		boolean renombrado = false;

		if (f.exists())
		{
			f.delete();

			renombrado = fDestino.renameTo(f);
			//f=fDestino;
//			actualizarRuta();
			//f.delete();
		}

		return renombrado;
	}

	/**
	 * Actualiza el atributo ruta. Es �til cuando hemos renombrado un fichero o directorio.
	 */
	public void actualizarRuta()
	{
		ruta = f.getAbsolutePath();
	}

	public abstract void crearFichero() throws IOException;

}
