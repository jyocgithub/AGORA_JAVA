package practica1eval.utilfiles;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.HashMap;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.DOMImplementation;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;

import com.sun.org.apache.xml.internal.serialize.OutputFormat;
import com.sun.org.apache.xml.internal.serialize.XMLSerializer;

import practica1eval.dao.exception.ExcepcionDAO;

public class XMLPersonal
{
	public static Document crearDocumento(HashMap<String, String> hashmap, String nombreXML)
	{

		DocumentBuilder builder = null;
		Document miDocDom = null;
		try
		{

			DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
			builder = factory.newDocumentBuilder();
			DOMImplementation implementation = builder.getDOMImplementation();
			
			
			miDocDom = implementation.createDocument(null, nombreXML, null);
			
			
			// ------- RAMA DE PERSONAL DEL XML
			// -- crea ETIQUETA PERSONAL
			Element raiz = miDocDom.getDocumentElement();

			for (String clavedni : hashmap.keySet())
			{
				Element etalumno = miDocDom.createElement("alumno");
				Element etnombre = miDocDom.createElement("nombre");
				Element etdni = miDocDom.createElement("dni");
				Node valordni = miDocDom.createTextNode(clavedni);
				Node valornombre = miDocDom.createTextNode(hashmap.get(clavedni));

				etalumno.appendChild(etdni);
				etalumno.appendChild(etnombre);

				etdni.appendChild(valordni);
				etnombre.appendChild(valornombre);

				raiz.appendChild(etalumno);

			}

		}
		catch (ParserConfigurationException e)
		{
			e.printStackTrace();
		}
		return miDocDom;
	}

	public static void guardarDocumentoDOMcomoXML(Document miDocumentoDom, String nombreFicheroXML)
	{
		try
		{
			// Crea un File con el nombre del parametro del m�todo
			File archivo_xml = new File(nombreFicheroXML);
			// Especifica el formato de salida, que es en realidad el objeto
			// Document creado en el m�todo anterior a este
			OutputFormat miFormato = new OutputFormat(miDocumentoDom);
			// Especifica ademas que la salida est� indentada, esto es, con
			// formato indentado
			miFormato.setIndenting(true);
			// Escribe (fisicamente) el contenido en el FILE. Para ello crea
			// primero un objeto serializador, con el File y el format creados
			FileOutputStream fos = new FileOutputStream(archivo_xml);
			XMLSerializer serializer = new XMLSerializer(fos, miFormato);
			// y finalmente ejecuta la serializacion
			serializer.serialize(miDocumentoDom);
		}
		catch (IOException e)
		{
			throw new ExcepcionDAO(e.getMessage());
		}
	}
}
