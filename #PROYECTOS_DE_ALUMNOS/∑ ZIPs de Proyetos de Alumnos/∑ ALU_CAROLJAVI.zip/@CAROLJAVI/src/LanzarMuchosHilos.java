import com.sun.tools.doclets.formats.html.SourceToHTMLConverter;

import java.util.Scanner;


public class LanzarMuchosHilos {


    public static void main(String[] args) {

        System.out.println("Dime numero de hilos");
        int numero = new Scanner(System.in).nextInt();

        HiloGuay[] miarray= new HiloGuay[numero];

        HiloGuay h1;
        for (int i = 0; i < numero; i++) {
            h1 = new HiloGuay(i);
            miarray[i]=h1;
            h1.start();
        }

        for (int i = 0; i < numero; i++) {
            try {
                miarray[i].join();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }


        System.out.println("FIN");
    }

}


class HiloGuay extends Thread{
    int id;

    public HiloGuay(int id) {
        this.id = id;
    }

    public void run(){

        System.out.println(" hola soy "+id);

    }


}