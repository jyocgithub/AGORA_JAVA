public class MainPingPong {


    public static void main(String[] args) {


        Compartida c = new Compartida();

        HiloEscribePing h1 = new HiloEscribePing(c);
        HiloEscribePong h2 = new HiloEscribePong(c);

        Thread t1 = new Thread(h1);
        Thread t2 = new Thread(h2);

        t1.start();
        t2.start();




//        Compartida c = new Compartida();
//
//        Thread tt1 = new Thread(new HiloEscribePing(c));
//        Thread tt2 = new Thread(new HiloEscribePong(c));
//
//        tt1.start();
//        tt2.start();

    }


}



class HiloEscribePing implements Runnable{
    Compartida compartida;

    public HiloEscribePing(Compartida compartida) {
        this.compartida = compartida;
    }

    @Override
    public void run() {
        while(true) {
            compartida.ponerPing();
        }
    }
}

class HiloEscribePong implements Runnable{
    Compartida compartida;

    public HiloEscribePong(Compartida compartida) {
        this.compartida = compartida;
    }

    @Override
    public void run() {
        while(true){
            compartida.ponerPong();
        }
    }
}

class Compartida{

    int turno=0;

    public synchronized void ponerPing(){
        try {
            if(turno==0) {
                wait();
            }
        } catch (InterruptedException e) {
            e.printStackTrace();
        }


        System.out.println("PING");
        turno =0;
        notifyAll();


    }
    public synchronized void ponerPong(){

        try {
            if(turno==1) {
                wait();
            }
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        System.out.println("....... PONG");
        turno=1;
        notifyAll();

    }
}