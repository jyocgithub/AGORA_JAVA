import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

/*
Escribe un programa que lea dos nombres de ficheros de texto como argumentos de ejecución. El
programa creará un fichero con el nombre especificado en segundo lugar. Este fichero creado tendrá el
mismo contenido que el fichero especificado en primer lugar, pero con la palabra más frecuente en
mayúsculas.

* El fichero original sólo contendrá minúsculas.
* Ejemplo de ejecución:
#java Main palabras.txt nuevo.txt
 */

public class CambiarFicheroPalabraMasHabitual {
	public static void main(String args[]) {
		if (args.length != 2) {
			System.out.println("Numero de parametros incorrecto.");
			return;
		}

		try {
			File f = new File(args[0]);
			File f2 = new File(args[1] + ".new");
			Scanner sc = new Scanner(f);
			ArrayList<Palabra> ar = new ArrayList<>();
			BufferedWriter bw = new BufferedWriter(new FileWriter(f2));

			int posicion = -1;

			while (sc.hasNext()) {
				for (String s : sc.nextLine().split(" ")) {

					if (ar.contains(new Palabra(s))) {
						posicion = ar.indexOf(new Palabra(s));
						Palabra p = ar.get(posicion);
						p.setCont(p.getCont() + 1);
					} else {
						ar.add(new Palabra(s));
					}
				}
			}

			Collections.sort(ar);
			String palMax = " ";

			palMax = (ar.get(ar.size() - 1)).getNombre();

			sc.close();
			sc = new Scanner(f);

			while (sc.hasNext()) {
				bw.write(sc.nextLine().replaceAll(palMax, palMax.toUpperCase()));
			}

			sc.close();
			bw.close();

		} catch (FileNotFoundException e) {
			System.out.println("Fichero no encontrado.");
			e.printStackTrace();
		} catch (IOException e) {
			System.out.println("Error al leer el fichero");
			e.printStackTrace();
		}

	}
}

class Palabra implements Comparable<Palabra> {
	private String nombre;
	private Integer cont;

	public Palabra(String nombre) {
		this.nombre = nombre;
		cont = 1;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nom) {
		nombre = nom;
	}

	public Integer getCont() {
		return cont;
	}

	public void setCont(int c) {
		cont = c;
	}

	@Override
	public boolean equals(Object o) {
		Palabra p = (Palabra) o;

		return p.getNombre().equalsIgnoreCase(nombre);
	}

	@Override
	public int compareTo(Palabra p) {
		return p.getCont().compareTo(cont);
	}

	@Override
	public int hashCode() {
		return nombre.hashCode();
	}
}
