import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.HashMap;
import java.util.Scanner;

public class Censor {

	public static void main(String[] args) {
		HashMap<String, String> hm = new HashMap<>();
		HashMap<String, Integer> hm1 = new HashMap<>();

		hm.put("cabron", "carambanos");
		hm.put("puton", "promiscua");
		hm.put("negro", "de color");
		hm.put("David Pelaez", "no capacitado");

		File f = new File(args[0]);
		String nombrefich = args[0].substring(0, args[0].lastIndexOf("."));

		File f1 = new File(nombrefich + ".censurado");
		Scanner sc = null;
		BufferedWriter bw = null;

		try {
			sc = new Scanner(f);
			bw = new BufferedWriter(new FileWriter(f1));
			String linea;
			String linea2 = null;

			while (sc.hasNext()) {
				linea = sc.nextLine();
				linea2 = linea;
				for (String s : hm.keySet()) {
					if (linea.contains(s)) linea2 = linea2.replaceAll(s, hm.get(s));
				}

				bw.write(linea2);

			}

			sc.close();
			bw.close();
		} catch (FileNotFoundException e) {
			System.out.println("Fichero no encontrado");
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

}
