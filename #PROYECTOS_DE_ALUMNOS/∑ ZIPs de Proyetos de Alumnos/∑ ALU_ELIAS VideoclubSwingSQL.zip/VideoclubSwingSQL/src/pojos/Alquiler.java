
package pojos;

public class Alquiler {
     
     
     private int codCliente, codPeli;

     public Alquiler(int codCliente, int codPeli) {
          this.codCliente = codCliente;
          this.codPeli = codPeli;
     }

     public int getCodCliente() {
          return codCliente;
     }

     public void setCodCliente(int codCliente) {
          this.codCliente = codCliente;
     }

     public int getCodPeli() {
          return codPeli;
     }

     public void setCodPeli(int codPeli) {
          this.codPeli = codPeli;
     }
     
     
     
     
}
