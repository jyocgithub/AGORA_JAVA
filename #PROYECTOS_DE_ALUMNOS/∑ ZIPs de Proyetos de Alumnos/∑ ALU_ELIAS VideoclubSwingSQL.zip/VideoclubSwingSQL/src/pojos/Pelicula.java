/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pojos;


public class Pelicula {
    int cod_peli, disponibles;
    String genero, argumento;

    public Pelicula(int cod_peli, int disponibles, String genero, String argumento) {
        this.cod_peli = cod_peli;
        this.disponibles = disponibles;
        this.genero = genero;
        this.argumento = argumento;
    }

    public int getCod_peli() {
        return cod_peli;
    }

    public void setCod_peli(int cod_peli) {
        this.cod_peli = cod_peli;
    }

    public int getDisponibles() {
        return disponibles;
    }

    public void setDisponibles(int disponibles) {
        this.disponibles = disponibles;
    }

    public String getGenero() {
        return genero;
    }

    public void setGenero(String genero) {
        this.genero = genero;
    }

    public String getArgumento() {
        return argumento;
    }

    public void setArgumento(String argumento) {
        this.argumento = argumento;
    }

    @Override
    public String toString() {
        return "Pelicula{" + "cod_peli=" + cod_peli + ", disponibles=" + disponibles + ", genero=" + genero + ", argumento=" + argumento + '}';
    }
    
}
