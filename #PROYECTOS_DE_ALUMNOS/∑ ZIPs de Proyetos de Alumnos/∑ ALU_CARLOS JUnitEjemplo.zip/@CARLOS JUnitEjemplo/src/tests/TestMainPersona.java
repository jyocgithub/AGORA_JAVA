package tests;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

public class TestMainPersona {

	@Test
	public void testMayorEdad() {
		System.out.println("TEST 1");

		GestionPersonas m = new GestionPersonas();
		m.crearArray();
		int mayorReal = m.mayorEdad();
		int mayorEsperado = 59;
		assertEquals(mayorReal, mayorEsperado);
	}

	@Test
	public void testQuienMayorEdad() {
		System.out.println("TEST 2");
		GestionPersonas m = new GestionPersonas();
		m.crearArray();
		Persona personaMayor = m.quienMayorEdad();

		// Persona personaMayorEsperada = m.arrPersonas[3];
		Persona personaMayorEsperada = new Persona("Luis", 59);
		assertEquals(personaMayor, personaMayorEsperada);
	}

}
