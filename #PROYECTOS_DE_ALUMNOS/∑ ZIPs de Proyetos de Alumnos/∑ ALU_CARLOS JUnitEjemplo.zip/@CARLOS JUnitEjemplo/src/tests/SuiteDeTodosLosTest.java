package tests;

import junit.framework.TestSuite;

//@RunWith(Suite.class)
//@Suite.SuiteClasses({ TestMainPersona.class, TestMainPersona2.class })
public class SuiteDeTodosLosTest {
	public static TestSuite suite() {
		TestSuite suite = new TestSuite(SuiteDeTodosLosTest.class.getName()); // $JUnit-BEGIN$
																				// suite.addTestSuite(W84bFuncionesTest2.class);
																				// suite.addTestSuite(StringArrayUtilsClassesTest.class);
																				// //$JUnit-END$
		return suite;
	}
}
