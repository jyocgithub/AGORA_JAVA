package tests;

public class GestionPersonas {

	Persona[] arrPersonas;

	public void crearArray() {
		arrPersonas = new Persona[3];
		arrPersonas[0] = new Persona("Pepe", 23);
		arrPersonas[1] = new Persona("Ana", 11);
		arrPersonas[2] = new Persona("Luis", 59);
	}

	public int mayorEdad() {
		int mayor = arrPersonas[0].getEdad();
		for (Persona p : arrPersonas) {
			if (p.getEdad() > mayor) {
				mayor = p.getEdad();
			}
		}
		return mayor;
	}

	public Persona quienMayorEdad() {
		int mayor = arrPersonas[0].getEdad();
		Persona pmayor = arrPersonas[0];
		for (Persona p : arrPersonas) {
			if (p.getEdad() > mayor) {
				mayor = p.getEdad();
				pmayor = p;
			}
		}
		return pmayor;
	}

	public int tamano() {
		return arrPersonas.length;
	}

	public boolean esmayordeedad(int cual) {
		return arrPersonas[cual].getEdad() > 17;
	}

}

class Persona {
	private String nombre;
	private int edad;

	public Persona(String nombre, int edad) {
		super();
		this.nombre = nombre;
		this.edad = edad;
	}

	@Override
	public boolean equals(Object obj) {
		Persona other = (Persona) obj;
		if (edad != other.edad) return false;
		if (nombre == null) {
			if (other.nombre != null) return false;
		} else if (!nombre.equals(other.nombre)) return false;
		return true;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public int getEdad() {
		return edad;
	}

	public void setEdad(int edad) {
		this.edad = edad;
	}

}
