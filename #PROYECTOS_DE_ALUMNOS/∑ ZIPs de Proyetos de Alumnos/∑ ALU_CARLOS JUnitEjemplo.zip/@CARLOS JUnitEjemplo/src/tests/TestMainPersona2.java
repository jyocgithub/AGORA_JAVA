package tests;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.fail;
import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class TestMainPersona2 {

	static GestionPersonas m;

	// TEST FIXTURES ---------------------------------------
	// -----------------------------------------------------

	@BeforeAll
	// public void antesdetodos() {
	public static void setUpBeforeClass() { // cuidado, ha de ser static
		m = new GestionPersonas();
	}

	@BeforeEach
	// public void antesdecadauna() {
	public void setUp() {
		m.crearArray();
	}

	// TEST UNITS ---------------------------------------
	// -----------------------------------------------------
	@Test
	public void testQuienMayorEdad() {
		System.out.println("test 1");
		m.arrPersonas[0].setEdad(10000);
		Persona personaMayorCalculada = m.quienMayorEdad();
		Persona personaMayorEsperada = m.arrPersonas[2];
		assertEquals(personaMayorCalculada, personaMayorEsperada);
	}

	@Test
	public void testMayorEdad() {
		System.out.println("test 2");
		int mayorReal = m.mayorEdad();
		int mayorEsperado = 59;
		assertEquals(mayorReal, mayorEsperado);
	}

	@Test
	public void testExisteArray() { // comprueba que el array no es null
		assertNotNull(m.arrPersonas);
	}

	@Test
	public void testNigunElementoEsNull() { // comprueba que el array no es null
		m.arrPersonas[1] = null;
		for (Persona p : m.arrPersonas) {
			if (p == null) {
				fail("ERROR: UNA PERSONA ES NULL !!!");
			}
		}
	}

}
