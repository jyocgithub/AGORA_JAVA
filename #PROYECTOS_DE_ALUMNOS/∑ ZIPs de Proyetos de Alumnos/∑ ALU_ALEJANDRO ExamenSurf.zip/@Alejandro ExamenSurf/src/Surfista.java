import java.util.ArrayList;
import java.util.TreeSet;

public class Surfista {

	private String nombre;
	private String apellido;
	private ArrayList<SurfOlasGigantes> sog;
	private ArrayList<Surf> surfeo;
	private ArrayList<SurfLagos> sl;

	public Surfista(String nombre, String apellido, ArrayList<SurfOlasGigantes> sog, ArrayList<Surf> surfeo,
			ArrayList<SurfLagos> sl) {

		this.nombre = nombre;
		this.apellido = apellido;
		this.sog = sog;
		this.surfeo = surfeo;
		this.sl = sl;
	}

	public double mayoralturaOlasgigantes() {
		double mayor = 0;
		for (SurfOlasGigantes cadaola : sog) {
			if (cadaola.getAltitud() > mayor) {
				mayor = cadaola.getAltitud();
			}
		}
		return mayor;
	}

	public int mayorsumarolas() {
		int suma = 0;

		for (SurfOlasGigantes cadaola : sog) {
			suma = suma + cadaola.olas;
		}
		for (SurfLagos cadaola : sl) {
			suma = suma + cadaola.olas;
		}
		return suma;

	}

	public void mostrarpaises() {

		// CON ARRAYLIST
		// ArrayList<String> paises = new ArrayList<>();
		//
		// for( SurfOlasGigantes cadaola : sog ) {
		// if(! paises.contains(cadaola.pais)) {
		// paises.add(cadaola.pais);
		// }
		// }

		// CON SETS
		TreeSet<String> paises = new TreeSet<>();
		for (SurfOlasGigantes cadaola : sog) {
			paises.add(cadaola.pais);
		}

	}

	public void borrarSurfLagos() {
		sl.clear();
	}

	public int numtotalsurfeos() {
		int t = sog.size() + sl.size();
		return t;
	}

	public ArrayList<SurfOlasGigantes> getSog() {
		return sog;
	}

	@Override
	public String toString() {
		return "Surfista [nombre=" + nombre + ", apellido=" + apellido + ", sog=" + sog + ", surfeo=" + surfeo + ", sl="
				+ sl + "]";
	}

}
