public class SurfOlasGigantes extends Surf {

	private double altitud;
	private String nombre;

	public SurfOlasGigantes(String lugar, String pais, int olas, double altitud, String nombre) {
		super(lugar, pais, olas);
		this.altitud = altitud;
		this.nombre = nombre;
	}

	@Override
	public String toString() {

		return super.toString();
	}

	public double getAltitud() {
		return altitud;
	}

}
