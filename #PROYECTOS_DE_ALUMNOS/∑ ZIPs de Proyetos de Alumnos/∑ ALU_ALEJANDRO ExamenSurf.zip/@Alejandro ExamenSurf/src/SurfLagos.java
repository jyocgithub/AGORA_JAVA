public class SurfLagos extends Surf {

	private String lago;

	public SurfLagos(String lugar, String pais, int olas, String lago) {
		super(lugar, pais, olas);
		this.lago = lago;
	}

	@Override
	public String toString() {
		return super.lugar.toString() + " lago" + lago;
	}

}
