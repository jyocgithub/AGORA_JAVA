import java.util.ArrayList;

public class Main {

	public static void main(String[] args) {
		String n = "pepe";
		ArrayList<SurfOlasGigantes> sog = new ArrayList<>();
		ArrayList<Surf> surfeo = new ArrayList<>();
		ArrayList<SurfLagos> sl = new ArrayList<>();

		Surfista unsurfista = new Surfista(n, "perez", sog, surfeo, sl);

		SurfOlasGigantes unaolagigante = new SurfOlasGigantes("cotaazul", "francia", 12, 22, "POCOS");
		unsurfista.getSog().add(unaolagigante);
		SurfOlasGigantes unaolagigante2 = new SurfOlasGigantes("cartagena", "españa", 15, 12, "PICOS");
		unsurfista.getSog().add(unaolagigante2);

		System.out.println(unsurfista.mayoralturaOlasgigantes());

		System.out.println(unsurfista.toString());

	}

}
