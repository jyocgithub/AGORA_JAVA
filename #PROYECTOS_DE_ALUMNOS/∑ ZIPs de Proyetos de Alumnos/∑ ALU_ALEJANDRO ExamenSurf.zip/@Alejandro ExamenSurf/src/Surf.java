public class Surf {

	protected String lugar;
	protected String pais;
	protected int olas;

	public Surf(String lugar, String pais, int olas) {

		this.lugar = lugar;
		this.pais = pais;
		this.olas = olas;
	}

	@Override
	public String toString() {
		return "Surf [lugar: " + lugar + ", pais: " + pais + ", olas: " + olas
				+ "]";
	}

}
