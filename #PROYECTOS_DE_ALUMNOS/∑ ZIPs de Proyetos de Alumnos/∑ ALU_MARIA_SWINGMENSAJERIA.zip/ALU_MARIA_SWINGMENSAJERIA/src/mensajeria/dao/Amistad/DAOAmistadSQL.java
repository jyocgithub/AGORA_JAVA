/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mensajeria.dao.Amistad;

import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import mensajeria.dao.ConfiguracionBBDD;
import mensajeria.modelo.Amistad;



/**
 *
 * @author Alumno
 */
public class DAOAmistadSQL implements DAOAmistad{

    @Override
    public void inserta(Amistad amistad) {
        
           try{
        Statement stmt = ConfiguracionBBDD.getInstance().getConnection().createStatement();
        stmt.execute("insert into Amistad(Id_usuario_emisor,Id_usuario_receptor,Estado_amistad)"
            +"values ('"+amistad.getId_usuario_emisor()+"','"+amistad.getId_usuario_receptor()+"','"+amistad.getEstado_amistad()+"')");
        
        stmt.close();
        
    }   catch (SQLException ex) {
            Logger.getLogger(DAOAmistadSQL.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }

    @Override
    public void actualiza(Amistad actualizada) {
                try {
            Statement statement = ConfiguracionBBDD.getInstance().getConnection().createStatement();
            statement.execute("update Amistad"
                    + "set Estado_amistad='"+actualizada.getEstado_amistad()+"' "
                    + "where Id_usuario_receptor = '"+actualizada.getId_usuario_receptor()+"'");
 
            
            statement.close();
        } catch (SQLException ex) {
            Logger.getLogger(DAOAmistadSQL.class.getName()).log(Level.SEVERE, null, ex);
        }
    }


    

    
}

