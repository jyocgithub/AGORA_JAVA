/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mensajeria.dao.Amistad;

import mensajeria.modelo.Amistad;

/**
 *
 * @author Alumno
 */
public interface DAOAmistad {
    
    //solicitud enviada
    //solicitud no enviada
    //solicitud rechazada
    //solicitud aceptada
    //solicitud en espera
    
    
    //enviar la solicitud es inserta
    //la respuesta a esa solicitud sera un update
    
   public void inserta (Amistad amistad);
   public void actualiza (Amistad actualizada);
    
}
