/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mensajeria.dao.Grupo;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import mensajeria.dao.ConfiguracionBBDD;
import mensajeria.modelo.Grupo;

/**
 *
 * @author mrs123456
 */
public class DAOGrupoSQL implements DAOGrupo{

    @Override
    public void inserta(Grupo personasAlGrupo) {
         try{
        Statement stmt = ConfiguracionBBDD.getInstance().getConnection().createStatement();
        stmt.execute("insert into Usuario (Id_grupo,Nombre_grupo,Icono)"
            +"values ('"+personasAlGrupo.getId_grupo()+
                "','"+personasAlGrupo.getNombre_grupo()+
                "','"+personasAlGrupo.getIcono()+"')");
        
        stmt.close();
        
    }   catch (SQLException ex) {
            Logger.getLogger(DAOGrupoSQL.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @Override
    public List<Grupo> listadoDeGrupos() {
        
               List<Grupo> listadoDeGrupos = new ArrayList <Grupo>();
        try{
            Statement stmt = ConfiguracionBBDD.getInstance().getConnection().createStatement();
            ResultSet rs = stmt.executeQuery("select * from Grupo");
            while (rs.next()){
                
                Grupo grupos = new Grupo();
                grupos.setId_grupo(rs.getString("Id_grupo"));
                grupos.setNombre_grupo(rs.getString("Nombre_grupo")); 
                grupos.setIcono(rs.getString("Icono"));
                
                listadoDeGrupos.add(grupos);
                
            }
            rs.close();
            stmt.close();
        }
        
        catch (SQLException ex){
            System.err.println(ex.getMessage());
        }
        return listadoDeGrupos;
        
        
    }
    
}
