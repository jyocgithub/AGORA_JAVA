/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mensajeria.modelo;

/**
 *
 * @author mrs123456
 */
public class Mensaje {
    
    private String Id_mensaje;
    private String Texto;
    private String fecha_hora;
    private String Conf_lectura;
    private String Id_usuario_emisor;
    private String Id_usuario_receptor;
    private String Id_grupo;

    public String getId_mensaje() {
        return Id_mensaje;
    }

    public void setId_mensaje(String Id_mensaje) {
        this.Id_mensaje = Id_mensaje;
    }

    public String getTexto() {
        return Texto;
    }

    public void setTexto(String Texto) {
        this.Texto = Texto;
    }

    public String getFecha_hora() {
        return fecha_hora;
    }

    public void setFecha_hora(String fecha_hora) {
        this.fecha_hora = fecha_hora;
    }

    public String getConf_lectura() {
        return Conf_lectura;
    }

    public void setConf_lectura(String Conf_lectura) {
        this.Conf_lectura = Conf_lectura;
    }

    public String getId_usuario_emisor() {
        return Id_usuario_emisor;
    }

    public void setId_usuario_emisor(String Id_usuario_emisor) {
        this.Id_usuario_emisor = Id_usuario_emisor;
    }

    public String getId_usuario_receptor() {
        return Id_usuario_receptor;
    }

    public void setId_usuario_receptor(String Id_usuario_receptor) {
        this.Id_usuario_receptor = Id_usuario_receptor;
    }

    public String getId_grupo() {
        return Id_grupo;
    }

    public void setId_grupo(String Id_grupo) {
        this.Id_grupo = Id_grupo;
    }
    
    

    
    
}
