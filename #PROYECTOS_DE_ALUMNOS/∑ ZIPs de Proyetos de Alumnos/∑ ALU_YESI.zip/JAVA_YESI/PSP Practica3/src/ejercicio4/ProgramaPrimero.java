package ejercicio4;

import java.io.*;
import java.net.*;

public class ProgramaPrimero {
	public static void main(String[] args) {
		ProcesarUDP p = new ProcesarUDP();
		Object o = p.recibirObjectUDP( "localhost", 22002);
		Alumno alumno = (Alumno) o;
		System.err.println("Recibida informacion del alumno "+alumno.getNombre());
	}
}
