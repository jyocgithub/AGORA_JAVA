package ejercicio4;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;

public class ProcesarUDP {

	public static void enviarObjetoUDP(Object objeto, String host, int puerto) {
		try {
			// Convertimos el objeto en un array de bytes
			byte[] arrayConElObjeto = objetoToByteArray(objeto);
			// Enviamos el byte[] como un Datagram normal
			InetAddress inetdireccion = InetAddress.getByName(host);
			DatagramPacket dpacket = new DatagramPacket(arrayConElObjeto, arrayConElObjeto.length, inetdireccion,
					puerto);
			DatagramSocket dSocket = new DatagramSocket();
			dSocket.send(dpacket);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static Object recibirObjectUDP(String host, int puerto) {
		try {
			// Preparar una array de bytes donde recibir un datagrama
			byte[] arrayDondeRecibir = new byte[5000];
			// Recibir un datagrama
			DatagramPacket packet = new DatagramPacket(arrayDondeRecibir, arrayDondeRecibir.length);
			InetAddress inetdireccion = InetAddress.getByName(host);
			DatagramSocket dSocket = new DatagramSocket(puerto, inetdireccion);
			dSocket.receive(packet);
			// Convertir el datagrama leido como byte[] en un objeto
			Object objetoLeido = byteArrayToObject(arrayDondeRecibir);
			return objetoLeido;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return (null);
	}	

	public static byte[] objetoToByteArray(Object o) {
		try {
			// Escribimos el objeto en un ByteArrayOutpuStream, y de ahi lo convertimos en
			// byte[]
			ByteArrayOutputStream baos = new ByteArrayOutputStream();
			ObjectOutputStream oos = new ObjectOutputStream(baos);
			oos.writeObject(o);
			oos.flush();
			byte[] arrayConElObjeto = baos.toByteArray(); // convertimos el objeto escrito en el byte[]
			oos.close(); // mejor en un finally, aqui ahora por ahorro de espacio
			return arrayConElObjeto;
		} catch (IOException e) {
			e.printStackTrace();
		}
		return null; // si se llega aqui es por que hubo un error...
	}

	public static Object byteArrayToObject(byte[] array) throws IOException, ClassNotFoundException {
		try {
			// Leemos el byte[] de un ByteArrayInpuStream, y de ahi lo convertimos en Object
			ByteArrayInputStream byteStream = new ByteArrayInputStream(array);
			ObjectInputStream is = new ObjectInputStream(byteStream);
			Object objetoLeido = is.readObject(); // posteriormente se debe hacer casting para modelar el objeto leido
			is.close(); // mejor en un finally, aqui ahora por ahorro de espacio
			return objetoLeido;
		} catch (IOException e) {
			e.printStackTrace();
		}
		return null; // si se llega aqui es por que hubo un error...
	}
}
