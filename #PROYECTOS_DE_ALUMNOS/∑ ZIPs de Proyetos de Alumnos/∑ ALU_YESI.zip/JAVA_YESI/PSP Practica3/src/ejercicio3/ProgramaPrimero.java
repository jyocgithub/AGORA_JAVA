package ejercicio3;

import java.io.*;
import java.net.*;

import javax.xml.bind.annotation.XmlRootElement;

public class ProgramaPrimero {
	public static void main(String[] args) {

		String host = "localhost";
		int puerto = 22003;

		// LEER
		leer();

		// ESCRIBIR
		escribir();

	}

	public static void leer() {
		DatagramSocket dSocket = null;
		DatagramPacket packet;
		InetAddress inetdireccion;
		try {
			// Preparar una array de bytes donde recibir un datagrama
			byte[] arrayDondeRecibir = new byte[5000];
			// Recibir un datagrama
			packet = new DatagramPacket(arrayDondeRecibir, arrayDondeRecibir.length);
			inetdireccion = InetAddress.getByName("localhost");
			dSocket = new DatagramSocket(22003, inetdireccion);
			dSocket.receive(packet);
			// Convertir el datagrama leido como byte[] en un objeto
			String respuesta = new String(arrayDondeRecibir, "UTF-8");
			System.out.println("Programa B recibe de A : " + respuesta);
			dSocket.close();

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			dSocket.close();
		}
	}

	public static void escribir() {
		DatagramSocket dSocket = null;
		DatagramPacket dpacket;
		InetAddress inetdireccion;
		try {
			// Convertimos el string en un array de bytes
			String pregunta = "¿Como estas?";
			byte[] arraybytes = pregunta.getBytes("UTF-8");
			// Enviamos el byte[] como un Datagram normal
			inetdireccion = InetAddress.getByName("localhost");
			dpacket = new DatagramPacket(arraybytes, arraybytes.length, inetdireccion, 22004);
			dSocket = new DatagramSocket();
			dSocket.send(dpacket);
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			dSocket.close();
		}
	}
}
