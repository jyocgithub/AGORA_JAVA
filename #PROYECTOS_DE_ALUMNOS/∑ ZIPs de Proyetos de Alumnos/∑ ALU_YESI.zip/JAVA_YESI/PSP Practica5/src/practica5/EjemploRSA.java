package practica5;

import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.spec.KeySpec;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;

import javax.crypto.Cipher;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.security.*;

public class EjemploRSA {
	
	
	public static void main(String[] args) throws Exception {
		new EjemploRSA().cifrarConRSA();;
		
	}
	

	public void cifrarConRSA() throws Exception {
		// Generar el par de claves
		KeyPairGenerator keyPairGenerator = KeyPairGenerator.getInstance("RSA");
		KeyPair keyPair = keyPairGenerator.generateKeyPair();
		PublicKey obClavePublica = keyPair.getPublic();
		PrivateKey obClavePrivada = keyPair.getPrivate();

		// Se salva y recupera de fichero la clave publica
		guardarClave(obClavePublica, "clavePublica.dat");
		obClavePublica = leerClavePublica("clavePublica.dat");

		// Se salva y recupera de fichero la clave privada
		guardarClave(obClavePrivada, "clavePrivada.dat");
		obClavePrivada = leerClavePrivada("clavePrivada.dat");

		// Obtener la clase para encriptar/desencriptar
		Cipher obCipher = Cipher.getInstance("RSA/ECB/PKCS1Padding");

		// Texto a encriptar
		String mensOriginal = "Texto que queremos encriptar";

		// Se encripta
		obCipher.init(Cipher.ENCRYPT_MODE, obClavePublica);
		byte[] mensCifrado = obCipher.doFinal(mensOriginal.getBytes());

		// Se desencripta
		obCipher.init(Cipher.DECRYPT_MODE, obClavePrivada);
		byte[] bytesDesencriptados = obCipher.doFinal(mensCifrado);
		String mensDesencripado = new String(bytesDesencriptados);

		// Texto obtenido, igual al original.
		System.out.println("Mensaje original;\n" + mensOriginal);
		System.out.println("Mensaje cifrado;\n" + new String(mensCifrado));
		System.out.println("Mensaje cifrado en hexadecimal; ");
		for (byte b : mensCifrado) {
			System.out.print(Integer.toHexString(0xFF & b));
		}
		System.out.println();
		System.out.println("Mensaje desencriptado; ");
		System.out.println(new String(mensDesencripado));

	}

	private PublicKey leerClavePublica(String fileName) throws Exception {
		FileInputStream fis = new FileInputStream(fileName);
		int numBtyes = fis.available();
		byte[] bytes = new byte[numBtyes];
		fis.read(bytes);
		fis.close();

		KeyFactory keyFactory = KeyFactory.getInstance("RSA");
		KeySpec keySpec = new X509EncodedKeySpec(bytes);
		PublicKey keyFromBytes = keyFactory.generatePublic(keySpec);
		return keyFromBytes;
	}

	private PrivateKey leerClavePrivada(String fileName) throws Exception {
		FileInputStream fis = new FileInputStream(fileName);
		int numBtyes = fis.available();
		byte[] bytes = new byte[numBtyes];
		fis.read(bytes);
		fis.close();

		KeyFactory keyFactory = KeyFactory.getInstance("RSA");
		KeySpec keySpec = new PKCS8EncodedKeySpec(bytes);
		PrivateKey keyFromBytes = keyFactory.generatePrivate(keySpec);
		return keyFromBytes;
	}

	private void guardarClave(Key key, String fileName) throws Exception {
		byte[] publicKeyBytes = key.getEncoded();
		FileOutputStream fos = new FileOutputStream(fileName);
		fos.write(publicKeyBytes);
		fos.close();
	}
}
