package hilos;



import java.util.Properties;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
 
public class EnviarCorreo {
		
	private final Properties properties = new Properties();
	
	private String password;
 
	private Session session;
 
	private void init() {
 
		properties.put("mail.smtp.host", "smtp.gmail.com");
		properties.put("mail.smtp.starttls.enable", "true");
		properties.put("mail.smtp.port",25);
		properties.put("mail.smtp.mail.sender","prumail2@gmail.com");
		properties.put("mail.smtp.user", "prumail2@gmail.com");
		properties.put("mail.smtp.auth", "true");
 
		session = Session.getDefaultInstance(properties);
	}
	
	public  synchronized void sendEmail(String Fichero,String maquina){
 
		init();
		try{
			MimeMessage message = new MimeMessage(session);
			message.setFrom(new InternetAddress((String)properties.get("mail.smtp.mail.sender")));
			message.addRecipient(Message.RecipientType.TO, new InternetAddress("sergio.pereyra.benito@gmail.com"));//sergio.pereyra.benito@gmail.com
			message.setSubject("Actividad servidor Receptor de Mensajes");
			String Texto="Se ha enviado el fichero  "+ Fichero+" con los datos generados en la comunicacion "+maquina+ " al servidor FTP.";
			message.setText(Texto);
			Transport t = session.getTransport("smtp");
			t.connect((String)properties.get("mail.smtp.user"), "pruebamail");//pruebamail password
			t.sendMessage(message, message.getAllRecipients());
			System.out.println("Correo enviado correctamente");
			t.close();
		}catch (MessagingException me){
					System.out.println("Error al enviar el email del fichero: "+Fichero);
					me.printStackTrace();
                        //Aqui se deberia o mostrar un mensaje de error o en lugar
                        //de no hacer nada con la excepcion, lanzarla para que el modulo
                        //superior la capture y avise al usuario con un popup, por ejemplo.
			return;
		}
		
	}
 



}
