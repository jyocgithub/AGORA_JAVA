package ejercicio2;

import java.util.concurrent.Semaphore;

public class Pintar {

	public static void main(String[] args) {

		if (args.length != 1) {
			System.out.println("Debe indicar un único parámetro, la prioridad");
			return;
		}

		int prioridad = Integer.parseInt(args[0]);
		if (prioridad < 1 || prioridad > 10) {
			System.out.println("Debe indicar como prioridad un valor entre 1 y 10");
			return;
		}

		Pizarra pizarra = new Pizarra();

		Pintor p1 = new Pintor("Ana", pizarra, 1, "TIC");
		Pintor p2 = new Pintor("Pedro", pizarra, 2, "  TOC");
//		Thread t1 = new Thread(p1);
//		Thread t2 = new Thread(p2);

		p1.setPriority(prioridad);
		p2.setPriority(prioridad);

		long initialTime = System.currentTimeMillis();
		
		System.out.println("Ana y Pedro empiezan a escribir en la pizarra");
		p1.start();
		p2.start();
		try {
			// ponemos los hilos en join para que los mensajes finales salgan cuando todos acaben
			p1.join();
			p2.join();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

		// Mensajes finales
		long duracion = (System.currentTimeMillis() - initialTime);
		System.out.println("Pedro y Ana han tardado "+duracion+" milisegundos en escribir en la pizarra, con una prioridad de "
				+ p1.getPriority());

	}

}
