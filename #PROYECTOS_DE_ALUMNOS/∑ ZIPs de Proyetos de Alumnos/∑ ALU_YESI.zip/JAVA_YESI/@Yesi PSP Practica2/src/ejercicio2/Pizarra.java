package ejercicio2;

public class Pizarra {
	
	private int turno=1;
		

	public synchronized void escribirEnLaPizarra(String linea, int miturno)
	{
		try {

			while (turno != miturno) {
				wait();
			}

			Thread.sleep(20);

			System.out.println(linea);

			if (turno == 1) {
				turno = 2;
			} else {
				turno  =1;
			}
 notifyAll();
		} catch (InterruptedException e) { // El acquire() puede dar excepción.
			e.printStackTrace();
		}
	}

}
