package ejercicio4Interrupcion;

import java.util.Random;
import java.util.concurrent.Semaphore;

public class Camarero extends Thread {
	private Cocinero cocinero;
	Random random = new Random();
	Pedido pedido ;

	@Override
	public void run() {
		
		// simulamos que entran en el restaurante 20 personas
		// el camarero recoge los pedidos de las 20 personas
		for (int i = 0; i < 20; i++) {
			
			int espera = random.nextInt(1000)+ 200;
			try {
				sleep(espera);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			System.out.println("Camarero: Acaba de entrar alguien al restaurante");
			try {
				sleep(800);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}

			System.out.println("Camarero: Ya he hecho el pedido, se lo mando al cocinero");
			pedido = new Pedido();
			cocinero.interrupt();
			
		}
	
	}

	public Pedido getPedido() {
		return pedido;
	}

	public void setCocinero(Cocinero cocinero) {
		this.cocinero = cocinero;
	}
	
	

}
