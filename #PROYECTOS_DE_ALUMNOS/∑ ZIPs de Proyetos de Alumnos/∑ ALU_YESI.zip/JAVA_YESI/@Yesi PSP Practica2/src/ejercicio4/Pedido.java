package ejercicio4;

public class Pedido {

	private String plato = "";
	volatile int contadorPlatos = 0;

	public synchronized String getPlato() {
		return plato;
	}

	public synchronized void setPlato(String plato) {
		this.plato = plato;
	}

	public synchronized int getContadorPlatos() {
		return contadorPlatos;
	}

	public synchronized void setContadorPlatos(int contadorPlatos) {
		this.contadorPlatos = contadorPlatos;
	}

	public synchronized void rellenar() {
		
		try {
			Thread.sleep(800);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

		System.out.println("Camarero: Ya he hecho el pedido, se lo mando al cocinero");

		contadorPlatos ++;
		notifyAll();

	}

	public synchronized void cocinar() {
		
		while (contadorPlatos == 0) {
			try {
				wait();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}

		System.out.println(" Cocinero: Acaban de decirme que hay un pedido");

		System.out.println(" Cocinero: Me pongo a cocinar ");
		try {
			Thread.sleep(400);
		} catch (InterruptedException e) {
		}
		System.out.println(" Cocinero: Plato listo");

		contadorPlatos--;
	}

}
