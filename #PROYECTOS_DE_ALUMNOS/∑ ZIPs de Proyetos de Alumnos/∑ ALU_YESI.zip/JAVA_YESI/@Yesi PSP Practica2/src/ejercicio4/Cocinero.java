package ejercicio4;

import java.util.concurrent.Semaphore;

public class Cocinero extends Thread {
	private Pedido pedido;
	

	public Cocinero(Pedido pedido) {
		this.pedido = pedido;
	}

	@Override
	public void run() {

		while(true) {
			pedido.cocinar();
		}
		

	}

}
