package ejercicio3;

import java.util.concurrent.Semaphore;

public class Inicio {

	public static void main(String[] args) {

		Garage garage = new Garage();
		Thread[] hilos = new Thread[40];

		for (int i = 0; i < hilos.length; i++) {
			Coche c = new Coche("Coche" + i, garage);
			hilos[i] = c;
			c.start();
		}

		for (int i = 0; i < hilos.length; i++) {
			try {
				hilos[i].join();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}

	}

}
