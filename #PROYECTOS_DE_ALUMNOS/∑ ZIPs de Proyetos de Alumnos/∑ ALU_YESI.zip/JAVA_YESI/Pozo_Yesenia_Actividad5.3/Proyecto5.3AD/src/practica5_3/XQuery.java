package practica5_3;

import java.util.Scanner;

import org.xmldb.api.DatabaseManager;
import org.xmldb.api.base.Collection;
import org.xmldb.api.base.Database;
import org.xmldb.api.base.Resource;
import org.xmldb.api.base.ResourceIterator;
import org.xmldb.api.base.ResourceSet;
import org.xmldb.api.base.XMLDBException;
import org.xmldb.api.modules.XPathQueryService;

public class XQuery {
	static XPathQueryService servicio;
	public static final String nombrefichero = "AleatorioEmple.dat";
	static String driver = "org.exist.xmldb.DatabaseImpl"; // Driver para eXist
	static String URI = "xmldb:exist://localhost:8080/exist/xmlrpc/db/ColeccionPruebas"; // URI colecci�n
	static String usu = "admin"; // Usuario
	static String usuPwd = "root"; // Clave
	static Collection col = null;
	
public void cargarProductos() {
		
		try {
        XPathQueryService servicio = (XPathQueryService) col.getService("XPathQueryService", "1.0");
		ResourceSet	resultprod = servicio.query("for $produc in /productos/produc return $produc"); 
		 // recorrer los datos del recurso. 
		ResourceIterator i;   
		i= resultprod.getIterator(); 	
		if (!i.hasMoreResources()) {
			    System.out.println(" LA CONSULTA NO DEVUELVE NADA O ESTA MAL ESCRITA");
			}
		while (i.hasMoreResources()) {
			    Resource r = i.nextResource();
			    System.out.println("------------------------------------------------------");
			    System.out.println((String) r.getContent());
		}
		}catch (XMLDBException e) {
			 System.out.println(" ERROR AL CONSULTAR DOCUMENTO.");
             e.printStackTrace();
		}
	}

private static boolean comprobarProd(int cod_prod) {
    //Devuelve true si el dep existe
        try {
            XPathQueryService servicio = (XPathQueryService) col.getService("XPathQueryService", "1.0");
            ResourceSet result = servicio.query(
                    "/productos/produc[cod_prod=" + cod_prod + "]");
            ResourceIterator i;
            i = result.getIterator();
            col.close();
            if (!i.hasMoreResources()) {
                return false;
            } else {
                return true;
            }
        } catch (Exception e) {
            System.out.println("Error al consultar.");
            // e.printStackTrace();
        }
    return false;
}// comprobardep

public void modificarProd(int cod_prod,String denominacion,int precio,int stock_actual,int stock_minimo,int cod_zona) {

	if(comprobarProd(cod_prod)) {
		try {
			System.out.printf("Actualizo el producto: %s\n", cod_prod);
			XPathQueryService servicio = (XPathQueryService) col.getService("XPathQueryService", "1.0");
			ResourceSet result = servicio.query("update value /productos/produc[cod_prod=" + cod_prod + "]/denominacion with data('"+denominacion+"') ");
			col.close();
			System.out.println("producto modificado.");
		} catch (Exception e) {
            System.out.println("Error al actualizar.");
            e.printStackTrace();
        }
	}else 
		System.out.println("El departamento no existe");
}

static void insertarProducto(int cod_prod,String denominacion,int precio,int stock_actual,int stock_minimo,int cod_zona) {
    
    String nuevoprod = "<produc><cod_prod>" + cod_prod + "</cod_prod><denominacion>" + denominacion + "</denominacion><precio>" + precio + "</precio><stock_actual>" + stock_actual + "</stock_actual><stock_minimo>" + stock_minimo + "</stock_minimo><cod_zona>" + cod_zona + "</cod_zona></produc>";
    if(!comprobarProd(cod_prod)) {
        try {
            XPathQueryService servicio = (XPathQueryService) col.getService("XPathQueryService", "1.0");
            System.out.printf("Inserto: %s \n", nuevoprod);
            ResourceSet result = servicio.query("update insert " + nuevoprod + " into /productos");
            col.close(); //borramos 
            System.out.println("Producto insertado.");
        } catch (Exception e) {
            System.out.println("Error al insertar producto.");
            e.printStackTrace();
        }
    }else 
		System.out.println("El Producto ya existe");
}

	public static Collection conectar() {

		try {
			Class cl = Class.forName(driver); // Cargar del driver
			Database database = (Database) cl.newInstance(); // Instancia de la BD
			DatabaseManager.registerDatabase(database); // Registro del driver
			col = DatabaseManager.getCollection(URI, usu, usuPwd);
			 if (col == null) {
	                System.out.println(" *** LA COLECCION NO EXISTE. ***");
	            }
			//Los servicios se solicitan para tareas como consultar una colección con XPath o la gestion de una colección
	        XPathQueryService servicio = (XPathQueryService) col.getService("XPathQueryService", "1.0");
			

		} catch (XMLDBException e) {
			System.out.println("Error al inicializar la BD eXist.");
			// e.printStackTrace();
		} catch (ClassNotFoundException e) {
			System.out.println("Error en el driver.");
			// e.printStackTrace();
		} catch (InstantiationException e) {
			System.out.println("Error al instanciar la BD.");
			// e.printStackTrace();
		} catch (IllegalAccessException e) {
			System.out.println("Error al instanciar la BD.");
			// e.printStackTrace();
		}
		return null;
	}
	public void modificarProd(int cod_prod, int precio) {
		// TODO Auto-generated method stub
		
	}
}