import java.util.Scanner;

public class EjerciciosConMetodos {

	public static void main(String[] args) {
		// Metodo que multiplica 3 numeros enteros y escribe el resultado en consola.
		// No devuelve nada
		multiplicar3(45, 34, 22);
		int q = 2;
		int w = 4;
		int e = 8;
		multiplicar3(q, w, e);

		// Metodo que multiplica 3 numeros enteros y NO escribe el resultado en consola.,
		// sino que devuelve el resultado
		int solucion = multiplicar3Resultado(q, w, e);
		System.out.println("ha salido " + solucion);

		// metodo que me da como resultado cual es el mayor de dos numeros
		int sol = mayordedos(43, 89);
		System.out.println("el mayor es  " + sol);

		// metodo que calcula el area de un circulo;
		double solu = areacirculo(33);
		System.out.println("el area es " + solu);

		// Crear un método que no recibe parámetros, pide al usuario
		// un numero entero por teclado y lo devuelve como resultado.
		// Usarlo en vez de Scanner en el método main para pedir números enteros.

		int minumero = pedirInt();
		System.out.println("has escrito el " + minumero);
		String cad = pedirString();
		System.out.println("has escrito " + cad);

		/*
		 * Crear un método double circulo (int radio, char opcion) que devuelve el area de un circulo (si opcion es ‘a’) o la
		 * longitud de la circunferencia (si opcion es ‘c’) , teniendo el circulo o circunferencia como radio el parámetro radio
		 */

		double elarea = circulo(43, 'a');
		System.out.println("el area es " + elarea);
		double lacircunferencia = circulo(43, 'c');
		System.out.println("la circunferencia es  " + lacircunferencia);

		// metodo recibe un array y devuelve otro array con todos los valores duplicados
		int[] arr = { 3, 4, 4, 3, 2 };
		int[] res = duplicar(arr);

	}

	public static int[] duplicar(int[] xx) {
		int[] duplicado = new int[xx.length];

		for (int i = 0; i < xx.length; i++) {
			duplicado[i] = xx[i] * 2;
		}
		return duplicado;
	}

	public static double circulo(int radio, char opcion) {
		double res = 0;
		if (opcion == 'a') {
			res = 3.1415 * radio * radio;
		}
		if (opcion == 'c') {
			res = 2 * 3.1415 * radio;
		}
		return res;
	}

	public static String pedirString() {
		Scanner sc = new Scanner(System.in);
		System.out.println("Dame una cadean de texto:");
		String a = sc.nextLine();
		return a;
	}

	public static int pedirInt() {
		Scanner sc = new Scanner(System.in);
		System.out.println("Dame un numero:");
		int a = sc.nextInt();
		return a;
	}

	public static double areacirculo(int radio) {
		double area = 3.1415 * radio * radio;
		return area;
	}

	public static int mayordedos(int x, int y) {
		if (x > y) {
			return x;
		} else {
			return y;
		}
	}

	public static int multiplicar3Resultado(int a, int b, int c) {
		int res = a * b * c;
		return res;
	}

	public static void multiplicar3(int a, int b, int c) {
		int res = a * b * c;
		System.out.println(res);
	}

}
