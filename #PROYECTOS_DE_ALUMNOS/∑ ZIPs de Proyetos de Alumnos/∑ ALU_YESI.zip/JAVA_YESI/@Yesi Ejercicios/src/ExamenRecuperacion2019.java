import java.util.Scanner;

public class ExamenRecuperacion2019 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int actual = 0;
		int anterior = 0;

		while (actual >= anterior) {
			anterior = actual;
			System.out.println("Dime un numerito....");
			actual = sc.nextInt();
		}
		System.out.println("fin");

	}

}
