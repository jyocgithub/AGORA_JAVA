package clases;

public class Prueba {

	public static void main(String[] args) {

		Ropa v = new Ropa("Zara", "M", 200);

		int j;
		String sr = "un mensaje";
		String jk = "el mensaje  es " + sr;

		// v.marca = "Zara";

		String lamarca = v.getMarca();
		System.out.println(lamarca);

		String tall = v.getTalla();
		System.out.println(tall);

		double pre = v.getPrecio();
		System.out.println(pre);

		v.setPrecio(123);
		pre = v.getPrecio();
		System.out.println(pre);

		v.rebajar();
		System.out.println(v.getPrecio());

		Blusa b1 = new Blusa("Chanel", "S", 1233, 12);
		Blusa b2 = new Blusa("ZAra", "S", 1233, 12);
		Pantalon p1 = new Pantalon("Levis", "S", 22, 2);
		b1.rebajar();
		p1.rebajar();

		int[] nums = new int[5];
		for (int i = 0; i < nums.length; i++) {
			System.out.println(nums[i]);
		}

		Blusa[] blusas = new Blusa[2];
		Pantalon[] pantalones = new Pantalon[2];
		blusas[0] = b1;
		blusas[1] = b2;

		System.out.println(b1.getLargomanga());
		System.out.println(b1.toString());

		for (int i = 0; i < blusas.length; i++) {
			System.out.println(blusas[i].toString());
		}

		Ropa q1 = new Blusa("Chanel", "S", 1233, 12);
		Ropa q2 = new Pantalon("Charol", "S", 1233, 12);

		Ropa[] ropas = new Ropa[2];

		ropas[0] = q1;
		ropas[1] = q2;

		for (int i = 0; i < ropas.length; i++) {
			ropas[i].rebajar();
		}
		int jj = 34;
		int sum = sumar(6, jj);

		System.out.println(sumar(6, jj));
		System.out.println("la suma es ");

	}

	public static int sumar(int a, int b) {

		int suma = a + b;

		return suma;
	}

}
