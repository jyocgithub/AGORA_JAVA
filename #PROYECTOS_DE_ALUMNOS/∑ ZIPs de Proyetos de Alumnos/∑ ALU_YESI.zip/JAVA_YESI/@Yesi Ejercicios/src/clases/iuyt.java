package clases;

public class iuyt {
	public static void main(String[] args) {

		System.out.println();

	}
}
