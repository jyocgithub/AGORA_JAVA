package ejercicio1;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;

public class Ejercicio1 {
	public static void main(String[] args) {

		try {

			// Creamos proceso hijo 1
			ProcessBuilder obProBuil1 = new ProcessBuilder("ls", "-la");
			Process proceso1 = obProBuil1.start();
			// obtenemos su canal de salida (que para nosotros es el de entrada, IN)
			InputStream is1 = proceso1.getInputStream();
			BufferedReader hijo1_CanalSalida = new BufferedReader(new InputStreamReader(is1));

			// Creamos proceso hijo 2
			ProcessBuilder obProBuil2 = new ProcessBuilder("tr", "\"d\"", "\"D\"");
			Process proceso2 = obProBuil2.start();
			// obtenemos su canal de entrada (que para nosotros es el de salida, OUT)
			OutputStream os2 = proceso2.getOutputStream();
			BufferedWriter hijo2_CanalEntrada = new BufferedWriter(new OutputStreamWriter(os2));
			// obtenemos su canal de salida (que para nosotros es el de salida, IN)
			InputStream is2 = proceso2.getInputStream();
			BufferedReader hijo2_CanalSalida = new BufferedReader(new InputStreamReader(is2));

			
			System.out.println("PRIMERA PARTE");

			// leemos linea a linea del canal de salida del primer proceso y la escribimos por consola
			String lineaHijo1 = hijo1_CanalSalida.readLine();
			while (lineaHijo1 != null) {
				// y cada linea leida del primer proceso lo escribimos en el segundo
				hijo2_CanalEntrada.write(lineaHijo1);
				// cada linea que escriba ha de acabar con un "fin de linea"
				hijo2_CanalEntrada.newLine();
				System.out.println("--> "+lineaHijo1);
				lineaHijo1 = hijo1_CanalSalida.readLine();
			}
			// se cierra el canal de entrada del hijo2, para que podamos procesar ahora su salida
			hijo2_CanalEntrada.close();

			System.out.println("SEGUNDA PARTE");

			// leemos linea a linea del canal de salida del segundo proceso y la escribimos por consola
			String lineaHijo2 = hijo2_CanalSalida.readLine();
			while (lineaHijo2 != null) {
				System.out.println("--> "+lineaHijo2);
				lineaHijo2 = hijo2_CanalSalida.readLine();
			}

			hijo1_CanalSalida.close();
			hijo2_CanalSalida.close();
			is1.close();
			is2.close();
			os2.close();

		} catch (IOException e) {
			System.out.println("Error en al ejecucion de su peticion");
		} catch (Exception e) {
			e.printStackTrace();
		}

	}
}
