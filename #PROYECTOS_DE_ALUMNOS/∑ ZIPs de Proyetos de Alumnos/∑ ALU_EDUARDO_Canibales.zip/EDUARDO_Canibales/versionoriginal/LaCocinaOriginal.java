package versionoriginal;

public class LaCocinaOriginal
{
    public static void main(String[] args) {
        int tamano = 5;//tamano de la olla
        Olla laolla = new Olla(tamano);

        //Crear el cocinero  y lanzarlo
        Cocinero cocinero = new Cocinero(laolla);
        Thread tCocinero = new Thread(cocinero);
        tCocinero.start();

        //Crear 3 canibales y lanzarlos
        for (int i = 1; i <= 3; i++) {
            Canibal canibal = new Canibal(laolla, i);
            Thread tCanibal = new Thread(canibal);
            tCanibal.start();
        }


    }
}


class Cocinero implements Runnable {

    private Olla laolla = null;

    public Cocinero(Olla o) {
        laolla = o;
    }

    public void run() {
        int misionero = 0;
        while (true) {
            laolla.echarAlaOlla(++misionero);
            try {
                Thread.sleep(100);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}

class Olla {

    private int tamano = 0;
//    private int cuantosEnLaOlla = 0;
        private int[] olla=null;
    private int echar = 0, sacar = 0;
    private int cont = 0;

    public Olla(int tamano) {
        this.tamano = tamano;
        olla=new int[tamano];
    }

    public synchronized void echarAlaOlla(int nummisionero) {
        while (estaLlenaLaOlla()) {
            //Si la olla esta llena
            try {
                System.out.println("No se puede echar a la olla: OLLA  LLENA ");
                wait();
                Thread.sleep(200);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        //Si se puede cocinar habr· que echar otro
        meterMisioneroEnArray(nummisionero);
        notifyAll();
        System.out.println("		Cocinando al misionero:  " + nummisionero);

    }

    public synchronized int sacardelaOlla(int numerocanibal) {
        while (hayAlguienEnLaOlla() == false) {
            //Si la olla esta vacÌa no se puede sacar
            try {
                wait();
                Thread.sleep(100);
                System.out.println("No hay nada mas que sacar: OLLA VACIA ");
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

        //Si hay misioneros cocinados se podran sacar y comer
        int misioneroDevorado =  sacarMisioneroDeArray();
        System.out.println("El canibal " + numerocanibal + " esta comiendo a "+misioneroDevorado );
        notifyAll();
        return 1;

    }//



    public synchronized boolean estaLlenaLaOlla(){
        boolean estallena = true;
        // puede mejorarse añadiendo a condicion de bucle     && haysitio = false
        for (int i = 0; i <olla.length && estallena==true; i++) {
            if(olla[i] == 0){
                estallena=false;
            }
        }
        return estallena;
    }
    public synchronized boolean hayAlguienEnLaOlla(){
        boolean hayAlguien = false;
        for (int i = 0; i <olla.length && hayAlguien==false; i++) {
            if(olla[i] != 0){
                hayAlguien=true;
            }
        }
        return hayAlguien;
    }


    public synchronized int meterMisioneroEnArray(int nummisionero){
        int posicion=0;
        for (int i = 0; i <olla.length && posicion == 0; i++) {
            if(olla[i] == 0){
                olla[i] = nummisionero;
                posicion  =i;
            }
        }
        return posicion;
    }

    public synchronized int sacarMisioneroDeArray(){
        int numMisionero = 0;
        for (int i = 0; i <olla.length && numMisionero==0; i++) {
            if(olla[i] != 0){
                numMisionero = olla[i];

            }
        }
        return numMisionero;
    }

}

class Canibal implements Runnable {

    private Olla laolla = null;
    private int numero = 0;

    public Canibal(Olla o, int num) {
        laolla = o;
        numero = num;
    }

    public void run() {

        int canibal;
        while (true) {
            laolla.sacardelaOlla(numero);
            try {
                Thread.sleep(400);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }


}
