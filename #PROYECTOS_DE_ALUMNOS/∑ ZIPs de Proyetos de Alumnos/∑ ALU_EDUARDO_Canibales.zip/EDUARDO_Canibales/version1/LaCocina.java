package EDUARDO_Canibales.version1;

public class LaCocina {
    public static void main(String[] args) {
        int tamano = 5;//tamano de la olla
        Olla laolla = new Olla(tamano);

        //Crear el cocinero  y lanzarlo
        Cocinero cocinero = new Cocinero(laolla);
        Thread tCocinero = new Thread(cocinero);
        tCocinero.start();

        //Crear 3 canibales y lanzarlos
        for (int i = 1; i <= 3; i++) {
            Canibal canibal = new Canibal(laolla, i);
            Thread tCanibal = new Thread(canibal);
            tCanibal.start();
        }


    }
}


class Cocinero implements Runnable {

    private Olla laolla = null;

    public Cocinero(Olla o) {
        laolla = o;
    }

    public void run() {
        int misionero = 0;
        while (true) {
            laolla.echarAlaOlla(++misionero);
            try {
                Thread.sleep(100);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}

class Olla {

    private int tamano = 0;
    private int cuantosEnLaOlla = 0;
    //    private int[] olla=null;
    private int echar = 0, sacar = 0;
    private int cont = 0;

    public Olla(int tamano) {
        this.tamano = tamano;
//        olla=new int[numero];
    }

    public synchronized void echarAlaOlla(int nummisionero) {
        while (cuantosEnLaOlla >= tamano) {
            //Si la olla est· llena
            try {
                System.out.println("No se puede echar a la olla: OLLA  LLENA ");
                wait();
                Thread.sleep(200);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        //Si se puede cocinar habr· que echar otro
        cuantosEnLaOlla++;
        notifyAll();
        System.out.println("		Cocinando al misionero:  " + nummisionero);
        System.out.println("		HAY EN LA OLLA:  " + cuantosEnLaOlla);


    }

    public synchronized int sacardelaOlla(int numerocanibal) {
        int misionero;
        while (cuantosEnLaOlla <= 0) {
            //Si la olla est· vacÌa no se puede sacar
            try {
                wait();
                Thread.sleep(100);
                System.out.println("No hay nada mas que sacar: OLLA VACIA ");
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }


        //Si hay misioneros cocinados se podr·n sacar y comer
        System.out.println("El canibal " + numerocanibal + " est· comiendo " );
        System.out.println("		HAY EN LA OLLA:  " + cuantosEnLaOlla);
        cuantosEnLaOlla--;
        notifyAll();
        return 1;

    }//

}

class Canibal implements Runnable {

    private Olla laolla = null;
    private int numero = 0;

    public Canibal(Olla o, int num) {
        laolla = o;
        numero = num;
    }

    public void run() {

        int canibal;
        while (true) {
            laolla.sacardelaOlla(numero);
            try {
                Thread.sleep(400);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }


}
