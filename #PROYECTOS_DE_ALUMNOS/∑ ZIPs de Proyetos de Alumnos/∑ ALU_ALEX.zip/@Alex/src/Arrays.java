import daw.com.Pantalla;
import daw.com.Teclado;

public class Arrays {

	public static void main(String[] args) {

		int j;
		double g;

		j = 45;
		g = 6.4;

		System.out.println(g + 4);

		// crear un array (2 modos)
		// vacio
		int[] calabaza = new int[3];
		// con valores por defecto
		int[] mitren = { 3, 6, 3, 5, 8 };

		// usar las posiciones del array
		calabaza[0] = 334;
		System.out.println(calabaza[0] + 456);

		// usar una variable como indice de un array
		int h = 2;
		calabaza[h] = 234;

		// saber el tamaño de un tren (NUMERO DE VAGONES)
		int tam = calabaza.length;

		// recorrer un array

		// ejemplo: pintar los elementos del array trenAlex
		System.out.println("-----------------------------");
		int[] trenAlex = { 3, 6, 1, 5, 8 };

		// System.out.println(trenAlex[0]);
		// System.out.println(trenAlex[1]);
		// System.out.println(trenAlex[2]);
		// System.out.println(trenAlex[3]);
		// System.out.println(trenAlex[4]);

		for (int i = 0; i < 5; i++) {
			System.out.println(trenAlex[i]);
		}

		System.out.println("-----------------------------");

		// PLANTILLA
		// for (int i = 0; i < trenAlex.length; i++) {
		// trenAlex[i]
		// }

		// i. Dado un array int[] vectorDeDatos = {8,2,5,4,9,1,0,8,9,3} pintar sus valores por consola

		// int[] vectorDeDatos = {8,2,5,4,9,1,0,8,9,3};
		// for (int i = 0; i < vectorDeDatos.length; i++) {
		// System.out.println( vectorDeDatos[i] );
		// }

		// ii. Dado un array int[] vectorDeDatos = {8,2,5,4,9,1,0,8,9,3} pintar por consola cuantos pares contiene
		// int contador = 0;
		// int[] vectorDeDatos = { 8, 2, 5, 4, 9, 1, 0, 8, 9, 3 };
		// for (int i = 0; i < vectorDeDatos.length; i++) {
		// if (vectorDeDatos[i] % 2 == 0) {
		// contador++;
		// }
		// }
		// System.out.println(contador);

		// iii. Dado un array int[] vectorDeDatos = {8,2,5,4,9,1,0,8,9,3} pintar por consola solo los elementos de
		// posición impar, no los que tengan valor impar, sino los que están en posición (indice) impar
		//
		// int[] vectorDeDatos = { 8, 2, 5, 4, 9, 1, 0, 8, 9, 3 };
		// for (int i = 0; i < vectorDeDatos.length; i++) {
		// if (i % 2 != 0) {
		// System.out.println(vectorDeDatos[i]);
		// }
		// }

		// iv. Crear un array de 15 enteros, rellenarlo con valores aleatorios,
		// y pinta sus valores por pantalla
		// int[] array = new int[15];
		// Random maquinadehacernumerosaleatorios = new Random();
		//
		// for (int i = 0; i < array.length; i++) {
		// int x = maquinadehacernumerosaleatorios.nextInt(20);
		// array[i] = x;
		// }
		// for (int i = 0; i < array.length; i++) {
		// System.out.println(array[i]);
		// }

		// v.Crear un array de 15 enteros, rellenarlo con valores aleatorios,
		// y pintar el numero mayor de ellos por consola
		//
		// int[] array = new int[15];
		// int mayor = 0;
		// Random maquinadehacernumerosaleatorios = new Random();
		//
		// for (int i = 0; i < array.length; i++) {
		// int x = maquinadehacernumerosaleatorios.nextInt(20);
		// array[i] = x;
		// System.out.println(array[i]);
		// }
		// for (int i = 0; i < array.length; i++) {
		// if (array[i] > mayor) {
		// mayor = array[i];
		// }
		// }
		// System.out.println(mayor);

		// vi. Crear un array con un numero aleatorio de elementos, que serán números double.
		// Se rellena con valores también aleatorios, y se pintan sus valores por pantalla.
		// Random maquinadehacernumerosaleatorios = new Random();
		// int x = maquinadehacernumerosaleatorios.nextInt(30) + 1;
		// double[] array = new double[x];
		//
		// for (int i = 0; i < array.length; i++) {
		// array[i] = maquinadehacernumerosaleatorios.nextDouble();
		// System.out.println(array[i]);
		// }

		// vii. Crear un programa que crea un array de 15 enteros,
		// lo rellena con valores solicitados al usuario, y
		// pinta todos los valores nuevamente por consola
		// int[] array = new int[15];
		//
		//
		// for (int i = 0; i < array.length; i++) {
		// x = Teclado.leer();
		// array[i] = x;
		// System.out.println(array[i]);
		// }
		//
		// viii.Crear un programa que crea un array de 15 enteros,
		// lo rellena con valores solicitados al usuario, y
		// pinta solo los valores pares por consola

		int[] array2 = new int[15];
		int x = 0;

		for (int i = 0; i < array2.length; i++) {
			x = Teclado.leerInt();
			array2[i] = x;
			if (x % 2 == 0) {

				Pantalla.escribirInt(x);
			}

		}

		// ix.
		//
		// Crear un programa que crea un array de 15 enteros, lo rellena con valores solicitados al usuario, y
		//
		// pinta por consola solo los valores múltiplos de 3 y de 5 a la vez
		int[] array = new int[15];
		int z = 0;

		for (int i = 0; i < array.length; i++) {
			z = Teclado.leerInt();
			array[i] = z;
			if (z % 3 == 0 && z % 5 == 0) {
				Pantalla.escribirInt(z);

			}

		}

		// x.
		//
		// Crear un array con un numero aleatorio de elementos, que serán números double. Se rellena con

		// valores también aleatorios, y se pinta por pantalla el primer y el ultimo de sus elementos
		//
		// Random maquinadehacernumerosaleatorios = new Random();
		// int y = maquinadehacernumerosaleatorios.nextInt(30) + 1;
		//
		// float[] array3 = new float[y];
		//
		// for (int i = 0; i < array3.length; i++) {
		// float z1=maquinadehacernumerosaleatorios.nextFloat();
		// array3[i]=z1;
		//
		//
		// if (i == 0) {
		// Pantalla.escribirFloat(array3[i]);
		// }
		// if (i == array3.length - 1) {
		// Pantalla.escribirFloat(array3[i]);
		// }
		// }
		// Random maquinadehacernumerosaleatorios = new Random();
		// int y = maquinadehacernumerosaleatorios.nextInt(30) + 1;
		// float[] array3 = new float[y];
		//
		// for (int i = 0; i < array3.length; i++) {
		// float z1 = maquinadehacernumerosaleatorios.nextFloat();
		// array3[i] = z1;
		// }
		// Pantalla.escribirFloat(array3[0]);
		// Pantalla.escribirFloat(array3[ array.length-1]);

		// con el array int[] vectorDeDatos = { 8, 2, 5, 4, 9, 1, 0, 8, 9, 3 }
		// decir si es mayor la media de los numeros pares o la media de lso impares
		int[] vectorDeDatos = { 8, 2, 5, 4, 9, 1, 0, 8, 9, 3 };
		int pares = 0;
		int impares = 0;
		int mediaPares;
		int mediaImpares;
		int sumadelospares = 0;

		for (int i = 0; i < vectorDeDatos.length; i++) {

			if (vectorDeDatos[i] % 2 == 0) {
				pares++;
				sumadelospares = sumadelospares + vectorDeDatos[i];
			}
			if (vectorDeDatos[i] % 2 != 0) {
				impares++;
			}
		}

		mediaPares = sumadelospares / pares;
		Pantalla.escribirInt(mediaPares);
		Pantalla.escribirInt(impares);
		Pantalla.escribirInt(pares);
	}
}
