import daw.com.Pantalla;
import daw.com.Teclado;

import java.util.Random;

public class Array1 {

    public static void main(String[] args) {


        // _____________ TEORIA

        // crear un array vacio con 20 vagones
        // (el crea el array hay que decir el numero de vagones)
        // luego no se puede modificar el numero de vagones
        int[] lista = new int[20];
        // crea el array VACIO
        // (realmente no esta vacio, todos los vagones son un 0)

        // crear un array de 6 elementos
        int[] arr2 = new int[6];
        // crea el array VACIO
        // (realmente no esta vacio, todos los vagones son un 0)

        // crear un array con contenido
        int[] arr4 = {4, 5, 3, 4, 7, 8, 9};
        // se ha creadi un array de 7 vagones y ademas se le
        // ha dado contenido a cada vagon


        // crear un array con un tamaño
        // que se le pide al usuario por teclado.
        // --- leemos un numero
        int tamano = Teclado.leerInt();
        // --- creamos el array con el tamaño que el usuario
        // --- ha dicho
        int[] arr5 = new int[tamano];


        // crear un array con un tamaño desconocido, al azar
        // -- creamos una maquiona de generar numeros al azar
        Random maquinita = new Random();
        // --- con la maquinita creada, le pido que me genere un
        // --- numero entre 0 y 99
        // --- El numero que crea lo guardo en una variable (tam)
        int tam = maquinita.nextInt(100);
        // --- creamos el array con el tamaño que el ha salido al azar
        int[] ar6 = new int[tam];
        // Este array esta VACIO , lo que es alk azar es el numero dfe elementos
        // (de vagones) pero al crearse estan vacios (bueno, tienen 0)


        // Si quiero saber el tamaño que tiene un array
        // uso length:     array.length
        int ttt = ar6.length;  // asi lo pinto
        Pantalla.escribirInt(ar6.length);  // asi lo escribo

        // escribir el vagon 2 del array lista
        Pantalla.escribirInt(lista[2]);
        // escribir el vagon 0 del array lista
        Pantalla.escribirInt(lista[0]);

        // Escribir TODOS LOS VAGONES
        // para ello RECORREMOS EL TREN ENTERO CON EL FOR SIGUIENTE
        // --- El bucle for da tantas vueltas como vagones tenga el array
        // --- como en cada vuelta la variable i cambia y vale cada vez
        // --- el numero de cada vagon
        // --- el buivcle RECORRE CADA VAGON DEL TREN
        // --- Solo queda decidir que se hace con cada vagon
//        for(int i=0;i<lista.length;i++) {
//            lista[i]
//        }

        for (int i = 0; i < lista.length; i++) {
            Pantalla.escribirInt(lista[i]);
        }

        // Escribir del array lista SOLO LOS VAGONES cuyo valor es par
        for (int i = 0; i < lista.length; i++) {
            if (lista[i] % 2 == 0) {
                Pantalla.escribirInt(lista[i]);
            }
        }


        // contar cuantos vagones del array lista tienen valor par
        // inicializamos contador
        int contapares = 0;
        for (int i = 0; i < lista.length; i++) {
            if (lista[i] % 2 == 0) {
                // como el numero es para incfrementamos el contador
                contapares++;
            }
        }
        // al FINAL , FUERA DEL BUCLE, escribimios el resultado
        Pantalla.escribirInt(contapares);


        // Sumamos todos los valores del array  lista
        // inicializamos un sumador
        int suma = 0;
        for (int i = 0; i < lista.length; i++) {
            suma = suma + lista[i];
        }
        // al FINAL , FUERA DEL BUCLE, escribimios el resultado
        Pantalla.escribirInt(suma);


        // encontrar el valor mayor del array lista
        // --- creo una variable donde guardar el numero mayor
        // --- la inicializo con un valor bajo, no puedo poiner un numero
        // --- alto no sea que en el array no haya valrores mayores que ese
        int mayor = 0;
        for (int i = 0; i < lista.length; i++) {
            if (lista[i] > mayor) {
                mayor = lista[i];
            }
        }
        // al FINAL , FUERA DEL BUCLE, escribimios el resultado
        Pantalla.escribirInt(mayor);

// _______ CUIDADIN
// en el ejericioc anterior, ¿y si en el array hay numeros negativos....?
// ... no puedo poner mayor = 0 .....
// TRUCO:   poner mayor con el valor del primer vagon del array
// Ejericioc retocado: cambiar la primera linea por
//        int mayor = list[0];

//       MORADO.X Crear un array con un numero aleatorio de elementos,
//       que serán números float. Se rellena con
//       valores también aleatorios, y se pinta por pantalla
//       el primer y el ultimo de sus elementos
        Random calabaza = new Random();
        // --- como no dice el rango del numero al azar , elijo poner 20
        // --- como podia haber elegido cualquier otra cosa
        int tamanoarray = calabaza.nextInt(20) + 1;  // el NUMERO de vagones es un int
        // el poner un +1   es por que el numero al  azar puede ser 0.....
        // --- creamos el array con el tamaño sacado al azar
        float[] numeros = new float[tamanoarray];
        for (int i = 0; i < numeros.length; i++) {
            // generamos un nuemro aleatorio para meterlo en el array
            // CUIDADO que el array CONTIENE DOUBLE
            // el numero generado al azar lo metemos en cada vagon del tren
            numeros[i] = calabaza.nextFloat();
        }
        Pantalla.escribirFloat(numeros[0]);
        Pantalla.escribirFloat(numeros[numeros.length - 1]);


//        4.a.1
//        Dado un array
//        int[] vectorDeDatos = {8,2,5,4,9,1,0,8,9,3}
//        construir un programa que copie el vectorDeDatos en
//        el array llamado copiaDeDatos, pero sumando
//        2 a cada elemento, y que escriba el array
//        copiaDeDatos por pantalla, esto es, que salga :
//        "el elemento 1 de copiadedatos es 10”
//        "el elemento 2 de copiadedatos es 4"
//        "el elemento 3 de copiadedatos es 7"
//        "el elemento 4 de copiadedatos es 6" …etc…
        int[] vectorDeDatos = {8, 2, 5, 4, 9, 1, 0, 8, 9, 3};
        int[] copiadedatos = new int[10];
//        int[] copiadedatos = new int[vectorDeDatos.length]; // otra manera mas pija

        for (int i = 0; i < vectorDeDatos.length; i++) {
            copiadedatos[i] = vectorDeDatos[i] + 2;
            Pantalla.escribirString("el elemento " + i + " de copiadedatos es" + copiadedatos[i]);
        }


//
//        Hacer un bucle que pida por teclado 10 números enteros y
//        los almacene en un array, y que se calcule posteriormente
//        la suma de los números que sean pares y la suma de los números
//        que sean impares, y que nos diga por pantalla cual de las dos
//        sumas es mayo
        int par = 0;
        int impar = 0;
        int[] arraysClase = new int[10];

        for (int i = 0; i < arraysClase.length; i++) {
            arraysClase[i] = Teclado.leerInt("introduce un numero");
        }

        for (int i = 0; i < arraysClase.length; i++) {
            if (arraysClase[i] % 2 == 0) {
                par = arraysClase[i] + par;
            } else {
                impar = arraysClase[i] + impar;
            }
        }
        if (par > impar) {
            Pantalla.escribirInt("suma de los pares", par);

        }
        if (impar > par) {


            Pantalla.escribirInt("suma de los impares", impar);
        }

//        4.a.4. Realiza un programa que pida por teclado 11 números enteros
//        y los almacene en un array, para posteriormente
//        mostrarlos en el orden inverso al que fueron introducidos

        int[] nums = new int[11];

        for (int i = 0; i < nums.length; i++) {
            nums[i] = Teclado.leerInt("introduce un numero");
        }


//      4.a.3  Temperaturas. Se piden por teclado la temperatura de
//      cada uno de los 7 días de una semana. Se pide por teclado
//      luego una nueva temperatura, y se compara con las leídas
//       anteriormente para decir si tal nueva temperatura se dio
//      en algún día de la semana.

        int[] temperaturasdelasemana = new int[7];

        for (int i = 0; i < 7; i++) {
            temperaturasdelasemana[i] = Teclado.leerInt("dime temp");
        }

        int nueva = Teclado.leerInt("dime temp a buscar");


        for (int i = 0; i < 7; i++) {
            if (temperaturasdelasemana[i] == nueva) {
                Pantalla.escribirString("SI");
            }
        }


    }

}
