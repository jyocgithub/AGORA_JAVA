package poo;

public class Coche {

	// --------------- ATRIBUTOS
	private String marca;
	private int velocidad;
	private double km;

	// -------------- METODOS

	// CONSTRUCTORES
	public Coche(String marca, int velocidad, double km) {
		this.marca = marca;
		setVelocidad(velocidad);
		this.km = km;
	}

	public Coche(String m, int v) {
		marca = m;
		velocidad = v;
	}

	public Coche() {
		marca = "";
		velocidad = 0;
		km = 0;
	}

	// GETTERS Y SETTERS

	public void setMarca(String x) {
		marca = x;
	}

	public String getMarca() {
		return marca;
	}

	public int getVelocidad() {
		return velocidad;
	}

	public void setVelocidad(int velocidad) {
		if (velocidad < 0) {
			velocidad = 0;
		}
		this.velocidad = velocidad;
	}

	public double getKm() {
		return km;
	}

	public void setKm(double km) {
		this.km = km;
	}

	// METODOS PROPIOS

	public void acelerar() {
		velocidad = velocidad + 10;
	}

	public void frenar() {
		velocidad = velocidad - 10;
	}

	public void renovarKm(double x) {
		km = x;
	}

}
