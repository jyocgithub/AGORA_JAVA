package poo;

public class Vivienda {
	private String calle;
	private int numero;
	private double precio;
	private int superﬁcie;
	private boolean conGarage;

	public Vivienda() {

	}

	public Vivienda(String calle, int numero, double pp, int superﬁcie, boolean conGarage) {
		super();
		this.calle = calle;
		this.numero = numero;
		if (pp >= 0) {
			this.precio = pp;
		}
		this.superﬁcie = superﬁcie;
		this.conGarage = conGarage;
	}

	public Vivienda(String calle, int numero, int superﬁcie, boolean conGarage) {
		super();
		this.calle = calle;
		this.numero = numero;
		this.superﬁcie = superﬁcie;
		this.conGarage = conGarage;
	}

	public String getCalle() {
		return calle;
	}

	public void setCalle(String calle) {
		this.calle = calle;
	}

	public int getNumero() {
		return numero;
	}

	public void setNumero(short numero) {
		this.numero = numero;
	}

	public double getPrecio() {
		return precio;
	}

	public void setPrecio(double pp) {
		if (pp >= 0) {
			this.precio = pp;
		}
	}

	public int getSuperﬁcie() {
		return superﬁcie;
	}

	public void setSuperﬁcie(int superﬁcie) {
		this.superﬁcie = superﬁcie;
	}

	public boolean isConGarage() {
		return conGarage;
	}

	public void setConGarage(boolean conGarage) {
		this.conGarage = conGarage;
	}

}
