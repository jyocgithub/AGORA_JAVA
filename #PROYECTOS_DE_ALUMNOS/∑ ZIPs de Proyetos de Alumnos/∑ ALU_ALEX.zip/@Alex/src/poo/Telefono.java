package poo;

import daw.com.Pantalla;

//Una clase Movil tiene estos atributos
//int capacidadMaxima  (se mide en mb) 
//int numeroMaximoAplicaciones 
//int capacidadUsada 
//int numeroAplicacionesActuales
//Crear getters y setters y un constructor que recibe capacidadMáxima y númeroMáximoAplicaciones, y pone capacidadUsada a 0 y númeroAplicacionesActuales a 0
//Crear estos métodos:
//void añadirAplicación(int cap),  que tiene parámetro capacidad (tamaño) de la aplicación a añadir. 
//No puede añadir una aplicación si se supera el tamaño máximo del móvil, 
//o el número máximo de aplicaciones permitido. Si se puede añadir la aplicación, se cambian los atributos capacidadUsada y numeroAplicacionesActuales
//void borrartodo() , pone capacidadUsada a 0 y númeroAplicacionesActuales a 0
//void mostrarEstado() , que escribe por consola los cuatro atributos.
//Crear una clase Prueba con un main para probar todas las funcionalidades de la clase Movil.

public class Telefono {
	private int capacidadMaxima;
	private int numeroMaximoAplicaciones;
	private int capacidadUsada;
	private int numeroAplicacionesActuales;

	public void espaciolibre() {
		int capacidadLibre;
		capacidadLibre = capacidadMaxima - capacidadUsada;
		Pantalla.escribirInt(capacidadLibre);

	}

	// get-set
	public void MostrarEstado() {

	}

	public void BorrarTodo() {
		capacidadUsada = 0;
		numeroAplicacionesActuales = 0;

	}

	void añadirAplicación(int capacidad) {

		if (capacidad < (capacidadMaxima - capacidadUsada) && numeroMaximoAplicaciones > numeroAplicacionesActuales) {
			capacidadUsada = capacidadUsada + capacidad;
			numeroAplicacionesActuales = numeroAplicacionesActuales + 1;

		} else {

			Pantalla.escribirString("no entra ");
		}

	}

	public int getCapacidadMaxima() {

		return capacidadMaxima;
	}

	public void setCapacidadMaxima(int capacidad) {

		this.capacidadMaxima = capacidadMaxima;
	}

	public int getNumeroMaximoAplicaciones() {
		return numeroMaximoAplicaciones;

	}

	public void setNumeroMaximoAplicaciones(int numeroMaximoAplicaciones) {
		this.numeroMaximoAplicaciones = numeroMaximoAplicaciones;

	}

	public int getcapacidadUsada() {

		return capacidadUsada;
	}

	public void setCapacidadUsada(int capacidadUsada) {

		this.capacidadUsada = capacidadUsada;
	}

	public int getNumeroAplicacionesActuales() {
		return numeroAplicacionesActuales;
	}

	public void setnumeroAplicacionesActuales(int numeroAplicacionesActuales) {

		this.numeroAplicacionesActuales = numeroAplicacionesActuales;

	}

}
