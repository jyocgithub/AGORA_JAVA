package poo;

public class Papel {
	private String color;
	private int grosor;

	public Papel(String color, int grosor) {
		super();
		this.color = color;
		this.grosor = grosor;
	}

	public String getColor() {
		return color;
	}

	public void setColor(String color) {
		this.color = color;
	}

	public int getGrosor() {
		return grosor;
	}

	public void setGrosor(int grosor) {
		this.grosor = grosor;
	}

	@Override
	public String toString() {
		return "Papel [color=" + color + ", grosor=" + grosor + "]";
	}

}
