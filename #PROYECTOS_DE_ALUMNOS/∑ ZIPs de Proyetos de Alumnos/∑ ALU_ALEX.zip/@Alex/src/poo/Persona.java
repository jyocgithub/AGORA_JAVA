package poo;

import daw.com.Pantalla;

//Hacer un programa que cree una clase Persona, con estos atributos: 
//String nombre, int edad, String dni. 
//Crear un constructor que de valores a los atributos, y estos métodos:
//void esMayorDeEdad() escribe por pantalla si la persona es mayor de edad o si no lo es. 
//int cuantoHaceMayorEdad() es un método que no recibe parámetro y devuelve el número de años que hace que la persona es mayor de edad (si la persona es menor de edad deberá por lo tanto devolver un valor negativo)
//boolean asignarDNI() es un método que recibe un String por parámetro, y lo asigna al DNI de la Persona. Sin embargo, no debe asignar el DNI si éste no es correcto (es correcto si tiene 9 caracteres, ni más ni menos). El método además devuelve un valor booleano dependiendo de si el DNI se ha validado (y por lo tanto, se ha asignado al atributo de la clase )
//boolean estaJubilado() devuelve true o false dependiente de si la persona esta jubilada o no Se considera que una persona se jubila a los 65.
public class Persona {

	private String nombre;
	private int edad;
	private String dni;

	public Persona() {

		nombre = "";
		edad = 1;
		dni = "";

	}

	public boolean estaJubilado(int cuandomejubilo) {
		boolean resultado;

		if (edad >= cuandomejubilo) {

			resultado = true;
		} else {
			resultado = false;
		}

		return resultado;
	}

	public boolean asignarDNI(String lola) {
		boolean pirata = false;
		if (lola.length() == 9) {

			this.dni = lola;
			pirata = true;
		} else {
			pirata = false;
		}

		return pirata;
	}

	int cuantoHaceMayorEdad(int cuandoMayor) {
		int a = cuandoMayor;
		int calculo = edad - a;
		return calculo;

	}

	public Persona(String nombre, int edad, String dni) {

		this.dni = dni;
		this.edad = edad;
		this.nombre = nombre;

	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public int getEdad() {
		return edad;

	}

	public void setEdad(int edad) {
		this.edad = edad;
	}

	public String setDni() {
		return dni;

	}

	public void getDni(String dni)

	{

		this.dni = dni;
	}

	public void esMayorDeEdad() {

		if (edad >= 18) {

			Pantalla.escribirString("eres mayor de edad");
		} else {
			Pantalla.escribirString("no eres mayor de edad");
		}

	}

}
