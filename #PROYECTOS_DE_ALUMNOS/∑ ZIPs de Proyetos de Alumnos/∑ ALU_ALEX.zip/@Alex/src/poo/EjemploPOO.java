package poo;

public class EjemploPOO {
	public static void main(String[] args) {

		// Persona personaa, personab;
		// personaa = new Persona("47411413t", 37, "paco");
		// personab = new Persona();
		//
		// personaa.esMayorDeEdad();
		// int cu = Teclado.leerInt("cuando me jubilo");
		// boolean ss = personaa.estaJubilado(cu);
		// int mayoria = Teclado.leerInt("edad para ser mayor de edad ");
		// int cuan = personaa.cuantoHaceMayorEdad(mayoria);
		// Pantalla.escribirInt(personaa.cuantoHaceMayorEdad(mayoria));
		// personab.setNombre("JUANILLO");
		// String nom = personab.getNombre();
		// Pantalla.escribirString("\n");
		// Pantalla.escribirString(nom);
		//
		// boolean nn = personab.asignarDNI("ytfuyfuf");
		// if (nn == false) {
		// Pantalla.escribirString("no se pudo poner el dni no era valido");
		// }

		Telefono telefono1, telefono2;
		telefono1 = new Telefono();
		telefono2 = new Telefono();
		telefono1.setCapacidadMaxima(100);
		telefono1.setCapacidadUsada(80);
		telefono1.añadirAplicación(10);
		telefono1.setNumeroMaximoAplicaciones(10);
		telefono1.setnumeroAplicacionesActuales(2);

	}

	public static int sumar(int a, int b) {

		int suma = a + b;

		return suma;

	}

}
