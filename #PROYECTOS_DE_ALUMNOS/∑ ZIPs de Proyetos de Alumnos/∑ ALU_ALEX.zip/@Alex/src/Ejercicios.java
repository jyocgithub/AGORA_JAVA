import daw.com.Pantalla;
import daw.com.Teclado;

public class Ejercicios {

	public static void main(String[] args) {

		Pantalla.escribirString("Inicio del programa\nTema de metodos\n");
		Pantalla.escribirString("hola\n");
		Pantalla.escribirString("dame dos num\n");

		int a = Teclado.leerInt();
		int b = Teclado.leerInt();

		float p = 5.25f;

		int k = 989;

		int sss = sumar(a, b);
		int mm = multiplicar(a, b);

		Pantalla.escribirInt(sss);
		Pantalla.escribirSaltoLinea();
		Pantalla.escribirInt(mm);
		Pantalla.escribirSaltoLinea();

		int azar = Libreria.aleatorio(10, 20);

		Pantalla.escribirInt(azar);
		Pantalla.escribirString("Fin del programa\n");

		char w = '%';

		String cc = "hola que";

	}

	public static int sumar(int j, int k) {
		int suma = j + k;
		return suma;
	}

	public static int multiplicar(int j, int k) {
		int suma = j * k;
		return suma;
	}

}
