package com.hibernate.main;

import java.util.InputMismatchException;
import java.util.Scanner;


public class Principal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Gestion gestion = new Gestion();

		Scanner leer = new Scanner(System.in);
		int opcion = 0;

		gestion.leerArrayLists();
		
		do {
			System.out.println("Elegir la opcion a realizar");
			System.out.println("**************************");
			System.out.println("1. Dar de alta un empleado");
			System.out.println("2. Modificar nombre del empleado");
			System.out.println("3. Modificar departamento de un empleado");
			System.out.println("4. Borrar un empleado");
			System.out.println("5. Modificar departamento por codigo");
			System.out.println("6. Modificar departamento por nombre");
			System.out.println("7. Consultar proyecto y departamento por dni o codigo del empleado");
			System.out.println("8. Consultar  proyecto por fechas");
			System.out.println("9. Asociar proyecto a un empleado");
			System.out.println("10. Listar empleado por departamento (Colleciones)");
			System.out.println("11. Listar empleado por departamento (HQL)");
			System.out.println("12. Salir del programa");

			try {
				opcion = leer.nextInt();
			} catch (InputMismatchException e) {
				System.out.println("Error:Solo se permite introducir numeros");
				break;
			}
				switch (opcion) {
				case 1:
			
					gestion.altaEmple();
					
					break;
				case 2:
					gestion.modificarNombreEmple();
					break;
				case 3:
					gestion.cambiarDepDeEmple();
					break;
				case 4:
					gestion.borrarEmple();
					break;
				case 5:
					gestion.modDepCod();
					break;
				case 6:
					gestion.modDepNombre();
					break;
				case 7:
					gestion.consultarProy();
					break;
				case 8:
					//gestion.consultarProyPorFechas();
					break;
				case 9:
					gestion.asociarProyAEmple();
					break;
				case 10:
					gestion.listarEmpleColle();
					break;
				case 11:
					gestion.listarEmpleHQL();
					break;
				default:
					if (opcion != 12)
						System.out.println("Opcion incorrecta");
						System.out.println("--------------------");
					break;
				}
			
		} while (opcion != 12);

		System.out.println("Fin del programa");
		System.exit(-1);

	}

}

