package com.hibernate.main;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.exception.ConstraintViolationException;

import com.hibernate.modelo.Departamento;
import com.hibernate.modelo.Empleado;
import com.hibernate.modelo.Proyecto;
import com.hibernate.utilidades.Utilidades;

public class Gestion {

	private Utilidades ut = new Utilidades();
	private ArrayList<Empleado> listaEmple = new ArrayList<>();
	private ArrayList<Departamento> listaDep = new ArrayList<>();
	private ArrayList<Proyecto> listaProy = new ArrayList<>();

	int codigoMultiMetodo;
	String codigoMultiMetodoString;

	public void leerArrayLists() {
		List listaDeElementos;
		Iterator it;
		int dsc = 0;

		// Conseguimos un objeto sesion para comunicarnos con la BD
		Session session = Utilidades.getSessionFactory().openSession();
		// abrimos una transaccion
		session.beginTransaction();

		// Leemos arraylist de Empleados
		Query query1 = session.createQuery("from Empleado");
		listaDeElementos = query1.list();
		it = listaDeElementos.iterator();
		Empleado e = null;
		while (it.hasNext()) {
			e = (Empleado) it.next();
			listaEmple.add(e);
		}

		// Leemos arraylist de proyecto
		Query query2 = session.createQuery("from Proyecto");
		listaDeElementos = query2.list();
		it = listaDeElementos.iterator();
		Proyecto proy = null;
		while (it.hasNext()) {
			proy = (Proyecto) it.next();
			listaProy.add(proy);
		}

		// Leemos arraylist de departamento
		Query query3 = session.createQuery("from Departamento");
		listaDeElementos = query3.list();
		it = listaDeElementos.iterator();
		Departamento dep = null;
		while (it.hasNext()) {
			dep = (Departamento) it.next();
			listaDep.add(dep);
		}

	}

	public void altaEmple() {

		String ultimoCod;
		String codEmple = ut.leerString("Codigo Emple: ");
		String nombre = ut.leerString("Nombre: ");
		String ape = ut.leerString("Apellido: ");
		String dni = ut.leerString("Dni: ");
		String codDep = ut.leerString("Codigo departamento: ");

		try {

			Departamento dep = null;
			for (Departamento d : listaDep) {
				if (d.getCodDep().equals(codDep)) {
					dep = d;

				}
			}
			if (dep == null) {
				System.out.println("El departamento no existe");
				return;
			}
			altaEmpleParam(codEmple, dep, dni, nombre, ape);

		} catch (ConstraintViolationException e) {
			System.out.println("El codigo de empleado no puede ser duplicada");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void altaEmpleParam(String codEmple, Departamento dep, String dni, String nombre, String ape)
			throws Exception {

		Empleado emple = new Empleado(codEmple, dep, dni, nombre, ape);
		guardarEmple(emple);

	}

	public void guardarEmple(Empleado emple) {
		listaEmple.add(emple);
		Session session = null;
		try {

			// Conseguimos un objeto sesi�n para comunicarnos con la BD
			session = Utilidades.getSessionFactory().openSession();
			// abrimos una transacci�n
			session.beginTransaction();
			Query query = session.createQuery("from Empleado");
			// Guardamos el objeto en la sesi�n
			session.save(emple);
			// Commit de la transacci�n
			session.getTransaction().commit();

			// Cerramos la factoria de sesiones, sino el programa no finalizar�
			// Utilidades.getSessionFactory().close();

		} catch (Exception e) {
			session.getTransaction().rollback();
			throw e;
		}
		System.out.println("Alta Emple ha finalizado bien");

		// } catch (NonUniqueObjectException e) {
		// System.out.println("El codigo de empleado no puede ser duplicada");

		// }
	}

	public void modificarNombreEmple() {
		// Conseguimos un objeto sesion para comunicarnos con la BD
		Session session = Utilidades.getSessionFactory().openSession();
		// abrimos una transaccion
		session.beginTransaction();

		Query query = session.createQuery("from Empleado");

		int i = 0;
		List listNom = query.list();
		Iterator itNom = listNom.iterator();
		Empleado emple = null;
		while (itNom.hasNext()) {
			emple = (Empleado) itNom.next();
			listaEmple.add(emple);
			System.out.println(i++ + " " + emple.getNombre());
		}

		int opcion = ut.leerInt("Elige el nombre a modificar");
		// int opcion =1;
		String nuevoNom = ut.leerString("Introducir el nuevo nombre: ");

		emple.setNombre(nuevoNom);
		// e.getCodDep();
		listaEmple.add(opcion, emple);

		// Guardamos el objeto en la sesion
		session.saveOrUpdate(emple);
		// Commit de la transaccion
		session.getTransaction().commit();

		// Cerramos la factoria de sesiones, sino el programa no finalizara
		// Utilidades.getSessionFactory().close();

		System.out.println("Modficacion del nombre de empleado ha finalizado bien");
	}

	public void cambiarDepDeEmple() {
		// Conseguimos un objeto sesi�n para comunicarnos con la BD
		Session session = Utilidades.getSessionFactory().openSession();
		// abrimos una transacci�n
		session.beginTransaction();

		Query query = session.createQuery("from Empleado");

		int i = 0;

		List list = query.list();
		Iterator it = list.iterator();
		Empleado e = null;
		while (it.hasNext()) {
			e = (Empleado) it.next();
			listaEmple.add(e);
			System.out.println(i++ + " " + e.getCodEmple() + " " + e.getNombre());

		}

		int opcion = ut.leerInt("Elige el empleado a modificar");

		// Leemos arraylist de Empleados
		Query query2 = session.createQuery("from Departamento");
		List list2 = query2.list();
		Iterator it2 = list2.iterator();
		Departamento dep = null;
		while (it2.hasNext()) {
			dep = (Departamento) it2.next();
			listaDep.add(dep);

			System.out.println(dep.getCodDep() + " " + dep.getNombreDep());
		}

		String nuevoDep = ut.leerString("Introduce el nuevo departamento: ");

		for (Departamento d : listaDep) {
			if (d.getCodDep().equals(nuevoDep)) {
				dep = d;

			}
		}
		if (dep == null) {
			System.out.println("El departamento no existe");
			return;
		}

		e.setDepartamento(dep);
		listaEmple.add(opcion, e);

		// Guardamos el objeto en la sesi�n
		session.saveOrUpdate(e);
		// Commit de la transacci�n
		session.getTransaction().commit();

		// Cerramos la factoria de sesiones, sino el programa no finalizar�
		// Utilidades.getSessionFactory().close();

		System.out.println("Modficacion del departamento de empleado ha finalizado bien");
	}

	public void borrarEmple() {

		// buscamos el empleado a asociar
		System.out.println("Busqueda de empleado a eliminar");
		Empleado empParaEliminar = buscarEmpleado();
		if (empParaEliminar == null) return;

		// control de excepciones
		// miramos si el empleado esta asociado a un proyecto

		// excepcion al borrar un empleado que esta asociado un proyecto
		for (Proyecto p : listaProy) {
			if (codigoMultiMetodoString.equals(p.getEmpleado())) {
				System.out.println("No se puede borrar el empleado " + empParaEliminar.getNombre());
				System.out.println("Esta asociado al proyecto " + p.getNombre());
				return;
			}
		}

		// borramos al empleado elegido
		// primero del arraylist
		listaEmple.remove(codigoMultiMetodo);
		// segundo de la bbdd
		// Conseguimos un objeto sesi?n para comunicarnos con la BD
		Session session = Utilidades.getSessionFactory().openSession();
		// org.hibernate.Query query = session.createQuery("from Empleado");
		// abrimos una transacci?n
		session.beginTransaction();
		session.delete(empParaEliminar);
		session.getTransaction().commit();

	}

	public void modDepCod() {
		try {
			// Conseguimos un objeto sesi�n para comunicarnos con la BD
			Session session = Utilidades.getSessionFactory().openSession();
			// abrimos una transacci�n
			session.beginTransaction();

			Query query = session.createQuery("from Departamento");

			int i = 0;
			List list = query.list();
			Iterator it = list.iterator();
			Departamento dep = null;
			while (it.hasNext()) {
				dep = (Departamento) it.next();
				listaDep.add(dep);

				System.out.println(i++ + " " + dep.getCodDep() + " " + dep.getNombreDep());

			}

			int opcion = ut.leerInt("Elige el codigo a modificar");
			String nuevoCod = ut.leerString("Introducir el nuevo codigo: ");

			dep.setCodDep(nuevoCod);
			listaDep.add(opcion, dep);

			// Guardamos el objeto en la sesi�n
			session.saveOrUpdate(dep);
			// Commit de la transacci�n
			session.getTransaction().commit();

			// Cerramos la factoria de sesiones, sino el programa no finalizar�
			// Utilidades.getSessionFactory().close();

			System.out.println("Modficacion del nombre de departamento ha finalizado bien");
		} catch (HibernateException e) {
			System.out.println("El codigo no se puede modificar.Opcion cancelada");
		}
	}

	public void modDepNombre() {
		// Conseguimos un objeto sesi�n para comunicarnos con la BD
		Session session = Utilidades.getSessionFactory().openSession();
		// abrimos una transacci�n
		session.beginTransaction();

		Query query = session.createQuery("from Departamento");

		int i = 0;
		List list = query.list();
		Iterator it = list.iterator();
		Departamento dep = null;
		while (it.hasNext()) {
			dep = (Departamento) it.next();
			listaDep.add(dep);

			System.out.println(i++ + " " + dep.getNombreDep());

		}

		int opcion = ut.leerInt("Elige el nombre a modificar");
		String nuevoNom = ut.leerString("Introducir el nuevo nombre: ");

		dep.setNombreDep(nuevoNom);
		listaDep.add(opcion, dep);

		// Guardamos el objeto en la sesi�n
		session.save(dep);
		// Commit de la transacci�n
		session.getTransaction().commit();

		// Cerramos la factoria de sesiones, sino el programa no finalizar�
		// Utilidades.getSessionFactory().close();

		System.out.println("Modficacion del nombre de departamento ha finalizado bien");
	}

	public void consultarProy() {
		SimpleDateFormat formateador = new SimpleDateFormat("dd/MM/yyyy");

		Empleado e = buscarEmpleado();
		System.out.println("Datos del empleado");
		System.out.println("Nombre: " + e.getNombre());
		System.out.println("Cod emple: " + e.getCodEmple());
		System.out.println("Apellido: " + e.getApellido());
		System.out.println("Dni: " + e.getDni());
		System.out.println("Cod Dep: " + e.getDepartamento().getCodDep());
		System.out.println("-------------------------");
		for (Proyecto p : listaProy) {
			if (p.getEmpleado().getCodEmple().equals(e.getCodEmple())) {

				System.out.println("");
				System.out.println("Datos del proyecto");
				System.out.println("Nombre: " + p.getNombre());
				System.out.println("Cod proyecto: " + p.getCodPro());
				// System.out.println("Codigo emple: " + p.getEmpleado().getCodEmple());
				String fini = formateador.format(p.getCodFechaIni());
				String ffin = formateador.format(p.getCodFechaFin());
				System.out.println("Fecha Inicio: " + fini);
				System.out.println("Fecha Fin: " + ffin);

			}
		}
		for (Departamento d : listaDep) {
			if (e.getDepartamento().getCodDep().equals(d.getCodDep())) {
				System.out.println("--------------------------");
				System.out.println("Datos del Departamento");
				System.out.println("Nombre :" + d.getNombreDep());
				System.out.println("Codigo Dep :" + d.getCodDep());
				System.out.println("Localizaci�n :" + d.getLocalizacion());
				return;
			}
		}
	}

	public void consultarProyPorFechas() { // Recoger fechas por teclado
		System.out.println("Buscar proyectos entre fechas. Escriba las fechas a buscar");

		String fTecladoIni = ut.leerString("Indique la fecha inicial:");
		String fTecladoFin = ut.leerString("Indique la fecha final:");

		SimpleDateFormat formateador = new SimpleDateFormat("dd/MM/yyyy");

		// estas son fechas en Java, no de Sql
		Date fDatedadaIni, fDatedadaFin;

		try {
			fDatedadaIni = formateador.parse(fTecladoIni);
			fDatedadaFin = formateador.parse(fTecladoFin);
			// convertimos a fechas date de sql
			java.sql.Date fsqlini = new java.sql.Date(fDatedadaIni.getTime());
			java.sql.Date fsqlfin = new java.sql.Date(fDatedadaFin.getTime());

			// hacer HQL completo
			String HQLString = "FROM Proyecto AS pr WHERE pr.codFechaIni > " + fsqlini + " AND pr.codFechaFin < "
					+ fsqlfin;

			// Conseguimos un objeto sesion para comunicarnos con la BD
			Session session = Utilidades.getSessionFactory().openSession();
			// abrimos una transaccion
			session.beginTransaction();

			Query query = session.createQuery(HQLString);
			session.getTransaction().commit();
			List list = query.list();
			Iterator it = list.iterator();
			boolean hayproyectos = false;
			Proyecto proy;
			System.out.println("Datos de proyecto entre fechas " + fTecladoIni + " y " + fTecladoFin);
			while (it.hasNext()) {
				proy = (Proyecto) it.next();
				System.out.println("Proyecto :" + proy.getNombre());
				System.out.println("Codigo :" + proy.getCodPro());
				hayproyectos = true;
			}

			// no hay proyectos entra las fechas dadas
			if (!hayproyectos) {
				System.out.println("No hay proyectos entre las fechas dadas");
			}
		} catch (ParseException e) {
			e.printStackTrace();
		}

	}

	public void asociarProyAEmple() {

		// buscamos el empleado a asociar
		System.out.println("Busqueda de proyecto para cambiar Jefe de Proyecto");
		Proyecto proyParaAsociar = buscarProyecto();
		if (proyParaAsociar == null) return;
		String nom = buscarEmpleadoPorId(proyParaAsociar.getEmpleado().getCodEmple()).getNombre();
		System.out.println("El proyecto indicado tiene asociado el empleado " + nom + " como Jefe de proyecto");

		// buscamos el empleado a asociar
		System.out.println("Busqueda de un nuevo empleado a asignar como Jefe de Proyecto");
		Empleado empParaAsociar = buscarEmpleado();
		if (empParaAsociar == null) return;

		// asociamos el proyecto al empleado
		proyParaAsociar.setEmpleado(empParaAsociar);
		// guardamos ern la bbdd el proyecto cambiado
		// Conseguimos un objeto sesion par comunicarnos con la BD
		Session session = Utilidades.getSessionFactory().openSession(); // abrimos una transaccion
		session.beginTransaction(); // session.save(proyParaAsociar);
		session.update(proyParaAsociar);
		session.getTransaction().commit();
		System.out.println("Asociar proyecto a un empleado finalizado bien");
	}

	public void listarEmpleColle() {
		Departamento dep = buscarDepartamento();
		System.out.println("Datos de empleados del departamento seleccionado");
		for (Empleado e : listaEmple) {
			if (dep.getCodDep().equals(e.getCodEmple())) {
				System.out.println("Nombre: " + e.getNombre());
				System.out.println("Apellido: " + e.getApellido());
				System.out.println("Dni: " + e.getDni());
				System.out.println("Codigo departamento: " + e.getCodEmple());
				System.out.println("--------------------------------------");

			}

		}
	}

	public void listarEmpleHQL() {
		// Recoger departamento
		Departamento d = buscarDepartamento();
		if (d == null) return;

		// elegir empleado
		System.out.println("Indique el metodo de ordenacion:");
		System.out.println("1.- por Nombre");
		System.out.println("2.- por Apellido");
		String op1 = ut.leerString("Opcion deseada: ");
		while (!(op1.equals("1") || op1.equals("2"))) {
			op1 = ut.leerString("Opcion err�nea, elija otra: ");
		}
		String textoOrden = (op1.equals("1") ? "EM.nombre" : "EM.apellido");

		// Conseguimos un objeto sesion para comunicarnos con la BD
		Session session = Utilidades.getSessionFactory().openSession();
		// abrimos una transaccion
		session.beginTransaction();

		// hacer HQL completo
		String HQLString = "FROM Empleado AS EM WHERE EM.codDep = '" + d.getCodDep() + "'  ORDER BY " + textoOrden;
		Query query = session.createQuery(HQLString);
		List list = query.list();
		Iterator it = list.iterator();

		System.out.println("Datos de empleados del departamento " + d.getNombreDep());
		while (it.hasNext()) {
			Empleado e = (Empleado) it.next();
			System.out.println("Nombre: " + e.getNombre());
			System.out.println("Apellido: " + e.getApellido());
			System.out.println("DNI: " + e.getDni());
			System.out.println("Codigo de departamento: " + e.getCodEmple());
			System.out.println("...........");
		}

		session.getTransaction().commit();

		// Cerramos la factoria de sesiones, sino el programa no finalizara
		// Utilidades.getSessionFactory().close();

		System.out.println("Operacion finalizado bien");
	}

	public Empleado buscarEmpleado() {
		Empleado resultado;
		// elegir empleado
		System.out.println("Indique el dato por el que buscar al empleado:");
		System.out.println("1.- Codigo");
		System.out.println("2.- DNI");
		String op1 = ut.leerString("Opcion deseada: ");
		while (!(op1.equals("1") || op1.equals("2"))) {
			op1 = ut.leerString("Opcion err�nea, elija otra: ");
		}
		if (op1.equals("1")) {
			// Conseguimos un objeto sesion para comunicarnos con la BD
			Session session = Utilidades.getSessionFactory().openSession();
			// abrimos una transaccion
			session.beginTransaction();
			// Leemos arraylist de Empleados
			Query query1 = session.createQuery("from Empleado");
			List lista = query1.list();
			Iterator it = lista.iterator();
			Empleado e = null;
			while (it.hasNext()) {
				e = (Empleado) it.next();
				listaEmple.add(e);
				System.out.println(e.getCodEmple() + " " + e.getNombre());
			}
		} else {
			// Conseguimos un objeto sesion para comunicarnos con la BD
			Session session = Utilidades.getSessionFactory().openSession();
			// abrimos una transaccion
			session.beginTransaction();
			// Leemos arraylist de Empleados
			Query query1 = session.createQuery("from Empleado");
			List lista = query1.list();
			Iterator it = lista.iterator();
			Empleado e = null;
			while (it.hasNext()) {
				e = (Empleado) it.next();
				listaEmple.add(e);
				System.out.println(e.getDni() + " " + e.getNombre());
			}
		}
		String opcion = (op1.equals("1") ? "codigo" : "DNI");

		String op2 = ut.leerString("Indique el valor del " + opcion + " para buscar el empleado: ");

		// buscamos el empleado
		int i;
		for (i = 0; i < listaEmple.size(); i++) {
			if (op1.equals("1")) {
				if (op2.equals(listaEmple.get(i).getCodEmple())) {
					resultado = listaEmple.get(i);
					codigoMultiMetodoString = listaEmple.get(i).getCodEmple();
					codigoMultiMetodo = i;
					return resultado;
				}
			} else {
				if (op2.equals(listaEmple.get(i).getDni())) {
					resultado = listaEmple.get(i);
					codigoMultiMetodoString = listaEmple.get(i).getCodEmple();
					codigoMultiMetodo = i;
					return resultado;
				}
			}
		}
		System.out.println("No existe el empleado solicitado. Operacion cancelada");
		return null;
	}

	public Empleado buscarEmpleadoPorId(String id) {
		Empleado resultado;
		// buscamos el empleado
		int i;
		for (i = 0; i < listaEmple.size(); i++) {
			if (id.equals(listaEmple.get(i).getCodEmple())) {
				resultado = listaEmple.get(i);
				codigoMultiMetodo = i;
				return resultado;
			}
		}
		return null;
	}

	public Departamento buscarDepartamento() {
		Departamento resultado;

		// elegir departamento
		System.out.println("Indique el codigo del departamento:");
		for (int i = 0; i < listaDep.size(); i++) {
			System.out.println(listaDep.get(i).getCodDep() + ".- " + listaDep.get(i).getNombreDep());
		}
		String op1 = ut.leerString("Opcion deseada: ");

		// buscamos el departamento
		int i;
		for (i = 0; i < listaDep.size(); i++) {
			if (op1.equals(listaDep.get(i).getCodDep())) {
				resultado = listaDep.get(i);
				codigoMultiMetodo = i;
				return resultado;
			}
		}
		System.out.println("No existe el departamento solicitado. Operacion cancelada");
		return null;
	}

	public Proyecto buscarProyecto() {
		Proyecto resultado;

		// elegir proyecto
		System.out.println("Indique el codigo del proyecto a buscar:");
		for (int i = 0; i < listaProy.size(); i++) {
			System.out.println(listaProy.get(i).getCodPro() + ".- " + listaProy.get(i).getNombre());
		}
		String op1 = ut.leerString("Opcion deseada: ");

		// buscamos el proyecto
		int i;
		for (i = 0; i < listaEmple.size(); i++) {
			if (op1.equals(listaProy.get(i).getCodPro())) {
				resultado = listaProy.get(i);
				codigoMultiMetodo = i;
				return resultado;
			}
		}
		System.out.println("No existe el proyecto solicitado. Operacion cancelada");
		return null;
	}

}
