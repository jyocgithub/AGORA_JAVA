package inicio.cliente;

import java.net.Socket;

/**
 * PROGRAMA PRINCIPAL
 * 
 */
class ServicioFTP_Cliente {
	public static void main(String args[]) throws Exception {
		Socket soc = new Socket("localhost", 5220);
		Cliente t = new Cliente(soc);
		t.menu();

	}
}