package inicio.cliente;
import java.io.Serializable;

public class ObtieneFichero implements Serializable {
	byte[] bytesDelFichero;

	public byte[] getBytesDelFichero() {
		return bytesDelFichero;
	}

	public void setBytesDelFichero(byte[] bytesDelFichero) {
		this.bytesDelFichero = bytesDelFichero;
	}

	public ObtieneFichero(byte[] bytesDelFichero) {
		super();
		this.bytesDelFichero = bytesDelFichero;
	}

}
