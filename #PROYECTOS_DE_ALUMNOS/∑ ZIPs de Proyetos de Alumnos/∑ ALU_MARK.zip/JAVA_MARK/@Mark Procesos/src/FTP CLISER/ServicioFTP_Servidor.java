package inicio.cliente;

import java.net.ServerSocket;

/**
 * PROGRAMA PRINCIPAL
 * 
 */
public class ServicioFTP_Servidor {

	public static void main(String args[]) throws Exception {
		int puerto = 5220;
		ServerSocket soc = new ServerSocket(puerto);
		System.out.println("Servidor FTP iniciado en el puerto" + puerto);
		while (true) {
			System.out.print("Esperando...");
			servidor t = new servidor(soc.accept());
		}
	}
}