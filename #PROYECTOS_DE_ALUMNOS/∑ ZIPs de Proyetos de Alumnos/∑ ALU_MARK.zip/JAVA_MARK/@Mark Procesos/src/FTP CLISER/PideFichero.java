package inicio.cliente;

import java.io.Serializable;

public class PideFichero implements Serializable {

	String nombreDelFichero;

	public PideFichero(String nombreDelFichero) {
		super();
		this.nombreDelFichero = nombreDelFichero;
	}

	public String getNombreDelFichero() {
		return nombreDelFichero;
	}

	public void setNombreDelFichero(String nombreDelFichero) {
		this.nombreDelFichero = nombreDelFichero;
	}

}
