package inicio.cliente;

import java.io.Serializable;

public class EnviaFichero implements Serializable {
	byte[] bytesDelFichero;
	String nombre;
	int tamano;

	public EnviaFichero(byte[] bytesDelFichero, String nombre, int tamano) {
		super();
		this.bytesDelFichero = bytesDelFichero;
		this.nombre = nombre;
		this.tamano = tamano;
	}

	public byte[] getBytesDelFichero() {
		return bytesDelFichero;
	}

	public void setBytesDelFichero(byte[] bytesDelFichero) {
		this.bytesDelFichero = bytesDelFichero;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public int getTamano() {
		return tamano;
	}

	public void setTamano(int tamano) {
		this.tamano = tamano;
	}

}
