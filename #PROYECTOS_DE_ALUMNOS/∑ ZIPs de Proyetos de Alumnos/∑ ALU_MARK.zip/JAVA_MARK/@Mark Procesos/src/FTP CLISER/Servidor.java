package inicio.cliente;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.nio.file.Files;

/**
 * CLASE PRINCIPAL
 * 
 */
class servidor extends Thread {

	Socket ClientSoc;

	String dirServer;
	DataInputStream din;

	DataOutputStream dout;
	ObjectOutputStream oos;

	ObjectInputStream ois;

	/**
	 * METODO ASINCRONO RUN()
	 * 
	 */
	@Override
	public void run() {
		while (true) {
			try {
				System.out.print("Esperando opcion...");
				String accion = (String) ois.readObject();
				if (accion.contains("MENSAJE AL SERVIDOR: ENVIO AL CLIENTE SOLICITADO")) {
					System.out.println("Solicitud de envio recibida...");
					enviarFicheroACliente();
				} else if (accion.contains("MENSAJE AL SERVIDOR: ENVIO A SERVIDOR SOLICITADO")) {
					System.out.println("Solicitud de recepcion recibida");
					recibirFicheroDesdeCliente();
				} else if (accion.contains("MENSAJE AL SERVIDOR: DESCONEXION SOLICITADO")) {
					System.out.println("Desconexion del cliente  ...");
					System.exit(1);
				}
			} catch (Exception ex) {
			}
		}
	}

	/**
	 * CONSTRUCTOR
	 * 
	 */
	public servidor(Socket soc) {
		try {
			ClientSoc = soc;
			din = new DataInputStream(ClientSoc.getInputStream());
			dout = new DataOutputStream(ClientSoc.getOutputStream());
			oos = new ObjectOutputStream(dout);
			ois = new ObjectInputStream(din);

			dirServer = ".";
			System.out.println("Directorio inicial del servicio del servidor (. por defecto)");
			dirServer = leerStringDeTeclado();
			if (dirServer.equals("")) dirServer = "DIR_RAIZ_SERVIDOR";

			System.out.println("Conexion de un cliente FTP realizada.");
			start();
		} catch (Exception ex) {
		}
	}

	/**
	 * leerDirectorioEnFicherosEF: crear un array de EstrcutruraFicheros con los ficheros del directorio pasado
	 * 
	 */
	EstructuraFichero[] leerDirectorioEnFicherosEF(File[] listadoDeficheros, String dirActual) throws Exception {

		EstructuraFichero[] arrayficherosEF = new EstructuraFichero[listadoDeficheros.length];
		int cont = 0;
		for (int i = 0; i < listadoDeficheros.length; i++) {
			arrayficherosEF[cont] = new EstructuraFichero();
			arrayficherosEF[cont].setName(listadoDeficheros[i].getName());
			arrayficherosEF[cont].setPath(listadoDeficheros[i].getPath());
			arrayficherosEF[cont].setNumFich(i);
			arrayficherosEF[cont].setEsDir(listadoDeficheros[i].isDirectory());

			// para leer recursivamente el directorio interno si el elemento analizado es un dir
			// if (listadoDeficheros[i].isDirectory()) {
			// String newDir = dirActual + File.separator + arrayficherosEF[cont].getName();
			// File f = new File(dirServer);
			// File[] listadoDefi = f.listFiles();
			//
			// // llamada recursiva a directorio interno
			// arrayficherosEF[cont].setLista(leerDirectorioEnFicherosEF(listadoDefi, newDir));
			// }

			cont++;
		}
		return arrayficherosEF;
	}

	/**
	 * ENVIAMOS UN FICHERO AL CLIENTE
	 * 
	 */
	void enviarFicheroACliente() throws Exception {

		// TODO cambiar a leer con directorios recursivos, y
		// añadir a resto que necesite

		File f = new File(dirServer);
		File[] listadoDeficheros;
		if (f.exists()) { // Directorio existe
			listadoDeficheros = f.listFiles();
		} else { // Directorio no existe
			f = new File(".");
			listadoDeficheros = f.listFiles();
		}

		EstructuraFichero arrayficherosEF[] = leerDirectorioEnFicherosEF(listadoDeficheros, dirServer);

		// ENVIAMOS A CLIENRE LA LISTA DE FICHEROS
		oos.writeObject(arrayficherosEF);

		// LEEMOS EL FICHERO SOLICITADO POR EL CLIENTE
		PideFichero pidef = (PideFichero) ois.readObject();
		String filename = pidef.getNombreDelFichero();
		f = new File(dirServer + File.separator + filename);
		if (!f.exists()) {
			// le decimos al cliente que el fichero ya no existe, que se cancela el envio
			oos.writeObject("MENSAJE A CLIENTE: El fichero no existe");
			return;
		} else {
			// le decimos al cliente que todo va bien, que ahi va el envio
			oos.writeObject("MENSAJE A CLIENTE: REALIZANDO_ENVIO");

			// CONVERTIMOS EL FICHERO A ENVIAR EN UN OBJETO, EN UN ARRAY de BYTES,
			// Y LUEGO EN UN OBJETO DE TIPO OBTIENEFICHERO
			byte[] content = Files.readAllBytes(f.toPath());
			ObtieneFichero obFichero = new ObtieneFichero(content);

			// LO ENVIO AL SERVIDOR COMO UN OBJETO
			oos.writeObject(obFichero);
		}
	}

	/**
	 * METODO PARA LEER STRING DESDE TECLADO
	 * 
	 */
	public String leerStringDeTeclado() {
		BufferedReader objetoBufRead = new BufferedReader(new InputStreamReader(System.in));
		try {
			return objetoBufRead.readLine();
		} catch (IOException e) {
			e.printStackTrace();
			return "";
		}
	}

	/**
	 * SE RECIBE UN FICHERO ENVIADO DESDE EL CLIENTE
	 * 
	 */
	void recibirFicheroDesdeCliente() throws Exception {

		// LEEMOS DEL CLIENTE EL NOMBRE DEL FICHERO A RECIBIR
		String filename = (String) ois.readObject();

		File f = new File(filename);
		String option;
		if (f.exists()) {

			// SE MANDA MENSAJE AL CLIENTE AVISANDO QUE EL FICHERO YA EXISTE EN
			// EL SERVIDOR
			oos.writeObject("MENSAJE A CLIENTE: El fichero ya existe");
			// SE RECIBE MENSAJE DE RESPUESTA DEL CLIENTE ACERCA DE SI SEGUIR
			// CON EL ENVIO O NO
			option = (String) ois.readObject();
		} else {
			option = "S";
		}

		if (option.contains("S")) {
			// SE CONTINUA CON EL ENVIO
			oos.writeObject("MENSAJE A CLIENTE: Recibiendo el fichero...");

			// EL FICHERO SE TRAE DESDE EL CLIENTE COMO UN OBJETO, UN ARRAY DE
			// BYTES
			EnviaFichero enFichero = (EnviaFichero) ois.readObject();
			byte[] arrayDeBytes = enFichero.getBytesDelFichero();

			// AHORA LO ESCRIBIMOS EN UN FICHERO FISICO
			File fileRecibirConPath = new File(dirServer + File.separator + filename);
			Files.write(fileRecibirConPath.toPath(), arrayDeBytes);

		} else {
			return;
		}
	}

	/**
	 * METODO QUE BORRA EL CONTENIDO DE UN DIRECTORIO, RECURSIVAMENTE SI HAY DIRECTORIOS DENTROPROGRAMA PRINCIPAL
	 * 
	 */
	public static void borrarDirectorio(File directorio) {
		File[] ficheros = directorio.listFiles();
		for (int i = 0; i < ficheros.length; i++) {
			if (ficheros[i].isDirectory()) {
				borrarDirectorio(ficheros[i]);
			}
			ficheros[i].delete();
		}
	}

}
