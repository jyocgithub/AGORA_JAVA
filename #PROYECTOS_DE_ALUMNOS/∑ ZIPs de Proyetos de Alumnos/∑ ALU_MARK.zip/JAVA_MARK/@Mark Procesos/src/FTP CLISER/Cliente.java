package inicio.cliente;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.nio.file.Files;

/**
 * CLASE PRINCIPAL
 * 
 */
public class Cliente {
	Socket ClientSoc;
	DataInputStream din;
	DataOutputStream dout;
	ObjectOutputStream oos;
	ObjectInputStream ois;
	String dirCliente = "DIR_RAIZ_CLIENTE";

	/**
	 * CONSTRUCTOR
	 * 
	 */
	public Cliente(Socket soc) {
		try {
			ClientSoc = soc;
			din = new DataInputStream(ClientSoc.getInputStream());
			dout = new DataOutputStream(ClientSoc.getOutputStream());
			oos = new ObjectOutputStream(dout);
			ois = new ObjectInputStream(din);
		} catch (Exception ex) {
		}
	}

	/**
	 * MENU PARA EL CLIENTE
	 * 
	 */
	public void menu() throws Exception {
		while (true) {
			System.out.println("=======================");
			System.out.println("  MENU");
			System.out.println("=======================");
			System.out.println("1. Enviar fichero");
			System.out.println("2. Recibir fichero");
			System.out.println("0. Fin");
			System.out.println("=======================\n");
			System.out.println("Opcion :");
			int opcion = Integer.parseInt(leerStringDeTeclado());
			switch (opcion) {
			case 1:
				oos.writeObject("MENSAJE AL SERVIDOR: ENVIO A SERVIDOR SOLICITADO");
				enviarFichero();
				break;
			case 2:
				oos.writeObject("MENSAJE AL SERVIDOR: ENVIO AL CLIENTE SOLICITADO");
				recibirfichero();
				break;

			case 0:
				oos.writeObject("MENSAJE AL SERVIDOR: DESCONEXION SOLICITADO");
				System.exit(1);
				break;
			default:
				System.out.println("Opcion erronea");
			}
		}
	}

	String selecFileDeArrayFicherosEF(EstructuraFichero[] arrayficherosEF) throws Exception {
		String tipo, fileName;
		do {

			for (int i = 0; i < arrayficherosEF.length; i++) {
				tipo = "Fichero ";
				if (arrayficherosEF[i].isEsDir()) tipo = "DIREC ";
				System.out.println("Num " + i + ": " + tipo + " -> " + arrayficherosEF[i].getName());
			}

			// ELEGIMOS EL FICHERO A RECIBIR AQUI EN EL CLIENTE
			System.out.print("Indique NUMERO de fichero a recibir desde el servidor:");
			int ops = leerIntDeTeclado();
			fileName = arrayficherosEF[ops].getName();
			return fileName;
		} while (true);

	}

	String selecFileDeArrayFicherosEFRecursivo(EstructuraFichero[] arrayficherosEF) throws Exception {
		String tipo, fileName;
		do {
			for (int i = 0; i < arrayficherosEF.length; i++) {
				tipo = "Fichero ";
				if (arrayficherosEF[i].isEsDir()) tipo = "DIREC ";
				System.out.println("Num " + i + ": " + tipo + " -> " + arrayficherosEF[i].getName());
			}

			// ELEGIMOS EL FICHERO A RECIBIR AQUI EN EL CLIENTE
			System.out.print("Indique NUMERO de fichero a recibir desde el servidor:");
			int ops = leerIntDeTeclado();
			fileName = arrayficherosEF[ops].getName();
			if (!arrayficherosEF[ops].esDir)
				return fileName;
			else
				arrayficherosEF = arrayficherosEF[ops].getLista();

		} while (true);

	}

	/**
	 * SE RECIBE UN FICHERO ENVIADO DESDE EL SERVIDOR
	 * 
	 */
	void recibirfichero() throws Exception {

		// LEEMOS DEL SERVIDOR EL LISTADO DE FICHEROS Y DE DIRECTORIOS
		// File[] listaFicheros = (File[]) ois.readObject();
		EstructuraFichero[] arrayficherosEF = (EstructuraFichero[]) ois.readObject();

		// MOSTRAMOS EL LISTADO DE FICHEROS AL USUARIO Y ELIJE UNO
		// String tipo;
		// for (int i = 0; i < arrayficherosEF.length; i++) {
		// tipo = "Fichero ";
		// if (arrayficherosEF[i].isEsDir())
		// tipo = "DIREC ";
		// System.out.println("Num " + i + ": " + tipo + " -> " + arrayficherosEF[i].getName());
		// }
		//
		// // ELEGIMOS EL FICHERO A RECIBIR AQUI EN EL CLIENTE
		// String fileName;
		// System.out.print("Indique NUMERO de fichero a recibir desde el servidor:");
		// int ops = leerIntDeTeclado();
		// fileName = arrayficherosEF[ops].getName();

		String fileName = selecFileDeArrayFicherosEF(arrayficherosEF);

		PideFichero pidef = new PideFichero(fileName);
		// oos.writeObject(fileName);
		oos.writeObject(pidef);

		String mensajeDesdeServidor = (String) ois.readObject();
		if (mensajeDesdeServidor.contains("MENSAJE A CLIENTE: El fichero no existe")) {
			System.out.println("El fichero NO existe en el servidor. Fin de intento.");
			return;
		} else if (mensajeDesdeServidor.contains("MENSAJE A CLIENTE: REALIZANDO_ENVIO")) {
			System.out.println("Recibiendo el fichero, espere...");
			File f = new File(dirCliente + File.separator + fileName);
			if (f.exists()) {
				String Option;
				System.out.println(
						"El fichero ya existe en este ordenador, ¿desea reemplazarlo con el del servidor? (S/N)?");
				Option = leerStringDeTeclado();
				if (Option == "N") {
					dout.flush();
					return;
				}
			}

			// EL FICHERO SE TRAE DESE DEL SERVER COMO UN OBJETO, UN ARRAY DE
			// BYTES

			ObtieneFichero obFichero = (ObtieneFichero) ois.readObject();

			byte[] arrayDeBytes = obFichero.getBytesDelFichero();

			// AHORA LO ESCRIBIMOS EN UN FICHERO FISICO
			// FileOutputStream fout = new FileOutputStream(f);
			Files.write(f.toPath(), arrayDeBytes);

			// fout.close();

		}

	}

	/**
	 * SE ENVIA UN FICHERO AL SERVIDOR
	 * 
	 */
	void enviarFichero() throws Exception {

		// String filename;
		// System.out.print("Escriba el nombre del archivo que desea enviar:");
		// filename = leerStringDeTeclado();

		File f = new File(dirCliente);
		File[] listadoDeficheros = f.listFiles();

		// MOSTRAMOS EL LISTADO DE FICHEROS AL USUARIO Y ELIJE UNO
		String tipo;
		for (int i = 0; i < listadoDeficheros.length; i++) {
			tipo = "Fichero ";
			if (listadoDeficheros[i].isDirectory()) tipo = "DIREC ";
			System.out.println("Num " + i + ": " + tipo + " -> " + listadoDeficheros[i].getName());
		}

		// ELEGIMOS EL FICHERO A ENVIAR A SERVER
		String fileName;
		System.out.print("Indique NUMERO de fichero a enviar al servidor:");
		int ops = leerIntDeTeclado();
		fileName = listadoDeficheros[ops].getName();
		// fileName = leerStringDeTeclado();

		// SE ENVIA MENSAJE AL SERVIDOR CON EL NOMBRE DEL ARCHIVO A ENVIAR
		oos.writeObject(fileName);

		// SE RECIBE MENSAJE DEL RESPUESTA DEL SERVIDOR
		String mensajeDesdeServidor = (String) ois.readObject();

		if (mensajeDesdeServidor.contains("MENSAJE A CLIENTE: El fichero ya existe")) {
			// EN LA RESPUESTA EL SERVIDOR DICE QUE EL FICHERO ALLI YA EXISTE
			String Option;
			System.out.println("El fichero ya existe en el servidor, ¿desea reemplazarlo? (S/N) ?");
			Option = leerStringDeTeclado();

			// SE CONTEXTA AL SERVIDOR SI SOBRESCRIBIMOS O NO EL DESTINO
			if (Option == "S") {
				oos.writeObject("S");
			} else {
				oos.writeObject("N");
				return;
			}
		}

		System.out.println("Enviando fichero a destino. Espere...");

		// CONVERTIMOS EL FICHERO A ENVIAR EN UN OBJETO, EN UN ARRAY DE BYTES

		File fileEnviarConPath = new File(dirCliente + File.separator + fileName);

		byte[] content = Files.readAllBytes(fileEnviarConPath.toPath());
		int tam = (int) fileEnviarConPath.length();
		EnviaFichero enFichero = new EnviaFichero(content, fileName, tam);

		// LO ENVIO AL SERVIDOR COMO UN OBJETO
		oos.writeObject(enFichero);

	}

	/**
	 * METODO PARA LEER STRING DESDE TECLADO
	 * 
	 */
	public String leerStringDeTeclado() {
		BufferedReader objetoBufRead = new BufferedReader(new InputStreamReader(System.in));
		try {
			return objetoBufRead.readLine();
		} catch (IOException e) {
			e.printStackTrace();
			return "";
		}
	}

	/**
	 * METODO PARA LEER INTQ DESDE TECLADO
	 * 
	 */
	public int leerIntDeTeclado() {
		BufferedReader objetoBufRead = new BufferedReader(new InputStreamReader(System.in));
		try {
			return Integer.parseInt(objetoBufRead.readLine());
			// return Integer.parseInt(objetoBufRead.read());
		} catch (IOException e) {
			e.printStackTrace();
			return 0;
		}
	}
}