package inicio.cliente;

import java.io.Serializable;

public class EstructuraFichero implements Serializable {
	private String name;
	private String path;
	boolean esDir;
	private int numFich;
	private EstructuraFichero[] lista;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPath() {
		return path;
	}

	public void setPath(String path) {
		this.path = path;
	}

	public boolean isEsDir() {
		return esDir;
	}

	public void setEsDir(boolean esDir) {
		this.esDir = esDir;
	}

	public int getNumFich() {
		return numFich;
	}

	public void setNumFich(int numFich) {
		this.numFich = numFich;
	}

	public EstructuraFichero[] getLista() {
		return lista;
	}

	public void setLista(EstructuraFichero[] lista) {
		this.lista = lista;
	}

	public EstructuraFichero() {
		super();
	}

	public EstructuraFichero(String name, String path, boolean esDir, int numFich, EstructuraFichero[] lista) {
		super();
		this.name = name;
		this.path = path;
		this.esDir = esDir;
		this.numFich = numFich;
		this.lista = lista;
	}

}
