package grupoAnillo.pruebas;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.InetSocketAddress;

public class GrupoAnillo {

	private static int posicion;
	private static int tamano;

	public static void main(String[] args) {

		if (args.length != 2) {
			System.out.println("Error en argumento hay que poner posicion y tamaño");
			System.exit(1);
		}

		posicion = Integer.parseInt(args[0]);
		tamano = Integer.parseInt(args[1]);

		/*
		 * lo normal es: recibir del anterior que sera 5550+posicion y despues
		 * enviar al siguiente que es 5550+posicion+1
		 * 
		 * reglas especiales: pero el ultimo enviara al 5550(al primero) y el
		 * primero tiene que enviar antes de recibir
		 */

		// si soy el primero envio antes de recibir
		if (posicion == 0) {
			enviar(5550 + posicion + 1);
			recibir(5550);
			// si no soy el primero recibo antes de enviar
		} else {
			recibir(5550 + posicion);
			// si soy el ultimo, envio al primero
			if (tamano == posicion + 1) {
				enviar(5550);
				// si no soy el ultimo envio al siguiente
			} else {
				enviar(5550 + posicion + 1);
			}
		}

	}

	public static void recibir(int puerto) {
		InetSocketAddress addr = new InetSocketAddress("localhost", puerto);
		try {
			DatagramSocket ds = new DatagramSocket(addr);

			// para recibir respuesta
			byte[] menRec = new byte[5];
			DatagramPacket dp2 = new DatagramPacket(menRec, menRec.length);
			System.out.println(posicion + ": Recibiendo datos por puerto:" + puerto);
			ds.receive(dp2);
			System.out.println(posicion + ": Recibido");
			ds.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public static void enviar(int puerto) {
		// por donde se escucho

		InetSocketAddress addr = new InetSocketAddress("localhost", 5550 + posicion);
		try {
			DatagramSocket ds = new DatagramSocket(addr);

			String men = "token";
			InetAddress addr1 = InetAddress.getByName("localhost");
			// a donde envia
			DatagramPacket dp1 = new DatagramPacket(men.getBytes(), men.getBytes().length, addr1, puerto);

			System.out.println(posicion + ": Enviando  token por puerto:" + 5550 + posicion
					+ " y el datagram por el puerto:" + puerto);
			ds.send(dp1);
			System.out.println(posicion + ": Enviado token");
			ds.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
