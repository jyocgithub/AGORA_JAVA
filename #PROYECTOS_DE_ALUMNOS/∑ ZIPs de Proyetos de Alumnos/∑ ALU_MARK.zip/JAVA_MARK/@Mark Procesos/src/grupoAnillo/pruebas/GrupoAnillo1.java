package grupoAnillo.pruebas;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.InetSocketAddress;

public class GrupoAnillo1 {

	public static void main(String[] args) {
		if (args.length != 2) {

			System.exit(1);
		}
		int tam_anillo = Integer.parseInt(args[0]);
		int pos_anillo = Integer.parseInt(args[1]);

		try {
			// Creando socket datagrama
			InetSocketAddress addr = new InetSocketAddress("localhost", 5550 + (pos_anillo % tam_anillo));
			DatagramSocket datagramSocket = new DatagramSocket(addr);

			// Si se trata del primer elemento, enviando token if (pos_anillo ==
			// 0) {
			if (pos_anillo == 0) {
				System.out.println("Generando toke");

				String token = "token";
				InetAddress addr1 = InetAddress.getByName("localhost");
				DatagramPacket datagrama1 = new DatagramPacket(token.getBytes(), token.getBytes().length, addr1, 5551);
				datagramSocket.send(datagrama1);
			}
			// Recibiendo token
			byte[] mensaje = new byte[5];
			DatagramPacket datagrama2 = new DatagramPacket(mensaje, 5);
			datagramSocket.receive(datagrama2);
			System.out.println("Token recibido desde " + datagrama2.getAddress() + ", puerto" + datagrama2.getPort());

			// Si no se trata del primer elemento, enviando al siguiente if
			// (pos_anillo != 0) {
			if (pos_anillo != 0) {
				System.out.println("Enviando el token al siguiente elemento del anillo");
				String token = "token";
				InetAddress addr1 = InetAddress.getByName("localhost");
				DatagramPacket datagrama3 = new DatagramPacket(token.getBytes(), token.getBytes().length, addr1,
						5550 + ((pos_anillo + 1) % tam_anillo));
				datagramSocket.send(datagrama3);
			}
			datagramSocket.close();

			System.out.println("Terminado");
		} catch (IOException e

		) {
			e.printStackTrace();
		}
	}
}
