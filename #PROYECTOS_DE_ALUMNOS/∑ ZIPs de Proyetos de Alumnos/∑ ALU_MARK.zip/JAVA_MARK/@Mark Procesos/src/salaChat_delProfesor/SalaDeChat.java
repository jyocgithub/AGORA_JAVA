package salaChat_delProfesor;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;

/**
 * Clase principal de la aplicación. Es el lado del servidor de una sala de
 * chat. Permite que se le conecten tantos clientes como se quiera. Para cada
 * uno, se queda escuchando en su stream de entrada y reenvía todo lo que le
 * llega a todos los demás, sin modificarlo.
 * 
 * En la salida estándar muestra, por depuración, todos los mensajes recibidos,
 * así como información sobre cada conexión que nos llega.
 * 
 * Esta clase es el servidor del chat Debe arrancarse antes que los clientes En
 * su main; - Crea un serverSocket por donde va a va analizando quien quiere
 * conectarse - Creamos una lista de clientes con sus bufferes de escritura -
 * Esperamos una nueva conexion - Creamos un socket de cada nuevo cliente que se
 * conecta - Creamos un hilo para cada nuevo cliente, contando con su socket y
 * su buffer de escritura - Mantenemos una lista con todos lols bufferes de
 * escritura de todos los clientes
 * 
 * 
 * 
 */
public class SalaDeChat {

	/**
	 * Programa principal.
	 * 
	 * @param args
	 *            Argumentos recibidos de la línea de órdenes. Debe haber uno,
	 *            con el número de puerto donde escuchar.
	 */
	public static void main(String[] args) {

		Socket socketDelCliente;
		int puertoParaClientes = 12345;

		// Creamos el ServerSocket donde nos quedaremos
		// escuchando, por el puerto decidido para conectar con clientes,
		// por lo que ha de ser el mismo que teniamos en el Chat cliente
		ServerSocket serverSocketServidor;
		try {
			serverSocketServidor = new ServerSocket(puertoParaClientes);
		} catch (IOException e) {
			System.out.println("No se puede escuchar por el puerto " + puertoParaClientes);
			return;
		}

		// Construimos una lista de bufferes de escritura
		// donde añadiremos el bufer de escritura de todas las conexiones
		// que recibamos, que será una por cada cliente del chat
		ArrayList<PrintWriter> listacanalesDeEscribir = new ArrayList<PrintWriter>();

		// Un bucle infinito que acaba solo cuando cerremos el proyecto
		while (true) {

			try {
				// Con accept lo que hacemos es esperar a que llegue una
				// peticion
				// de conexion NUEVA, y aceptarla, y ademas devuelve
				// el socket con el que se nos comunica quien nos ha enviado la
				// peticion
				socketDelCliente = serverSocketServidor.accept();
			} catch (IOException ioe) {
				System.err.println("Error esperando clientes: " + ioe.getLocalizedMessage());
				return;
			}

			// Obtenemos el canal de escribir hacia el socket del Cliente
			// para mandar texto a este cliente cuando lo necesitemos
			PrintWriter canalDeEscrituraHaciaElCliente;
			try {
				canalDeEscrituraHaciaElCliente = new PrintWriter(socketDelCliente.getOutputStream());
			} catch (IOException e) {
				System.err.println("Error al obtner el buffer de escritura del socket del cliente.");

				// Si no pongo el continue, intenta ejecutar el resto del método
				// sin un buffer correcto
				continue;
			}

			// Añadimos el buffer de escritura del Cliente a nuestra
			// lista listaBuffersEscritura
			listacanalesDeEscribir.add(canalDeEscrituraHaciaElCliente);

			// Cada cliente conectado al servidor debe tener su propio hilo
			// (HiloDeCadaCliente)
			// enviar lo que queramos que reciba.
			// Ahora creamos este hilo del nuevo cliente,
			// que se suma a los hilos de otros clientes ya creadas

			HiloDeCadaCliente unHiloCliente;

			// debemos pasar al hilo:
			// - el buffer donde escribe del cliente, sacado de su socket,
			// para que el hilo pueda leer de ahi lo que le envien los clientes
			// - el canal de escribir hacia el cliente
			// - la lista de canales de escribir hacia todos los clientes
			InputStream bufferDondeEscribeElCliente;
			try {
				bufferDondeEscribeElCliente = socketDelCliente.getInputStream();
				unHiloCliente = new HiloDeCadaCliente(bufferDondeEscribeElCliente, canalDeEscrituraHaciaElCliente,
						listacanalesDeEscribir);
			} catch (IOException e) {
				System.err.println("No pude conseguir el canal de lectura del socket.");
				return;
			}
			new Thread(unHiloCliente).start();

			// Informamos por Acaba de llegarnos un NUEVO cliente.
			// Mostramos información de la conexión.
			System.out.print("[ Conexión desde ");
			escribeExtremo(socketDelCliente.getLocalAddress(), socketDelCliente.getLocalPort());
			System.out.print(" a ");
			escribeExtremo(socketDelCliente.getInetAddress(), socketDelCliente.getPort());
			System.out.println(" ]");

		} // while(true)

	} // main

	/**
	 * Método auxiliar que recibe una dirección de internet y un puerto y lo
	 * escribe por la salida estándar.
	 * 
	 * @param address
	 *            Dirección de internet
	 * @param port
	 *            Puerto
	 */
	protected static void escribeExtremo(InetAddress address, int port) {

		System.out.print(address.getHostAddress());
		System.out.print(":" + port);
		if (address.getCanonicalHostName() != null)
			System.out.print(" (" + address.getCanonicalHostName() + ")");

	}

}

/**
 * Clase que supone cada uno de los hilos de cada uno de los clientes conectados
 * al chat Implementa el interfaz Runnable para poder ser ejecutado como un hilo
 * 
 * Esta clase: - Queda en espera de leer algo desde el buffer
 * 
 */
class HiloDeCadaCliente implements Runnable {

	BufferedReader miBufferDeLectura;
	PrintWriter micanalDeEscritura;
	List<PrintWriter> listacanalesDeEscribir;

	/**
	 * Constructor que recibe: - El buffer de lectura del cliente, sacado de su
	 * socket, para que el hilo pueda leer de ahi lo que le envien los clientes
	 * 
	 * 
	 * is Stream de entrada del que leer líneas.
	 * 
	 * @param pw
	 *            PrintWriter asociado al mismo socket que el stream del primer
	 *            parámetro.
	 * @param writers
	 *            Lista con los canales de salida de todos los clientes.
	 */
	HiloDeCadaCliente(InputStream bufferDondeEscribeElCliente, PrintWriter pmicanalDeEscritura,
			ArrayList<PrintWriter> plistacanalesDeEscribir) {

		// Creo un canal de leer iiii
		// desde el buffer donde escribe el cliente
		// para poder leer lso mensajes des este
		// de este canal de lectura saco un buffer
		// donde usar metodos como readline
		InputStreamReader iiii = new InputStreamReader(bufferDondeEscribeElCliente);
		miBufferDeLectura = new BufferedReader(iiii);

		micanalDeEscritura = pmicanalDeEscritura;
		listacanalesDeEscribir = plistacanalesDeEscribir;

	}

	/**
	 * Método para ser lanzado en otra hebra. Lee lineas del canal recibido en
	 * el constructor y las escribe por todos los PrintWriter de la lista
	 * recibida en el constructor.
	 */
	@Override
	public void run() {

		String leido;

		while (true) {
			try {
				leido = miBufferDeLectura.readLine();
			} catch (IOException e) {
				break;
			}
			if (leido == null) {
				// EOF.
				break;
			}
			for (PrintWriter cadacanalDeEscritura : listacanalesDeEscribir) {

				// Compruebo que no envio el mensaje al mismo
				// cliente que lo envio
				if (cadacanalDeEscritura != micanalDeEscritura) {
					cadacanalDeEscritura.println(leido);
					if (cadacanalDeEscritura.checkError())
						System.out.println("\t[Error en el último envío]");
				}
			}
			System.out.println();
		}

		// Cerramos el canal de entrada. El socket se dará
		// cuenta, y verá que el canal de salida está
		// también cerrado (por el otro extremo) y
		// dará error en el próximo intento de escritura.
		try {
			miBufferDeLectura.close();
		} catch (IOException e) {
			e.printStackTrace();
		}

		System.out.println("  [Fin de la hebra de entrada]");

	}

}
