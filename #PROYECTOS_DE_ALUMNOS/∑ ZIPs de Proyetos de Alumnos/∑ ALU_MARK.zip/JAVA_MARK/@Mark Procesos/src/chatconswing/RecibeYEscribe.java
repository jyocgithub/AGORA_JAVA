package chatconswing;


import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

/**
 * Clase que implementa el interfaz runnable para ser
 * ejecutada en otra hebra.
 * 
 * En el constructor recibe un InputStream del que leer
 * líneas contínuamente una vez envuelto en un BufferedReader.
 * Cada vez que lee una línea, la envía a la ventana de
 * chat, recibida en el constructor, a través de su método
 * onTextoIntroducido(). Si se detecta el cierre del
 * stream, se envía a la ventana de chat un aviso que indica
 * que se ha detectado el cierre del socket por parte
 * del servidor.
 */
class RecibeYEscribe implements Runnable {

	// declaramos un objeto para leer de un buffer
	BufferedReader	reader;

	// declaramos un objeto de Chat que luego asignaremos al que nos venga
	// con el constructor
	Chat			ventanaChat;

	/**
	 * Constructor
	 */
	RecibeYEscribe (InputStream is, Chat ventanaChat) {

		// el objeto declarado como para leer de un buffer
		// finalmente se crea como un canal de entrada, llamado is
		reader = new BufferedReader (new InputStreamReader (is));

		// el objeto ventana sera finalmente el que recibamos por parametro
		this.ventanaChat = ventanaChat;

	} // fin de Constructor




	/**
	 * Método para ser lanzado en otra hebra. Lee lineas del canal
	 * recibido en el constructor y las escribe por la salida
	 * estándar.
	 */
	@Override
	public void run () {

		String leido;

		while (true) {
			try {
				// metemos en el string leido lo que leamos del buffer de entrada
				leido = reader.readLine ();
			}
			catch (IOException e) {
				break;
			}
			if (leido == null) {
				// EOF.
				break;
			}

			// llamamos a onTextoRecibido del objeto chat
			// con el string recibido desde is
			// para que lio muestre en la ventana
			ventanaChat.onTextoRecibido (leido + "\n");
		}

		// Cerramos el canal de entrada. El socket se dará
		// cuenta, y verá que el canal de salida está
		// también cerrado (por el otro extremo) y
		// dará error en el próximo intento de escritura.
		try {
			reader.close ();
		}
		catch (IOException e) {
			e.printStackTrace ();
		}

		ventanaChat.onTextoRecibido ("  [El servidor cerró la entrada]");

	} // run



} // RecibeYEscribe