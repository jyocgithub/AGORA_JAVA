package Procesos_UT1;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

public class Ejer0 {

	public static void main(String[] args) throws IOException {
		/* En mi programa he utilizado la clase Runtime para ejecutar el proceso hijo */

		try {
			// Se ejecuta el primer hijo con el comando ls-la
			Process p1 = Runtime.getRuntime().exec("ls -la");

			/* El comando es para que la letra d minuscula convertirlo en D mayuscula. */
			Process p2 = Runtime.getRuntime().exec("tr \"d\" \"D\" ");

			// es la salida del proceso 1
			InputStream is1 = p1.getInputStream();

			// la entrada del proceso 2
			OutputStream os2 = p2.getOutputStream();

			// leer la salida del prcoeso 1 y escribe la entrada del proceso
			int value = is1.read();
			while (value != -1) {
				os2.write(value);
				os2.flush();
				value = is1.read();
			}

			os2.close();

			// es la salida del proceso 2
			InputStream is2 = p2.getInputStream();

			// Se muestra en la pantalla la salida
			byte[] buffer = new byte[1024 * 16];
			int leidos;
			while ((leidos = is2.read(buffer)) != -1) {
				System.out.write(buffer, 0, leidos);

			}
			is2.close();
		} catch (Throwable e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
}
