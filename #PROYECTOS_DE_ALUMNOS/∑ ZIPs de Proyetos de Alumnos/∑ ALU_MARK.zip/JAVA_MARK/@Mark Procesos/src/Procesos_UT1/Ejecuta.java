package Procesos_UT1;

import java.io.InputStream;
import java.util.Arrays;

public class Ejecuta {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		// Se asegura que lo pasa un parametro para el programa Runtime se ejecuta.
		if (args.length == 0) {
			System.err.println("No has especificado parametros");
			return;

		} else if (args.length > 1) {
			System.err.println("Demasiados parametros, introduce 2 parametros" + " Pon el comando entre comillas");
			return;// finalizando el sistema
		}

		try {
			// Si no quiere ejecutar en Terminal,se puede escribir directamente al exec el comando
			// por ejemplo .exec("javac")
			final Process proc = Runtime.getRuntime().exec(args[0]);
			InputStream is = proc.getErrorStream();

			// TODO Auto-generated method stub
			byte[] buffer = new byte[1024 * 16];
			int leidos;
			try {
				while ((leidos = is.read(buffer)) != -1) {
					System.err.write(buffer, 0, leidos);
				}
				is.close();
			} catch (Exception e) {
				System.out.println("Erro al leer o escribir");
			}

			// el padre va a esperar hasta que el hijo finalice
			int resultado = proc.waitFor();
			System.out.println("Comando " + Arrays.toString(args) + " devolvio: " + resultado);
		} catch (Throwable e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
