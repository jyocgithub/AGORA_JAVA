package socket2.sockets.sockets1;

import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;

public class Cliente extends Thread {

	private final int PUERTO = 1234; // Puerto para la conexión
	private final String HOST = "localhost"; // Host para la conexión
	protected Socket socketCliente; // Socket del cliente
	private String mensaje;

	/**
	 * Constructor
	 * 
	 * @throws IOException
	 */
	public Cliente() throws IOException { // Se usa el constructor para
											// establecer conexion
		socketCliente = new Socket(HOST, PUERTO); // Socket para el cliente en
													// localhost en puerto 1234
	}

	/**
	 * run () Lanza el thread
	 */
	@Override
	public void run() {
		try {
			// Se crea el flujo de salida para escibir en el
			DataOutputStream flujoDeSalidaDelClienteHaciaElServidor = new DataOutputStream(
					socketCliente.getOutputStream());

			// Se enviarán dos mensajes
			// Se escribe en el flujo del servidor
			for (int i = 0; i < 2; i++) {
				mensaje = "Este es el Contenido del mensaje número " + (i + 1);
				flujoDeSalidaDelClienteHaciaElServidor.writeBytes(mensaje + "\n");
				System.out.println("	CLI-Escribiendo mensaje :" + mensaje);
			}
			System.out.println("	CLI-Cerrando conexion");
			// Fin de la conexión
			socketCliente.close();
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}
}