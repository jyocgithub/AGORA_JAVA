package socket2.sockets.sockets2;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.ServerSocket;
import java.net.Socket;

public class Servidor extends Thread {

	private final int		PUERTO	= 1234;			// Puerto para la conexión
	private final String	HOST	= "localhost";	// Host para la conexión
	protected String		mensajeServidor;		// Mensajes recibidos en el servidor
	protected ServerSocket	serverSocket;			// Socket del servidor
	protected Socket		clienteSocket;			// Socket del cliente

	/**
	 * Constructor Se usa el constructor para crear los sockets
	 * 
	 */
	public Servidor() throws IOException {
		serverSocket = new ServerSocket(PUERTO);
		clienteSocket = new Socket();
		System.out.println("Server Arrancado");
	}

	/**
	 * run () Lanza el thread
	 * 
	 */
	@Override
	public void run() {
		try {
			// El serverSocket acepta una conexion y la devuelve, y nosotros la
			// cogemos en clienteSocket
			System.out.println("SER-Esperando...");
			clienteSocket = serverSocket.accept();
			System.out.println("SER-Cliente aceptado y en línea");

			// Se obtiene el flujo de salida del cliente y se le envía un
			// mensaje de confirmacion
			DataOutputStream flujoDeSalidaDelServerHaciaElCliente = new DataOutputStream(
			        clienteSocket.getOutputStream());
			flujoDeSalidaDelServerHaciaElCliente.writeBytes("Petición recibida y aceptada");
			System.out.println("SER-Peticion recibida, enviando acuse al cliente ");

			// Se obtiene el flujo entrante desde el cliente, y en un bucle se
			// leen los mendajes mientras haya
			// podria ponerse un tiempo de latencia para que no este
			// continuamente "mirando" el puerto
			// Los mensajes recibidos unicamente los mostramos por pantalla
			BufferedReader flujoDeEntradaDesdeElClienteHacieElServidor = new BufferedReader(
			        new InputStreamReader(clienteSocket.getInputStream()));

			while ((mensajeServidor = flujoDeEntradaDesdeElClienteHacieElServidor.readLine()) != null) {
				// System.out.println("SER-!!recibidos
				// "+mensajeServidor.substring(2, 43)+ " bytes !! ");
				System.out.println("SER-!! Recibido este mensaje: " + mensajeServidor + " ! ");
			}

			// Se finalizan las conexiones. Se espera algo entre una y otra para
			// sincronizarlas
			clienteSocket.close();
			this.sleep(1000);
			serverSocket.close();
			System.out.println("SER-Fin de la conexión");
		}
		catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}
}