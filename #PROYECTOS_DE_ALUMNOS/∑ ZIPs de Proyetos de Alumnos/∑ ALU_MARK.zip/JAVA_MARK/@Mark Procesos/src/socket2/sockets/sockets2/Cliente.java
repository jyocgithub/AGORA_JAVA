package socket2.sockets.sockets2;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.Socket;

public class Cliente extends Thread {

	private final int PUERTO = 1234; // Puerto para la conexión
	private final String HOST = "localhost"; // Host para la conexión
	protected Socket socketCliente; // Socket del cliente
	private String mensaje;

	/**
	 * Constructor
	 * 
	 * @throws IOException
	 */
	public Cliente() throws IOException { // Se usa el constructor para
											// establecer conexion
		socketCliente = new Socket(HOST, PUERTO); // Socket para el cliente en
													// localhost en puerto 1234
	}

	/**
	 * run () Lanza el thread
	 */
	@Override
	public void run() {
		try {
			// Se crea el flujo de salida para escibir en el
			DataOutputStream flujoDeSalidaDelClienteHaciaElServidor = new DataOutputStream(
					socketCliente.getOutputStream());

			// Se enviarán dos mensajes
			// Se escribe en el flujo del servidor
			for (int i = 0; i < 2; i++) {
				mensaje = "Este es el Contenido del mensaje número " + (i + 1);
				flujoDeSalidaDelClienteHaciaElServidor.writeBytes(mensaje + "\n");
				System.out.println("	CLI-Escribiendo mensaje :" + mensaje);
			}
			this.sleep(5000);

			// Se obtiene el flujo entrante desde el sever, y en un bucle se
			// leen los mendajes mientras haya
			// Los mensajes recibidos unicamente los mostramos por pantalla
			BufferedReader flujoDeEntradaDesdeElServidorAlCLiente = new BufferedReader(
					new InputStreamReader(socketCliente.getInputStream()));
			System.out.println("	CLIE-!! TB ESCUCHO ! ");
			String mensajeDesdeElServidor;
			mensajeDesdeElServidor = flujoDeEntradaDesdeElServidorAlCLiente.readLine();
			System.out.println("	CLIE-!! QUE SOY : " + mensajeDesdeElServidor + " ! ");
			while (mensajeDesdeElServidor != null) {
				// System.out.println("SER-!!recibidos
				// "+mensajeServidor.substring(2, 43)+ " bytes !! ");
				System.out.println("	CLIE-!! Acuse en el mensaje: " + mensajeDesdeElServidor + " ! ");
			}

			System.out.println("	CLI-Cerrando conexion");
			// Fin de la conexión
			socketCliente.close();
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}
}