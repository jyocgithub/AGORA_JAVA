package socket2.sockets.sockets1;

import java.io.IOException;

//Clase principal que hará uso del servidor
public class Inicio extends Thread {

	public static void main(String[] args) throws IOException, InterruptedException {
		// Se crea un objeto servidor y otro cliente
		// Ambos heredan de Thread
		System.out.println("SER-Creando conexion servidor");
		Servidor serv = new Servidor();
		System.out.println("		CLI-Creando conexion cliente");
		Cliente cli = new Cliente(); // Se crea el cliente

		// Se inicia el hilo del objeto del cliente y del servidor
		System.out.println("		CLI-Iniciando cliente\n");
		cli.start();
		System.out.println("SER-Iniciando servidor\n");
		serv.start();

	}
}
