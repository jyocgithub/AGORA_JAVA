package controlador;

import java.util.ArrayList;

import basededatos.LibrosBBDD;
import clases.Libro;

public class InicioEjercicioBD {

	public static void main(String[] args) {

		LibrosBBDD librobbdd = new LibrosBBDD();

		// CREAMOS SIEMPRE CON UN METODO QUE NOS DE EL ID NUEVO
		Libro libro = new Libro(librobbdd.getSiguienteIdLibro(), "MISERIAS", 3, 2000, 700);
		librobbdd.insertarLibro(libro);

		librobbdd.borrarLibro(23);

		// consultar todos los libros
		ArrayList<Libro> listalibros = librobbdd.consultarTodosLosLibros();
		for (Libro lib : listalibros) {
			System.out.println(lib);
		}

		System.out.println("++++++++++++++++++++++++++++++++++++++++");

		// consultar todos los libros por autor
		ArrayList<Libro> listalibros2 = librobbdd.consultarTodosLosLibrosPorAutor(13);
		if (listalibros2.size() == 0) {
			System.out.println("no hay na de ese autor");
		} else {
			for (Libro lib : listalibros2) {
				System.out.println(lib);
			}
		}

		// consultar un solo libro
		Libro librobuscado = librobbdd.consultarUnSoloLibroPorId(4543);
		if (librobuscado == null) {
			System.out.println("no hay na de ese libro");
		} else {
			System.out.println(librobuscado);
		}

	}

}
