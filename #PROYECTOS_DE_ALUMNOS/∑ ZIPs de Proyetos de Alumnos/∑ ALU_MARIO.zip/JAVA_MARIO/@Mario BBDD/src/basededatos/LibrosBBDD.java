package basededatos;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import clases.Libro;

public class LibrosBBDD {
	Connection miConexion;

	// public void insertarLibro(Libro libro) {
	// try {
	// conectar();
	// String sql = " insert into libro values(" + libro.getIdLibro() + ",'" + libro.getTitulo() + "', "
	// + libro.getIdautor() + "," + libro.getAno() + "," + libro.getNumPaginas() + ") ";
	// Statement instruccion = miConexion.createStatement();
	// instruccion.execute(sql);
	//
	// } catch (SQLException e) {
	// e.printStackTrace();
	// } finally {
	// desconectar();
	// }
	//
	// }

	// ---------------------------------------------------------
	// ----------------------------------------------- INSERTAR SI HAY AUTOINCREMENTAL
	public void insertarLibroAutoincremental(Libro libro) {
		try {
			conectar();
			String sql = "insert into libro values(?,?,?,?)";
			PreparedStatement instruccion = miConexion.prepareStatement(sql);
			instruccion.setString(1, libro.getTitulo());
			instruccion.setInt(2, libro.getIdautor());
			instruccion.setInt(3, libro.getAno());
			instruccion.setInt(4, libro.getNumPaginas());
			instruccion.execute();
		} catch (SQLException e) {
			System.out.println(" !! Error en la insercion en la base de datos !!");
		} finally {
			desconectar();
		}
	}

	// ---------------------------------------------------------
	// ----------------------------------------------- INSERTAR SI NO HAY AUTOINCREMENTAL
	public void insertarLibro(Libro libro) {
		try {
			conectar();
			String sql = "insert into libro values(?,?,?,?,?)";
			PreparedStatement instruccion = miConexion.prepareStatement(sql);
			instruccion.setInt(1, libro.getIdLibro());
			instruccion.setString(2, libro.getTitulo());
			instruccion.setInt(3, libro.getIdautor());
			instruccion.setInt(4, libro.getAno());
			instruccion.setInt(5, libro.getNumPaginas());
			instruccion.execute();
		} catch (SQLException e) {
			System.out.println(" !! Error en la insercion en la base de datos !!");
		} finally {
			desconectar();
		}
	}

	// ---------------------------------------------------------
	// ----------------------------------------------- BORRAR
	public void borrarLibro(int idlib) {
		try {
			conectar();
			String sql = "delete from libro where idlibro=?";
			PreparedStatement instruccion = miConexion.prepareStatement(sql);
			instruccion.setInt(1, idlib);
			instruccion.execute();
		} catch (SQLException e) {
			System.out.println(" !! Error en el borrado en la base de datos !!");
		} finally {
			desconectar();
		}
	}

	// ---------------------------------------------------------
	// ----------------------------------------------- MODIFICAR
	public void modificarLibro(Libro libro) {
		try {
			conectar();
			String sql = "update libro set titulo=?, idautor=?, ano=?, numpaginas=? where idlibro=?";
			PreparedStatement instruccion = miConexion.prepareStatement(sql);
			instruccion.setString(1, libro.getTitulo());
			instruccion.setInt(2, libro.getIdautor());
			instruccion.setInt(3, libro.getAno());
			instruccion.setInt(4, libro.getNumPaginas());
			instruccion.setInt(5, libro.getIdLibro());
			instruccion.execute();
		} catch (SQLException e) {
			System.out.println(" !! Error en la actualizacion en la base de datos !!");
		} finally {
			desconectar();
		}
	}

	// ---------------------------------------------------------
	// ----------------------------------------------- SELECCIONAR

	public ArrayList<Libro> consultarTodosLosLibros() {
		ArrayList<Libro> lista = new ArrayList<>();

		try {
			conectar();
			String sql = "select * from libro";
			PreparedStatement instruccion = miConexion.prepareStatement(sql);

			ResultSet registros = instruccion.executeQuery();

			while (registros.next()) {
				int idlib = registros.getInt("idlibro");
				String tit = registros.getString("titulo");
				int idaut = registros.getInt("idautor");
				int ano = registros.getInt("ano");
				int numpag = registros.getInt("numpaginas");

				Libro l = new Libro(idlib, tit, idaut, ano, numpag);
				lista.add(l);
			}

		} catch (SQLException e) {
			System.out.println(" !! Error en la consulta en la base de datos !!");
		} finally {
			desconectar();
		}
		return lista;
	}

	// ---------------------------------------------------------
	// ----------------------------------------------- SELECCIONAR

	public ArrayList<Libro> consultarTodosLosLibrosPorAutor(int id) {
		ArrayList<Libro> lista = new ArrayList<>();

		try {
			conectar();
			String sql = "select * from libro where idautor =? ";
			PreparedStatement instruccion = miConexion.prepareStatement(sql);
			instruccion.setInt(1, id);
			ResultSet registros = instruccion.executeQuery();

			while (registros.next()) {
				int idlib = registros.getInt("idlibro");
				String tit = registros.getString("titulo");
				int idaut = registros.getInt("idautor");
				int ano = registros.getInt("ano");
				int numpag = registros.getInt("numpaginas");

				Libro l = new Libro(idlib, tit, idaut, ano, numpag);
				lista.add(l);
			}

		} catch (SQLException e) {
			System.out.println(" !! Error en la consulta en la base de datos !!");
		} finally {
			desconectar();
		}
		return lista;
	}

	public Libro consultarUnSoloLibroPorId(int id) {
		Libro l = null;

		try {
			conectar();
			String sql = "select * from libro where idlibro =? ";
			PreparedStatement instruccion = miConexion.prepareStatement(sql);
			instruccion.setInt(1, id);
			ResultSet registros = instruccion.executeQuery();

			while (registros.next()) {
				int idlib = registros.getInt("idlibro");
				String tit = registros.getString("titulo");
				int idaut = registros.getInt("idautor");
				int ano = registros.getInt("ano");
				int numpag = registros.getInt("numpaginas");

				l = new Libro(idlib, tit, idaut, ano, numpag);

			}

		} catch (SQLException e) {
			System.out.println(" !! Error en la consulta en la base de datos !!");
		} finally {
			desconectar();
		}
		return l;
	}

	public int getSiguienteIdLibro() {
		int idlib = 0;
		try {
			conectar();
			String sql = "select max(idLibro) from libro";
			PreparedStatement instruccion = miConexion.prepareStatement(sql);
			ResultSet registros = instruccion.executeQuery();
			registros.next();
			idlib = registros.getInt("max(idLibro)");
		} catch (SQLException e) {
			System.out.println(" !! Error en la consulta en la base de datos !!");
		} finally {
			desconectar();
		}
		return idlib + 1;
	}

	// -------------------------------- constructores y conexion y desconexion
	public LibrosBBDD() {
		try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}

	}

	public void conectar() {
		try {
			miConexion = DriverManager.getConnection("jdbc:mysql://localhost:3306/librosjyoc", "root", "");
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public void desconectar() {
		try {
			miConexion.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

}
