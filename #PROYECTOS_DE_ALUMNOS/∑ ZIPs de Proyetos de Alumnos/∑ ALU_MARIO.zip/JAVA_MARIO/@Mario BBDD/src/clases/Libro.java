package clases;

public class Libro {

	private int idLibro;
	private String titulo;
	private int idautor;
	private int ano;
	private int numPaginas;

	public Libro(int idLibro, String titulo, int idautor, int ano, int numPaginas) {
		super();
		this.idLibro = idLibro;
		this.titulo = titulo;
		this.idautor = idautor;
		this.ano = ano;
		this.numPaginas = numPaginas;
	}

	public Libro() {
	}

	@Override
	public String toString() {
		return "Libro [idLibro=" + idLibro + ", titulo=" + titulo + ", idautor=" + idautor + ", ano=" + ano
				+ ", numPaginas=" + numPaginas + "]";
	}

	public int getIdLibro() {
		return idLibro;
	}

	public void setIdLibro(int idLibro) {
		this.idLibro = idLibro;
	}

	public String getTitulo() {
		return titulo;
	}

	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}

	public int getIdautor() {
		return idautor;
	}

	public void setIdautor(int idautor) {
		this.idautor = idautor;
	}

	public int getAno() {
		return ano;
	}

	public void setAno(int ano) {
		this.ano = ano;
	}

	public int getNumPaginas() {
		return numPaginas;
	}

	public void setNumPaginas(int numPaginas) {
		this.numPaginas = numPaginas;
	}

	@Override
	public boolean equals(Object obj) {

		Libro other = (Libro) obj;

		if (idLibro != other.idLibro) return false;

		return true;
	};

	// public boolean equals(Object x) {
	// Libro b = (Libro) x;
	// if (this.idLibro == b.idLibro) {
	// return true;
	// }
	// return false;
	// }
	//

}
