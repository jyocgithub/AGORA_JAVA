package practica1;

import java.io.Serializable;

public class Rueda  implements Serializable  {

	private int altura;
	private int ancho;
	private int diametro;

	public Rueda() {

	}

	public Rueda(int altura, int ancho, int diametro) {

		this.altura = altura;
		this.ancho = ancho;
		this.diametro = diametro;

	}

	public int getAltura() {
		return altura;
	}

	public void setAltura(int altura) {
		this.altura = altura;
	}

	public int getAncho() {
		return ancho;
	}

	public void setAncho(int ancho) {
		this.ancho = ancho;
	}

	public int getDiametro() {
		return diametro;
	}

	public void setDiametro(int diametro) {
		this.diametro = diametro;
	}

	@Override
	public String toString() {
		return "Rueda [altura=" + altura + ", ancho=" + ancho + ", diametro=" + diametro + "]";
	}

}
