package practica1;

import java.io.Serializable;

public class Motor  implements Serializable {

	private int cilindrada;
	private String combustible;

	public Motor() {

	}

	public Motor(int cilindrada, String combustible) {

		this.cilindrada = cilindrada;
		this.combustible = combustible;

	}

	public int getCilindrada() {
		return cilindrada;
	}

	public void setCilindrada(int cilindrada) {
		this.cilindrada = cilindrada;
	}

	public String getCombustible() {
		return combustible;
	}

	public void setCombustible(String combustible) {
		this.combustible = combustible;
	}

	@Override
	public String toString() {
		return "Motor [cilindrada=" + cilindrada + ", combustible=" + combustible + "]";
	}

}
