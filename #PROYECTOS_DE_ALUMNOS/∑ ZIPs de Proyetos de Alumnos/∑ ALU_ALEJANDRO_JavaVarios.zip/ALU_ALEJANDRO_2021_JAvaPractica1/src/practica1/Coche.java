package practica1;

import java.io.File;
import java.io.Serializable;
import java.util.ArrayList;

public class Coche implements Serializable {

	private String matricula;
	private String marca;
	private String modelo;
	private String color;
	private Motor motor;
	private ArrayList<Rueda> ruedas;

	public void Coche() {

	}


	public Coche(String matricula, String marca, String modelo, String color, Motor motor, ArrayList<Rueda> ruedas) {
		super();
		this.matricula = matricula;
		this.marca = marca;
		this.modelo = modelo;
		this.color = color;
		this.motor = motor;
		this.ruedas = ruedas;
	}


	public String getMatricula() {
		return matricula;
	}

	public void setMatricula(String matricula) {
		this.matricula = matricula;
	}

	public String getMarca() {
		return marca;
	}

	public void setMarca(String marca) {
		this.marca = marca;
	}

	public String getModelo() {
		return modelo;
	}

	public void setModelo(String modelo) {
		this.modelo = modelo;
	}

	public String getColor() {
		return color;
	}

	public void setColor(String color) {
		this.color = color;
	}

	
	
	
	public Motor getMotor() {
		return motor;
	}


	public void setMotor(Motor motor) {
		this.motor = motor;
	}


	public ArrayList<Rueda> getRuedas() {
		return ruedas;
	}


	public void setRuedas(ArrayList<Rueda> ruedas) {
		this.ruedas = ruedas;
	}


	@Override
	public String toString() {
		return "Matricula: " + matricula + ", Marca: " + marca + ", Modelo: " + modelo + ", Color: " + color;
	}

}
