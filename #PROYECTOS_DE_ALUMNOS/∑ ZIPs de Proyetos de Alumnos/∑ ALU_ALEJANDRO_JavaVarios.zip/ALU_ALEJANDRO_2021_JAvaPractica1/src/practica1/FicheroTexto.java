package practica1;

import java.io.*;
import java.util.ArrayList;

public class FicheroTexto {

    // Metodo que guarda un coche en el fichero indicado.
    public void guardarCoche(Coche c, String nombrefichero) {

        File fileTex = new File(nombrefichero);

        PrintWriter pw = null;

        try {
            pw = new PrintWriter(new FileWriter(fileTex, true));

            pw.print(c.getMatricula() + ",");
            pw.print(c.getMarca() + ",");
            pw.print(c.getModelo() + ",");
            pw.println(c.getColor());

            for (int j = 0; j < 4; j++) {
                Rueda r = c.getRuedas().get(j);
                pw.print(r.getAltura() + ",");
                pw.print(r.getAncho() + ",");
                pw.println(r.getDiametro());
            }
            pw.print(c.getMotor().getCilindrada() + ",");
            pw.println(c.getMotor().getCombustible());

        } catch (IOException e) {
            System.out.println(e.getMessage());
        } finally {
            if (pw != null) {
                pw.close();
            }
        }

    }

    // Metodo que devuelve el coche que se encuentra en la posicion indicada en el
    // fichero indicado.
    public Coche leerCoche(String nombrefichero, int posicion) {
        Coche coche = null;
        int cont = 1;
        boolean encontrado = false;
        File fil = new File(nombrefichero);

        if (fil.exists()) {
            BufferedReader br = null;
            try {
                br = new BufferedReader(new FileReader(fil));

                String linea1 = br.readLine();
                while (linea1 != null && !encontrado) {
                    // si hay una linea es que hay un coche entero, leo el resto del lineas del coche
                    String linea2 = br.readLine();
                    String linea3 = br.readLine();
                    String linea4 = br.readLine();
                    String linea5 = br.readLine();
                    String linea6 = br.readLine();
                    // miro si el coche esta en la posicion que busco
                    if (cont == posicion) {
                        // cosas del coche
                        String[] trozos1 = linea1.split(",");
                        String matricula = trozos1[0];
                        String marca = trozos1[1];
                        String modelo = trozos1[2];
                        String color = trozos1[3];

                        // cosas del motor
                        String[] trozos6 = linea6.split(",");
                        int cilindrada = Integer.parseInt(trozos6[0]);
                        String combustible = trozos6[1];
                        Motor motor = new Motor(cilindrada, combustible);

                        // cosas de las ruedas
                        ArrayList<Rueda> listaruedas = new ArrayList<>();

                        String[] trozos2 = linea2.split(",");
                        int altura = Integer.parseInt(trozos2[0]);
                        int ancho = Integer.parseInt(trozos2[1]);
                        int diametro = Integer.parseInt(trozos2[2]);
                        Rueda r = new Rueda(altura, ancho, diametro);
                        listaruedas.add(r);

                        String[] trozos3 = linea3.split(",");
                        altura = Integer.parseInt(trozos3[0]);
                        ancho = Integer.parseInt(trozos3[1]);
                        diametro = Integer.parseInt(trozos3[2]);
                        r = new Rueda(altura, ancho, diametro);
                        listaruedas.add(r);

                        String[] trozos4 = linea4.split(",");
                        altura = Integer.parseInt(trozos4[0]);
                        ancho = Integer.parseInt(trozos4[1]);
                        diametro = Integer.parseInt(trozos4[2]);
                        r = new Rueda(altura, ancho, diametro);
                        listaruedas.add(r);

                        String[] trozos5 = linea5.split(",");
                        altura = Integer.parseInt(trozos5[0]);
                        ancho = Integer.parseInt(trozos5[1]);
                        diametro = Integer.parseInt(trozos5[2]);
                        r = new Rueda(altura, ancho, diametro);
                        listaruedas.add(r);

                        coche = new Coche(matricula, marca, modelo, color, motor, listaruedas);
                        encontrado = true;
                    }

                    linea1 = br.readLine();
                    cont++;
                }

            } catch (IOException e) {
                System.out.println(e.getMessage());
            } finally {
                try {
                    if (br != null) {
                        br.close();
                    }
                } catch (IOException e) {
                    System.out.println(e.getMessage());
                }
            }
        }

        return coche;

    }

    // Metodo que guarda todos los coches en el fichero indicado.
    public void guardarCoches(ArrayList<Coche> listacoches, String nombrefichero) {
        File fileTex = new File(nombrefichero);

        PrintWriter pw = null;

        try {
            pw = new PrintWriter(new FileWriter(fileTex));

            // ESCRIBIR
            for (int i = 0; i < 10; i++) {
                Coche c = listacoches.get(i);

                pw.print(c.getMatricula() + ",");
                pw.print(c.getMarca() + ",");
                pw.print(c.getModelo() + ",");
                pw.println(c.getColor());

                for (int j = 0; j < 4; j++) {

                    Rueda r = c.getRuedas().get(j);
                    pw.print(r.getAltura() + ",");
                    pw.print(r.getAncho() + ",");
                    pw.println(r.getDiametro());
                }
                pw.print(c.getMotor().getCilindrada() + ",");
                pw.println(c.getMotor().getCombustible());
            }

        } catch (IOException e) {
            System.out.println(e.getMessage());
        } finally {
            if (pw != null) {
                pw.close();
            }
        }

    }

    // Metodo que devuelve todos los coches contenidos en el fichero en un
    // ArrayList.
    public ArrayList<Coche> leerCoches(String nombrefichero) {
        ArrayList<Coche> listacoches = new ArrayList<Coche>();

        File fil = new File(nombrefichero);

        if (fil.exists()) {
            BufferedReader br = null;
            try {
                br = new BufferedReader(new FileReader(fil));

                String linea1 = br.readLine();
                while (linea1 != null) {

                    String linea2 = br.readLine();
                    String linea3 = br.readLine();
                    String linea4 = br.readLine();
                    String linea5 = br.readLine();
                    String linea6 = br.readLine();

                    // cosas del coche
                    String[] trozos1 = linea1.split(",");
                    String matricula = trozos1[0];
                    String marca = trozos1[1];
                    String modelo = trozos1[2];
                    String color = trozos1[3];

                    // cosas del motor
                    String[] trozos6 = linea6.split(",");
                    int cilindrada = Integer.parseInt(trozos6[0]);
                    String combustible = trozos6[1];
                    Motor motor = new Motor(cilindrada, combustible);

                    // cosas de las ruedas
                    ArrayList<Rueda> listaruedas = new ArrayList<Rueda>();

                    String[] trozos2 = linea2.split(",");
                    int altura = Integer.parseInt(trozos2[0]);
                    int ancho = Integer.parseInt(trozos2[1]);
                    int diametro = Integer.parseInt(trozos2[2]);
                    Rueda r = new Rueda(altura, ancho, diametro);
                    listaruedas.add(r);

                    String[] trozos3 = linea3.split(",");
                    altura = Integer.parseInt(trozos3[0]);
                    ancho = Integer.parseInt(trozos3[1]);
                    diametro = Integer.parseInt(trozos3[2]);
                    r = new Rueda(altura, ancho, diametro);
                    listaruedas.add(r);

                    String[] trozos4 = linea4.split(",");
                    altura = Integer.parseInt(trozos4[0]);
                    ancho = Integer.parseInt(trozos4[1]);
                    diametro = Integer.parseInt(trozos4[2]);
                    r = new Rueda(altura, ancho, diametro);
                    listaruedas.add(r);

                    String[] trozos5 = linea5.split(",");
                    altura = Integer.parseInt(trozos5[0]);
                    ancho = Integer.parseInt(trozos5[1]);
                    diametro = Integer.parseInt(trozos5[2]);
                    r = new Rueda(altura, ancho, diametro);
                    listaruedas.add(r);

                    Coche c = new Coche(matricula, marca, modelo, color, motor, listaruedas);

                    listacoches.add(c);

                    linea1 = br.readLine();
                }

            } catch (IOException e) {
                System.out.println(e.getMessage());
            } finally {
                try {
                    if (br != null) {
                        br.close();
                    }
                } catch (IOException e) {
                    System.out.println(e.getMessage());
                }
            }
        }

        return listacoches;
    }
}
