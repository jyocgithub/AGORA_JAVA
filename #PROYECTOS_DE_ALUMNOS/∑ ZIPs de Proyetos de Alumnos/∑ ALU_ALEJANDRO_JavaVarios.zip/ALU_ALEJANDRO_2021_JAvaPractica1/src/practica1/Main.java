package practica1;

import java.io.File;
import java.util.ArrayList;

public class Main {

    public static void main(String[] args) {
        String[] matriculas = {"4373hbh", "9516hrj", "9345mht", "1452ter", "6537ugk"};
        String[] marcas = {"opel", "ford", "audi", "bmw", "jaguar"};
        String[] modelos = {"astra", "fiesta", "a3", "200", "ap3"};
        String[] colores = {"rojo", "gris", "azul", "blanco", "negro"};
        int[] anchos = {23, 25, 26, 30, 34};
        int[] alturas = {130, 250, 260, 300, 340};
        int[] diametros = {230, 255, 265, 305, 345};
        int[] cilindradas = {1200, 1500, 1600, 1900, 2000};
        String[] combustibles = {"diesel", "gasolina"};

        ArrayList<Coche> listacoches = new ArrayList<Coche>();

        int x;
        for (int i = 0; i < 10; i++) {
            x = (int) (Math.random() * 5);
            String matricula = matriculas[x];

            x = (int) (Math.random() * 5);
            String marca = marcas[x];

            x = (int) (Math.random() * 5);
            String modelo = modelos[x];

            x = (int) (Math.random() * 5);
            String color = colores[x];

            x = (int) (Math.random() * 5);
            int cilindrada = cilindradas[x];

            x = (int) (Math.random() * 2);
            String combustible = combustibles[x];


            Motor motor = new Motor(cilindrada, combustible);

            ArrayList<Rueda> listaruedas = new ArrayList<>();
            for (int j = 0; j < 4; j++) {
                x = (int) (Math.random() * 5);
                int altura = alturas[x];
                x = (int) (Math.random() * 5);
                int ancho = anchos[x];
                x = (int) (Math.random() * 5);
                int diametro = diametros[x];

                Rueda r = new Rueda(altura, ancho, diametro);

                listaruedas.add(r);
            }

            Coche c = new Coche(matricula, marca, modelo, color, motor, listaruedas);

            listacoches.add(c);
        }


        /////////////////////////////////////////////////////////////////////////////////////

        FicheroTexto ft = new FicheroTexto();
        FicheroSerializado fileSer = new FicheroSerializado();
        FicheroBinario fileBin = new FicheroBinario();

        int accion = (int) (Math.random() * 2);

        switch (accion) {
            case 0:
                System.out.println("--------- CASE 0   ----- ");
                System.out.println("--------- DE TEXTO ----- ");
                ft.guardarCoches(listacoches, "CochesTexto.txt");
                ArrayList<Coche> listacochesleidos = ft.leerCoches("CochesTexto.txt");
                for (Coche c : listacochesleidos) {
                    System.out.println(c);
                }

                System.out.println("--------- BINARIOS ----- ");
                fileBin.guardarCoches(listacoches, "CochesBinarios.txt");
                ArrayList<Coche> listacochesleidosbin = fileBin.leerCoches("CochesBinarios.txt");
                for (Coche c : listacochesleidosbin) {
                    System.out.println(c);
                }


                System.out.println("--------- SERIALIZABLES ----- ");
                fileSer.guardarCoches(listacoches, "CochesSerializados.txt");
                ArrayList<Coche> listacochesleidosser = fileSer.leerCoches("CochesSerializados.txt");
                for (Coche c : listacochesleidosser) {
                    System.out.println(c);
                }
                break;

            case 1:
                System.out.println("--------- CASE 1   ----- ");
                System.out.println("--------- DE TEXTO ----- ");
                Coche cocheleido1 = ft.leerCoche("CochesTexto.txt", 3);
                ft.guardarCoche(cocheleido1, "CochesTexto.txt");
                System.out.println(cocheleido1);

                System.out.println("--------- BINARIOS ----- ");
                Coche cocheleido2 = fileBin.leerCoche("CochesBinarios.txt", 3);
                fileBin.guardarCoche(cocheleido2, "CochesBinarios.txt");
                System.out.println(cocheleido2);


                System.out.println("--------- SERIALIZABLES ----- ");
                Coche cocheleido3 = fileSer.leerCoche("CochesSerializados.txt");
                fileSer.guardarCoche(cocheleido3, "CochesSerializados.txt");
                System.out.println(cocheleido3);

        }


    }


}
