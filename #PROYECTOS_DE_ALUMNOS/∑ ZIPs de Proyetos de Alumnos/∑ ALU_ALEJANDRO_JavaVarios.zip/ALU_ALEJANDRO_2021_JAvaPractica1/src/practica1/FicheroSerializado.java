package practica1;

import java.io.*;
import java.util.ArrayList;

public class FicheroSerializado {

    // Metodo que guarda un coche en el fichero indicado.
    public void guardarCoche(Coche c, String nombrefichero) {
        File fileTex = new File(nombrefichero);

        ObjectOutputStream oos = null;

        try {
            oos = new ObjectOutputStream(new FileOutputStream(fileTex));
            // solo fuardamos un coche y no al final
            oos.writeObject(c);

        } catch (IOException e) {
            System.out.println(e.getMessage());
        } finally {
            if (oos != null) {
                try {
                    oos.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }

    }

    // Metodo que devuelve el coche que se encuentra en la posici�n indicada en el
    // fichero indicado.
    public Coche leerCoche(String nombrefichero) {
        Coche coche = null;
        File fil = new File(nombrefichero);

        if (fil.exists()) {
            ObjectInputStream ois = null;
            try {
                ois = new ObjectInputStream(new FileInputStream(fil));
                // solo leemos el primer coche
                coche = (Coche) ois.readObject();

            } catch (EOFException e) {
                // fin de fichero, se llega aqui y no se hace nada
            } catch (IOException e) {
                System.out.println(e.getMessage());
            } catch (ClassNotFoundException e) {
                e.printStackTrace();
            } finally {
                try {
                    if (ois != null) {
                        ois.close();
                    }
                } catch (IOException e) {
                    System.out.println(e.getMessage());
                }
            }
        }
        return coche;

    }

    // Metodo que guarda todos los coches en el fichero indicado.
    public void guardarCoches(ArrayList<Coche> listacoches, String nombrefichero) {
        File fileTex = new File(nombrefichero);

        ObjectOutputStream oos = null;

        try {
            oos = new ObjectOutputStream(new FileOutputStream(fileTex));

            // ESCRIBIR
            for (int i = 0; i < 10; i++) {
                Coche c = listacoches.get(i);
                oos.writeObject(c);

            }

        } catch (IOException e) {
            System.out.println(e.getMessage());
        } finally {
            if (oos != null) {
                try {
                    oos.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }

    }

    // Metodo que devuelve todos los coches contenidos en el fichero en un
    // ArrayList.
    public ArrayList<Coche> leerCoches(String nombrefichero) {
        ArrayList<Coche> listacoches = new ArrayList<Coche>();

        File fil = new File(nombrefichero);

        if (fil.exists()) {
            ObjectInputStream ois = null;
            try {
                ois = new ObjectInputStream(new FileInputStream(fil));

                while (true) {
                    Coche c = (Coche) ois.readObject();
                    listacoches.add(c);
                }
            } catch (EOFException e) {
                // fin de fichero, se llega aqui y no se hace nada
            } catch (IOException e) {
                System.out.println(e.getMessage());
            } catch (ClassNotFoundException e) {
                e.printStackTrace();
            } finally {
                try {
                    if (ois != null) {
                        ois.close();
                    }
                } catch (IOException e) {
                    System.out.println(e.getMessage());
                }
            }
        }

        return listacoches;
    }
}
