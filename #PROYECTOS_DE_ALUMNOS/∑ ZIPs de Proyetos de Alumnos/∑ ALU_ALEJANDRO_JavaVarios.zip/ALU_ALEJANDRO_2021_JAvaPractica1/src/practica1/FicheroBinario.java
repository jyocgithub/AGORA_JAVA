package practica1;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

public class FicheroBinario {

    // Metodo que guarda un coche en el fichero indicado.
    public void guardarCoche(Coche c, String nombrefichero) {
        File fileTex = new File(nombrefichero);

        DataOutputStream dos = null;

        try {
            dos = new DataOutputStream(new FileOutputStream(fileTex, true));

            // ESCRIBIR
            dos.writeUTF(c.getMatricula());
            dos.writeUTF(c.getMarca());
            dos.writeUTF(c.getModelo());
            dos.writeUTF(c.getColor());

            dos.writeInt(c.getMotor().getCilindrada());
            dos.writeUTF(c.getMotor().getCombustible());

            for (int j = 0; j < 4; j++) {

                Rueda r = c.getRuedas().get(j);
                dos.writeInt(r.getAltura());
                dos.writeInt(r.getAncho());
                dos.writeInt(r.getDiametro());
            }


        } catch (IOException e) {
            System.out.println(e.getMessage());
        } finally {
            if (dos != null) {
                try {
                    dos.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }

    }

    // Metodo que devuelve el coche que se encuentra en la posici�n indicada en el
    // fichero indicado.
    public Coche leerCoche(String nombrefichero, int posicion) {
        Coche coche = null;
        int cont = 1;
        boolean encontrado = false;
        File fil = new File(nombrefichero);

        if (fil.exists()) {
            DataInputStream dis = null;
            try {
                dis = new DataInputStream(new FileInputStream(fil));


                while (!encontrado) {
                    // cosas del coche

                    String matricula = dis.readUTF();
                    String marca = dis.readUTF();
                    String modelo = dis.readUTF();
                    String color = dis.readUTF();

                    // cosas del motor

                    int cilindrada = dis.readInt();
                    String combustible = dis.readUTF();
                    Motor motor = new Motor(cilindrada, combustible);

                    // cosas de las ruedas
                    ArrayList<Rueda> listaruedas = new ArrayList<>();
                    for (int j = 0; j < 4; j++) {
                        int altura = dis.readInt();
                        int ancho = dis.readInt();
                        int diametro = dis.readInt();
                        Rueda r = new Rueda(altura, ancho, diametro);
                        listaruedas.add(r);
                    }

                    // miro si es la posicion del coche deseado
                    if (cont == posicion) {
                        coche = new Coche(matricula, marca, modelo, color, motor, listaruedas);
                        encontrado = true;
                    }

                    cont++;
                }

            } catch (EOFException e) {
                System.out.println("Fin de fichero, no se ha encontrado el coche");
            } catch (IOException e) {
                System.out.println(e.getMessage());
            } finally {
                try {
                    if (dis != null) {
                        dis.close();
                    }
                } catch (IOException e) {
                    System.out.println(e.getMessage());
                }
            }
        }

        return coche;

    }

    // Metodo que guarda todos los coches en el fichero indicado.
    public void guardarCoches(ArrayList<Coche> listacoches, String nombrefichero) {
        File fileTex = new File(nombrefichero);

        DataOutputStream dos = null;

        try {
            dos = new DataOutputStream(new FileOutputStream(fileTex));

            // ESCRIBIR
            for (int i = 0; i < 10; i++) {
                Coche c = listacoches.get(i);

                dos.writeUTF(c.getMatricula());
                dos.writeUTF(c.getMarca());
                dos.writeUTF(c.getModelo());
                dos.writeUTF(c.getColor());

                dos.writeInt(c.getMotor().getCilindrada());
                dos.writeUTF(c.getMotor().getCombustible());

                for (int j = 0; j < 4; j++) {

                    Rueda r = c.getRuedas().get(j);
                    dos.writeInt(r.getAltura());
                    dos.writeInt(r.getAncho());
                    dos.writeInt(r.getDiametro());
                }
            }

        } catch (IOException e) {
            System.out.println(e.getMessage());
        } finally {
            if (dos != null) {
                try {
                    dos.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }

    }

    // Metodo que devuelve todos los coches contenidos en el fichero en un
    // ArrayList.
    public ArrayList<Coche> leerCoches(String nombrefichero) {
        ArrayList<Coche> listacoches = new ArrayList<Coche>();

        File fil = new File(nombrefichero);

        if (fil.exists()) {
            DataInputStream dis = null;
            try {
                dis = new DataInputStream(new FileInputStream(fil));

                while (true) {
                    // cosas del coche

                    String matricula = dis.readUTF();
                    String marca = dis.readUTF();
                    String modelo = dis.readUTF();
                    String color = dis.readUTF();

                    // cosas del motor

                    int cilindrada = dis.readInt();
                    String combustible = dis.readUTF();
                    Motor motor = new Motor(cilindrada, combustible);

                    // cosas de las ruedas
                    ArrayList<Rueda> listaruedas = new ArrayList<Rueda>();
                    for (int j = 0; j < 4; j++) {
                        int altura = dis.readInt();
                        int ancho = dis.readInt();
                        int diametro = dis.readInt();
                        Rueda r = new Rueda(altura, ancho, diametro);
                        listaruedas.add(r);
                    }

                    Coche c = new Coche(matricula, marca, modelo, color, motor, listaruedas);
                    listacoches.add(c);
                }
            } catch (EOFException e) {
                // fin de fichero, se llega aqui y no se hace nada
            } catch (IOException e) {
                System.out.println(e.getMessage());
            } finally {
                try {
                    if (dis != null) {
                        dis.close();
                    }
                } catch (IOException e) {
                    System.out.println(e.getMessage());
                }
            }
        }

        return listacoches;
    }
}
