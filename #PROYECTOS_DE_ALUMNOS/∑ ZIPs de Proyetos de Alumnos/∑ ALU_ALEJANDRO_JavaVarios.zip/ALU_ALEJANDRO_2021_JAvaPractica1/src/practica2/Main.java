package practica2;

import java.lang.reflect.Method;
import java.util.ArrayList;

/*-D. Finalmente, crea un metodo main que utilice los metodos anteriormente creados.
El programa debera funcionar secuencialmente sin ningun menu, llamando a los metodos uno tras otro.
El usuario NO tendra ninguna interaccion con el programa. NO HAGAIS NINGUN MENU

*/


public class Main {

    public static void main(String[] args) {


        Metodos m = new Metodos();

        // parte A
        ArrayList<Contacto> lista = m.parteA();

        System.out.println(lista);

        // parte B
        m.parteB(lista);


        // parte C
        m.parteC();


    }

}
