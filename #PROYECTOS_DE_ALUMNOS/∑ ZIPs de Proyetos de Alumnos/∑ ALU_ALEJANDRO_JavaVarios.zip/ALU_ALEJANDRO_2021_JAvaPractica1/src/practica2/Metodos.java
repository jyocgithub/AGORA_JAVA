package practica2;

import java.io.*;
import java.util.ArrayList;

public class Metodos {


/*	-A. Escribe un metodo en java que lea el fichero de texto anterior
	y cree los contactos correspondientes a cada una de las personas del fichero.
	El programa no deber saber cuantas personas hay definidas en el fichero, por lo que no vale hacer 3 lecturas si mas.
	Habra que hacer un bucle hasta llegar al final del fichero y crear tantos contactos como personas haya en el fichero.
	El metodo debe devolver un arrayList con los contactos.
*/

        public ArrayList<Contacto> parteA() {
        String nombrefichero = "./practica2/contactos.txt";
        ArrayList<Contacto> listacontactos = new ArrayList<>();
        File[] f = new File(".").listFiles();
        File archivo = new File(nombrefichero);
        String linea1, linea2, linea3, linea4;
        if (archivo.exists()) {
            BufferedReader br = null;
            try {
                br = new BufferedReader(new FileReader(archivo));

                linea1 = br.readLine();
                while (linea1 != null) {
                    linea2 = br.readLine();
                    linea3 = br.readLine();
                    linea4 = br.readLine();
                    String nombre = linea1;
                    String[] cosas = linea2.split(" ");
                    String telefono = cosas[0];
                    int edad = Integer.parseInt(cosas[1]);
                    Contacto c = new Contacto(nombre, telefono, edad);
                    listacontactos.add(c);

                    linea1 = br.readLine();
                }

            } catch (IOException ex) {
                ex.printStackTrace();
            } finally {
                try {
                    br.close();
                } catch (IOException ex) {
                    ex.printStackTrace();
                }
            }
        }
        return listacontactos;

    }

    /*	-B. Escribe un metodo que reciba el arrayList de contactos devuelto por el metodo anterior,
        modifique el telefono de todos los contactos a valores aleatorios y guarde todos los contactos en 3 ficheros;
        uno de texto, otro binario y otro serializado. Se pueden utilizar metodos auxiliares.
        En el fichero binario no es valido escribir el contacto utilizando el metodo toString,
        habra que guardar cada atributo por separado.
    */
    public void parteB(ArrayList<Contacto> listacontactos) {
        cambiarTelefonos(listacontactos);
        guardarFicheroTexto(listacontactos);
        guardarFicheroBinario(listacontactos);
        guardarFicheroSerializado(listacontactos);
    }

    //  -C. Escribe un metodo que debera mostrar el contenido de los 3 ficheros uno detras del otro.
    public void parteC() {
        mostrarFicheroTexto();
        mostrarFicheroBinario();
        mostrarFicheroSerializado();
    }

    public static void guardarFicheroTexto(ArrayList<Contacto> listacontactos) {
        BufferedWriter bw = null;

        try {
            bw = new BufferedWriter(new FileWriter("ContactosTextos.txt"));
            for (Contacto c : listacontactos) {
                bw.write(c.getNombre() + "," + c.getTelefono() + "," + c.getEdad());
                bw.newLine();
            }

        } catch (IOException ex) {
            ex.printStackTrace();
        } finally {
            try {
                bw.close();
            } catch (IOException ex) {
                ex.printStackTrace();
            }
        }
    }

    public static void cambiarTelefonos(ArrayList<Contacto> listacontactos) {
        for (Contacto c : listacontactos) {
            int telefononuevo = (int) (Math.random() * 1000000 + 600000000);
            c.setTelefono(String.valueOf(telefononuevo));
        }
    }

    public static void guardarFicheroBinario(ArrayList<Contacto> listacontactos) {
        DataOutputStream dos = null;

        try {
            dos = new DataOutputStream(new FileOutputStream("ContactosBinarios.bin"));
            for (Contacto c : listacontactos) {
                dos.writeUTF(c.getNombre());
                dos.writeUTF(c.getTelefono());
                dos.writeInt(c.getEdad());
            }

        } catch (IOException ex) {
            ex.printStackTrace();
        } finally {
            try {
                if (dos != null) {
                    dos.close();
                }
            } catch (IOException ex) {
                ex.printStackTrace();
            }
        }
    }


    public static void guardarFicheroSerializado(ArrayList<Contacto> listacontactos) {
        ObjectOutputStream oos = null;

        try {
            oos = new ObjectOutputStream(new FileOutputStream("ContactosSerializados.bin"));
            for (Contacto c : listacontactos) {
                oos.writeObject(c);
            }

        } catch (IOException ex) {
            ex.printStackTrace();
        } finally {
            try {
                if (oos != null) {
                    oos.close();
                }
            } catch (IOException ex) {
                ex.printStackTrace();
            }
        }
    }



    public static void mostrarFicheroTexto() {
        System.out.println(" =========== TEXTO =============== ");
        String nombrefichero = "ContactosTextos.txt";

        File archivo = new File(nombrefichero);
        String linea1, linea2, linea3, linea4;
        if (archivo.exists()) {
            BufferedReader br = null;
            try {
                br = new BufferedReader(new FileReader(archivo));

                linea1 = br.readLine();
                while (linea1 != null) {

                    String[] cosas = linea1.split(",");
                    String nombre = cosas[0];
                    String telefono = cosas[1];
                    String edad = cosas[2];
                    System.out.println("Nombre : " + nombre + "; telefono:" + telefono + " ; edad: " + edad);

                    linea1 = br.readLine();
                }

            } catch (IOException ex) {
                ex.printStackTrace();
            } finally {
                try {
                    br.close();
                } catch (IOException ex) {
                    ex.printStackTrace();
                }
            }
        }
    }

    public static void mostrarFicheroBinario() {
        System.out.println(" =========== BINARIO =============== ");
        DataInputStream dis = null;

        try {
            dis = new DataInputStream(new FileInputStream("ContactosBinarios.bin"));

            while (true) {
                System.out.print("Nombre : " + dis.readUTF());
                System.out.print("; telefono : " + dis.readUTF());
                System.out.println("; edad : " + dis.readInt());
            }

        } catch (EOFException ex) {
            System.out.println("Fin de lectura de fichero");
        } catch (IOException ex) {
            ex.printStackTrace();
        } finally {
            try {
                if (dis != null) {
                    dis.close();
                }
            } catch (IOException ex) {
                ex.printStackTrace();
            }
        }
    }


    public static void mostrarFicheroSerializado() {
        System.out.println(" =========== SERIALIZADO =============== ");
        ObjectInputStream ois = null;

        try {
            ois = new ObjectInputStream(new FileInputStream("ContactosSerializados.bin"));

            while (true) {
                Contacto c = (Contacto) ois.readObject();
                System.out.println("Nombre : " + c.getNombre() + "; telefono:" + c.getTelefono() + " ; edad: " + c.getEdad());

            }

        } catch (EOFException ex) {
            System.out.println("Fin de lectura de fichero");
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (IOException ex) {
            ex.printStackTrace();
        } finally {
            try {
                if (ois != null) {
                    ois.close();
                }
            } catch (IOException ex) {
                ex.printStackTrace();
            }
        }
    }


}
