package nacho;

import java.util.Scanner;

public class Nacho {

   public static void main(String[] args) {

      int[] x = new int[6];
      x[0] = 124;
      x[1] = 824;
      x[2] = 34;
      x[3] = 134;
      x[4] = x[3] * 234;
      x[5] = 234;

      int k;
      x[4] = k * 234;
                                       
   
      String u = "dc khl vnksfl     ºkjahdc    ";
      String j = "lakmvfñljkdñj ";
      
      
      
      
     
              
      int[] p;
      Scanner sc = new Scanner(System.in);
      System.out.println("Dame el tamaño del array");
      int tam = sc.nextInt();
      p = new int[tam];

      for (int i = 0; i < x.length; i++) {
         System.out.println(p[i]);

      }

      for (int i = 0; i < p.length; i++) {
         p[i]
      }

   }

}
