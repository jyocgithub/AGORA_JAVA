package utils;

import org.hibernate.SessionFactory;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;

import tablas.Dept;
import tablas.Emp;

public class SessionFactoryUtil {

	
	//ATRIBUTOS
	//-----------------------------------------------------
	
    private static Configuration configuration;
	private static ServiceRegistry serviceRegistry;
	private static SessionFactory sessionFactory;

    
	//M�TODOS
	//-----------------------------------------------------
    
	public static SessionFactory createSessionFactory() {
    	
    	configuration = new Configuration();
        configuration.configure();
        
        serviceRegistry = new StandardServiceRegistryBuilder().applySettings(configuration.getProperties()).build();

        sessionFactory = configuration.addAnnotatedClass(Emp.class)
        							  .addAnnotatedClass(Dept.class)
        							  .buildSessionFactory(serviceRegistry);

        return sessionFactory;
        
	}//createSessionFactory
    
    
    
}//SessionFactoryUtil
