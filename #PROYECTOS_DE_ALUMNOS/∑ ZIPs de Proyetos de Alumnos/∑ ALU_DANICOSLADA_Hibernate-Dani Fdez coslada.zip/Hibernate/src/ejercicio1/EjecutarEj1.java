package ejercicio1;

import java.util.Scanner;
import java.util.Set;



import tablas.Emp;



public class EjecutarEj1 {
	

	public static void main(String[] args) {
    
	 ManejoBBDD ej1=new ManejoBBDD();
     System.out.println("Introduce el id del departamento que quieras mostrar: ");
     Scanner scan=new Scanner(System.in);
     byte id=scan.nextByte();
     
     Set<Emp> listaEmpleadosEmps=ej1.mostrarEmpleadosConId(id);
     System.out.println("La Lista de empleados con dept= "+id);
     for(Emp empleado:listaEmpleadosEmps) {
    	 System.out.println(empleado);
     }
     System.out.println("**********************************");
     
     System.out.println("introduce el id del departamento nuevo: ");
     byte deptno=scan.nextByte();
     System.out.println("introduce el nombre: ");
     String dname=scan.next();
     System.out.println("introduce la localizaci�n: ");
     String loc=scan.next();
     ej1.crearDepartamento(deptno, dname, loc);
     
     
     System.out.println("introduce el id del empleado que quieras borrar: ");
      short idEmp=scan.nextShort();
      scan.close();
     ej1.borrarEmpleado(idEmp);
     System.exit(0);
     

	}

}
