import org.hibernate.Session;
import org.hibernate.Transaction;

import tablas.Dept;
import utils.HibernateUtils;

public class PruebaEjecutar {
	
	private static Session session;

	public static void main(String[] args) {
		
		//abrimos la sesion con hibernate
		session=HibernateUtils.getSessionFactory().openSession();
		Transaction transaccion=session.beginTransaction();
		
		createDept((byte) 1);
		
		//hacer la transaccion
		transaccion.commit();
		//cerrar la sesion
		session.close();
		

	}

	private static void createDept(byte id) {
		Dept deptt=new Dept();
		deptt.setDeptno((byte)60);
		deptt.setDname("MARKETING");
		deptt.setLoc("GUADALAJARA");
		session.save(deptt);
		
	}

}
