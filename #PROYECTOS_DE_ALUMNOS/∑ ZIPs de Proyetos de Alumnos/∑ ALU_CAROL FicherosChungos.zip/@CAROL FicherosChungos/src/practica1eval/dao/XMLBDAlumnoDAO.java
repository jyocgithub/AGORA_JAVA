package practica1eval.dao;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.DOMImplementation;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;

import com.sun.org.apache.xml.internal.serialize.OutputFormat;
import com.sun.org.apache.xml.internal.serialize.XMLSerializer;

import practica1eval.dao.exception.ExcepcionDAO;
import practica1eval.idao.AlumnoDAO;
import practica1eval.model.Alumno;

public class XMLBDAlumnoDAO implements AlumnoDAO
{
	public static Document crearDocumento(HashMap<String, String> hashmap, String nombreXML)
	{

		DocumentBuilder builder = null;
		Document miDocDom = null;
		try
		{

			DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
			builder = factory.newDocumentBuilder();
			DOMImplementation implementation = builder.getDOMImplementation();


			miDocDom = implementation.createDocument(null, nombreXML, null);


			// ------- RAMA DE PERSONAL DEL XML
			// -- crea ETIQUETA PERSONAL
			Element raiz = miDocDom.getDocumentElement();

			for (String clavedni : hashmap.keySet())
			{
				Element etalumno = miDocDom.createElement("alumno");
				Element etnombre = miDocDom.createElement("nombre");
				Element etdni = miDocDom.createElement("dni");
				Node valordni = miDocDom.createTextNode(clavedni);
				Node valornombre = miDocDom.createTextNode(hashmap.get(clavedni));

				etalumno.appendChild(etdni);
				etalumno.appendChild(etnombre);

				etdni.appendChild(valordni);
				etnombre.appendChild(valornombre);

				raiz.appendChild(etalumno);

			}

		}
		catch (ParserConfigurationException e)
		{
			e.printStackTrace();
		}
		return miDocDom;
	}

	public static void guardarDocumentoDOMcomoXML(Document miDocumentoDom, String nombreFicheroXML)
	{
		/*Crea un File con el nombre del parametro del m�todo
		 *Especifica el formato de salida, que es en realidad el objeto
		 *Document creado en el m�todo anterior a este
		 *Especifica ademas que la salida est� indentada, esto es, con formato indentado
		 *Escribe (fisicamente) el contenido en el FILE. Para ello crea
		 *primero un objeto serializador, con el File y el format creados
		 *y finalmente ejecuta la serializacion
		 **/

		try
		{

			File archivo_xml = new File(nombreFicheroXML);

			OutputFormat miFormato = new OutputFormat(miDocumentoDom);

			miFormato.setIndenting(true);

			FileOutputStream fos = new FileOutputStream(archivo_xml);
			XMLSerializer serializer = new XMLSerializer(fos, miFormato);

			serializer.serialize(miDocumentoDom);
		}
		catch (IOException e)
		{
			throw new ExcepcionDAO(e.getMessage());
		}
	}





	@Override
	public boolean insertaAlumno(Alumno alumno)
	{
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Alumno borraAlumno(String DNI)
	{
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Alumno buscaAlumno(String DNI)
	{
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean modificaAlumno(String DNI, Alumno alumno)
	{
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public List<Alumno> listadoAlumnos()
	{
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Map<String, Alumno> listadoMapAlumnos()
	{
		// TODO Auto-generated method stub
		return null;
	}
}
