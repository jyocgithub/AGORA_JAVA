package bbdd;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import pojos.Alquiler;
import pojos.Cliente;
import pojos.Pelicula;
import vistas.AlquilarPelicula;

public class BBDDVideoClub {

     Connection conexion;

     public void insertarCliente(Cliente miCliente) {
          conectar();
          try {
               String sql = "INSERT INTO CLIENTE ( NOMBRE, DIRECCION, TELEFONO ) VALUES ( ?,?,?)  "; //no aparece cod_cliente por ser autoincrementable

               PreparedStatement instruccion = conexion.prepareStatement(sql);
               instruccion.setString(1, miCliente.getNombre());//empieza en posicion 1 y no 0
               instruccion.setString(2, miCliente.getDireccion());
               instruccion.setString(3, miCliente.getTelefono());
               instruccion.executeUpdate();

          } catch (SQLException ex) {
               Logger.getLogger(BBDDVideoClub.class.getName()).log(Level.SEVERE, null, ex);
          } finally {
               desconectar();
          }

     }

     public void insertarPelicula(Pelicula miPelicula) {
          conectar();
          try {
               String sql = "INSERT INTO PELICULA ( GENERO, ARGUMENTO, DISPONIBLES ) VALUES ( ?,?,?)  ";

               PreparedStatement instruccion = conexion.prepareStatement(sql);
               instruccion.setString(1, miPelicula.getGenero());
               instruccion.setString(2, miPelicula.getArgumento());
               instruccion.setInt(3, miPelicula.getDisponibles());
               instruccion.executeUpdate();

          } catch (SQLException ex) {
               Logger.getLogger(BBDDVideoClub.class.getName()).log(Level.SEVERE, null, ex);
          } finally {
               desconectar();
          }
     }

     public ArrayList<Cliente> consultarClientes() {

          conectar();

          ArrayList<Cliente> clientes = new ArrayList<>();
          try {
               String sql = "SELECT * FROM CLIENTE "; //no aparece cod_cliente por ser autoincrementable

               PreparedStatement instruccion = conexion.prepareStatement(sql);

               ResultSet registros = instruccion.executeQuery();

               while (registros.next()) {
                    int cod = registros.getInt("cod_cliente");
                    String nom = registros.getString("nombre");
                    String dir = registros.getString("direccion");
                    String tel = registros.getString("telefono");

                    Cliente nuevocliente = new Cliente(cod, nom, dir, tel);

                    clientes.add(nuevocliente);

               }

          } catch (SQLException ex) {
               Logger.getLogger(BBDDVideoClub.class.getName()).log(Level.SEVERE, null, ex);
          } finally {
               desconectar();

          }
          return clientes;
     }

     public ArrayList<Pelicula> consultarPeliculas() {
          conectar();

          ArrayList<Pelicula> peliculas = new ArrayList<>();
          try {
               String sql = "SELECT * FROM PELICULA ";

               PreparedStatement instruccion = conexion.prepareStatement(sql);

               ResultSet registros = instruccion.executeQuery();

               while (registros.next()) {
                    int cod = registros.getInt("cod_peli");
                    int dis = registros.getInt("disponibles");
                    String gen = registros.getString("genero");
                    String arg = registros.getString("argumento");

                    Pelicula nuevaPelicula = new Pelicula(cod, dis, gen, arg);

                    peliculas.add(nuevaPelicula);

               }

          } catch (SQLException ex) {
               Logger.getLogger(BBDDVideoClub.class.getName()).log(Level.SEVERE, null, ex);
          } finally {
               desconectar();

          }
          return peliculas;
     }

     public ArrayList<Alquiler> consultarAlquileres() {
          conectar();

          ArrayList<Alquiler> alquileres = new ArrayList<>();
          try {
               String sql = "SELECT * FROM ALQUILER";

               PreparedStatement instruccion = conexion.prepareStatement(sql);

               ResultSet registros = instruccion.executeQuery();

               while (registros.next()) {
                    int peli = registros.getInt("cod_peli");
                    int cli = registros.getInt("cod_cliente");

                    Alquiler alq = new Alquiler(cli, peli);

                    alquileres.add(alq);

               }

          } catch (SQLException ex) {
               Logger.getLogger(BBDDVideoClub.class.getName()).log(Level.SEVERE, null, ex);
          } finally {
               desconectar();

          }
          return alquileres;
     }

   

     public boolean consultarUnAlquiler(int codcli, int codpeli) {
          boolean resultado = false;
          conectar();

          Cliente cliente = null;
          try {
               String sql = " SELECT * FROM ALQUILER WHERE COD_CLIENTE = ? AND COD_PELI = ?"; //no aparece cod_cliente por ser autoincrementable

               PreparedStatement instruccion = conexion.prepareStatement(sql);
               instruccion.setInt(1, codcli);
               instruccion.setInt(2, codpeli);
               ResultSet registros = instruccion.executeQuery();

               if (registros.next()) {
                    resultado = true;
               }

          } catch (SQLException ex) {
               Logger.getLogger(BBDDVideoClub.class.getName()).log(Level.SEVERE, null, ex);
          } finally {
               desconectar();

          }
          return resultado;
     }

     public boolean alquilarPeli(int codcli, int codpeli) {
          boolean res = true;

          int quedanDisponibles = 0;
          conectar();

          try {
               // VER SI HAY EXISTENCUAS
               String sql = " SELECT DISPONIBLES FROM PELICULA WHERE COD_PELI = ?"; //no aparece cod_peli por ser autoincrementable

               PreparedStatement instruccion = conexion.prepareStatement(sql);
               instruccion.setInt(1, codpeli);
               ResultSet registros = instruccion.executeQuery();

               if (registros.next()) { //DBE CUMPLIRSE SIEMPRE, PERO.... POR ACCIONES FUTURAS 
                    quedanDisponibles = registros.getInt("disponibles");
               }
//            else {
//                DatosNoEncontradosException mierror = new DatosNoEncontradosException();
//                throw mierror;
//            }

               if (quedanDisponibles <= 0) {
                    res = false;
               } else {
                    // SI LAS HAY ALQUILAR: GUARDAR EN ALQUILERES

                    // VER SI EHY EXISTENCUAS
                    String sql2 = " INSERT INTO ALQUILER VALUES ( ?, ?) ";

                    PreparedStatement instruccion2 = conexion.prepareStatement(sql2);
                    instruccion2.setInt(1, codcli);
                    instruccion2.setInt(2, codpeli);
                    instruccion2.executeUpdate();

                    // ACTUALIZAR EXISTENCIAS
                    String sql3 = " UPDATE PELICULA SET DISPONIBLES = ? WHERE COD_PELI = ? ";

                    PreparedStatement instruccion3 = conexion.prepareStatement(sql3);
                    instruccion3.setInt(1, quedanDisponibles - 1);
                    instruccion3.setInt(2, codpeli);
                    instruccion3.executeUpdate();

               }

          } catch (SQLException ex) {
               Logger.getLogger(BBDDVideoClub.class.getName()).log(Level.SEVERE, null, ex);
          } finally {
               desconectar();

          }

          return res;

     }

     public void altaTablas() {

          String sqlCrearTablaPelicula = "CREATE TABLE IF NOT EXISTS pelicula ( "
                  + "cod_peli int NOT NULL AUTO_INCREMENT,  "
                  + "genero varchar(20) DEFAULT NULL, "
                  + "argumento varchar(45) DEFAULT NULL, "
                  + "disponibles int DEFAULT NULL , "
                  + "PRIMARY KEY (cod_peli))";

          String sqlCrearTablaAlquiler = "CREATE TABLE  IF NOT EXISTS alquiler (  cod_cliente int NOT NULL, "
                  + "cod_peli int NOT NULL, "
                  + "PRIMARY KEY (cod_cliente,cod_peli),"
                  + " CONSTRAINT fk1 FOREIGN KEY (cod_peli) REFERENCES pelicula (cod_peli),  "
                  + " CONSTRAINT fk2 FOREIGN KEY (cod_cliente) REFERENCES cliente (cod_cliente))";

          String sqlCrearTablaCliente = " CREATE TABLE IF NOT EXISTS cliente ( "
                  + " cod_cliente int NOT NULL AUTO_INCREMENT,"
                  + " nombre varchar(45) DEFAULT NULL, "
                  + " direccion varchar(45) DEFAULT NULL, "
                  + " telefono varchar(45) DEFAULT NULL, "
                  + " PRIMARY KEY (cod_cliente));";

          conectar();
          try {

               PreparedStatement instruccion = conexion.prepareStatement(sqlCrearTablaCliente);
               instruccion.executeUpdate();

               instruccion = conexion.prepareStatement(sqlCrearTablaPelicula);
               instruccion.executeUpdate();

               instruccion = conexion.prepareStatement(sqlCrearTablaAlquiler);
               instruccion.executeUpdate();

          } catch (SQLException ex) {
               Logger.getLogger(BBDDVideoClub.class.getName()).log(Level.SEVERE, null, ex);
          } finally {
               desconectar();
          }

     }

     public void conectar() {
          try {
               conexion = DriverManager.getConnection("jdbc:mysql://localhost:3306/tarea11", "root", "root");
          } catch (SQLException ex) {
               Logger.getLogger(BBDDVideoClub.class.getName()).log(Level.SEVERE, null, ex);
          }
     }

     public void desconectar() {
          try {
               conexion.close();
          } catch (SQLException ex) {
               Logger.getLogger(BBDDVideoClub.class.getName()).log(Level.SEVERE, null, ex);
          }
     }

}
