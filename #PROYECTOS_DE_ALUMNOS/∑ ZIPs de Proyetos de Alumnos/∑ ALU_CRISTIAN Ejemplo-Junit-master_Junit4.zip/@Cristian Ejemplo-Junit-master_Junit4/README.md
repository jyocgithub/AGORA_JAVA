Ejemplo-Junit
=============

Ejemplos en Junit para curso de testing

Para los ejemplos se utilizo Eclipse Helios for Java Developers, además de Junit 4.

Se utilizo el plugin ecobertura (http://ecobertura.johoop.de/)
