package cl.usm.testing.ejercicio.carrito;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

public class ShoppingCartTest {

	private ShoppingCart bookCart;
	private Product defaultBook;

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {
		bookCart = new ShoppingCart();
		defaultBook = new Product("Extreme Programming", 23.95);
		bookCart.addItem(defaultBook);
	}

	@Test
	// Prueba que después de ejecutar el método empty()
	// sobre la instancia del carrito de compras "bookCart" esta queda vacía (isEmpty()).
	public void testEmpty() {
		bookCart.empty();
		assertTrue(bookCart.isEmpty());
		// int expected = 0 ;
		// int actual = bookCart.getItemCount();
		assertEquals(0, bookCart.getItemCount());
	}

	@Test
	// Al carrito inicial de compras que ya tenía un ítem se le
	// agrega otro y luego se verifica que el balance de la compra
	// (getBalance()) sea la suma del costo de los dos ítems y
	// que el número de ítems final (getItemCount()) sea igual a dos.
	public void testProductAdd() {
		Product p = new Product("item2", 10);
		bookCart.addItem(p);
		assertEquals(33.95, bookCart.getBalance(), 0);
		assertEquals(2, bookCart.getItemCount());
	}

	// aqui no hay assert por que el assert es que se lance efectivamente la excepcion
	// como se indica tras la anotacion @Test
	@Test(expected = ProductNotFoundException.class)
	public void testProductNotFound() throws ProductNotFoundException {
		Product p = new Product("", 123);
		bookCart.removeItem(p);
	}

	// IDEM PARA JUNIT5
	// aqui no hay assert por que el assert es que se lance efectivamente la excepcion
	// como se indica tras la anotacion @Test
	// @Test
	// public void testProductNotFound_en_junit5() throws ProductNotFoundException {
	//
	// assertThrows( ProductNotFoundException.class, () -> {
	// Product p = new Product("", 123);
	// bookCart.removeItem(p);
	// });
	//
	// }

	@Test
	// Prueba que dos productos son iguales
	// Es necesaria sobre todo por la tercera prueba,
	// pues sin ella la cobertura de la clase Product no es del 100
	// ya que no se comprobaba el metodo equals() recibiendo un objeto que no
	// fuera una instancia de producto
	public void testProductEquals() {
		Product p1 = new Product("item2", 10);
		Product p2 = new Product("item2", 10);
		Product p3 = new Product("item9", 99);
		String d = "Hola";
		assertTrue(p1.equals(p2));
		assertFalse(p1.equals(p3));
		assertFalse(p1.equals(d));
	}

	@Test
	// Necesario por que si no la cobertura no prueba que se borre efectivamente un producto
	public void testProductRemove() throws ProductNotFoundException {
		Product p = new Product("", 123);
		bookCart.addItem(p);
		bookCart.removeItem(p);
		assertEquals(1, bookCart.getItemCount());
	}

	@Test
	// Necesario por que si no la cobertura no prueba que isempty() pueda dar false y true, solo daba true
	public void testIsEmpty() throws ProductNotFoundException {
		assertFalse(bookCart.isEmpty());
		bookCart.removeItem(defaultBook);
		assertTrue(bookCart.isEmpty());
	}

	@After
	public void tearDown() throws Exception {
		bookCart = null;
	}

}
