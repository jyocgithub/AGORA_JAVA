public class GestionPersonas {
	Persona[] arrPersonas;

	public void crearArray() {
		arrPersonas = new Persona[3];
		arrPersonas[0] = new Persona("Pepe", 23);
		arrPersonas[1] = new Persona("Ana", 11);
		arrPersonas[2] = new Persona("Luis", 59);
	}

	public int mayorEdad() {
		int mayor = arrPersonas[0].getEdad();
		for (Persona p : arrPersonas) {
			if (p.getEdad() > mayor) {
				mayor = p.getEdad();
			}
		}
		return mayor;
	}

	public Persona quienMayorEdad() {
		int mayor = arrPersonas[0].getEdad();
		Persona pmayor = arrPersonas[0];
		for (Persona p : arrPersonas) {
			if (p.getEdad() > mayor) {
				mayor = p.getEdad();
				pmayor = p;
			}
		}
		return pmayor;
	}
}