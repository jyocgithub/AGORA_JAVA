package com.jyoc.miproyectospringnb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MiproyectospringnbApplicationTests {

	@Test
	void contextLoads() {
	}

}
