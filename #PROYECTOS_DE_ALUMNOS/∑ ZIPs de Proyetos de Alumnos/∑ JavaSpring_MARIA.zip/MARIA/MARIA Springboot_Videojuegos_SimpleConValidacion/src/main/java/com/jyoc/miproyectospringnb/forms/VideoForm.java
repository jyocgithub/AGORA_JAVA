package com.jyoc.miproyectospringnb.forms;

// Exige dependencia en Gradle :
// compile group: 'org.springframework.boot', name: 'spring-boot-starter-validation', version: '2.3.5.RELEASE'
import javax.validation.constraints.Min;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Size;

// ESTA CLASE SE USA PARA VALIDAR UN OBJETO DE LA CLASE VIDEO
// ademas de ser usada en el controlador , tambien se relaciona con el formulario thymeleaf
// para indicar los errores en el navegador


public class VideoForm {
    
     // --------- VALIDACIONES DE ATRIBUTOS ----------------------------------------
    @NotEmpty(message = "El titulo es obligatorio.")  // esto no permite que este valor este vacio 
    @Size(min=1, max=256)    // esta validacion controla tamaño minimo y maximo del valor
    private String titulo;
    
    @Min(value=0)           // no permitiremos valores de año negativos 
    private Integer ano;
    
    @Size(min=1, max=256)   // esta validacion controla tamaño minimo y maximo del valor
    private String productora;

     // --------- METODOS DE VALIDACION ----------------------------------------
    public void vaciarForm() {
        titulo=null;
        ano=null;
        productora=null;
    }
    
    
    
     // --------- GETTERS Y SETTERS ----------------------------------------
    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo.trim();   //Para evitar que a base de escribir espacios pueda saltarse la validacion.
    }

    public Integer getAno() {
        return ano;
    }

    public void setAno(Integer ano) {
        this.ano = ano;
    }

    public String getProductora() {
        return productora;
    }

    public void setProductora(String productora) {
        this.productora = productora;
    }
}
