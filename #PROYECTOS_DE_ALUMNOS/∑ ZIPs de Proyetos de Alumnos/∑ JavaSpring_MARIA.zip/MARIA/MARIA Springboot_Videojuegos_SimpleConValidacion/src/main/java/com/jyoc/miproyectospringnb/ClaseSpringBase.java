package com.jyoc.miproyectospringnb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ClaseSpringBase {

	public static void main(String[] args) {
		SpringApplication.run(ClaseSpringBase.class, args);
	}

}
