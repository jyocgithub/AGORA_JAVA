package com.jyoc.miproyectospringnb.controllers;

import com.jyoc.miproyectospringnb.forms.VideoForm;
import com.jyoc.miproyectospringnb.model.Video;
import com.jyoc.miproyectospringnb.repositories.VideoRepository;
import javax.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import static org.springframework.web.bind.annotation.RequestMethod.GET;
import static org.springframework.web.bind.annotation.RequestMethod.POST;
import org.springframework.web.bind.annotation.RequestParam;

@Controller  // sustituye al servlet tradicional
@RequestMapping("video")    // establece un mapeo de URL INICIAL para TODOS LOS METODOS (puede ir con o sin / )
public class VideoController {
    @Autowired
    VideoRepository videoRepository;
    
    @RequestMapping(value = "borrar")
    public String borrar(@RequestParam(name = "id") String id, Model model) {
        Long elid=null;
        String m=null;
        try {
            elid=Long.parseLong(id);
            videoRepository.deleteById(elid);
            m="Se ha borrado el juego juego con id " + id;
        } catch(Exception e) {
            m="No se pudo borrar el juego con id " + id;
        }
        return "redirect:/videojuego/todos?mensaje=" + m;
    }
    
    @RequestMapping(value = "todos")
    public String mostrarTodos(Model model) {
        model.addAttribute("videojuegos", videoRepository.findAll());
        return "videojuegos";
    }
    
    @RequestMapping(value = "crear", method = GET)
    public String crearGet(VideoForm vf, Model model) {
        return "videojuego";
    }
    
    @RequestMapping(value = "crear", method = POST)
    public String crearPost(@Valid VideoForm vf, BindingResult bindingResult, Model model) {
        
        if (bindingResult.hasErrors()) {
            return "videojuego";
        }
        
        Video v = new Video();
        v.setTitulo(vf.getTitulo());
        v.setAno(vf.getAno());
        v.setProductora(vf.getProductora());
        videoRepository.save(v);
        
        model.addAttribute("resultado", "Juego creado.");
        vf.vaciarForm();
        return "videojuego";
    }


     // @Valid indica qué clase se va a usar para validar un objeto a la hora de crearlo
     // BindingResult es un objeto que se crea por Spring tras hacer la validacion, y lleva informacion de la validacion


}

// en esta version no anidamos los mappings, los poniamos siempre enteros en la peticion finalm, esto  es, 
// no ponemos @RequestMapping("video") delante de la clase como un mapeo inicial, sino que el mapping va entero en cada metodo

//@Controller  // sustituye al servlet tradicional
//public class VideoController {
//     
//     
//     @RequestMapping("/video/crear")    // establece un mapeo de URL para este método
//     public String tiendaCrear(){
//          return "video";    // un return ejecuta algo asi como un formward de un servlet,
//                                 
//     }
//
//     
//}
