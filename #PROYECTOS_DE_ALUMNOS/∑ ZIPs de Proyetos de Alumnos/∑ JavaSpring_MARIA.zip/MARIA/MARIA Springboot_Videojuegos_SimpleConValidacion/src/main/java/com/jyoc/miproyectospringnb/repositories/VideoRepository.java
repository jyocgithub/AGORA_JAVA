
package com.jyoc.miproyectospringnb.repositories;

import com.jyoc.miproyectospringnb.model.Video;
import org.springframework.data.jpa.repository.JpaRepository;

/*Hay que crear un repository por cada @Entity*/
public interface VideoRepository extends JpaRepository<Video, Long>{
    
}
