package com.daw2.ejemploREST.controllers;

import com.daw2.ejemploREST.forms.ProductoraForm;
import java.util.List;
import com.daw2.ejemploREST.models.Productora;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.daw2.ejemploREST.repositories.ProductoraRepository;
import javax.validation.Valid;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;

@RestController
@RequestMapping(value = "/productora")
public class ProductoraController {

    @Autowired
    ProductoraRepository pr;

    @GetMapping("/todas")
    public List<Productora> todos() {
        return pr.findAll();
    }
    
    @DeleteMapping("/{id}")
    public String borrar(@PathVariable("id") long id) {
        pr.deleteById(id);
        return "{\"Result\": \"OK\"}";
    }
    
    @GetMapping("/{id}")
    public Productora leer(@PathVariable("id") long id) {
        Productora p = new Productora();
        p.setNombre("No existe");
        return pr.findById(id).orElse(p);
    }
    
 
    @PostMapping
    public String crear(@Valid ProductoraForm pf,
			BindingResult bindingResult) {
        
        if (bindingResult.hasErrors()) {
            return "{\"Result\": \"ERROR\"}";
        }
        
        try {
            Productora p = new Productora();
            p.setNombre(pf.getNombre());
            p.setAnoFundacion(pf.getAnoFundacion());
            p.setPresidente(pf.getPresidente());
            pr.save(p);
            return "{\"Result\": \"OK\"}";
        } catch(Exception e) {
            // nada
        }
        return "{\"Result\": \"ERROR\"}";
    }
    
    @PutMapping
    public String actualizar(@Valid ProductoraForm pf,
			BindingResult bindingResult) {
        
        if (bindingResult.hasErrors()) {
            return "{\"Result\": \"ERROR\"}";
        }
        
        if(pf.getId()!=null) {
            Productora p = pr.findById(pf.getId()).orElse(null);
            if(p!=null) {
                p.setNombre(pf.getNombre());
                p.setAnoFundacion(pf.getAnoFundacion());
                p.setPresidente(pf.getPresidente());
                pr.save(p);
                return "{\"Result\": \"OK\"}";
            }
        }
        return "{\"Result\": \"ERROR\"}";
    }
}
