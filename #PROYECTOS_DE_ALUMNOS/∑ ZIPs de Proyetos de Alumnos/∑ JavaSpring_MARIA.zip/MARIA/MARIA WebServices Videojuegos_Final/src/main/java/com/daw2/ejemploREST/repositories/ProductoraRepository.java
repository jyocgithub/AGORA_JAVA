package com.daw2.ejemploREST.repositories;

import com.daw2.ejemploREST.models.Productora;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ProductoraRepository extends JpaRepository<Productora, Long> {

}
