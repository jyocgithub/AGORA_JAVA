package com.daw2.ejemploREST.controllers;

import com.daw2.ejemploREST.forms.ProductoraForm;
import com.daw2.ejemploREST.models.Productora;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.daw2.ejemploREST.repositories.ProductoraRepository;
import javax.validation.Valid;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

@RestController
@RequestMapping(value = "/productoraJson")
public class ProductoraJsonController {

    @Autowired
    ProductoraRepository pr;

    @PostMapping(consumes = "application/json")
    public String crear(@Valid @RequestBody ProductoraForm pf,
			BindingResult bindingResult) {
        
        if (bindingResult.hasErrors()) {
            return "{\"Result\": \"ERROR\"}";
        }
        
        try {
            Productora p = new Productora();
            p.setNombre(pf.getNombre());
            p.setAnoFundacion(pf.getAnoFundacion());
            p.setPresidente(pf.getPresidente());
            pr.save(p);
            return "{\"Result\": \"OK\"}";
        } catch(Exception e) {
            // nada
        }
        return "{\"Result\": \"ERROR\"}";
    }
}
