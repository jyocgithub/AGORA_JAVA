package com.daw2.ejemploREST.repositories;

import com.daw2.ejemploREST.models.Videojuego;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

public interface VideojuegoRepository extends JpaRepository<Videojuego, Long> {
    @Query(value="SELECT v FROM Videojuego v LEFT JOIN FETCH v.roles r LEFT JOIN FETCH r.persona p", nativeQuery = false)
    public List<Videojuego> todos();
}
