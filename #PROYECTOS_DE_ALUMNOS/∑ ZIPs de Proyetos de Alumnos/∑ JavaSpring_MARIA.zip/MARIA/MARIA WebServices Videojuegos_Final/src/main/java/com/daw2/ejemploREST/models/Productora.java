package com.daw2.ejemploREST.models;

import com.fasterxml.jackson.annotation.JsonIgnore;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "productora")
public class Productora implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String nombre;

    @Column(name = "ano_fundacion")
    private Integer anoFundacion;

    private String presidente;

    /*Opcional, solo si quiero bidireccionalidad*/
    @OneToMany(mappedBy = "productora")
    @JsonIgnore
    private List<Videojuego> videojuegos = new ArrayList();/*Mejor inicializarlo, as al construir uno no ser null y nos evitamos problemas*/

    /**
     * @return the id
     */
    public Long getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(Long id) {
        this.id = id;
    }

    /**
     * @return the nombre
     */
    public String getNombre() {
        return nombre;
    }

    /**
     * @param nombre the nombre to set
     */
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    /**
     * @return the anoFundacion
     */
    public Integer getAnoFundacion() {
        return anoFundacion;
    }

    /**
     * @param anoFundacion the anoFundacion to set
     */
    public void setAnoFundacion(Integer anoFundacion) {
        this.anoFundacion = anoFundacion;
    }

    /**
     * @return the presidente
     */
    public String getPresidente() {
        return presidente;
    }

    /**
     * @param presidente the presidente to set
     */
    public void setPresidente(String presidente) {
        this.presidente = presidente;
    }

    /**
     * @return the videojuegos
     */
    public List<Videojuego> getVideojuegos() {
        return videojuegos;
    }

    /**
     * @param videojuegos the videojuegos to set
     */
    public void setVideojuegos(List<Videojuego> videojuegos) {
        this.videojuegos = videojuegos;
    }
}
