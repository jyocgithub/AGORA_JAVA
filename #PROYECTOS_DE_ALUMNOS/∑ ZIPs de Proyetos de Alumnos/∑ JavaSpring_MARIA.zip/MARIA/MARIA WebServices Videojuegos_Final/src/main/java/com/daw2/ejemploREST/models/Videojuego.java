/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.daw2.ejemploREST.models;

import com.fasterxml.jackson.annotation.JsonIgnore;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

/**
 *
 * @author alumno
 */
@Entity
public class Videojuego implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String titulo;

    private Integer ano;

    @OneToMany(mappedBy = "videojuego") /*Nombre de atributo de PParticipaEnV asociado*/
    private List<PParticipaEnV> roles=new ArrayList();/*Mejor inicializarlo, as al construir uno no ser null y nos evitamos problemas*/
    
    @ManyToOne
    @JoinColumn(name="id_productora", nullable=false)
    private Productora productora;

    /**
     * @return the id
     */
    public Long getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(Long id) {
        this.id = id;
    }

    /**
     * @return the titulo
     */
    public String getTitulo() {
        return titulo;
    }

    /**
     * @param titulo the titulo to set
     */
    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    /**
     * @return the ano
     */
    public Integer getAno() {
        return ano;
    }

    /**
     * @param ano the ano to set
     */
    public void setAno(Integer ano) {
        this.ano = ano;
    }

    /**
     * @return the roles
     */
    public List<PParticipaEnV> getRoles() {
        return roles;
    }

    /**
     * @param roles the roles to set
     */
    public void setRoles(List<PParticipaEnV> roles) {
        this.roles = roles;
    }

    /**
     * @return the productora
     */
    public Productora getProductora() {
        return productora;
    }

    /**
     * @param productora the productora to set
     */
    public void setProductora(Productora productora) {
        this.productora = productora;
    }

}
