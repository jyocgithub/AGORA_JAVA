/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.daw2.ejemploREST.models;

import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;
import java.io.Serializable;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.MapsId;
import javax.persistence.Table;

/**
 *
 * @author alumno
 */
@Entity
@Table(name="p_PARTICIPA_EN_v")
public class PParticipaEnV implements Serializable {

    @EmbeddedId
    private VideojuegoPersonaRolKey id=new VideojuegoPersonaRolKey();

    @ManyToOne
    @MapsId("idPersona") /*Ponemos el atributo asociado del EmbeddedId*/
    @JoinColumn(name = "id_persona")
    private Persona persona;

    @ManyToOne
    @MapsId("idVideojuego") /*Ponemos el atributo asociado del EmbeddedId*/
    @JoinColumn(name = "id_videojuego")
    private Videojuego videojuego;

    private String rol;

        /**
     * @return the id
     */
    public VideojuegoPersonaRolKey getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(VideojuegoPersonaRolKey id) {
        this.id = id;
    }

    /**
     * @return the persona
     */
    public Persona getPersona() {
        return persona;
    }

    /**
     * @param persona the persona to set
     */
    public void setPersona(Persona persona) {
        this.persona = persona;
    }

    /**
     * @return the videojuego
     */
    public Videojuego getVideojuego() {
        return videojuego;
    }

    /**
     * @param videojuego the videojuego to set
     */
    public void setVideojuego(Videojuego videojuego) {
        this.videojuego = videojuego;
    }

    /**
     * @return the rol
     */
    public String getRol() {
        return rol;
    }

    /**
     * @param rol the rol to set
     */
    public void setRol(String rol) {
        this.rol = rol;
    }
}
