/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.daw2.ejemploREST.controllers;

import com.daw2.ejemploREST.models.PParticipaEnV;
import com.daw2.ejemploREST.models.Videojuego;
import com.daw2.ejemploREST.objetosJSON.PersonaJSON;
import com.daw2.ejemploREST.objetosJSON.VideojuegoJSON;
import com.daw2.ejemploREST.repositories.VideojuegoRepository;
import java.util.ArrayList;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 *
 * @author truser
 */
@RestController
@RequestMapping(value = "/videojuego")
public class VideojuegoController {

    @Autowired
    VideojuegoRepository vr;

    @GetMapping("/todos")
    public List<VideojuegoJSON> todos() {
        ArrayList<VideojuegoJSON> salida = new ArrayList();
        List<Videojuego> entrada = vr.todos();
        VideojuegoJSON v;
        PersonaJSON pj;
        List<PParticipaEnV> entradaP;
        int i=0;
        
        for(; i<entrada.size(); i++) {
            v=new VideojuegoJSON();
            salida.add(v);
            v.setId(entrada.get(i).getId());
            v.setTitulo(entrada.get(i).getTitulo());
            v.setAno(entrada.get(i).getAno());
            
            entradaP=entrada.get(i).getRoles();
            int j=0;
            v.setPersonas(new ArrayList());
            for(; j<entradaP.size(); j++) {
                pj=new PersonaJSON();
                PParticipaEnV pv = entradaP.get(j);
                pj.setRol(pv.getRol());
                pj.setApellido1(pv.getPersona().getApellido1());
                pj.setApellido2(pv.getPersona().getApellido2());
                pj.setFechaNac(pv.getPersona().getFechaNac());
                pj.setNombre(pv.getPersona().getNombre());

                v.getPersonas().add(pj);
            }
        }
        
        return salida;
    }
}
