package config;

import java.util.Properties;
import javax.sql.DataSource;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.dao.annotation.PersistenceExceptionTranslationPostProcessor;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.JpaVendorAdapter;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.orm.jpa.vendor.HibernateJpaVendorAdapter;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;


@Configuration 
@EnableJpaRepositories("repositories") //TODO Poner aqu� paquete donde est�n los repositories
@EnableTransactionManagement
public class AppConfig {

  
    @Bean
    public LocalContainerEntityManagerFactoryBean entityManagerFactory() {
        System.out.println("####################### Entr� en " + " entityManagerFactory ##########################");
        LocalContainerEntityManagerFactoryBean em
                = new LocalContainerEntityManagerFactoryBean();
        em.setDataSource(dataSource());
        
        //TODO Aqu� sustituir por paquete donde residen todas las clases entity
        em.setPackagesToScan(new String[]{"models"});

        JpaVendorAdapter vendorAdapter = new HibernateJpaVendorAdapter();
        
        em.setJpaVendorAdapter(vendorAdapter);
        em.setJpaProperties(additionalProperties());

        return em;
    }

    @Bean
    public DataSource dataSource() {
        System.out.println("####################### Entr� en " + " dataSource ##########################");
        DriverManagerDataSource dataSource = new DriverManagerDataSource();
        dataSource.setDriverClassName("org.mariadb.jdbc.Driver");
        
        //TODO cambiar aqu� los datos de conexi�n con MariaDB
        dataSource.setUrl("jdbc:mysql://localhost:3306/vjcompleta3");
        dataSource.setUsername("vjcompletauser");
        dataSource.setPassword("1234");
        return dataSource;
    }

    @Bean
    public PlatformTransactionManager transactionManager() {
        System.out.println("####################### Entr� en " + " transactionManager ##########################");
        JpaTransactionManager transactionManager = new JpaTransactionManager();
        transactionManager.setEntityManagerFactory(entityManagerFactory().getObject());

        return transactionManager;
    }

    @Bean
    public PersistenceExceptionTranslationPostProcessor exceptionTranslation() {
        System.out.println("####################### Entr� en " + " PersistenceExceptionTranslationPostProcessor ##########################");
        return new PersistenceExceptionTranslationPostProcessor();
    }

    Properties additionalProperties() {
        Properties properties = new Properties();
        
        //TODO poner aqu� las propiedades de hibernate que a uno le interesen
        properties.setProperty("hibernate.hbm2ddl.auto", "validate");
        properties.setProperty("hibernate.dialect", "org.hibernate.dialect.MariaDBDialect");
        properties.setProperty("hibernate.show_sql", "true");
        properties.setProperty("hibernate.format_sql", "true");
        return properties;
    }
	
}
