package forms;

public class ProductoraForm {

    private String id;
    
    private String nombre;

    private String anoFundacion;

    private String presidente;

    /**
     * @return the nombre
     */
    public String getNombre() {
        return nombre;
    }

    /**
     * @param nombre the nombre to set
     */
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    /**
     * @return the anoFundacion
     */
    public String getAnoFundacion() {
        return anoFundacion;
    }

    /**
     * @param anoFundacion the anoFundacion to set
     */
    public void setAnoFundacion(String anoFundacion) {
        this.anoFundacion = anoFundacion;
    }

    /**
     * @return the presidente
     */
    public String getPresidente() {
        return presidente;
    }

    /**
     * @param presidente the presidente to set
     */
    public void setPresidente(String presidente) {
        this.presidente = presidente;
    }

    /**
     * @return the id
     */
    public String getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(String id) {
        this.id = id;
    }
}
