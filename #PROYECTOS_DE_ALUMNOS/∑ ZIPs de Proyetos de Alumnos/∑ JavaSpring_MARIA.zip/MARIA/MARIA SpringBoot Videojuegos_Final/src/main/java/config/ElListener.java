/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package config;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

/**
 *
 * @author truser
 */
public class ElListener implements ServletContextListener {

    @Override
    public void contextInitialized(ServletContextEvent sce) {
        System.out.println("Ejecutando m�todo ElListener.contextInitialized");
        AnnotationConfigApplicationContext ctx = new AnnotationConfigApplicationContext();
        ApplicationContextStatic.ctx=ctx;
        ctx.register(AppConfig.class);
        ctx.refresh();
    }
    
    @Override
    public void contextDestroyed(ServletContextEvent sce) {
         ApplicationContextStatic.ctx.close();
    }
}
