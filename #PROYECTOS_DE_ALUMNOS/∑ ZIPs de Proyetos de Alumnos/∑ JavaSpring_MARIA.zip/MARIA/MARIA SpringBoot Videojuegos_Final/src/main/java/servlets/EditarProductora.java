/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package servlets;

import config.ApplicationContextStatic;
import forms.ProductoraForm;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Optional;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import models.Productora;
import repositories.ProductoraRepository;

/**
 *
 * @author alumno
 */
@WebServlet(name = "EditarProductora", urlPatterns = {"/productora/editar"})
public class EditarProductora extends HttpServlet {
    ProductoraRepository prodr=ApplicationContextStatic.ctx.getBean(ProductoraRepository.class);
    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String id=request.getParameter("id");
        Long idL=null;
        ProductoraForm pf = new ProductoraForm();
        
        try {
            idL=Long.parseLong(id);
        } catch(NumberFormatException e) {
            //nada
        }
        if(idL!=null) {
            Optional<Productora> op = prodr.findById(idL);
            if(op.isPresent()) {
                Productora p = op.get();
                pf.setId(p.getId().toString());
                pf.setNombre(p.getNombre());
                pf.setAnoFundacion(p.getAnoFundacion().toString());
                pf.setPresidente(p.getPresidente());
            } else {
                //TODO ver que hacemos aqu�
            }
        }
        
        request.setAttribute("productoraForm", pf);
        request.getServletContext().
                getRequestDispatcher("/WEB-INF/jsp/productoraformulario.jsp").forward(request, response);   
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        ProductoraForm pf = new ProductoraForm();
        pf.setId(request.getParameter("id"));
        pf.setNombre(request.getParameter("nombre").trim());
        pf.setAnoFundacion(request.getParameter("ano").trim());
        pf.setPresidente(request.getParameter("presidente").trim());
        System.out.println( pf.getNombre());
        
        ArrayList errores = new ArrayList();
        
        if(pf.getNombre().length()<=0) {
            errores.add("El nombre es obligatorio");
        }
        
        Integer anoI = null;
        if(pf.getAnoFundacion().length()>0) {
            try {
                anoI=Integer.parseInt(pf.getAnoFundacion().trim());
            } catch(NumberFormatException e) {
                //nada
            }
            if(anoI==null) {
                errores.add("El a�o debe ser un n�mero entero");
            }
        }
        
        if(pf.getPresidente().length()<=0) {
            pf.setPresidente(null);
        }
             
        if(errores.size()<=0) {

            
            //Todo ha ido bien, guardo en BD la productora
            Productora p = new Productora();
            
            try {
                p.setId(Long.parseLong(pf.getId()));
            } catch(NumberFormatException e) {
                //nada
            }
            
            p.setNombre(pf.getNombre());
            p.setAnoFundacion(anoI);
            p.setPresidente(pf.getPresidente());
            prodr.save(p);
            
            //Hacemos forward al formulario otra vez, para que si quiere
            // el usuario, pueda instertar otra productora r�pidamente
            request.setAttribute("mensaje", "Productora guardada con id " + p.getId());
            request.getServletContext().
                getRequestDispatcher("/WEB-INF/jsp/productoraformulario.jsp")
                    .forward(request, response);
        } else {
            /*Si ha habido errores de validaci�n, se pasan al JSP para mostrarlos*/
            request.setAttribute("errores", errores);
            request.setAttribute("productoraForm", pf);
            request.getServletContext().
                getRequestDispatcher("/WEB-INF/jsp/productoraformulario.jsp")
                    .forward(request, response);
        }
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
