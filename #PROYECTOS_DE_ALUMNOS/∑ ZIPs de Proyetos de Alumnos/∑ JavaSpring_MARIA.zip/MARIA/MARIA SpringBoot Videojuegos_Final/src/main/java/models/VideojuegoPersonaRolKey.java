/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package models;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Embeddable;

@Embeddable
public class VideojuegoPersonaRolKey implements Serializable {

    @Column(name = "id_persona")
    private Long idPersona;

    @Column(name = "id_videojuego")
    private Long idVideojuego;

    /**
     * @return the idPersona
     */
    public Long getIdPersona() {
        return idPersona;
    }

    /**
     * @param idPersona the idPersona to set
     */
    public void setIdPersona(Long idPersona) {
        this.idPersona = idPersona;
    }

    /**
     * @return the idVideojuego
     */
    public Long getIdVideojuego() {
        return idVideojuego;
    }

    /**
     * @param idVideojuego the idVideojuego to set
     */
    public void setIdVideojuego(Long idVideojuego) {
        this.idVideojuego = idVideojuego;
    }
}
