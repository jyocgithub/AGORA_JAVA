/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package servlets;

import java.io.IOException;
import java.io.PrintWriter;
import config.ApplicationContextStatic;
import models.Videojuego;
import repositories.VideojuegoRepository;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import models.PParticipaEnV;
import models.Persona;
import models.Productora;
import repositories.PParticipaEnVRepository;
import repositories.PersonaRepository;
import repositories.ProductoraRepository;

/**
 *
 * @author truser
 */
@WebServlet(name = "Prueba", urlPatterns = {"/probar"})
public class Prueba extends HttpServlet {
    //TODO Sustituir por vuestra clase XXXXXXRepository
    VideojuegoRepository vjr=ApplicationContextStatic.ctx.getBean(VideojuegoRepository.class);
    PersonaRepository pr=ApplicationContextStatic.ctx.getBean(PersonaRepository.class);
    PParticipaEnVRepository pvr=ApplicationContextStatic.ctx.getBean(PParticipaEnVRepository.class);
    ProductoraRepository prodr=ApplicationContextStatic.ctx.getBean(ProductoraRepository.class);
    
    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        Productora prod=new Productora();//creo productora
        prod.setNombre("Productora1");
        prodr.save(prod);//lo inserto

        Videojuego v=new Videojuego();//creo un videojuego
        v.setTitulo("Videojuego1");
        v.setProductora(prod);
        vjr.save(v);//lo inserto
        
        Persona p=new Persona();//creo una persona
        p.setNombre("Ram�n");
        p.setApellido1("S�nchez");
        pr.save(p);//la inserto

        v=new Videojuego();//creo otro videojuego
        v.setTitulo("Videojuego2");
        v.setProductora(prod);
        vjr.save(v);//lo inserto      

        p=new Persona();//creo otra persona
        p.setNombre("Blanca");
        p.setApellido1("Fern�ndez");
        pr.save(p);//la inserto

        PParticipaEnV pv = new PParticipaEnV();//creo relacion
        pv.setVideojuego(v);//asocio con Videojuego2
        pv.setPersona(p);//asocio con Blanca
        pv.setRol("Programador");
        pvr.save(pv);//la inserto
        
       
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet Prueba</title>");            
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Despu�s de la prueba</h1>");
            out.println("</body>");
            out.println("</html>");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
