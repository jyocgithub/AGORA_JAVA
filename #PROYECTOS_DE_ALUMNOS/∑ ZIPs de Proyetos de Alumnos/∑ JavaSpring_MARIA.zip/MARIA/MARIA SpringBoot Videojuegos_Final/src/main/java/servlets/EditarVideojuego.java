/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package servlets;

import config.ApplicationContextStatic;
import forms.VideojuegoForm;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Optional;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import models.Videojuego;
import org.springframework.data.domain.Sort;
import repositories.ProductoraRepository;
import repositories.VideojuegoRepository;

/**
 *
 * @author alumno
 */
@WebServlet(name = "EditarVideojuego", urlPatterns = {"/videojuego/editar"})
public class EditarVideojuego extends HttpServlet {

    VideojuegoRepository vjr = ApplicationContextStatic.ctx.getBean(VideojuegoRepository.class);
    ProductoraRepository prr = ApplicationContextStatic.ctx.getBean(ProductoraRepository.class);

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String id = request.getParameter("id");
        Long idL = null;
        VideojuegoForm vf = new VideojuegoForm();
        
        request.setAttribute("productoras", prr.findAll(Sort.by("nombre").ascending()));

        try {
            idL = Long.parseLong(id);
        } catch (NumberFormatException e) {
            //nada
        }
        if (idL != null) {
            Optional<Videojuego> op = vjr.findById(idL);
            if (op.isPresent()) {
                Videojuego v = op.get();
                vf.setId(v.getId().toString());
                vf.setTitulo(v.getTitulo());
                vf.setAno(v.getAno().toString());
                vf.setProductora(v.getProductora().getId().toString());
            } else {
                //TODO ver que hacemos aqu�
            }
        }

        request.setAttribute("videojuegoForm", vf);
        request.getServletContext().
                getRequestDispatcher("/WEB-INF/jsp/videojuegoformulario.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        VideojuegoForm vf = new VideojuegoForm();
        vf.setId(request.getParameter("id"));
        vf.setTitulo(request.getParameter("titulo").trim());
        vf.setAno(request.getParameter("ano").trim());
        vf.setProductora(request.getParameter("productora").trim());

        ArrayList errores = validarVideojuego(vf);
        request.setAttribute("productoras", prr.findAll(Sort.by("nombre").ascending()));

        if (errores.size() <= 0) {

            try {
                //Todo ha ido bien, guardo en BD la productora
                Videojuego v = new Videojuego();

                try {
                    v.setId(Long.parseLong(vf.getId()));
                } catch (NumberFormatException e) {
                    //nada
                }

                v.setTitulo(vf.getTitulo());
                Integer anoI = null;
                try {
                    anoI = Integer.parseInt(vf.getAno().trim());
                } catch (NumberFormatException e) {
                    //nada
                }

                Long prodId = null;
                try {
                    prodId = Long.parseLong(vf.getProductora().trim());
                } catch (NumberFormatException e) {
                    //nada
                }
                v.setAno(anoI);
                v.setProductora(prr.getOne(prodId));
                vjr.save(v);

                //Hacemos forward al formulario otra vez, para que si quiere
                // el usuario, pueda instertar otro videojuego r�pidamente
                request.setAttribute("mensaje", "Videojuego guardado con id " + v.getId());
                request.getServletContext().
                        getRequestDispatcher("/WEB-INF/jsp/videojuegoformulario.jsp")
                        .forward(request, response);
            } catch (Exception e) {
                //Si algo falla, redirigimos a misma pantalla pero con este mensaje
                //de error
                request.setAttribute("mensaje", "Error. No se pudo guardar");
                request.getServletContext().
                        getRequestDispatcher("/WEB-INF/jsp/videojuegoformulario.jsp")
                        .forward(request, response);
            }
        } else {
            /*Si ha habido errores de validaci�n, se pasan al JSP para mostrarlos*/
            request.setAttribute("errores", errores);
            request.setAttribute("videojuegoForm", vf);
            request.getServletContext().
                    getRequestDispatcher("/WEB-INF/jsp/videojuegoformulario.jsp")
                    .forward(request, response);
        }
    }

    /*Queda m�s limpio llevar las validaciones a un m�todo aparte*/
    private ArrayList validarVideojuego(VideojuegoForm vf) {
        ArrayList errores = new ArrayList();

        if (vf.getTitulo().length() <= 0) {
            errores.add("El t�tulo es obligatorio");
        }

        Integer anoI = null;
        if (vf.getAno().length() > 0) {
            try {
                anoI = Integer.parseInt(vf.getAno().trim());
            } catch (NumberFormatException e) {
                //nada
            }
            if (anoI == null) {
                errores.add("El a�o debe ser un n�mero entero");
            }
        }
        return errores;
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
