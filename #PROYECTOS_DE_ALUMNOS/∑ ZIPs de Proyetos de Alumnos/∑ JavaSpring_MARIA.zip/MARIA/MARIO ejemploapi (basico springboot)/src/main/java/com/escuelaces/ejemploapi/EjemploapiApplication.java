package com.escuelaces.ejemploapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EjemploapiApplication {

    public static void main(String[] args) {
        SpringApplication.run(EjemploapiApplication.class, args);
    }

}
