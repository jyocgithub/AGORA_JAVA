package com.escuelaces.ejemploapi.models;

public class ProductoModel {
	private String nombre;
	private double precio;
	//IMPORTANTE: crear getters y setters
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public double getPrecio() {
		return precio;
	}
	public void setPrecio(double precio) {
		this.precio = precio;
	}

	public ProductoModel(String nombre, double precio) {
		this.nombre = nombre;
		this.precio = precio;
	}
}
