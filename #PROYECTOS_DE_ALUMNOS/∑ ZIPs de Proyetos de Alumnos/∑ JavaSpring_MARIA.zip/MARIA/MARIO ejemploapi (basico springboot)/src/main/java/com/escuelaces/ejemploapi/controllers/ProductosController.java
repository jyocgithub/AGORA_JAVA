package com.escuelaces.ejemploapi.controllers;

import java.util.ArrayList;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.escuelaces.ejemploapi.models.ProductoModel;

@RestController
public class ProductosController {
	ArrayList<ProductoModel> productos = new ArrayList();


	public ProductosController() {
		productos.add(new ProductoModel("Lapiz" ,123));
		productos.add(new ProductoModel("Goma" ,33));
		productos.add(new ProductoModel("Boli" ,432));
	}

	@GetMapping(path="/producto")
	public ArrayList<ProductoModel> getProductos() {

		return productos;
	}
	
	@GetMapping(path="/producto/{id}")
	public ProductoModel getProducto(@PathVariable(name="id") int id) {
		return productos.get(id);
	}
	
	@PostMapping(path="/producto")
	public void postProducto(@RequestBody ProductoModel productoM) {
		productos.add(productoM);
	}
}