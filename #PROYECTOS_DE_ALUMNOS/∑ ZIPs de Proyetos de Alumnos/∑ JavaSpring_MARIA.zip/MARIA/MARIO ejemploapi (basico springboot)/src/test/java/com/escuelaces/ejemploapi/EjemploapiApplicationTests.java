package com.escuelaces.ejemploapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EjemploapiApplicationTests {

	@Test
	void contextLoads() {
	}

}
