package com.example.biblioteca.controllers;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.biblioteca.errors.NotFoundException;
import com.example.biblioteca.models.LibroModel;
import com.example.biblioteca.services.LibroService;

@RestController
public class LibroController {
	@Autowired
	private LibroService libroService;

	/*
	 * @GetMapping(path="/libro") public ArrayList<LibroModel> getLibros() { return
	 * libroService.getLibros(); }
	 */

	@GetMapping(path = "/libro")
	public List<LibroModel> getLibros( @RequestParam(name = "titulo", required = false) String titulo, 
			                           @RequestParam(name = "paginas", required = false) Integer paginas) {
		if (titulo == null || titulo.isEmpty() || paginas == null) {
			return libroService.getLibros();
		} else {
			return libroService.getLibrosTituloPaginas(titulo, paginas);
		}
	}

	@GetMapping(path = "libro/{isbn}")
	public LibroModel getLibro(@PathVariable(name = "isbn") String isbn) {
		Optional<LibroModel> result = libroService.getLibro(isbn);

		if (result.isPresent()) {
			return result.get();
		}
		throw new NotFoundException();
	}

	@GetMapping(path = "/libro/titulo/{titulo}")
	public List<LibroModel> getLibrosTitulo(@PathVariable(name = "titulo") String titulo) {
		return libroService.getLibrosTitulo(titulo);
	}

	@PostMapping(path = "/libro")
	public void posLibro(@RequestBody LibroModel libroModel) {
		// Falta validar datos
		libroService.addLibro(libroModel);
	}

	@DeleteMapping(path = "/libro/{isbn}")
	public LibroModel deleteLibro(@PathVariable(name = "isbn") String isbn) {
		Optional<LibroModel> result = libroService.deleteLibro(isbn);

		if (result.isPresent()) {
			return result.get();
		}
		throw new NotFoundException();
	}
}
