package com.example.biblioteca.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.biblioteca.entities.Libro;

@Repository                     //Tabla a la que me refiero  , //Tipo de dato del id de la identidad
public interface LibroRepository extends JpaRepository<Libro, String> {
	// todos los libros con un titulo  concreto
	public List<Libro> findByTitulo(String titulo);
	// todos los libros con un titulo  concreto y que tengan mas de un nº de paginas
	//selectisbn, titutlo, paginas, secion from libro where titutlo =? and paginas=?
	public List<Libro> findByTituloAndPaginasGreaterThan(String titulo, int paginas);
	
}
