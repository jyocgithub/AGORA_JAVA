package com.example.biblioteca.entities;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonManagedReference;

@Entity
@Table(name="seccion")
public class Seccion {
	@Id
	@GeneratedValue
	@Column(name="numero")
	private int numero;
	
	@Column(name="nombre", length = 60)
	private String nombre;
	
	//Una seccion tiene varios libros:
	@OneToMany(mappedBy= "seccion")
	@JsonManagedReference
	//@JsonIgnoreProperties({"secciones","autores"}) uno u otro
	private List<Libro> libros;

	public int getNumero() {
		return numero;
	}

	public void setNumero(int numero) {
		this.numero = numero;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	

}
