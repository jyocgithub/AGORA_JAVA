package com.example.biblioteca.entities;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonBackReference;

@Entity
@Table(name="carnet")
public class Carnet {
	@Id
	@GeneratedValue
	@Column(name="num_carnet")
	private long num;
	
	@Column(name="fecha_alta")
	private Date fechaAlta;
	
	@Column(name="biblioteca", length = 60)
	private String biblioteca;
	
	@OneToOne
	@JsonBackReference
	//@JsonIgnoreProperties({"carnet"})
	private Usuario usuario;

	public long getNum() {
		return num;
	}

	public void setNum(long num) {
		this.num = num;
	}

	public Date getFechaAlta() {
		return fechaAlta;
	}

	public void setFechaAlta(Date fechaAlta) {
		this.fechaAlta = fechaAlta;
	}

	public String getBiblioteca() {
		return biblioteca;
	}

	public void setBiblioteca(String biblioteca) {
		this.biblioteca = biblioteca;
	}
	
	
}