package com.example.biblioteca.entities;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@Table(name="autor")
public class Autor {
	
	
	@Id
	@GeneratedValue
	@Column(name="id")
	private long id;
	
	@Column(name="nombre", length = 100)
	private String nombre;
	
	@Column(name="apellidos",length = 100)
	private String apellidos;
	
	@ManyToMany(mappedBy = "autores")
	@JsonIgnoreProperties({"autores"})
	private List<Libro> libros; //Lista porque un autor tiene mas de un libro
	
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public String getApellidos() {
		return apellidos;
	}
	public void setApellidos(String apellidos) {
		this.apellidos = apellidos;
	}
	
}
