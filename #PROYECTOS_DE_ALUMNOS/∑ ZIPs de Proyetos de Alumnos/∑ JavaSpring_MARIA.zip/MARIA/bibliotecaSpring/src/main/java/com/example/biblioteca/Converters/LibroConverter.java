package com.example.biblioteca.Converters;

import org.springframework.stereotype.Component;

import com.example.biblioteca.entities.Libro;
import com.example.biblioteca.entities.Seccion;
import com.example.biblioteca.models.LibroModel;

@Component
public class LibroConverter {
	
	public LibroModel entityToModel(Libro libro) 
	{
		LibroModel libroModel = new LibroModel();
		libroModel.setIsbn(libro.getIsbn());
		libroModel.setTitulo(libro.getTitulo());
		libroModel.setPaginas(libro.getPaginas());
		return libroModel;
	}
	
	public Libro modelToEntity(LibroModel libroModel) 
	{
		Libro libro = new Libro();
		libro.setIsbn(libroModel.getIsbn());
		libro.setTitulo(libroModel.getTitulo());
		libro.setPaginas(libroModel.getPaginas());
		Seccion seccion = new Seccion();
		seccion.setNumero(libroModel.getSeccion());
		libro.setSeccion(seccion);
		return libro;
	}

}
