package com.example.biblioteca.controllers;

import org.springframework.web.bind.annotation.RestController;

@RestController
public class UsuarioController 
{
	
}
