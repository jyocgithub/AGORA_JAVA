package com.example.biblioteca.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonManagedReference;

@Entity
@Table(name="usuario")
public class Usuario {
	@Id
	@GeneratedValue
	@Column(name="id")
	private long id;
	
	@Column(name="nif", unique=true, length = 9)
	private String nif;
	
	@Column(name="nombre", length = 50)
	private String nombre;
	
	@Column(name="apellidos", length = 100)
	private String apellidos;
	
	@Column(name="telefono", length = 12)
	private String telefono;
	
	@Column(name="email", length = 60)
	private String email;
	
	@OneToOne(mappedBy = "usuario")
	@JsonManagedReference
	//@JsonIgnoreProperties({"usuario"})
	private Carnet carnet;

	
	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getNif() {
		return nif;
	}

	public void setNif(String nif) {
		this.nif = nif;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getApellidos() {
		return apellidos;
	}

	public void setApellidos(String apellidos) {
		this.apellidos = apellidos;
	}

	public String getTelefono() {
		return telefono;
	}

	public void setTelefono(String telefono) {
		this.telefono = telefono;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}
	

}
