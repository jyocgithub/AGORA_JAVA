package com.example.biblioteca.services;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.biblioteca.Converters.LibroConverter;
import com.example.biblioteca.entities.Libro;
import com.example.biblioteca.models.LibroModel;
import com.example.biblioteca.repositories.LibroRepository;

@Service
public class LibroService {
	@Autowired
	private LibroRepository libroRepository;
	
	@Autowired
	private LibroConverter libroConverter;
	
	public List<LibroModel> getLibros()
	{
		List<Libro> libros = libroRepository.findAll();
		List<LibroModel> librosModel = new ArrayList();
		for(Libro libro: libros ) 
		{
			LibroModel libroModel = libroConverter.entityToModel(libro);
			librosModel.add(libroModel);
			/*librosModel.add(libroConverter.entityToModel(libro));*/
		}
		return librosModel;
	}
	public Optional<LibroModel> getLibro(String isbn) 
	{
		Optional<LibroModel>resultLm = Optional.empty();
		Optional<Libro>result = libroRepository.findById(isbn);
		if(result.isPresent()) 
			//el isbn existe
		{
			Libro libro = result.get();
			LibroModel libroModel = libroConverter.entityToModel(libro);
			resultLm = Optional.of(libroModel);
		}
		return resultLm;
	}
	
	public List<LibroModel> getLibrosTitulo(String titulo) 
	{
		List<Libro> libros = libroRepository.findByTitulo(titulo);
		List<LibroModel> librosModel = new ArrayList();
		for(Libro libro : libros) 
		{
			librosModel.add(libroConverter.entityToModel(libro));
		}
		return librosModel;
	}
	
	public List<LibroModel> getLibrosTituloPaginas(String titulo, int paginas) 
	{
		List<Libro> libros = libroRepository.findByTituloAndPaginasGreaterThan(titulo, paginas);
		List<LibroModel> librosModel = new ArrayList();
		for(Libro libro : libros) 
		{
			librosModel.add(libroConverter.entityToModel(libro));
		}
		return librosModel;
	}
	
	public void addLibro(LibroModel libroModel)
	{
		Libro libro = libroConverter.modelToEntity(libroModel);
		libroRepository.save(libro); //Insercion
	}
	
	public Optional<LibroModel> deleteLibro(String isbn) 
	{
		Optional<LibroModel>resultLm = Optional.empty();
		Optional<Libro>result = libroRepository.findById(isbn);
		if(result.isPresent()) 
		{
			Libro libro = result.get();
			LibroModel libroModel = libroConverter.entityToModel(libro);
			resultLm = Optional.of(libroModel);
			libroRepository.delete(libro);
		}
		return resultLm;
	}

}
