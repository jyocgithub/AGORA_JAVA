package com.example.biblioteca.entities;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@Table(name="libro")
public class Libro {
	@Id
	@Column(name="isbn", length = 13)
	private String isbn;
	
	@Column(name="titulo", length = 60)
	private String titulo;
	
	@Column(name="paginas")
	private int paginas;
	
	//Un libro solo esta en una seccion
	@ManyToOne
	@JsonBackReference
	private Seccion seccion;
	
	@ManyToMany
	@JsonIgnoreProperties({"libros"})
	private List<Autor> autores; //List porque un libro puede tener mas de un autor

	
	public String getIsbn() {
		return isbn;
	}

	public void setIsbn(String isbn) {
		this.isbn = isbn;
	}

	public String getTitulo() {
		return titulo;
	}

	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}

	public int getPaginas() {
		return paginas;
	}

	public void setPaginas(int paginas) {
		this.paginas = paginas;
	}

	public Seccion getSeccion() {
		return seccion;
	}

	public void setSeccion(Seccion seccion) {
		this.seccion = seccion;
	}

	public List<Autor> getAutores() {
		return autores;
	}

	public void setAutores(List<Autor> autores) {
		this.autores = autores;
	}
	
	
}
