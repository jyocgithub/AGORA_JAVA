package com.example.ligabaloncesto.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.ligabaloncesto.converters.JugadorConverter;
import com.example.ligabaloncesto.entities.Jugador;
import com.example.ligabaloncesto.models.JugadorModel;
import com.example.ligabaloncesto.repositories.JugadorRepository;

@Service
public class JugadorService {
	@Autowired
	private JugadorRepository jugadorRepository;
	
	@Autowired
	private JugadorConverter jugadorConverter;
	
	public void insertJugador(JugadorModel jugadormodel) {
		Jugador jugador = jugadorConverter.modelToEntity(jugadormodel);
		jugadorRepository.save(jugador);
	}
	
}
