package com.example.ligabaloncesto.converters;

import org.springframework.stereotype.Component;

import com.example.ligabaloncesto.entities.Equipo;
import com.example.ligabaloncesto.models.EquipoModel;

@Component
public class EquipoConverter {
	
	public Equipo modelToEntity (EquipoModel equipoModel) 
	{
		Equipo equipo = new Equipo();
		equipo.setGanados(equipoModel.getGanados());
		equipo.setPerdidos(equipoModel.getPerdidos());
		equipo.setNombre(equipoModel.getNombre());
		return equipo;
	}
	
	public EquipoModel entityToModel (Equipo equipo) {
		EquipoModel equipoModel = new EquipoModel();
		equipoModel.setGanados(equipo.getGanados());
		equipoModel.setPerdidos(equipo.getPerdidos());
		equipoModel.setNombre(equipo.getNombre());
		return equipoModel;
	}

}
