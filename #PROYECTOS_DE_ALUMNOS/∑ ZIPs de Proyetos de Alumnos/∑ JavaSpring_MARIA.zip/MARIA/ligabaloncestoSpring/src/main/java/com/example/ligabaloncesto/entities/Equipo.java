package com.example.ligabaloncesto.entities;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonBackReference;

@Entity
@Table(name = "equipo")
public class Equipo {
	@Id
	@GeneratedValue
	@Column(name = "id" )
	private long id;
	
	@Column(name = "nombre")
	private String nombre;
	
	@Column(name = "ganados")
	private int ganados;
	
	@Column(name = "perdidos")
	private int perdidos;
	
	@OneToMany(mappedBy= "equipo")
	@JsonBackReference
	private List<Jugador> jugadores;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public int getGanados() {
		return ganados;
	}

	public void setGanados(int ganados) {
		this.ganados = ganados;
	}

	public int getPerdidos() {
		return perdidos;
	}

	public void setPerdidos(int perdidos) {
		this.perdidos = perdidos;
	}

	public List<Jugador> getJugadores() {
		return jugadores;
	}

	public void setJugadores(List<Jugador> jugadores) {
		this.jugadores = jugadores;
	}
	
	
}
