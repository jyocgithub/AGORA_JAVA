package com.example.ligabaloncesto.converters;

import org.springframework.stereotype.Component;

import com.example.ligabaloncesto.entities.Equipo;
import com.example.ligabaloncesto.entities.Jugador;
import com.example.ligabaloncesto.models.JugadorModel;

@Component
public class JugadorConverter {

	public Jugador modelToEntity (JugadorModel jugadorModel) {
		Jugador jugador = new Jugador();
		jugador.setNombre(jugadorModel.getNombre());
		jugador.setNumero(jugadorModel.getNumero());
		jugador.setPosicion(jugadorModel.getPosicion());
		jugador.setPuntos(jugadorModel.getPuntos());
		Equipo equipo = new Equipo();
		equipo.setId(jugadorModel.getEquipo());
		jugador.setEquipo(equipo);
		return jugador;
	}
	
	public JugadorModel entityToModel (Jugador jugador) {
		JugadorModel jugadorModel = new JugadorModel();
		jugadorModel.setNombre(jugador.getNombre());
		jugadorModel.setNumero(jugador.getNumero());
		jugadorModel.setPosicion(jugador.getPosicion());
		jugadorModel.setPuntos(jugador.getPuntos());
		jugadorModel.setEquipo(jugador.getEquipo().getId());
		return jugadorModel;
	}
}
