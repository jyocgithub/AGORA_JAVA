package com.example.ligabaloncesto.controllers;

import javax.persistence.Column;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.ligabaloncesto.models.EquipoModel;
import com.example.ligabaloncesto.services.EquipoService;

@RestController
public class EquipoController {
	@Autowired
	private EquipoService equipoService;
	
	@PostMapping(path="/equipo")
	public void postEquipo (@RequestBody EquipoModel equipoModel) 
	{
		equipoService.insertEquipo(equipoModel);

	}


}
