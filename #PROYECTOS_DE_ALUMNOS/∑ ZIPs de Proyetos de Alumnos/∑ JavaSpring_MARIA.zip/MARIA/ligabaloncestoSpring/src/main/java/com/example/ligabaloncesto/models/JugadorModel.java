package com.example.ligabaloncesto.models;

public class JugadorModel {
	
	private String nombre;
	private int numero;
	private String posicion;
	private int puntos;
	private long equipo; //id del equipo
	
	
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public int getNumero() {
		return numero;
	}
	public void setNumero(int numero) {
		this.numero = numero;
	}
	public String getPosicion() {
		return posicion;
	}
	public void setPosicion(String posicion) {
		this.posicion = posicion;
	}
	public int getPuntos() {
		return puntos;
	}
	public void setPuntos(int puntos) {
		this.puntos = puntos;
	}
	public long getEquipo() {
		return equipo;
	}
	public void setEquipo(long equipo) {
		this.equipo = equipo;
	}
	
	
}
