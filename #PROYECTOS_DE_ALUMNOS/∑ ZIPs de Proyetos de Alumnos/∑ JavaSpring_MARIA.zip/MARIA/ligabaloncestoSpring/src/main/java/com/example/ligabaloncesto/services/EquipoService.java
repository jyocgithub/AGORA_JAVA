package com.example.ligabaloncesto.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.ligabaloncesto.converters.EquipoConverter;
import com.example.ligabaloncesto.entities.Equipo;
import com.example.ligabaloncesto.models.EquipoModel;
import com.example.ligabaloncesto.repositories.EquipoRepository;

@Service
public class EquipoService {
	@Autowired
	private EquipoRepository equipoRepository;
	
	@Autowired
	private EquipoConverter equipoConverter;
	
	public void insertEquipo(EquipoModel equipoModel) {
		Equipo equipo = equipoConverter.modelToEntity(equipoModel);
		equipoRepository.save(equipo);
		
	}
}
