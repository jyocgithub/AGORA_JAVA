package com.example.ligabaloncesto.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.ligabaloncesto.models.JugadorModel;
import com.example.ligabaloncesto.services.JugadorService;

@RestController
public class JugadorController {
	@Autowired
	private JugadorService jugadorService;
	
	@PostMapping(path="/jugador")
	public void postJugador (@RequestBody JugadorModel jugadorModel) 
	{
		jugadorService.insertJugador(jugadorModel);
	}
}
