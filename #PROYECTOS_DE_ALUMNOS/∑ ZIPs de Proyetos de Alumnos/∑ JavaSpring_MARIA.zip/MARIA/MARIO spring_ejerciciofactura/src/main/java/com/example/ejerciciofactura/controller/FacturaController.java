package com.example.ejerciciofactura.controller;

import java.util.ArrayList;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.ejerciciofactura.models.FacturaModel;

public class FacturaController {
	
	@RestController
	public class facturaController {
		ArrayList<FacturaModel> facturas = new ArrayList();
		private String numero;
	
		
		@GetMapping(path="/factura")
		public ArrayList<FacturaModel> getFactura() {
			return facturas;
		}
		
		@GetMapping(path="/factura/{numero}")
		public FacturaModel getNumero(@PathVariable(name="numero") String numero) {
			for(int i=0; i<facturas.size(); i++) 
			{
				FacturaModel facturaM = facturas.get(i);
				if(facturaM.getNumero()==numero) 
				{
					return facturaM;
				}
			}
			return null;
		}
		
		@GetMapping(path="/factura/{cliente}")
		public FacturaModel getCliente(@PathVariable(name="cliente") String cliente) {
			for(int i=0; i<facturas.size(); i++) 
			{
				FacturaModel facturaM = facturas.get(i);
				if(facturaM.getCliente()==cliente) 
				{
					return facturaM;
				}
			}
			return null;
		}
		
		@PostMapping(path="/factura")
		public void postFactura(@RequestBody FacturaModel facturaM) {
			this.numero++;
			facturaM.setNumero(this.numero);
			facturas.add(facturaM);
		}
		@PutMapping(path="/factrua/{numero}")
		public void putProducto(@RequestBody FacturaModel facturaM) {
			for(int i=0; i<facturas.size(); i++) {
				FacturaModel FacturaOld = facturas.get(i);
				if(FacturaOld.getNumero()==facturaM.getNumero()) {
					FacturaOld.setImporte(facturaM.getImporte());
					FacturaOld.setCliente(facturaM.getCliente());
					break;
				}
			}
		}
		//ELIMINACION
		@DeleteMapping(path="/producto/{numero}")
		public void deleteFactura(@PathVariable(name="numero") String numero) {
			for(int i=0; i<facturas.size(); i++) {
				FacturaModel facturaM = facturas.get(i);
				if(facturaM.getNumero()==numero) {
					facturas.remove(i);
					break;
				}
			}
		}
		

	}
		
	

}
