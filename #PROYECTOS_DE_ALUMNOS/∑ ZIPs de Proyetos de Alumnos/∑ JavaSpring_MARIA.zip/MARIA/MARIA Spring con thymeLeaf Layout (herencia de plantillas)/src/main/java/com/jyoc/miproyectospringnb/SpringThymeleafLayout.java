package com.jyoc.miproyectospringnb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringThymeleafLayout {

	public static void main(String[] args) {
		SpringApplication.run(SpringThymeleafLayout.class, args);
	}

}
