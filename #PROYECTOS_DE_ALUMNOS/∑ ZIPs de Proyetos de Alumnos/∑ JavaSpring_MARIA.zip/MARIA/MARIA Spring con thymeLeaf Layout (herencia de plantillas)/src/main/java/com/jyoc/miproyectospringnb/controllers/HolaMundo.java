package com.jyoc.miproyectospringnb.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;


@Controller  // sustituye al servlet tradicional
public class HolaMundo {
     
     
//     @RequestMapping("/hola")    // establece un mapeo de URL para este método
//     public String r_saludar(){
//          return "plantilla_holamundo";    // un return ejecuta algo asi como un formward de un servlet,
//                                 
//     }
//     @RequestMapping("/numeros")   
//     public String r_numeros(Model model){
//          model.addAttribute("unnumero", 12);
//          return "plantilla_numeros";  
//     }
     @RequestMapping("/base")    
     public String r_array(Model model){
          int[] unarray = {1,2,3,4,5};
          model.addAttribute("a_array", unarray);
          return "plantilla_array";    
                                 
     }
     
}
