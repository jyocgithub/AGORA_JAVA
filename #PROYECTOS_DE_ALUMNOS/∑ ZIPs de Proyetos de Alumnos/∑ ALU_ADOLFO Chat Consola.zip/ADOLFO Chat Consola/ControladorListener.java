package EjercicioFIN;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;

public class ControladorListener extends Thread{
	
	String nombre;
	public DataOutputStream escritor;
    public DataInputStream lector;
    public boolean fin = false;
    
	public ControladorListener(String nombre, DataOutputStream escritor, DataInputStream lector) {
		super();
		this.nombre = nombre;
		this.escritor = escritor;
		this.lector = lector;
	}
    
    public void run() {
    	
    	boolean error = true;
    	String mensajetemp = "";
    	
    	while (fin == false) {
			
    		while (error == true) {
				
    			try {
    				mensajetemp = lector.readUTF();
    				error = false;
    			} catch (IOException e) {
    				// TODO Auto-generated catch block
    				error = true;
    			}
				
			}
			
    		error=true;
    		
    		System.out.println(nombre + ": " + mensajetemp);
			
    		if (mensajetemp.contains("fin")) {
    			
    			System.out.println("Fin encontrado. Saliendo...");
    			fin = true;
				
			}
    		
		}
    	
    	
    }
    
}
