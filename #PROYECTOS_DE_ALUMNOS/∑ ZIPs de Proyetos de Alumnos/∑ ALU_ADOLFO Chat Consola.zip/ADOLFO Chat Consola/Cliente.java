package EjercicioFIN;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.util.Scanner;

public class Cliente{

	
	static final int PUERTO = 20001;
    static DataOutputStream escritor;
    static DataInputStream lector;
    
    static Socket manguera; 
    
	public static void main(String[] args) {

		try {
			manguera = new Socket("localhost", PUERTO);
	
		    escritor = new DataOutputStream(manguera.getOutputStream());	
            lector = new DataInputStream(manguera.getInputStream());  // Abrimos los canales de E/S
        
            comunicarse();
	
		} catch (IOException e) {
			e.printStackTrace();
		}finally {
			
			try {
				escritor.close();
				lector.close();
				manguera.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

	public static void comunicarse() throws IOException {
		
		Scanner sc = new Scanner(System.in);
		ControladorListener CC = new ControladorListener("Servidor", escritor, lector);
		CC.start();
		String mensaje= "";
		boolean fin = false;
		
		escritor.writeUTF("Mensaje de prueba de servidor");
		
		System.out.println("Cliente conectado");
		
		while (CC.fin == false || fin == false) {
			
			try {
				Thread.sleep(10);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			System.out.println("Introduzca un mensaje (Cliente) :");
			mensaje = sc.next();
			escritor.writeUTF(mensaje);
			
			if(mensaje.contains("fin")){
				
				System.out.println("Fin encontrado. Saliendo...");
				fin = true;
				
			}
			
		}
		
		
		
		
	}

}
