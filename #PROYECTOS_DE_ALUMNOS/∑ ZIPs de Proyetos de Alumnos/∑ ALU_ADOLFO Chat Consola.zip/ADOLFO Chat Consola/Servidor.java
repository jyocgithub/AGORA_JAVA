package EjercicioFIN;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Scanner;

public class Servidor{

	static final int PUERTO = 20001;
	
    static DataOutputStream escritor;
    static DataInputStream lector;
    static ServerSocket servidor ;
    static Socket manguera; 
    
	public static void main(String[] args) {
		
		try {
			servidor = new ServerSocket(PUERTO);
			System.out.println("Servidor arrancado y esperando a alguien...");
					
				manguera = servidor.accept(); //esperando a que alguien conecte
			
            lector = new DataInputStream(manguera.getInputStream());  // Abrimos los canales de E/S
            escritor = new DataOutputStream(manguera.getOutputStream());
    		
            comunicarse();

		} catch (IOException e) {
			e.printStackTrace();
		} finally {	
			try {
				escritor.close();
				lector.close();
				manguera.close();
				servidor.close();
			} catch (IOException e) {
				e.printStackTrace();
			}

		}
	}

	
	public static void comunicarse() throws IOException {
		
		Scanner sc = new Scanner(System.in);
		ControladorListener CC = new ControladorListener("Cliente", escritor, lector);
		CC.start();
		String mensaje= "";
		boolean fin = false;
		
		escritor.writeUTF("Mensaje de prueba de servidor");
		
		System.out.println("Servidor conectado");
		
		while (CC.fin == false || fin == false) {
			
			try {
				Thread.sleep(10);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			System.out.println("Introduzca un mensaje (Servidor) :");
			mensaje = sc.next();
			escritor.writeUTF(mensaje);
			
			if(mensaje.contains("fin")){
				
				System.out.println("Fin encontrado. Saliendo...");
				fin = true;
				
			}
			
		}
		

	}

}
