package EjerciciosJaviStrings1;

import java.util.Scanner;

public class EjercicioD1_D2 {
    // D1.Realizar un programa que lea el título y el autor de 10 libros,
    // las almacene en un array de Strings y después pida un título y
    // muestre el autor del mismo o No encontrado según proceda.
    // No se distinguirá entre mayúsculas y minúsculas en la comparación.

    public static void main(String[] args) {

        String[] autores = new String[10];
        String[] titulos = new String[10];

        Scanner entrada = new Scanner(System.in);
        for (int i = 0; i < autores.length; i++) {
            System.out.println("Escriba titulo:");
            titulos[i] = entrada.nextLine();
            System.out.println("Escriba autor:");
            autores[i] = entrada.nextLine();
        }

        System.out.println("Escriba titulo a buscar:");
        String tituloabuscar = entrada.nextLine();
        String autorencontrado = "";
        for (int i = 0; i < autores.length; i++) {
            if (tituloabuscar.equalsIgnoreCase(titulos[i])) {
                autorencontrado = autores[i];
            }
        }

        if (autorencontrado.equals("")) {
            System.out.println("No encontrado el libro");

        } else {
            System.out.println("Autor:" + autorencontrado);
        }



    }


    // D2.- Realizar un método ordenar que permita ordenar ,
    // libros por orden alfabético de autores, el array de libros
    // y si hay varios libros del mismo autor por el título de los mismos.
    // Después se mostrará el array ordenado (Autor- título)


    public void ordenarLibros(String[] autores, String[] libros) {

        String aux;
        // creo un nuevo array que contendra el nombre mas el titulo
        // asi si hay varios libros del mismo autor, los ordena a la vez
        String[] todo = new String[autores.length];
        for (int i = 0; i < autores.length; i++) {
            todo[i] = libros[i] + " -  " + autores[i];
        }

        // ordeno el nuevo array
        for (int i = 0; i < libros.length; i++) {
            for (int j = 0; j < libros.length - 1; j++) {
                // para comparar cadenas uso compareTo
                if (todo[j].compareTo(todo[j + 1]) > 1) {
                    aux = todo[j];
                    todo[j] = todo[j + 1];
                    todo[j + 1] = aux;
                }
            }
        }

        // imprimir resultado
        for (int i = 0; i < autores.length; i++) {
            System.out.println(todo[i]);
        }
    }

}

