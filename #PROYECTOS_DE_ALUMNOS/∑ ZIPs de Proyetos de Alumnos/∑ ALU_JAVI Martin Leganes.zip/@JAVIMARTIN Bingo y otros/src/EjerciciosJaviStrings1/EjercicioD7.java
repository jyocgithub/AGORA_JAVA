package EjerciciosJaviStrings1;

import java.util.Scanner;

//D7.-(Dif: 4) Método que devuelva el número de caracteres que hay entre la
// primera y última aparición de un carácter concreto en una cadena.
// "Hola Juan Antonio Ramsés"  entre la primera y última 'a'
// hay 15 caracteres (" Juan Antonio R")
public class EjercicioD7 {

    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        System.out.println("Escriba frase");
        String texto = entrada.nextLine();
        System.out.println("Escriba letra");
        String letra = entrada.nextLine();

        int res = calcularDistancia(texto, letra);
        System.out.println("suma de numeros de la frase:" + res);
    }

    public static int calcularDistancia(String cadena, String letra) {
        int res=0;
        int ini= cadena.indexOf(letra);
        int fin= cadena.lastIndexOf(letra);
        res = fin - ini;
        return res;
    }

}
