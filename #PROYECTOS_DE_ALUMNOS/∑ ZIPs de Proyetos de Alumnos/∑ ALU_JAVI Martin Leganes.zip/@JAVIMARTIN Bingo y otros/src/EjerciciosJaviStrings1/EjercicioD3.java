package EjerciciosJaviStrings1;

//D3.- (Dif:3) Realizar un método que reciba un parámetro de tipo
// String que será un DNI (con números y letra en la misma variable)
// y compruebe si es correcto.
// Buscar en internet el algoritmo que asigna la letra a un DNI para realizar el ejercicio.
// Consejo: Almacenar en un array la letra correspondiente a cada número.
public class EjercicioD3 {

    public static void main(String[] args) {
      String d1= "81127294S";   // este es valido
      String d2= "91127294S";   // este es invalido

        boolean vale = validarDbni(d1);
        if(vale==true){
            System.out.println(d1 +" es un dni valido");
        }else{
            System.out.println(d1 +" es un dni invalido");
        }

        boolean vale2 = validarDbni(d2);
        if(vale2==true){
            System.out.println(d2+" es un dni valido");
        }else{
            System.out.println(d2 +" es un dni invalido");
        }


    }

    public static boolean validarDbni(String dni){
        boolean valido;

        // Array con las letras posibles del dni en su posición
        char[] letraDni = {
                'T', 'R', 'W', 'A', 'G', 'M', 'Y', 'F', 'P', 'D',  'X',  'B', 'N', 'J', 'Z', 'S', 'Q', 'V', 'H', 'L', 'C', 'K', 'E'
        };

        // compruebo su longitud que sea 9
        if (dni.length() != 9){
            return false;
        }

        // paso a int el string donde tengo el numero del dni
        String num= dni.substring(0,8);
        int numEnInt = Integer.parseInt(num);

        // calculo la posición de la letra en el array que corresponde a este dni
        int factor = numEnInt % 23;

        // verifico que la letra del dni corresponde con la del array
        char letra = dni.charAt(8);
        letra = Character.toUpperCase(letra);
        if (letra != letraDni[factor]){
            return false;
        }

        // si el flujo de la funcion llega aquí, es que el dni es correcto
        return true;
    }


}
