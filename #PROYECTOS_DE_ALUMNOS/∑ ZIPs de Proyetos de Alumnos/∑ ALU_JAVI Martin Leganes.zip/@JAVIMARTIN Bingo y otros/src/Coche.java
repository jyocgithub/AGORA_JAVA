


public class Coche {


    // ATRIBUTOS
    private String color;
    private String marca;
    private String matricula;
    private int precio;


    Coche(String col, String mar, String mat, int pre) {
        color = col;
        marca = mar;
        matricula = mat;
        precio = pre;
    }

    Coche(String col, String mar, String mat) {
        color = col;
        marca = mar;
        matricula = mat;
        precio = 0;
    }

    Coche() {

    }


    // METODOS
    public void dimeImpuesto() {
        double impuesto = precio * 0.10;
        System.out.println(impuesto);
    }

    void dimeSiEsMetalizado() {
        if (color.equals("Negro")) {
            System.out.println("El coche tiene pintura metalizada");
        } else {
            System.out.println("El coche NO tiene pintura metalizada");
        }
    }

    public void setMatricula(String x) {
        matricula = x;
    }

    public void setColor(String x) {
        if (x.equalsIgnoreCase("VAYA MIERDA")) {
            color = color;
        } else {

            color = x;
        }
    }

    public void setMarca(String x) {
        marca = x;
    }

    public void setPrecio(int x) {
        precio = x;
    }

    public int getPrecio() {
        return precio;
    }

    public String getColor() {
        return color;
    }


    public String toString() {
        String res = marca + ":" + color + ":" + matricula;
        return res;
    }


}
