package swing;

public class pruebas {

	public static void main(String[] args) {

		for (int i = 0; i < 1000; i++) {
			int x = (Utilidades.azar(1, 91));
			if (x == 1) {
				System.out.println(x);
			}
			if (x == 0) {
				System.out.println(x);
			}
			if (x == 90) {
				System.out.println(x);
			}
			if (x == 91) {
				System.out.println(x);
			}
		}
	}

}
