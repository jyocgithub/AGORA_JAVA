package swing;

import java.awt.Color;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class MesaBingo {

	private JFrame ventanaPrincipal;
	Carton c1;
	MotorBingo mb;
	Carton[] arrayDeCartones = new Carton[4];
	JPanel panelFondo1, panelFondo2, panelFondo3, panelFondo4;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {

		// for (int i = 0; i < 100; i++) {
		// System.out.println(Utilidades.azar(1, 91));
		// }

		// abrimos la ventana principal
		EventQueue.invokeLater(new Runnable() {
			@Override
			public void run() {
				try {
					MesaBingo objetomesabingo = new MesaBingo();
					objetomesabingo.initialize();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public MesaBingo() {

		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {

		// crear clases de trabajo
		c1 = new Carton();
		mb = new MotorBingo();

		// creamos el array de cartones
		arrayDeCartones[0] = new Carton();
		arrayDeCartones[1] = new Carton();
		arrayDeCartones[2] = new Carton();
		arrayDeCartones[3] = new Carton();

		// creamos el array de paneles
		panelFondo1 = new JPanel();
		panelFondo2 = new JPanel();
		panelFondo3 = new JPanel();
		panelFondo4 = new JPanel();

		// creamos la ventana
		ventanaPrincipal = new JFrame();
		ventanaPrincipal.setBounds(10, 10, 810, 610);
		ventanaPrincipal.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		ventanaPrincipal.getContentPane().setLayout(null);

		// rellenar cartones inicialmente
		mb.rellenarCarton(arrayDeCartones[0]);
		mb.rellenarCarton(arrayDeCartones[1]);
		mb.rellenarCarton(arrayDeCartones[2]);
		mb.rellenarCarton(arrayDeCartones[3]);

		// pintar cartones
		pintarCartones();

		// hacemos visible la ventana
		ventanaPrincipal.setVisible(true);
	}

	public void pintarCartones() {
		pintarSoloUnCarton(panelFondo1, 20, 20, arrayDeCartones[0].tabla);
		pintarSoloUnCarton(panelFondo2, 430, 20, arrayDeCartones[1].tabla);
		pintarSoloUnCarton(panelFondo3, 20, 300, arrayDeCartones[2].tabla);
		pintarSoloUnCarton(panelFondo4, 430, 300, arrayDeCartones[3].tabla);
	}

	public void pintarSoloUnCarton(JPanel enQuePanel, int x, int y, int[][] cartonquesepinta) {
		// JPanel panelFondo1 = new JPanel();
		enQuePanel.setBounds(x, y, 360, 110);
		enQuePanel.setLayout(null);
		enQuePanel.setBackground(Color.cyan);
		// crear paneles de cada celda del carton 1
		JLabel[][] arrayLabelsCelda = new JLabel[3][9];
		for (int fila = 0; fila < 3; fila++) {
			for (int columna = 0; columna < 9; columna++) {
				arrayLabelsCelda[fila][columna] = new JLabel("00");
				arrayLabelsCelda[fila][columna].setBounds(10 + (columna * 40), 10 + (fila * 30), 40, 30);
				// carton1[fila][columna].setBounds(inicioy1 + (columna * 40), iniciox1 + (fila * 30), 40, 30);
				arrayLabelsCelda[fila][columna].setBackground(Color.red);
				enQuePanel.add(arrayLabelsCelda[fila][columna]);
				if (cartonquesepinta[fila][columna] == 0) {
					arrayLabelsCelda[fila][columna].setText("--");
				} else {
					arrayLabelsCelda[fila][columna].setText(cartonquesepinta[fila][columna] + "");
				}
			}
		}

		// añadimos el panel a la ventana principal
		ventanaPrincipal.getContentPane().add(enQuePanel);
	}

}

class MotorBingo {

	/**
	 * Rellena un carton con numeros Valida que en cada columna se coloquen los numeros de la decena correspondiente Valida que en
	 * cada columna no haya tres numeros Valida que no existan numeros repetidos No valida que existan numeros en todas las columnas
	 * (puede haber columnas sin numeros)
	 * 
	 * @param carton
	 *            carton que se va a rellenar
	 */
	public void rellenarCarton(Carton carton) {
		int elegido, columna;
		int totalNumerosAgregadosEnUnaFila = 0;
		boolean existeElNumeroEnELCarton = false;
		boolean hayDosNumerosYaEnLaColumna = false;
		for (int fila = 0; fila < 3; fila++) {
			totalNumerosAgregadosEnUnaFila = 0;
			while (totalNumerosAgregadosEnUnaFila < 5) {
				elegido = Utilidades.azar(1, 91);
				columna = elegido / 10;
				if (columna == 9) { // por si sale el 90, que se ponga en la columna de los 80
					columna = 8;
				}
				existeElNumeroEnELCarton = verSiExisteElNumeroEnELCarton(carton, elegido);
				hayDosNumerosYaEnLaColumna = verSiHayDosNumerosYaEnLaColumna(carton, columna);
				if (existeElNumeroEnELCarton == false && hayDosNumerosYaEnLaColumna == false) {
					if (carton.tabla[fila][columna] == 0) {
						carton.tabla[fila][columna] = elegido;
						totalNumerosAgregadosEnUnaFila++;
					}
				}
			}
		}
	}

	public void pintarCartonMonitor(Carton carton) {
		System.out.println("\n******************************************");
		for (int fila = 0; fila < 3; fila++) {
			for (int columna = 0; columna < 9; columna++) {
				String numstr = Utilidades.dosCifras(carton.tabla[fila][columna]);
				if (numstr.equals(" 0")) {
					numstr = "--";
				}
				System.out.print(numstr);

				if (columna < 8) {
					System.out.print("   ");
				}
			}
			System.out.println();
		}
		System.out.println("******************************************\n");
	}

	public boolean verSiExisteElNumeroEnELCarton(Carton carton, int numero) {
		boolean existe = false;
		for (int fila = 0; fila < 3 && existe == false; fila++) {
			for (int columna = 0; columna < 9; columna++) {
				if (carton.tabla[fila][columna] == numero) {
					existe = true;
				}
			}
		}
		return existe;
	}

	public boolean verSiHayDosNumerosYaEnLaColumna(Carton carton, int columna) {
		int cuantos = 0;
		for (int fila = 0; fila < 3; fila++) {
			if (carton.tabla[fila][columna] != 0) {
				cuantos++;
			}
		}
		if (cuantos > 1) {
			return true;
		}
		return false;
	}
}

class Carton {
	int[][] tabla;

	Carton() {
		tabla = new int[3][9];
	}
}
