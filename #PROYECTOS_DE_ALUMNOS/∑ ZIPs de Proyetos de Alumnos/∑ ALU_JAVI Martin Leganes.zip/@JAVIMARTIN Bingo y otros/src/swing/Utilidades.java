package swing;

import java.util.Random;

public class Utilidades {
	public static int azar(int min, int max) {
		Random r = new Random();
		int s = r.nextInt(max - min) + 1;
		return s;
	}

	public static String dosCifras(int numero) {
		if (numero < 10) {
			return " " + numero;
		}
		return "" + numero;
	}
}
