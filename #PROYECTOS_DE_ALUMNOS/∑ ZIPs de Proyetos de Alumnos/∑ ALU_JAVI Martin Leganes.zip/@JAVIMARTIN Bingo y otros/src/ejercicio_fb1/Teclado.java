package ejercicio_fb1;

import java.util.Scanner;


public class Teclado {
	public int leerInt () {
		int res = 0;
		Scanner sc = new Scanner (System.in);
		res = sc.nextInt ();
		return res;
	}
	public String leerString () {
		String resultado = "";
		Scanner sc = new Scanner (System.in);
		resultado = sc.nextLine ();
		return resultado;
	}
}
