package ejercicio_fb1;

public class ArrayAlumnos {
	Alumno[] alumnos=new Alumno[3];

	int numMujeres() {
	  int numeroMujeres=0;
	  for (int i=0; i<alumnos.length;i++) {
		if(alumnos[i]!=null && this.alumnos[i].mujer)
			numeroMujeres++;
	  }
	  return numeroMujeres;
	}
	int numAlumnosAprobados() {
		int numeroAprobados=0;
		for (int i=0; i<alumnos.length;i++) {
			if(alumnos[i]!=null && this.alumnos[i].CalcularMedia()>=5)
				numeroAprobados++;
		}
		return (numeroAprobados);
	}
	boolean mediaHombresEsMayor() {
		float mediaHombres=0, contH=0;
		float mediaMujeres=0, contM=0;
		boolean hombresMayor=false;
		for (int i=0;i<alumnos.length;i++) {
			if(alumnos[i]!=null && alumnos[i].mujer) {
				mediaMujeres=mediaMujeres+alumnos[i].CalcularMedia();
				contM++;
			}
			else {
				mediaHombres=mediaHombres+alumnos[i].CalcularMedia();
				contH++;
			}
		}
		if (contM == 0)
			hombresMayor=true;
		else
			if (contH == 0)
				hombresMayor=false;
			else
				if( (mediaHombres/contH)> (mediaMujeres/contM) )
					hombresMayor=true;
		return hombresMayor;
	}
	public static void main(String[] args) {
		/*ArrayAlumnos instituto=new ArrayAlumnos();
	    int notasA[] = {5,5,7,7};
	    Alumno prueba= new Alumno("A", true, notasA);
	    instituto.añadirAlumno(prueba);
	    System.out.println(instituto.alumnos[0].CalcularMedia());
	    */
	    //Creacion aleatoria de los 30 alumnos del grupo A y B
		ArrayAlumnos instituto=new ArrayAlumnos();
		for(int i=0; i<instituto.alumnos.length; i++) {
			 int numNotas=(int)(Math.random()*9)+1; //+1 para que tengan al menos una nota
			 int notasAlumno[]=new int [numNotas];
			 for(int j=0; j<numNotas; j++) {
			    	notasAlumno[j]=(int)(Math.random()*10);
			 }
			 int sexo=(int)(Math.random()*2);
			 boolean esMujer;
			 	if (sexo==0)
			 		esMujer=true;
			 	else esMujer=false;
			 int grupo=(int)(Math.random()*2);
			 String group;
			 if (grupo==0)
		    		group="A";
		     else group="B";

			 Alumno alumnoAleatorio= new Alumno(group, esMujer, notasAlumno);
			 instituto.alumnos[i]=alumnoAleatorio;
		}
		for(int k=0;k<instituto.alumnos.length; k++) {
			System.out.print(instituto.alumnos[k].grupo + " ");
			System.out.print(instituto.alumnos[k].mujer + " ");
			System.out.print(instituto.alumnos[k].CalcularMedia() + " ");
			System.out.println();
		}
		System.out.println(instituto.numMujeres());
		System.out.println(instituto.numAlumnosAprobados());
		boolean mediaHombresMay=instituto.mediaHombresEsMayor();
		System.out.println("La media de los hombres es mayor: " + mediaHombresMay);
	}
}
