import java.io.*;

public class FD2 {

    //.-(Dif 5). Para gestionar los pedidos de una tienda se tiene un fichero de texto (fventasPedidas.txt)
    // en el que el encargado de ventas coloca el número de artículo y, separado por 2 puntos (:)
    // la cantidad solicitada para su venta.
    //    Por otra parte se tiene un fichero (fproductos.dat)de acceso directo (RandomAccessFile)
    // en el que están almacenados los atributos de los productos en el orden indicado en la siguiente clase:
    //    class Producto{
    //  int codigo;
    //  String nombre; //almacenado siempre con 20bytes (1 byte por carácter)
    //  int cantidadStock; //cantidad de productos en el almacén
    //  double precio; //Precio por unidad de producto
    //    }
    //    Realizar una aplicación que, suponiendo que el fichero fproductos.dat está creado y
    // tiene todos los productos que aparecen en el fventasPedidas.txt, y el producto de código
    // x está en la posición x , cree un fichero de texto fventasRealizadas.txt en el que estén
    // incluidas todas las ventas que se pueden realizar, que serán aquellas tales que la cantidad
    // solicitada para la venta sea menor o igual que la cantidad en stock.
    // Después de procesar
    // cada línea del fichero de ventas, si la venta es realizable, se restará de la cantidad en
    // stock del producto la cantidad vendida.  
    // No se podrán realizar ventas parciales, es decir
    // si se desea vender 10 unidades y sólo hay 3 en stock no se venderá ninguna.
    // Para cada venta
    // realizada se grabará una línea en el fichero fventasRealizadas con el formato 
    // numProducto#cantidadVendida#PrecioTotal de la venta
    //    En el fichero fventasPedidas.txt deben quedar almacenadas todas las ventas no realizadas
    //
    //      fventasPedidas.txt y fventasPedidasSinRealizar.txt
    //  numarticulo:cantidadsolicitada
    //      fproductos.dat
    //  int codigo;
    //  String nombre;      //almacenado siempre con 20bytes (1 byte por carácter)
    //  int cantidadStock;  //cantidad de productos en el almacén
    //  double precio;
    //      fventasRealizadas.txt
    // numProducto#cantidadVendida#PrecioTotaldelaventa

    final static int TAMANOREGISTROFPRODUCTOS = 4 + 20 + 4 + 8;
    static BufferedReader fichPedidos = null;
    static BufferedWriter fichPedidosSinRealizar = null;
    static BufferedWriter fichVentasRealizadas = null;
    static RandomAccessFile raf = null;

    public static void main(String[] args) throws IOException {
        try {
            fichPedidos = new BufferedReader(new FileReader("fventaspedidas.txt"));
            fichPedidosSinRealizar = new BufferedWriter(new FileWriter("fventaspedidasSinRealizar.txt"));
            fichVentasRealizadas = new BufferedWriter(new FileWriter("fventasRealizadas.txt"));
            raf = new RandomAccessFile("fproductos.dat", "rw");

            String lineapedidos = fichPedidos.readLine();
            while (lineapedidos != null) {
                String[] trozos = lineapedidos.split(":");
                int cantidadSolicitada = Integer.parseInt(trozos[1]);
                mirarSiExisteStock(raf, trozos[0], cantidadSolicitada);
                lineapedidos = fichPedidos.readLine();
            }

            File ventasoriginal = new File("fventaspedidas.txt");
            File ventasnew = new File("fventaspedidasSinRealizar.txt");
            ventasoriginal.delete();
            ventasnew.renameTo(ventasoriginal);

        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                fichPedidos.close();
                fichPedidosSinRealizar.close();
                fichVentasRealizadas.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    public static void mirarSiExisteStock(RandomAccessFile raf, String codpedido, int cantidadSolicitada) {
        boolean encontrado = false;
        int posicion = 0;
        int codigo;
        String nombre;
        int stock;
        double precio = 0;
        try {
            raf.seek(posicion);
            while (posicion < raf.length() && encontrado==false) {
                codigo = raf.readInt();
                nombre = leerCadenaRAF(raf, 20);
                stock = raf.readInt();
                precio = raf.readDouble();
                if (codpedido.equalsIgnoreCase(codpedido)) {
                    if (cantidadSolicitada <= stock) {
                        encontrado = true;
                        stock = stock - cantidadSolicitada;
                        raf.seek(posicion + 4 + 20);
                        raf.writeInt(stock);
                    }
                }
                posicion = posicion + TAMANOREGISTROFPRODUCTOS;
            }

            if (encontrado == true) {
                 fichVentasRealizadas.write(codpedido + "#" + cantidadSolicitada + "#" + (precio*cantidadSolicitada));
            } else {
                fichPedidosSinRealizar.write(codpedido + ":" + cantidadSolicitada);
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static String leerCadenaRAF(RandomAccessFile raf, int tamano) {
        String resultado = "";
        for (int i = 0; i < tamano; i++) {
            try {
                resultado=resultado + raf.readChar();
            } catch (IOException e) {
            }
        }
        resultado = resultado.trim();
        return resultado;
    }
}
