package swing;

import java.io.*;
import java.util.Iterator;
import java.util.Scanner;

import javax.swing.JOptionPane;

public class S_ServidorBingo {
	Carton c1;
	Carton[] arrayDeCartones;
	int[] numerosSacados;
	// creamos el array de cartones
	public static final String FICHERO_CARTONES = "cartones.txt";
	public static final String FICHERO_NUMEROEXTRAIDO = "numeroextraido.txt";
	public static final String FICHERO_PREMIOS = "premios.txt";
	public static final String FICHERO_PARTICIPANTES = "participantes.txt";

	public static final String DIRECTORIO_COMPARTIDO = ".";
	private boolean yaHaSalidoLinea = false;
	private boolean yaHaSalidoBingo = false;
	private int numeroJugadores;
	private String[] nombresJugadores;

	// metodo main de inicio
	public static void main(String[] args) {
		S_ServidorBingo motor = new S_ServidorBingo();
		motor.iniciar();
	}

	public void iniciar() {
		numerosSacados = new int[91];

		String numj = JOptionPane.showInputDialog(null, "NUMERO DE JUGADORES QUE PARTICIPAN", "N�mero participantes",
				JOptionPane.PLAIN_MESSAGE);
		numeroJugadores = Integer.parseInt(numj);
		nombresJugadores = new String[numeroJugadores];	
		arrayDeCartones = new Carton[numeroJugadores];
		for (int i = 0; i < numeroJugadores; i++) {
			arrayDeCartones[i] = new Carton();
			rellenarCarton(arrayDeCartones[i]);
		}

		File ficherodepremios = new File(DIRECTORIO_COMPARTIDO, FICHERO_PREMIOS);
		ficherodepremios.delete();
		File ficherodejugadores = new File(DIRECTORIO_COMPARTIDO, FICHERO_PARTICIPANTES);
		ficherodejugadores.delete();
		File ficherodecartones = new File(DIRECTORIO_COMPARTIDO, FICHERO_CARTONES);
		ficherodecartones.delete();
		File ficherodenumeroextraido = new File(DIRECTORIO_COMPARTIDO, FICHERO_NUMEROEXTRAIDO);
		ficherodenumeroextraido.delete();

		// ver si estan todos los jugadores arrancados
		//verSiYaEstanTodosLosJugadores();

		jugar();

	}

	public void jugar() {
		int numeroextraido = 0;
		pintarCartonesEnLaConsola();
		guardarCartonesEnFicheroTexto();
		escribirnuloennumerosextraidos();

		while (yaHaSalidoBingo == false) {

			 System.out.println("pulsa intro para seguir");
			 new Scanner(System.in).nextLine();

//			try {
//				Thread.sleep(300);
//			} catch (InterruptedException e) {
//				// TODO Bloque catch generado autom�ticamente
//				e.printStackTrace();
//			}

			// sacar nuevo numero
			boolean seguirsacando = true;
			while (seguirsacando == true) {
				numeroextraido = Utilidades.azar(1, 90);
				if (numerosSacados[numeroextraido] == 0) {
					numerosSacados[numeroextraido] = 1;
					seguirsacando = false;
				}
			}

			// pintar en consola del servido el numero extraido
			System.out.println("HA SALIDO EL : " + numeroextraido);

			// tachar el numero en los cartones
			for (int i = 0; i < arrayDeCartones.length; i++) { // cada carton
				Carton cadacarton = arrayDeCartones[i];
				for (int f = 0; f < 3; f++) {
					for (int c = 0; c < 9; c++) {
						if (cadacarton.tabla[f][c] == numeroextraido) {
							cadacarton.tabla[f][c] = -1;
							System.out.println("Numero encontrado en carton " + i);
						}
					}
				}
			}
			// pintar cartones en la consola del servidor para verlos
			pintarCartonesEnLaConsola();

			// guardar cartones ya cambiados
			guardarCartonesEnFicheroTexto();

			// guardar numero que ha salido
			guardarNumerosExtraidosEnFicheroTexto(numeroextraido);

			// comprobar si ha habido linea
			if (yaHaSalidoLinea == false) {
				comprobarSiHaHabidoLinea();
			}

			// comprobar si ha habido bingo, y entonces, se ha acabado
			if (yaHaSalidoBingo == false) {
				comprobarSiHaHabidoBingo();
			}

		}

		// calcular estadisticasy guaradr en fichero

	}

	public void verSiYaEstanTodosLosJugadores() {
		File fich = new File(DIRECTORIO_COMPARTIDO, FICHERO_PARTICIPANTES);
		if(!fich.exists()){
			try {
				fich.createNewFile();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		FileReader fw = null;
		BufferedReader lector = null;
		int numerodejugadoresquehayenelfichero = 0;
		while (numerodejugadoresquehayenelfichero < numeroJugadores) {
			// PARAR UN SGUNDO O ASI
			try {
				Thread.sleep(2000);
			} catch (InterruptedException e1) {
				e1.printStackTrace();
			}
			try {
				fw = new FileReader(fich);
				lector = new BufferedReader(fw);
				numerodejugadoresquehayenelfichero = 0;
				String linea = lector.readLine();
				while (linea != null) {
					nombresJugadores[numerodejugadoresquehayenelfichero] = linea;
					numerodejugadoresquehayenelfichero++;
					linea = lector.readLine();
				}
			} catch (IOException e) {
				e.printStackTrace();
			} finally {
				try {
					lector.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
			System.out.println("HAy por ahora "+numerodejugadoresquehayenelfichero+" jugadores");
		}
	}

	public void comprobarSiHaHabidoBingo() {
		// si hay bingo
		boolean hayBingo;
		for (int numerodecadcarton = 0; numerodecadcarton < arrayDeCartones.length; numerodecadcarton++) {
			Carton carton = arrayDeCartones[numerodecadcarton];

			// se trata cada carton
			hayBingo = false;
			int contadordeencontrados = 0;

			for (int f = 0; f < 3; f++) { // cada fila de la matriz de numeros

				// recorro las columnas de cada linea y cuento los -1 que haya
				for (int c = 0; c < 9; c++) {
					if (carton.tabla[f][c] == -1) {
						contadordeencontrados++;
					}
				}

			}
			// acaba de mirar en un carton
			// ver si hubo bingo en este carton
			if (contadordeencontrados == 15) {
				System.out.println("HAY BINGOOOOOOO EN EL CARTON " + numerodecadcarton);
				guardarPremioEnFicheroDePremios(numerodecadcarton, "BINGO");
				yaHaSalidoBingo = true;
				System.out.println("pulsa intro para seguir");
				new Scanner(System.in).nextLine();
			}
		}
	}

	public void comprobarSiHaHabidoLinea() {
		// si hay linea
		boolean haylinea = true;
		for (int numerodecadcarton = 0; numerodecadcarton < arrayDeCartones.length; numerodecadcarton++) {
			Carton carton = arrayDeCartones[numerodecadcarton];

			// se trata cada carton
			haylinea = false;
			for (int f = 0; f < 3; f++) { // cada fila de la matriz de numeros

				int contadordeencontrados = 0;
				// recorro las columnas de cada linea y cuento los -1 que haya
				for (int c = 0; c < 9; c++) {
					if (carton.tabla[f][c] == -1) {
						contadordeencontrados++;
					}
				}
				// si hay 5 numeros -1, esque hay linea
				if (contadordeencontrados == 5) {
					haylinea = true;
				}

			}
			// acaba de mirar en un carton
			// ver si hubo linea en este carton
			if (haylinea == true) {
				System.out.println("HAY LINEA EN EL CARTON " + numerodecadcarton);
				guardarPremioEnFicheroDePremios(numerodecadcarton, "LINEA");
				yaHaSalidoLinea = true;
				System.out.println("pulsa intro para seguir");
				new Scanner(System.in).nextLine();

			}
		}
	}

	public void guardarPremioEnFicheroDePremios(int numerocartonpremiado, String quepremiopongo) {

		File fich = new File(DIRECTORIO_COMPARTIDO, FICHERO_PREMIOS);
		FileWriter fw = null;
		BufferedWriter escritor = null;

		try {
			fw = new FileWriter(fich, true);
			escritor = new BufferedWriter(fw);
			escritor.write(quepremiopongo + "," + numerocartonpremiado );
			escritor.newLine();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				escritor.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

	public void guardarNumerosExtraidosEnFicheroTexto(int nuevonumero) {

		File fich = new File(DIRECTORIO_COMPARTIDO, FICHERO_NUMEROEXTRAIDO);
		FileWriter fw = null;
		BufferedWriter escritor = null;

		try {
			fw = new FileWriter(fich);
			escritor = new BufferedWriter(fw);
			escritor.write(nuevonumero + "");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				escritor.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}

	}
	public void escribirnuloennumerosextraidos() {

		File fich = new File(DIRECTORIO_COMPARTIDO, FICHERO_NUMEROEXTRAIDO);
		FileWriter fw = null;
		BufferedWriter escritor = null;

		try {
			fw = new FileWriter(fich);
			escritor = new BufferedWriter(fw);
			String nulo="";
			escritor.write(nulo);
		} catch (IOException e) {
			System.out.println("Error al escribir nulo");
		} finally {
			try {
				escritor.close();
			} catch (IOException e) {
				System.out.println("Error al cerrar buffer de escritura de numero nulo");
			}
		}

	}

	public void guardarCartonesEnFicheroTexto() {

		File fich = new File(DIRECTORIO_COMPARTIDO, FICHERO_CARTONES);
		FileWriter fw = null;
		BufferedWriter escritor = null;

		try {
			fw = new FileWriter(fich);
			escritor = new BufferedWriter(fw);
			for (int i = 0; i < arrayDeCartones.length; i++) { // cada carton
				Carton cadacarton = arrayDeCartones[i];

				for (int f = 0; f < 3; f++) {
					for (int c = 0; c < 9; c++) {
						escritor.write(cadacarton.tabla[f][c] + "");
						if (c < 8) {
							escritor.write(",");
						}
					}
					escritor.newLine();
				}
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				escritor.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}

	}

	/**
	 * Rellena un carton con numeros Valida que en cada columna se coloquen los
	 * numeros de la decena correspondiente Valida que en cada columna no haya
	 * tres numeros Valida que no existan numeros repetidos No valida que
	 * existan numeros en todas las columnas (puede haber columnas sin numeros)
	 * 
	 * @param carton
	 *            carton que se va a rellenar
	 */
	public void rellenarCarton(Carton carton) {
		int elegido, columna;
		int totalNumerosAgregadosEnUnaFila = 0;
		boolean existeElNumeroEnELCarton = false;
		boolean hayDosNumerosYaEnLaColumna = false;
		for (int fila = 0; fila < 3; fila++) {
			totalNumerosAgregadosEnUnaFila = 0;
			while (totalNumerosAgregadosEnUnaFila < 5) {
				elegido = Utilidades.azar(0, 90);
				columna = elegido / 10;
				if (columna == 9) { // por si sale el 90, que se ponga en la
									// columna de los 80
					columna = 8;
				}
				existeElNumeroEnELCarton = verSiExisteElNumeroEnELCarton(carton, elegido);
				hayDosNumerosYaEnLaColumna = verSiHayDosNumerosYaEnLaColumna(carton, columna);
				if (existeElNumeroEnELCarton == false && hayDosNumerosYaEnLaColumna == false) {
					if (carton.tabla[fila][columna] == 0) {
						carton.tabla[fila][columna] = elegido;
						totalNumerosAgregadosEnUnaFila++;
					}
				}
			}
		}
	}

	public void pintarUnSoloCartonEnConsola(Carton carton) {
		System.out.println("\n******************************************");
		String numstr;
		for (int fila = 0; fila < 3; fila++) {
			for (int columna = 0; columna < 9; columna++) {

				if (carton.tabla[fila][columna] == 0) {
					numstr = "--";
				} else if (carton.tabla[fila][columna] > 9) {
					numstr = carton.tabla[fila][columna] + "";
				} else if (carton.tabla[fila][columna] == -1) {
					numstr = "XX";
				} else {
					numstr = " " + carton.tabla[fila][columna];
				}

				System.out.print(numstr);
				System.out.print("   ");
			}
			System.out.println();
		}
		System.out.println("******************************************\n");
	}

	public boolean verSiExisteElNumeroEnELCarton(Carton carton, int numero) {
		boolean existe = false;
		for (int fila = 0; fila < 3 && existe == false; fila++) {
			for (int columna = 0; columna < 9; columna++) {
				if (carton.tabla[fila][columna] == numero) {
					existe = true;
				}
			}
		}
		return existe;
	}

	public boolean verSiHayDosNumerosYaEnLaColumna(Carton carton, int columna) {
		int cuantos = 0;

		for (int fila = 0; fila < 3; fila++) {
			if (carton.tabla[fila][columna] != 0) {
				cuantos++;
			}
		}

		if (cuantos > 1) {
			return true;
		}
		return false;
	}

	public void pintarCartonesEnLaConsola() {
		for (int i = 0; i < arrayDeCartones.length; i++) {
			pintarUnSoloCartonEnConsola(arrayDeCartones[i]);
		}
	}
}
