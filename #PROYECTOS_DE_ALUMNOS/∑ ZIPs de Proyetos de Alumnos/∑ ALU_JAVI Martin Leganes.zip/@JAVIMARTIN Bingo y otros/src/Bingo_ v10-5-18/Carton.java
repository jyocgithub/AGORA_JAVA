package swing;

import javax.swing.JLabel;

public class Carton {
	int[][] tabla;
	JLabel[][] arraydelabels;
	
	Carton() {
		tabla = new int[3][9];
		arraydelabels = new JLabel[3][9];

		for (int fila = 0; fila < 3; fila++) {
			for (int columna = 0; columna < 9; columna++) {
				arraydelabels[fila][columna] = new JLabel();
			}
		}
	}
}