package swing;

import java.awt.Color;
import java.awt.EventQueue;
import java.io.*;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

public class J_CadaJugador {
    public static final String FICHERO_CARTONES = "cartones.txt";
    public static final String FICHERO_NUMEROEXTRAIDO = "numeroextraido.txt";
    public static final String FICHERO_PREMIOS = "premios.txt";
    public static final String FICHERO_PARTICIPANTES = "participantes.txt";
    public static final String DIRECTORIO_COMPARTIDO = ".";
    JLabel ultimonumero, labellinea, labelbingo;
    JLabel label1 = new JLabel("--");
    JLabel label2 = new JLabel("--");
    JLabel label3 = new JLabel("--");
    JLabel label4 = new JLabel("--");
    JLabel label5 = new JLabel("--");
    JLabel label6 = new JLabel("--");
    JLabel label7 = new JLabel("--");
    JLabel label8 = new JLabel("--");
    JLabel label9 = new JLabel("--");
    JLabel label10 = new JLabel("--");
    JLabel label11 = new JLabel("--");
    JLabel label12 = new JLabel("--");
    JLabel label13 = new JLabel("--");
    JLabel label14 = new JLabel("--");
    JLabel label15 = new JLabel("--");
    JLabel label16 = new JLabel("--");
    JLabel label17 = new JLabel("--");
    JLabel label18 = new JLabel("--");
    JLabel label19 = new JLabel("--");
    JLabel label20 = new JLabel("--");
    JLabel label21 = new JLabel("--");
    JLabel label22 = new JLabel("--");
    JLabel label23 = new JLabel("--");
    JLabel label24 = new JLabel("--");
    JLabel label25 = new JLabel("--");
    JLabel label26 = new JLabel("--");
    JLabel label27 = new JLabel("--");
    private JFrame ventanaPrincipal;
    Carton carton;

    JPanel panelFondo1;

    public static void main(String[] args) {
        J_CadaJugador objetojugadorbingo = new J_CadaJugador();
    }

    public J_CadaJugador() {
        arrancar();
    }

    private void arrancar() {
        carton = new Carton();
        // creamos la ventana
        ventanaPrincipal = new JFrame();
        ventanaPrincipal.setBounds(10, 10, 410, 270);
        ventanaPrincipal.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        ventanaPrincipal.getContentPane().setLayout(null);

        panelFondo1 = new JPanel();
        panelFondo1.setBounds(30, 30, 360, 110);
        panelFondo1.setLayout(null);
        panelFondo1.setBackground(Color.GREEN);
        ventanaPrincipal.add(panelFondo1);

        label1.setBounds(10,10,40,30);
        label2.setBounds(50,10,40,30);
        label3.setBounds(90,10,40,30);
        label4.setBounds(130,10,40,30);
        label5.setBounds(170,10,40,30);
        label6.setBounds(210,10,40,30);
        label7.setBounds(250,10,40,30);
        label8.setBounds(290,10,40,30);
        label9.setBounds(330,10,40,30);
        label10.setBounds(10,40,40,30);
        label11.setBounds(50,40,40,30);
        label12.setBounds(90,40,40,30);
        label13.setBounds(130,40,40,30);
        label14.setBounds(170,40,40,30);
        label15.setBounds(210,40,40,30);
        label16.setBounds(250,40,40,30);
        label17.setBounds(290,40,40,30);
        label18.setBounds(330,40,40,30);
        label19.setBounds(10,70,40,30);
        label20.setBounds(50,70,40,30);
        label21.setBounds(90,70,40,30);
        label22.setBounds(130,70,40,30);
        label23.setBounds(170,70,40,30);
        label24.setBounds(210,70,40,30);
        label25.setBounds(250,70,40,30);
        label26.setBounds(290,70,40,30);
        label27.setBounds(330,70,40,30);


        panelFondo1.add(label1);
        panelFondo1.add(label2);
        panelFondo1.add(label3);
        panelFondo1.add(label4);
        panelFondo1.add(label5);
        panelFondo1.add(label6);
        panelFondo1.add(label7);
        panelFondo1.add(label8);
        panelFondo1.add(label9);
        panelFondo1.add(label10);
        panelFondo1.add(label11);
        panelFondo1.add(label12);
        panelFondo1.add(label13);
        panelFondo1.add(label14);
        panelFondo1.add(label15);
        panelFondo1.add(label16);
        panelFondo1.add(label17);
        panelFondo1.add(label18);
        panelFondo1.add(label19);
        panelFondo1.add(label20);
        panelFondo1.add(label21);
        panelFondo1.add(label22);
        panelFondo1.add(label23);
        panelFondo1.add(label24);
        panelFondo1.add(label25);
        panelFondo1.add(label26);
        panelFondo1.add(label27);

        ultimonumero = new JLabel();
        ultimonumero.setBounds(100, 130, 300, 61);
        ventanaPrincipal.add(ultimonumero);

        labellinea = new JLabel();
        labellinea.setBounds(100, 150, 185, 61);
        ventanaPrincipal.add(labellinea);
        labellinea.setText("NO HAY LINEA");

        labelbingo = new JLabel();
        labelbingo.setBounds(100, 170, 185, 61);
        ventanaPrincipal.add(labelbingo);
        labelbingo.setText("NO HAY BINGO");

        ventanaPrincipal.setVisible(true);

        // Bucle que lee continuamente cartonres hastaque haya bingo
        while (true) {
            // leer fichero de cartones
            leerFicheroCartones();
            // pintar carton
            pintarCarton();
            // lee fichero de ultimo numero cantado y lo pinta
            leerUltimoNumeroypintarlo();
            // lee fichero dfe premios y lo pinta
            leerpremiosypintarlos();
            // comprobar si se ha acabado (falta)

            // esperar un poco
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

    public void leerpremiosypintarlos() {
        File fich = new File(DIRECTORIO_COMPARTIDO, FICHERO_PREMIOS);
        FileReader fr = null;
        BufferedReader lector = null;
        if (fich.exists()) {
            try {
                fr = new FileReader(fich);
                lector = new BufferedReader(fr);
                String lineaquecontieneelpremiodelinea = lector.readLine();
                String lineaquecontieneelpremiodebingo = lector.readLine();
                if (lineaquecontieneelpremiodelinea != null) {
                    // pintar linea
                    labellinea.setText("LINEAAAAAA :  " + lineaquecontieneelpremiodelinea);
                }
                if (lineaquecontieneelpremiodebingo != null) {
                    // pintar bingo
                    labelbingo.setText("BINGOOOOO :  " + lineaquecontieneelpremiodebingo);
                    // acabamos (falta)
                }

            } catch (IOException e) {
                e.printStackTrace();
            } finally {
                try {
                    if (lector != null) lector.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    public void leerUltimoNumeroypintarlo() {
        File fich = new File(DIRECTORIO_COMPARTIDO, FICHERO_NUMEROEXTRAIDO);
        FileReader fr = null;
        BufferedReader lector = null;

        try {
            fr = new FileReader(fich);
            lector = new BufferedReader(fr);
            String lineaquecontieneelultimonumero = lector.readLine();
            if (lineaquecontieneelultimonumero != null)
                ultimonumero.setText("ULTIMO NUMERO EXTRAIDO: " + lineaquecontieneelultimonumero);
            else ultimonumero.setText("ESPERANDO A QUE SALGA EL PRIMER NUMERO");
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                lector.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }


    public void leerFicheroCartones() {
        File fich = new File(DIRECTORIO_COMPARTIDO, FICHERO_CARTONES);
        FileReader fr = null;
        BufferedReader lector = null;

        try {
            fr = new FileReader(fich);
            lector = new BufferedReader(fr);
            String linea = lector.readLine();

            // leo por ahora solo el primer carton
            int quelinealeo = 0;
            while (quelinealeo <3) {
                linea = lector.readLine();
                System.out.println("linea leida:" + linea);
                String[] numerosdelalineaenstring = linea.split(",");
                int[] numeroslinea = new int[9];
                for (int i = 0; i < numerosdelalineaenstring.length; i++) {
                    numeroslinea[i] = Integer.parseInt(numerosdelalineaenstring[i]);
                }

                for (int k = 0; k < 9; k++) {
                    carton.tabla[quelinealeo][k] = numeroslinea[k];
                }
                quelinealeo++;
            }

        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                lector.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }


    public void pintarCarton() {
        label1.setText(carton.tabla[0][0]+"");
        label2.setText(carton.tabla[0][1]+"");
        label3.setText(carton.tabla[0][2]+"");
        label4.setText(carton.tabla[0][3]+"");
        label5.setText(carton.tabla[0][4]+"");
        label6.setText(carton.tabla[0][5]+"");
        label7.setText(carton.tabla[0][6]+"");
        label8.setText(carton.tabla[0][7]+"");
        label9.setText(carton.tabla[0][8]+"");
        label10.setText(carton.tabla[0][0]+"");
        label11.setText(carton.tabla[1][1]+"");
        label12.setText(carton.tabla[1][2]+"");
        label13.setText(carton.tabla[1][3]+"");
        label14.setText(carton.tabla[1][4]+"");
        label15.setText(carton.tabla[1][5]+"");
        label16.setText(carton.tabla[1][6]+"");
        label17.setText(carton.tabla[1][7]+"");
        label18.setText(carton.tabla[1][8]+"");
        label19.setText(carton.tabla[2][0]+"");
        label20.setText(carton.tabla[2][1]+"");
        label21.setText(carton.tabla[2][2]+"");
        label22.setText(carton.tabla[2][3]+"");
        label23.setText(carton.tabla[2][4]+"");
        label24.setText(carton.tabla[2][5]+"");
        label25.setText(carton.tabla[2][6]+"");
        label26.setText(carton.tabla[2][7]+"");
        label27.setText(carton.tabla[2][8]+"");
        ventanaPrincipal.validate();
    }
}
