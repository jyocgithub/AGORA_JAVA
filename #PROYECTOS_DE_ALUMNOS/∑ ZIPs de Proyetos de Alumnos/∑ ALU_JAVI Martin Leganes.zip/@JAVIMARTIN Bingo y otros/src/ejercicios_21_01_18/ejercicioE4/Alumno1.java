package ejercicios_21_01_18.ejercicioE4;

public class Alumno1 {
	String nombre;
	int edad;
	int numMatricula;
	String curso;
	int notas[]=new int[5];
	
	Alumno1(){}
	
	Alumno1(String n, int e, int nm, String c, int[] not){
		nombre=n;
		edad=e;
		numMatricula=nm;
		curso=c;
		notas=not;
	}
	
	int calcularMedia(){
		int resultado=0;
		int c=0;
		for(int i=0;i<notas.length;i++){
			if (notas[i]!=0) {
			  resultado=resultado+notas[i];
			  c++;
			}
		}
		if (c>0)
		  resultado=resultado/c;
		else resultado=-1;
		return resultado;
	}
	
	void mostrar() {
		System.out.println(nombre+", "+edad+", "+numMatricula+", "+curso);
		for(int j=0;j<notas.length;j++){
			System.out.println("sus notas son: "+notas[j]+" ");
		}
	}
}
