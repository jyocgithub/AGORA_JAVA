package ejercicios_21_01_18.ejercicioE4;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.RandomAccessFile;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Random;
import java.util.Scanner;


public class Teclado {
	public int leerInt () {
		int res = 0;
		Scanner sc = new Scanner (System.in);
		res = sc.nextInt ();
		return res;
	}
	public String leerString () {
		String resultado = "";
		Scanner sc = new Scanner (System.in);
		resultado = sc.nextLine ();
		return resultado;
	}
}
