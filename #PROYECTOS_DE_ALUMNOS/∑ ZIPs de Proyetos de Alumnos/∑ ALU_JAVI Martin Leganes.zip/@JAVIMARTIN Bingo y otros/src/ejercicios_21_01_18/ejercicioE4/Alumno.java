package ejercicios_21_01_18.ejercicioE4;

public class Alumno {
	    String grupo;
	    int [] notas=new int [10];  // con sitio para un máximo de 10 notas
	    int contNotas; //indica cuantas notas hay en el array de notas.
	    boolean mujer;
	    
	Alumno() {
		
	}
	    
	Alumno (String grupo, boolean mujer, int [] notas){
		this.grupo=grupo;
		this.mujer=mujer;
		this.notas=notas;
		contNotas=this.notas.length;
		
	}
	    
    float CalcularMedia() {
    	int sumaNotas=0; float media;
	    for(int i=0; i<contNotas;i++) {
		   sumaNotas=sumaNotas+ this.notas[i];
	    }
	    if(contNotas>=1) 
	      media=(sumaNotas/contNotas);
	    else
	      media=-1; //Los alumnos sin ninguna nota apareceran con -1 en la media
	    return media;
    }
    public static void main(String[] args) {
    int notasA[] = {5,5,7,7};
    Alumno prueba= new Alumno("A", true, notasA);
    System.out.println(prueba.grupo);
    System.out.println(prueba.notas[2]);
    System.out.println(prueba.CalcularMedia());
    }

    
}
