package ejercicios_21_01_18.ejercicioE4;

import java.io.IOException;

public class Instituto {
    Alumno1 arrayAlumnoInstituto[] = new Alumno1[30];

    //El n�mero de matr�cula NO ES LA POSICI�N EN EL ARRAY

    Instituto() {
        String nombre = "No hay ningun nombre";
        int edad = 0;
        int matricula = 0;
        String curso = "1 Daw";

        for (int i = 0; i < arrayAlumnoInstituto.length; i++) {
            arrayAlumnoInstituto[i] = new Alumno1(nombre, edad, matricula, curso, this.darNotas());
        }
    }

    // añadido para ejercicioE4
    Alumno1 buscarAlumno(String nombreABuscar) throws Exception {  // el metodo debe "enviar" la posible Exception creada
        Alumno1 respuesta = null;
        for (int i = 0; i < arrayAlumnoInstituto.length; i++) {
            if (nombreABuscar.equalsIgnoreCase(arrayAlumnoInstituto[i].nombre)) {
                respuesta = arrayAlumnoInstituto[i];
            }
        }
        if (respuesta == null) {
            // crear una excepcion pues es la fraccion es infinita
            Exception unaExcepcion = new Exception("Alumno Inexistente");
            // Lanzar (provocar) la excepcion creada
            throw unaExcepcion;
        }
        return respuesta;
    }
    // fin del añadido para ejercicioE4


    int[] darNotas() {
        Alumno1 nuevo = new Alumno1();
        int i = 0;
        for (; i < 1; i++) {
            for (int j = 0; j < nuevo.notas.length; j++) {
                nuevo.notas[j] = 0;
            }
        }
        return nuevo.notas;
    }

    void menu() throws IOException {
        int opc = 1;
        int cont = 0;
        int numMatricula = 0;
        Teclado t = new Teclado();

        do {

            System.out.println("1- Dar de alta a un alumno");
            System.out.println("2- Dar de baja a un alumno");
            System.out.println("3- Modificar los datos de un alumno");
            System.out.println("4- Consultar los datos de un alumno");
            System.out.println("5- Listar los datos de los alumno");
            System.out.println("6- Listar los datos ordenados de los alumnos");
            System.out.println("7- Buscar alumno por nombre");
            System.out.println("0- Fin");
            opc = t.leerInt();
            switch (opc) {
                case 1:
                    System.out.println("Dar el nombre.");
                    String nombre = t.leerString();
                    System.out.println("Dar la edad.");
                    int edad = t.leerInt();
                    do {
                        System.out.println("Introducir numero de matricula.");
                        numMatricula = t.leerInt();
                        if (this.verificarAlumno(numMatricula) == false) {
                            cont++;
                        } else {
                            System.out.println("Ya existe un alumno con esa matricula.");
                        }
                    } while (cont < 1);
                    System.out.println("Introducir curso.");
                    String curso = t.leerString();
                    int arrayNotas[] = new int[5];
                    int notas = 0;
                    for (int i = 0; i < arrayNotas.length && notas >= 0; i++) {
                        System.out.println("introducir sus notas. introducir un numero negativo para indicar que no quiere introducir mas notas. ");
                        notas = t.leerInt();
                        if (notas != -1) {
                            arrayNotas[i] = notas;
                        }
                    }
                    this.darAlta(nombre, edad, numMatricula, curso, arrayNotas);
                    this.mostrarAlumno(numMatricula);
                    break;

                case 2:
                    System.out.println("Introduzca el numero de matricula.");
                    numMatricula = t.leerInt();
                    if (this.verificarAlumno(numMatricula) == true) {
                        this.mostrarAlumno(numMatricula);
                        System.out.println("Quiere borrar al alumno con matricula " + numMatricula + ". (ponga 1 si es si y 2 si es no)");
                        int confirmacion = t.leerInt();
                        if (confirmacion == 1) {
                            if (this.darBaja(numMatricula)) {
                                System.out.println("Usted ha dado de baja al usuario.");
                            } else {
                                System.out.println("Error del sistema el usuario no ha sido borrado.");
                            }
                        } else {
                            System.out.println("Usted ha decidido no borrarlo.");
                        }
                    } else {
                        System.out.println("Datos erroneos.");
                    }
                    break;

                case 3:
                    System.out.println("Introduzca el numero de matricula.");
                    numMatricula = t.leerInt();
                    int pos = buscar(numMatricula);
                    if (pos >= 0) {
                        arrayAlumnoInstituto[pos].mostrar();
                        //this.mostrarAlumno(numMatricula);
                        System.out.println("1- cambiar nombre.");
                        System.out.println("2- cambiar edad.");
                        int cambiar = t.leerInt();
                        switch (cambiar) {
                            case 1:
                                System.out.println("Ponga el nuevo nombre.");
                                nombre = t.leerString();
                                this.cambiarNombre(pos, nombre);
                                System.out.println("Los datos son:");
                                arrayAlumnoInstituto[pos].mostrar();
                                break;
                            case 2:
                                System.out.println("Ponga la nueva edad.");
                                edad = t.leerInt();
                                this.cambiarEdad(numMatricula, edad);
                                arrayAlumnoInstituto[pos].mostrar();
                                break;
                        }
                    } else {
                        System.out.println("Datos erroneos.");
                    }
                    break;
                case 4:
                    System.out.println("Introduzca el numero de matricula.");
                    numMatricula = t.leerInt();
                    if (this.verificarAlumno(numMatricula)) {
                        this.mostrarAlumno(numMatricula);
                    } else {
                        System.out.println("Datos erroneos.");
                    }
                    break;
                case 5:
                    System.out.println("Los datos son: ");
                    this.mostrarArray();
                    break;
                case 6:
                    this.ordenarArray();
                    System.out.println("Los datos son: ");
                    this.mostrarArray();
                    break;

                // añadido para ejercicioE4
                case 7:
                    System.out.println("Escriba el nombre del alumno a buscar:");
                    String nombreBuscar = t.leerString();
                    try {
                        Alumno1 al = this.buscarAlumno(nombreBuscar);
                        al.mostrar();
                    } catch (Exception ex) {
                        System.out.println("Alumno no encontrado.");
                    }
                    // -- fin del añadido para EjercicioE4

                case 0:
                    ;
                    break;
                default:
                    System.out.println("Opcion no valida.");
            }
        } while (opc != 0);
    }

    void darAlta(String a, int b, int c, String d, int[] e) {
        int i = 0;
        int j = 0;
        do {
            if (arrayAlumnoInstituto[i].nombre.equals("No hay ningun nombre")) {
                arrayAlumnoInstituto[i] = new Alumno1(a, b, c, d, e);
                j++;
            }
            if (i == arrayAlumnoInstituto.length - 1) {
                System.out.println("Ya estan ocupadas todas las plazas.");
            }
            i++;
        } while (j < 1 && i < arrayAlumnoInstituto.length);
    }

    int buscar(int mat) {
        int pos = -1;
        for (int i = 0; i < arrayAlumnoInstituto.length; i++)
            if (mat == arrayAlumnoInstituto[i].numMatricula)
                pos = i;
        return pos;
    }

    boolean darBaja(int a) {
        String nombre = "No hay ningun nombre";
        String curso = "1 Daw";
        boolean borrado = false;
        int pos = buscar(a);
        if (pos >= 0) {
            arrayAlumnoInstituto[pos] = new Alumno1(nombre, 0, 0, curso, this.darNotas());
            borrado = true;
        }
        return borrado;
    }

    void cambiarNombre(int pos, String b) {
        arrayAlumnoInstituto[pos].nombre = b;

    }

    void cambiarEdad(int a, int b) {
        for (int i = 0; i < arrayAlumnoInstituto.length; i++) {
            if (a == arrayAlumnoInstituto[i].numMatricula) {
                arrayAlumnoInstituto[i].edad = b;
            }
        }
    }

    void ordenarArray() {
        int pos = 0, nota1, nota2;
        for (int i = 0; i < (arrayAlumnoInstituto.length - 1); i++) {
            nota1 = arrayAlumnoInstituto[i].calcularMedia();
            for (int j = i + 1; j < arrayAlumnoInstituto.length; j++) {
                nota2 = arrayAlumnoInstituto[j].calcularMedia();
                if (nota2 > nota1) {
                    nota1 = nota2;
                    pos = j;
                }
            }
            Alumno1 variableaux = arrayAlumnoInstituto[i];
            arrayAlumnoInstituto[i] = arrayAlumnoInstituto[pos];
            arrayAlumnoInstituto[pos] = variableaux;
        }
    }

    boolean verificarAlumno(int nm) {
        boolean verdad = false;
        for (int i = 0; i < arrayAlumnoInstituto.length; i++) {
            if (nm == arrayAlumnoInstituto[i].numMatricula) {
                verdad = true;
            }
        }
        return verdad;
    }

    void mostrarAlumno(int a) {
        for (int i = 0; i < arrayAlumnoInstituto.length; i++) {
            if (a == arrayAlumnoInstituto[i].numMatricula) {
                arrayAlumnoInstituto[i].mostrar();
            }
        }
    }

    void mostrarArray() {
        for (int i = 0; i < arrayAlumnoInstituto.length; i++) {
            if (arrayAlumnoInstituto[i].numMatricula != 0) {  //mejor usar el nombre
                arrayAlumnoInstituto[i].mostrar();
            }
        }
    }

    public static void main(String[] args) throws IOException {
        Instituto a = new Instituto();
        a.menu();
    }
}
