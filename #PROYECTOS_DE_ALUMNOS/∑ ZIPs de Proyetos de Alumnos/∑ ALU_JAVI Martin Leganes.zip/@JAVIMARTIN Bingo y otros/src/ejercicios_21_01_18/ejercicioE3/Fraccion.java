package ejercicios_21_01_18.ejercicioE3;

import java.util.Scanner;

public class Fraccion {
    int numerador;
    int denominador;

    Fraccion(int num1, int dem1) throws Exception{  // el consructor debe "enviar" las posibles Exceptions creadas
        if (num1==0 && dem1==0){
            // crear una excepcion pues es la fraccion es indeterminada
            Exception unaExcepcion = new Exception("Fraccion Indeterminada");
            // Lanzar (provocar) la excepcion creada
            throw unaExcepcion;
        }
        if (dem1==0){
            // crear una excepcion pues es la fraccion es infinita
            Exception unaExcepcion = new Exception("Numero infinito");
            // Lanzar (provocar) la excepcion creada
            throw unaExcepcion;
        }
        numerador = num1;
        denominador = dem1;
        mostrarFraccion(this);
    }

    Fraccion() {
    }

    public void mostrarFraccion(Fraccion f) {
        System.out.println(f.numerador + "/" + f.denominador);
    }

    public Fraccion sumar(Fraccion f) {
        Fraccion fsuma = new Fraccion();
        fsuma.numerador = f.numerador * this.denominador + this.numerador * f.denominador;
        fsuma.denominador = f.denominador * this.denominador;
        return fsuma;
    }

    public Fraccion restar(Fraccion f) {
        Fraccion fresta = new Fraccion();
        fresta.numerador = this.numerador * f.denominador - this.denominador * f.numerador;
        fresta.denominador = f.denominador * this.denominador;
        return fresta;
    }

    public void mostrar(String txt) {
        System.out.println(txt + " ->" + numerador + "/" + denominador);
    }

    public static void main(String[] args) {

        try {
        Scanner sc = new Scanner(System.in);
        System.out.print("Inserta el numerador:");
        int numerador = sc.nextInt();
        System.out.print("Inserta el denominador:");
        int denominador = sc.nextInt();
        Fraccion f1 = new Fraccion(numerador, denominador);

        System.out.print("Inserta el numerador:");
        numerador = sc.nextInt();
        System.out.print("Inserta el denominador:");
        denominador = sc.nextInt();
        Fraccion f2 = new Fraccion(numerador, denominador);

        Fraccion fsuma = f1.sumar(f2);
        fsuma.mostrar("suma ");
        Fraccion fresta = f1.restar(f2);
        fresta.mostrar("resta ");

        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
    }

}
