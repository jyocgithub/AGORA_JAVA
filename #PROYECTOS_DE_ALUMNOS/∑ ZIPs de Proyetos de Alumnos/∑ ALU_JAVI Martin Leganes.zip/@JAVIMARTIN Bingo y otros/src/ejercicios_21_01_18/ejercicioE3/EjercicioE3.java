package ejercicios_21_01_18.ejercicioE3;

public class EjercicioE3 {

    // E3.- (Dif :3)-Modificar el constructor de la clase Fracción
    // para que si el denominador y el numerador son 0 genere una
    // excepción con el mensaje “Indeterminada” y si el numerador
    // es distinto de 0 pero el denominador es 0 genere una excepción
    // con el mensaje “Infinito”.
    // Realizar un programa principal que cree diferentes fracciones para probar el constructor.

    public static void main(String[] args) {
        try {
            Fraccion f12 = new Fraccion(0, 0);
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
        try {
            Fraccion f12 = new Fraccion(4, 0);
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
        try {
            Fraccion f12 = new Fraccion(1, 4);
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
    }
}
