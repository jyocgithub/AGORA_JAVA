package ejercicios_21_01_18.ejercicioE1;

import java.util.InputMismatchException;
import java.util.Scanner;

public class EjercicioE1 {

    // E1.-(Dif :3)- Realizar un método leerInt() que, utilizando la clase Scanner,
    // permita repetir la petición de datos por teclado de un número hasta que lo
    // introducido por el usuario sea realmente un número entero válido.
    // Cuando se descarte un dato leído se debe descartar la línea entera del mismo.

    public static int leerInt() {

        Scanner entrada = new Scanner(System.in);
        boolean seguir = true;
        int resultado = 0;
        do {
            try {
                resultado = entrada.nextInt();
                seguir = false;
            } catch (InputMismatchException ex) {
                System.out.println("Indique solo dígitos por favor");
                entrada.nextLine();  // para limpiar lo que haya en el buffer del scanner
            } catch (Exception ex) {
                System.out.println("Error inesperado, repita la introduccion por favor");
                entrada.nextLine();  // para limpiar lo que haya en el buffer del scanner
            }

        } while (seguir);
        return resultado;
    }

    public static void main(String[] args) {
        int h = leerInt();

    }
}
