package fd1;

import java.io.*;

/**
 * @author Jos� Manuel P�rez Lobato
 *
 */
public class FicheroAccDirecto2 {

	RandomAccessFile f;
	final static String NOMBREFICHERO="FichDirecto2.dat";
	
	void irARegistro(RandomAccessFile f, int pos, int tamReg) throws IOException {
		  f.seek(pos* tamReg);	  
	}
	void borrarFichero() throws IOException{
		File f= new File (NOMBREFICHERO);
		f.delete();
	}
	void escribir2EnFichero ()throws IOException{
		f= new RandomAccessFile (NOMBREFICHERO,"rw");
		Persona2 p1= new Persona2 ("Jos�", 11);
		Persona2 p2= new Persona2 ("Ana Isabel", 22);		
		Persona2 p3= new Persona2 ("Bego�a", 33);

		p1.escribir2(f);
		p2.escribir2(f);
		p3.escribir2(f);
		f.close();
	}
	void leer2DeFichero() throws IOException{
		RandomAccessFile f= new RandomAccessFile (NOMBREFICHERO, "r");
		Persona2 p3= new Persona2();
		irARegistro(f,1,p3.getTamanoRegistro2() );  //Leo primero el segundo registro 
		p3.leer2(f);
		p3.mostrar();
		irARegistro(f,0,p3.getTamanoRegistro2()); //Leo despu�s el primer registro
		p3.leer2(f);
		p3.mostrar();
		irARegistro(f,2,p3.getTamanoRegistro2()); //Leo despu�s el �ltimo registro
		p3.leer2(f);
		p3.mostrar();
		f.close();
	}
	void modificarFichero ()throws IOException{
		f= new RandomAccessFile (NOMBREFICHERO,"rw");
		Persona2 p3= new Persona2();
		irARegistro(f,1,p3.getTamanoRegistro2() );  //Leo el segundo registro 
		p3.leer2(f);
		System.out.println ("Contenido reg 1 antes de modificaci�n");
		p3.mostrar();
		p3=new Persona2("Antonio", 44);
		irARegistro(f,1,p3.getTamanoRegistro2() ); 
		p3.escribir2(f);
		f.close();
	}
	void mostrarFichero() throws IOException{
		//Comprobar antes si existe el fichero.
		if (new File (NOMBREFICHERO).isFile()){
		  RandomAccessFile f= new RandomAccessFile (NOMBREFICHERO, "r");
		  Persona2 p3= new Persona2();
		  boolean hayDatos=p3.leer2(f);
		  while (hayDatos){
			p3.mostrar();
			hayDatos=p3.leer2(f);
		  }
		  f.close();
		}
		else
			System.out.println("El Fichero no existe");
	}
	void insertarAlFinalFichero() throws IOException{
		f= new RandomAccessFile (NOMBREFICHERO,"rw");
		Persona2 p3= new Persona2("Peper2",55);
		 f.seek( p3.getTamanoRegistro2()*4);	
		 p3.escribir2(f);
		f.close();
	}
	
	public static void main(String[] args) throws IOException {
		System.out.println("FicheroAccDirecto 2");
		FicheroAccDirecto2 fad= new FicheroAccDirecto2();
		fad.borrarFichero();
		fad.escribir2EnFichero();	
		System.out.println("Contenido inicial del fichero");
		fad.leer2DeFichero();
		fad.modificarFichero();
		System.out.println ("Fichero despu�s de modificaci�n");
		fad.mostrarFichero();
		fad.insertarAlFinalFichero();
		System.out.println ("Fichero despu�s de insertar al final");
		fad.mostrarFichero();
	}

}
