package fd1;

import java.io.*;
import java.text.*;
import java.util.Date;

public class Utilidades {

	void escribirCadena(RandomAccessFile f, String nombre, int tam) {
		char nombreB[] = new char[tam];
		for (int i = 0; i < nombre.length() && i < tam; i++)
			nombreB[i] = nombre.charAt(i);
		for (int i = nombre.length(); i < tam; i++)
			nombreB[i] = (char) 0;//Escribe 0 en los espacios restantes
		String resultado = String.valueOf(nombreB);//convierte array de char en String
		try {
			f.writeChars(resultado);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	String leerCadena(RandomAccessFile f, int tam) throws IOException {
		try {
			StringBuffer nombreB = new StringBuffer(tam);
			nombreB.setLength(tam);
			char car = 'a';
			int i = 0, tamanoString = 0;
			for (i = 0; i < tam; i++) {
				car = f.readChar();
				nombreB.setCharAt(i, car);
				if (car == '\0' || i==tam-1)  // si no se encuentra un /0 por que el titulo ocupa todos los espacios del tamaño
					tamanoString = i;
			}
			nombreB.setLength(tamanoString);
			return nombreB.toString();
		} catch (EOFException e) {
			return "";
		}
	}

	String convertirDateEnString(Date d) {
		DateFormat df = new SimpleDateFormat("dd/MM/yy");
		String dateEnString = df.format(d);
		return dateEnString;
	}

	String eliminarVacios (String s) {
		if(s.length()==0){
			return s;
		}
		StringBuffer sb= new StringBuffer (s);
		int i=0;
		while ( sb.charAt(i) != (char) 0 )
			i++;
		sb.setLength(i);
		return (sb.toString() );
	}


}
