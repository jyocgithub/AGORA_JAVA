package fd1;

import java.io.*;
import java.nio.charset.Charset;
/**
 * @author Jos� Manuel P�rez Lobato
 *
 */
public class Persona2 {
  String nombre;
  int edad;
  final static int TAMANONOMBRE=20;
  
  int getTamanoRegistro2(){
	  return (TAMANONOMBRE*2 + 4);  // tama�o del array con el nombre *2 (por ser unicode) + tama�o de 1 int (4 bytes)
  }
  Persona2(String n, int e){
	  nombre=n;
	  edad=e;
  }
  Persona2 (){
	  nombre="NADA";
	  edad=0;
  }

  char [] rellenarString (String nombre){
	  char nombreB[]=new char[TAMANONOMBRE];
	  for (int i=0; i<nombre.length() && i<TAMANONOMBRE; i++)
		    nombreB[i]= nombre.charAt(i);
	  for (int i=nombre.length(); i<TAMANONOMBRE ; i++)
		    nombreB[i]=(char) 0;
	  return nombreB;
  }

  void escribir2 (RandomAccessFile f) throws IOException {
	  char nombreB[];
	  nombreB=rellenarString(nombre);
	  f.writeChars(String.valueOf(nombreB));
	  f.writeInt(edad);
  }
  boolean leer2 (RandomAccessFile f) throws IOException { 
	  //devuelve true si lee algo y false si no devuelve nada
	  try {
		StringBuffer nombreB=new StringBuffer(TAMANONOMBRE);
		nombreB.setLength(TAMANONOMBRE);
		char car='a';
		int i=0,tamanoString=0;
	    for (i=0; i<TAMANONOMBRE ;i++){
	    	car=f.readChar ();
	        nombreB.setCharAt(i, car);
		    if (car=='\0')
		    	  tamanoString= i;
	    }
	    nombreB.setLength(tamanoString);
   	    nombre=nombreB.toString();
	    edad=f.readInt();
	    return true;
	  }catch (EOFException e) {
		  return false;
	  }
  }
  void mostrar(){
	  System.out.println ("nombre:"+ nombre +"  edad:"+ edad);
  }
  void mostrarArrayChar(char nombreB[]){
	  for (int i=0;i<nombreB.length;i++)
		  System.out.print(nombreB[i]);
  }

}
