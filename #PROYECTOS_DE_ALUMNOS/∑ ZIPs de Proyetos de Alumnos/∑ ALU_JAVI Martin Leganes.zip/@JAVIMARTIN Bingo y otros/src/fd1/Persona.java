package fd1;

import java.io.*;
import java.nio.charset.Charset;
/**
 * @author Jos� Manuel P�rez Lobato
 *
 */
public class Persona {
  String nombre;
  int edad;
  final static int TAMANONOMBRE=20;
  
  int getTamanoRegistro(){
	  return (TAMANONOMBRE + 4);  // tama�o del array con el nombre + tama�o de 1 int (4 bytes)
  }

  Persona(String n, int e){
	  nombre=n;
	  edad=e;
  }
  Persona (){
	  nombre="NADA";
	  edad=0;
  }
  byte [] pasarStringaArrayBytes(String nombre){
	  byte nombreB[]=new byte[TAMANONOMBRE];
	  for (int i=0; i<nombre.length() && i<TAMANONOMBRE; i++)
		    nombreB[i]=(byte) nombre.charAt(i);
	  for (int i=nombre.length(); i<TAMANONOMBRE; i++)
		    nombreB[i]=(byte) 0;
	  return nombreB;
  }

  /**
   * Elimina del string los caracteres vac�os (0)
   * @param s
   * @return el string sin vac�os.
   */
  String eliminarVacios (String s) {
	  StringBuffer sb= new StringBuffer (s);
	  int i=0;
	  while ( sb.charAt(i) != (char) 0  ) 
		  i++;
	  sb.setLength(i);
	  return (sb.toString() );
  }
  void escribir (RandomAccessFile f) throws IOException {
	  byte nombreB[];
	  nombreB=pasarStringaArrayBytes(nombre);

	  f.write (nombreB);
	  f.writeInt(edad);
	//  System.out.println ("tamano"+ nombreB.length);
  }

  boolean leer (RandomAccessFile f) throws IOException { 
	  //devuelve true si lee algo y false si no devuelve nada
	  try {
	    byte nombreB[]=new byte[TAMANONOMBRE];
	    f.read (nombreB,0,TAMANONOMBRE);
	 //  nombre=new String(nombreB, "UTF-8"); //convierte el array de bytes en un string con la notaci�n UTF-8
	    nombre=new String(nombreB, "ISO-8859-1"); //Mejor 8859 para � y acentos.
	    nombre=eliminarVacios(nombre);
	    edad=f.readInt();
	    return true;
	  }catch (EOFException e) {
		  return false;
	  }
  }

  void mostrar(){
	  System.out.println ("nombre:"+ nombre +"  edad:"+ edad);
  }
  

}
