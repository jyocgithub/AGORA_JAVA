package fd1;
import java.io.*;
import java.util.Calendar;
import java.util.Date;
import javax.swing.plaf.synth.SynthSeparatorUI;

// Fd1.-(Dif 5)Realizar una aplicaci�n utilizando RandomAccessFile en
//lugar de arrays para gestionar los usuarios de una biblioteca. De cada
//usuario se almacenar�, el c�digo (que se asignar� autom�ticamente cuando
//		se le de de alta y ser� secuencial empezando en 0), el nombre (20 caracteres)
//y la fecha y t�tulo del libro (30 caracteres)del �ltimo pr�stamo.
//La aplicaci�n permitir� dar de alta, baja y modificar los datos de usuario.
//Tambi�n deber� poder mostrarse un listado. Tendr� una opci�n prestar
//que pedir� el n�mero de usuario y el t�tulo del libro prestado y,
//si el usuario no tienen libros prestados le realizar� el pr�stamo y
//otra para devolver un libro prestado.
//
//Todas las operaciones se realizar�n directamente sobre el fichero.
//De esa forma conseguimos que la informaci�n siempre est� actualizada
//y est� protegida ante paradas del programa o fallos el�ctricos o de
//otro tipo en el ordenador.
//
//El c�digo de usuario se asignar� al usuario al darlo de alta para que
//sea una unidad mayor que el �ltimo matriculado, ser� la clave para acceder al fichero.
public class Fd1 {
	public static void main(String[] args) throws IOException {
		Teclado t = new Teclado();
		RandomAccessFile raf = new RandomAccessFile("usuarios.dat", "rw");
		int opcion = 1;

		do {
			System.out.println("1- Dar de alta a un usuario");
			System.out.println("2- Dar de baja a un usuario");
			System.out.println("3- Modificar datos de un usuario");
			System.out.println("4- Mostrar listado");
			System.out.println("5- Prestar libro");
			System.out.println("6- Devolver libro prestado");
			System.out.println("0- Fin");
			opcion = t.leerInt();
			switch (opcion) {
				case 1:
					System.out.println("Escriba el nombre del usuario");
					String nombre = t.leerString();
					System.out.println("Escriba el titulo del libro");
					String titulo = t.leerString();
					Date fechad = Calendar.getInstance().getTime();
					int nuevocodigo = (int) raf.length()/Usuario.TAMANOREGISTRO;
					Usuario usu = new Usuario(nuevocodigo, nombre, fechad, titulo);
					usu.guardarUsuario(raf);
					break;

				case 2:
					System.out.println("Escriba el codigo del usuario");
					int code = t.leerInt();
					Usuario obj = new Usuario();
					obj.borrarUsuario(raf, code);
					break;
				case 3:
					System.out.println("Escriba el codigo del usuario a modificar:");
					int code2 = t.leerInt();
					int posicion = code2 * Usuario.TAMANOREGISTRO;
					if (posicion >= raf.length()) {
						System.out.println("Usuario inexistente");
					} else {
						System.out.println("Escriba el nuevo nombre del usuario");
						String nombre2 = t.leerString();
						System.out.println("Escriba el titulo del nuevo libro");
						String titulo2 = t.leerString();
						Date fechad2 = Calendar.getInstance().getTime();
						Usuario usu2 = new Usuario(nombre2, fechad2, titulo2, code2);
						usu2.modificarUsuario(raf);
					}
					break;
				case 4:
					try{
						Usuario.listar(raf);
					}catch(Exception e){
						System.out.println("Fin del listado");
					}


					break;
				case 5:
					System.out.println("Escriba el codigo del usuario a prestar:");
					int code3 = t.leerInt();
					int posicion3 = code3 * Usuario.TAMANOREGISTRO;
					if (posicion3 > raf.length()) {
						System.out.println("Usuario inexistente");
					} else {
						System.out.println("Escriba el titulo del nuevo libro");
						String titulo4 = t.leerString();
						Date fechad4 = Calendar.getInstance().getTime();
						Usuario usu5 = new Usuario("", fechad4, titulo4, code3);
						usu5.prestar(raf);
					}
					break;
				case 6:
					System.out.println("Escriba el codigo del usuario que devuelve:");
					int code6 = t.leerInt();
					int posicion6 = code6 * Usuario.TAMANOREGISTRO;
					if (posicion6 > raf.length()) {
						System.out.println("Usuario inexistente");
					} else {
						Usuario usu6 = new Usuario();
						usu6.devolver(raf,code6);
					}
					break;
				case 0:
					System.out.println("Fin.");
					break;
			}

		} while (opcion != 0);
	}
}
