package fd1;

import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.Date;

public class Usuario {
    private String nombre;
    private Date fecha;
    private String titulo;
    private int codigo;
    final static int TAMANONOMBRE = 20;
    final static int TAMANOTITULO = 30;
    final static int TAMANOFECHA = 10;

    final static int TAMANOREGISTRO = TAMANONOMBRE * 2 + TAMANOTITULO * 2 + TAMANOFECHA * 2; // los

    void prestar(RandomAccessFile raf) throws IOException {
        int posicion = codigo * TAMANOREGISTRO + (TAMANONOMBRE*2);
        raf.seek(posicion);
        String tituloantes = u.leerCadena(raf, TAMANOTITULO);
        boolean existelibroprestado = true;
        if (tituloantes.charAt(0) == '\0') {
            existelibroprestado = false;
        }
        if (existelibroprestado == true) {
            System.out.println("Tiene libro prestado, devolver antes de prestar");
        } else {
            raf.seek(posicion);
            u.escribirCadena(raf, titulo, TAMANOTITULO);
        }
    }                                                                        // son

    // de
    // los
    // 8
    void devolver(RandomAccessFile raf, int codes) throws IOException {
        int posicion = codes * TAMANOREGISTRO + TAMANONOMBRE*2;
        raf.seek(posicion);
        char[] ceros = new char[TAMANOTITULO / 2];
        for (int i = 0; i < ceros.length; i++) {
            raf.writeChar(ceros[i]);// escribe el array de bytes
        }
    }                                                                        // chars
    // de
    // la
    // fecha
    // formato
    // "dd/mm/aa"

    static Utilidades u = new Utilidades();

    public static void listar(RandomAccessFile raf) {
        try {

            int posicion = 0;
            raf.seek(posicion);
            int indiceusuario = 0;
            while (posicion < raf.length()) {
                String nombre = u.leerCadena(raf, TAMANONOMBRE);
                String titulo = u.leerCadena(raf, TAMANOTITULO);
                String fechastr = u.leerCadena(raf, TAMANOFECHA);
                String nombreLimpio = u.eliminarVacios(nombre);
                String tituloLimpio = u.eliminarVacios(titulo);
                String fechastrLimpio = u.eliminarVacios(fechastr);
                if (nombreLimpio.equalsIgnoreCase("") == false) { // nombre vacio es registro vacio

                    System.out.println("---------- Usuario numero " + indiceusuario);
                    System.out.println("Nombre:" + nombreLimpio);
                    System.out.println("Titulo:" + tituloLimpio);
                    System.out.println("Fecha:" + fechastrLimpio);
                    System.out.println("----------");
                }
                indiceusuario++;

                if (nombreLimpio != null && tituloLimpio != null && fechastr != null) {

                    posicion = posicion + TAMANOREGISTRO;
                }
            }

        } catch (IOException e) {
            System.out.println("Error al listar");
        }
    }

    void modificarUsuario(RandomAccessFile raf) throws IOException {
        int posicion = codigo * TAMANOREGISTRO;
        raf.seek(posicion);
        u.escribirCadena(raf, nombre, TAMANONOMBRE);
        u.escribirCadena(raf, titulo, TAMANOTITULO);
        String fechass = u.convertirDateEnString(fecha);
        u.escribirCadena(raf, fechass, TAMANOFECHA);

    }

    void guardarUsuario(RandomAccessFile raf) throws IOException {
        int posicion = codigo * TAMANOREGISTRO;
        raf.seek(posicion);
        u.escribirCadena(raf, nombre, TAMANONOMBRE);
        u.escribirCadena(raf, titulo, TAMANOTITULO);
        String fechass = u.convertirDateEnString(fecha);
        u.escribirCadena(raf, fechass, TAMANOFECHA * 2);
    }

    void irARegistro(RandomAccessFile raf, int pos, int tamReg) throws IOException {
        raf.seek(pos * tamReg);
    }

    void borrarUsuario(RandomAccessFile raf, int codes) throws IOException {
        int posicion = codes * TAMANOREGISTRO;
        raf.seek(posicion);
        char[] ceros = new char[TAMANOREGISTRO / 2]; // por defecto se rellenan con \0
        for (int i = 0; i < ceros.length; i++) {
            raf.writeChar(ceros[i]);// escribe el array de bytes
        }
    }

    public Usuario() {

    }

    // constructor que  lleva codigo nuevo codigo como primer parametro
    // Sirve solo apra crear nuevos usuarios en una nueva posiscio
    public Usuario(int nuevocodigo,String nombre, Date fecha, String titulo) {
        this.nombre = nombre;
        this.fecha = fecha;
        this.titulo = titulo;
        this.codigo = nuevocodigo;

    }
    // constructor que si lleva codigo, no cra un nuevo codigo, usa el que se
    // crea en este constructor
    public Usuario(String nombre, Date fecha, String titulo, int codigoyaexistente) {
        this.nombre = nombre;
        this.fecha = fecha;
        this.titulo = titulo;
        this.codigo = codigoyaexistente;
    }


    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public Date getFecha() {
        return fecha;
    }

    public int getCodigo() {
        return codigo;
    }

    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

}

