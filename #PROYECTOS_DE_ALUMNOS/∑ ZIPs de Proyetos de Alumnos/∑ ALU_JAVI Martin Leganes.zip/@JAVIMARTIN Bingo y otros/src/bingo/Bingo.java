import java.util.Random;


public class Bingo {

    MotorBingo mb = new MotorBingo();

    public static void main(String[] args) {
        Bingo b = new Bingo();
        b.iniciar();
    }

    public void iniciar() {
        Carton carton = new Carton();
        mb.pintarCartonMonitor(carton);
        mb.rellenarCarton(carton);
        mb.pintarCartonMonitor(carton);
    }


}


class MotorBingo {


    /**
     * Rellena un carton con numeros
     * Valida que en cada columna se coloquen los numeros de la decena correspondiente
     * Valida que en cada columna no haya tres numeros
     * Valida que no existan numeros repetidos
     * No valida que existan numeros en todas las columnas (puede haber columnas sin numeros)
     * @param carton carton que se va a rellenar
     */
    public void rellenarCarton(Carton carton) {
        int elegido, columna;
        int totalNumerosAgregadosEnUnaFila = 0;
        boolean existeElNumeroEnELCarton = false;
        boolean hayDosNumerosYaEnLaColumna = false;
        for (int fila = 0; fila < 3; fila++) {
            totalNumerosAgregadosEnUnaFila = 0;
            while (totalNumerosAgregadosEnUnaFila < 5) {
                elegido = Ut.azar(1, 90);
                columna = (int) elegido / 10;
                existeElNumeroEnELCarton = verSiExisteElNumeroEnELCarton(carton, elegido);
                hayDosNumerosYaEnLaColumna = verSiHayDosNumerosYaEnLaColumna(carton, columna);
                if (existeElNumeroEnELCarton == false && hayDosNumerosYaEnLaColumna == false) {
                    if (carton.tabla[fila][columna] == 0) {
                        carton.tabla[fila][columna] = elegido;
                        totalNumerosAgregadosEnUnaFila++;
                    }
                }
            }
        }
    }

    public void pintarCartonMonitor(Carton carton) {
        System.out.println("\n******************************************");
        for (int fila = 0; fila < 3; fila++) {
            for (int columna = 0; columna < 9; columna++) {
                String numstr = Ut.dosCifras(carton.tabla[fila][columna]);
                if (numstr.equals(" 0")) {
                    numstr = "--";
                }
                System.out.print(numstr);

                if (columna < 8) {
                    System.out.print("   ");
                }
            }
            System.out.println();
        }
        System.out.println("******************************************\n");
    }


    public boolean verSiExisteElNumeroEnELCarton(Carton carton, int numero) {
        boolean existe = false;
        for (int fila = 0; fila < 3; fila++) {
            for (int columna = 0; columna < 9; columna++) {
                if (carton.tabla[fila][columna] == numero) {
                    existe = true;
                }
            }
        }
        return existe;
    }

    public boolean verSiHayDosNumerosYaEnLaColumna(Carton carton, int columna) {
        int cuantos = 0;
        for (int fila = 0; fila < 3; fila++) {
            if (carton.tabla[fila][columna] != 0) {
                cuantos++;
            }
        }
        if (cuantos > 1) {
            return true;
        }
        return false;
    }
}

class Carton {
    int[][] tabla;
    Carton() {
        tabla = new int[3][9];
    }
}


class Ut {
    public static int azar(int min, int max) {
        Random r = new Random();
        int s = r.nextInt(max - min) + 1;
        return s;
    }
    public static String dosCifras(int numero) {
        if (numero < 10) {
            return " " + numero;
        }
        return "" + numero;
    }
}
