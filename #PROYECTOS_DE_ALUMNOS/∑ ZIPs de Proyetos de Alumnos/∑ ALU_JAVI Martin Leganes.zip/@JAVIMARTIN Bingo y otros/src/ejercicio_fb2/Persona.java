package ejercicio_fb2;

import java.util.StringTokenizer;

public class Persona {
    private String nombre;
    private String telefono;
    private int diac;
    private int mesc;
    private boolean espersonal;

    public Persona(String nombre, String telefono, int diac, int mesc, boolean espersonal) {
        this.nombre = nombre;
        this.telefono = telefono;
        this.diac = diac;
        this.mesc = mesc;
        this.espersonal = espersonal;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public int getDiac() {
        return diac;
    }

    public void setDiac(int diac) {
        this.diac = diac;
    }

    public int getMesc() {
        return mesc;
    }

    public void setMesc(int mesc) {
        this.mesc = mesc;
    }

    public boolean isEspersonal() {
        return espersonal;
    }

    public void setEspersonal(boolean espersonal) {
        this.espersonal = espersonal;
    }
}
