package ejercicio_fb2;


import java.io.*;
import java.util.Calendar;

public class AgendaConFicheros {

    static String nombrefichero = "agenda.dat";

    public static void main(String[] args) {
        File file1 = new File(nombrefichero);
        int opc = 1;
        int cont = 0;
        int numMatricula = 0;
        Teclado t = new Teclado();
        do {
            System.out.println("1- Dar de alta a una persona");
            System.out.println("2- Dar de baja a una persona");
            System.out.println("3- Mostrar personas que cumplen hoy años o mañana");
            System.out.println("4- Consultar persona por nombre");
            System.out.println("5- Mostrar numero de personas almacenadas");
            System.out.println("6- Crear fichero de contactos personales");
            System.out.println("7- Mostrar todo");
            System.out.println("0- Fin");
            opc = t.leerInt();

            switch (opc) {
                case 1:
                    alta();
                    break;
                case 2:
                    baja();
                    break;
                case 3:
                    cumplehoy();
                    break;
                case 4:
                    consulta();
                    break;
                case 5:
                    numeropersonas();
                    break;
                case 6:
                    crearficheropersonales();
                    break;
                case 7:
                    todo();
                    break;
                case 0:
                    break;
            }

        } while (opc != 0);
    }


    public static void numeropersonas() {
        String n, t;
        int d, m;
        boolean p;
        int contador = 0;
        DataInputStream dis = null;
        try {
            dis = new DataInputStream(new FileInputStream(nombrefichero));
            while (true) {
                n = dis.readUTF();      // leo cada persona del fichero
                t = dis.readUTF();
                d = dis.readInt();
                m = dis.readInt();
                p = dis.readBoolean();
                contador++;
            }
        } catch (EOFException e) {
            // fin de fichero controlado
        } catch (FileNotFoundException e) {
            System.out.println("No existe un fichero de agenda, debe crear algun contacto al menos");
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                if (dis != null)
                    dis.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        System.out.println("Personas en la agenda: " + contador);
    }


    public static void consulta() {
        Teclado te = new Teclado();
        String n, t;
        int d, m;
        boolean p;
        System.out.println("Datos de la persona a consultar");
        System.out.println("Nombre");
        String nom = te.leerString();
        boolean encontrada = false;

        DataInputStream dis = null;
        try {
            dis = new DataInputStream(new FileInputStream(nombrefichero));
            while (true) {
                n = dis.readUTF();      // leo cada persona del fichero
                t = dis.readUTF();
                d = dis.readInt();
                m = dis.readInt();
                p = dis.readBoolean();
                if (n.equalsIgnoreCase(nom)) {  // es la pesona a consultar
                    encontrada = true;
                    System.out.println("Nombre: " + n);
                    System.out.println("Telefono: " + t);
                    System.out.println("Dia de nacimiento: " + d);
                    System.out.println("Mes de nacimiento: " + m);
                    System.out.println("Es telefono personal?: " + p);
                }
            }
        } catch (EOFException e) {
            // fin de fichero controlado
        } catch (FileNotFoundException e) {
            System.out.println("No existe un fichero de agenda, debe crear algun contacto al menos");
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                if (dis != null)
                    dis.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        if (encontrada == false) {
            System.out.println("Persona no encontrada");
        }

    }

    public static void todo() {
        String n, t;
        int d, m;
        boolean p;


        DataInputStream dis = null;
        try {
            dis = new DataInputStream(new FileInputStream(nombrefichero));
            while (true) {
                n = dis.readUTF();      // leo cada persona del fichero
                t = dis.readUTF();
                d = dis.readInt();
                m = dis.readInt();
                p = dis.readBoolean();
                System.out.println("Nombre: " + n);
                System.out.println("Telefono: " + t);
                System.out.println("Dia de nacimiento: " + d);
                System.out.println("Mes de nacimiento: " + m);
                System.out.println("Es telefono personal?: " + p);
                System.out.println();
            }
        } catch (EOFException e) {
            // fin de fichero controlado
        } catch (FileNotFoundException e) {
            System.out.println("No existe un fichero de agenda, debe crear algun contacto al menos");
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                if (dis != null)
                    dis.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }


    }


    public static void alta() {
        Teclado te = new Teclado();
        System.out.println("Datos de la persona a dar de alta");
        System.out.println("Nombre");
        String n = te.leerString();
        System.out.println("Telefono");
        String t = te.leerString();
        System.out.println("Dia de cumpleaños");
        int d = te.leerInt();
        System.out.println("Mes de cumpleaños");
        int m = te.leerInt();
        System.out.println("¿Personal (S) o Trabajo (T)");
        String per = te.leerString();
        boolean p = false;
        if (per.equalsIgnoreCase("S")) {
            p = true;
        }
        //        Persona pe = new Persona(nom,tel,dia,mes,espersonal);
        DataOutputStream dos = null;
        try {
            dos = new DataOutputStream(new FileOutputStream(nombrefichero, true));
            dos.writeUTF(n);
            dos.writeUTF(t);
            dos.writeInt(d);
            dos.writeInt(m);
            dos.writeBoolean(p);
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                if (dos != null)
                    dos.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }


    public static void baja() {
        Teclado te = new Teclado();
        String n, t;
        int d, m;
        boolean p;
        System.out.println("Datos de la persona a borrar");
        System.out.println("Nombre");
        String nom = te.leerString();

        DataInputStream dis = null;
        DataOutputStream dos = null;
        try {
            dis = new DataInputStream(new FileInputStream(nombrefichero));
            dos = new DataOutputStream(new FileOutputStream("TEMP.DAT"));
            while (true) {
                n = dis.readUTF();      // leo cada persona del fichero
                t = dis.readUTF();
                d = dis.readInt();
                m = dis.readInt();
                p = dis.readBoolean();
                if (!n.equalsIgnoreCase(nom)) {  // no es la pesona a eliminar,  sus datos los copio en temp
                    dos.writeUTF(n);
                    dos.writeUTF(t);
                    dos.writeInt(d);
                    dos.writeInt(m);
                    dos.writeBoolean(p);
                }
            }
        } catch (EOFException e) {
            // fin de fichero controlado
        } catch (FileNotFoundException e) {
            System.out.println("No existe un fichero de agenda, debe crear algun contacto al menos");
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                if (dis != null)
                    dis.close();
                if (dos != null)
                    dos.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        // borro el original fichero y renombre el temp
        File file1 = new File(("TEMP.DAT"));
        File file2 = new File(nombrefichero);
        file1.delete();
        file2.renameTo(file1);

    }

    public static void crearficheropersonales() {
        String n, t;
        int d, m;
        boolean p;
        System.out.println("El fichero de copia se llamara PERSONALES.DAT");

        DataInputStream dis = null;
        DataOutputStream dos = null;
        try {
            dis = new DataInputStream(new FileInputStream(nombrefichero));
            dos = new DataOutputStream(new FileOutputStream("PERSONALES.DAT"));
            while (true) {
                n = dis.readUTF();      // leo cada persona del fichero
                t = dis.readUTF();
                d = dis.readInt();
                m = dis.readInt();
                p = dis.readBoolean();
                if (p == true) {            // es un dato personal,  sus datos los copio en temp
                    dos.writeUTF(n);
                    dos.writeUTF(t);
                    dos.writeInt(d);
                    dos.writeInt(m);
                    dos.writeBoolean(p);
                }
            }
        } catch (EOFException e) {
            // fin de fichero controlado
        } catch (FileNotFoundException e) {
            System.out.println("No existe un fichero de agenda, debe crear algun contacto al menos");
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                if (dis != null)
                    dis.close();
                if (dos != null)
                    dos.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    public static void cumplehoy() {

        String n, t;
        int d, m;
        boolean p;
        Calendar c1 = Calendar.getInstance();
        int diadehoy = c1.get(Calendar.DATE);
        int mesdehoy = c1.get(Calendar.MONTH) + 1;

        DataInputStream dis = null;
        try {
            dis = new DataInputStream(new FileInputStream(nombrefichero));
            while (true) {
                n = dis.readUTF();      // leo cada persona del fichero
                t = dis.readUTF();
                d = dis.readInt();
                m = dis.readInt();
                p = dis.readBoolean();
                if (diadehoy == d && mesdehoy == m) {  // cumple hoy
                    System.out.println(n + " cumple años hoy!!!");
                }
            }
        } catch (EOFException e) {
            // fin de fichero controlado
        } catch (FileNotFoundException e) {
            System.out.println("No existe un fichero de agenda, debe crear algun contacto al menos");
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                if (dis != null)
                    dis.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}
