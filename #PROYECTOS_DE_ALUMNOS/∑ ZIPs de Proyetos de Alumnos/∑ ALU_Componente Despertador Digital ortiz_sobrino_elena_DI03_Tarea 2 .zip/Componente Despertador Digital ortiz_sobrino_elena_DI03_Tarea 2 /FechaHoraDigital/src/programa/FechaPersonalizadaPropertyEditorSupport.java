/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

//import FechaPersonalizadaPanel;
import java.awt.Component;
import java.beans.PropertyEditorSupport;

/**
 *
 * @author elena
 */
public class FechaPersonalizadaPropertyEditorSupport extends PropertyEditorSupport {

    private FechaPersonalizadaPanel fecha = new FechaPersonalizadaPanel();

    @Override
    public boolean supportsCustomEditor() {
        return true;
    }

    //método que indica de que clase es el custom editor que se debe usar
    @Override
    public Component getCustomEditor() {
        return fecha;
    }

    @Override
    public String getJavaInitializationString() {
        return "new programa.FechaPersonalizada("
                + fecha.getSelectedValue().getDia() + "," 
                + fecha.getSelectedValue().getMes()+ ","
                + fecha.getSelectedValue().getAnio()+ ","
                + fecha.getSelectedValue().getHora()+ ","
                + fecha.getSelectedValue().getMinuto()+ ","
                + fecha.getSelectedValue().getSegundo()+
                ")";
    }

    //método que nos permite recuperar la información introducida en el custom editor.
    @Override
    public Object getValue() {
        return fecha.getSelectedValue();
    }

}
