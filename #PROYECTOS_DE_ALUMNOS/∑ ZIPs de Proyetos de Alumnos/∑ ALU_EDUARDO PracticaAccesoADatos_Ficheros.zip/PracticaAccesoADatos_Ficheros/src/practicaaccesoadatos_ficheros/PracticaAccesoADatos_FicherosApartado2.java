package practicaaccesoadatos_ficheros;

//Enunciado.
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import org.w3c.dom.NodeList;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.Element;
import javax.xml.parsers.*;
import org.w3c.dom.NamedNodeMap;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.XMLReaderFactory;

//Apartado 1) (5 puntos) Realiza las siguientes acciones utilizando NetBeans:
//
//(2,5 puntos) Crear un fichero EMPLEADOS.DAT de acceso aleatorio, 
// que contenga al menos cinco empleados. 
// Dicho fichero contendrá los campos siguientes: CODIGO (int), NOMBRE (string), DIRECCION (string), SALARIO (float) y COMISION (float).
//(2,5 puntos) A partir de los datos del fichero EMPLEADOS.DAT crear un fichero llamado EMPLEADOS.XML usando DOM.
//Apartado 2) (5 puntos) Visualizar todas las etiquetas del fichero LIBROS.XML utilizando las técnicas DOM y SAX
public class PracticaAccesoADatos_FicherosApartado2 {

     private static ArrayList<Libro> listaLibros;
     private static Document miDocDom = null;

     public static void main(String[] args) {

          // --------------------    con DOM
          leerFicheroXmlconDom();
          crearArrayConDocumentDeDom();
          // ver resultados DOM
          System.out.println("======== RESULTADOS CON DOM ==========");
          for (Libro l : listaLibros) {
               System.out.println(l);
          }

          // --------------------    con SAX
          leerFicheroXmlconSax();
          // ver resultados SAX
          System.out.println("======== RESULTADOS CON SAX ==========");
          for (Libro l : listaLibros) {
               System.out.println(l);
          }

     }

     public static void leerFicheroXmlconDom() {
          try {
               DocumentBuilderFactory builderFactory = DocumentBuilderFactory.newInstance();
               DocumentBuilder builder = builderFactory.newDocumentBuilder();
               miDocDom = builder.parse(new FileInputStream("libros.xml"));
          } catch (Exception e1) {
               e1.printStackTrace();
          }
     }

     public static void crearArrayConDocumentDeDom() {
          Node nodo_raiz = null, nodo_libros = null, nodo_libro = null, nodo_titulo = null, nodo_año = null, nodo_autor = null, nodo_apellido = null, nodo_nombre = null, nodo_editorial = null, nodo_precio = null;
          String titulo, año, autor, apellido, nombre, editorial, precio;
          listaLibros = new ArrayList<>();

          // cogemos el nodo raiz 
          nodo_raiz = miDocDom.getDocumentElement();

          // cogemos todos los nodos de tipo Libro, que sean hjos del nodo raiz
          NodeList listaHijosRaiz = ((Element) nodo_raiz).getElementsByTagName("libro");

          // recorremos el array de nodos libro
          for (int t = 0; t < listaHijosRaiz.getLength(); t++) {
               // cogemos un nodo_libro en cada vuelta del bucle
               nodo_libro = listaHijosRaiz.item(t);

               // NODOS SIMPLES --------
               // cogemos los valores de cada uno de los nodos hijos simples de un libro
               titulo = getValorNodoHijoSimple("titulo", nodo_libro);
               editorial = getValorNodoHijoSimple("editorial", nodo_libro);
               precio = getValorNodoHijoSimple("precio", nodo_libro);

               // cogemos los atributos de los nodos que tengan atributo
               año = getValorAtributo("año", nodo_libro);


               // NODOS MULTIPLES ------ (repetimos el proceso con los Autores que estamos haciendo con los Libros)
               // cogemos todos los nodos de tipo Autor, que sean hjos del nodo libro actual
               NodeList listaNodosAutores = ((Element) nodo_libro).getElementsByTagName("autor");
               // creamos un array de autors donde meter todos los autores de este libro
               ArrayList<Autor> listaAutores = new ArrayList<>();
               // recorremos el array de nodos libro
               for (int w = 0; w < listaNodosAutores.getLength(); w++) {
                    // cogemos un nodo_autor en cada vuelta del bucle
                    nodo_autor = listaNodosAutores.item(w);
                    // cogemos los valores de cada uno de los nodos hijos simples de un libro
                    apellido = getValorNodoHijoSimple("apellido", nodo_autor);
                    nombre = getValorNodoHijoSimple("nombre", nodo_autor);
                    // FIN DE BUCLE de autor
                    // con lo que hemos sacado, creamos un Autor y lo añadirmo a la lista de autores
                    Autor a = new Autor(apellido, nombre);
                    listaAutores.add(a);
               }

               // FIN DE BUCLE de libro
               // con lo que hemos sacado, creamos un Libro y lo añadirmo a la lista de libros
               Libro lib = new Libro(titulo, Integer.parseInt(año), listaAutores, editorial, Double.parseDouble(precio));
               listaLibros.add(lib);
          }
     }


     public static String getValorNodoHijoSimple(String etiquetaABuscar, Node nodoPadre) {
          // convertimos el Node en un element para poder procesarlo mejor
          Element elementoPadre = (Element) nodoPadre;
          String resultado = "";
          // sacar una lista de todos los hijos de nodoPadre que se llamen como "etiquetaABuscar"
          NodeList listaNodosHijos = elementoPadre.getElementsByTagName(etiquetaABuscar);
          // sacar el primer nodo de la lista previa 
          // (por que estamos sacando nodos simples, solo debe haber un nodo en la lista)
          Node nodosimple = listaNodosHijos.item(0);
          if (nodosimple != null) {
               // sacar del nodosimple su único hijo, que es el TEXTO-CONTENIDO del nodo
               // Cuidado que el contenido es aun ... otro nodo
               Node nodoContenido = nodosimple.getFirstChild();
               // sacar EL TEXTO del nodoContenido (su valor) 
               resultado = nodoContenido.getNodeValue();
          }
          return resultado;
     }

     public static String getValorAtributo(String atributoABuscar, Node nodoPadre) {
          String resultado = "";
          // de un nodo, sacamos la lista de sus atributos
          NamedNodeMap listaatributos = nodoPadre.getAttributes();
          // de la lista de atributos, sacamos aquel que tenga el nombre que buscamos
          Node attr = listaatributos.getNamedItem(atributoABuscar);
          if (attr != null) {
               resultado = attr.getNodeValue();
          }
          return resultado;
     }
     
     public static void leerFicheroXmlconSax() {
          try {
               // Creamos un analizador de XML con una fábrica de analizadores 
               ControladorSaxLectura miControlador = new ControladorSaxLectura();
               XMLReader xmlreader = XMLReaderFactory.createXMLReader();
               // Añadimos nuestro handler al analizador 
               xmlreader.setContentHandler(miControlador);
               // Analizamos con el analizador el xml deseado 
               xmlreader.parse(new InputSource(new FileInputStream("libros.xml")));
               // Recogemos del controlador la lista de libros leidos 
               listaLibros = miControlador.getListaLibros();
          } catch (SAXException e) {
               e.printStackTrace();
          } catch (IOException e) {
               e.printStackTrace();
          }
     }

}
