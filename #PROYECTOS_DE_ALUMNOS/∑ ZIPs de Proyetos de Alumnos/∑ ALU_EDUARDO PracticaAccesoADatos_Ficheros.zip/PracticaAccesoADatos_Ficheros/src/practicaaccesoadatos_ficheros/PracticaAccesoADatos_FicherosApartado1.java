package practicaaccesoadatos_ficheros;

import com.sun.org.apache.xml.internal.serialize.OutputFormat;
import com.sun.org.apache.xml.internal.serialize.XMLSerializer;
import java.io.EOFException;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.xml.parsers.*;
import org.w3c.dom.DOMImplementation;
import org.w3c.dom.Document;
import org.w3c.dom.Node;

//Enunciado.
//Apartado 1) (5 puntos) Realiza las siguientes acciones utilizando NetBeans:
//
//(2,5 puntos) Crear un fichero EMPLEADOS.DAT de acceso aleatorio, 
// que contenga al menos cinco empleados. 
// Dicho fichero contendrá los campos siguientes: CODIGO (int), NOMBRE (string), DIRECCION (string), SALARIO (float) y COMISION (float).
//(2,5 puntos) A partir de los datos del fichero EMPLEADOS.DAT crear un fichero llamado EMPLEADOS.XML usando DOM.
//Apartado 2) (5 puntos) Visualizar todas las etiquetas del fichero LIBROS.XML utilizando las técnicas DOM y SAX

public class PracticaAccesoADatos_FicherosApartado1 {

     private static ArrayList<Empleado> listaEmpleados;

     public static void main(String[] args) {

          crearFicheroAleatorio();

          leerFicheroDat();

          pasarAXmlConDOM();

     }

     public static void pasarAXmlConDOM() {

          Node nodo_raiz, nodo_empleado, nodo_nombre, nodo_direccion, nodo_salario, nodo_comision, nodo_codigo,
                  nodo_nombre_texto, nodo_direccion_texto, nodo_salario_texto, nodo_comision_texto, nodo_codigo_texto;

          Document miDocDom = null; //Objeto Document que almacena el DOM del XML seleccionado.
          try {
               DocumentBuilderFactory builderFactory = DocumentBuilderFactory.newInstance();
               DocumentBuilder builder = builderFactory.newDocumentBuilder();
               DOMImplementation implementation = builder.getDOMImplementation();
               String nombreDelNodoRaiz = "lista_empleados";
               miDocDom = implementation.createDocument(null, nombreDelNodoRaiz, null);
               miDocDom.setXmlVersion("1.0");
               //-- Crear los nodos de todas las etiquetas generales
               nodo_raiz = miDocDom.getDocumentElement();

               // recorrer el arraylist de empleados
               for (Empleado em : listaEmpleados) {
                    //-- Crear los nodos de todas las etiquetas del empleado
                    nodo_empleado = miDocDom.createElement("empleado");
                    nodo_nombre = miDocDom.createElement("nombre");
                    nodo_direccion = miDocDom.createElement("direccion");
                    nodo_salario = miDocDom.createElement("salario");
                    nodo_comision = miDocDom.createElement("comision");
                    nodo_codigo = miDocDom.createElement("codigo");

                    //-- Crear los nodos de texto con los valores de cada empleado
                    nodo_nombre_texto = miDocDom.createTextNode(em.getNombre());
                    nodo_direccion_texto = miDocDom.createTextNode(em.getDireccion());
                    nodo_salario_texto = miDocDom.createTextNode(em.getSalario() + "");
                    nodo_comision_texto = miDocDom.createTextNode(em.getComision() + "");
                    nodo_codigo_texto = miDocDom.createTextNode(em.getCodigo() + "");

                    //-- Añadir a cada nodo su texto
                    nodo_nombre.appendChild(nodo_nombre_texto);
                    nodo_direccion.appendChild(nodo_direccion_texto);
                    nodo_salario.appendChild(nodo_salario_texto);
                    nodo_comision.appendChild(nodo_comision_texto);
                    nodo_codigo.appendChild(nodo_codigo_texto);

                    //-- Añadir cada nodo a su padre
                    nodo_empleado.appendChild(nodo_codigo);
                    nodo_empleado.appendChild(nodo_nombre);
                    nodo_empleado.appendChild(nodo_direccion);
                    nodo_empleado.appendChild(nodo_salario);
                    nodo_empleado.appendChild(nodo_comision);

                    nodo_raiz.appendChild(nodo_empleado);
               }

          } catch (Exception e) {
               e.printStackTrace();
          }

          try {
               File archivo_xml = new File("EMPLEADOS.XML");
               OutputFormat format = new OutputFormat(miDocDom);
               format.setIndenting(true);
               XMLSerializer serializer = new XMLSerializer(new FileOutputStream(archivo_xml), format);
               serializer.serialize(miDocDom);
          } catch (IOException e) {
               e.printStackTrace();
          } catch (ClassCastException ex) {
               Logger.getLogger(PracticaAccesoADatos_FicherosApartado1.class.getName()).log(Level.SEVERE, null, ex);
          }
     }

     public static void leerFicheroDat() {
          RandomAccessFile fichero = null;

          try {
               listaEmpleados = new ArrayList<>();
               fichero = new RandomAccessFile("EMPLEADOS.DAT", "r");

               while (1 == 1) {
                    int cod = fichero.readInt();
                    String nom = fichero.readUTF();
                    String dir = fichero.readUTF();
                    float salario = fichero.readFloat();
                    float comision = fichero.readFloat();
                    nom = nom.trim();
                    dir = dir.trim();
                    Empleado empleado = new Empleado(cod, nom, dir, salario, comision);

                    listaEmpleados.add(empleado);
                    System.out.println(empleado);
               }
          } catch (EOFException ex) {
               System.out.println("Lectura de fichero terminada. Seguimos.");
          } catch (FileNotFoundException ex) {
               ex.printStackTrace();
          } catch (IOException ex) {
               ex.printStackTrace();
          } catch (Exception ex) {
               ex.printStackTrace();
          } finally {
               try {
                    fichero.close();
               } catch (IOException ex) {
                    Logger.getLogger(PracticaAccesoADatos_FicherosApartado1.class.getName()).log(Level.SEVERE, null, ex);
               }
          }

     }

     public static void crearFicheroAleatorio() {
          RandomAccessFile fichero = null;

          try {
               listaEmpleados = new ArrayList<>();
               Empleado empleado1 = new Empleado(1, "Juan", "Calle", 3200, 200);
               Empleado empleado2 = new Empleado(2, "Pepe", "Plaza", 3200, 200);
               Empleado empleado3 = new Empleado(3, "Luis", "Avenida", 3200, 200);
               Empleado empleado4 = new Empleado(4, "Cesar", "Villa", 3200, 200);
               Empleado empleado5 = new Empleado(5, "Nacho", "Pueblo", 3200, 200);

               listaEmpleados.add(empleado1);
               listaEmpleados.add(empleado2);
               listaEmpleados.add(empleado3);
               listaEmpleados.add(empleado4);
               listaEmpleados.add(empleado5);

               fichero = new RandomAccessFile("EMPLEADOS.DAT", "rw");

               for (Empleado empleado : listaEmpleados) {
                    fichero.writeInt(empleado.getCodigo());
                    String nom = rellenarConEspacios(empleado.getNombre(), 30);
                    fichero.writeUTF(nom);
                    String dir = rellenarConEspacios(empleado.getDireccion(), 100);
                    fichero.writeUTF(dir);
                    fichero.writeFloat(empleado.getSalario());
                    fichero.writeFloat(empleado.getComision());
               }

          } catch (FileNotFoundException ex) {
               ex.printStackTrace();
          } catch (IOException ex) {
               ex.printStackTrace();
          } catch (Exception ex) {
               ex.printStackTrace();
          } finally {
               try {
                    fichero.close();
               } catch (IOException ex) {
                    Logger.getLogger(PracticaAccesoADatos_FicherosApartado1.class.getName()).log(Level.SEVERE, null, ex);
               }
          }
     }

     public static String rellenarConEspacios(String elque, int cuanto) {
          int cuantofalta = cuanto - elque.length();
          for (int i = 0; i < cuantofalta; i++) {
               elque = elque + " ";
          }
          return elque;
     }

}
