/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practicaaccesoadatos_ficheros;

import java.util.ArrayList;

/**
 *
 * @author Eduardo
 */
public class Libro {

     private String titulo;
     private ArrayList<Autor> autores;
     private String editorial;
     private double precio;
     private int año;

     public Libro(String titulo, int año, ArrayList<Autor> autores, String editorial, double precio) {
          this.titulo = titulo;
          this.autores = autores;
          this.editorial = editorial;
          this.precio = precio;
          this.año = año;
     }
     public Libro() {
     }

     public String getTitulo() {
          return titulo;
     }

     public void setTitulo(String titulo) {
          this.titulo = titulo;
     }

     public ArrayList<Autor> getAutores() {
          return autores;
     }

     public void setAutores(ArrayList<Autor> autores) {
          this.autores = autores;
     }

     public String getEditorial() {
          return editorial;
     }

     public void setEditorial(String editorial) {
          this.editorial = editorial;
     }

     public double getPrecio() {
          return precio;
     }

     public void setPrecio(double precio) {
          this.precio = precio;
     }

     public int getAño() {
          return año;
     }

     public void setAño(int año) {
          this.año = año;
     }


     @Override
     public String toString() {
          String res = "Libro{\n" + "\t titulo=" + titulo + "\n\t autores=\n";
          for (Autor a : autores) {
              res = res + "            "+ a + "\n";
          }
          res = res +"\t año=" + año+ "\n\t editorial=" + editorial + "\n\t precio=" + precio + "\n}";
          return res;
     }


}
