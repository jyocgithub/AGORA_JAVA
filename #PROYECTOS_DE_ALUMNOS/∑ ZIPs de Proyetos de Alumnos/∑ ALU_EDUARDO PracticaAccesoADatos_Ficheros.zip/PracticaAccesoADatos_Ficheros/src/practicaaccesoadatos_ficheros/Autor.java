/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practicaaccesoadatos_ficheros;

/**
 *
 * @author Eduardo
 */
public class Autor {

    private String apellido;
    private String nombre;

    public Autor(String apellido, String nombre) {
        this.apellido = apellido;
        this.nombre = nombre;
    }

    public Autor() {
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

     @Override
     public String toString() {
          return "Autor{" + "apellido=" + apellido + ", nombre=" + nombre + '}';
     }

}
