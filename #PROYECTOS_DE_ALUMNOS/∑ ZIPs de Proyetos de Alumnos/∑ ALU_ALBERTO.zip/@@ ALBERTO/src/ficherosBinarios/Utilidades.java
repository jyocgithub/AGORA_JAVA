package ficherosBinarios;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.Scanner;

/**
 *
 * @author IMS
 */
public class Utilidades {

	/**
	 * 
	 * Devuelve un int leido por Scanner por System.in TODO añadir validacion de que es un entero
	 * 
	 * @param
	 * @author IMS
	 */
	public int leerInt() {
		int res = 0;
		Scanner sc = new Scanner(System.in);
		res = sc.nextInt();
		return res;
	}

	/**
	 * 
	 * Devuelve un String ledi por Scanner por System.in TODO añadir validacion de que es un String (
	 * 
	 * @param
	 * @author IMS
	 */
	public String leerString() {
		String res = "";
		Scanner scannerPru = new Scanner(System.in);
		res = scannerPru.nextLine();
		return res;
	}

	/**
	 * 
	 * Devuelve el array ordenado ascendentemente si el valor de direcion es 0, o descendientemiente, si el valor de ordenacion es 1
	 * TODO añadir direccion
	 * 
	 * @param int[]m
	 *            array de integers a ordenar
	 * @author IMS
	 */
	public void ordenarArrayIntPorBurbuja(int[] m) {
		// variable auxiliar utilizada para el
		// intercambio de datos en el array
		int aux;

		// recorre todas las posiciones del array
		for (int i = 0; i < m.length; i++) {
			// el segundo for se utiliza para comparar el
			// valor de la posición actual con las siguientes
			for (int j = i + 1; j < m.length; j++) {
				// si uno de los siguientes valores es inferior
				// al actual, procede al intercambio de las
				// posiciones del array
				if (m[j] < m[i]) {
					aux = m[i];
					m[i] = m[j];
					m[j] = aux;
				}
			}
		}

	}

	/**
	 * Metodo para ordenar un List de Arrays de String
	 *
	 */
	public static void burbujaConListDeArray(ArrayList<String[]> listaDeArr, int indice) {
		// recorre todas las posiciones del array
		for (int i = 0; i < listaDeArr.size(); i++) {
			// este for anidado se usa para comparar el valor de la posición actual
			// con todas las siguientes
			for (int j = i + 1; j < listaDeArr.size(); j++) {
				// si uno de los siguientes valores es inferior al actual,
				// procede al intercambio de las posiciones del array
				String[] aux;
				if (listaDeArr.get(i)[indice].compareTo(listaDeArr.get(j)[indice]) < 0) {
					aux = listaDeArr.get(i);
					listaDeArr.set(i, listaDeArr.get(j));
					listaDeArr.set(j, aux);

				}

			}
		}
	}

	/**
	 * Metodo para leer un fichero de texto en que cada linea es un grupo de datos
	 *
	 */
	public ArrayList<String[]> LeerFicheroTextoConSeparadorDeCampo(File ruta, String pFichero, String separador) {

		ArrayList<String[]> datos = null;
		try {
			datos = new ArrayList<>();

			File filres = new File(ruta.getAbsolutePath(), pFichero);

			FileInputStream fis = new FileInputStream(filres);
			// para ficheros con símbolos propios del español,
			// utilizar la codificación "ISO-8859-1"
			InputStreamReader isr = new InputStreamReader(fis, "UTF8");
			BufferedReader br = new BufferedReader(isr);

			String linea = br.readLine();
			while (linea != null) {
				datos.add(linea.split(separador));
				linea = br.readLine();
			}

			br.close();
			isr.close();
			fis.close();
		} catch (IOException e) {
			e.printStackTrace();
		}

		return datos;

	}

	/**
	 * Metodo para leer un fichero de texto en que cada linea es un UNICO dato
	 *
	 */
	public ArrayList<String> LeerFicheroTexto(String fichero_a_leer)

			throws IOException {

		ArrayList<String> datos = new ArrayList<>();

		FileInputStream fis = new FileInputStream(fichero_a_leer);
		// para ficheros con símbolos propios del español,
		// utilizar la codificación "ISO-8859-1"
		InputStreamReader isr = new InputStreamReader(fis, "UTF8");
		BufferedReader br = new BufferedReader(isr);

		String linea = br.readLine();
		while (linea != null) {
			datos.add(linea);
			linea = br.readLine();
		}

		br.close();
		isr.close();
		fis.close();

		return datos;
	}

	/**
	 * intAleatorio y booleanAleatorio
	 *
	 * DEVUELVEN UN ENTERO ALEATORIO EN UN RANGO DETERMINADO DEVUELVEN UN BOOLEAE ALEATORIO
	 *
	 */
	public int intAleatorio(int min, int max) {
		return (int) (Math.random() * (max - min + 1) + min);
	}

	public boolean booleanAleatorio() {
		// mantenemos la formula aunque sea sin operar operandos, para recordarla
		if ((int) (Math.random() * (1 - 0 + 1) + 0) == 0)
			return false;
		else
			return true;
	}

	/**
	 * Metodo que devuelve la fecha de hoy en String "DD/MM/AA"
	 *
	 */
	public String fechaDeHoy() {
		Calendar fecha = new GregorianCalendar();
		int año = fecha.get(Calendar.YEAR);
		int mes = fecha.get(Calendar.MONTH);
		int dia = fecha.get(Calendar.DAY_OF_MONTH);
		return dia + "/" + (mes + 1) + "/" + año;
	};

	/**
	 * Metodo que devuelve la hora actual en String "HH:MM:SS"
	 *
	 */
	public String horaDeHoy() {
		Calendar fecha = new GregorianCalendar();

		int hora = fecha.get(Calendar.HOUR);
		int minuto = fecha.get(Calendar.MINUTE);
		int segundo = fecha.get(Calendar.SECOND);
		return hora + ":" + minuto + ":" + segundo;
	};

	/**
	 * Metodo que devuelve un numero con ceros por delante
	 * 
	 * @author: Iñaki Martin
	 * @param :
	 *            numero original - el numero que se desea convertir numeroDeCharTamanoFinal - el tamaño final de la cadena a
	 *            devolver, con ceros a la izquierda
	 * @return: String con el numero con ceros por delante
	 * 
	 *          Si el numero a convertir es mayor que el tamaño de la cadena solicitada, devuelve el numero original Ejemplos:
	 *          stringConCeros(3, 5) -> 00003 stringConCeros(3234, 8)); -> 00003234 stringConCeros(322, 2) -> 322
	 * 
	 */
	public static String stringConCeros(int numeroOriginal, int numeroDeCharTamanoFinal) {
		int intMaximo = (int) Math.pow(10, numeroDeCharTamanoFinal);
		if (numeroOriginal > intMaximo) return Integer.toString(numeroOriginal);
		return Integer.toString(numeroOriginal + (intMaximo)).substring(1);
	}

	// public static void main(String[] s) {
	//
	// System.out.println(stringConCeros(3, 5));
	// System.out.println(stringConCeros(3234, 8));
	// System.out.println(stringConCeros(322, 2));
	//
	// }

}
