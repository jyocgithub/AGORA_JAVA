package ficherosBinarios;

//Se quiere realizar el mantenimiento de una agenda.
//La agenda se compone de dos ficheros: agenda.dat e indice.dat (ambos RandomAccessFile)
//agenda.dat se compone de apodo(5), nombre(25), telefono(9)
//indice.dat se compone de número de registro y apodo(5)
//Siempre se busca en la agenda a través del apodo del fichero indice.dat.
//Se pide programar el siguiente menú:
//a) Añadir entrada
//b) Buscar entrada
//e) Eliminar entrada (hacer lo último)
//p) Empaquetar ficheros (hacer lo último)
//m) Mostrar toda la agenda
//s) Salir
//Subir el proyecto en formato zip.
public class Persona {
	private String nombre;
	private String apodo;
	private String telefono;

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getApodo() {
		return apodo;
	}

	public void setApodo(String apodo) {
		this.apodo = apodo;
	}

	public String getTelefono() {
		return telefono;
	}

	public void setTelefono(String telefono) {
		this.telefono = telefono;
	}

	public Persona(String n, String a, String t) {
		super();
		this.nombre = n;
		this.apodo = a;
		this.telefono = t;
	}

}