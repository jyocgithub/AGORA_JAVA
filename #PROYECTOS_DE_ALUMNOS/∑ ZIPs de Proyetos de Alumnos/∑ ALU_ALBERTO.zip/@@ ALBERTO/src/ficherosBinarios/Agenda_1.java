package ficherosBinarios;
// VERSION RETOCADA EN ECLIPSE

import java.io.File;
import java.io.IOException;
import java.io.RandomAccessFile;

public class Agenda_1 {
	static Utilidades ut = new Utilidades();

	public static void main(String[] args) {
		int selector = 0;
		do {
			System.out.println("----------- MENU ----------");
			System.out.println("1.- Añadir entrada");
			System.out.println("2.- Buscar entrada");
			System.out.println("3.- Eliminar entrada");
			System.out.println("4.- Empaquetar ficheros  ");
			System.out.println("5.- Mostrar toda la agenda ");
			System.out.println("0.- Salir");
			System.out.println("----- indique opcion: -----");
			selector = ut.leerInt();

			switch (selector) {
			case 1:
				anadirEntrada();
				break;
			case 2:
				buscarEntrada();
				break;

			case 3:
				eliminarEntrada();
				break;
			case 4:
				empaquetarFicheros();
				break;
			case 5:
				mostrarTodos();
				break;
			}
		} while (selector != 0);
		System.out.println("Hasta pronto");

	}

	/**
	 * EMPAQUETAR
	 * 
	 */
	public static void empaquetarFicheros() {
		try {

			// Recorremos uno a uno todos los registros del fichero de agenda.
			// Si encontramos en una posicion un registro LLENO
			// lo escribimos en un fichero auxiliar

			// variables necesarias
			RandomAccessFile indiceAgenda = new RandomAccessFile("indice.dat", "rw");
			RandomAccessFile indiceAgendaTemp = new RandomAccessFile("indiceTemp.dat", "rw");
			int tamanoFicherOriginal = (int) indiceAgenda.length();
			int posFicheroOriginal = 0;
			int posFicheroTemp = 0;
			String bloqueleidoApodo = "";
			String bloqueleido = "";
			int nuevoIndice = 0;
			int indiceLeido = 0;

			// bucle para recorrer el fichero original registro a registro
			for (int j = 0; j <= (tamanoFicherOriginal / 14) - 1; j++) {

				// colocamos el puntero del fichero origen en su sitio
				posFicheroOriginal = (j) * 14;
				indiceAgenda.seek(posFicheroOriginal);

				// Por si me he salido analizo y acabo el bucle
				if (indiceAgenda.getFilePointer() > indiceAgenda.length()) {
					break;
				}

				// leo los dos datos del indice del registro actual (numero indice y apodo)
				indiceLeido = indiceAgenda.readInt();
				bloqueleidoApodo = leerStringDeRandomFile(indiceAgenda, 5);

				// miro ei el registro tiene datos y si es asi entro a copiar
				if (indiceLeido != 0) {

					// coloco el puntero de escritura del temporal para escribir en su sitio
					indiceAgendaTemp.seek(posFicheroTemp);

					// escribo dos datos. El nuevo indice, que sera el que tenia mas uno,
					// y el apodo, que lo tengo ya de antes en bloqueleido
					nuevoIndice++;
					indiceAgendaTemp.writeInt(nuevoIndice);
					indiceAgendaTemp.writeChars(bloqueleidoApodo);

					// incremento el puntero del fichero temporal para la siguiente escritura
					posFicheroTemp = posFicheroTemp + 14;

				}
			}

			// Ahora lo mismo, pero con el fichero agenda.dat
			RandomAccessFile objetoAgenda = new RandomAccessFile("agenda.dat", "rw");
			RandomAccessFile objetoAgendaTemp = new RandomAccessFile("agendaTemp.dat", "rw");
			indiceAgenda.seek(0);
			tamanoFicherOriginal = (int) objetoAgenda.length();
			posFicheroOriginal = 0;
			posFicheroTemp = 0;
			bloqueleido = "";
			nuevoIndice = 0;
			indiceLeido = 0;

			// bucle para recorrer el fichero original registro a registro
			for (int j = 0; j <= (tamanoFicherOriginal / 78) - 1; j++) {

				// colocamos el puntero del fichero origen en su sitio
				posFicheroOriginal = (j) * 78;
				objetoAgenda.seek(posFicheroOriginal);

				// Por si me he salido analizo y acabo el bucle
				if (objetoAgenda.getFilePointer() > objetoAgenda.length()) {
					break;
				}

				// leo los dos datos del indice actual
				bloqueleido = leerStringDeRandomFile(objetoAgenda, 39);

				// miro ei el registro tiene datos y si es asi entro a copiar
				if (!bloqueleido.startsWith("         ")) {

					// me coloco en el temporal para escribir en su sitio
					objetoAgendaTemp.seek(posFicheroTemp);

					// escribo los datos en el fichero temporal
					objetoAgendaTemp.writeChars(bloqueleido);

					// incremento el puntero del fichero temporal para la siguiente escritura
					posFicheroTemp = posFicheroTemp + 78;

				}
			}

			// cierro todos los objetos de randomaccessfile
			objetoAgenda.close();
			objetoAgendaTemp.close();
			indiceAgenda.close();
			indiceAgendaTemp.close();

			// finalmente borramos los ficheros originales y
			// renombramos los temporales como los originales
			File file1 = new File("agenda.dat");
			File file2 = new File("indice.dat");
			File file3 = new File("agendaTemp.dat");
			File file4 = new File("indiceTemp.dat");
			file1.delete();
			file2.delete();
			file3.renameTo(file1);
			file4.renameTo(file2);

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	/**
	 * ELIMINAR ENTRADA
	 * 
	 */
	public static void eliminarEntrada() {
		System.out.println("Introduce apodo de la persona a eliminar");
		String apodo;
		apodo = ut.leerString();
		apodo = rellenar(apodo, 5);
		int indiceBueno = -1;
		try {
			RandomAccessFile indiceAgenda = new RandomAccessFile("indice.dat", "rw");
			indiceAgenda.seek(0);
			int tamanoFichero = (int) indiceAgenda.length();

			// BUSCAR EN INDICE EL APODO Y OBTENER EL NUMERO DE REGISTRO
			// Recorro con un array el fichero, voy sacando uno a uno los registros
			// y miro si son el que estoy buscando
			for (int j = 0; j <= (tamanoFichero / 14) - 1; j++) {
				if (indiceAgenda.getFilePointer() > indiceAgenda.length()) {
					break;
				}
				// Leemos los datos del regitro del índice
				// leemos el primer dato que es un integer
				int indiceLeido = indiceAgenda.readInt();

				// leemos el segundo dato que es un string de 5
				String bloqueleido = leerStringDeRandomFile(indiceAgenda, 5);

				// String bloqueleido = "";
				// for (int i = 0; i < 5; i++) {
				// bloqueleido = bloqueleido + indiceAgenda.readChar();
				// }
				// Comparamos lo leido (bloqueleido) con el texto a buscar (apodo)
				if (bloqueleido.equalsIgnoreCase(apodo)) {
					// Como henos encontrado coincidencia, guardamos en indiceBueno
					// el valor del indice de este registro (indiceLeido), leido 4 lineas antes.
					indiceBueno = indiceLeido;
					// Abandonamos el for para no seguir buscando
					break;
				}

				// no es necesario hacer un nuevo seek para posicionarse en el siguiente
				// registro, pues como se va leyendo secuencialmente, cuando acabo de leer
				// un registro siempre tengo el puntero apuntando al registro siguiente
			}

			// ELIMINAR EN AGENDA.DAT EL INDICE QUE HE ENCONTRADO, SI ES QUE HE ENCONTRADO ALGUNO
			// Primero miro si no he encontrado registro, y aviso en tal caso
			if (indiceBueno == -1) {
				System.out.println("\n********************************");
				System.out.println("DATOS DE LA PERSONA");
				System.out.println("No hay registro que coindica con el apodo " + apodo);

			} else {
				// Aqui entro si estoy seguro de que he encontrado un registro en el indice, asi que
				// ya sabemos en que registro de agenda.dat hemos de buscar
				// Creamos objeto para acceder a agenda.dat
				RandomAccessFile objetoAgenda = new RandomAccessFile("agenda.dat", "rw");

				// nos posicionamos en el sitio donde hemos de leer el registro de valor indiceBueno
				// para ello multiplicamos el indiceBueno-1 por el tamaño de cada registro
				// (de agenda.dat en este caso), y usamos seek para acceder directamente a la posicion
				objetoAgenda.seek((indiceBueno - 1) * 78);

				// creamos un String de 39 espacios en blanco
				String espacios = "";
				for (int i = 0; i < 39; i++) {
					espacios = espacios + " ";
				}

				// sobrescribimos el regiostro del agenda
				// con el string creado, para dejar borrado el elemento
				objetoAgenda.writeChars(espacios);

				// ADEMAS DE BORRAR EL REGISTRO EN LA AGENDA.DAT, TAMBIEN HAY QUE HACERLO EN EL INDICE
				// Nos posicionamos en el sitio donde hemos de leer el registro de valor indiceBueno
				// para ello multiplicamos el indiceBueno-1 por el tamaño de cada registro
				// (de indice.dat en este caso)
				indiceAgenda.seek((indiceBueno - 1) * 14);

				// creamos un String de 39 espacios en blanco
				espacios = "";
				for (int i = 0; i < 5; i++) {
					espacios = espacios + " ";
				}

				// sobrescribimos el registro del indice
				// primero con un int y luego con el string creado, para dejar borrado el elemento
				indiceAgenda.writeInt(0);
				indiceAgenda.writeChars(espacios);

			}

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	/**
	 * BUSCAR ENTRADA
	 * 
	 */
	public static void buscarEntrada() {
		// Solicita un apodo a buscar
		System.out.println("Introduce apodo");
		String apodo;
		apodo = ut.leerString();
		apodo = rellenar(apodo, 5);
		int indiceBueno = -1;

		try {
			RandomAccessFile indiceAgenda = new RandomAccessFile("indice.dat", "rw");
			indiceAgenda.seek(0);
			int tamanoFichero = (int) indiceAgenda.length();

			// con n bucle voy a ir cogiendo cada uno de los registros del indice.dat
			// si me coincide con el apodo buscado, me quedare con el numero de registro
			for (int j = 0; j <= (tamanoFichero / 14) - 1; j++) {

				if (indiceAgenda.getFilePointer() > indiceAgenda.length()) {
					break;
				}
				// Leemos los datos del regitro del índice
				// leemos el primer dato que es un integer
				int indiceLeido = indiceAgenda.readInt();

				// leemos el segundo dato que es un string de 5
				String bloqueleido = leerStringDeRandomFile(indiceAgenda, 5);

				// String bloqueleido = "";
				// for (int i = 0; i < 5; i++) {
				// bloqueleido = bloqueleido + indiceAgenda.readChar();
				// }
				// Comparamos lo leido (bloqueleido) con el texto a buscar (apodo)
				if (bloqueleido.equalsIgnoreCase(apodo)) {
					// Como henos encontrado coincidencia, guardamos en indiceBueno
					// el valor del indice de este registro (indiceLeido), leido 4 lineas antes.
					indiceBueno = indiceLeido;
					// Abandonamos el for para no seguir buscando
					break;
				}

				// no es necesario hacer un nuevo seek para posicionarse en el siguiente
				// registro, pues como se va leyendo secuencialmente, cuando acabo de leer
				// un registro siempre tengo el puntero apuntando al registro siguiente

			}
			if (indiceBueno == -1) {
				System.out.println("\n********************************");
				System.out.println("DATOS DE LA PERSONA");
				System.out.println("No hay registro que coindica con el apodo " + apodo);

			} else {
				// Ya sabemos en que registro de agenda.dat hemos de buscar
				// Creamos objeto para acceder a agenda.dat
				RandomAccessFile objetoAgenda = new RandomAccessFile("agenda.dat", "rw");

				// nos posicionamos en el sitio donde hemos de leer el registro de valor indiceBueno
				// para ello multiplicamos el indiceBueno-1 por el tamaño de cada registro
				objetoAgenda.seek((indiceBueno - 1) * 78);

				// leemos el bloque enbtero de String de tamaño 39
				String bloqueleido = leerStringDeRandomFile(objetoAgenda, 39);
				// String bloqueleido = "";
				// for (int i = 0; i < 39; i++) {
				// bloqueleido = bloqueleido + objetoAgenda.readChar();
				// }
				// El string de 39 cchar que hemos leido, lo troceamos en cada elemento de la persona
				String nombre = bloqueleido.substring(0, 26);
				String apodo2 = bloqueleido.substring(26, 31);
				String telefono = bloqueleido.substring(31, 40);

				// Pintamos resultados
				System.out.println("\n********************************");
				System.out.println("DATOS DE LA PERSONA");
				System.out.println("Nombre  :[" + nombre + "]");
				System.out.println("Apodo   :[" + apodo2 + "]");
				System.out.println("Telefono:[" + telefono + "]");
				System.out.println("********************************");
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	/**
	 * AÑADIR ENTRADA
	 * 
	 */
	public static void anadirEntrada() {
		System.out.println("Introduce nombre: ");
		String nombre;
		nombre = ut.leerString();
		System.out.println("Introduce Apodo: ");
		String apodo;
		apodo = ut.leerString();
		System.out.println("Introduce telefono: ");
		String telefono;
		telefono = ut.leerString();
		guardarPersona(nombre, apodo, telefono);
	}

	public static boolean guardarPersona(String n, String a, String t) {
		boolean resultado = false;
		try {
			// Abro el ficheroi
			RandomAccessFile objetoAgenda = new RandomAccessFile("agenda.dat", "rw");
			// coloco el puntero al final del fichero, que es donde voy a escribir
			// el nuevo registro
			objetoAgenda.seek(objetoAgenda.length());

			// Relleno los campos que me han dado con blancos hasta completar el tamaño de cada campo
			String ab = rellenar(n, 25);
			System.out.println(ab);
			String ac = rellenar(a, 5);
			System.out.println(ac);
			String ad = rellenar(t, 9);
			System.out.println(ad);

			// Escribo los tres camposd del nuevo registro
			objetoAgenda.writeChars(ab);
			objetoAgenda.writeChars(ac);
			objetoAgenda.writeChars(ad);
			objetoAgenda.close();

			// Ahora voy a escribir en el fichero de indice el registro correspondiente a la nueva persona
			RandomAccessFile indiceAgenda = new RandomAccessFile("indice.dat", "rw");

			// coloco el puntero al final del fichero, que es donde voy a escribir
			// el nuevo registro, y usamos seek para acceder directamente a la posicion
			indiceAgenda.seek(indiceAgenda.length());
			int indice = 0;

			// cuantosIndice es el numero de registros que hay en el fichero de indice.dat
			int cuantosindice = (int) (indiceAgenda.length() / 14);

			// guardo dos datos. El nuevo indice, que sera el añadido de los que hay mas uno,
			// y el apodo, que lo tengo ya de antes
			indiceAgenda.writeInt(cuantosindice + 1);
			indiceAgenda.writeChars(ac);
			indiceAgenda.close();

		} catch (Exception e) {
			e.printStackTrace();
		}

		return resultado;
	}

	/**
	 * MOSTRAR TODOS
	 * 
	 */
	public static void mostrarTodos() {
		try {
			RandomAccessFile objetoAgenda = new RandomAccessFile("agenda.dat", "rw");
			objetoAgenda.seek(0);
			int tamanoFichero = (int) objetoAgenda.length();
			int numeroRegistros = (tamanoFichero / 78);

			for (int j = 1; j <= numeroRegistros; j++) {
				// este if por si acaso me intenta leer fuera de fichero,
				// que salga del bucle
				if (objetoAgenda.getFilePointer() > objetoAgenda.length()) {
					break;
				}

				// leo un bloque de 39 caracteres, que son todos los datos de una Persona
				String bloqueleido = leerStringDeRandomFile(objetoAgenda, 39);

				// troceo los datos de la persona en sus tres partes
				String nombre = bloqueleido.substring(0, 25);
				String apodo = bloqueleido.substring(25, 30);
				String telefono = bloqueleido.substring(30, 39);

				// escribo los datos de la persona
				System.out.println("\n********************************");
				System.out.println("DATOS DE LA PERSONA");
				System.out.println("Nombre  :[" + nombre + "]");
				System.out.println("Apodo   :[" + apodo + "]");
				System.out.println("Telefono:[" + telefono + "]");
				System.out.println("********************************");
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	/**
	 * RELLENAR
	 * 
	 * Rellena con blancos a la derecha una cadena , hasta el tamaño indicado parametro. Si la el tamaño es mas pequeño que la
	 * cadena original recorta esta dejando solo el tamaño solicitado
	 * 
	 * @param cadenaARellenar
	 *            -> cadena que se desea ampliar tamano -> tamaño de la cadena final
	 * 
	 *            Ejemplos rellenar("hola",4) -> da "hola    " rellenar("",3) -> da "   " rellenar("1234567",4) -> da "1234"
	 * 
	 */
	public static String rellenar(String cadenaARellenar, int tamano) {
		String resultado = cadenaARellenar;
		int cuantos = tamano - cadenaARellenar.length();
		if (cadenaARellenar.length() > tamano) {
			resultado = cadenaARellenar.substring(tamano);
		} else {
			String relleno = "";
			for (int i = 0; i < cuantos; i++) {
				relleno = relleno + " ";
			}
			resultado = cadenaARellenar + relleno;
		}
		return resultado;
	}

	/**
	 * LEER STRING DE UN FICHERO RANDOMFILE
	 * 
	 * Lee una cadena de caractreeres de un fichero RandomAccessFile desde la posicion en la que se encuentre el puntero (no se
	 * controla la posicion inicial en el metodo)
	 * 
	 * @param raf
	 *            -> fichero RandomAccessFile donde leer tamano -> cuantos caracteres ha de leer seguidos
	 * 
	 */
	public static String leerStringDeRandomFile(RandomAccessFile raf, int tamano) {
		String bloqueleido = "";
		try {
			for (int i = 0; i < tamano; i++) {
				char c = raf.readChar();
				bloqueleido = bloqueleido + c;
			}
		} catch (IOException e) {
			e.printStackTrace();
		}

		return bloqueleido;
	}

}