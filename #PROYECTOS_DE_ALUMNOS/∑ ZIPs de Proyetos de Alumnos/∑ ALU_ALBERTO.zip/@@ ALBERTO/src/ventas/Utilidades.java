package ventas;

import java.util.Scanner;

public class Utilidades {
	// LEER STRING- NO RECIBE POR PARAMETRO Y DEVUELVE UNA CADENA LEIDA POR TECLADO.
	public String leerString(String mensaje) {
		System.out.println(mensaje);
		String resultado;
		Scanner teclado = new Scanner(System.in);
		resultado = teclado.nextLine();
		return resultado;
	}

	public int leerInt(String mensaje) {
		System.out.println(mensaje);
		int resultado;
		Scanner teclado = new Scanner(System.in);
		resultado = teclado.nextInt();
		return resultado;
	}

	public double leerDouble(String mensaje) {
		System.out.println(mensaje);
		double resultado;
		Scanner teclado = new Scanner(System.in);
		resultado = teclado.nextDouble();
		return resultado;
	}
}
