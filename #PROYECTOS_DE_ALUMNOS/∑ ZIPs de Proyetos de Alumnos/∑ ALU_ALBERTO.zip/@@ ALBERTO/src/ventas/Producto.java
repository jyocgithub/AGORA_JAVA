package ventas;

import java.io.Serializable;

public class Producto implements Serializable {

	private String idProducto;
	private double precio;
	private int idFabricante;
	private String dniComprador;

	public Producto(String idProducto, double precio, int idFabricante, String dniComprador) {
		super();
		this.idProducto = idProducto;
		this.precio = precio;
		this.idFabricante = idFabricante;
		this.dniComprador = dniComprador;
	}

	@Override
	public String toString() {
		return idProducto + ": precio; " + precio + " id fabricante " + idFabricante + " comprado por " + dniComprador;
	}

	public String getIdProducto() {
		return idProducto;
	}

	public void setIdProducto(String idProducto) {
		this.idProducto = idProducto;
	}

	public double getPrecio() {
		return precio;
	}

	public void setPrecio(double precio) {
		this.precio = precio;
	}

	public int getIdFabricante() {
		return idFabricante;
	}

	public void setIdFabricante(int idFabricante) {
		this.idFabricante = idFabricante;
	}

	public String getDniComprador() {
		return dniComprador;
	}

	public void setDniComprador(String dniComprador) {
		this.dniComprador = dniComprador;
	}

}
