package ventas;

import java.io.EOFException;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;

public class Datos {

	public static void main(String[] args) {

		Utilidades leer = new Utilidades();

		ArrayList<Producto> lista = new ArrayList<>();
		ArrayList<Producto> lista2 = new ArrayList<>();

		// PARTE UNO
		// Escribir y leer el fichero

		try {
			FileOutputStream fout = new FileOutputStream("productos.dat");
			ObjectOutputStream Oops = new ObjectOutputStream(fout);

			// ESCRIBIMOS EL FICHERO

			for (int i = 0; i < 3; i++) {
				// String a = leer.leerString("Dame un Id de Producto:");
				double b = leer.leerDouble("Dame un precio:");
				int c = leer.leerInt("Dame un Id de fabricante:");

				// la i es el id del producto por lo tanto no puede repetirse.
				// No lo pido al usuario.
				// Para mejorar el ejercicio, hacer un bucle for que lea los
				// anteriores e impida escribir repetido.

				String d = leer.leerString("Dame un DNI de comprador de producto:");
				Producto uno = new Producto(i + "", b, c, d);
				lista.add(uno);
				Oops.writeObject(uno);
			}

			Oops.close();

			// LEEMOS EL FICHERO

			FileInputStream foutLeer = new FileInputStream("productos.dat");
			ObjectInputStream OopsLeer = new ObjectInputStream(foutLeer);

			System.out.println("-------------------------");
			System.out.println("PRODUCTOS EN EL FICHERO");

			Producto p = (Producto) OopsLeer.readObject();
			System.out.println(p);
			while (p != null) {
				lista2.add(p);
				p = (Producto) OopsLeer.readObject();
				// mostramos lo que vamos leyendo
				System.out.println(p);
			}

		} catch (EOFException eofex) {
			System.out.println("Leido hasta el fin de fichero");
		} catch (ClassNotFoundException | IOException e) {
			e.printStackTrace();
		}

		// PARTE DOS
		// Pedimos un DNI de un comprador para ver sus compras
		System.out.println("-------------------------");
		System.out.println("CONSULTA DE COMPRAS");
		String dniAConsultar = leer.leerString("Dame un DNI de comprador de producto:");
		while (!dniValido(dniAConsultar)) {
			dniAConsultar = leer.leerString("DNI no valido, dame un nuevo DNI de comprador de producto:");
		}

		// creamos sumadores para los calculos posteriores
		double sumaImportes = 0;
		int contadorProductos = 0;
		ArrayList<Integer> listaFabricantes = new ArrayList<>();

		// recorremos todos los productos
		for (int j = 0; j < lista2.size(); j++) {

			// sacamos a un objeto p cada producto a analizar
			Producto p = lista2.get(j);

			// miramos si el dni del comprador del productro es el mismo que el dni que nos han dado
			if (p.getDniComprador().equals(dniAConsultar)) {

				// Aqui sabemos que el producto lo ha comprado el comprados con dniAConsultar
				contadorProductos++;
				sumaImportes = sumaImportes + p.getPrecio();

				// Miramos si el fabricante de este producto ya estaba en nuestra lista
				// de fabricantes, para no repetirlo.
				// Si no estaba, lo añadimos a la lista, y si ya estaba, no hacemnos nada
				int fabricanteParaAnadir = p.getIdFabricante();
				boolean elFabricanteYaEstabaEnLaLista = false;

				for (int k = 0; k < listaFabricantes.size(); k++) {
					// se cumple este if si el fabricante ya estaba en nuestra lista
					if (listaFabricantes.get(k) == fabricanteParaAnadir) {
						elFabricanteYaEstabaEnLaLista = true;
					}
				}

				// si el fabricante no esyaba, lo añadimos
				if (!elFabricanteYaEstabaEnLaLista) {
					listaFabricantes.add(fabricanteParaAnadir);
				}

			}
		}

		System.out.println("-------------------------");
		System.out.println("RESULTADOS DE LA BUSQUEDA");

		// mostramos resultados finales
		System.out.println("Datos del comprador con dni " + dniAConsultar);
		System.out.println("Productos comprados: " + contadorProductos);
		System.out.println("Importes acumulados: " + sumaImportes);

		System.out.println("Id de fabricantes de productos comprados: ");
		for (int k = 0; k < listaFabricantes.size(); k++) {
			System.out.println(listaFabricantes.get(k));
		}

		// por si no hay ningun comprador, avisamos con un mensaje
		if (listaFabricantes.size() == 0) {
			System.out.println("No hay ningun fabricante en la lista");
		}

	}

	public static boolean dniValido(String dni) {
		int contador = 0;
		boolean valido = true;
		if (dni.length() != 9) {
			return false;
		}
		if (!Character.isLetter(dni.charAt(8))) {
			return false;
		}

		if (dni.charAt(8) == 'I' || dni.charAt(8) == 'Ñ' || dni.charAt(8) == 'O' || dni.charAt(8) == 'U') {
			return false;
		}

		for (int i = 0; i < 8; i++) {
			if (!Character.isDigit(dni.charAt(i))) {
				return false;
			}
		}
		// for (int i = 0; i < 8; i++) {
		// if (dni.charAt(i) == '0' || dni.charAt(i) == '1' || dni.charAt(i) == '2' || dni.charAt(i) == '3'
		// || dni.charAt(i) == '4' || dni.charAt(i) == '5' || dni.charAt(i) == '6' || dni.charAt(i) == '7'
		// || dni.charAt(i) == '8' || dni.charAt(i) == '9') {
		// contador++;
		// }
		// }
		// if (contador != 8) {
		// return false;
		// }
		return valido;
	}
}
