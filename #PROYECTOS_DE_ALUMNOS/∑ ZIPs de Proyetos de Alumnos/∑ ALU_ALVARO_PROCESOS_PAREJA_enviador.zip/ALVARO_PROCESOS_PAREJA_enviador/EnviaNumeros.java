import java.util.Random;

public class EnviaNumeros {

    public static void main(String[] args) {
        Random azar = new Random();
        for (int i = 0; i < 10 ; i++) {
            System.out.println( azar.nextInt(20));
        }

    }

}
