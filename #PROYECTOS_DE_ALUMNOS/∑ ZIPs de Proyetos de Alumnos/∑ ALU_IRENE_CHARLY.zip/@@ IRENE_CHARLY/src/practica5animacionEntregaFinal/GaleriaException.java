public class GaleriaException extends Exception {
/**
 * Galeria Exception
 * @author Irene.bahon
 * @version 1.0
 */
	private static final long serialVersionUID = 1L;

	//CONSTRUCTOR
	/**
	 * public GaleriaException(String message)
	 * @param message
	 */
	public GaleriaException(String message){
		super(message);
	}
}