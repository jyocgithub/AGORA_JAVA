/**
 * Interface Galeria.
 * 
 * @author Irene.bahon
 * @version 1.0
 */

public interface IGaleria {

	public boolean a�adirAlbum(Album album);
	
	
	/**
	 * public boolean crearAlbum(String album) Crea un �lbum y lo a�ade a la
	 * colecci�n de base
	 * 
	 * @param album
	 * @return true si lo ha creado y a�adido y false si no.
	 * @throws java.lang.IllegalArgumentException
	 *             - si el par�metro album es null
	 */
	public boolean crearAlbum(String album);

	/**
	 * public Album getAlbum(String album) Devuelve el citado �lbum sin borrarlo
	 * de la colecci�n
	 * 
	 * @param album
	 * @return el Album o null si no existe �lbum con ese nombre
	 * @throws java.lang.IllegalArgumentException
	 *             - si el par�metro nombre es null
	 */
	public Album getAlbum(String album);

	/**
	 * public Album delAlbum(String album) Borramos el citado �lbum de la
	 * colecci�n
	 * 
	 * @param album
	 * @return el �lbum borrado o null si no lo ha podido borrar por que no
	 *         exista
	 * @throws java.lang.IllegalArgumentException
	 *             - si el par�metro album es null
	 */
	public Album delAlbum(String album);

	/**
	 * public String[] getAlbumes() Devuelve los nombres de los �lbumes o null
	 * si no existe ninguno
	 * 
	 * @return array de nombres
	 */
	public String[] getAlbumes();

	/**
	 * public void presentarAlbum(String album, int retardo) throws
	 * GaleriaException Visualizar las fotos de un determinado �lbum a trav�s de
	 * una de las animaciones de la pr�ctica 5, eligiremos la clase
	 * AnimacionImagenesCircular
	 * 
	 * @param album
	 * @param retardo
	 * @throws GaleriaException
	 *             - si no existe el �lbum o se produce la excepci�n
	 *             AnimacionException
	 * @throws java.lang.IllegalArgumentException
	 *             - si el album es null o retardo negativo
	 */
	public void presentarAlbum(String album, int retardo) throws GaleriaException;

}