/**
 * 
 * Animacion Imagenes
 * @author Irene.bahon
 * @version 1.0
 */

public class AnimacionImagenes extends Animacion {

	//ATRIBUTOS
	protected Imagen[] imagenes;
	int laquetoca = 0;
	
	
	//Constructor
		/**
		 * public AnimacionImagenes(String nombre, int ancho, int alto, Imagen[] imagenes)
		 * Crea una animaci�n con el nombre proporcionado, la animaci�n se mostrar� en un Escenario de tama�o ancho x alto.
		 * La animaci�n mostrar� las imagenes cuyos nombres de ficheros se pasan como par�metro en el array imagenes secuencialmente,
		 * en el mismo orden en que est�n en el array, y terminar�.
		 * Parameters:
		 * @param nombre;el nombre de la animacion
		 * @param ancho;el ancho del escenario donde mostrarla (en pixels)
		 * @param alto;el alto del escenario donde mostrarla (en pixels)
		 * @param imagenes;array con el nombre de los ficheros con las im�genes a mostrar
		 */
	
	public AnimacionImagenes(String nombre, int ancho, int alto, Imagen[] imagenes) throws IllegalArgumentException, AnimacionException {
		super(nombre, ancho, alto);
		
		if(imagenes.length < 2){
			AnimacionException aE = new AnimacionException("No tiene suficientes elementos");
			throw aE;
		}
		
		this.imagenes=imagenes;
		
		
	}
	
	public AnimacionImagenes(String nombre, int ancho, int alto, String[] imagene) throws IllegalArgumentException, AnimacionException {
		super(nombre, ancho, alto);
		
		if(imagene.length < 2){
			AnimacionException aE = new AnimacionException("No tiene suficientes elementos");
			throw aE;
		}
		Imagen[] ima = new Imagen[imagene.length];
		for (int i = 0; i < imagene.length; i++) {
			Imagen x= new Imagen(imagene[i]);
			ima[i]= x;
		}
		this.imagenes=ima;
		
		
	}

	/**
	 * public void setPosicion(int posicion)
	 * Permite cambiar la posici�n correspondiente a la imagen a mostrar al ejecutar el siguiente paso.
	 * Su valor debe estar comprendido entre 1 y el n�mero de im�genes existentes.
	 * Parameters:
	 * @param posicion
	 * posici�n de la imagen a mostrar al ejecutar el siguiente paso
	 */
	
	public void setPosicion(int posicion){
		Imagen aux=imagenes[posicion];
		imagenes[posicion]=imagenes[laquetoca];
		imagenes[laquetoca]=aux;
		
	}
	
	/**
	 * public int getCuantas()
	 * Devuelve el n�mero de im�genes que forman la animaci�n
	 * @return
	 * int el n�mero de im�genes de al animaci�n
	 */
	
	public int getCuantas(){
		return imagenes.length;
	}
	
	/**
	 * public void ejecutarPaso()
	 * Description copied from class:
	 * Animacion
	 * Ejecuta un paso de la animaci�n y prepara todo para ejecutar el siguiente paso.
	 * Se llamar� en un bucle hasta que finalice la animaci�n, de forma que se vaya ejecutando paso a paso.
	 * Specified by:
	 * ejecutarPaso in class Animacion
	 */
	
	public void ejecutarPaso() throws IllegalStateException {
		if(acabado){
			throw new IllegalStateException();
		}
		p.dibujarImagen(240, 240, imagenes[laquetoca]);
		laquetoca++;
		if (laquetoca==imagenes.length){
			acabado = true;			
		}
	}

	/**
	 * public boolean estaFinalizada()
	 * Description copied from class:
	 * Animacion
	 * Devuelve si la animaci�n ha finalizado o no.
	 * Specified by:
	 * estaFinalizada in class Animacion
	 * Returns:
	 * true si la animaci�n ha finalizado
	 */
	
	public boolean estaFinalizada() {
		return acabado;
	}

}