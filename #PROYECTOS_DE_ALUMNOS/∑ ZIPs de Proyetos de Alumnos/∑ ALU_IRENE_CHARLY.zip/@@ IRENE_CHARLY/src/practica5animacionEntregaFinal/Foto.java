import java.text.SimpleDateFormat;
import java.util.Date;
/**
 * Creacion de una Foto.
 * @author Irene.bahon
 * @version 1.0
 */
public class Foto {

	//ATRIBUTOS
	private String nomFichero;
	private Date fecha;
	private String descripcion;
	
	//CONSTRUCTOR
	/**
	 * public Foto(String descripcion, Date fecha, String nomFichero) throws IllegalArgumentException
	 * Crear una foto
	 * @param descripcion
	 * @param fecha
	 * @param nomFichero
	 * @throws IllegalArgumentException- en el caso que alguno de los par�metros vayan a null
	 */
	public Foto(String descripcion, Date fecha, String nomFichero) throws IllegalArgumentException{
		if(descripcion==null || fecha==null || nomFichero==null){
			throw new IllegalArgumentException();
		}
		this.descripcion=descripcion;
		this.fecha=fecha;
		this.nomFichero=nomFichero;

	}
	
	/**
	 * public String getNomFichero()
	 * Devuelve el nombre del fichero al que est� vinculada la foto
	 * @return
	 */
	public String getNomFichero(){
		return nomFichero;
	}
	
	/**
	 * public Date getFecha()
	 * Devuelve la fecha.
	 * @return fecha
	 */
	public Date getFecha(){
		return fecha;
	}
	
	/**
	 * public String getDescripcion()
	 * Devuelve la descripci�n de la foto.
	 * @return descripci�n
	 */
	public String getDescripcion(){
		return descripcion;
	}
	
	/**
	 * public String toString()
	 * M�todo de conveniencia para representar textualmente el estado del objeto
	 * @return 
	 */
	public String toString(){
		return "El fichero: "+nomFichero+", con fecha: "+fechaTostring(fecha)+", contiene la descripcion: "+descripcion;
	}
	
	
	/**
	 * public String fechaTostring
	 * Tranforma un tipo fecha en un tipo to string.
	 * @param d
	 * @return
	 */
	public String fechaTostring(Date d ) {
		String fechast;
		SimpleDateFormat miFormato2 = new SimpleDateFormat("dd/MM/yyyy");	
		fechast = miFormato2.format(d);
		return fechast;
	}

}