import java.io.*;
import java.util.*;

/**
 * Programa de prueba con conjuntos, donde se crea un albun con fotos el cual
 * luego borraremos.
 * 
 * @author Irene.bahon
 * @version 1.0
 */
public class TestPF7F2 {

	public static void main(String[] args) {
		String a1 = "";
		String a2 = "";
		GaleriaF2 gal = null;
		String nombreficherobinario = "albumes.bin";
		String nombreficherotexto = "albumes.txt";
		File f1 = new File(nombreficherobinario);
		if (!f1.exists()) {
			// crear
			gal = new GaleriaF2();
			a1 = "Album 1\n";
			a2 = "Album 2\n";
			// crear albumes
			gal.crearAlbum(a1);
			gal.crearAlbum(a2);

			// crear 6 fotos para el album 1
			for (int i = 0; i < 6; i++) {
				Foto fff = new Foto("Descripcion " + (i + 1), new Date(), "T" + (i + 1) + ".gif");
				gal.getAlbum(a1).addFoto(fff);
			}

			for (int i = 3; i < 6; i++) {
				Foto fff = new Foto("Descripcion " + (i + 1), new Date(), "T" + (i + 1) + ".gif");
				gal.getAlbum(a2).addFoto(fff);
			}

			// guardar
			guardarAlbumes(nombreficherobinario, gal);
			generarInfoAlbumes(nombreficherotexto, gal);

		} else {
			gal = (GaleriaF2) recuperarAlbumes(nombreficherobinario);
		}

		// ATRIBUTOS

		// escribir info de albumes
		for (Album al : gal.conjunto) {
			System.out.print("\nNombre de album: ");
			System.out.println(al.getNombre());

			// escribir info de fotos de cada album
			for (Foto fot : al.listaFotos) {
				System.out.print("  Foto : ");
				System.out.println("  " + fot.getDescripcion());
			}
		}

		// Realizar la presentacion de las fotos del primer album.
		try {
			gal.presentarAlbum(a1, 1000);
		} catch (GaleriaException e) {
			e.printStackTrace();
		}
		System.out.println("Guardar presentacion?");
		Scanner sc = new Scanner(System.in);		
		
		String opcion = sc.nextLine();
		
		if( opcion.toUpperCase().equals("S")){
			System.out.println("Nombre del fichero?");
			String nombrefich = sc.nextLine();
			
			try{
				guardarPresentación(nombrefich,a1,gal.getAlbum(a1),1000);
			
			}catch(IOException e){
				e.printStackTrace();
			}
		}
		sc.close();
		// Borrar todas las fotos del primer album
		System.out.println("\n\t***ALBUM 1***");
		System.out.println("\nTamaño del album antes de borrarlo:" + gal.getAlbum(a1).listaFotos.size());

		Iterator<Foto> ite = gal.getAlbum(a1).listaFotos.iterator();
		while (ite.hasNext()) {
			System.out.println(ite.next().toString());
			ite.remove();
		}
		System.out.println("\nTamaño del album tras borrarlo:" + gal.getAlbum(a1).listaFotos.size());

		// Borrar el primer album.
		gal.delAlbum(a1);

		// Borrar todas las fotos del segundo album
		System.out.println("\n\t***ALBUM 2***");
		System.out.println("\nTamaño del album antes de borrarlo:" + gal.getAlbum(a2).listaFotos.size());

		Iterator<Foto> ite2 = gal.getAlbum(a2).listaFotos.iterator();
		while (ite2.hasNext()) {
			System.out.println(ite2.next().toString());
			ite2.remove();
		}
		System.out.println("\nTamaño del album tras borrarlo:" + gal.getAlbum(a2).listaFotos.size());

		// Borrar el segundo album.
		gal.delAlbum(a2);
		System.out.println("\nNumero de albums en la galeria tras borrar 2:" + gal.getAlbumes().length);
	}

	private static boolean guardarAlbumes(String fichero, IGaleria gf) {
		boolean res = true;
		File f = new File(fichero);
		// IMPORTAAAAANTE
		GaleriaF2 gf2 = (GaleriaF2) gf;
		FileOutputStream fo = null;
		ObjectOutputStream oos = null;
		try {
			if (!f.exists()) {
				f.createNewFile();
			}
			fo = new FileOutputStream(f);
			oos = new ObjectOutputStream(fo);
			for (Album a : gf2.conjunto) {
				oos.writeObject(a);
			}

		} catch (IOException e) {
			res = false;
		} finally {

			try {
				if (fo != null)
					fo.close();
				if (oos != null)
					oos.close();
			} catch (IOException e) {
				res = false;
			}
		}
		return res;
	}

	private static IGaleria recuperarAlbumes(String fichero) {

		GaleriaF2 gF2 = new GaleriaF2();
		File f = new File(fichero);
		FileInputStream fi = null;
		ObjectInputStream ois = null;
		IGaleria igal = null;

		if (!f.exists()) {
			try {
				f.createNewFile();
			} catch (IOException io) {
				io.printStackTrace();
			}
		}
		try {
			fi = new FileInputStream(f);
			ois = new ObjectInputStream(fi);

			Album m = (Album) ois.readObject();
			while (m != null) {
				gF2.añadirAlbum(m);
				m = (Album) ois.readObject();
			}
			igal = gF2;
		} catch (IOException | ClassNotFoundException e) {
			return null;
		} finally {

			try {
				if (fi != null)
					fi.close();
				if (ois != null)
					ois.close();
			} catch (IOException e) {
				return null;
			}
		}
		return igal;
	}

	public static boolean generarInfoAlbumes(String fichero, IGaleria gf) {
		boolean res = true;

		// crear objeros fichero
		GaleriaF2 gf2 = (GaleriaF2) gf;
		File f = new File(fichero);
		PrintWriter pw = null;
		String cad = "";
		try {
			pw = new PrintWriter(f);

			for (Album a : gf2.conjunto) {
				cad = a.getNombre() + "; ";
				for (Foto ff : a.listaFotos) {
					cad = cad + ff.getNomFichero() + ": " + ff.getDescripcion() + ": ";
				}
				pw.println(cad);
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} finally {

			if (pw != null)
				pw.close();

		}

		return res;
	}
	
	
	
	
	private static void guardarPresentación(String nombreFichero, String nombrePresentacion, Album album, int retardo) throws IOException{
	
		File f = new File(nombreFichero);
		FileOutputStream fo = null;
		DataOutputStream dop = null;
		
		fo = new FileOutputStream(f);
		dop = new DataOutputStream(fo);

		dop.writeUTF(nombrePresentacion);
		dop.writeInt(retardo);
		dop.writeInt(album.listaFotos.size());
		
		for (Foto ff : album.listaFotos) {
			dop.writeUTF(ff.getNomFichero());
		}
		
		if (fo != null)
			fo.close();
		if (dop != null)
			dop.close();

	}
}