import java.awt.Color;
/**
 * Efecto que pasa de color a Blanco y Negro la imagen deseada.
 * @author Irene.bahon
 * @version 1.0
 */
public class EfectoEscalaGrises implements Efecto {

	//Constructor
	public EfectoEscalaGrises() {
		
	}

	//Metodos
		/**
		 * public Imagen transformar(Imagen entrada)
		 * Transforma la imagen de color a blanco y negro.
		 * @return Imagen transformada.
		 */
	public Imagen transformar(Imagen entrada)throws IllegalArgumentException {

		if(entrada == null){
			throw new IllegalArgumentException();
		}
		
		int mediaPixel;
		Color colorAux;
		for (int i = 0; i < entrada.getAncho(); i++) {
			for (int j = 0; j < entrada.getAlto(); j++) {

				colorAux = entrada.getColor(i, j);
				mediaPixel = (int) ((colorAux.getRed() + colorAux.getGreen() + colorAux.getBlue()) / 3);
				colorAux = new Color(mediaPixel, mediaPixel, mediaPixel);
				entrada.setColor(i, j, colorAux);

			}
		}

		return entrada;
	}

}