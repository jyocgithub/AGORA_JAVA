import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Set;
/**
 * Galeria F3: perteneciente a mapas.
 * @author Irene.bahon
 * @version 1.0
 */
public class GaleriaF3 implements IGaleria {

	HashMap<String, Album> conjunto = new HashMap<>();
	
	
	public boolean añadirAlbum(Album album) {
		conjunto.put(album.getNombre(), album);
		return false;
	}
	/**
	 * boolean crearAlbum(String album)
	 * Crea un álbum y lo añade a la colección de base
	 * Parameters:
	 * @param album;el nombre del album
	 * @return true si lo ha creado y añadido y false si no.
	 * @throws java.lang.IllegalArgumentException - si el parámetro album es null
	 */
	public boolean crearAlbum(String album) {

		Album a = new Album(album);
		añadirAlbum(a);
		return false;
	}

	/**
	 * Album getAlbum(String album)
	 * Devuelve el citado álbum sin borrarlo de la colección
	 * Parameters:
	 * @param album;nombre del álbum
	 * @return el Album o null si no existe álbum con ese nombre
	 * @throws java.lang.IllegalArgumentException - si el parámetro nombre es null
	 */
	public Album getAlbum(String album) {
		Collection<Album> losvalores = conjunto.values();
		for (Album a : losvalores) {
			if (a.getNombre().equals(album)) {
				return a;
			}

		}
		return null;
	}

	/**
	 * Album delAlbum(String album)
	 * Borramos el citado álbum de la colección
	 * Parameters:
	 * @param album;nombre del álbum
	 * @return el álbum borrado o null si no lo ha podido borrar por que no exista
	 * @throws java.lang.IllegalArgumentException - si el parámetro album es null
	 */
	public Album delAlbum(String album) {
		Set<String> lasclaves = conjunto.keySet();
		for (String ss : lasclaves) {
			Album m = conjunto.get(ss);
			if (m.getNombre().equals(album)){
				conjunto.remove(ss);
				return m;
			}
		}
		return null;
	}

	/**
	 * String[] getAlbumes()
	 * Devuelve los nombres de los álbumes o null si no existe ninguno
	 * @return array de nombres
	 */
	public String[] getAlbumes() {
		String[] aa = new String[conjunto.size()];
		int x = 0;
		Collection<Album> losvalores = conjunto.values();
		for (Album a : losvalores) {
			aa[x] = a.getNombre();
			x++;
		}

		return aa;
	}

	/**
	 * void presentarAlbum(java.lang.String album,int retardo)throws GaleriaException
	 * Visualizar las fotos de un determinado álbum a través de una de las animaciones de la práctica 5,
	 * eligiremos la clase AnimacionImagenesCircular
	 * Parameters:
	 * @param album;nombre del álbum
	 * @param retardo;entre pasos de ejecución
	 * @throws GaleriaException - si no existe el álbum o se produce la excepción AnimacionException
	 * @throws java.lang.IllegalArgumentException - si el album es null o retardo negativo
	 * @throws AnimacionException 
	 */
	public void presentarAlbum(String album, int retardo) throws GaleriaException {

		AnimacionImagenes a7 = null;
		Collection<Album> losvalores = conjunto.values();
		for (Album al : losvalores) {
			if (al.getNombre().equals(album)) {

				ArrayList<Foto> arrfotos = al.listaFotos;
				// animacionImagenesCircular necesita una array de Imagen
				// Lo creamos a partir de un array de Foto
				Imagen[] lisimagenes = new Imagen[arrfotos.size()];

				for (int i = 0; i < lisimagenes.length; i++) {
					Imagen kk = new Imagen(arrfotos.get(i).getNomFichero());
					lisimagenes[i] = kk;
				}

				try {
					a7 = new AnimacionImagenes("Animacion Imagenes", 600, 600, lisimagenes);
				} catch (IllegalArgumentException e) {
					e.printStackTrace();
				}

				catch (AnimacionException e) {
					// capturar la excepción AnimacionException y lanzar en su lugar –sustituyendola- la excepción
					// GaleriaException
					throw new GaleriaException("Error de tipo Galeria Exception");
				}
			}
		}

		new P5F2();
		P5F2.player(a7, 500);

	}

}
