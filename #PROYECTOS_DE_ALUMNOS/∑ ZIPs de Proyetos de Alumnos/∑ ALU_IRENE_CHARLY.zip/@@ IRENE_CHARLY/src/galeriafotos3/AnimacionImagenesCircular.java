package galeriafotos3;
/**
 * Muestra una imagen en movimiento con repeticion infinita.
 * @author Irene.bahon
 * @version 1.0
 */
public class AnimacionImagenesCircular extends AnimacionImagenes{

	//ATRIBUTOS
	int laquetoca = 0;
	
	//Constructor
		/**
		 * public AnimacionImagenesCircular(String nombre, int ancho, int alto, Imagen[] imagenes)
		 * Crea una animacin con el nombre proporcionado, la animacin se mostrar en un Escenario de tamao ancho x alto.
		 * La animacin mostrar las imagenes cuyos nombres de ficheros se pasan como parmetro en el array imagenes,
		 * en el mismo orden en que estn en el array, al mostrar la ltima imagen volver a empezar por la primera, en circulo,
		 * por lo que esta animacin no tiene final.
		 * Parameters:
		 * @param nombre;el nombre de la animacion
		 * @param ancho;el ancho del escenario donde mostrarla (en pixels)
		 * @param alto;el alto del escenario donde mostrarla (en pixels)
		 * @param imagenes;array con el nombre de los ficheros con las imgenes a mostrar
		 */
	
	public AnimacionImagenesCircular(String nombre, int ancho, int alto, Imagen[] imagenes)throws IllegalArgumentException , AnimacionException{
		super(nombre, ancho, alto, imagenes);
		
	}
	
	/**
	 * public void ejecutarPaso()
	 * Description copied from class:
	 * Animacion
	 * Ejecuta un paso de la animacin y prepara todo para ejecutar el siguiente paso.
	 * Se llamar en un bucle hasta que finalice la animacin, de forma que se vaya ejecutando paso a paso.
	 * Specified by:
	 * ejecutarPaso in class Animacion
	 */
	public void ejecutarPaso() throws IllegalStateException{
		if(acabado){
			throw new IllegalStateException();
		}
		p.dibujarImagen(240, 240, imagenes[laquetoca]);
		laquetoca++;
		if (laquetoca==imagenes.length){
			laquetoca = 0;			
		}
				
	}

	/**
	 * public boolean estaFinalizada()
	 * Description copied from class:
	 * Animacion
	 * Devuelve si la animacin ha finalizado o no.
	 * Specified by:
	 * estaFinalizada in class Animacion
	 * Returns:
	 * true si la animacin ha finalizado
	 */
	
	public boolean estaFinalizada() {
		return acabado;
	}
}
