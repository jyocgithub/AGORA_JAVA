package galeriafotos3;
/**
 * Animacion Movimiento, solo se repite una vez el ciclo de la imagen.
 * @author Irene.bahon
 * @version 1.0
 */
public class AnimacionMovimiento extends Animacion{

	//ATRIBUTOS
	private int x;
	private int y;
	private int vx;
	private int vy;
	private Imagen imagen;
	int direccion =0;
	int laquetoca = 0;

	//Constructor
		/**
		 * public AnimacionMovimiento(String nombre, int ancho, int alto, Imagen imagen, int x, int y, int vx, int vy)
		 * Crea una animacin con el nombre proporcionado, que se mostrar en un Escenario de tamao ancho x alto.
		 * La animacin mostrar la imagen cuyo nombre de fichero se pasa como parmetro, empezando en la posicion inicial x,y.
		 * En cada paso de la animacin la imagen se mover en la coordenada X e Y la cantidad de pixels especificados por los parmetros vx,vy.
		 * Esta animacin termina cuando la imagen se sale totalmente del escenario que la muestra.
		 * Parameters:
		 * @param nombre;el nombre de la animacion
		 * @param ancho;el ancho del escenario donde mostrarla (en pixels)
		 * @param alto;el alto del escenario donde mostrarla (en pixels)
		 * @param imagen;el nombre del fichero con la imagen a mostrar
		 * @param x;coordenada x inicial de la imagen a mostrar
		 * @param y;coordenada y inicial de la imagen a mostrar
		 * @param vx;velocidad en la coordenada x de la imagen a mostrar
		 * @param vy;velocidad en la coordenada y de la imagen a mostrar
		 */
	
	public AnimacionMovimiento(String nombre, int ancho, int alto, Imagen imagen,int x,int y, int vx,int vy) throws IllegalArgumentException {
		super(nombre, ancho, alto);
		
		if(imagen==null || x<0 || y<0 || vx<0 || vy<0){
			throw new IllegalArgumentException();
		}
		this.imagen=imagen;
		this.x=x;
		this.y=y;
		this.vx=vx;
		this.vy=vy;
	}
	
	/**
	 * public void ejecutarPaso()
	 * Description copied from class:
	 * Animacion
	 * Ejecuta un paso de la animacin y prepara todo para ejecutar el siguiente paso.
	 * Se llamar en un bucle hasta que finalice la animacin, de forma que se vaya ejecutando paso a paso.
	 * Specified by:
	 * ejecutarPaso in class Animacion
	 */
	
	public void ejecutarPaso() throws IllegalStateException{
		
		if(acabado){
			throw new IllegalStateException();
		}
		p.dibujarImagen(x, y, imagen);
		switch (direccion) {
		case 0:
			x=x+vx;
			y=y+vy;
			break;
		case 1:
			x=x-vx;
			break;
		case 2:
			x=x+vx;
			y=y-vy;
			break;
		default:
			break;
		}

		if(laquetoca==0){
			direccion=0;
		}
		laquetoca++;
		if (laquetoca==20){
			direccion = 1;			
		}
		if(laquetoca==40){
			direccion=2;
		}
		if(laquetoca==60){
			direccion=1;
		}
		if(laquetoca==79){
			laquetoca=0;
		}
	}

	/**
	 * public boolean estaFinalizada()
	 * Description copied from class:
	 * Animacion
	 * Devuevle si la animacin ha finalizado o no.
	 * Specified by:
	 * estaFinalizada in class Animacion
	 * Returns:
	 * true si la animacin ha finalizado
	 */
	public boolean estaFinalizada() {
		
		return acabado;
	}

}
