package galeriafotos3;
/**
 * Animacin Exception
 * @author Irene.bahon
 * @version 1.0
 */
public class AnimacionException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public AnimacionException(String mensaje){
		super(mensaje);
		
	}
	
	
	
	
}
