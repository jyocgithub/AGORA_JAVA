package galeriafotos3;
import java.util.*;
/**
 * Programa Principal.
 * @author Irene.bahon
 * @version 1.0
 */
public class P5F2 {

	public static void main(String[] args) {

		// Recoger parametro y analizar que animacion es.
		// Ejecutar la animacion.

		int numImagenes = 6;
		Scanner scanner = new Scanner(System.in);
		int numAnimacion = 0;
		Imagen[] imagenes = new Imagen[6];

		do {

			System.out.println("\tANIMACIONES.");
			System.out.println("\nNumero de la imagen? Entre 1 y " + (numImagenes - 1) + "; 0 para finalizar.");
			numAnimacion = scanner.nextInt();

			//Bucle try-catch para controlar las Excepciones.
			try {

				for (int i = 0; i < numImagenes; i++) {
					imagenes[i] = new Imagen("T" + (i + 1) + ".gif");
				}
				if (numAnimacion != 0) {

					System.out.println("Elige imagen a mostrar:Entre 1 y " + numImagenes);
					int elegida = scanner.nextInt();
					Imagen imagen = new Imagen("T" + elegida + ".gif");

					switch (numAnimacion) {
					case 1:

						AnimacionImagen a = new AnimacionImagen("Animacion Fija", 600, 600, imagen);
						player(a, 1000);
						break;

					case 2:

						AnimacionImagenes a2 = new AnimacionImagenes("Animacion Imagenes", 600, 600, imagenes);
						player(a2, 600);
						break;
					case 3:

						AnimacionImagenesCircular a3 = new AnimacionImagenesCircular("Animacion Circular", 600, 600,
								imagenes);
						player(a3, 500);
						break;
					case 4:

						AnimacionMovimiento a4 = new AnimacionMovimiento("Animacion en Movimiento", 600, 600, imagen,
								10, 10, 25, 25);
						player(a4, 200);
						break;

					case 5:
						EfectoEscalaGrises primero = new EfectoEscalaGrises();
						EfectoLibre segundo = new EfectoLibre();
						EfectoSecuencia efSec = new EfectoSecuencia(primero, segundo);

						AnimacionImagenConEfecto a5 = new AnimacionImagenConEfecto("Animacion con Efecto", 600, 600,
								imagen, efSec);
						player(a5, 200);
						break;

					default:
						break;
					}

				}

			} catch (IllegalArgumentException ex) {
				System.out.println(ex.getMessage());
			} catch (AnimacionException ax) {
				System.out.println(ax.getMessage());
			} catch (IllegalStateException isx) {
				System.out.println(isx.getMessage());
			} catch (RuntimeException rx) {
				System.out.println(rx.getMessage());
			}
			
		} while (numAnimacion != 0);
		scanner.close();
	}

	public static void player(Animacion a, int retardo) throws IllegalStateException {

		while (!a.estaFinalizada()) {
			try {
				a.ejecutarPaso();
				Thread.sleep(retardo);
				
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}

}
