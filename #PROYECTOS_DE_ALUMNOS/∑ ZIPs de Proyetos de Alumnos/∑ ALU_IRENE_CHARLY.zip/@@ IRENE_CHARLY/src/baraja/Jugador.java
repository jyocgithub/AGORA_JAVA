package baraja;

public class Jugador {


	//public static final String[]NUMJUGADORES=new String[];
	private static int numero;
	private static double saldo;
	private static int ganadas = 0;
	
	//CONSTRUCTOR
	public Jugador(int numero, double saldo) {
		this.numero=numero;
		this.saldo=saldo;
		this.ganadas = 0;
	}
	
	//METODOS
	public double getGanadas(){
		return ganadas;
	}

	public int getNumero() {
		return numero;
	}
	public double getSaldo(){
		return saldo;
	}

	/**
	 * INCREMENTAGANADAS
	 *
	 */
	public void incrementaGanadas(int ganadas){
		// Se trata de una especie de contador que nos vaya diciendo el numero
		// de partidas ganadas por cada jugador, empezara en 0.
		ganadas++;
	}

	/**
	 * SETSALDO
	 *
	 */
	public double setSaldo(double cantidad){
		saldo = cantidad + saldo;
		return saldo;
	}

	/**
	 * TOSTRING
	 *
	 */
	@Override
	public String toString() {
		return "Numero de jugador: " + numero + "/ Saldo: " + saldo + "/ Partidas ganadas: " + ganadas;
	}
}
