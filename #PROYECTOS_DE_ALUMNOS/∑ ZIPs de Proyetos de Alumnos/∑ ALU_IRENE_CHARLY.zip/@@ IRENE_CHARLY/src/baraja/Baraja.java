package baraja;

import java.util.Random;

public class Baraja {

	// ATRIBUTOS
	public static final int NUMCARTAS = 48;
	private Carta[] laBaraja = new Carta[NUMCARTAS];
	private int cartasEnElMazo;


	// CONSTRUCTOR
	public Baraja() {
		inicializar();
		cartasEnElMazo = 48;
	}

	// METODOS
	/**
	 * BARAJAR
	 *
	 */
	public void barajar(int veces) {
		System.out.println("Veces que se quiere barajar: " + veces);
		if (veces == 0) {
			System.out.println("No se puede barajar");
			return;
		}
		// FALTA METER NUMERO DE VECES ???

		Baraja nuevaBaraja = new Baraja();
		boolean seHaGuardadoCarta = false;
		Carta[] nuevaPilaDeCartas = new Carta[cartasEnElMazo]; // Crear una baraja auxiliar
		for (int i = 0; i < cartasEnElMazo; i++) {
			seHaGuardadoCarta = false;
			Carta cartaQueSeMueve = laBaraja[i];
			do {
				int x = intAleatorio(1, cartasEnElMazo); // elegir una posicion al azar
				if (nuevaPilaDeCartas[x] != null) { // si la posicion no esta ya con alguna carta
					nuevaPilaDeCartas[x] = cartaQueSeMueve; // guardo la carta ahí
					seHaGuardadoCarta = true;
				}
			} while (seHaGuardadoCarta);
		} // fin del for
	} // fin del metodo

	/**
	 * BARAJAR
	 *
	 */
	// un segundo modo de barajar, usar el que se desee
	public void barajar2(int veces, int cartasEnElMazo) {
		System.out.println("Veces que se quiere barajar: " + veces);
		if (veces == 0) {
			System.out.println("No se puede barajar");
			return;
		}
		// FALTA METER NUMERO DE VECES ???

		Carta intermedia;
		for (int i = 0; i < cartasEnElMazo; i++) {
			int x = intAleatorio(1, cartasEnElMazo); // elegir una posicion al azar
			int y = intAleatorio(1, cartasEnElMazo); // elegir otra posicion al azar
			intermedia = laBaraja[x];
			laBaraja[x] = laBaraja[y];
			laBaraja[y] = intermedia;
		}

	}

	/**
	 * GETCARTACIMA
	 *
	 */
	public Carta getCartaCima() {
		Carta carta = laBaraja[cartasEnElMazo];
		laBaraja[cartasEnElMazo] = null;
		return carta;
	}

	/**
	 * GETCARTAPOSICION
	 *
	 */
	public Carta getCartaPosicion(int posicion) {
		return laBaraja[posicion];
	}

	/**
	 * INICIALIZAR
	 *
	 */
	public void inicializar() {
		for (int i = 0; i < 4; i++) {
			for (int j = 0; j < 13; j++) {
				laBaraja[0] = new Carta(i, j);
			}
		}
	}

	/**
	 * TAMANO
	 *
	 */
	public int tamano() {
		return cartasEnElMazo;

	}

	/**
	 * TODAS
	 *
	 */
	public Carta[] todas() {
		return laBaraja;
	}

	/**
	 * TOSTRING
	 *
	 */
	@Override
	public String toString() {
		String resultado = "";
		for (int i = 0; i < cartasEnElMazo; i++) {
			int elPalo = laBaraja[i].getPalo();
			int elValor = laBaraja[i].getValor();
			resultado += laBaraja[i].getPaloComoString(elPalo) + "/" + laBaraja[i].getValorComoString(elValor);
			resultado += "\n";
		}
		return resultado;
	}

	/**
	 * INTALEATORIO
	 *
	 */
	public int intAleatorio(int min, int max) {
		return (int) (Math.random() * (max - min + 1) + min);
	}

	/**
	 * INTALEATORIO2
	 *
	 */
	public int intAleatorio2(int min, int max) {
		Random rn = new Random();
		return rn.nextInt() * (max - min + 1) + min;
	}

}
