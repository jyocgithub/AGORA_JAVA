package baraja;

import java.util.Scanner;

/**
 * Aplicacin: juego de la carta ms alta.
 * 
 * @author DTE
 * @version 1
 *
 */
public class JuegoMasAlta {
	/**
	 * Metodo principal de la aplicacin de juego.
	 * 
	 * @param args
	 *            Array de String con los parmetros necesarios para el funcionamiento de la aplicacin. Deberan pasarse dos
	 *            parmetros: El nmero de jugadores, la cantidad de dinero que dispondr cada uno. El formato del mandato ser:
	 *            <code>java JuegoMasAltaV1 [jugadores]  [euros totales por jugador] </code> Por ejemplo:
	 *            <code>java JuegoMasAltaV1 [4]  [1000] </code> Para poder jugar a este juego el numero de jugadores debe de ser
	 *            como mnimo 2 y cada uno con un mnimo de 100 euros.
	 */
	public static void main(String[] args) {
		Jugador[] jugadores;

		if (args.length != 2) {
			System.out.println("Error en los argumentos del programa");
			System.out.println("teclear: java JuegoMasAltaV1 [jugadores]  [euros totales por jugador] ");
		} else {
			int numJugadores = Integer.parseInt(args[0]);
			int cantidad = Integer.parseInt(args[1]);
			if (numJugadores < 2 || cantidad < 100) {
				System.out.println("los valores de los argumentos no permiten jugar");
			} else {
				jugadores = new Jugador[numJugadores];
				for (int i = 0; i < jugadores.length; i++) {
					jugadores[i] = new Jugador(i, cantidad);
				}
				play(jugadores, new Baraja());
			}
		}

	} // del main

	/**
	 * Metodo que invocado desde el programa principal crea una partida
	 * 
	 * @param jugadores
	 *            Array con los jugadores que jugaran la partida
	 * @param baraja
	 *            la baraja con la que jugarn la partida
	 */
	public static void play(Jugador[] jugadores, Baraja baraja) {
		boolean finPartida = false;
		Scanner sc = new Scanner(System.in);
		int apuesta;
		int numRonda = 0;
		Carta carta = null;
		Carta masAlta = null;
		Jugador ganador = null;
		Jugador ganadorTotal = null;
		// COMPLETAR, puede haber ms variables.
		// COMPLETAR, inicializa los datos que necesite par jugar y no esten ya creados.

		System.out.println("\n\t\tCOMIENZA LA PARTIDA\n");

		// COMIENZA LA PARTIDA
		do {
			// se mete en un bucle hasta ver si los jugadores actuales
			// pueden cubrir la apuesta pedida.
			boolean aceptada = true;
			do {
				// COMPLETAR
			} while (!aceptada);

			// COMIENZA LA RONDA
			// miramos si quedan suficientes cartas en la baraja para los jugadores actuales
			// si no quedan reseteamos y barajamos de nuevo.
			numRonda++;

			// COMPLETAR

			// obtenemos el ganador de la ronda. podemos usar un algoritmo del tipo
			// de ensayo y comprobacin del estilo: asignamos la carta ms alta a la primera que se
			// saca y comprobamos en un bucle si las siguientes son o no mayores intercambiandolas y
			// asignando como ganador momentaneo al jugador que saca dicha carta.
			// ESTO ES SIMILAR A LO REALIZADO EN LA ACTIVIDAD 2 DE LA PRCTICA 2

			// COMPLETAR

			// Anotamos en el ganador los premios y eliminamos a los jugadores que
			// se han quedado sin dinero

			// COMPLETAR

			/// recosntruimos el aray de jugadores quitando a los perdedores

			jugadores = eliminaCeros(jugadores);

			// se muestran resultados : Carta ms alta y jugador ganador.

			// COMPLETAR

			// Comprueba si hay un ganador absoluto para terminar la partida. Si no hay un jugador
			// ganador volvera a jugar

			// COMPLETAR

		} while (!finPartida);

		System.out.println("\n\t\tLA PARTIDA HA TERMINADO\n");
		System.out.println("EL GANADOR ABSOLUTO ES:" + ganadorTotal);
		sc.close();

	}

	/**
	 * Metodo que invocado desde el mtodo play recostruye el array de jugadores eliminando las posiciones que tengan un valor null
	 * 
	 * @param jugadores
	 *            Array con los jugadores que estan jugando la partida
	 * @return un nuevo array de jugadores con los que tienen un saldo superior a 0
	 */
	private static Jugador[] eliminaCeros(Jugador[] jugadores) {
		Jugador[] temp = null;

		// COMPLETAR

		return temp;
	}
}