package baraja;

public class Carta {

	public static final int OROS = 0;
	public static final int COPAS = 1;
	public static final int ESPADAS = 2;
	public static final int BASTOS = 3;
	public static final int AS = 1;
	public static final int SOTA = 10;
	public static final int CABALLO = 11;
	public static final int REY = 12;

	public static final int NUMCARTAS = 48;
	public static final int NUMPALOS = 4;
	public static final int NUMVALORES = 12;

	private int valor;
	private int palo;

	public static final String[] PALOS = { "OROS", "COPAS", "ESPADAS", "BASTOS" };
	public static final String[] VALORES = { "As", "2", "3", "4", "5", "6", "7", "8", "9", "Sota", "Caballo", "Rey" };

	// CONSTRUCTOR
	public Carta(int palo, int valor) {

		this.palo = palo;
		this.valor = valor;
	}

	// METODOS

	public int getValor() {
		return valor;
	}

	public int getPalo() {
		return palo;
	}

	/**
	 * GETRPALOCOMOSTRING
	 *
	 */
	public String getPaloComoString(int palo) {
		return PALOS[palo];
	}

	/**
	 * GETVALORCOMOSTRING
	 *
	 */
	public String getValorComoString(int valor) {
		return VALORES[valor];

	}

	/**
	 * TOSTRING
	 *
	 */
	@Override
	public String toString() {
		return VALORES[valor] + " de " + PALOS[palo];

	}
}
