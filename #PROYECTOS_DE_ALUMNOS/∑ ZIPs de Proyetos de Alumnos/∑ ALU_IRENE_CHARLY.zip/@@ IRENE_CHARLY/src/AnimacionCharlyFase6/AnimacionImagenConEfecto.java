package AnimacionCharlyFase6;
/**
 * Muestra una imagen con el efecto a convenir.
 * @author Irene.bahon
 * @version 1.0
 */
public class AnimacionImagenConEfecto extends AnimacionImagen {
	
	//ATRIBUTOS
	
	private EfectoSecuencia efecto;

	//Constructor
		/**
		 * public AnimacionImagenesConEfecto(String nombre, int ancho, int alto, Imagen imagen, EfectoSecuencia efecto)
		 * Crea una animacin con el nombre proporcionado que se mostrar en un Escenario de tamao ancho x alto.
		 * La animacin mostrar la imagen cuyo nombre de fichero se pasa como parmetro -aplicandole antes el efecto indicado- y terminar.
		 * Parameters:
		 * @param nombre;el nombre de la animacion
		 * @param ancho;el ancho del escenario donde mostrarla (en pixels)
		 * @param alto;el alto del escenario donde mostrarla (en pixels)
		 * @param imagen;el nombre del fichero con la imagen a mostrar
		 * @param efecto;el efecto a aplicar a la imagen antes de mostrarla
		 */
	
	public AnimacionImagenConEfecto(String nombre, int ancho, int alto, Imagen imagen, EfectoSecuencia efecto) throws IllegalArgumentException {
		super(nombre, ancho, alto, imagen);
		this.imagen=imagen;
		if(efecto == null){
			throw new IllegalArgumentException();
		}
		this.efecto=efecto;
		
	}

	/**
	 * public abstract void ejecutarPaso()
	 * Ejecuta un paso de la animacin y prepara todo para ejecutar el siguiente paso.
	 * Se llamar en un bucle hasta que finalice la animacin, de forma que se vaya ejecutando paso a paso.
	 */
	public void ejecutarPaso() throws IllegalStateException, IllegalArgumentException  {
	
		if(acabado){
			throw new IllegalStateException();
		}
		try {
//			Thread.sleep(2000);
			Imagen mm = efecto.primero.transformar(imagen);
			p.dibujarImagen(240, 240, mm);
				
			Thread.sleep(2000);

			mm = efecto.segundo.transformar(imagen);
			p.dibujarImagen(200, 200, mm);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		acabado = true;
	
	}

	/**
	 * public abstract boolean estaFinalizada()
	 * Devuevle si la animacin ha finalizado o no.
	 * @return
	 * True si la animacin ha finalizado
	 */
	public boolean estaFinalizada() {
		
		return acabado;
	}

	
	
	
	
}


