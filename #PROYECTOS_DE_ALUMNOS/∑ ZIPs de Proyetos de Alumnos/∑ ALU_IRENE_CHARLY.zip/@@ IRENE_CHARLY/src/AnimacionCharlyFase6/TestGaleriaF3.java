package AnimacionCharlyFase6;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Programa de prueba con mapas, donde se crea un albun con fotos el cual luego borraremos.
 * 
 * @author Irene.bahon
 * @version 1.0
 */
public class TestGaleriaF3 {

	// ATRIBUTOS
	static GaleriaF3	galeria			= new GaleriaF3();
	static String		nombreAlbum1	= "Album 1";
	static String		nombreAlbum2	= "Album 2";

	public static void main(String[] args) {

		// // ATRIBUTOS
		// GaleriaF3 gal = new GaleriaF3();
		// String a1 = "Album 1";
		// String a2 = "Album 2";

		// crear albumes
		galeria.crearAlbum(nombreAlbum1);
		galeria.crearAlbum(nombreAlbum2);

		// // crear 3 fotos por album
		// for (int i = 1; i < 7; i++) {
		// Foto fff = new Foto("Descripcion " + i, stringToFecha(i + "/5/2016"), "T" + i + ".gif");
		// gal.getAlbum(a1).addFoto(fff);
		// }
		//
		// for (int i = 6; i > 0; i--) {
		// Foto fff = new Foto("Descripcion " + i, stringToFecha(i + "/5/2016"), "T" + i + ".gif");
		// gal.getAlbum(a2).addFoto(fff);
		// }


		cargarfotos();

		// escribir info de albumes
		galeria.infoAlbumes();
		// Collection<Album> losvalores = gal.conjunto.values();
		//
		// for (Album al : losvalores) {
		// System.out.print("Nombre de album: ");
		// System.out.println(al.getNombre());
		//
		// // escribir info de fotos de cada album
		// for (Foto fot : al.listaFotos) {
		// System.out.println("\tFoto:\t" + fot.getDescripcion());
		// }
		// }

		// Realizar la presentacion de las fotos del primer aÌlbum.
		try {
			galeria.presentarAlbum(nombreAlbum1, 1000);
			Thread.sleep(500);
			galeria.presentarAlbum(nombreAlbum2, 1000);


			// Borrar todas las fotos del primer album
			System.out.println("Tamao del album antes de borrarlo:" + galeria.getAlbum(nombreAlbum1).listaFotos.size());
			galeria.getAlbum(nombreAlbum1).listaFotos.clear();

			// Iterator<Foto> ite = galeria.getAlbum(nombreAlbum1).listaFotos.iterator();
			// while (ite.hasNext()) {
			// System.out.println(ite.next().toString());
			// ite.remove();
			// }
			System.out.println("Tamao del 1er album tras borrarlo:" + galeria.getAlbum(nombreAlbum1).listaFotos.size());

			// Borrar el primer album.
			galeria.delAlbum(nombreAlbum1);
			System.out.println("Se ha borrado el " + nombreAlbum1);

			// Borrar todas las fotos del segundo album
			System.out.println("Tamao del album antes de borrarlo:" + galeria.getAlbum(nombreAlbum2).listaFotos.size());
			galeria.getAlbum(nombreAlbum2).listaFotos.clear();

			// Iterator<Foto> ite2 = galeria.getAlbum(nombreAlbum2).listaFotos.iterator();
			// while (ite2.hasNext()) {
			// System.out.println(ite2.next().toString());
			// ite2.remove();
			// }
			System.out.println("Tamao del 2 album tras borrarlo:" + galeria.getAlbum(nombreAlbum2).listaFotos.size());

			// Borrar el segundo album.
			galeria.delAlbum(nombreAlbum2);
			System.out.println("Se ha borrado el " + nombreAlbum2);
			if (galeria.getAlbumes().length == 0) {
				System.out.println("\nN de albums tras borrarlos: " + galeria.getAlbumes().length);
				System.out.println("No queda ninguno");
			}
		}
		catch (GaleriaException e) {
			e.printStackTrace();
		}
		catch (InterruptedException e) {
			e.printStackTrace();
		}

	}

	static public void cargarfotos() {

		galeria.getAlbum(nombreAlbum1).addFoto(new Foto("Detalle de foto 1", stringToFecha("12/01/2016"), "T1.gif"));
		galeria.getAlbum(nombreAlbum1).addFoto(new Foto("Detalle de foto 2", stringToFecha("16/02/2016"), "T2.gif"));
		galeria.getAlbum(nombreAlbum1).addFoto(new Foto("Detalle de foto 3", stringToFecha("22/01/2016"), "T3.gif"));
		galeria.getAlbum(nombreAlbum2).addFoto(new Foto("Detalle de foto 4", stringToFecha("12/04/2016"), "T4.gif"));
		galeria.getAlbum(nombreAlbum2).addFoto(new Foto("Detalle de foto 5", stringToFecha("13/02/2016"), "T5.gif"));
		galeria.getAlbum(nombreAlbum2).addFoto(new Foto("Detalle de foto 6", stringToFecha("19/01/2016"), "T6.gif"));

	}


	// Cambio de To String a fecha.
	static public Date stringToFecha(String strFecha) {
		SimpleDateFormat miFormato2 = new SimpleDateFormat("dd/MM/yyyy");
		Date fecha = null;
		try {
			fecha = miFormato2.parse(strFecha);
		}
		catch (java.text.ParseException e) {
			e.printStackTrace();
			return null;
		}
		return fecha;
	}

}