package AnimacionCharlyFase6;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Programa de prueba con conjuntos, donde se crea un albun con fotos el cual luego borraremos.
 * 
 * @author carlos.fernandez.olmedilla
 * @version 1.0
 */
public class TestGaleriaF2 {

	// ATRIBUTOS
	static GaleriaF2	galeria			= new GaleriaF2();
	static String		nombreAlbum1	= "Album 1";
	static String		nombreAlbum2	= "Album 2";

	public static void main(String[] args) {


		// crear albumes
		galeria.crearAlbum(nombreAlbum1);
		galeria.crearAlbum(nombreAlbum2);

		// crear 3 fotos por album
		// for (int i = 0; i < 6; i++) {
		// Date fecha = stringToFecha("1" + i + "/1/2016");
		// Foto fff = new Foto("Descripcion " + (i + 1), fecha, "T" + (i + 1) + ".gif");
		// galeria.getAlbum(nombreAlbum1).addFoto(fff);
		// }
		//
		// for (int i = 3; i < 6; i++) {
		// Date fecha = stringToFecha("1" + i + "/1/2016");
		// Foto fff = new Foto("Descripcion " + (i + 1), fecha, "T" + (i + 1) + ".gif");
		// galeria.getAlbum(nombreAlbum2).addFoto(fff);
		// }

		cargarfotos();
		// galeria.getAlbum(nombreAlbum1)
		// .addFoto(new Foto("Detalle de foto 1", stringToFecha("12/01/2016"), "T1.gif"));
		// galeria.getAlbum(nombreAlbum1)
		// .addFoto(new Foto("Detalle de foto 2", stringToFecha("16/02/2016"), "T2.gif"));
		// galeria.getAlbum(nombreAlbum1)
		// .addFoto(new Foto("Detalle de foto 3", stringToFecha("22/01/2016"), "T3.gif"));
		// galeria.getAlbum(nombreAlbum2)
		// .addFoto(new Foto("Detalle de foto 4", stringToFecha("12/04/2016"), "T4.gif"));
		// galeria.getAlbum(nombreAlbum2)
		// .addFoto(new Foto("Detalle de foto 5", stringToFecha("13/02/2016"), "T5.gif"));
		// galeria.getAlbum(nombreAlbum2)
		// .addFoto(new Foto("Detalle de foto 6", stringToFecha("19/01/2016"), "T6.gif"));

		// escribir info de albumes
		// for (Album album : galeria.conjunto) {
		// System.out.println("Nombre de album: " + album.getNombre());
		//
		// // escribir info de fotos de cada album
		// for (Foto fot : album.listaFotos) {
		// System.out.println(" Foto : " + fot.getDescripcion());
		//
		// }
		// }

		galeria.infoAlbumes();

		try {
			// Realizar la presentacion de las fotos de los albums.
			galeria.presentarAlbum(nombreAlbum1, 1000);
			Thread.sleep(500);
			galeria.presentarAlbum(nombreAlbum2, 1000);

			// Borrar todas las fotos del primer album

			System.out.println("Tamao del album antes de borrarlo:" + galeria.getAlbum(nombreAlbum1).listaFotos.size());
			galeria.getAlbum(nombreAlbum1).listaFotos.clear();

			// Iterator<Foto> ite = galeria.getAlbum(nombreAlbum1).listaFotos.iterator();
			// while (ite.hasNext()) {
			// System.out.println(ite.next().toString());
			// ite.remove();
			// }
			System.out.println("Tamao del album tras borrarlo:" + galeria.getAlbum(nombreAlbum1).listaFotos.size());

			// Borrar el primer album.
			System.out.println("Se ha borrado el " + nombreAlbum1);
			galeria.delAlbum(nombreAlbum1);

			// Borrar todas las fotos del segundo album
			System.out.println("Tamao del album antes de borrarlo:" + galeria.getAlbum(nombreAlbum2).listaFotos.size());
			galeria.getAlbum(nombreAlbum2).listaFotos.clear();

			// Iterator<Foto> ite2 = galeria.getAlbum(nombreAlbum2).listaFotos.iterator();
			// while (ite2.hasNext()) {
			// System.out.println(ite2.next().toString());
			// ite2.remove();
			// }
			System.out.println("Tamao del album tras borrarlo:" + galeria.getAlbum(nombreAlbum2).listaFotos.size());

			// Borrar el segundo album.
			galeria.delAlbum(nombreAlbum2);
			System.out.println("Se ha borrado el " + nombreAlbum2);
			System.out.println("\nN de albums en la galeria tras borrar 2:" + galeria.getAlbumes().length);
		}
		catch (GaleriaException e) {
			e.printStackTrace();
		}
		catch (InterruptedException ex) {
			ex.printStackTrace();
		}
	}


	static public void cargarfotos() {

		galeria.getAlbum(nombreAlbum1).addFoto(new Foto("Detalle de foto 1", stringToFecha("12/01/2016"), "T1.gif"));
		galeria.getAlbum(nombreAlbum1).addFoto(new Foto("Detalle de foto 2", stringToFecha("16/02/2016"), "T2.gif"));
		galeria.getAlbum(nombreAlbum1).addFoto(new Foto("Detalle de foto 3", stringToFecha("22/01/2016"), "T3.gif"));
		galeria.getAlbum(nombreAlbum2).addFoto(new Foto("Detalle de foto 4", stringToFecha("12/04/2016"), "T4.gif"));
		galeria.getAlbum(nombreAlbum2).addFoto(new Foto("Detalle de foto 5", stringToFecha("13/02/2016"), "T5.gif"));
		galeria.getAlbum(nombreAlbum2).addFoto(new Foto("Detalle de foto 6", stringToFecha("19/01/2016"), "T6.gif"));

	}


	// Cambio de To String a fecha.
	static public Date stringToFecha(String strFecha) {
		SimpleDateFormat unformato = new SimpleDateFormat("dd/MM/yyyy");
		Date fecha = null;
		try {
			fecha = unformato.parse(strFecha);
		}
		catch (java.text.ParseException e) {
			e.printStackTrace();
			return null;
		}
		return fecha;
	}

}