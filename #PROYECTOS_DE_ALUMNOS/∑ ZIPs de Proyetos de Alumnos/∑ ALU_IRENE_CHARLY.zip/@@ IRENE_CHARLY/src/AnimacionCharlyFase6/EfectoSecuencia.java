package AnimacionCharlyFase6;
/**
 * Efecto Secuencia, se realizan ambos efectos de EscalaEfectoGrises y EfectoLibre sobre la misma imagen.
 * @author Irene.bahon
 * @version 1.0
 */
public class EfectoSecuencia implements Efecto {

	//ATRIBUTOS
	public Efecto primero;
	public Efecto segundo;
	
	//Constructor
		/**
		 * public  EfectoSecuencia(Efecto primero, Efecto segundo) 
		 * @param primero
		 * @param segundo
		 */
	
	public  EfectoSecuencia(Efecto primero, Efecto segundo) {
		this.primero=primero;
		this.segundo=segundo;
	}
	
	
	
	//Metodos
		/**
		 * public Imagen transformar(Imagen entrada)
		 * @return entrada.
		 */
	public Imagen transformar(Imagen entrada) throws IllegalArgumentException{
		
		if(entrada == null){
			throw new IllegalArgumentException();
		}
		entrada=primero.transformar(entrada);
		entrada=segundo.transformar(entrada);
		
		return entrada;
	}

}
