package AnimacionCharlyFase6;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Set;

/**
 * Galeria F3: perteneciente a mapas.
 * 
 * @author carlos.fernandez.olmedilla
 * @version 1.0
 */
public class GaleriaF3 implements IGaleria {

	HashMap<String, Album> conjunto = new HashMap<>();


	public void infoAlbumes() {
		Collection<Album> losvalores = conjunto.values();

		for (Album al : losvalores) {
			System.out.print("Nombre de album: ");
			System.out.println(al.getNombre());

			// escribir info de fotos de cada album
			for (Foto fot : al.listaFotos) {
				System.out.println("\tFoto:\t" + fot.getDescripcion());
			}
		}
	}

	/**
	 * public boolean crearAlbum(String album)
	 * Crea un album y lo aade a la coleccion de base
	 * Parameters:
	 * 
	 * @param album;el
	 *            nombre del album
	 * @return true si lo ha creado y aadido, y false si no.
	 * @throws IllegalArgumentException,
	 *             si el parametro album es null
	 */
	@Override
	public boolean crearAlbum(String album) throws IllegalArgumentException {
		if (album == null) throw new IllegalArgumentException();
		Album a = new Album(album);
		conjunto.put(a.getNombre(), a);
		return false;
	}

	/**
	 * public Album getAlbum(String album)
	 * Devuelve el citado album sin borrarlo de la coleccion
	 * Parameters:
	 * 
	 * @param album;nombre
	 *            del album
	 * @return el Album o null si no existe album con ese nombre
	 * @throws IllegalArgumentException,
	 *             si el parametro nombre es null
	 */
	@Override
	public Album getAlbum(String album) throws IllegalArgumentException {
		if (album == null) throw new IllegalArgumentException();
		Collection<Album> losvalores = conjunto.values();
		for (Album a : losvalores) {
			if (a.getNombre().equals(album)) { return a; }
		}
		return null;
	}

	/**
	 * public Album delAlbum(String album)
	 * Borramos el citado album de la coleccion
	 * Parameters:
	 * 
	 * @param album;nombre
	 *            del album
	 * @return el album borrado o null si no lo ha podido borrar por que no exista
	 * @throws IllegalArgumentException,
	 *             si el parametro album es null
	 */
	@Override
	public Album delAlbum(String album) throws IllegalArgumentException {
		if (album == null) throw new IllegalArgumentException();
		Set<String> lasclaves = conjunto.keySet();
		for (String ss : lasclaves) {
			Album m = conjunto.get(ss);
			if (m.getNombre().equals(album)) {
				conjunto.remove(ss);
				return m;
			}
		}
		return null;
	}

	/**
	 * public String[] getAlbumes()
	 * Devuelve los nombres de los albumes o null si no existe ninguno
	 * 
	 * @return array de nombres
	 */
	@Override
	public String[] getAlbumes() {
		String[] aa = new String[conjunto.size()];
		int x = 0;
		Collection<Album> losvalores = conjunto.values();
		for (Album a : losvalores) {
			aa[x] = a.getNombre();
			x++;
		}
		return aa;
	}

	/**
	 * public void presentarAlbum(String album,int retardo)
	 * Visualizar las fotos de un determinado album a traves de una de las animaciones de la practica 5,
	 * eligiremos la clase AnimacionImagenesCircular
	 * Parameters:
	 * 
	 * @param album;nombre
	 *            del album
	 * @param retardo;entre
	 *            pasos de ejecucion
	 * @throws GaleriaException,
	 *             si no existe el album o se produce la excepcion AnimacionException
	 * @throws IllegalArgumentException,
	 *             si el album es null o retardo negativo
	 * @throws AnimacionException
	 */
	@Override
	public void presentarAlbum(String album, int retardo) throws GaleriaException {
		if (album == null || retardo < 0) throw new GaleriaException("***Error***");
		AnimacionImagenes a7 = null;
		Collection<Album> losvalores = conjunto.values();
		for (Album al : losvalores) {
			if (al.getNombre().equals(album)) {
				ArrayList<Foto> arrfotos = al.listaFotos;
				// animacionImagenesCircular necesita una array de Imagen
				// Lo creamos a partir de un array de Foto

				Imagen[] lisimagenes = crearArrayImagenes(arrfotos);
				// Imagen[] lisimagenes = new Imagen[arrfotos.size()];
				// for (int i = 0; i < lisimagenes.length; i++) {
				// Imagen kk = new Imagen(arrfotos.get(i).getNomFichero());
				// lisimagenes[i] = kk;
				// }

				try {
					a7 = new AnimacionImagenes("Animacion de Fase3", 600, 600, lisimagenes);
				}
				catch (IllegalArgumentException e) {
					e.printStackTrace();
				}
				catch (AnimacionException e) {
					// capturar la excepcion AnimacionException y lanzar en su lugar GaleriaException
					throw new GaleriaException("Error de tipo Galeria Exception");
				}
			}
		}
		new P5F2();
		P5F2.player(a7, 200);
	}


	private Imagen[] crearArrayImagenes(ArrayList<Foto> arrayf) {
		Imagen[] lisim = new Imagen[arrayf.size()];
		for (int i = 0; i < lisim.length; i++) {
			lisim[i] = new Imagen(arrayf.get(i).getNomFichero());
		}
		return lisim;
	}


}