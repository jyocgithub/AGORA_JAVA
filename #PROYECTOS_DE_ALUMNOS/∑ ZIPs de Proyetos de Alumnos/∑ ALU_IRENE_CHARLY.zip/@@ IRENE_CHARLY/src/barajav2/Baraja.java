package barajav2;

/*
 * Esta clase modela representa el comportamiento de una baraja espaola de 48 cartas.
 * @author Irene Bahon Mora
 * @version 1.0
 */
public class Baraja {

	public static final int NUMCARTAS = 48;
	private Carta[] laBaraja = new Carta[NUMCARTAS];
	public int cartasEnElMazo;

	// CONSTRUCTOR

	/**
	 * BARAJA
	 * 
	 * public Baraja() Crear una Baraja Espaola. Las cartas inicialmente se encuentran organizadas por palos -OROS, COPAS, ESPADAS
	 * y BASTOS- y a su vez ordenadas en sentido creciente - de AS a REY-. La primera posicin del mazo (cima) ser el AS de OROS.
	 */
	public Baraja() {

		inicializar();
		cartasEnElMazo = 48;
	}

	// METODOS

	/**
	 * BARAJAR public void barajar(int cartasEnElMazo) Este mtodo permite barajar las cartas. Parameters: veces - nmero de veces
	 * que se quiere barajar el mazo. Si su valor es 0 no se barajar.
	 */
	public void barajar(int cuantas) {

		Carta intermedia;
		for (int i = 0; i < cartasEnElMazo - 1; i++) {
			int x = (int) (Math.random() * ((cartasEnElMazo - 1)) + 1);
			int y = (int) (Math.random() * ((cartasEnElMazo - 1)) + 1);
			intermedia = laBaraja[x];
			// System.out.println(x +":" + y);
			laBaraja[x] = laBaraja[y];
			laBaraja[y] = intermedia;
		}

	}

	/**
	 * GETCARTACIMA
	 * 
	 * public Carta getCartaCima() Devuelve la carta que esta en la cima del mazo de cartas eliminandola del mazo haciendo que la
	 * cima del mismo apunte a la siguiente. La posicin del array donde esta la carta pasa a null para impedir su reutilizacin.
	 * Returns:La carta que se encuentra actualmente en la cima del mazo
	 */
	public Carta getCartaCima() {

		if (cartasEnElMazo == 0) {
			return null;
		}

		Carta c = laBaraja[cartasEnElMazo - 1];
		laBaraja[cartasEnElMazo - 1] = null;
		cartasEnElMazo--;

		return c;
	}

	/**
	 * GETCARTAPOSICION
	 * 
	 * public Carta getCartaPosicion(int posicion) Devuelve la carta del mazo que se encuentra en una determinada posicin. Todas
	 * las cartas entre la cima del mazo y la posicin debern moverse hacia el final del array. de forma que el array se empezara a
	 * reducir siendo la posicion puesta en null del lugar en el que se enconctraba la carta. Parameters: posicion - de la carta
	 * solicitada dentro del mazo. La posicin de la carta se indica usando nmero naturales de forma que 1 indica la posicin de la
	 * carta en la cima del mazo, 2 la segunda asi hasta la ltima carta que quede en el mazo. Returns:La Carta de la baraja que se
	 * encuentra en la posicion del mazo pedida.
	 */
	public Carta getCartaPosicion(int posicion) {
		if (cartasEnElMazo > 0) {
			if (posicion < cartasEnElMazo) {
				Carta c = laBaraja[posicion];
				for (int i = posicion; i < cartasEnElMazo - 1; i++) {
					laBaraja[i] = laBaraja[i + 1];
				}
				// la ultima carta eahora estara vacia
				laBaraja[cartasEnElMazo - 1] = null;
				cartasEnElMazo = cartasEnElMazo - 1;
				return c;
			}
		}
		return null;
	}

	/**
	 * INICIALIZAR
	 * 
	 * public void inicializar() Resetea las baraja. Se colocaran de la misma manera que en el constructor(mismo orden)
	 */
	public void inicializar() {
		int x = 0;
		for (int i = 0; i < 4; i++) {
			for (int j = 1; j < 13; j++) {
				laBaraja[x] = new Carta(i, j);
				x = x + 1;
			}
		}
	}

	/**
	 * TAMANO
	 * 
	 * public int tamano() Devuelve el numero de cartas que en ese momento tiene el mazo. Returns: numero entero entre 1 y 48 con el
	 * tamano del mazo.
	 */
	public int tamano() {
		return cartasEnElMazo;
	}

	/**
	 * CARTA[]
	 * 
	 * public Carta[] todas() Devuelve un array de Cartas con las que en ese instante estan en la baraja. Returns:El array de
	 * Cartas. Si no quedan cartas devuelve null.
	 */
	public Carta[] todas() {
		return laBaraja;
	}

	/**
	 * TOSTRING
	 * 
	 * public String toString Redefine el mtodo toString para obtener un String con las cartas que en un instante determinado estan
	 * en el mazo y en el orden en que se encuentran. El formato de salida es: [valor] de [palo] por ejemplo: 7 de Oros As de
	 * Bastos... Overrides: toString in class java.lang.ObjectReturns:String con la representacin de las cartas del mazo o un array
	 * vaco si no quedan cartas
	 */
	@Override
	public String toString() {
		String resultado = "Baraja actual: \n";
		for (int i = 0; i < cartasEnElMazo; i++) {
			resultado = resultado + laBaraja[i].getValorComoString() + " de " + laBaraja[i].getPaloComoString() + "\n";
		}
		return resultado;
	}

}
