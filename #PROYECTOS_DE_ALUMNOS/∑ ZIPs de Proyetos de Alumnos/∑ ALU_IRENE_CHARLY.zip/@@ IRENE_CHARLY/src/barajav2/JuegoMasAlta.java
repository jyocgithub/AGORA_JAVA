package barajav2;

import java.util.Scanner;

/**
 * Aplicacin: juego de la carta ms alta.
 * 
 * @author DTE
 * @version 1
 *
 */
public class JuegoMasAlta {
	/*
	 * Metodo principal de la aplicacin de juego.
	 * 
	 * @param args Array de String con los parmetros necesarios para el funcionamiento de la aplicacin. Deberan pasarse dos
	 * parmetros: El nmero de jugadores, la cantidad de dinero que dispondr cada uno. El formato del mandato ser: <code>java
	 * JuegoMasAltaV1 [jugadores] [euros totales por jugador] </code> Por ejemplo: <code>java JuegoMasAltaV1 [4] [1000] </code> Para
	 * poder jugar a este juego el numero de jugadores debe de ser como mnimo 2 y cada uno con un mnimo de 100 euros.
	 */
	static boolean finPartida = false;

	static double apuesta;
	static int numRonda = 0;
	static Carta carta = null;
	static Carta masAlta = null;
	static Jugador ganador = null;
	static Jugador ganadorTotal = null;
	static Jugador jugador;
	static int numero;
	static Baraja baraja;

	public static void main(String[] args) {
		Jugador[] jugadores;

		if (args.length != 2) {
			System.out.println("Error en los argumentos del programa:");
			System.out.println("teclear: java JuegoMasAltaV1 [jugadores]  [euros totales por jugador] ");
		} else {
			int numJugadores = Integer.parseInt(args[0]);
			int cantidad = Integer.parseInt(args[1]);
			if (numJugadores < 2 || cantidad < 100) {
				System.out.println("los valores de los argumentos no permiten jugar");
			} else {
				jugadores = new Jugador[numJugadores];
				for (int i = 0; i < jugadores.length; i++) {
					jugadores[i] = new Jugador(i + 1, cantidad);
				}
				baraja = new Baraja();
				play(jugadores);
			}
		}

	} // del main

	/**
	 * Metodo que invocado desde el programa principal crea una partida
	 * 
	 * @param jugadores
	 *            Array con los jugadores que jugaran la partida
	 * @param baraja
	 *            la baraja con la que jugarn la partida
	 */
	public static void play(Jugador[] jugadores) {

		System.out.println("\n\t\tCOMIENZA LA PARTIDA\n");

		int tamano = baraja.tamano();
		baraja.barajar(1);

		// COMIENZA LA PARTIDA
		do {
			// se mete en un bucle hasta ver si los jugadores actuales
			// pueden cubrir la apuesta pedida.
			System.out.println("Ronda numero: " + (numRonda + 1));
			boolean aceptada;
			Scanner scanner = new Scanner(System.in);
			do {
				aceptada = true;
				// PEDIR CANTIDAD A APOSTAR
				System.out.println("Cantidad a apostar:");
				apuesta = scanner.nextInt();
				// COMPROBAR SI TODOS TIENEN SALDO SUFCIENTE
				// SI NO LO TIENEN PONER aceptada = false
				for (int i = 0; i < jugadores.length; i++) {
					if (apuesta > jugadores[i].getSaldo()) aceptada = false;
				}
			} while (!aceptada);

			// miramos si quedan suficientes cartas en la baraja para los
			// jugadores actuales
			// si no quedan reseteamos y barajamos de nuevo.
			if (tamano < jugadores.length) {
				baraja.inicializar();
				baraja.barajar(tamano);
			}
			numRonda++;

			// COMIENZA LA RONDA
			// BUCLE DE JUGADOREES,
			Carta[] cartasDeLaRonda = new Carta[jugadores.length];
			for (int i = 0; i < jugadores.length; i++) {
				System.out.print("Le toca al jugador " + jugadores[i].getNumero() + "n");
				Carta cartaElegida = elegirCarta();
				cartasDeLaRonda[i] = cartaElegida;
			}

			// METODO QUE DEVUELVE EL INDICE DEL GANADOR
			int indiceDelGanador = elegirGanador(jugadores, cartasDeLaRonda);
			ganador = jugadores[indiceDelGanador];

			// se muestran resultados : Carta ms alta y jugador ganador.
			for (int i = 0; i < jugadores.length; i++) {
				System.out.println("Jugador numero " + jugadores[i].getNumero() + ", tienes en la mano la carta  "
						+ cartasDeLaRonda[i].toString());

			}
			System.out.println("GANADOR DE LA MANO: El jugador numero " + ganador.getNumero() + ", con la carta: "
					+ cartasDeLaRonda[indiceDelGanador].toString());
			jugadores[indiceDelGanador].incrementaGanadas();

			// Anotamos en el cambio de saldo de cada jugador
			// segun si ha ganado o no
			for (int x = 0; x < jugadores.length; x++) {
				if (x == indiceDelGanador) {
					// al que gana le sumamos lo apostado por todos los demas jugadores
					jugadores[x].setSaldo(apuesta * (jugadores.length - 1));
				} else {
					jugadores[x].setSaldo(apuesta * (-1));
				}
			}

			// mostrar informacion de como estan los jugadores
			System.out.println("");
			System.out.println("JUGADORES EN LA SIGUIEMTE RONDA:");

			for (int x = 0; x < jugadores.length; x++) {
				System.out.println(jugadores[x].toString());
			}

			// Eliminamos a los jugadores que se han quedado sin dinero
			// reconstruimos el array de jugadores quitando a los perdedores
			jugadores = eliminaCeros(jugadores);

			// Comprueba si hay un ganador absoluto para terminar la partida.
			// Si no hay un jugador ganador volver a jugar
			if (jugadores.length == 1) {
				ganadorTotal = jugadores[0];
				finPartida = true;
			} else {
				for (int i = 0; i < jugadores.length; i++) {
					if (jugadores[i].getGanadas() == 5) {
						ganadorTotal = jugadores[i];
						finPartida = true;
					}
				}
			}
		} while (!finPartida);

		System.out.println("\n\t\tLA PARTIDA HA TERMINADO\n");
		System.out.println("EL GANADOR ABSOLUTO ES:" + ganadorTotal.toString());

	}

	/**
	 * Metodo que invocado desde el mtodo play, elije una carta de la baraja
	 * 
	 * 
	 * @return un objeto cart ade la cart aelegida
	 */
	private static Carta elegirCarta() {
		System.out.println("indicar el numero de carta que desea o 0 si quiere la del monton:");
		Scanner scanner = new Scanner(System.in);
		int opcion = scanner.nextInt();
		Carta unacarta;
		if (opcion == 0) {
			unacarta = baraja.getCartaCima();
		} else {

			while (numero > baraja.tamano()) {
				System.out.println("numero de carta erroneo. elija otra carta");
				numero = scanner.nextInt();
			}
		}
		unacarta = baraja.getCartaPosicion(numero);
		return unacarta;
	}

	/**
	 * Metodo que invocado desde el mtodo play recostruye el array de jugadores eliminando las posiciones que tengan un valor null
	 * 
	 * @param jugadores
	 *            Array con los jugadores que estan jugando la partida
	 * @return un nuevo array de jugadores con los que tienen un saldo superior a 0
	 */
	private static Jugador[] eliminaCeros(Jugador[] juga) {
		int cuantosQuedan = 0;
		for (int i = 0; i < juga.length; i++) {
			if (juga[i].getSaldo() > 0) cuantosQuedan++;
		}
		int indiceArrayJuga2 = 0;
		Jugador[] juga2 = new Jugador[cuantosQuedan];
		for (int i = 0; i < juga.length; i++) {
			if (juga[i].getSaldo() > 0) {
				juga2[indiceArrayJuga2] = juga[i];
				indiceArrayJuga2++;
			}
		}
		juga = juga2;
		return juga;
	}

	/**
	 * Metodo que elige un badanor si lo hay
	 */
	public static int elegirGanador(Jugador[] ju, Carta[] car) {
		Carta masAlta = car[0];
		int elquegana = 0;
		for (int x = 0; x < ju.length; x++) {
			// analizamos cada carta car[x] para ver si es mayor
			if (car[x].getPalo() < masAlta.getPalo()) {
				masAlta = car[x];
				elquegana = x; // car[x] tiene un palo menor
			} else if ((car[x].getPalo() == masAlta.getPalo()) // car[x] tiene un palo igual
					&& (car[x].getValor() > masAlta.getValor())) { // car[x] tiene un valor mayor
				masAlta = car[x];
				elquegana = x;
			}
		}
		return elquegana;
	}
}
