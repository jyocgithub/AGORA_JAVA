package barajav2;

/*
 * Esta clase representa los datos de una carta perteneciente a una baraja.
 * @author Irene Bahon Mora.
 * @version 1.0
 */
public class Carta {

	// ATRIBUTOS

	public static final int OROS = 0;
	public static final int COPAS = 1;
	public static final int ESPADAS = 2;
	public static final int BASTOS = 3;

	public static final int AS = 1;
	public static final int SOTA = 10;
	public static final int CABALLO = 11;
	public static final int REY = 12;

	public static final int NUMCARTAS = 48;
	public static final int NUMPALOS = 4;
	public static final int NUMVALORES = 12;

	private int valor;
	private int palo;

	public static final String[] PALOS = { "OROS", "COPAS", "ESPADAS", "BASTOS" };
	public static final String[] VALORES = { "", "As", "2", "3", "4", "5", "6", "7", "8", "9", "Sota", "Caballo",
			"Rey" };

	// CONSTRUCTOR

	/**
	 * CARTA public Carta(int palo, int valor) Crea una Carta con el palo y valor deseado. Parameters: valor - de la nueva tarjeta.
	 * Debe estar en el rango de 1 A 12, donde 1 representa un AS. Puede utilizar las constantes Carta.AS, Carta.SOTA, Carta.CABALLO
	 * y Carta.REY. palo - el palo de la nueva Carta.Este debe ser uno de los valores Carta.OROS, Carta.COPAS, Carta.ESPADAS,
	 * Carta.BSATOS
	 */
	public Carta(int palo, int valor) {
		this.palo = palo;
		this.valor = valor;
	}

	// METODOS

	/**
	 * GETVALOR
	 *
	 * public int getValor() Devuelve el valor de la carta. Returns:Un entero entre 1 y 10.
	 */
	public int getValor() {
		return valor;
	}

	/**
	 * GETPALO
	 * 
	 * public int getPalo() Devuelve el palo de la carta. Returns:el palo de la carta el que es una de las constantes Carta.OROS,
	 * Carta.COPAS, Carta.ESPADAS o Carta.BASTOS
	 */
	public int getPalo() {
		return palo;
	}

	/**
	 * GETPALOCOSTRING
	 * 
	 * public String getPaloComoString() Devuelve un String representacin del palo de la carta. Returns:uno de los Strings "Oros",
	 * "Copas", "Espadas", or "Bastos".
	 */
	public String getPaloComoString() {
		return PALOS[palo];
	}

	/**
	 * GETVALORCOMOSTRING
	 * 
	 * public String getValorComoString() Devuelve un String representacin del valor de la carta Returns:uno de los strings "AS",
	 * "2", "3", ..., "9", "Sota", "Caballo", or "Rey".
	 */
	public String getValorComoString() {
		return VALORES[valor];
	}

	/**
	 * TOSTRING
	 * 
	 * public String toString() Devuelve a string representacin of esta carta, incluye palo y valor. Ejemplos: "Sota de Bastos",
	 * "6 de Espadas", "As de oros". Overrides:toString in class java.lang.ObjectReturns:un string que representa textualmente la
	 * carta
	 */
	@Override
	public String toString() {
		return VALORES[valor] + " de " + PALOS[palo];
	}

}