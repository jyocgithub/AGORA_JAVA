
public class Cliente {

	//ATRIBUTOS
	
	private String nombre; //Nombre del cliente al cual pertenece la cuenta.
	private String NIF;	   // DNI del cliente
	
	//CONSTRUCTOR
	public Cliente(String nombre,String NIF){
		this.nombre=nombre;
		this.NIF=NIF;
	}
	
	//METODOS
	
	/**
	 * public String getNombre()
	 * Permite conocer el nombre del cliente.
	 * @return nombre
	 */
	public String getNombre(){
		return nombre;
	}
	
	/**
	 * public java.lang.String getNIF()
	 * Permite conocer el NIF del cliente.
	 * @return NIF
	 */
	public java.lang.String getNIF(){
		return NIF;
	}
}
