import java.util.Date;

/**
 * Clase que crea una cuenta bancaria con un c�digo de cuenta que la identifica un�vocamente.
 * 
 * @author Irene Bahon Mora
 * @version 1.0
 */

public class CuentaBancaria {

	// ATRIBUTOS
	private double	saldo;			// Nunca puede ser saldo negativo.
	private String	numeroCuenta;	// Numero de la cuenta EEEENNNNNNNNNN
	private Cliente	cliente;		// Titular de la cuenta
	private Date	fecha;			// Fecha creacion de la cuenta

	// CONSTRUCTOR
	public CuentaBancaria(String numeroCuenta, Cliente cliente) {
		// assert(saldo>0.0);
		this.numeroCuenta = numeroCuenta;
		this.cliente = cliente;
	}

	// METODOS

	/**
	 * public String getnumero()
	 * Permite conocer el c�digo de la cuenta bancaria.
	 * 
	 * @return Devuelve el c�digo de la cuenta bancaria.
	 */
	public String getCodigo() {
		return numeroCuenta;
	}

	/**
	 * public Cliente getCliente()
	 * Permite conocer el cliente de la cuenta bancaria.
	 * 
	 * @return Devuelve el objeto Cliente de la cuenta bancaria.
	 */
	public Cliente getCliente() {
		return cliente;
	}

	/**
	 * public Date getFecha()
	 * Permite conocer la fecha de creaci�n e de la cuenta bancaria.
	 * 
	 * @return Devuelve el objeto Date con la fecha de la cuenta bancaria.
	 */
	public Date getFecha() {
		return fecha;
	}

	/**
	 * public double getSaldo()
	 * Permite conocer el saldo de la cuenta bancaria.
	 * 
	 * @return Devuelve el saldo de la cuenta bancaria.
	 */

	public double getSaldo() {
		return saldo;
	}

	/**
	 * public double sacar(double cantidad)
	 * Extrae una cantidad de dinero de la cuenta.
	 * Si la cantidad es menor que 0 o si el saldo es insuficiente no se realiza la operaci�n.
	 * 
	 * @param cantidad
	 *            - Cantidad a retirar de la cuenta bancaria.
	 * @return Devuelve la cantidad retirada o 0 en caso de error.
	 */

	public double sacar(double cantidad) {
		double res = 0;

		if (cantidad < 0 || cantidad > saldo) {
			return res;
		}
		else {
			res = cantidad;
			saldo = saldo - cantidad;
		}

		return res;

	}

	/**
	 * public double ingresar(double cantidad)
	 * Ingresa en la cuenta una cantidad de dinero.
	 * Si la cantidad es menor que 0 no realiza la operaci�n.
	 * 
	 * @param cantidad
	 *            - Cantidad a ingresar.
	 * @return Devuelve el dinero ingresado (0 en caso de error).
	 */

	public double ingresar(double cantidad) {
		double res = 0;

		if (cantidad < 0) {
			return res;
		}
		else {
			res = cantidad;
			saldo = saldo + cantidad;
		}

		return res;
	}

	/**
	 * public double transferir(double cantidad,CuentaBancaria destino)
	 * Extrae una cantidad de la cuenta actual y la ingresa en una cuenta destino.
	 * Si la cantidad es menor que 0 o si el saldo es insuficiente no realiza la operaci�n.
	 * 
	 * @param cantidad
	 *            - Cantidad de dinero a transferir.
	 * @param destino
	 *            - Cuenta bancaria destino a la que se hace la transferencia.
	 * @return Devuelve el dinero transferido (0 en caso de error).
	 */

	public double transferir(double cantidad, CuentaBancaria destino) {
		double res = 0;

		if (cantidad < 0 || cantidad > saldo) {
			return res;
		}
		else {
			sacar(cantidad);
			destino.ingresar(cantidad);
		}

		return res;

	}

	// toString
	@Override
	public String toString() {
		return "CuentaBancaria " + numeroCuenta + " : saldo=" + saldo + ", nombre cliente="
		        + cliente.getNombre();
	}

}
