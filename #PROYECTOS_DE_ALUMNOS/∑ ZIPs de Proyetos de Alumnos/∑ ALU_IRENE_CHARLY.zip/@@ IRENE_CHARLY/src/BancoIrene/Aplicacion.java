
public class Aplicacion {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		// ATRIBUTOS
		Banco banco;
		Cliente cliente1;
		Cliente cliente2;
		// CuentaBancaria cuenta1;
		// CuentaBancaria cuenta2;

		System.out.println("\tAPLICACION\n");
		// Creara un banco con 2 cuentas, una para cada cliente
		banco = new Banco(2, "ES80");

		// Creara 2 usuarios o clientes para las cuentas.
		cliente1 = new Cliente("JUAN", "54782412-H");
		cliente2 = new Cliente("PEPE", "75456344-G");

		// Crea una cuenta para cada usuario o cliente.
		// cuenta1 = new CuentaBancaria("101", cliente1);
		// cuenta2 = new CuentaBancaria("102", cliente2);

		System.out.println("El cliente " + cliente1.getNombre() + " con DNI: " + cliente1.getNIF());
		System.out.println("El cliente " + cliente2.getNombre() + " con DNI: " + cliente2.getNIF() + "\n");

		// Abrira una cuenta para cada usuario o cliente.
		banco.abrirCuenta(cliente1);
		banco.abrirCuenta(cliente2);

		// OBTENGO UN ARRAY CON TODAS LA CUENTAS DEL BANCO
		CuentaBancaria[] arraydecuentas = banco.getCuentas();
		// INDICO SALDO DE TODAS LA CUENTAS DEL BANCO
		System.out.println("Saldo de la cuentas en el momento inicial: ");
		for (int i = 0; i < banco.getNumCuentas(); i++) {
			System.out.println("-Cuenta " + arraydecuentas[i].getCodigo() + " con saldo de: "
			        + arraydecuentas[i].getSaldo() + " �");
		}
		// System.out.println(
		// "-La cuenta " + cuenta2.getCodigo() + " con saldo de: " + cuenta2.getSaldo() + " �\n");
		//

		// A�adira/Ingresara 500� en la cuenta de cada usuario o cliente.
		banco.getCuenta("ES8000000000").ingresar(500);
		banco.getCuenta("ES8000000001").ingresar(500);

		System.out.println("Saldo de la cuentas tras el ingreso: ");
		System.out.println("-El saldo de la cuenta " + arraydecuentas[0].getCodigo() + " es: "
		        + arraydecuentas[0].getSaldo() + " €");
		System.out.println("-El saldo de la cuenta " + arraydecuentas[1].getCodigo() + " es: "
		        + arraydecuentas[1].getSaldo() + " €\n");

		// Mostrara la informacion del banco con cada cuenta y usuario o cliente de las cuentas.
		System.out.println("El banco tiene " + banco.getNumCuentas() + " cuentas:");

		for (int i = 0; i < banco.getNumCuentas(); i++) {
			System.out.println(arraydecuentas[i].getCodigo());
			// System.out.println(banco.getCuentas());
			// System.out.println(banco.getCuenta("101"));
			// System.out.println(banco.getCuenta("102"));
		}

		// Tranferira de una cuenta a otra 500�, quedando la primera con saldo 0.
		arraydecuentas[0].transferir(500, arraydecuentas[1]);

		System.out.println("\nSaldo final de cada cuenta tras el traspaso de una a otra: ");
		for (int i = 0; i < banco.getNumCuentas(); i++) {
			System.out.println("-Cuenta " + arraydecuentas[i].getCodigo() + " con saldo de: "
			        + arraydecuentas[i].getSaldo() + " �");
		}
		// System.out
		// .println("-La cuenta " + cuenta1.getCodigo() + " con saldo de: " + cuenta1.getSaldo() + " �");
		// System.out.println(
		// "-La cuenta " + cuenta2.getCodigo() + " con saldo de: " + cuenta2.getSaldo() + " �\n");

		// Cerrara/Borrara la cuenta la cual a tranferido el dinero.
		// banco.cerrarCuenta(arraydecuentas[0].getCodigo());
		banco.cerrarCuenta(banco.getCuenta("ES8000000000").getCodigo());
		// Mostrara la informacion de la cuenta que queda con el resultado del ingreso.
		// RELEEMOS EL ARRAYDECEUNTAS POR QUE YA HA CAMBIADO:
		arraydecuentas = banco.getCuentas();

		// VERSION SIN toSTRING: SI SE USA ESTA, BORRAR EL METODO TOSTRING DE CUENTABANCARIA
		System.out.println("El banco tiene " + banco.getNumCuentas() + " cuentas: ");
		for (int i = 0; i < banco.getNumCuentas(); i++) {
			System.out
			        .println(arraydecuentas[i].getCodigo() + "," + arraydecuentas[i].getCliente().getNombre()
			                + "," + arraydecuentas[i].getSaldo());
		}

		// VERSION CON toSTRING: SI SE USA ESTA, PONER COMENTARIOS CORRECTOS EN EL METODO TOSTRING DE CUENTABANCARIA
		System.out.println("El banco tiene " + banco.getNumCuentas() + " cuentas: ");
		for (int i = 0; i < banco.getNumCuentas(); i++) {
			System.out.println(arraydecuentas[i]);
		}

		// Terminara el programa.
	}

}