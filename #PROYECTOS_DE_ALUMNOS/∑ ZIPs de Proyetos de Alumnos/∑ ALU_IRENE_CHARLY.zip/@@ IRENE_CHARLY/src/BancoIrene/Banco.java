
public class Banco {

	// ATRIBUTOS

	private int				maxCuentas;		// numero m�ximo de cuentas que podr� contener el banco.
	public String			codigoBanco;	// c�digo que se usa para identificar al banco y forma parte del n�mero de cuenta.
	private CuentaBancaria	cuentas[];
	private int				numCuentas;

	// CONSTRUCTOR
	public Banco(int maxCuentas, String codigoBanco) {
		this.maxCuentas = maxCuentas;
		this.codigoBanco = codigoBanco;
		numCuentas = 0;
		cuentas = new CuentaBancaria[maxCuentas];
	}

	// METODOS

	/**
	 * public CuentaBancaria getCuenta(java.lang.String codigo)
	 * Busca en el banco y devuelve, si se encuentra, la cuenta bancaria cuyo c�digo
	 * coincide con el que se pasa como par�metro.
	 * 
	 * @param codigo
	 *            - C�digo de la cuenta buscada.
	 * @return Devuelve la cuenta bancaria buscada si se encuentra en el banco y null en caso contrario.
	 */
	public CuentaBancaria getCuenta(String codigo) {
		CuentaBancaria res = null;
		for (int i = 0; i < numCuentas; i++) {
			if (codigo.equals(cuentas[i].getCodigo())) {
				res = cuentas[i];
			}
		}
		return res;
	}

	/**
	 * public CuentaBancaria abrirCuenta(Cliente cliente)
	 * Abre una cuenta bancaria.
	 * El c�digo de la cuenta lo crea el banco en esta operaci�n a partir del c�digo de la �ltima
	 * cuenta creada incrementando en una unidad el n�mero de la cuenta (NNNNNNNNNN).
	 * El formato del c�digo de cuenta es: EEEENNNNNNNNNN, donde EEEE son 4 d�gitos que representan
	 * la entidad bancaria (por ejemplo ES80) y NNNNNNNNNN son los n�meros de la cuenta.
	 * 
	 * @param cliente
	 *            - Datos del cliente que va a crear la cuenta.
	 * @return La nueva cuenta o null si no se ha podido abrir porque no se pueden crear m�s cuentas.
	 *         Tambi�n devuelve null si el par�metro cliente es null
	 */

	public CuentaBancaria abrirCuenta(Cliente cliente) {
		CuentaBancaria cuenta = null;
		if (cliente == null) { return cuenta; }
		if (numCuentas < cuentas.length) {
			String nuevonumerocuenta = String.format("%08d", numCuentas);
			cuentas[numCuentas] = new CuentaBancaria(codigoBanco + nuevonumerocuenta, cliente);
			cuenta = cuentas[numCuentas];
			numCuentas++;
		}
		// return cuenta;
		return null;
	}

	/**
	 * public int getNumCuentas()
	 * Devuelve el n�mero de cuentas abiertas en ese momento en el banco.
	 * 
	 * @return N�mero de cuentas abiertas en el banco.
	 */
	public int getNumCuentas() {
		return numCuentas;
	}

	/**
	 * public CuentaBancaria cerrarCuenta(java.lang.String codigo)
	 * Busca en el banco y elimina, si se encuentra, la cuenta bancaria cuyo c�digo coincide con el que se pasa como par�metro.
	 * Cuando se borra una cuenta ese c�digo ya no se le asignara a ninguna.
	 * 
	 * @param codigo
	 *            - C�digo de la cuenta que se pretende eliminar.
	 * @return Devuelve la cuenta bancaria eliminada si se encuentra en el banco y null en caso contrario.
	 */
	public CuentaBancaria cerrarCuenta(String codigo) {
		CuentaBancaria eliminada = null;
		for (int i = 0; i < numCuentas; i++) {
			String codigodecadacuenta = cuentas[i].getCodigo();
			if (codigo.equals(codigodecadacuenta)) {
				// Esta es la cuenta eliminada si se encuentra
				eliminada = cuentas[i];
				// Reordenar el array para que se muevan uno hacia la izquierda a partir de la eliminada
				for (int z = i; z < numCuentas - 1; z++) {
					cuentas[i] = cuentas[i + 1];
				}
				cuentas[numCuentas - 1] = null;
				numCuentas--;
			}
		}
		return eliminada;

		/*
		 * En vez de mover los elemento una posicion, pasar el ultimo al primero y borrar este ultimo
		 * arry[contador] borrado
		 * contador
		 */
	}

	/**
	 * public CuentaBancaria[] getCuentas()
	 * Devuelve un array con una copia de todas la cuentas bancarias abiertas en el banco hasta el momento.
	 * 
	 * @return Devuelve un array con una copia de todas la cuentas bancarias abiertas en el banco hasta el momento.
	 */
	public CuentaBancaria[] getCuentas() {
		CuentaBancaria cuentasAbiertas[] = new CuentaBancaria[numCuentas];
		for (int i = 0; i < numCuentas; i++) {
			cuentasAbiertas[i] = cuentas[i];
		}
		return cuentasAbiertas;
	}

}
