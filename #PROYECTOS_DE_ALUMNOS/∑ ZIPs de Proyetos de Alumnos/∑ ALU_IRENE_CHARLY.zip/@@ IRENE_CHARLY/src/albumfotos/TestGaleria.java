package albumfotos;

import java.text.SimpleDateFormat;
import java.util.Date;

public class TestGaleria {

	public static void main (String[] args) {

		GaleriaF2 gal = new GaleriaF2 ();
		String a1 = "Album 1";
		String a2 = "Album 2";

		// crear fotos
		Foto f1 = new Foto ("Descripcion 1", stringToFecha ("21/12/2016"), "T1.gif");
		Foto f2 = new Foto ("Descripcion 2", stringToFecha ("22/12/2016"), "T2.gif");
		Foto f3 = new Foto ("Descripcion 3", stringToFecha ("23/12/2016"), "T3.gif");
		Foto f4 = new Foto ("Descripcion 4", stringToFecha ("24/12/2016"), "T4.gif");
		Foto f5 = new Foto ("Descripcion 5", stringToFecha ("25/12/2016"), "T5.gif");
		Foto f6 = new Foto ("Descripcion 6", stringToFecha ("26/12/2016"), "T6.gif");

		// crear albumes
		gal.crearAlbum (a1);
		gal.crearAlbum (a2);

		// añadir fotos a albumes
		gal.getAlbum (a1).addFoto (f1);
		gal.getAlbum (a1).addFoto (f2);
		gal.getAlbum (a1).addFoto (f3);
		gal.getAlbum (a2).addFoto (f4);
		gal.getAlbum (a2).addFoto (f5);
		gal.getAlbum (a2).addFoto (f6);
//
//
//		HashSet<Foto> n = gal.getAllFotos ();
//		for (Foto f : n) {
//			System.out.println (f.getNomFichero ());
//		}


		// escribir info de albumes
		for (Album al : gal.conjunto) {
			System.out.print ("Nombre de album: ");
			System.out.println (al.getNombre ());

			// escribir info de fotos de cada album
			for (Foto fot : al.listaFotos) {
				System.out.print ("  Foto : ");
				System.out.println ("  " + fot.getDescripcion ());
			}
		}







		// Realizar la presentación de las fotos del primer álbum.
		try {
			gal.presentarAlbum (a1, 1000);
		}
		catch (GaleriaException e) {
			e.printStackTrace ();
		}

		// Borrar todas las fotos del primer álbum
		// opcion 1
		System.out.println ("Tamaño del album antes de borrarlo:" + gal.getAlbum (a1).listaFotos.size ());
		for (Foto fot : gal.getAlbum (a1).listaFotos) {
			gal.getAlbum (a1).listaFotos.remove (fot);
		}
		System.out.println ("Tamaño del album tras borrarlo:" + gal.getAlbum (a1).listaFotos.size ());

		// // opcion 2, con iterator
		// Iterator<Foto> iterator = gal.getAlbum(a1).listaFotos.iterator();
		// while (iterator.hasNext()) {
		// iterator.remove();
		// }

		// Borrar el primer álbum.
		gal.delAlbum (a1);

		// Borrar el segundo álbum.
		gal.delAlbum (a2);
		System.out.println ("Numero de albums en la galeria tras borrar 2:" + gal.getAlbumes ().length);

	}

	static public Date stringToFecha (String strFecha) {
		SimpleDateFormat miFormato2 = new SimpleDateFormat ("dd/MM/yyyy");
		Date fecha = null;
		try {
			fecha = miFormato2.parse (strFecha);
		}
		catch (java.text.ParseException e) {
			e.printStackTrace ();
		}
		return fecha;
	}

}
