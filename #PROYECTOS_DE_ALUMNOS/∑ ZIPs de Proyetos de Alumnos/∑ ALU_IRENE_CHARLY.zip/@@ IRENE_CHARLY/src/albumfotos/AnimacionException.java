package albumfotos;

public class AnimacionException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public AnimacionException(String mensaje) {
		super(mensaje);

	}

}
