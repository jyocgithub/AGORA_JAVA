package albumfotos;

import java.util.ArrayList;
import java.util.HashSet;

public class GaleriaF2 implements IGaleria {

	HashSet<Album> conjunto = new HashSet<> ();


	// metodo para unir las fotos de todos los albumes, sin que esten repetidas
	public HashSet<Foto> getAllFotos () {
		// hago un conjunto nuevo que sera la suma de los demas, sin repetir
		HashSet<Foto> resultado = new HashSet<> ();

		// recorro uno a uno los albumes que tengo
		for (Album cadaAlbum : conjunto) {

			// con cada album, recorro sus fotos
			for (Foto cadaFoto : cadaAlbum.listaFotos) {
				// con cada foto, comprueba que no exista ya en el nuevo conjunto antes de añadirla
				if (!resultado.contains (cadaFoto)) {
					resultado.add (cadaFoto);
				}
			}
		}
		return resultado;
	}

	@Override
	public boolean crearAlbum (String album) {
		Album a = new Album (album);
		conjunto.add (a);
		return false;
	}

	@Override
	public Album getAlbum (String album) {
		for (Album a : conjunto) {
			if (a.getNombre ().equals (album)) { return a; }

		}

		return null;
	}

	@Override
	public Album delAlbum (String album) {
		for (Album a : conjunto) {
			if (a.getNombre ().equals (album)) {
				Album d = a;
				conjunto.remove (a);
				return d;
			}

		}

		return null;
	}

	@Override
	public String[] getAlbumes () {
		String[] aa = new String[conjunto.size ()];
		int x = 0;
		for (Album a : conjunto) {
			aa[x] = a.getNombre ();
			x++;
		}

		return aa;
	}

	@Override
	public void presentarAlbum (String album, int retardo) throws GaleriaException {

		AnimacionImagenesCircular a7 = null;

		for (Album al : conjunto) {
			if (al.getNombre ().equals (album)) {

				ArrayList<Foto> arrfotos = al.listaFotos;
				// animacionImagenesCircular necesita una array de Imagen
				// Lo creamos a partir de un array de Foto
				Imagen[] lisimagenes = new Imagen[arrfotos.size ()];

				for (int i = 0; i < lisimagenes.length; i++) {
					Imagen kk = new Imagen (arrfotos.get (i).getNomFichero ());
					lisimagenes[i] = kk;
				}

				try {
					a7 = new AnimacionImagenesCircular ("Animacion Circular", 600, 600, lisimagenes);
				}
				catch (IllegalArgumentException e) {
					e.printStackTrace ();
				}

				catch (AnimacionException e) {
					// capturar la excepción AnimacionException y lanzar en su lugar –sustituyendola- la excepción
					// GaleriaException
					throw new GaleriaException ("Error de tipo Galeria Exception");
				}
			}
		}

		new P5F2 ().player (a7, 500);

	}

}
