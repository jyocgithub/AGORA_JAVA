package albumfotos;

import java.util.ArrayList;

public class Album {

	private String	nombre;
	ArrayList<Foto>	listaFotos	= new ArrayList<>();

	public Album(String nombre) throws IllegalArgumentException {
		if (nombre == null) { throw new IllegalArgumentException(); }
		this.nombre = nombre;
	}

	public String getNombre() {
		return nombre;
	}

	public boolean addFoto(Foto foto) throws IllegalArgumentException {

		if (foto == null) {
			throw new IllegalArgumentException();
		}
		else {
			listaFotos.add(foto);
		}
		return true;
	}

	public Foto delFoto(int posicion) {

		Foto f = listaFotos.get(posicion);
		if (f == null) {
			return null;

		}
		else {
			listaFotos.remove(posicion);
		}
		return f;
	}

	public boolean delFoto(String nf) throws IllegalArgumentException {
		if (nf == null) { throw new IllegalArgumentException(); }

		for (Foto f : listaFotos) {
			if (f.getNomFichero().equals(nf)) {
				listaFotos.remove(f);
				return true;
			}
		}
		return false;
	}

	public Foto getFoto(String nf) {

		for (Foto f : listaFotos) {
			if (f.getNomFichero().equals(nf)) {

			return f; }
		}
		return null;

	}

	public Foto getFoto(int posicion) {
		return listaFotos.get(posicion);
	}

	public int getNumFotos() {
		return listaFotos.size();
	}

	@Override
	public boolean equals(Object o) {
		if (this == o)
		    return true;
		if (o == null)
		    return false;
		if (o instanceof Album) {
			Album a = (Album) o;
			return (this.nombre.equals(a.nombre));
		}
		else {
			return false;
		}
	}

	@Override
	public int hashCode() {
		int resultado = 1;
		final int marca = 31;
		resultado = marca * resultado + ((listaFotos == null) ? 0 : listaFotos.hashCode());
		resultado = marca * resultado + ((nombre == null) ? 0 : nombre.hashCode());
		return resultado;
	}

}
