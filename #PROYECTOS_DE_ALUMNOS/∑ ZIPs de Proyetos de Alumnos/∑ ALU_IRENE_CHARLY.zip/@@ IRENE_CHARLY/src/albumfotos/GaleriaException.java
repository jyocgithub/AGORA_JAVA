package albumfotos;

public class GaleriaException extends Exception {

	private static final long serialVersionUID = 1L;

	public GaleriaException(String message) {
		super(message);
	}
}