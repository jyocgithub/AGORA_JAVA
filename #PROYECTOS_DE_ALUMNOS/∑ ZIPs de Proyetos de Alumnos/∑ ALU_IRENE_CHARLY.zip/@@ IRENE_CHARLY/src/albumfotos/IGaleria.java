package albumfotos;

public interface IGaleria {

	public boolean crearAlbum(String album);

	public Album getAlbum(String album);

	public Album delAlbum(String album);

	public String[] getAlbumes();

	public void presentarAlbum(String album, int retardo) throws GaleriaException;

}
