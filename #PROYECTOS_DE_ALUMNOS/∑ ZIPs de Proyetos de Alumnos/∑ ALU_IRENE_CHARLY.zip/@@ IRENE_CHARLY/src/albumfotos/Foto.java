package albumfotos;

import java.util.Date;

public class Foto {

	private String	nomFichero;
	private Date	fecha;
	private String	descripcion;

	public Foto(String descripcion, Date fecha, String nomFichero) throws IllegalArgumentException {
		if (descripcion == null || fecha == null
		        || nomFichero == null) { throw new IllegalArgumentException(); }
		this.descripcion = descripcion;
		this.fecha = fecha;
		this.nomFichero = nomFichero;

	}

	public String getNomFichero() {
		return nomFichero;
	}

	public Date getFecha() {
		return fecha;
	}

	public String getDescripcion() {
		return descripcion;
	}

	@Override
	public String toString() {

		return "El fichero " + nomFichero + ",con fecha " + fecha + "contiene  " + descripcion;
	}
}