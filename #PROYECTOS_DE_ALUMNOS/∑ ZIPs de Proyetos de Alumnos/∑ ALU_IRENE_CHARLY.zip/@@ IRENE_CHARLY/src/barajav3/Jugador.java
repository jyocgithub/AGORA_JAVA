package barajav3;

/*
 * Esta clase modela el comportamiento de los jugadores.
 * @author Irene Bahon Mora
 * @version 1.0
 */
public class Jugador {

	private int numero = 0;
	private double saldo = 0;
	private int ganadas;

	// CONSTRUCTOR

	/**
	 * JUGADOR
	 * 
	 * public Jugador(int numero, double saldo) Crea un jugador Parameters:numero - nmero de orden que identifica al jugador en la
	 * partida debe de ser nico por jugador saldo - Cantidad de dinero inicial que dispondr el jugador.
	 */
	public Jugador(int numero, double saldo) {

		this.numero = numero;
		this.saldo = saldo;
		this.ganadas = 0;
	}

	// METODOS

	/**
	 * GETGANADAS
	 * 
	 * public int getGanadas() Devuelve el numero de rondas ganadas por el jugador. Returns:entero con el numero de manos ganadas.
	 */
	public int getGanadas() {

		return ganadas;
	}

	/**
	 * GETNUMERO
	 * 
	 * public int getNumero() Devuelve el nmero de orden del jugador en la partida Returns:El nmero del jugador en la partida.
	 */
	public int getNumero() {
		return numero;
	}

	/**
	 * GETSALDO
	 * 
	 * public double getSaldo() Devuelve el dinero que dispone el jugador en ese instante. Returns:double con la cantidad de dinero
	 * del cliente en la partida.
	 */
	public double getSaldo() {
		return saldo;
	}

	/**
	 * INCREMENTAGANADAS
	 * 
	 * public void incrementaGanadas() Incrementa en una unidad el numero de rondas ganadas por el jugador
	 */
	public void incrementaGanadas() {
		ganadas++;
	}

	/**
	 * SETSALDO
	 * 
	 * public double setSaldo(double cantidad) Modifica el saldo de un jugador sumando la cantidad que se le pasa como parmetro.
	 * Parameters:cantidad. - Valor que se sumar al saldo del jugador podr ser positiva o negativa. Returns:valor double con el
	 * saldo actual del jugador
	 */
	public double setSaldo(double cantidad) {
		double saldoActual = cantidad + saldo;
		saldo = saldoActual;
		return saldoActual;
	}

	/**
	 * TOSTRING
	 * 
	 * public String toString() Redefine el mtodo toString para obtener los datos de un jugador y poderlos sacar en un terminal
	 * Overrides:toString in class java.lang.Object Returns:String con los datos del jugador
	 */
	@Override
	public String toString() {

		return "Jugador numero " + numero + ", con saldo: " + saldo + " y " + ganadas + " partidas ganadas:";
	}
}
