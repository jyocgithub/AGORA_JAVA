package animacion2;

import java.awt.Color;

public class EfectoLibre implements Efecto {

	public EfectoLibre() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public Imagen transformar(Imagen pImagen) {
		int mediaPixel, colorSRGB;
		Color colorAux;

		int an = pImagen.getAncho();
		int al = pImagen.getAlto();

		// INVIERTE COLORES DE LA IMAGEN
		for (int x = 0; x < pImagen.getAncho(); x++) {
			for (int y = 0; y < pImagen.getAlto(); y++) {
				Color col = pImagen.getColor(x, y);
				col = new Color(255 - col.getRed(),
				        255 - col.getGreen(),
				        255 - col.getBlue());
				pImagen.setColor(x, y, col);
			}
		}
		return pImagen;

	}

}
