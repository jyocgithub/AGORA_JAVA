package animacion2;

public abstract class Animacion {

	protected Escenario	p;
	private String		nombre;
	private int			ancho;
	private int			alto;
	boolean				acabado	= false;

	public abstract void ejecutarPaso();

	public abstract boolean estaFinalizada();

	public Animacion(String nombre, int ancho, int alto) {
		this.nombre = nombre;
		this.ancho = ancho;
		this.alto = alto;
		p = new Escenario(nombre, alto, ancho);

	}

	public int getAncho() {
		return ancho;
	}

	public int getAlto() {
		return alto;
	}

	public String getNombre() {
		return nombre;
	}

}