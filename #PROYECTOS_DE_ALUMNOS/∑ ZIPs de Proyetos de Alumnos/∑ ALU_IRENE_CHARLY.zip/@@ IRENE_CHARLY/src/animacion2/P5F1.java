package animacion2;

import java.util.Scanner;

public class P5F1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		// Recoger parametro y analizar que animacion es.
		// Ejecutar la animacion.

		int numImagenes = 5;
		Scanner scanner = new Scanner(System.in);
		System.out.println("Numero de la imagen? Entre 1 y " + numImagenes);
		int numAnimacion = scanner.nextInt();
		Imagen[] imagenes = new Imagen[6];
		imagenes[0] = new Imagen("T1.gif");
		imagenes[1] = new Imagen("T2.gif");
		imagenes[2] = new Imagen("T3.gif");
		imagenes[3] = new Imagen("T4.gif");
		imagenes[4] = new Imagen("T5.gif");
		imagenes[5] = new Imagen("T6.gif");
		Imagen imagen = new Imagen("T1.gif");

		switch (numAnimacion) {
			case 1:

				AnimacionImagen a = new AnimacionImagen("Una Animacion fija", 300, 300, imagen);
				player(a, 1000);
				break;
			case 2:
				AnimacionImagenes a2 = new AnimacionImagenes("otro", 500, 500, imagenes);
				player(a2, 1000);
				break;
			case 3:

				AnimacionImagenesCircular a3 = new AnimacionImagenesCircular("otro", 500, 500, imagenes);
				player(a3, 500);
				break;
			case 4:

				AnimacionMovimiento a4 = new AnimacionMovimiento("Una Animacion fija", 600, 600, imagen, 10,
				        10, 25, 25);
				player(a4, 200);
				break;
			default:
				break;
		}
	}

	public static void player(Animacion a, int retardo) {

		while (!a.estaFinalizada()) {
			a.ejecutarPaso();
			try {
				Thread.sleep(retardo);
			}
			catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}

}
