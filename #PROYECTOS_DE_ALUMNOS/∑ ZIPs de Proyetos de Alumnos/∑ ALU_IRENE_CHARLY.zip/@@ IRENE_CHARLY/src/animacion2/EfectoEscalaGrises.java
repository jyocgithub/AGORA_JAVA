package animacion2;

import java.awt.Color;

public class EfectoEscalaGrises implements Efecto {

	public EfectoEscalaGrises() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public Imagen transformar(Imagen entrada) {

		int mediaPixel, colorSRGB;
		Color colorAux;

		for (int i = 0; i < entrada.getAncho(); i++) {
			for (int j = 0; j < entrada.getAlto(); j++) {

				colorAux = entrada.getColor(i, j);
				mediaPixel = (colorAux.getRed() + colorAux.getGreen() + colorAux.getBlue()) / 3;
				colorAux = new Color(mediaPixel, mediaPixel, mediaPixel);
				entrada.setColor(i, j, colorAux);

			}
		}

		return entrada;
	}

}
