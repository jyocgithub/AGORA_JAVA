package animacion2;

public class AnimacionImagenesCircular extends AnimacionImagenes {

	int laquetoca = 0;

	public AnimacionImagenesCircular(String nombre, int ancho, int alto, Imagen[] imagenes) {
		super(nombre, ancho, alto, imagenes);
	}

	@Override
	public void ejecutarPaso() {

		p.dibujarImagen(10, 10, imagenes[laquetoca]);
		if (++laquetoca == imagenes.length - 1) {
			laquetoca = 0;
		}
	}

	@Override
	public boolean estaFinalizada() {
		return false;
	}
}
