package animacion2;

public class AnimacionImagenConEfecto extends Animacion {

	private Imagen			imagen;
	private EfectoSecuencia	efecto;

	public AnimacionImagenConEfecto(String nombre, int ancho, int alto, Imagen imagen,
	        EfectoSecuencia efecto) {
		super(nombre, ancho, alto);
		this.imagen = imagen;
		this.efecto = efecto;

	}

	@Override
	public void ejecutarPaso() {

		try {
			Thread.sleep(1000);
			p.dibujarImagen(10, 10, efecto.primero.transformar(imagen));
			Thread.sleep(1000);
			p.dibujarImagen(10, 10, efecto.segundo.transformar(imagen));
		}
		catch (InterruptedException e) {
			e.printStackTrace();
		}
		acabado = true;

	}

	@Override
	public boolean estaFinalizada() {

		return acabado;
	}

}
