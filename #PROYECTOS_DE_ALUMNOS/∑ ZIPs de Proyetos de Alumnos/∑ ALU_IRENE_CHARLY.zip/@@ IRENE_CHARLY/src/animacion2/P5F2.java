package animacion2;

import java.util.Scanner;

public class P5F2 {

	public static void main(String[] args) {

		int numImagenes = 5;
		Imagen[] imagenes = new Imagen[6];

		Scanner scanner = new Scanner(System.in);
		int numAnimacion = 0;
		do {
			System.out.println("EJERCICIO ANIMACION");
			System.out.println("QUE ANIMACION DESE EJECUTAR ?? (Valores entre 1 y " + numImagenes + ")");
			System.out.println("(Diga 0 para acabar)");
			numAnimacion = scanner.nextInt();

			for (int i = 1; i <= numImagenes; i++) {
				String cad = "T" + i + ".gif";
				imagenes[i - 1] = new Imagen(cad);
			}

			Animacion a = null;
			if (numAnimacion != 0) {
				switch (numAnimacion) {
					case 1:
						a = new AnimacionImagen("Una Animacion fija", 600, 600, imagenes[0]);
						// player(a, 1000);
						break;
					case 2:
						a = new AnimacionImagenes("otro", 600, 600, imagenes);
						// player(a2, 1000);
						break;
					case 3:
						a = new AnimacionImagenesCircular("otro", 600, 600, imagenes);
						// player(a3, 500);
						break;
					case 4:
						a = new AnimacionMovimiento("Una Animacion fija", 600, 600, imagenes[0],
						        10,
						        10, 25, 25);
						// player(a4, 200);
						break;

					case 5:

						EfectoSecuencia efSec = new EfectoSecuencia(new EfectoEscalaGrises(),
						        new EfectoLibre());
						a = new AnimacionImagenConEfecto("AnimacionEfecto", 600, 600,
						        imagenes[0], efSec);
						break;

					default:
						break;
				}

				player(a, 200);
			}

		} while (numAnimacion != 0);

	}

	public static void player(Animacion a, int retardo) {
		try {
			while (!a.estaFinalizada()) {
				a.ejecutarPaso();
				Thread.sleep(retardo);
			}
		}
		catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

}
