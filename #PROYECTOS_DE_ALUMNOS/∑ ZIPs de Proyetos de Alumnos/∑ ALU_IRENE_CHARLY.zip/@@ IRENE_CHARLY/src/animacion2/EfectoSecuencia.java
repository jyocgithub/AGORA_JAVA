package animacion2;

public class EfectoSecuencia implements Efecto {

	public Efecto	primero;
	public Efecto	segundo;

	public EfectoSecuencia(Efecto primero, Efecto segundo) {
		this.primero = primero;
		this.segundo = segundo;
	}

	@Override
	public Imagen transformar(Imagen entrada) {
		return entrada;
	}

}
