package animacion;

public class AnimacionImagenes extends Animacion {

	protected Imagen[]	imagenes;
	int					laquetoca	= 0;

	public AnimacionImagenes(String nombre, int ancho, int alto, Imagen[] imagenes) {
		super(nombre, ancho, alto);
		// TODO Auto-generated constructor stub
		this.imagenes = imagenes;
	}

	public void setPosicion(int posicion) {
		int numero;

	}

	public int getCuantas() {
		return imagenes.length;
	}

	@Override
	public void ejecutarPaso() {
		// TODO Auto-generated method stub
		p.dibujarImagen(210, 210, imagenes[laquetoca]);
		laquetoca++;
		if (laquetoca == imagenes.length) {
			acabado = true;
		}
	}

	@Override
	public boolean estaFinalizada() {
		return acabado;
	}

}