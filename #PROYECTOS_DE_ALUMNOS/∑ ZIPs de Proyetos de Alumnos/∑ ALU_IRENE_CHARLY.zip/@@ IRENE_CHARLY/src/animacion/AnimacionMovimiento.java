package animacion;

public class AnimacionMovimiento extends Animacion {

	private int		x;
	private int		y;
	private int		vx;
	private int		vy;
	private Imagen	imagen;
	int				laquetoca	= 0;

	public AnimacionMovimiento(String nombre, int ancho, int alto, Imagen imagen, int x, int y, int vx,
	        int vy) {
		super(nombre, ancho, alto);
		// TODO Auto-generated constructor stub
		this.imagen = imagen;
		this.x = x;
		this.y = y;
		this.vx = vx;
		this.vy = vy;
	}

	int direccion = 0;

	@Override
	public void ejecutarPaso() {
		// TODO Auto-generated method stub
		p.dibujarImagen(x, y, imagen);
		switch (direccion) {
			case 0:
				x = x + vx;
				y = y + vy;
				break;
			case 1:
				x = x - vx;
				y = y - vy;
				break;

			default:
				break;
		}

		laquetoca++;
		if (laquetoca == 10) {

			direccion = 1;
		}

	}

	@Override
	public boolean estaFinalizada() {
		// TODO Auto-generated method stub
		return acabado;
	}

}
