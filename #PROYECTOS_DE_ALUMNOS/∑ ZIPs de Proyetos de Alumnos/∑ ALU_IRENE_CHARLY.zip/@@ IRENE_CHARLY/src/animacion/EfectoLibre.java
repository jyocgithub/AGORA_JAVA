package animacion;

import java.awt.Color;

public class EfectoLibre implements Efecto {

	public EfectoLibre() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public Imagen transformar(Imagen pImagen) {
		int mediaPixel, colorSRGB;
		Color colorAux;

		int an = pImagen.getAncho();
		int al = pImagen.getAlto();

		// INVIERTE LA IMAGEN SOBRE EJE X
		Color[][] colores = new Color[an][al];
		for (int x = 0; x < pImagen.getAncho(); x++) {
			for (int y = 0; y < pImagen.getAlto(); y++) {
				Color col = pImagen.getColor(x, y);
				colores[x][y] = col;
			}
		}
		for (int x = 0; x < pImagen.getAncho(); x++) {
			int i = 0;
			for (int y = pImagen.getAlto() - 1; y >= 0; y--) {
				Color col = colores[x][y];
				pImagen.setColor(x, i, col);
				i++;
			}
		}
		return pImagen;

	}

}
