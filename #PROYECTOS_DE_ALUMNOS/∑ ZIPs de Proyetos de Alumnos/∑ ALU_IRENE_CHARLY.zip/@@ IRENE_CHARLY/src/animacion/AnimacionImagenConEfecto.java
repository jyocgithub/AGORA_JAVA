package animacion;

public class AnimacionImagenConEfecto extends Animacion {

	private Imagen			imagen;
	private EfectoSecuencia	efecto;

	public AnimacionImagenConEfecto(String nombre, int ancho, int alto, Imagen imagen,
	        EfectoSecuencia efecto) {
		super(nombre, ancho, alto);
		this.imagen = imagen;
		this.efecto = efecto;

	}

	@Override
	public void ejecutarPaso() {

		try {
			Thread.sleep(1000);
			Imagen mm = efecto.primero.transformar(imagen);
			p.dibujarImagen(100, 100, mm);

			Thread.sleep(1000);

			mm = efecto.segundo.transformar(imagen);
			p.dibujarImagen(100, 100, mm);
		}
		catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		acabado = true;

	}

	@Override
	public boolean estaFinalizada() {

		return acabado;
	}

}
