package animacion;

public class AnimacionImagenesCircular extends AnimacionImagenes {

	public AnimacionImagenesCircular(String nombre, int ancho, int alto, Imagen[] imagenes) {
		super(nombre, ancho, alto, imagenes);
		// TODO Auto-generated constructor stub

	}

	int laquetoca = 0;

	@Override
	public void ejecutarPaso() {
		// TODO Auto-generated method stub
		p.dibujarImagen(10, 10, imagenes[laquetoca]);
		laquetoca++;
		if (laquetoca == imagenes.length) {
			laquetoca = 0;
		}

	}

	@Override
	public boolean estaFinalizada() {
		// TODO Auto-generated method stub
		return false;
	}
}
