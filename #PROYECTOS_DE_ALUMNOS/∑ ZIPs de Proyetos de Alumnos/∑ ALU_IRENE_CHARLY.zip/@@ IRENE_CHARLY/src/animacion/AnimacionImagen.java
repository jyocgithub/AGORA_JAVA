package animacion;

public class AnimacionImagen extends Animacion {

	private Imagen imagen;

	public AnimacionImagen(String nombre, int ancho, int alto, Imagen imagen) {
		super(nombre, alto, ancho);
		this.imagen = imagen;
	}

	@Override
	public void ejecutarPaso() {
		p.dibujarImagen(10, 10, imagen);
		acabado = true;
	}

	@Override
	public boolean estaFinalizada() {
		return acabado;
	}

}