

import java.util.ArrayList;
import java.util.HashSet;

import galeriafotos3.Album;

/**
 * Galeria F2: Clase realizada con conjuntos. 
 * @author Irene.bahon
 * @version 1.0
 */
public class GaleriaF2 implements IGaleria {

	HashSet<Album> conjunto = new HashSet<> ();

	@Override
	public boolean añadirAlbum (Album album) {
		conjunto.add (album);
		return false;
	}

	/**
	 * boolean crearAlbum(String album)
	 * Crea un álbum y lo añade a la colección de base
	 * Parameters:
	 * @param album;el nombre del album
	 * @return true si lo ha creado y añadido y false si no.
	 * @throws java.lang.IllegalArgumentException - si el parámetro album es null
	 */
	@Override
	public boolean crearAlbum (String album) throws IllegalArgumentException {
		if (album == null) throw new IllegalArgumentException ();
		Album a = new Album (album);
		añadirAlbum (a);
		return false;
	}

	/**
	 * Album getAlbum(String album)
	 * Devuelve el citado álbum sin borrarlo de la colección
	 * Parameters:
	 * @param album;nombre del álbum
	 * @return el Album o null si no existe álbum con ese nombre
	 * @throws java.lang.IllegalArgumentException - si el parámetro nombre es null
	 */
	@Override
	public Album getAlbum (String album) throws IllegalArgumentException {
		if (album == null) throw new IllegalArgumentException ();
		for (Album a : conjunto) {
			if (a.getNombre ().equals (album)) { return a; }
		}
		return null;
	}

	/**
	 * Album delAlbum(String album)
	 * Borramos el citado álbum de la colección
	 * Parameters:
	 * @param album;nombre del álbum
	 * @return el álbum borrado o null si no lo ha podido borrar por que no exista
	 * @throws java.lang.IllegalArgumentException - si el parámetro album es null
	 */
	@Override
	public Album delAlbum (String album) throws IllegalArgumentException {
		Album d = null;
		if (album == null) throw new IllegalArgumentException ();
		for (Album alb : conjunto) {
			if (alb.getNombre ().equals (album)) {
				d = alb;
				conjunto.remove (alb);
				return d;
			}
		}
		return d;
	}

	/**
	 * String[] getAlbumes()
	 * Devuelve los nombres de los álbumes o null si no existe ninguno
	 * @return array de nombres
	 */
	@Override
	public String[] getAlbumes () {
		String[] newAlbum = new String[conjunto.size ()];
		int i = 0;
		for (Album a : conjunto) {
			newAlbum[i] = a.getNombre ();
			i++;
		}
		return newAlbum;
	}

	/**
	 * void presentarAlbum(java.lang.String album,int retardo)throws GaleriaException
	 * Visualizar las fotos de un determinado álbum a través de una de las animaciones de la práctica 5,
	 * eligiremos la clase AnimacionImagenesCircular
	 * Parameters:
	 * @param album;nombre del álbum
	 * @param retardo;entre pasos de ejecución
	 * @throws GaleriaException - si no existe el álbum o se produce la excepción AnimacionException
	 * @throws java.lang.IllegalArgumentException - si el album es null o retardo negativo
	 * @throws AnimacionException 
	 */
	@Override
	public void presentarAlbum (String album, int retardo) throws GaleriaException {
		if (album == null || retardo < 0) throw new GaleriaException ("***Error***");
		AnimacionImagenes a7 = null;

		for (Album al : conjunto) {
			if (al.getNombre ().equals (album)) {

				ArrayList<Foto> arrfotos = al.listaFotos;
				// animacionImagenesCircular necesita una array de Imagen
				// Lo creamos a partir de un array de Foto
				Imagen[] lisimagenes = new Imagen[arrfotos.size ()];

				for (int i = 0; i < lisimagenes.length; i++) {
					Foto hh = arrfotos.get (i);
					Imagen kk = new Imagen (hh.getNomFichero ());
					lisimagenes[i] = kk;
				}

				try {
					a7 = new AnimacionImagenes ("Animacion Imagenes", 600, 600, lisimagenes);
				}
				catch (IllegalArgumentException e) {
					e.printStackTrace ();
				}

				catch (AnimacionException e) {
					// capturar la excepcioÌn AnimacionException y lanzar en su lugar â€“sustituyendola- la excepcioÌn
					// GaleriaException
					throw new GaleriaException ("Error de tipo Galeria Exception");
				}
			}
		}

		P5F2.player (a7, 500);

	}

}