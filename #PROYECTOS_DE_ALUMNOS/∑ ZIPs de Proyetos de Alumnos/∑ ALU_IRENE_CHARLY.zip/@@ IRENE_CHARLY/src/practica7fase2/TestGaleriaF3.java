
import java.util.Collection;
import java.util.Date;
import java.util.Iterator;

import galeriafotos3.Album;
/**
 * Programa de prueba con mapas, donde se crea un albun con fotos el cual luego borraremos.
 * @author Irene.bahon
 * @version 1.0
 */
public class TestGaleriaF3 {

	public static void main(String[] args) {

		//ATRIBUTOS
		GaleriaF3 gal = new GaleriaF3();
		String a1 = "Album 1\n";
		String a2 = "Album 2\n";

		// crear albumes
		gal.crearAlbum(a1);
		gal.crearAlbum(a2);

		//crear 6 fotos.
		for (int i = 0; i < 6; i++) {
			Foto fff = new Foto("Descripcion " + (i + 1), new Date(), "T" + (i + 1) + ".gif");
			gal.getAlbum(a1).addFoto(fff);
		}

		for (int i = 3; i < 6; i++) {
			Foto fff = new Foto("Descripcion " + (i + 1), new Date(), "T" + (i + 1) + ".gif");
			gal.getAlbum(a2).addFoto(fff);
		}
		
		// escribir info de albumes
		Collection<Album> losvalores = gal.conjunto.values();

		for (Album al : losvalores) {
			System.out.print("\nNombre de album: ");
			System.out.println(al.getNombre());

			// escribir info de fotos de cada album
			for (Foto fot : al.listaFotos) {
				System.out.print("  Foto : ");
				System.out.println("  " + fot.getDescripcion());
			}
		}

//		 Realizar la presentación de las fotos del primer álbum.
		try {
			gal.presentarAlbum(a1, 1000);
		} catch (GaleriaException e) {
			e.printStackTrace();
		}

		
		// Borrar todas las fotos del primer álbum
		System.out.println("\n\t***ALBUM 1***");
		System.out.println("\nTamaño del album antes de borrarlo:" + gal.getAlbum(a1).listaFotos.size());

		Iterator<Foto> ite = gal.getAlbum(a1).listaFotos.iterator();
		while (ite.hasNext()) {
			System.out.println(ite.next().toString());
			ite.remove();
		}
		System.out.println("\nTamaño del album tras borrarlo:" + gal.getAlbum(a1).listaFotos.size());
 
		// Borrar el primer álbum.
		gal.delAlbum(a1);

		
		// Borrar todas las fotos del segundo album
		System.out.println("\n\t***ALBUM 2***");
		System.out.println("\nTamaño del album antes de borrarlo:" + gal.getAlbum(a2).listaFotos.size());

				Iterator<Foto> ite2 = gal.getAlbum(a2).listaFotos.iterator();
				while (ite2.hasNext()) {
					System.out.println(ite2.next().toString());
					ite2.remove();
				}
				System.out.println("\nTamaño del album tras borrarlo:" + gal.getAlbum(a2).listaFotos.size());

		// Borrar el segundo álbum.
		gal.delAlbum(a2);
		System.out.println("\nNumero de albums en la galeria tras borrar 2:" + gal.getAlbumes().length);

	}

}

