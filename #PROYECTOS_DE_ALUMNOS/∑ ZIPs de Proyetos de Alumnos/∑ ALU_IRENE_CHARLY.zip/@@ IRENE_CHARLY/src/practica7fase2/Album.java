import java.io.Serializable;
import java.util.ArrayList;

/**
 * Representa una secuencia de fotos en la que puede haber fotos repetidas.
 * @author Irene.bahon
 * @version 1.0
 */
public class Album implements Serializable {

	private String	nombre;
	ArrayList<Foto>	listaFotos	= new ArrayList<> ();

	/**
	 * public Album(String nombre)
	 * Crea un lbum
	 * Parameters:
	 * @param nombre;nombre del lbum
	 * @throws java.lang.IllegalArgumentException - si el nombre es null
	 */
	public Album (String nombre) throws IllegalArgumentException {
		if (nombre == null) { throw new IllegalArgumentException (); }
		this.nombre = nombre;
	}

	/**
	 * public String getNombre()
	 * Obtiene el nombre del lbum
	 * @return el nombre
	 */
	public String getNombre () {
		return nombre;
	}

	/**
	 * public boolean addFoto(Foto foto)
	 * Aade una foto al lbum.
	 * Parameters:
	 * @param foto;foto a agregar al lbum
	 * @return true si se aade la foto o false en caso contrario
	 * @throws IllegalArgumentException, si la foto es null
	 */
	public boolean addFoto (Foto foto) throws IllegalArgumentException {

		if (foto == null) {
			throw new IllegalArgumentException ();
		}
		else {
			listaFotos.add (foto);
		}
		return true;
	}

	/**
	 * public Foto delFoto(int posicion)
	 * Borra la foto que ocupa esa posicin en la secuencia
	 * Parameters:
	 * @param posicion;posicion
	 * @return la foto borrada o null si no se ha borrado por que no exista una foto en esa posicin.
	 */
	public Foto delFoto (int posicion) {

		Foto f = listaFotos.get (posicion);
		if (f == null) {
			return null;

		}
		else {
			listaFotos.remove (posicion);
		}
		return f;
	}

	/**
	 * public boolean delFoto(String nomFichero)
	 * Borra la foto que tiene el citado nombre de fichero
	 * Parameters:
	 * @param nf;nombre de fichero
	 * @return true si se ha borrado o false si no existe una foto con ese nombre.
	 * @throws IllegalArgumentException, si la nf es null
	 */
	public boolean delFoto (String nf) throws IllegalArgumentException {
		if (nf == null) { throw new IllegalArgumentException (); }

		for (Foto f : listaFotos) {
			if (f.getNomFichero ().equals (nf)) {
				listaFotos.remove (f);
				return true;
			}
		}
		return false;
	}

	/**
	 * public Foto getFoto(String nomFichero)
	 * Devuelve la foto con ese nombre de fichero sin borrarla del lbum
	 * Parameters:
	 * @param nomFichero;nombre de fichero
	 * @return la foto con ese nombre de fichero, o null en caso de que no exista o el parmetro nomFichero sea null
	 */
	public Foto getFoto (String nf) {

		for (Foto f : listaFotos) {
			if (f.getNomFichero ().equals (nf)) {

			return f; }
		}
		return null;

	}

	/**
	 * public Foto getFoto(int posicion)
	 * Devuelve la foto que se encuentra en esa posicin de la secuencia sin borrarla del lbum
	 * Parameters:
	 * @param posicion;posicion
	 * @return la foto o null si posicin est fuera de la secuencia.
	 */
	public Foto getFoto (int posicion) {
		return listaFotos.get (posicion);
	}

	/**
	 * public int getNumFotos()
	 * Devuelve el nmero de fotos que contiene el lbum
	 * @return nmero de fotos
	 */
	public int getNumFotos () {
		return listaFotos.size ();
	}

	@Override
	public boolean equals (Object obj) {
		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass () != obj.getClass ()) return false;
		Album other = (Album) obj;
		if (listaFotos == null) {
			if (other.listaFotos != null) return false;
		}
		else if (!listaFotos.equals (other.listaFotos)) return false;
		if (nombre == null) {
			if (other.nombre != null) return false;
		}
		else if (!nombre.equals (other.nombre)) return false;
		return true;
	}


	@Override
	public int hashCode () {
		final int prime = 31;
		int result = 1;
		result = prime * result + ( (listaFotos == null) ? 0 : listaFotos.hashCode ());
		result = prime * result + ( (nombre == null) ? 0 : nombre.hashCode ());
		return result;
	}

}
