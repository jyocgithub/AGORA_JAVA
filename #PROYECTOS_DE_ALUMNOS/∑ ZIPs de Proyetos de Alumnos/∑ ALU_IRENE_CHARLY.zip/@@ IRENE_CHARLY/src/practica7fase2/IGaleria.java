import galeriafotos3.Album;

/**
 * Interface Galeria.
 * 
 * @author Irene.bahon
 * @version 1.0
 */

public interface IGaleria {

	public boolean añadirAlbum (Album album);


	/**
	 * public boolean crearAlbum(String album) Crea un lbum y lo aade a la
	 * coleccin de base
	 * 
	 * @param album
	 * @return true si lo ha creado y aadido y false si no.
	 * @throws java.lang.IllegalArgumentException
	 *             - si el parmetro album es null
	 */
	public boolean crearAlbum (String album);

	/**
	 * public Album getAlbum(String album) Devuelve el citado lbum sin borrarlo
	 * de la coleccin
	 * 
	 * @param album
	 * @return el Album o null si no existe lbum con ese nombre
	 * @throws java.lang.IllegalArgumentException
	 *             - si el parmetro nombre es null
	 */
	public Album getAlbum (String album);

	/**
	 * public Album delAlbum(String album) Borramos el citado lbum de la
	 * coleccin
	 * 
	 * @param album
	 * @return el lbum borrado o null si no lo ha podido borrar por que no
	 *         exista
	 * @throws java.lang.IllegalArgumentException
	 *             - si el parmetro album es null
	 */
	public Album delAlbum (String album);

	/**
	 * public String[] getAlbumes() Devuelve los nombres de los lbumes o null
	 * si no existe ninguno
	 * 
	 * @return array de nombres
	 */
	public String[] getAlbumes ();

	/**
	 * public void presentarAlbum(String album, int retardo) throws
	 * GaleriaException Visualizar las fotos de un determinado lbum a travs de
	 * una de las animaciones de la prctica 5, eligiremos la clase
	 * AnimacionImagenesCircular
	 * 
	 * @param album
	 * @param retardo
	 * @throws GaleriaException
	 *             - si no existe el lbum o se produce la excepcin
	 *             AnimacionException
	 * @throws java.lang.IllegalArgumentException
	 *             - si el album es null o retardo negativo
	 */
	public void presentarAlbum (String album, int retardo) throws GaleriaException;

}