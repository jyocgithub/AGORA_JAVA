/**
 *Clase abstracta de la cual derivan todas las imagenes las cuales tendran que documentar sus propios metodos.
 * @author Irene.bahon
 * @version 1.0
 */
public abstract class Animacion {

	//ATRIBUTOS
	protected Escenario p;
	private String nombre;
	private int ancho;
	private int alto;
	boolean acabado = false;
	
	//Constructor
		/**
		 * public Animacion(String nombre, int ancho, in alto)
		 * Crea una animaci�n con el nombre proporcionado que se mostrar� en un Escenario de tama�o ancho x alto.
		 * Parameters:
		 * @param nombre;el nombre de la animacion
		 * @param ancho;el ancho del escenario donde mostrarla (en pixels)
		 * @param alto;el alto del escenario donde mostrarla (en pixels)
		 */
	
	public Animacion (String nombre,int ancho,int alto) throws IllegalArgumentException{
		
		if(nombre==null || ancho <= 0 || alto <=0){
			throw new IllegalArgumentException("***ERROR***");
			}
		
			this.nombre=nombre;
			this.ancho=ancho;
			this.alto=alto;
			p=new Escenario(nombre,alto,ancho);
		
	}
	
	//Metodos
		/**
		 * public int getAncho()
		 * Devuelve el ancho del escenario
		 * @return
		 * El ancho del escenario
		 */
	public int getAncho(){
		return ancho;
	}
	
	/**
	 * public int getAlto()
	 * Devuelve el alto del escenario
	 * @return
	 * El alto del escenario
	 */
	public int getAlto(){
		return alto;
	}
	
	/**
	 * public java.lang.String getNombre()
	 * @return
	 * El nombre de la animacion
	 */
	
	public String getNombre(){
		return nombre;
	}
	
	/**
	 * public abstract void ejecutarPaso()
	 * Ejecuta un paso de la animaci�n y prepara todo para ejecutar el siguiente paso.
	 * Se llamar� en un bucle hasta que finalice la animaci�n, de forma que se vaya ejecutando paso a paso.
	 */
	
	public abstract void ejecutarPaso();
	
	/**
	 * public abstract boolean estaFinalizada()
	 * Devuevle si la animaci�n ha finalizado o no.
	 * @return
	 * True si la animaci�n ha finalizado
	 */
	
	public abstract boolean estaFinalizada();
		
}