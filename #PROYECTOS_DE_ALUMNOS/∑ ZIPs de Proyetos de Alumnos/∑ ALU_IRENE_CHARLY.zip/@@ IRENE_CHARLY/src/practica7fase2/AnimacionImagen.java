
import practica5animacionEntregaFinal.Animacion;

/**
 * Muestra una imagen a elegir.
 * @author Irene.bahon
 * @version 1.0
 */
public class AnimacionImagen extends Animacion{

	//ATRIBUTOS
	protected Imagen imagen;
	
	//Constructor
		/**
		 * public AnimacionImagen(String nombre, int ancho, int alto, String imagen)
		 * Crea una animacin con el nombre proporcionado que se mostrar en un Escenario de tamao ancho x alto.
		 * La animacin mostrar la imagen cuyo nombre de fichero se pasa como parmetro y terminar.
		 * Parameters:
		 * @param nombre;el nombre de la animacion
		 * @param ancho;el ancho del escenario donde mostrarla (en pixels)
		 * @param alto;el alto del escenario donde mostrarla (en pixels)
		 * @param imagen;el nombre del fichero con la imagen a mostrar
		 */
	
	public AnimacionImagen(String nombre,int ancho,int alto,Imagen imagen)throws IllegalArgumentException{
		super(nombre,alto,ancho);
		
		if(imagen == null){
			throw new IllegalArgumentException();
		}
		this.imagen=imagen;
	}

	
	//Metodos
		/**
		 * public void ejecutarPaso()
		 * Description copied from class:
		 * Animacion
		 * Ejecuta un paso de la animacin y prepara todo para ejecutar el siguiente paso.
		 * Se llamar en un bucle hasta que finalice la animacin, de forma que se vaya ejecutando paso a paso.
		 * Specified by:
		 * ejecutarPaso in class Animacion
		 */
	
	public void ejecutarPaso() throws IllegalStateException{
		
		if(acabado){
			throw new IllegalStateException();
		}
		p.dibujarImagen(240, 240, imagen);
		acabado = true;
	}

	/**
	 * public boolean estaFinalizada()
	 * Description copied from class:
	 * Animacion
	 * Devuevle si la animacin ha finalizado o no.
	 * Specified by:
	 * estaFinalizada in class AnimacionReturns:true si la animacin ha finalizado
	 */
	public boolean estaFinalizada() {
		return acabado;
	}
	
}