package masa;

import java.util.Scanner;

public class Masa1 {

	public static void main(String[] args) {

		String parametro = args[0];
		int numPersonas = Integer.parseInt(parametro);
		String arrayDePersonas[] = new String[numPersonas];
		String personas;
		double peso;
		double altura;
		String texto;
		double IMC;
		String categoria;
		double media;
		int numeroPersonas = 0;
		String cadena;

		if (numPersonas < 0) {

			System.out.println("ARRANQUE ERRONEO. Debe pasar como argumento un numero de personas");
		}

		else {

			do {

				System.out.println("Escriba nombre del sujeto: ");
				personas = leerString();

				System.out.println("Escriba peso del sujeto: ");
				peso = leerDouble();

				if (peso < 25 || peso > 160) {

					System.out.println("***ERROR***: El peso no puede ser menor de 25 kg ni mayor que 160kg.");

				}

				else {

					System.out.println("Escriba altura del sujeto: ");
					altura = leerDouble();

					if (altura < 0.5 || altura > 2.5) {

						System.out.println("Altura inválida. La altura no puede ser menor de 0.5m ni mayor que 2.5m.");

					}

					else {

						IMC = peso / (altura * altura);
						categoria = obtenerCategoria(IMC);

						cadena = personas + ":" + peso + ":" + altura + ":" + IMC + ":" + categoria;

						arrayDePersonas[numeroPersonas] = cadena;
						numeroPersonas++;
					}

				}

				if (numeroPersonas == Integer.parseInt(args[0])) {
					break;
				}

				System.out.println(
						"Teclee S para salir de obtener valores, o cualquier tecla para continuar con mas personas: ");
				texto = leerString();

			} while (!texto.equals("S") && !texto.equals("s"));

			// MENU **************************************************************
			do {

				System.out.println("\nMENU PRINCIPAL");
				System.out.println("--------------");
				System.out.println("  A: Todas las personas. ");
				System.out.println("  B: Todas las personas de determinada categoria. ");
				System.out.println("  C: Todas las personas con IMC superior a la media. ");
				System.out.println("  S: Finalizar. ");

				System.out.println("Teclee A,B,C para hacer un calculo o S para salir: ");
				texto = leerString();

				switch (texto) {

				case "A":

					EscribirPersona(arrayDePersonas, numeroPersonas);

					break;

				case "B":
					System.out.println("Escriba una categoria a buscar: ");
					categoria = leerString();

					personasDeUnaCategoria(arrayDePersonas, numeroPersonas, categoria);

					break;

				case "C":

					media = calcularMedia(arrayDePersonas, numeroPersonas);
					System.out.println("La media es " + media);
					calcularMedia(arrayDePersonas, numeroPersonas, media);

					break;

				default:
				}
			}

			while (!texto.equals("S"));

		}

	}

	private static String obtenerCategoria(double IMC) {

		String resultado = "";

		if (IMC < 18) {

			resultado = "Bajo";

		}

		if (IMC >= 18 && IMC < 25) {

			resultado = "Normal";
		}

		if (IMC >= 25 && IMC < 30) {

			resultado = "Sobrepeso";
		}

		if (IMC >= 30) {

			resultado = "Obesidad";
		}

		return resultado;
	}

	private static void EscribirPersona(String[] persona, int contador) {

		for (int i = 0; i < contador; i++) {

			if (!persona[i].equals("")) {

				String[] m = persona[i].split(":");
				System.out.println("Nombre: " + m[0] + " IMC: " + m[3] + " Categoria: " + m[4] + " Peso: " + m[1]
						+ " Altura: " + m[2]);

			}

		}
	}

	private static double calcularMedia(String[] personas, int numper) {

		double suma = 0;

		for (int i = 0; i < numper; i++) {

			String[] m = personas[i].split(":");

			suma = suma + Double.parseDouble(m[3]);
		}

		double media = suma / numper;

		return media;
	}

	private static void personasDeUnaCategoria(String[] personas, int numper, String parametroCategoria) {

		System.out.println("PERSONAS QUE TIENEN LA CATEGORIA " + parametroCategoria);

		int personasEncontradas = 0;

		for (int i = 0; i < numper; i++) {
			String[] m = personas[i].split(":");
			String catABuscar = m[4];
			if (catABuscar.equals(parametroCategoria)) {
				personasEncontradas++;
				System.out.println("Nombre: " + m[0] + " IMC: " + m[3] + " Categoria: " + m[4] + " Peso: " + m[1]
						+ " Altura: " + m[2]);
			}
		}
		if (personasEncontradas == 0) {
			System.out.println("Categoría inválida, no existe.");
		}

	}

	private static void calcularMedia(String[] personas, int numper, double mediaCalculada) {

		int personasEncontradas = 0;

		for (int i = 0; i < numper; i++) {
			String[] m = personas[i].split(":");
			if (Double.parseDouble(m[3]) >= mediaCalculada) {
				personasEncontradas++;
				System.out.println("Nombre: " + m[0] + " IMC: " + m[3] + " Categoria: " + m[4] + " Peso: " + m[1]
						+ " Altura: " + m[2]);
			}
		}
		if (personasEncontradas == 0) {
			System.out.println("Solicitud inválida. No hay personas con IMC mayor o igual a media.");
		}
	}

	public static double leerDouble() {
		double res = 0;
		Scanner sc = new Scanner(System.in);
		res = sc.nextDouble();
		return res;
	}

	public static String leerString() {
		String res = "";
		Scanner scannerPru = new Scanner(System.in);
		res = scannerPru.nextLine();
		return res;
	}
}
