package cc.controlAlmacen;

import es.upm.babel.cclib.Monitor;

import java.util.*;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.CopyOnWriteArrayList;


public class ControlAlmacenMonitor implements ControlAlmacen {

  private Monitor mutex;
  private  Monitor.Cond condEntregar2;

  private  Monitor.Cond condOfRe;

  private CopyOnWriteArrayList<ClienteEnEspera> clientesEnEsperaCondEntregar;



  private static class ClienteEnEspera {
    private final String clientId;
    private final long TiempoEspera;

    public ClienteEnEspera(String clientId, long TiempoEspera) {
      this.clientId = clientId;
      this.TiempoEspera = TiempoEspera;
    }



    public String getClientId() {
      return clientId;
    }

    public long getTiempoEspera() {
      return TiempoEspera;
    }


  }
  private static class Producto {
    //Los datos que contiene cada uno de los producto y sobre los que se trabaja
    private int disponibles;
    private int enCamino;
    private int comprados;
    private int minDisponibles;



    //Sobrescribe el numero de productos disponibles
    public void setDisponibles(int disponibles) {
      this.disponibles = disponibles;
    }

    public void setEnCamino(int enCamino) {
      this.enCamino = enCamino;
    }

    public void setComprados(int comprados) {
      this.comprados = comprados;
    }


    public void setMinDisponibles(int minDisponibles) {
      this.minDisponibles = minDisponibles;
    }
    //Devuelve el numero de productos que estan disponibles
    public int getDisponibles() {
      return this.disponibles;
    }

    public int getEnCamino() {
      return this.enCamino;
    }

    public int getComprados() {
      return this.comprados;
    }

    public int getMinDisponibles() {
      return this.minDisponibles;
    }

    //Inicializa todos los datos del producto
    public Producto(int minDisponibles) {
      this.disponibles = 0;
      this.enCamino = 0;
      this.comprados = 0;
      this.minDisponibles = minDisponibles;
    }

  }

  private Map<String, Integer> productos;
  private Map<String, Producto> almacen;
  // Resource state
  // ...

  // Monitors and conditions
  // ...

  public ControlAlmacenMonitor(Map<String, Integer> tipoProductos) {
    this.productos = tipoProductos;
    this.almacen = new HashMap<>();
    this.mutex = new Monitor();
    condEntregar2 = mutex.newCond();

    condOfRe = mutex.newCond();
    clientesEnEsperaCondEntregar = new CopyOnWriteArrayList<ClienteEnEspera>();
    Iterator<Map.Entry<String, Integer>> var2 = tipoProductos.entrySet().iterator();
    //Introduce los datos mediante iteradores
    while(var2.hasNext()) {
      Map.Entry<String, Integer> entry = var2.next();
      String itemId = entry.getKey();
      int minDisponible = entry.getValue();
      Producto producto = new Producto(minDisponible);
      this.almacen.put(itemId, producto);
    }

  }

  public boolean comprar(String clientId, String itemId, int cantidad) {
    mutex.enter();
    try {
      if (cantidad <= 0 || !this.productos.containsKey(itemId)) {
        throw new IllegalArgumentException("Producto no encontrado");
      }

      Producto producto = this.almacen.get(itemId);
      int comprados = producto.getComprados();
      int disponibles = producto.getDisponibles();
      int enCamino = producto.getEnCamino();
      boolean result = disponibles + enCamino >= cantidad + comprados;

      if (result) {
        producto.setComprados(comprados + cantidad);
        desbloquear(itemId, cantidad);
        return true;
      } else {
        return false;
      }
    }finally {
      mutex.leave();
    }
  }

  public void entregar(String clientId, String itemId, int cantidad) {
    mutex.enter();
    try {
      if (cantidad <= 0 || !this.productos.containsKey(itemId)) {
        throw new IllegalArgumentException("Producto no encontrado");
      }

      Producto producto = this.almacen.get(itemId);
      int disponibles = producto.getDisponibles();
      int enCamino = producto.getEnCamino();

      if (disponibles < cantidad) {
        ClienteEnEspera cliente = new ClienteEnEspera(itemId, System.currentTimeMillis());
        clientesEnEsperaCondEntregar.add(cliente);
        condEntregar2.await();
      }

      producto = this.almacen.get(itemId);
      disponibles = producto.getDisponibles();
      enCamino = producto.getEnCamino();

      producto.setDisponibles(disponibles - cantidad);
      producto.setEnCamino(enCamino - cantidad);
      desbloquear(itemId, cantidad);
    } finally {
      mutex.leave();
    }
  }

  public void devolver(String clientId, String itemId, int cantidad) {
    mutex.enter();
    try {
      if (cantidad <= 0 || !this.productos.containsKey(itemId)) {
        throw new IllegalArgumentException("Producto no encontrado");
      }

      Producto producto = this.almacen.get(itemId);
      int disponibles = producto.getDisponibles();

      producto.setDisponibles(disponibles + cantidad);
      desbloquear(itemId, cantidad);
    } finally {
      mutex.leave();
    }
  }

  private Map<String, List<Condition>> condiciones = new HashMap<>();
  public void agregarHilo(String nombreHilo) {
    condiciones.put(nombreHilo, new ArrayList<>());
  }
  public void removerHilo(String nombreHilo) {
    condiciones.remove(nombreHilo);
  }


  public void ofrecerReabastecer(String itemId, int cantidad) {
    mutex.enter();
    if (cantidad <= 0 || !this.productos.containsKey(itemId)){
      throw new IllegalArgumentException("Producto no encontrado");
    }

    Producto producto = this.almacen.get(itemId);
    int disponibles = producto.getDisponibles();
    int enCamino = producto.getEnCamino();
    int comprados = producto.getComprados();
    int minDisp = producto.getMinDisponibles();

    if (disponibles + enCamino - comprados >= minDisp){
      agregarHilo(itemId);
      condOfRe.await();
    }

    producto = this.almacen.get(itemId);
    int enCamino1 = producto.getEnCamino();

    producto.setEnCamino(enCamino1 + cantidad);
    desbloquear( itemId, cantidad);


    mutex.leave();

  }

  public void reabastecer(String itemId, int cantidad) {
    mutex.enter();
    if (cantidad <= 0 || !this.productos.containsKey(itemId)){
      throw new IllegalArgumentException("Producto no encontrado");
    }

    Producto producto = this.almacen.get(itemId);
    int disponibles = producto.getDisponibles();
    int enCamino = producto.getEnCamino();
    int comprados = producto.getComprados();
    int minDisp = producto.getMinDisponibles();



    producto.setDisponibles(disponibles + cantidad);
    producto.setEnCamino(enCamino - cantidad);
    desbloquear(itemId,  cantidad);
    mutex.leave();
  }
  private void desbloquear( String itemId, int cantidad) {
    Producto producto = this.almacen.get(itemId);
    int disponibles = producto.getDisponibles();
    int enCamino = producto.getEnCamino();
    int comprados = producto.getComprados();
    int minDisponibles = producto.getMinDisponibles();

//    if (clientesEnEsperaCondEntregar.size() == 1 && disponibles >= cantidad) {
//      clientesEnEsperaCondEntregar.clear();
//      condEntregar2.signal();
//    }
//    if (clientesEnEsperaCondEntregar.size() > 1 && condEntregar2.waiting() > 0) {
//      Iterator <ClienteEnEspera> it = clientesEnEsperaCondEntregar.iterator();
//      boolean encontrado = false;
//      while(it.hasNext() && !encontrado){
//        ClienteEnEspera p = it.next();
//        String nombre = p.getClientId();
//        if(nombre.equals(itemId) && disponibles >= cantidad){
//          it.remove();
//          condEntregar2.signal();
//          encontrado = true;
//        }
//      }





//     //  Encontrar el cliente prioritario basado en el tiempo de espera máximo
//      ClienteEnEspera clientePrioritario = null;
//      long tiempoEsperaMaximo = Long.MIN_VALUE;
//
//      for (ClienteEnEspera cliente : clientesEnEsperaCondEntregar) {
//        if (cliente.getClientId().equals(itemId)){
//        long tiempoEspera = cliente.getTiempoEspera();
//        if (tiempoEspera > tiempoEsperaMaximo) {
//          tiempoEsperaMaximo = tiempoEspera;
//          clientePrioritario = cliente;
//        }
//        }
//      }
//      if (disponibles >= cantidad) {
//        clientesEnEsperaCondEntregar.remove(clientePrioritario);
//        condEntregar2.signal();
//      }

    //  Encontrar el cliente prioritario basado en el tiempo de espera máximo
    ClienteEnEspera clientePrioritario = null;
    long tiempoEsperaMaximo = Long.MIN_VALUE;
    Iterator<ClienteEnEspera> iterator = clientesEnEsperaCondEntregar.iterator();

    while (iterator.hasNext()) {
      ClienteEnEspera cliente = iterator.next();
      if (cliente.getClientId().equals(itemId)){
        long tiempoEspera = cliente.getTiempoEspera();
        if (tiempoEspera > tiempoEsperaMaximo) {
          tiempoEsperaMaximo = tiempoEspera;
          clientePrioritario = cliente;
        }
      }
    }
    if (clientePrioritario != null && disponibles >= cantidad) {
      clientesEnEsperaCondEntregar.remove(clientePrioritario);
      condEntregar2.signal();
    }

    for (Map.Entry<String, List<Condition>> entry : condiciones.entrySet()) {
      String nombre = entry.getKey();
      if (nombre.equals(itemId)){
        if (disponibles + enCamino - comprados < minDisponibles && condOfRe.waiting() > 0){
          removerHilo(itemId);
          condOfRe.signal();
        }
      }
    }

    }
  }



