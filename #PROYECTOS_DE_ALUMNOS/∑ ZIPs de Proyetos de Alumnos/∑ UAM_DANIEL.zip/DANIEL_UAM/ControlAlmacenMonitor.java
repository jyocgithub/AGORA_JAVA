package cc.controlAlmacen;

import es.upm.babel.cclib.Monitor;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.CopyOnWriteArrayList;


public class ControlAlmacenMonitor implements ControlAlmacen {

  private Monitor mutex;
  private  Monitor.Cond condEntregar2;

  private  Monitor.Cond condOfRe;

  private List<ClienteEnEspera> clientesEnEsperaCondEntregar =  new ArrayList<>();



  private static class ClienteEnEspera {
    public String getClienteId() {
      return clienteId;
    }

    public void setClienteId(String clienteId) {
      this.clienteId = clienteId;
    }

    public String getItemId() {
      return itemId;
    }

    public void setItemId(String itemId) {
      this.itemId = itemId;
    }

    public int getCantidad() {
      return cantidad;
    }

    public void setCantidad(int cantidad) {
      this.cantidad = cantidad;
    }

    public long getTiempoEspera() {
      return tiempoEspera;
    }

    public void setTiempoEspera(long tiempoEspera) {
      this.tiempoEspera = tiempoEspera;
    }

    private String clienteId;
    private String itemId;
    private int cantidad;
    private long tiempoEspera;

    public int getMinDisponibles() {
      return minDisponibles;
    }

    public void setMinDisponibles(int minDisponibles) {
      this.minDisponibles = minDisponibles;
    }

    private int minDisponibles;

    public int getDisponibles() {
      return disponibles;
    }

    public void setDisponibles(int disponibles) {
      this.disponibles = disponibles;
    }

    private int disponibles;
    public ClienteEnEspera(String clienteId, String itemId, int cantidad, long tiempoEspera, int minDisponibles, int disponibles) {
      this.clienteId = clienteId;
      this.disponibles = disponibles;
      this.itemId = itemId;
      this.cantidad = cantidad;
      this.tiempoEspera = tiempoEspera;
      this.minDisponibles = minDisponibles;
    }



  }
  static class Producto {
    //Los datos que contiene cada uno de los producto y sobre los que se trabaja
    private int disponibles;
    private int enCamino;
    private int comprados;
    private int minDisponibles;



    //Sobrescribe el numero de productos disponibles
    public void setDisponibles(int disponibles) {
      this.disponibles = disponibles;
    }

    public void setEnCamino(int enCamino) {
      this.enCamino = enCamino;
    }

    public void setComprados(int comprados) {
      this.comprados = comprados;
    }


    public void setMinDisponibles(int minDisponibles) {
      this.minDisponibles = minDisponibles;
    }
    //Devuelve el numero de productos que estan disponibles
    public int getDisponibles() {
      return this.disponibles;
    }

    public int getEnCamino() {
      return this.enCamino;
    }

    public int getComprados() {
      return this.comprados;
    }

    public int getMinDisponibles() {
      return this.minDisponibles;
    }

    //Inicializa todos los datos del producto
    public Producto(int minDisponibles) {
      this.disponibles = 0;
      this.enCamino = 0;
      this.comprados = 0;
      this.minDisponibles = minDisponibles;
    }

  }

  private Map<String, Integer> productos;
  private Map<String, Producto> almacen;
  // Resource state
  // ...

  // Monitors and conditions
  // ...

  public ControlAlmacenMonitor(Map<String, Integer> tipoProductos) {
    this.productos = tipoProductos;
    this.almacen = new ConcurrentHashMap<>();
    this.mutex = new Monitor();
    condEntregar2 = mutex.newCond();

    condOfRe = mutex.newCond();

    Iterator<Map.Entry<String, Integer>> var2 = tipoProductos.entrySet().iterator();
    //Introduce los datos mediante iteradores
    while(var2.hasNext()) {
      Map.Entry<String, Integer> entry = var2.next();
      String itemId = entry.getKey();
      int minDisponible = entry.getValue();
      Producto producto = new Producto(minDisponible);
      this.almacen.put(itemId, producto);
    }

  }

  public boolean comprar(String clientId, String itemId, int cantidad) {
    mutex.enter();
    try {
      if (cantidad <= 0 || !this.productos.containsKey(itemId)) {
        throw new IllegalArgumentException("Producto no encontrado");
      }

      Producto producto = this.almacen.get(itemId);
      int comprados = producto.getComprados();
      int disponibles = producto.getDisponibles();
      int enCamino = producto.getEnCamino();
      boolean result = disponibles + enCamino >= cantidad + comprados ;

      if (result) {
        producto.setComprados(comprados + cantidad);

        desbloquear(itemId, cantidad);
        return true;
      } else {
        return false;
      }
    }finally {
      mutex.leave();
    }
  }

  public void entregar(String clientId, String itemId, int cantidad) {
    mutex.enter();
    try {
      if (cantidad <= 0 || !this.productos.containsKey(itemId)) {
        throw new IllegalArgumentException("Producto no encontrado");
      }

      Producto producto = this.almacen.get(itemId);
      int disponibles = producto.getDisponibles();
      int minDisp = producto.getMinDisponibles();
      int enCamino = producto.getEnCamino();
      int comprado = producto.getEnCamino();

      if (disponibles < cantidad) {

        ClienteEnEspera cliente = new ClienteEnEspera(clientId, itemId, cantidad, System.currentTimeMillis(), minDisp,disponibles);
        clientesEnEsperaCondEntregar.add(cliente);
        condEntregar2.await();
      }

      producto = this.almacen.get(itemId);
      disponibles = producto.getDisponibles();
      enCamino = producto.getEnCamino();
      comprado = producto.getEnCamino();



      producto.setDisponibles(disponibles - cantidad);
      producto.setComprados(comprado - cantidad);

      desbloquear(itemId, cantidad);
    } finally {
      mutex.leave();
    }
  }

  public void devolver(String clientId, String itemId, int cantidad) {
    mutex.enter();
    try {
      if (cantidad <= 0 || !this.productos.containsKey(itemId)) {
        throw new IllegalArgumentException("Producto no encontrado");
      }

      Producto producto = this.almacen.get(itemId);
      int disponibles = producto.getDisponibles();
      int comprados = producto.getComprados();
      int enCamino = producto.getEnCamino();

      producto.setDisponibles(disponibles + cantidad);
      desbloquear(itemId, cantidad);
    } finally {
      mutex.leave();
    }
  }

  private Map<String, List<Condition>> condiciones = new ConcurrentHashMap<>();
  public void agregarHilo(String nombreHilo) {
    condiciones.put(nombreHilo, new ArrayList<>());
  }
  public void removerHilo(String nombreHilo) {
    condiciones.remove(nombreHilo);
  }


  public void ofrecerReabastecer(String itemId, int cantidad) {
    mutex.enter();
    try {
      if (cantidad <= 0 || !this.productos.containsKey(itemId)) {
        throw new IllegalArgumentException("Producto no encontrado");
      }

      Producto producto = this.almacen.get(itemId);
      int disponibles = producto.getDisponibles();
      int enCamino = producto.getEnCamino();
      int comprados = producto.getComprados();
      int minDisp = producto.getMinDisponibles();

      if (disponibles + enCamino - comprados >= minDisp) {
        agregarHilo(itemId);
        condOfRe.await();
      }


      producto = this.almacen.get(itemId);
      int enCamino1 = producto.getEnCamino();
      producto.setEnCamino(enCamino1 + cantidad);
      desbloquear(itemId, cantidad);
    }finally {

      mutex.leave();
    }
  }

  public void reabastecer(String itemId, int cantidad) {
    mutex.enter();
    try {
      if (cantidad <= 0 || !this.productos.containsKey(itemId)) {
        throw new IllegalArgumentException("Producto no encontrado");
      }

      Producto producto = this.almacen.get(itemId);
      int disponibles = producto.getDisponibles();
      int enCamino = producto.getEnCamino();
      int comprados = producto.getComprados();

      producto.setDisponibles(disponibles + cantidad);
      producto.setEnCamino(enCamino - cantidad);

      desbloquear(itemId, cantidad);
    }finally {
      mutex.leave();
    }
  }


  private void desbloquear( String itemId, int cantidad) {
    mutex.enter();
    try {
      Producto producto = this.almacen.get(itemId);
      int disponibles = producto.getDisponibles();
      int enCamino = producto.getEnCamino();
      int comprados = producto.getComprados();
      int minDisponibles = producto.getMinDisponibles();
      ClienteEnEspera entregaDesbloqueo = null;
      long entregaDesbloqueoTiempo = Long.MAX_VALUE;
      boolean desbloque = false;



      if (clientesEnEsperaCondEntregar.size() == 1) {
        ClienteEnEspera cliente = clientesEnEsperaCondEntregar.get(0);
        if (disponibles >= cliente.cantidad && cliente.getItemId().equals(itemId)) {
          clientesEnEsperaCondEntregar.remove(cliente);
          condEntregar2.signal();
        }

      }
      for (ClienteEnEspera entrega : clientesEnEsperaCondEntregar) {
        if (entrega.getItemId().equals(itemId)) {
          if (entrega.getTiempoEspera() < entregaDesbloqueoTiempo) {
            entregaDesbloqueo = entrega;
            entregaDesbloqueoTiempo = entrega.getTiempoEspera();
          }
        }
      }

      if (entregaDesbloqueo != null && disponibles >= entregaDesbloqueo.getCantidad()) {
        clientesEnEsperaCondEntregar.remove(entregaDesbloqueo);
        condEntregar2.signal();
      }


      if (disponibles + enCamino - comprados < minDisponibles ){
        for (Map.Entry<String, List<Condition>> entry : condiciones.entrySet()) {
          String nombre = entry.getKey();
          if (nombre.equals(itemId)) {
            if (condOfRe.waiting() > 0) {
              removerHilo(itemId);
              condOfRe.signal();
            }
          }
        }
      }
    }finally{
      mutex.leave();
    }
  }
}