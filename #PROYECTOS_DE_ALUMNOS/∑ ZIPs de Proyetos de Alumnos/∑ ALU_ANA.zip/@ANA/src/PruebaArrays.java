import java.util.Scanner;

public class PruebaArrays {

	public static void main(String[] args) {
		System.out.println("...............................");
		System.out.println(invertirNumero(46812));
		System.out.println("...............................");
		System.out.println(invertirNumero2(6824139));
		System.out.println("...............................");

		Scanner c = new Scanner(System.in);

		// int[] lista = new int[3];
		// int[] lista2;
		// lista2 = new int[3];
		//
		// lista2[1] = 235;
		//// System.out.println(lista2[1]);

		// int i = 1;
		// while (i < 6) {
		// System.out.println(i);
		// i++;
		// }

		// System.out.println("4 por 1 es 4");
		// System.out.println("4 por 2 es 8");
		// System.out.println("4 por 3 es 12");
		// System.out.println("4 por 4 es 16");
		// System.out.println("4 por 5 es 20");
		//
		// int k = 1;
		// while (k <= 10) {
		// System.out.println("4 por " + k + " es " +k*4);
		// k++;
		// }

		// int[] lis = { 2, 4, 7, 4, 8 };
		//
		// System.out.println(lis[0]);
		// System.out.println(lis[1]);
		//
		// System.out.println(lis[2]);
		// System.out.println(lis[3]);
		// System.out.println(lis[4]);
		//
		// int w = 0;
		// while (w < 5) {
		// System.out.println(lis[w]);
		// w++;
		// }

		// int suma=0;
		//
		// int y = 0;
		// while (y < lis.length) {
		// suma = suma + lis[y];
		// y++;
		// }

		// int mayor=0;
		//
		// int y = 0;
		// while (y < lis.length) {
		// if (lis[y] > mayor) {
		// mayor=lis[y];
		// }
		// y++;
		// }

		// int[] lisx = new int[10];
		// lisx[0] = 5;
		// lisx[1] = 2;
		// lisx[2] = 1;
		// lisx[3] = 6;
		//
		// int res = calcularelmenor(lisx, 82);
		// double res2 = calcularmedia(lisx, 4);
		//
		// sustituir(lisx, 2, 9);
		//
		// int resu = cuadrado(7);
		// Scanner s = new Scanner(System.in);

		////////////////////////////////////////////////////
		////////////////////////////////////////////////////
		////////////////////////////////////////////////////
		////////////////////////////////////////////////////
		////////////////////////////////////////////////////

		// int[] s = deDecimalaBinario(125);
		//
		// for (int i = 0; i < s.length; i++) {
		//
		// System.out.print(s[i]);
		//
		// }
		// System.out.println();
		// double solu = deBinarioADecimal(s);
		// System.out.println(solu);

		int xa = 19;
		int[] arraya = { 2, 6 };
		probar(xa, arraya);

		System.out.println(xa);
		System.out.println(arraya[0]);
	}

	public static void probar(int a, int[] b) {
		a = 5;
		b[0] = 23;
	}

	// 13. Diseñar un método que reciba como parámetro un número entero y devuelva el número con
	// sus dígitos invertidos. (utilizer un array para situar cada dígito en una posición)

	public static int invertirNumero(int numero) {

		// // como convertir un String en un int
		// String h = "4235";
		// int hh = Integer.parseInt(h);
		// // como convertir un int en un String
		// int k = 4235;
		// String kk = String.valueOf(k);
		// String kkk = k+"";
		//

		int resultado = 0;
		// convertir el numero en una cadena
		String numeroString = String.valueOf(numero);
		int tamano = numeroString.length();
		String[] digitos = new String[tamano];

		int x = 0;
		while (x < tamano) {
			digitos[x] = numeroString.substring(x, x + 1);
			x++;
		}
		String resultadofinal = "";

		// resultadofinal = resultadofinal + digitos[3];
		// resultadofinal = resultadofinal + digitos[2];
		// resultadofinal = resultadofinal + digitos[1];
		// resultadofinal = resultadofinal + digitos[0];

		int k = tamano - 1;
		while (k >= 0) {
			resultadofinal = resultadofinal + digitos[k];
			k--;
		}
		resultado = Integer.parseInt(resultadofinal);

		return resultado;
	}

	public static int invertirNumero2(int n) {
		int resultado = 0;
		// convertir el numero en una cadena
		int[] digitos = new int[25];

		int i = 0;
		while (n != 0) {
			digitos[i] = n % 10;
			n = n / 10;
			i++;
		}
		// curiosamente (jeje) la variable i queda con el valor del total de digitos del numero
		//
		// resultado = resultado + digitos[0] * 1000;
		// resultado = resultado + digitos[1] * 100;
		// resultado = resultado + digitos[2] * 10;
		// resultado = resultado + digitos[3] * 1;

		int j = 0;
		while (j < i) {
			int jjj = (i - 1) - j;
			int multi = (int) Math.pow(10, jjj);
			resultado = resultado + digitos[j] * multi;
			j++;
		}

		return resultado;
	}

	public static int cuadrado(int j) {
		int cuad = j * j;
		return cuad;
	}

	// 1
	public static double calcularmedia(int[] lis, int n) {

		int y = 0;
		double suma = 0;
		while (y < n) {
			suma = suma + lis[y];

			y++;
		}

		double media = suma / n;
		return media;
	}

	// 2
	public static int calcularelmenor(int[] lis, int tam) {
		int menor = lis[0];
		int y = 0;
		while (y < tam) {
			if (lis[y] < menor) {
				menor = lis[y];
			}
			y++;
		}
		return menor;
	}

	// 3
	public static void sustituir(int[] lis, int numASustituir, int sustituto) {
		int y = 0;
		while (y < lis.length) {

			if (lis[y] == numASustituir) {
				lis[y] = sustituto;
			}
			y++;
		}
	}

	// 4 .- Realizar un método que nos permita calcular cuántos elementos positivos,
	// negativos y ceros hay almacenados en un array de tamaño máximo MAX y n elementos,
	// crear un array respuesta de 3 elementos y guardar cada resultado en uno deellos,
	// en respuesta[0] el número de elementos positivos excluyendo el 0, enrespuesta[1]
	// el numero de elementos negativos y en respuesta[2] el númerode 0’s.
	// El método debe retornar
	// respuesta (public static int [] cuentaPosNegCero(int [] a, intn))

	public static int[] cuentaPosNegCero(int[] lis, int n) {
		int[] respuesta = new int[3];

		int y = 0;
		int contPos = 0, contNeg = 0, contCeros = 0;
		while (y < n) {
			if (lis[y] == 0) {
				contCeros++;
			} else if (lis[y] < 0) {
				contNeg++;
			} else {
				contPos++;
			}
			y++;
		}
		respuesta[0] = contPos;
		respuesta[1] = contNeg;
		respuesta[2] = contCeros;

		return respuesta;
	}

	// 5 Realizar un método para obtener la suma de los elementos pares y la de los
	// impares.

	public static void sumaParesImpares(int[] lis, int n) {
		int sumapar = 0, sumaimpar = 0;

		int y = 0;
		while (y < n) {
			if (lis[y] % 2 == 0) {
				sumapar = sumapar + lis[y];
			} else {
				sumaimpar = sumaimpar + lis[y];
			}
			y++;
		}

	}

	// 6 Realizar un método para obtener el mayor y menor elemento contenido en unarray.
	public static void mayorMenor(int[] lis, int n) {
		int mayor = lis[0];
		int menor = lis[0];
		int y = 0;
		while (y < n) {
			if (lis[y] > mayor) {
				mayor = lis[y];
			}
			if (lis[y] < menor) {
				menor = lis[y];
			}
			y++;
		}

	}

	// 7 Realizar un método que devuelva true si dos arrays (de
	// tamaño máximo MAX y n elementos) A y B recibidos como parámetro
	// son iguales y false en caso contrario.

	public static boolean soniguales(int[] A, int[] B, int n) {
		boolean res = true;
		int y = 0;
		while (y < n && res == true) {
			if (A[y] != B[y]) {
				res = false;
			}
			y++;
		}
		return res;
	}

	// 8 Realizar un método para calcular el array suma de dos array A y B
	// detamaño máximo MAX y n elementos, de dos maneras,
	public static int[] suma1(int[] a, int nA, int[] b, int nB) {
		int tamanodec = 0;
		if (nA > nB) {
			tamanodec = nA;
		} else {
			tamanodec = nB;
		}
		int[] c = new int[tamanodec];

		int y = 0;
		while (y < tamanodec) {
			if (y > a.length) {
				c[y] = b[y];
			} else if (y > b.length) {
				c[y] = a[y];
			} else {
				c[y] = a[y] + b[y];
			}
			y++;
		}
		return c;
	}

	public static int[] suma3(int[] a, int nA, int[] b, int nB) {
		int tamanodec = 0;
		int[] c;
		if (a.length > b.length) {
			c = a;
			int y = 0;
			while (y < b.length) {
				c[y] = c[y] + b[y];
				y++;
			}
		} else {
			c = b;
			int y = 0;
			while (y < a.length) {
				c[y] = c[y] + a[y];
				y++;
			}
		}
		return c;
	}

	/**
	 * 9 Realizar un método para convertir un número decimal en binario, se almacenará cada dígito binario en un elemento de un
	 * array de números enteros (0 ó1).
	 */
	public static int[] deDecimalaBinario(int numOriginal) {
		int totnumeros = 0;
		int resto;
		int x = numOriginal;
		while (x > 0) {
			resto = x % 2;
			x = x / 2;
			totnumeros++;
		}

		int[] solu = new int[totnumeros];

		x = numOriginal;

		int y = totnumeros - 1;
		while (y >= 0) {
			resto = x % 2;
			solu[y] = resto;
			x = x / 2;
			y--;
		}
		return solu;
	}

	public static double deBinarioADecimal(int[] numBinarioOriginal) {
		double totalfinal = 0;
		int y = 0;
		while (y < numBinarioOriginal.length) {
			if (numBinarioOriginal[y] == 1) {
				int exponente = (numBinarioOriginal.length - 1) - y;
				totalfinal = totalfinal + Math.pow(2, exponente);
			}
			y++;
		}
		return totalfinal;
	}

	public int[] deDecimalACA2(int numOriginal) {
		int[] res = null;
		if (numOriginal > 0) {
			res = deDecimalaBinario(numOriginal);
		} else {
			numOriginal = numOriginal * (-1);
			res = deDecimalaBinario(numOriginal);
			int y = 0;
			while (y < res.length) {
				if (res[y] == 1) {
					res[y] = 0;
				}
				if (res[y] == 0) {
					res[y] = 1;
				}
				y++;
			}
		}
		return res;
	}

}
