package socketsConObjects;

public class Mensaje {

	int id_mensaje;
	String contenido;
	final static int MSG_CONEXIONOK = 0;
	final static int MSG_SOLICITUDCONEXION = 1;
	final static int MSG_LISTARCONECTADOS = 2;
	final static int MSG_FINCONEXION = 100;

	public Mensaje(int id_mensaje, String contenido) {
		super();
		this.id_mensaje = id_mensaje;
		this.contenido = contenido;
	}

}
