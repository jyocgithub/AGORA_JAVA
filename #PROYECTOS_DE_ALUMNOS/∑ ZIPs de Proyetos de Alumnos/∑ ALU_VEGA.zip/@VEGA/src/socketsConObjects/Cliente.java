package socketsConObjects;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.Scanner;

public class Cliente {

	String nombre;
	Socket socketcliente;
	int puerto = 12345;
	String host = "localhost";
	PrintWriter escritor;
	BufferedReader lector;

	public static void main(String[] args) {
		new Cliente().inicio();
	}

	public void inicio() {
		Socket socketcliente;
		int puerto = 12345;
		String host = "localhost";
		PrintWriter escritor;
		BufferedReader lector;
		System.out.println("Dame un nombre de conexion");
		nombre = new Scanner(System.in).nextLine();

		try {
			socketcliente = new Socket(host, puerto);
			System.out.println("---- cliente conectado a servidor por puerto " + socketcliente.getPort());

			escritor = new PrintWriter(socketcliente.getOutputStream());
			lector = new BufferedReader(new InputStreamReader(socketcliente.getInputStream()));

			String peticion = "";
			System.out.println(nombre + " ---- en hilo");
			String linea;
			try {

				linea = lector.readLine();
				System.out.println(linea);

				while (!peticion.equalsIgnoreCase("fin")) {
					System.out.println("ESCRIBIR PETICION AL SERVIDOR (escriba FIN para acabar)" + linea);
					peticion = new Scanner(System.in).nextLine();
					escritor.println(peticion);
					escritor.flush();
					linea = lector.readLine();
					System.out.println("Respuesta del servidor :" + linea);
				}
				System.out.println("CLIENTE CERRADO---------------");

			} catch (IOException e) {
				e.printStackTrace();
			}

		} catch (IOException e) {
			e.printStackTrace();
		}

	}

}

// class HiloDelCliente implements Runnable {
//
// PrintWriter escritor;
// BufferedReader lector;
// String nombre;
//
// public HiloDelCliente(String n, PrintWriter escritor, BufferedReader lector) {
// super();
// this.escritor = escritor;
// this.lector = lector;
// this.nombre = n;
// }
//
// @Override
// public void run() {
// String peticion = "";
// System.out.println(nombre + " ---- en hilo");
// String linea;
// try {
//
// linea = lector.readLine();
// System.out.println(linea);
//
// while (!peticion.equalsIgnoreCase("fin")) {
// System.out.println("ESCRIBIR PETICION AL SERVIDOR (escriba FIN para acabar)" + linea);
// peticion = new Scanner(System.in).nextLine();
// escritor.println(peticion);
// escritor.flush();
// linea = lector.readLine();
// System.out.println("Respuesta del servidor :" + linea);
// }
// System.out.println("CLIENTE CERRADO---------------");
//
// } catch (IOException e) {
// e.printStackTrace();
// }
//
// }
// }
