package socketsConObjects;

import java.io.File;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.List;

public class Servidor {

	public static void main(String[] args) {

		Socket socketcliente;
		int puerto = 12345;
		ServerSocket ss;
		ObjectOutputStream escritor;
		ObjectInputStream lector;

		try {
			ss = new ServerSocket(puerto);

			System.out.println("---- servidor creado");
			while (true) {
				System.out.println("---- esperando clientes...");
				socketcliente = ss.accept();
				System.out.println("---- cliente conectado...");
				escritor = new ObjectOutputStream(socketcliente.getOutputStream());
				lector = new ObjectInputStream(socketcliente.getInputStream());
				ClienteConectado clienteconectado = new ClienteConectado(socketcliente, ss, escritor, lector);
				HiloDelServidor hds = new HiloDelServidor(clienteconectado);
				Thread t = new Thread(hds);
				t.start();
			}

		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}

class HiloDelServidor implements Runnable {
	ClienteConectado clienteconectado;
	String Directorioraizdepaginas = "/Users/inaki/Downloads/pruebas/";

	public HiloDelServidor(ClienteConectado clienteconectado) {
		super();
		this.clienteconectado = clienteconectado;
	}

	@Override
	public void run() {
		String peticion = "";
		System.out.println("En el hilo servidor");
		try {
			clienteconectado.escritor.writeObject(new Mensaje(Mensaje.MSG_CONEXIONOK, ""));
			clienteconectado.escritor.flush();

			while (!peticion.equalsIgnoreCase("fin")) {
				peticion = clienteconectado.lector.readLine();
				System.out.println("He recibido la peticion: " + peticion);

				File file = new File(Directorioraizdepaginas, peticion);

				if (!file.exists()) {
					clienteconectado.escritor.println("404");

				} else {
					clienteconectado.escritor.println("220");
				}
				clienteconectado.escritor.flush();
			}
			System.out.println("SERVIDOR CERRADO---------------");
		} catch (IOException e) {
			e.printStackTrace();
		}

	}
}

class ClienteConectado {
	Socket socketcliente;
	int puerto = 12345;
	ServerSocket ss;
	ObjectOutputStream escritor;
	ObjectInputStream lector;
	String nombre;
	List<Mensaje> mensajes;

	public ClienteConectado(Socket socketcliente, ServerSocket ss, ObjectOutputStream escritor,
			ObjectInputStream lector) {
		super();
		this.socketcliente = socketcliente;
		this.ss = ss;
		this.escritor = escritor;
		this.lector = lector;
		this.nombre = nombre;
		this.mensajes = mensajes;
	}

}