package hilosencilloi;

import java.util.Random;

public class EjemploHilo1
{

	public static void main(String[] args)
	{

		Buffer b = new Buffer();

		// creo un objeto de la otra clase
		HebraConRunnable objetoHCR = new HebraConRunnable("Eva", b);
		HebraConRunnable objetoHCR2 = new HebraConRunnable("Paz", b);
		HebraConRunnable objetoHCR3 = new HebraConRunnable("Maria", b);

		// Creo un hilo con el objeto de la otra clase
		Thread objetoThread = new Thread(objetoHCR);
		Thread objetoThread2 = new Thread(objetoHCR2);
		Thread objetoThread3 = new Thread(objetoHCR3);

		// arranco el hilo creado
		// CUIDADO, no es objetoThread.run(), pues start() ya inicia el método run()
		objetoThread.start();
		objetoThread2.start();
		objetoThread3.start();

		try
		{
			objetoThread.join();
			objetoThread2.join();
			objetoThread3.join();
		} catch (InterruptedException e)
		{
			e.printStackTrace();
		}

		System.out.println("FINAL:    " + b.valor);
	}

}

class HebraConRunnable implements Runnable
{
	String nombre;
	Buffer b;

	public HebraConRunnable(String n, Buffer b)
	{
		nombre = n;
		this.b = b;
	}

	// tiene un método run que será lo que se ejecute al iniciar el hilo con start() desde fuera
	@Override
	public void run()
	{
		for (int i = 0; i < 10; i++)
		{
			Buffer.espera(100);
			b.valor++;
			System.out.println("Soy " + nombre + " y asi esta la cosa:" + b.valor);

		}
	}
}

class Buffer
{
	int valor = 0;

	static void espera(int tiempo)
	{
		try
		{
			Thread.sleep(new Random().nextInt(100));
		} catch (InterruptedException e)
		{
		}
	}
}
