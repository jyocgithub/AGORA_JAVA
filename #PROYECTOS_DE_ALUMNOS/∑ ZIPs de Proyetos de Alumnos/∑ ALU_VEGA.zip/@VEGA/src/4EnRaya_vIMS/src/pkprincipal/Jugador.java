package pkprincipal;

public class Jugador
{

	String nombre;
	int color;

	/**
	 * mete una ficha en la columna dad, con el color dado
	 */
	void anadirFicha(int columna, int color, int[][] matriz)
	{

	}

}
