package pkprincipal;

import java.util.ArrayList;

interface ITablero
{

	/**
	 * Borra la matriz de tablero y pone los indices de fichas de los jugadores a 0
	 */
	public void inicilalizarTablero();

	/**
	 * Mira si la columna esta llena
	 * 
	 * @return true si la columna no esta llena
	 */
	public boolean puedoPoner();

	/**
	 * Mira si el jugador con numero indicado por parametro ha ganado
	 * 
	 * @param numjugador
	 *            numero de jugador a comprobar, debe coincidir el numero con el color de la ficha
	 * @return array de 8 posiciones con las coordenadas (a pares) de las 4 fichas ganadoras
	 */
	public ArrayList<Posicion> haGanado(int numjugador);

	/**
	 * Devuelve una lista de las posibles posiciones en las que puede poner ficha
	 * 
	 */
	public ArrayList<Posicion> listaPosicionesPosibles(int color);

}
