package pkprincipal;

import java.util.ArrayList;

public class Tablero implements ITablero
{
	final int FICHAVACIA = 0;
	final int FICHAROJA = 1;
	final int FICHABLANCA = 2;

	Posicion[][] tablero = new Posicion[6][7];

	public int puedoGanarHorizontal(Posicion posactual, int colordeficha)
	{

		// miramos a la derecha e izquierda
		int contador = 0;
		boolean vanseguidas = true;

		int columnaactual = posactual.getX();
		int filaactual = posactual.getX();

		for (int c = columnaactual; vanseguidas; c++)
		{
			if (c < 7)
			{
				if (tablero[filaactual][c].getMicolor() == colordeficha)
				{
					contador++;
				} else
				{
					vanseguidas = false;
				}
			}
		}

		vanseguidas = true;
		for (int c = columnaactual; vanseguidas; c--)
		{
			if (c > 0)
			{
				if (tablero[filaactual][c].getMicolor() == colordeficha)
				{
					contador++;
				} else
				{
					vanseguidas = false;
				}
			}
		}

		return contador;
	}

	public int puedoGanar0a6(Posicion posactual, int colordeficha)
	{

		// miramos a la derecha e izquierda
		int contador = 0;
		boolean vanseguidas = true;

		int columnaactual = posactual.getX();
		int filaactual = posactual.getX();

		// DIAGONAL SO - NE
		vanseguidas = true;
		for (int c = columnaactual, f = filaactual; vanseguidas; f--, c++)
		{
			if (c < 7 && f > 0)
			{
				if (tablero[f][c].getMicolor() == colordeficha)
				{
					contador++;
				} else
				{
					vanseguidas = false;
				}
			}
		}

		for (int c = columnaactual, f = filaactual; vanseguidas; f++, c--)
		{
			if (c > 0 && f < 6)
			{
				if (tablero[f][c].getMicolor() == colordeficha)
				{
					contador++;
				} else
				{
					vanseguidas = false;
				}
			}
		}
		return contador;
	}

	@Override
	public void inicilalizarTablero()
	{
		// TODO Auto-generated method stub

	}

	@Override
	public boolean puedoPoner()
	{
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public ArrayList<Posicion> haGanado(int numjugador)
	{

		return null;
	}

	@Override
	public ArrayList<Posicion> listaPosicionesPosibles(int color)
	{
		// TODO Auto-generated method stub
		return null;
	}

}
