package pkprincipal;

public class JugadorPersona
{

}
