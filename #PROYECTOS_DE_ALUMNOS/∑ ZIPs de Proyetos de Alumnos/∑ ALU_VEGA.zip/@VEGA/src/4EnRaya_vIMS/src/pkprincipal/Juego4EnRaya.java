package pkprincipal;

public class Juego4EnRaya
{

	// inicia con uan ventana wue pide nomnbre al usuario
	// sortea el turno
	// arranca ventana principal
}
