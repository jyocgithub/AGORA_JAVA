package pkprincipal;

public interface IJugador
{
	void anadirFicha(int columna, int color, int[][] matriz);
}
