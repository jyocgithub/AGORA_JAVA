package pkprincipal;

import java.util.ArrayList;

public class JugadorMaquina
{

	/**
	 * 
	 * @return
	 */
	int cualPoner()
	{
		// ver si puedo acabar - puedoAcabar()
		// ver si pueda acabar el otro - puedeAcabarElOtro()
		// puedoCrearDosCondicionesGanadoras
		// puedeCrearElOtroDosCondicionesGanadoras
		// puedeCrearElOtroUnaCondicionGanadora
		// puedoCrearYoUnaCondicionGanadora

		// Intentar juntar 2
		// Intentar que no cree el otro 2

		// azar
		return 0;
	}

	/**
	 * 
	 * @return columna en la que puede acabar, o 0 si no hay posibilidad
	 */
	int puedoAcabar()
	{
		return 0;
	}

	/**
	 * 
	 * @return columna en la que puede acabar, o 0 si no hay posibilidad
	 */
	ArrayList<Posicion> puedeAcabarElOtro()
	{
		return null;
	}

	/**
	 * Existe alguna posicion que pueda poner y dejar dos lineas de 3 para ganar
	 * 
	 * @return
	 */
	int puedoCrearDosCondicionesGanadoras()
	{
		return 0;
	}

	/**
	 * Existe alguna posicion que pueda poner y dejar dos lineas de 3 para ganar
	 * 
	 * @return
	 */
	int puedeCrearElOtroDosCondicionesGanadoras()
	{

		return 0;
	}

}
