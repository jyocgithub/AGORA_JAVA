package pkprincipal;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class VentanaPrincipal
{
	int matrizprueba[][] = new int[6][7];

	int calcularQueFilaEstaLibre(int columna)
	{
		int x = 5;
		for (int fil = 0; fil <= 5; fil++)
		{
			if (matrizprueba[fil][columna] != 0)
			{
				x = fil - 1;
				break;
			}
		}
		return x;
	}

	// CÓDIGO A EJECUTAR CUANDO SE PINCHE EN EL BOTON
	public void colocarFicha(int columna)
	{
		// la fila hasta la que cae la ficha se debe leer de la matriz
		// ejemplo de como cae hasta fila 4 (la penúltima)

		int fila = calcularQueFilaEstaLibre(columna);
		// int fila = 4;

		numeroFichasPuestas++;
		matrizprueba[fila][columna] = numeroFichasPuestas;
		arrFichasPuestas[numeroFichasPuestas] = new JLabel(imagenDefichaDeMiColor);

		int posxSuperior = 223;
		int posySuperior = 138;

		int posy = posySuperior + (fila * 40);
		int posx = posxSuperior + ((columna) * 40);

		arrFichasPuestas[numeroFichasPuestas].setBounds(posx, posy, 33, 33);
		frmPrincipal.getContentPane().add(arrFichasPuestas[numeroFichasPuestas]);
		frmPrincipal.repaint();

		// CÓDIGO A EJECUTAR CUANDO SE PINCHE EN EL BOTON

	}

	public void borraTablero()
	{

	}

	private void initialize()
	{

		// Crear arrays e inicializar variables
		arrFichasCabeceras = new JLabel[7];
		arrFichasPuestas = new JLabel[100];
		arrBtnTransp = new JButton[7];
		anchoVentana = 800;
		altoVentana = 600;
		numeroFichasPuestas = 0;

		imagenDefichaDeMiColor = new ImageIcon(leeImagen("FichaRoja.png"));
		imagenDefichaDeMiColorCabecera = new ImageIcon(leeImagen("FichaRojaCabecera.png"));

		// ------------------ FRAME VENTANATABLERO
		// ----------------------------------------
		frmPrincipal = new JFrame();
		frmPrincipal.setBounds(100, 100, 800, 600);
		frmPrincipal.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmPrincipal.setResizable(false);
		frmPrincipal.setContentPane(new JLabel(new ImageIcon("FondoConSilla.png")));
		frmPrincipal.setLayout(null);

		// ------------------ BOTON SEGUIR
		// ----------------------------------------
		btnSeguir = new JButton("Seguir");
		btnSeguir.setBounds(700, 10, 70, 40);
		frmPrincipal.getContentPane().add(btnSeguir);

		// ------------------ IMAGENES TRANSPARENTES DE CABEZAS DE FICHA
		// ----------------------------------------
		for (int i = 0; i < 7; i++)
		{
			JLabel lblFichaCab = new JLabel(new ImageIcon(leeImagen("FichaRojaCabecera.png")));
			arrFichasCabeceras[i] = lblFichaCab;
			arrFichasCabeceras[i].setBounds(225 + (i * 40), 100, 33, 33);
			arrFichasCabeceras[i].setVisible(false);
			frmPrincipal.getContentPane().add(arrFichasCabeceras[i]);
			frmPrincipal.repaint();
		}

		// ------------------ BOTONES TRANSPARENTES DE DELANTE DE TABLERO
		// ----------------------------------------
		JButton cadab;
		for (colactual = 0; colactual < 7; colactual++)
		{
			colactual = colactual;
			cadab = new JButton("");
			arrBtnTransp[colactual] = cadab;
			arrBtnTransp[colactual].setBounds(220 + (40 * colactual), 130, 40, 250);
			arrBtnTransp[colactual].setOpaque(false);
			arrBtnTransp[colactual].setContentAreaFilled(false);
			arrBtnTransp[colactual].setBorderPainted(false);

			frmPrincipal.getContentPane().add(arrBtnTransp[colactual]);

		}

		// ------------------ LSTENERS DE LOS BOTONES TRANSPARENTES DE DELANTE DE TABLERO
		// ----------------------------------------
		// for (colactual = 0; colactual < 7; colactual++)
		// {
		//
		// arrBotones[colactual].addMouseListener(new MouseAdapter()
		// {
		// @Override
		// public void mouseEntered(MouseEvent me)
		// {
		// arrFichasCabeceras[colactual].setVisible(true);
		// // mostrarFichaCabeza(arrBotones[i], i);
		// }
		//
		// @Override
		// public void mouseExited(MouseEvent me)
		// {
		// arrFichasCabeceras[colactual].setVisible(false);
		// // ocultarFichaCabeza(arrBotones[i], i);
		// }
		//
		// });
		// }

	}

	/**
	 * Crea una BufferedImage desde un nombre de fichero de disco (en string)
	 * 
	 * @param nombre
	 * @return
	 */

	public static BufferedImage leeImagen(String nombre)
	{
		BufferedImage img = null;
		try
		{
			img = ImageIO.read(new File(nombre));
		} catch (IOException e)
		{
			e.printStackTrace();
		}
		return img;
	}

	// ------------------ ATRIBUTOS
	// ----------------------------------------
	private JFrame frmPrincipal;

	int colactual = 0;
	int numeroFichasPuestas;
	JLabel[] arrFichasPuestas;
	JLabel[] arrFichasCabeceras;
	JButton[] arrBtnTransp;
	int anchoVentana;
	int altoVentana;
	ImageIcon imagenDefichaDeMiColor;
	ImageIcon imagenDefichaDeMiColorCabecera;
	JButton btnSeguir;

	// CONSTRUCTOR
	public VentanaPrincipal()
	{
		initialize();
		crearListeners();
	}

	// MAIN QUE LANZA LA VENTANA A LA VEZ
	// ----------------------------------------
	public static void main(String[] args)
	{
		EventQueue.invokeLater(new Runnable()
		{
			@Override
			public void run()
			{
				try
				{
					VentanaPrincipal window = new VentanaPrincipal();
					window.frmPrincipal.setVisible(true);
				} catch (Exception e)
				{
					e.printStackTrace();
				}
			}
		});
	}

	void crearListeners()
	{

		arrBtnTransp[0].addActionListener(new ActionListener()
		{
			@Override
			public void actionPerformed(ActionEvent ev)
			{
				colocarFicha(0);
			}
		});
		arrBtnTransp[1].addActionListener(new ActionListener()
		{
			@Override
			public void actionPerformed(ActionEvent ev)
			{
				colocarFicha(1);
			}
		});
		arrBtnTransp[2].addActionListener(new ActionListener()
		{
			@Override
			public void actionPerformed(ActionEvent ev)
			{
				colocarFicha(2);
			}
		});
		arrBtnTransp[3].addActionListener(new ActionListener()
		{
			@Override
			public void actionPerformed(ActionEvent ev)
			{
				colocarFicha(3);
			}
		});
		arrBtnTransp[4].addActionListener(new ActionListener()
		{
			@Override
			public void actionPerformed(ActionEvent ev)
			{
				colocarFicha(4);
			}
		});
		arrBtnTransp[5].addActionListener(new ActionListener()
		{
			@Override
			public void actionPerformed(ActionEvent ev)
			{
				colocarFicha(5);
			}
		});
		arrBtnTransp[6].addActionListener(new ActionListener()
		{
			@Override
			public void actionPerformed(ActionEvent ev)
			{
				colocarFicha(6);
			}
		});

		arrBtnTransp[0].addMouseListener(new MouseAdapter()
		{
			@Override
			public void mouseEntered(MouseEvent me)
			{
				arrFichasCabeceras[0].setVisible(true);
				// mostrarFichaCabeza(arrBotones[i], i);
			}

			@Override
			public void mouseExited(MouseEvent me)
			{
				arrFichasCabeceras[0].setVisible(false);
				// ocultarFichaCabeza(arrBotones[i], i);
			}

		});
		arrBtnTransp[1].addMouseListener(new MouseAdapter()
		{
			@Override
			public void mouseEntered(MouseEvent me)
			{
				arrFichasCabeceras[1].setVisible(true);
				// mostrarFichaCabeza(arrBotones[i], i);
			}

			@Override
			public void mouseExited(MouseEvent me)
			{
				arrFichasCabeceras[1].setVisible(false);
				// ocultarFichaCabeza(arrBotones[i], i);
			}

		});
		arrBtnTransp[2].addMouseListener(new MouseAdapter()
		{
			@Override
			public void mouseEntered(MouseEvent me)
			{
				arrFichasCabeceras[2].setVisible(true);
				// mostrarFichaCabeza(arrBotones[i], i);
			}

			@Override
			public void mouseExited(MouseEvent me)
			{
				arrFichasCabeceras[2].setVisible(false);
				// ocultarFichaCabeza(arrBotones[i], i);
			}

		});
		arrBtnTransp[3].addMouseListener(new MouseAdapter()
		{
			@Override
			public void mouseEntered(MouseEvent me)
			{
				arrFichasCabeceras[3].setVisible(true);
				// mostrarFichaCabeza(arrBotones[i], i);
			}

			@Override
			public void mouseExited(MouseEvent me)
			{
				arrFichasCabeceras[3].setVisible(false);
				// ocultarFichaCabeza(arrBotones[i], i);
			}

		});
		arrBtnTransp[4].addMouseListener(new MouseAdapter()
		{
			@Override
			public void mouseEntered(MouseEvent me)
			{
				arrFichasCabeceras[4].setVisible(true);
				// mostrarFichaCabeza(arrBotones[i], i);
			}

			@Override
			public void mouseExited(MouseEvent me)
			{
				arrFichasCabeceras[4].setVisible(false);
				// ocultarFichaCabeza(arrBotones[i], i);
			}

		});
		arrBtnTransp[5].addMouseListener(new MouseAdapter()
		{
			@Override
			public void mouseEntered(MouseEvent me)
			{
				arrFichasCabeceras[5].setVisible(true);
				// mostrarFichaCabeza(arrBotones[i], i);
			}

			@Override
			public void mouseExited(MouseEvent me)
			{
				arrFichasCabeceras[5].setVisible(false);
				// ocultarFichaCabeza(arrBotones[i], i);
			}

		});
		arrBtnTransp[6].addMouseListener(new MouseAdapter()
		{
			@Override
			public void mouseEntered(MouseEvent me)
			{
				arrFichasCabeceras[6].setVisible(true);
				// mostrarFichaCabeza(arrBotones[i], i);
			}

			@Override
			public void mouseExited(MouseEvent me)
			{
				arrFichasCabeceras[6].setVisible(false);
				// ocultarFichaCabeza(arrBotones[i], i);
			}

		});

		// ******************************************** para ver las posiciones del nouse en pantalla
		frmPrincipal.addMouseMotionListener(new MouseAdapter()
		{
			@Override
			public void mouseMoved(MouseEvent me)
			{
				btnSeguir.setText(me.getX() + ":" + me.getY());
			}
		});

		btnSeguir.addActionListener(new ActionListener()
		{
			@Override
			public void actionPerformed(ActionEvent ev)
			{
				arrFichasPuestas[numeroFichasPuestas] = null;
				for (int i = 0; i < 6; i++)
				{
					for (int j = 0; j < 7; j++)
					{
						if (matrizprueba[i][j] == numeroFichasPuestas)
						{
							matrizprueba[i][j] = 0;
							numeroFichasPuestas--;

						}
					}
				}
			}
		});
	}

}
