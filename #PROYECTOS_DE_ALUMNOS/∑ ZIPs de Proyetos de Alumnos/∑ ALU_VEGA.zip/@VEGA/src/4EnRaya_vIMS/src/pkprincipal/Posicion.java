package pkprincipal;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

public class Posicion
{
	int x;
	int y;
	static int COLOR_SINCOLOR = 0;
	static int COLOR_ROJO = 1;
	static int COLOR_AZUL = 2;

	private int micolor;
	private BufferedImage myPicture;

	public Posicion(int x, int y, int micolor)
	{
		super();
		this.x = x;
		this.y = y;

		this.micolor = micolor;

		if (micolor == COLOR_AZUL)
		{
			try
			{
				File elficherodefichaazul = (new File("FichaAzul.png"));
				myPicture = ImageIO.read(elficherodefichaazul);
			} catch (IOException e)
			{
				e.printStackTrace();
			}
		}

	}

	public int getX()
	{
		return x;
	}

	public void setX(int x)
	{
		this.x = x;
	}

	public int getY()
	{
		return y;
	}

	public void setY(int y)
	{
		this.y = y;
	}

	public int getMicolor()
	{
		return micolor;
	}

	public void setMicolor(int micolor)
	{
		this.micolor = micolor;
	}

}
