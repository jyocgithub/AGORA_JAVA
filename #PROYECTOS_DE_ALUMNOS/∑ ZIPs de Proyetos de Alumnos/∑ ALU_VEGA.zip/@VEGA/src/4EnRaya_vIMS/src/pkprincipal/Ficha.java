package pkprincipal;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

public class Ficha
{
	static int COLOR_SINCOLOR = 0;
	static int COLOR_ROJO = 1;
	static int COLOR_AZUL = 2;

	private int micolor;
	private BufferedImage myPicture;

	public Ficha(int micolor)
	{
		this.micolor = micolor;

		if (micolor == COLOR_AZUL)
		{
			try
			{
				File elficherodefichaazul = (new File("FichaAzul.png"));
				myPicture = ImageIO.read(elficherodefichaazul);
			} catch (IOException e)
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

	}

	public int getMicolor()
	{
		return micolor;
	}

	public void setMicolor(int micolor)
	{
		this.micolor = micolor;
	}

	public BufferedImage getMyPicture()
	{
		return myPicture;
	}

	public void setMyPicture(BufferedImage myPicture)
	{
		this.myPicture = myPicture;
	}

}
