package servidor_http_ims;

import java.awt.Image;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

public class Pruebas {

	public static void main(String[] args) throws IOException {
		File f = new File(".", "Pirata.png");

		Image originalImage = ImageIO.read(f);
		Image image = null;
		try {
			URL url = new URL("http://www.mkyong.com/image/mypic.jpg");
			image = ImageIO.read(url);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}
