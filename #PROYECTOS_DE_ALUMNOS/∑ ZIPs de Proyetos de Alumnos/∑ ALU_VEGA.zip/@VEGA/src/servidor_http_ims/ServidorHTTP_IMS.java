package servidor_http_ims;

import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.URL;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.imageio.ImageIO;

public class ServidorHTTP_IMS {

	static final String Directorioraizdepaginas = ".";

	public static void main(String[] args) {
		int puerto = 20001;
		ServerSocket ss;
		Socket socket;

		try {
			ss = new ServerSocket(puerto);
			System.out.println("SERVIDOR CREADO ===========");
			while (true) {
				System.out.println("-- Esperando llamadas desde navegador por puerto:" + puerto);
				socket = ss.accept();
				System.out.println("-- Llamada recibida");
				HiloDelServidor hds = new HiloDelServidor(socket);
				Thread t = new Thread(hds);
				t.start();
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}

class HiloDelServidor implements Runnable {
	OutputStream escritor;
	BufferedReader lector;
	Socket socket;
	ArrayList<String> lineasDePeticion;
	File f;
	final int TCONTENIDO_HTML = 1, TCONTENIDO_JPG = 2, TCONTENIDO_PNG = 3, TCONTENIDO_DESCONOCIDO = 99;

	public HiloDelServidor(Socket socket) {
		super();
		this.socket = socket;
		lineasDePeticion = new ArrayList<>();
		try {
			escritor = socket.getOutputStream();
			lector = new BufferedReader(new InputStreamReader(socket.getInputStream()));
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	@Override
	public void run() {
		String peticion = "";
		String peticion2 = "";
		System.out.println("En el hilo servidor");
		URL unaurl = null;
		String respuestaHttp = "";
		int tipopeticion = 0; // 1.get 2.post 0.desconocida
		try {
			String linea;
			while (!(linea = lector.readLine()).isEmpty()) {
				lineasDePeticion.add(linea);
			}

			String linea1 = lineasDePeticion.get(0);
			if (linea1.toUpperCase().startsWith("GET")) {
				tipopeticion = 1;
			} else if (linea1.toUpperCase().startsWith("POST")) {
				tipopeticion = 2;
			}

			if (tipopeticion == 1) { // para simplificar, solo procesamos los GET
				int pos1 = linea1.indexOf("/");
				int pos2 = linea1.indexOf(" ", pos1);
				String ficheropedido = linea1.substring(pos1 + 1, pos2);
				System.out.println("He recibido la peticion: " + linea1);

				// EJEMPLO DE ELEMENTROS DE LA CABECERA DE LA RESPUESTA AL NAVEGADOR
				// "HTTP/1.1 200 OK\r\n"
				// "Connection: close\r\n"
				// "Server: ejercicios.JYOC.pruebasserver \r\n"
				// "Content-type: text/html charset=utf-8"
				// "\r\n"

				int tipocontenido = TCONTENIDO_DESCONOCIDO;
				if ((ficheropedido.toUpperCase().endsWith("HTML")) || (ficheropedido.toUpperCase().endsWith("HTM"))) {
					tipocontenido = TCONTENIDO_HTML;
				} else if (ficheropedido.toUpperCase().endsWith("JPG"))
					tipocontenido = TCONTENIDO_JPG;
				else if (ficheropedido.toUpperCase().endsWith("PNG")) tipocontenido = TCONTENIDO_PNG;

				if (tipocontenido == TCONTENIDO_DESCONOCIDO) { // contenido solicitido de tipo no controlado
					respuestaHttp = "HTTP/1.0 415 Unsupported Media Type\r\n\r\n FORMATO NO SOPORTADO";
					escritor.write(respuestaHttp.getBytes("UTF-8"));

				} else { // contenido solicitado de tipo conocido

					File f = new File(ServidorHTTP_IMS.Directorioraizdepaginas, ficheropedido);
					if (f.exists() == false) { // fichero solicitado no existe
						respuestaHttp = "HTTP/1.0 404 Not Found\r\n\r\n El Recurso soliticado no existe !!!!";
						escritor.write(respuestaHttp.getBytes("UTF-8"));
					} else {
						if (tipocontenido == TCONTENIDO_HTML) {
							respuestaHttp = "HTTP/1.1 200 OK\\r\\nContent-type: text/html charset=utf-8\r\n\r\n";
							BufferedReader bfdefich = new BufferedReader(new FileReader(f));
							String linfich = bfdefich.readLine();
							while (linfich != null) {
								respuestaHttp += linfich;
								linfich = bfdefich.readLine();
							}
							bfdefich.close();
							escritor.write(respuestaHttp.getBytes("UTF-8"));
						}
						if (tipocontenido == TCONTENIDO_PNG || tipocontenido == TCONTENIDO_JPG) {
							BufferedImage originalImage = ImageIO.read(f);
							byte[] imagenInByte;
							ByteArrayOutputStream baosDeImagen = new ByteArrayOutputStream();
							if (tipocontenido == TCONTENIDO_PNG) {
								ImageIO.write(originalImage, "png", baosDeImagen);
								respuestaHttp = "HTTP/1.1 200 OK\r\nContent-type: image/png\r\n\r\n";
							}
							if (tipocontenido == TCONTENIDO_JPG) {
								ImageIO.write(originalImage, "jpg", baosDeImagen);
								respuestaHttp = "HTTP/1.1 200 OK\r\nContent-type: image/jpg\r\n\r\n";
							}
							baosDeImagen.flush();
							imagenInByte = baosDeImagen.toByteArray();
							baosDeImagen.close();
							escritor.write(respuestaHttp.getBytes("UTF-8"));
							escritor.write(imagenInByte);
						}
					}
				}
			} else { // la peticion no es GET, no la procesamos
				respuestaHttp = "HTTP/1.0 400 Bad Request\r\n\r\n NO ENTIENDO LA PETICION SI NO ES GET :-) ";
				escritor.write(respuestaHttp.getBytes("UTF-8"));
			}
			System.out.println("__DEVUELVO: " + respuestaHttp);
		} catch (IOException e) { // error al procesar los streams o ficheros pedidos
			e.printStackTrace();
		} finally {
			try {
				if (escritor != null) escritor.close();
				if (lector != null) lector.close();
			} catch (IOException ex) { // no se pudieron cerrar los streams
				Logger.getLogger(this.getClass().getName()).log(Level.SEVERE, null, ex);
			}
		}
	}

	// public byte[] unirDosArraysBytes(byte[] a, byte[] b) {
	// int aLen = a.length;
	// int bLen = b.length;
	// byte[] c = new byte[aLen + bLen];
	// System.arraycopy(a, 0, c, 0, aLen);
	// System.arraycopy(b, 0, c, aLen, bLen);
	// return c;
	// }
}
