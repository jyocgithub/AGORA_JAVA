package hilosSinc;

import java.util.Random;

public class HilosSincronizados
{

	public static void main(String[] args)
	{

		// creo un objeto de BufferSync, que compartiran todos los objetos
		BufferSinc b = new BufferSinc();

		// creo un objeto de la otra clase
		HebraConRunnableSinc objetoHCR = new HebraConRunnableSinc("Eva", b);
		HebraConRunnableSinc objetoHCR2 = new HebraConRunnableSinc("Paz", b);
		HebraConRunnableSinc objetoHCR3 = new HebraConRunnableSinc("Maria", b);

		// Creo un hilo con el objeto de la otra clase
		Thread objetoThread = new Thread(objetoHCR);
		Thread objetoThread2 = new Thread(objetoHCR2);
		Thread objetoThread3 = new Thread(objetoHCR3);

		// arranco el hilo creado
		// CUIDADO, no es objetoThread.run(), pues start() ya inicia el método run()
		objetoThread.start();
		objetoThread2.start();
		objetoThread3.start();

		try
		{
			objetoThread.join();
			objetoThread2.join();
			objetoThread3.join();
		} catch (InterruptedException e)
		{
			e.printStackTrace();
		}

		System.out.println("FINAL:    " + b.getValor());
	}

}

class HebraConRunnableSinc implements Runnable
{
	String nombre;
	BufferSinc b;

	public HebraConRunnableSinc(String n, BufferSinc b)
	{
		nombre = n;
		this.b = b;
	}

	// tiene un método run que será lo que se ejecute al iniciar el hilo con start() desde fuera
	@Override
	public void run()
	{
		for (int i = 0; i < 10; i++)
		{
			BufferSinc.espera(50);
			b.sumarValor();
			System.out.println("Soy " + nombre + ":" + b.getValor());

		}
	}
}

class BufferSinc
{
	private int valor = 0;

	public synchronized void sumarValor()
	{
		valor++;
	}

	public int getValor()
	{
		return valor;
	}

	static void espera(int tiempo)
	{
		try
		{
			Thread.sleep(new Random().nextInt(100));
		} catch (InterruptedException e)
		{
		}
	}
}
