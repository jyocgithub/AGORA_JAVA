package ALVARO_fichas;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.sql.*;
import java.util.ArrayList;

public class Main {
    static ArrayList<Ficha> arrayFichas = new ArrayList<>();

    public static void main(String[] args) throws Exception {
        borrarTablas();
        trocearFichero();
        guardarArrayEnBBDD();
    }

    public static void trocearFichero() throws IOException {

        int c = 0;

        FileReader fr = new FileReader("./AG__ALUMNOS_EJERCICIOS/src/ALVARO_fichas/fichas.csv");
        BufferedReader br = new BufferedReader(fr);
        StringBuilder todoBuilder = new StringBuilder();
        try {
            char algo = (char) br.read();
            while (algo != 65535) {
                todoBuilder.append(algo);
                algo = (char) br.read();
            }
        } catch (Exception e) {
            System.out.println(" ----------- FIN DE FICHERO");
        }
        br.close();

        String todo = todoBuilder.toString();
        todo = todo.replace("\"", "");
        String[] listafichas = todo.split("@@@");

        c = 0;
        for (String cadaficha : listafichas) {
            if (c == 1000) break;
            String[] trozos = cadaficha.split(";");

            if (trozos.length == 6) {
                String index = limpiar(trozos[0]);
                String ici = limpiar(trozos[1]);
                String EC = limpiar(trozos[2]);
                String CAS = limpiar(trozos[3]);
                String hClass = trozos[4];
                String hSC = trozos[5];

                String[] trozosClass = hClass.split("\\n");
                String[] trozoshache = hSC.split("\\n");

                Ficha f = new Ficha(index, ici, EC, CAS, trozosClass, trozoshache);

                arrayFichas.add(f);

                System.out.println(f);
            }
        }
    }

    public static void guardarArrayEnBBDD() throws IOException, SQLException {
        PreparedStatement instruccion, instruccion2, instruccion3;

        int c = 0;
        // conexion a la bbdd
        Connection miConexion = DriverManager.getConnection("jdbc:mysql://localhost:3306/ALVARO_FICHAS", "root", "root");
        miConexion.setAutoCommit(false);  // para tratamiento por transacciones

        for (Ficha ficha : arrayFichas) {
            try {
                System.out.println("Guardando el registro " + c++);
                instruccion = miConexion.prepareStatement("INSERT into fichas values (?,?,?,?)");
                instruccion.setString(1, ficha.getIndex());
                instruccion.setString(2, ficha.getInternationalChemicalIdentification());
                instruccion.setString(3, ficha.getEC());
                instruccion.setString(4, ficha.getCAS());
                instruccion.executeUpdate();
            } catch (SQLIntegrityConstraintViolationException e) {
                System.out.println("**************************** CUIDADO, clave de FICHA duplicado : " + ficha.getIndex() + "no se almacena el duplicado");
                miConexion.rollback();
                continue;

            } catch (Exception e) {
                System.out.println("******************************************************** error desconocido en FICHA error desconocido en FICHA" + ficha.getIndex());
                miConexion.rollback();
                continue;
            }

            try {
                for (String cadaclase : ficha.getHazardClass()) {
                    if (cadaclase.isEmpty()) {
                        System.out.println("**************************** AVISO: clave de CLASE vacia en ficha " + ficha.getIndex());
                    } else {
                        instruccion2 = miConexion.prepareStatement("INSERT into fichas_clases values (?,?)");
                        instruccion2.setString(1, ficha.getIndex());
                        instruccion2.setString(2, cadaclase);
                        instruccion2.executeUpdate();
                    }
                }

            } catch (SQLIntegrityConstraintViolationException e) {
                System.out.println("**************************** clave de CLASS duplicado en ficha " + ficha.getIndex() + ", no se almacena la repeticion");
//                miConexion.rollback();
                continue;

            } catch (Exception e) {
                System.out.println("******************************************************** error desconocido en FICHA error desconocido en CLASS de la ficha " + ficha.getIndex());
                miConexion.rollback();
                continue;
            }

            try {
                for (String cadahache : ficha.getHazardStatCode()) {
                    if (cadahache.isEmpty()) {
                        System.out.println("**************************** AVISO: clave de HACHE vacia en ficha " + ficha.getIndex());
                    } else {
                        instruccion2 = miConexion.prepareStatement("INSERT into fichas_haches values (?,?,?)");
                        instruccion2.setString(1, ficha.getIndex());
                        instruccion2.setString(2, cadahache);
                        instruccion2.setString(3, "0");
                        instruccion2.executeUpdate();
                    }
                }
            } catch (SQLIntegrityConstraintViolationException e) {
                System.out.println("**************************** clave de HACHE duplicada en ficha " + ficha.getIndex() + ", no se almacena la repeticion");
//                miConexion.rollback();
                continue;
            } catch (Exception e) {
                System.out.println("******************************************************** error desconocido en FICHA error desconocido en HACHE de la ficha " + ficha.getIndex());
                miConexion.rollback();
                continue;
            }
            miConexion.commit();
        }
        miConexion.close();
    }

    public static String limpiar(String algo) {
        algo = algo.replace("\\r", "");
        algo = algo.replace("\\n", "");
        algo = algo.replace("\"", "");
        return algo;
    }

    public static void borrarTablas() throws SQLException {
        Connection miConexion = DriverManager.getConnection("jdbc:mysql://localhost:3306/ALVARO_FICHAS", "root", "root");
        Statement instruccion1 = miConexion.createStatement();
        instruccion1.executeUpdate("TRUNCATE TABLE FICHAS");
        instruccion1.executeUpdate("TRUNCATE TABLE FICHAS_CLASES");
        instruccion1.executeUpdate("TRUNCATE TABLE FICHAS_HACHES");
    }

}
