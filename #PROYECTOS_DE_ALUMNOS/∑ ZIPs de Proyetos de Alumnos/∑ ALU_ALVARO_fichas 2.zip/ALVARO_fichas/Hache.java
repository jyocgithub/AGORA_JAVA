package ALVARO_fichas;

public class Hache {

    String idHache;
    String concentracion;
    String descripcion;

    public Hache(String idHache, String concentracion, String descripcion) {
        this.idHache = idHache;
        this.concentracion = concentracion;
        this.descripcion = descripcion;
    }

    public String getIdHache() {
        return idHache;
    }

    public void setIdHache(String idHache) {
        this.idHache = idHache;
    }

    public String getConcentracion() {
        return concentracion;
    }

    public void setConcentracion(String concentracion) {
        this.concentracion = concentracion;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }
}
