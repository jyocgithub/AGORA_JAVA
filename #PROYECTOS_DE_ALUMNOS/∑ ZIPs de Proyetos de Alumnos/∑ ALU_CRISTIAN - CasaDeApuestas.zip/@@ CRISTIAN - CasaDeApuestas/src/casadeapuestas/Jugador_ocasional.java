/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package casadeapuestas;

import java.util.Date;

/**
 *
 * @author cristiandiaz
 */
public class Jugador_ocasional extends Jugador {
    
    private String tarjeta;
    
    public Jugador_ocasional(String nif, String nombre, String apellidos, String fechaNacimiento,String tarjeta) {
        super(nif, nombre, apellidos, fechaNacimiento);
        this.tarjeta = tarjeta;
    }

    public String getTarjeta() {
        return tarjeta;
    }

    public void setTarjeta(String tarjeta) {
        this.tarjeta = tarjeta;
    }

    @Override
    public double retirarBeneficios() {
        double w = 0;
        if (this.getSaldo()>0){
            w = this.getSaldo();
            this.setSaldo(0);
            
        }
        return w;
    }
    
}
