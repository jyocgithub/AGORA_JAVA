/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package casadeapuestas;

/**
 *
 * @author cristiandiaz
 */
public class Carta {
    
    // Crear variables
    private int palo;
    private int figura;

    /**
     * Metodo constructor de una carta
     *
     * @param palo : palo de la carta
     * @param figura : figura de la carta
     */
    public Carta(int palo, int figura) {
        this.palo = palo;
        this.figura = figura;

    }

    
    /**
     * Metodo getter del atributo palo
     *
     * @return String : palo de la carta
     */
    public int getPalo() {
        return palo;
    }

    /**
     * Metodo setter del atributo palo
     *
     * @param palo : String palo de la carta
     */
    public void setPalo(int palo) {
        this.palo = palo;
    }

    /**
     * Metodo getter del atributo figura
     *
     * @return String : figura de la carta
     */
    public int getFigura() {
        return figura;
    }

    /**
     * Metodo setter del atributo figura
     *
     * @param figura : String figura de la carta
     */
    public void setFigura(int figura) {
        this.figura = figura;
    }

    /**
     * Metodo que devuelve la informacion de una carta, en formato de letra, por
     * ejempo, "Carta: Sota de Oros"
     *
     * @return String : informacion de la carta actual
     */
    @Override
    public String toString() {
        String ppalo = "";
        String pfigura = "";
        switch (palo) {
            case 0:
                ppalo = "Oros";
                break;
            case 1:
                ppalo = "Copas";
                break;
            case 2:
                ppalo = "Espadas";
                break;
            case 3:
                ppalo = "Bastos";
                break;
            default:
                ppalo = "PALO ERRONEO";
                break;

        }
        switch (figura) {
            case 0:
                pfigura = "As";
                break;
            case 1:
                pfigura = "dos";
                break;
            case 2:
                pfigura = "tres";
                break;
            case 3:
                pfigura = "cuatro";
                break;
            case 4:
                pfigura = "cinco";
                break;
            case 5:
                pfigura = "seis";
                break;
            case 6:
                pfigura = "siete";
                break;
            case 7:
                pfigura = "Sota";
                break;
            case 8:
                pfigura = "Caballo";
                break;
            case 9:
                pfigura = "Rey";
                break;
            default:
                pfigura = "PALO ERRONEO";
                break;

        }

        return "Carta: " + pfigura + " de " + ppalo;
    }
    
}
