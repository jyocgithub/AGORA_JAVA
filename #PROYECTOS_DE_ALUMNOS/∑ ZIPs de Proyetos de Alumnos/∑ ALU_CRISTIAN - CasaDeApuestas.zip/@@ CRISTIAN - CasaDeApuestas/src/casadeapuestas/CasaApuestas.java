/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package casadeapuestas;

import java.util.HashMap;
import java.util.Map;

/**
 *
 * @author cristiandiaz
 */
public class CasaApuestas {
    
    private Jugador_registrado jug;
    private Apuesta unaApuesta;
    private double saldo;
    
    Map<String,Jugador_registrado> miMapa;

    public CasaApuestas(Jugador_registrado jug, Apuesta unaApuesta, double saldo) {
        this.jug = jug;
        this.unaApuesta = unaApuesta;
        this.saldo = saldo;
        miMapa = new HashMap<>();
    }

    public Jugador_registrado getJug() {
        return jug;
    }

    public void setJug(Jugador_registrado jug) {
        this.jug = jug;
    }

    public Apuesta getUnaApuesta() {
        return unaApuesta;
    }

    public void setUnaApuesta(Apuesta unaApuesta) {
        this.unaApuesta = unaApuesta;
    }

    public double getSaldo() {
        return saldo;
    }

    public void setSaldo(double saldo) {
        this.saldo = saldo;
    }
    
    
    public void altaJugador(Jugador_registrado jr){
        miMapa.put(jr.getNif(), jr);
        
    }
    public double bajaJugador(String nif){
       double beneficios = -1;
        if(miMapa.containsKey(nif)){
           
            Jugador x = miMapa.get(nif);
            beneficios = x.retirarBeneficios();
            miMapa.remove(nif);
        }
        // -1 El jugador no existe
        // 0 El jugador no tiene dinero
        // cualquier otro es el dinero que devuelve. 
        return beneficios;
    }
            
    
    
    
}
