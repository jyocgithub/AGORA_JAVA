/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package casadeapuestas;

/**
 *
 * @author cristiandiaz
 */
public abstract class Jugador {

    private String nif;
    private String nombre;
    private String apellidos;
    private String fechaNacimiento;
    private int saldo = 50;

    public Jugador(String nif, String nombre, String apellidos, String fechaNacimiento) {
        this.nif = nif;
        this.nombre = nombre;
        this.apellidos = apellidos;
        this.fechaNacimiento = fechaNacimiento;
        
    }

    public String getNif() {
        return nif;
    }

    public void setNif(String nif) {
        this.nif = nif;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellidos() {
        return apellidos;
    }

    public void setApellidos(String apellidos) {
        this.apellidos = apellidos;
    }

    public String getFechaNacimiento() {
        return fechaNacimiento;
    }

    public void setFechaNacimiento(String fechaNacimiento) {
        this.fechaNacimiento = fechaNacimiento;
    }

    public double getSaldo() {
        return saldo;
    }

    public void setSaldo(int saldo) {
        this.saldo = saldo;
    }

    abstract public double retirarBeneficios();

    public void aumentarSaldo(int saldo) {

        // this.setSaldo(saldo + this.getSaldo());
        this.saldo = this.saldo + saldo;
    }

}
