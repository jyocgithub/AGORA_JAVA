/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package casadeapuestas;

import java.util.ArrayList;

/**
 *
 * @author cristiandiaz
 */
public class Baraja {

    // Atributos.
    private ArrayList<Carta> baraja = new ArrayList<Carta>();
    private ArrayList<Carta> mano = new ArrayList<>();

    /**
     * Metodo constructor Baraja. Su objetivo es crear una baraja de 40 cartas.
     * Un primer bucle representa el palo de la carta por eso es de tamaño 4. El
     * bucle de tamaño 10 es para la figura. c es atributo de tipo Carta que
     * contiene un palo y una figura.
     *
     */
    public Baraja() {

        for (int palo = 0; palo < 4; palo++) {
            for (int figura = 0; figura < 10; figura++) {
                Carta c = new Carta(palo, figura);
                baraja.add(c);
            }
        }

    }

    /**
     * Metodo que contiene un ArrayList de tipo Carta llamado crearMano. Su
     * objetivo es crear un ArrayList de tamaño 5 que seran las cartas de la
     * mano. Para ello tengo un atributo para el palo y otro para la figura.
     * Cada uno de ellos se toma de forma aleatoria. Compruebo que no se
     * obtienen 2 cartas iguales.
     *
     * @return ArrayList: un arrayList de tipo Carta con las cartas de la mano
     */
    public ArrayList<Carta> crearMano() {
        mano.clear(); // Limpiar mano para cuando se llame al metodo con las apuestas.
        int i = 0;
        while (i < 5) {

            int p = (int) (Math.random() * 4); // Palos aleatorios entre 0 y 4
            int f = (int) (Math.random() * 10); // Figuras aleatorios entre 0 y 10
            Carta h = new Carta(p, f);

            if (!mano.contains(h)) {    // Comprobar que la carta no se va a repetir
                mano.add(h);
                i++;
            }

        }

        return mano;
    }

    /**
     * Metodo que contiene un bucle que recorre el ArrayMano y pinta cada una de
     * las posiciones
     *
     */
    public void pintarmano() {
        for (int i = 0; i < mano.size(); i++) {
            System.out.println(mano.get(i));
        }

    }

}