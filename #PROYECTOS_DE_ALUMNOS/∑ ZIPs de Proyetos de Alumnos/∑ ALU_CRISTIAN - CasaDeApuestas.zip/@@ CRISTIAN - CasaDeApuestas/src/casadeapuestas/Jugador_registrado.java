/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package casadeapuestas;

import java.io.IOException;
import java.util.Date;

/**
 *
 * @author cristiandiaz
 */
public class Jugador_registrado extends Jugador{
    
    private String cuentaBancaria;
    private String contraseña;
    private String fechaRegistro;
    
    public Jugador_registrado(String nif, String nombre, String apellidos, String fechaNacimiento,String cuentaBancaria, String contraseña,String fechaRegistro) {
        super(nif, nombre, apellidos, fechaNacimiento);
        this.cuentaBancaria = cuentaBancaria;
        this.contraseña = contraseña;
        this.fechaRegistro = fechaRegistro;
    }

    public String getCuentaBancaria() {
        return cuentaBancaria;
    }

    public void setCuentaBancaria(String cuentaBancaria) {
        this.cuentaBancaria = cuentaBancaria;
    }

    public String getContraseña() {
        return contraseña;
    }

    public void setContraseña(String contraseña) {
        this.contraseña = contraseña;
    }

    public String getFechaRegistro() {
        return fechaRegistro;
    }

    public void setFechaRegistro(String fechaRegistro) {
        this.fechaRegistro = fechaRegistro;
    }

    @Override
    public double retirarBeneficios() {
        double w = 0;
        if (this.getSaldo()>0){
            w = this.getSaldo();
            this.setSaldo(0);
            
        }
        return w;
    }
    
    
    
}
