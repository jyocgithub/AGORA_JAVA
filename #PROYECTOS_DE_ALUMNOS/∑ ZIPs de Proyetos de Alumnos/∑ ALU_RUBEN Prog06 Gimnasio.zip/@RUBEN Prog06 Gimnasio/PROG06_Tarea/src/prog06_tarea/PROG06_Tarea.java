package prog06_tarea;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

public class PROG06_Tarea {
    static Scanner sc = new Scanner(System.in);
    static Gimnasio gimnasio = new Gimnasio();

    public static void main(String[] args) {


        boolean salir = false;

        while (!salir) {
            System.out.println("Menú:");
            System.out.println("1. Nueva persona");
            System.out.println("2. Buscar persona");
            System.out.println("3. Modificar código taquilla");
            System.out.println("4. Listar personas");
            System.out.println("5. Eliminar persona");
            System.out.println("6. Salir");
            System.out.print("Elige una opción: ");

            int opcion =         Integer.parseInt(sc.nextLine());
            switch (opcion) {
                case 1:
                    try {
                        nuevapersona();
                    } catch (Exception e) {
                        System.out.println("Debe repetir la peticion de alta");
                    }
                    // Acción para "Nueva persona"
                    break;
                case 2:
                    buscarpersona();
                    // Acción para "Buscar persona"
                    break;
                case 3:
                    modificarCodigo();
                    // Acción para "Modificar código taquilla"
                    break;
                case 4:
                    listar();
                    // Acción para "Listar personas"
                    break;

                case 5:
                    eliminar();
                    // Acción para "Eliminar persona"
                    break;
                case 6:
                    salir = true;
                    break;
                default:
                    System.out.println("Opción inválida");
                    break;
            }
        }
        sc.close();
    }

    public static void eliminar()  {
        String  dni;
        boolean repetir = true;
        do {
            System.out.println("Dime el dni:");
            dni = sc.nextLine();
            if (validarDni(dni)) {
                repetir = false;
            } else {
                System.out.println("Dni erroneo, repite:");
            }
        } while (repetir);

        boolean vale = gimnasio.eliminaPersona(dni);
        if(vale){
            System.out.println("Persona eliminada");
        }else{
            System.out.println("No existe Persona con el DNI introducido");
        }

    }

    public static void listar()  {
        gimnasio.listaPersonas();
    }

    public static void modificarCodigo()  {
        String  dni, codigoTaquilla;
        boolean repetir = true;
        do {
            System.out.println("Dime el dni:");
            dni = sc.nextLine();
            if (validarDni(dni)) {
                repetir = false;
            } else {
                System.out.println("Dni erroneo, repite:");
            }
        } while (repetir);

        repetir = true;
        do {
            System.out.println("Dime el codigo de taquilla:");
            codigoTaquilla = sc.nextLine();
            if (validarCodigo(codigoTaquilla)) {
                repetir = false;
            } else {
                System.out.println("Codigo erroneo");
            }
        } while (repetir);

        boolean vale = gimnasio.actualizaTaquilla(dni,codigoTaquilla);
        if(vale){
            System.out.println("Codigo modificado");
        }else{
            System.out.println("No existe Persona con el DNI introducido");
        }
    }



    public static void buscarpersona()  {
        String  dni;
        boolean repetir = true;
        do {
            System.out.println("Dime el dni:");
            dni = sc.nextLine();
            if (validarDni(dni)) {
                repetir = false;
            } else {
                System.out.println("Dni erroneo, repite:");
            }
        } while (repetir);

        Persona persona = gimnasio.devuelvePersona(dni);
        if(persona == null){
            System.out.println("No existe Persona con el DNI introducido");
        }else{
            System.out.println(persona);
        }
    }


    public static void nuevapersona() throws Exception {
        String nombre, dni, fecha1,codigoTaquilla;
        int peso, altura ;
        LocalDate fecha;
        char sexo;
        boolean repetir;

        repetir = true;
        do {
            System.out.println("Dime el nombre de la persona:");
            nombre = sc.nextLine();
            if (nombre.length() < 20) {
                repetir = false;
            } else {
                System.out.println("nombre muy largo");
            }
        } while (repetir);

        repetir = true;
        do {
            System.out.println("Dime el dni:");
            dni = sc.nextLine();
            if (validarDni(dni)) {
                repetir = false;
            } else {
                System.out.println("Dni erroneo");
            }
        } while (repetir);

        repetir = true;
        do {
            System.out.println("Dime fecha de nacimiento (dd/mm/aaaa):");
            fecha1 = sc.nextLine();
            fecha = hacerlocaldate(fecha1);
            if (fecha != null) {
                repetir = false;
            } else {
                System.out.println("fecha erronea");
            }
        } while (repetir);

        repetir = true;
        do {
            System.out.println("Dime el sexo (H/M) :");
            sexo = sc.nextLine().charAt(0);
            fecha = hacerlocaldate(fecha1);
            if (sexo == 'H' || sexo == 'M') {
                repetir = false;
            } else {
                System.out.println("sexo erroneo");
            }
        } while (repetir);


        System.out.println("Dime el peso:");
        peso = Integer.parseInt(sc.nextLine());


        System.out.println("Dime al altura:");
        altura = Integer.parseInt(sc.nextLine());


        repetir = true;
        do {
        System.out.println("Dime el codigo de taquilla:");
            codigoTaquilla = sc.nextLine();
            if (validarCodigo(codigoTaquilla)) {
                repetir = false;
            } else {
                System.out.println("Codigo erroneo");
            }
        } while (repetir);

        boolean vale = gimnasio.anadePersona(nombre, dni, fecha, sexo, peso, altura, codigoTaquilla);
        if(! vale){
        throw new Exception("no caben mas en el gimnasio");
        }

    }


    public static boolean validarDni(String dni) {
        boolean vale = dni.matches("[0-9]{8}[A-Za-z]");
        return vale;
    }

    public static boolean validarCodigo(String codigo) {
        boolean vale = codigo.matches("[A-Za-z]{2}[0-9]{3}");
        return vale;
    }

    public static LocalDate hacerlocaldate(String fecha) {
        try {
            LocalDate fecha1 = LocalDate.parse(fecha, DateTimeFormatter.ofPattern("dd/MM/yyyy"));
            return fecha1;
        } catch (Exception e) {
            return null;
        }
    }

}
