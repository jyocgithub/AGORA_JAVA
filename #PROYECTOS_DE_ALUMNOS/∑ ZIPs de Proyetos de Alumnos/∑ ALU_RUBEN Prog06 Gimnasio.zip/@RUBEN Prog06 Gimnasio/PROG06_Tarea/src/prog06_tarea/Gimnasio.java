package prog06_tarea;

import java.time.LocalDate;

/**
 *
 * @author User
 */
public class Gimnasio {

    private Persona[] personas;
    private static int numPersonas = 0;
    
    public Gimnasio() {
        personas = new Persona[70];
    }
    
    public boolean buscaPersona(String DNI) {
        for (int i = 0; i < numPersonas; i++) {
            if (personas[i].getDni().equals(DNI)) {
                return true;
            }
        }
        return false;
    }
    
    public Persona devuelvePersona(String DNI) {
        for (int i = 0; i < numPersonas; i++) {
            if (personas[i].getDni().equals(DNI)) {
                return personas[i];
            }
        }
        return null;
    }
    
    public String datosPersona(String DNI) {
        for (int i = 0; i < numPersonas; i++) {
            if (personas[i].getDni().equals(DNI)) {
                return personas[i].toString();
            }
        }
        return null;
    }
    
    public boolean anadePersona(String nombre, String dni, LocalDate fecha, char sexo, double peso, int altura, String codigoTaquilla) {
       if (numPersonas < 70) {
            Persona persona = new Persona( nombre,  dni,  fecha,  sexo,  peso,  altura,  codigoTaquilla);
            personas[numPersonas] = persona;
            numPersonas++;
            return true;
       }
       return false;
    }
    
    public void listaPersonas() {
        for (int i = 0; i < numPersonas; i++) {
            System.out.println(personas[i]);
        }
    }
    
    public boolean actualizaTaquilla(String DNI, String codigoTaquilla) {
        for (int i = 0; i < numPersonas; i++) {
            if (personas[i].getDni().equals(DNI)) {
                personas[i].setCodigoTaquilla(codigoTaquilla);
                return true;
            }
        }
        return false;
    }
    
    public boolean eliminaPersona(String DNI) {
        for (int i = 0; i < numPersonas; i++) {
            if (personas[i].getDni().equals(DNI)) {
                for (int j = i; j < numPersonas - 1; j++) {
                    personas[j] = personas[j + 1];
                }
                numPersonas--;
                return true;
            }
        }
        return false;
    }
}

