package prog06_tarea;


import java.time.LocalDate;
import java.time.Period;

/**
 * @author User
 */
public class Persona {
    public static final char SEXO_DEFECTO = 'H';

    private String nombre ="";
    private String dni;
    private LocalDate fecha;
    private char sexo = SEXO_DEFECTO;
    private double peso=0;
    private int altura=0;
    private String codigoTaquilla="";

    public Persona() {
    }

    public Persona(String nombre, LocalDate edad, char sexo) {
        this.nombre = nombre;
        this.fecha = edad;
        this.sexo = sexo;

    }

    public Persona(String nombre, String dni, LocalDate fecha, char sexo, double peso, int altura, String codigoTaquilla) {
        this.nombre = nombre;
        this.dni = dni;
        this.fecha = fecha;
        this.sexo = sexo;
        this.peso = peso;
        this.altura = altura;
        this.codigoTaquilla = codigoTaquilla;
    }

    public int calcularIMC() {
        final int PESOBAJO = -1;
        final int PESOIDEAL = 0;
        final int SOBREPESO = 1;
        double imc = peso / (altura * altura);
        if (imc < 20) {
            return PESOBAJO;
        } else if (imc >= 20 && imc <= 25) {
            return PESOIDEAL;
        } else {
            return SOBREPESO;
        }
    }

    private char comprobarsexo(char sexo) {
        if (sexo != 'H' && sexo != 'M') {
            return SEXO_DEFECTO;
        }
        return sexo;
    }

    public int getAnyos() {
        Period p =  Period.between(fecha, LocalDate.now());
        int anyos =  p.getYears();
        return anyos;
    }

    public boolean esMayorDeEdad() {
        return getAnyos() >= 18;
    }

    public String toString() {
        return "DNI: " + dni + ", Nombre: " + nombre + ", Edad: " + getAnyos() + ", Código de taquilla: " + codigoTaquilla;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDni() {
        return dni;
    }

    public void setDni(String dni) {
        this.dni = dni;
    }

    public LocalDate getFecha() {
        return fecha;
    }

    public void setFecha(LocalDate fecha) {
        this.fecha = fecha;
    }

    public char getSexo() {
        return sexo;
    }

    public void setSexo(char sexo) {
        this.sexo = sexo;
    }

    public double getPeso() {
        return peso;
    }

    public void setPeso(double peso) {
        this.peso = peso;
    }

    public int getAltura() {
        return altura;
    }

    public void setAltura(int altura) {
        this.altura = altura;
    }

    public String getCodigoTaquilla() {
        return codigoTaquilla;
    }

    public void setCodigoTaquilla(String codigoTaquilla) {
        this.codigoTaquilla = codigoTaquilla;
    }
}


  