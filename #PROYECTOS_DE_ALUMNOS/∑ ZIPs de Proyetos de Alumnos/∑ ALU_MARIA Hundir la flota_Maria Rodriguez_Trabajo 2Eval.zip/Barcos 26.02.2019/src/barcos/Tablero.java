/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package barcos;

import java.util.Random;
import java.util.Scanner;

/**
 *
 * @author mrs123456
 */
public class Tablero {
    
  /*en tablero recogeremos toda la informacion para consultar las partidas
 Jugadores, Ganador, Fecha y hora, Estado barcos maquina, Estado barcos jugador
 */
    
       //Creamos matriz para el trablero
    
    public final static int tamanioMaximo = 10;
    
          char[][] casillas = new char[tamanioMaximo][tamanioMaximo];
   Barco portaviones = new Barco();
          
 public void crearTableroJugador(){
 
     Scanner entrada = new Scanner (System.in);
       int fila,columna,orientacion;
    
        //Rellenar la matriz
        for(int x=0;x<10;x++){
            for(int y=0;y<10;y++){
                 
                    casillas[x][y] = '~';     
            }
        }
    //introducimos los barcos
    //Barco portaviones = new Barco();
    
    
    
        //introducimos portaviones
        
                //mostrar tablero
        System.out.println("\nTablero Jugador: \n");
        
        System.out.print("  0 1 2 3 4 5 6 7 8 9 \n");
            
        for(int x=0;x<10;x++){
            System.out.print(x+" ");
            for(int y=0;y<10;y++){
                System.out.print(casillas[x][y]+" ");
            }
            System.out.println("");
        }
        System.out.println("");
       
            
            System.out.println("Introduce la fila de cabecera del Portaviones: ");
       
            //introduzco la fila del portaviones
            portaviones.setFila(entrada.nextInt());
        
        System.out.println("Introduce la columna de cabecera");
        portaviones.setColumna(entrada.nextInt());
        
        
        //Si la fila esta entre 1 y 10 le digo que me inserte la columna 
        if ((portaviones.getFila()>=0 && portaviones.getFila()<=tamanioMaximo)&& (portaviones.getColumna()>=0 && portaviones.getColumna()<=tamanioMaximo)){
            
            System.out.println("vertical (1) u horizontal (0): ");   
            orientacion=entrada.nextInt(); 
            
            if(orientacion==1){
                portaviones.setOrientacion(Orientacion.VERTICAL);
            }else if (orientacion == 0){
                portaviones.setOrientacion(Orientacion.HORIZONTAL);
            }
            else{System.out.println("introduce una posicion correcta");}
        
        } else{ System.out.println("introduce valores correctos"); }
        
        
        if(portaviones.getOrientacion() == Orientacion.VERTICAL){
           for(int i=0;i<6;i++){casillas[portaviones.getFila()+i][portaviones.getColumna()]='p';}
        }else if(portaviones.getOrientacion() == Orientacion.HORIZONTAL){//6 porque son 6 casillas las que ocupa el portaaviones
            for(int i=0;i<6;i++){casillas[portaviones.getFila()][portaviones.getColumna()+i]='p';}  
        }

        
       
        
        //mostrar tablero
        System.out.println("\nTablero Jugador: \n");
        
        System.out.print("  0 1 2 3 4 5 6 7 8 9 \n");
            
        for(int x=0;x<10;x++){
            System.out.print(x+" ");
            for(int y=0;y<10;y++){
                System.out.print(casillas[x][y]+" ");
            }
            System.out.println("");
        }
        System.out.println("");
        
   
        //introducimos el buque
        Barco buque1 = new Barco(); 
        Barco buque2 = new Barco(); 
        Barco barco = new Barco(); //buque generico
        char buq='b';
        for(int buque=0;buque<2;buque++){
            
        
        
      System.out.println("Introduce la fila de cabecera del Buque "+ (buque+1) +": ");
        //introduzco la fila del portaviones
            barco.setFila(entrada.nextInt());
        
        System.out.println("Introduce la columna de cabecera");
        barco.setColumna(entrada.nextInt());
        
        
        //Si la fila esta entre 1 y 10 le digo que me inserte la columna 
        if ((barco.getFila()>=0 && barco.getFila()<=tamanioMaximo)&& (barco.getColumna()>=0 && barco.getColumna()<=tamanioMaximo)){
            
            System.out.println("vertical (1) u horizontal (0): ");   
            orientacion=entrada.nextInt(); 
            
            if(orientacion==1){
                barco.setOrientacion(Orientacion.VERTICAL);
            }else if (orientacion == 0){
                barco.setOrientacion(Orientacion.HORIZONTAL);
            }
            else{System.out.println("introduce una posicion correcta");}
        
        } else{ System.out.println("introduce valores correctos"); }
        
        
   //aqui comprobamos que no se crucen los barcos
   
   
   if (buque ==0){
       buq='b';
       
   }else if (buque==1){
       buq='c';
   }
   if (casillas[barco.getFila()][barco.getColumna()] == '~'){
        if(barco.getOrientacion() == Orientacion.VERTICAL){
           for(int i=0;i<4;i++){casillas[barco.getFila()+i][barco.getColumna()]=buq;}
        }else if(barco.getOrientacion() == Orientacion.HORIZONTAL){//4 porque son 4 casillas las que ocupa el buque
            for(int i=0;i<4;i++){casillas[barco.getFila()][barco.getColumna()+i]=buq;}  
       }
   }else if(casillas[barco.getFila()][barco.getColumna()]!='~'){
        
        System.out.println("se cruzan los barcos. Introduce de nuevo la posicion.");
        
        
    }
  
                //mostrar tablero
        System.out.println("\nTablero Jugador: \n");
        
        System.out.print("  0 1 2 3 4 5 6 7 8 9 \n");
            
        for(int x=0;x<10;x++){
            System.out.print(x+" ");
            for(int y=0;y<10;y++){
                System.out.print(casillas[x][y]+" ");
            }
            System.out.println("");
        }
        System.out.println("");  
 
        
        if(buque==0){
            
            buque1=barco;
        }else if (buque==1){
            buque2=barco;
        }
            
        }
        
 
        
 //introducimos el submarino
 
        Barco sub1 = new Barco(); 
        Barco sub2 = new Barco();
        Barco sub3 = new Barco();
        
        for(int submarino=0;submarino<3; submarino++){
        
              System.out.println("Introduce la fila de cabecera del Submarino "+(submarino+1)+": ");
        //introduzco la fila del portaviones
            barco.setFila(entrada.nextInt());
        
        System.out.println("Introduce la columna de cabecera");
        barco.setColumna(entrada.nextInt());
        
        
        //Si la fila esta entre 1 y 10 le digo que me inserte la columna 
        if ((barco.getFila()>=0 && barco.getFila()<=tamanioMaximo)&& (barco.getColumna()>=0 && barco.getColumna()<=tamanioMaximo)){
            
            System.out.println("vertical (1) u horizontal (0): ");   
            orientacion=entrada.nextInt(); 
            
            if(orientacion==1){
                barco.setOrientacion(Orientacion.VERTICAL);
            }else if (orientacion == 0){
                barco.setOrientacion(Orientacion.HORIZONTAL);
            }
            else{System.out.println("introduce una posicion correcta");}
        
        } else{ System.out.println("introduce valores correctos"); }
        
        
        
           if (submarino ==0){
       buq='d';
       
   }else if (submarino==1){
       buq='e';
   }else if (submarino==2){
       buq='f';
   }
        
        if(barco.getOrientacion() == Orientacion.VERTICAL){
           for(int i=0;i<2;i++){casillas[barco.getFila()+i][barco.getColumna()]= buq;}
        }else if(barco.getOrientacion() == Orientacion.HORIZONTAL){//2 porque son 2 casillas las que ocupa el buque
            for(int i=0;i<2;i++){casillas[barco.getFila()][barco.getColumna()+i]= buq;}  
        }

        //mostrar tablero
        System.out.println("\nTablero Jugador: \n");
        
        System.out.print("  0 1 2 3 4 5 6 7 8 9 \n");
            
        for(int x=0;x<10;x++){
            System.out.print(x+" ");
            for(int y=0;y<10;y++){
                System.out.print(casillas[x][y]+" ");
            }
            System.out.println("");
        }
        System.out.println("");  
        
                if(submarino==0){
            
            sub1=barco;
        }else if (submarino==1){
            sub2=barco;
        }else if(submarino ==2){
               sub3=barco; 
        }
        
        
        
        }
        
        
        //introducimos el pesquero
        
        Barco pes1 = new Barco(); 
        Barco pes2 = new Barco();
        Barco pes3 = new Barco();
        Barco pes4 = new Barco();
        for(int pesquero=0; pesquero<4; pesquero++){
        
              System.out.println("Introduce la fila de cabecera del Pesquero"+(pesquero+1)+": ");
        //introduzco la fila del portaviones
            barco.setFila(entrada.nextInt());
        
        System.out.println("Introduce la columna de cabecera");
        barco.setColumna(entrada.nextInt());
        
        
        //Si la fila esta entre 1 y 10 le digo que me inserte la columna 
        if ((barco.getFila()>=0 && barco.getFila()<=tamanioMaximo)&& (barco.getColumna()>=0 && barco.getColumna()<=tamanioMaximo)){
            
            System.out.println("vertical (1) u horizontal (0): ");   
            orientacion=entrada.nextInt(); 
            
            if(orientacion==1){
                barco.setOrientacion(Orientacion.VERTICAL);
            }else if (orientacion == 0){
                barco.setOrientacion(Orientacion.HORIZONTAL);
            }
            else{System.out.println("introduce una posicion correcta");}
        
        } else{ System.out.println("introduce valores correctos"); }
        
        
        
        
           if (pesquero ==0){
       buq='g';
       
   }else if (pesquero==1){
       buq='h';
   }else if (pesquero==2){
       buq='i';
   }else if (pesquero==3){
       buq='j';
   }
        
        if(barco.getOrientacion() == Orientacion.VERTICAL){
           for(int i=0;i<1;i++){casillas[barco.getFila()+i][barco.getColumna()]=buq;}
        }else if(barco.getOrientacion() == Orientacion.HORIZONTAL){//2 porque son 2 casillas las que ocupa el buque
            for(int i=0;i<1;i++){casillas[barco.getFila()][barco.getColumna()+i]=buq;}  
        }

        //mostrar tablero
        System.out.println("\nTablero Jugador: \n");
        
        System.out.print("  0 1 2 3 4 5 6 7 8 9 \n");
            
        for(int x=0;x<10;x++){
            System.out.print(x+" ");
            for(int y=0;y<10;y++){
                System.out.print(casillas[x][y]+" ");
            }
            System.out.println("");
        }
        System.out.println("");
        
        
        if(pesquero==0){
            
            pes1=barco;
        }else if (pesquero==1){
            pes2=barco;
        }else if(pesquero ==2){
           pes3=barco; 
        }else if(pesquero==3){
            pes4=barco;
        }
 }

 }


 
        
public boolean cabe(Barco barco){

     if(barco.getOrientacion()==Orientacion.VERTICAL){
        int tamanioTotal = barco.getColumna()+barco.getTamano();
        if(tamanioTotal>Tablero.tamanioMaximo){
            return false;
        }
        for(int i = 0; i < barco.getTamano();i++){
            if(
                casillas[barco.getFila()+i][barco.getColumna()]=='p' ||
                casillas[barco.getFila()+i][barco.getColumna()]=='q' ||
                casillas[barco.getFila()+i][barco.getColumna()]=='s' ||
                casillas[barco.getFila()+i][barco.getColumna()]=='b'
                ){
                return false;
            }
        }
        
     }
     else if(barco.getOrientacion()== Orientacion.HORIZONTAL){//mirarlo con la horizontal  
        int tamanioTotal=barco.getFila()+barco.getTamano();
        if(tamanioTotal>Tablero.tamanioMaximo){
            return false;
        }else if(tamanioTotal<Tablero.tamanioMaximo){
            return true;
        }
        for(int i = 0; i < barco.getTamano();i++){
            if(
                casillas[barco.getFila()][barco.getColumna()+i]=='p' ||
                casillas[barco.getFila()][barco.getColumna()+i]=='q' ||
                casillas[barco.getFila()][barco.getColumna()+i]=='s' ||
                casillas[barco.getFila()][barco.getColumna()+i]=='b'
                ){
                return false;
            }
        }
     }
     
     return true;
     
 }   

 public void crearTableroMaquina (){
     
     Scanner entrada = new Scanner (System.in);
       int fila,columna,orientacion;
              Random random = new Random();
        
        
    
        //Rellenar la matriz
        for(int x=0;x<10;x++){
            for(int y=0;y<10;y++){
                 //Es el borde de las filas
                    casillas[x][y] = '~';     
            }
        }
     
         //introducimos los barcos
    Barco barco = new Barco();
    
    //introducimos portaviones
      
                //posicion vertical u horizontal  
            //orientacion=ranwdom.nextInt(2); 
            
            if(random.nextBoolean()){
                barco.setOrientacion(Orientacion.VERTICAL);
            }else {
                barco.setOrientacion(Orientacion.HORIZONTAL);
            }
        
            //limites de barco segun orientacion y por fila y columna
            
     if(barco.getOrientacion()==Orientacion.VERTICAL){
       do{
        //introduzco la fila del portaviones
       barco.setFila(random.nextInt(10));
        
        //introduzco la columna del portaviones
        barco.setColumna(random.nextInt(10));
        
    }while(barco.getFila()>3); 
     }   
     
     
          if(barco.getOrientacion()==Orientacion.HORIZONTAL){
       do{
        //introduzco la fila del portaviones
       barco.setFila(random.nextInt(10));
        
        //introduzco la columna del portaviones
        barco.setColumna(random.nextInt(10));
        
    }while(barco.getColumna()>3); 
     } 
     
        //Si la fila esta entre 1 y 10 le digo que me inserte la columna 
        if ((barco.getFila()>=0 && barco.getFila()<=tamanioMaximo)&& (barco.getColumna()>=0 && barco.getColumna()<=tamanioMaximo)){
            
} else{ System.out.println("La maquina no ha introducido los datos correctamente"); }
        //Awui miramos si hay espacio para el barco
        
        if(barco.getOrientacion()==Orientacion.VERTICAL){
            
        }
        
        
        
        
        
        if(barco.getOrientacion() == Orientacion.VERTICAL){
           for(int i=0;i<6;i++){casillas[barco.getFila()+i][barco.getColumna()]='p';}
        }else if(barco.getOrientacion() == Orientacion.HORIZONTAL){//6 porque son 6 casillas las que ocupa el portaaviones
            for(int i=0;i<6;i++){casillas[barco.getFila()][barco.getColumna()+i]='p';}  
        }


        
//introducimos buque
      
        //introduzco la fila del buque
            barco.setFila(random.nextInt(10));
        
        //introduzco la columna del buque
        barco.setColumna(random.nextInt(10));
        
        
        //Si la fila esta entre 1 y 10 le digo que me inserte la columna 
        if ((barco.getFila()>=0 && barco.getFila()<=tamanioMaximo)&& (barco.getColumna()>=0 && barco.getColumna()<=tamanioMaximo)){
            
            //posicion vertical u horizontal  
             
            
            if(random.nextBoolean()){
                barco.setOrientacion(Orientacion.VERTICAL);
            }else {
                barco.setOrientacion(Orientacion.HORIZONTAL);
            }
        
        } else{ System.out.println("La maquina no ha introducido los datos correctamente"); }
        
        
        if(barco.getOrientacion() == Orientacion.VERTICAL){
           for(int i=0;i<4;i++){casillas[barco.getFila()+i][barco.getColumna()]='b';}
        }else if(barco.getOrientacion() == Orientacion.HORIZONTAL){//4 porque son 4 casillas las que ocupa el portaaviones
            for(int i=0;i<4;i++){casillas[barco.getFila()][barco.getColumna()+i]='b';}  
        }

 
         //introducimos submarino
      
        //introduzco la fila del submarino
            barco.setFila(random.nextInt(10));
        
        //introduzco la columna del submarino
        barco.setColumna(random.nextInt(10));
        
        
        //Si la fila esta entre 1 y 10 le digo que me inserte la columna 
        if ((barco.getFila()>=0 && barco.getFila()<=tamanioMaximo)&& (barco.getColumna()>=0 && barco.getColumna()<=tamanioMaximo)){
            
            //posicion vertical u horizontal  
            
            
            if(random.nextBoolean()){
                barco.setOrientacion(Orientacion.VERTICAL);
            }else {
                barco.setOrientacion(Orientacion.HORIZONTAL);
            }
        
        } else{ System.out.println("La maquina no ha introducido los datos correctamente"); }
        
        
        if(barco.getOrientacion() == Orientacion.VERTICAL){
           for(int i=0;i<2;i++){casillas[barco.getFila()+i][barco.getColumna()]='s';}
        }else if(barco.getOrientacion() == Orientacion.HORIZONTAL){//2 porque son 2 casillas las que ocupa el portaaviones
            for(int i=0;i<2;i++){casillas[barco.getFila()][barco.getColumna()+i]='s';}  
        }


//introducimos pesquero
      do{
     
 
        //introduzco la fila del pesquero
            barco.setFila(random.nextInt(10));
        
        //introduzco la columna del pesquero
        barco.setColumna(random.nextInt(10));
        
        
        //Si la fila esta entre 1 y 10 le digo que me inserte la columna 
        if ((barco.getFila()>=0 && barco.getFila()<=tamanioMaximo)&& (barco.getColumna()>=0 && barco.getColumna()<=tamanioMaximo)){
            
            //posicion vertical u horizontal  
            //orientacion=ranwdom.nextInt(2); 
            
            if(random.nextBoolean()){
                barco.setOrientacion(Orientacion.VERTICAL);
            }else {
                barco.setOrientacion(Orientacion.HORIZONTAL);
            }
        
        } else{ System.out.println("La maquina no ha introducido los datos correctamente"); }
      //miramos que no se solapen los barcos  
  
 
      }while(!cabe(barco));
      if(barco.getOrientacion() == Orientacion.VERTICAL){
           for(int i=0;i<1;i++){casillas[barco.getFila()+i][barco.getColumna()]='q';}
        }else if(barco.getOrientacion() == Orientacion.HORIZONTAL){//1 porque son 1 casillas las que ocupa el portaaviones
            for(int i=0;i<1;i++){casillas[barco.getFila()][barco.getColumna()+i]='q';}  
        }
      

        
        //mostrar tablero
        System.out.println("\nTablero Maquina: \n");
        
        
        System.out.print("  0 1 2 3 4 5 6 7 8 9 \n");
        for(int x=0;x<10;x++){
            System.out.print(x+" ");
            for(int y=0;y<10;y++){
                System.out.print(casillas[x][y]+" ");
            }
            System.out.println("");
        }
        System.out.println("");
}
 
 
 
 
 
 
}

