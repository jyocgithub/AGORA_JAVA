/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package barcos;

/**
 *
 * @author mrs123456
 */
public class Barco {
    
    int fila, columna, tamano;
    boolean vida[];
    Orientacion orientacion;

   public Barco(){}
    
    public Barco(int fila, int columna, int tamano, Orientacion orientacion) {
        this.fila = fila;
        this.columna = columna;
        this.tamano = tamano;
        this.orientacion = orientacion;
        this.vida = new boolean[tamano];
    }

    public int getFila() {
        return fila;
    }

    public int getColumna() {
        return columna;
    }

    public Orientacion getOrientacion() {
        return orientacion;
    }

    


    public int getTamano() {
        return tamano;
    }

    public Orientacion isOrientacion() {
        return orientacion;
    }

    public boolean[] getVida() {
        return vida;
    }

    public void setFila(int fila) {
        this.fila = fila;
    }

    public void setColumna(int columna) {
        this.columna = columna;
    }

    public void setTamano(int tamano) {
        this.tamano = tamano;
    }

    public void setVida(boolean[] vida) {
        this.vida = vida;
    }

    public void setOrientacion(Orientacion orientacion) {
        this.orientacion = orientacion;
    }
    
    

    public void portaviones(){
        this.tamano=6;
        this.vida=new boolean[6];
    }
    
    public void buque(){
        this.tamano=4;
        this.vida=new boolean[4];
    }
    
    
    public void submarino(){
        this.tamano=2;
        this.vida=new boolean[2];
    }
    
    public void pesquero(){
        this.tamano=1;
        this.vida=new boolean[1];
    }
    
    
    
    
    
    
    
    
    
    
    
    
}


