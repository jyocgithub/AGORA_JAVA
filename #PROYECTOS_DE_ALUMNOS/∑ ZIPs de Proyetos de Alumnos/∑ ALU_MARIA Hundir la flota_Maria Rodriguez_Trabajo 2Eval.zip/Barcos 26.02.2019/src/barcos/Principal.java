/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package barcos;

import java.util.Scanner;

/**
 *
 * @author mrs123456
 */
public class Principal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner entrada = new Scanner (System.in);
        int opcion;
        
        System.out.println("------MENU------");
        System.out.println("1. Jugar");
        System.out.println("2. Consulta partidas");
        System.out.println("3. Dificultad");
        System.out.println("4. Salir");
        opcion = entrada.nextInt();
        
        switch(opcion){
            case 1: Tablero juego =new Tablero();//aqui inicializamos la creacion del tablero
                    juego.crearTableroJugador();//aqui creamos el tablero en Principal del jugador
                    juego.crearTableroMaquina();//aqui creamos el tablero de la maquina
                    Jugador jugador= new Jugador();
                    jugador.ataqueMaquina(juego);
                    
                    
                    break;
            
            case 2: break;
            
            case 3: break;
            
            case 4: break;
            
                default: System.out.println("Escribe una opcion correcta");break;
                    
        }
        
        

        }
     
    }
    

