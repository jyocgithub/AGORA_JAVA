/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: alumno
 *
 * Created on 22 de noviembre de 2018, 12:07
 */

#include <cstdlib>
#include <iostream>
using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {
    int selecciona;
    
    cout<< "\n-MENU-"<<endl;
    cout<<"1. JUGAR"<<endl;
    cout<<"2. PALABRAS"<<endl;    
    cout<<"3. DIFICULTAD"<<endl;
    cout<<"4. ESTADISTICAS"<<endl;
    cout<<"\n5. SALIR"<<endl; 
    
    cout<<"Escoge una opcion: ";cin>>selecciona;
    
    switch (selecciona){
        case 1:// ir a funcion JUGAR
        case 2://ir a fichero PALABRAS
        case 3:// ir a funcion dificultad
        case 4://ir a fichero estadisticas
        case 5://salir del juego. cerrar ejecutable.
    }
  
    
return 0;
}

