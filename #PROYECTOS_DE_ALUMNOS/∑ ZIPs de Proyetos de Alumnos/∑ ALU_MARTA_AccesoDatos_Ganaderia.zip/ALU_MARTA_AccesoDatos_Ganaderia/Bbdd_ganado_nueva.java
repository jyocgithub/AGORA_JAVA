package jdbc_ejercicio6;

import java.sql.*;
import java.util.ArrayList;
import java.util.Scanner;

public class Bbdd_ganado_nueva {

	public static String url = "jdbc:mysql://localhost:3306/";
	public static final String usuario = "root";
//	public static final String password = "martis";
	public static final String password = "root";
	Connection conn;
	Statement query;
	String nombrebbdd;
	String veterinario;
//	Ganaderia ganaderia;

	public Bbdd_ganado_nueva(String nombrebbdd, String veterinario) {
		this.nombrebbdd = nombrebbdd;
		this.veterinario = veterinario;
		conectar();
	}

	public void conectar() {

		try {
			conn = DriverManager.getConnection(url, usuario, password);

			Statement query2 = conn.createStatement();
			String create = "Create database if not exists "+ nombrebbdd ;
			query2.executeUpdate(create);

			String use = "Use "+ nombrebbdd +"";
			query2.executeUpdate(use);
			
			String table = "Create table if not exists Traza_Ministerio (id int primary key auto_increment,veterinario varchar(30),origen varchar(30),reses int,destino varchar(30))";
			query2.executeUpdate(table);	

		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public void desconectar() {
		try {
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public void meterGanaderia(ArrayList<Ganaderia> ganaderiaOrigen)  {

		try {

			for(Ganaderia ganaderia : ganaderiaOrigen) {

				String queryNueva = "Insert into Traza_Ministerio values(null,?,?,?,?)";
				PreparedStatement queryps = conn.prepareStatement(queryNueva);

				queryps.setString(1, veterinario);
				queryps.setString(2, ganaderia.getProcedencia() + ganaderia.getPropietario());
				queryps.setInt(3, ganaderia.getNumero_reses());
				queryps.setString(4, ganaderia.getDestino());
				queryps.executeUpdate();

			}

		} catch (SQLException e) {
			e.printStackTrace();
		}
	}



	public ArrayList<GanaderiaNueva> leerGanaderianueva() {

		ArrayList<GanaderiaNueva> lista = new ArrayList<>();
		//conectarDestino();
		try {
			query = conn.createStatement();
			ResultSet res = query.executeQuery("SELECT * FROM Traza_Ministerio");

			while (res.next()) {
				GanaderiaNueva gn = new GanaderiaNueva(res.getString("veterinario"), res.getString("origen"),
								   res.getInt("reses"), res.getString("destino"));
				lista.add(gn);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			desconectar();
		}
		return lista;
	}
}
