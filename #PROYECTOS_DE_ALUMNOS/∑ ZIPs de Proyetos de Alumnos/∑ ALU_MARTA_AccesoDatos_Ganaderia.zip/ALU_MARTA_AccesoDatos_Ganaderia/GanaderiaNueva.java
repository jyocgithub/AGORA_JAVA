package jdbc_ejercicio6;

public class GanaderiaNueva {
	
	private String veterinario;
	private String origen;
	private int reses;
	private String destino;
	
	public GanaderiaNueva(String veterinario, String origen, int reses, String destino) {
		this.veterinario = veterinario;
		this.origen = origen;
		this.reses = reses;
		this.destino = destino;
	}
	public String getVeterinario() {
		return veterinario;
	}
	public void setVeterinario(String veterinario) {
		this.veterinario = veterinario;
	}
	public String getOrigen() {
		return origen;
	}
	public void setOrigen(String origen) {
		this.origen = origen;
	}
	public int getReses() {
		return reses;
	}
	public void setReses(int reses) {
		this.reses = reses;
	}
	public String getDestino() {
		return destino;
	}
	public void setDestino(String destino) {
		this.destino = destino;
	}
	@Override
	public String toString() {
		return "GanaderiaNueva [veterinario=" + veterinario + ", origen=" + origen + ", reses=" + reses + ", destino="
				+ destino + "]";
	}
	
}
