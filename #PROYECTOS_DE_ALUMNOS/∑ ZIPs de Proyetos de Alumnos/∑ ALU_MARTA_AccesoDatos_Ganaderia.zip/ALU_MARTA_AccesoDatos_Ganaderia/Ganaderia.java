package jdbc_ejercicio6;

public class Ganaderia {
	
	private String procedencia;
	private String destino;
	private int numero_reses;
	private String propietario;

	public Ganaderia(String procedencia, String destino, int numero_reses, String propietario) {
		this.procedencia = procedencia;
		this.destino = destino;
		this.numero_reses = numero_reses;
		this.propietario = propietario;
	}
	public String getProcedencia() {
		return procedencia;
	}
	public void setProcedencia(String procedencia) {
		this.procedencia = procedencia;
	}
	public String getDestino() {
		return destino;
	}
	public void setDestino(String destino) {
		this.destino = destino;
	}
	public int getNumero_reses() {
		return numero_reses;
	}
	public void setNumero_reses(int numero_reses) {
		this.numero_reses = numero_reses;
	}
	public String getPropietario() {
		return propietario;
	}
	public void setPropietario(String propietario) {
		this.propietario = propietario;
	}

	@Override
	public String toString() {
		return "Ganaderia [procedencia=" + procedencia + ", destino=" + destino + ", numero_reses=" + numero_reses
				+ ", propietario=" + propietario + "]";
	}
	
}
