CREATE DATABASE ganaderia;

USE ganaderia;

CREATE TABLE Traza_Aragon (
	procedencia varchar(20),
	destino varchar(20),
	numero_reses int(3),
	propietario varchar(20)
);
insert into Traza_Aragon values("Zaragoza","Madrid",12,"Ganadería López");
insert into Traza_Aragon values("Zaragoza","Sevilla",8,"Vacas Aristóbulo");
insert into Traza_Aragon values("Huesca","Barcelona",23,"Reses Benasque");
