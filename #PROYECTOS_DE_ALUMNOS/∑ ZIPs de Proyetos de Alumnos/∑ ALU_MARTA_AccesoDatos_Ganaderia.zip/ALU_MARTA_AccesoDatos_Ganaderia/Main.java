package jdbc_ejercicio6;

import java.util.ArrayList;
import java.util.Scanner;

public class Main {


	public static void main(String[] args) {
		
		Scanner entrada = new Scanner(System.in);

		// pido datos nuevos al usuario
		System.out.println("dime el nombre de la bbdd de origen");
		String nombreOrigen = entrada.nextLine();
		System.out.println("dime el nombre de la bbdd de destino");
		String nombreDestino = entrada.nextLine();
		System.out.println("dime el nombre del veterinario");
		String veterinario = entrada.nextLine();

		// creamos los objetos de las dos clases, que se parecen pero no son iguales
		// una clase por bbdd es mas limpio
		Bbdd_ganado origen = new Bbdd_ganado(nombreOrigen);
		Bbdd_ganado_nueva destino = new Bbdd_ganado_nueva(nombreDestino, veterinario);

		// movemos de una a otra ganaderia
		// primero leemos lo que hay en la primera
		ArrayList<Ganaderia> lista  = origen.leerGanaderia();
		// luego se lo pasamos a la segunda para que haga los insert de todo
		destino.meterGanaderia(lista);


		// pintamos primera ganaderia
		for(Ganaderia g : lista) {
			System.out.println(g);
		}

		// pintamos segunda ganaderia
		ArrayList<GanaderiaNueva> listaNueva  = destino.leerGanaderianueva();
		for(GanaderiaNueva gn : listaNueva) {
			System.out.println(gn);
		}

		origen.desconectar();
		destino.desconectar();
	}


}
