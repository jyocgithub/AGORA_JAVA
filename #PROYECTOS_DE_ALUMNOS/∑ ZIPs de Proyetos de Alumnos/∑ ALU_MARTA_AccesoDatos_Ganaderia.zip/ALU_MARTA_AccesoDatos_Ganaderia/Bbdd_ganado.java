package jdbc_ejercicio6;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Scanner;

public class Bbdd_ganado {

	public static String url = "jdbc:mysql://localhost:3306/";
	public static final String usuario = "root";
	//	public static final String password = "martis";
	public static final String password = "root";
	Connection conn;
	Statement query;
	String nombrebbdd;
	Ganaderia ganaderia;
	Scanner entrada = new Scanner(System.in);


	public Bbdd_ganado(String nombrebbdd) {
		this.nombrebbdd = nombrebbdd;
		conectar();
	}

	public void conectar() {
		try {
			url = "jdbc:mysql://localhost:3306/"+ nombrebbdd;
			conn = DriverManager.getConnection(url, usuario, password);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public void desconectar() {
		try {
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}


	public ArrayList<Ganaderia> leerGanaderia() {

		ArrayList<Ganaderia> lista = new ArrayList<>();
		//conectarOrigen();
		try {
			Statement query = conn.createStatement();
			ResultSet res = query.executeQuery("SELECT * FROM Traza_Aragon");

			while (res.next()) {
				Ganaderia g = new Ganaderia(res.getString("procedencia"), res.getString("destino"),
						res.getInt("numero_reses"), res.getString("propietario"));
				lista.add(g);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			desconectar();
		}
		return lista;
	}


}
