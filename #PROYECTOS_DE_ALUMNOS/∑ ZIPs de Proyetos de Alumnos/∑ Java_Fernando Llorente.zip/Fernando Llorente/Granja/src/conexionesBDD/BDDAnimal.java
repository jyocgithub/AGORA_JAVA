/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package conexionesBDD;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Fernando
 */
public class BDDAnimal {

    private Connection conn1; // Creamos att del tipo connection y debe ser privada.

    public BDDAnimal() {

        try {
            String url1 = "jdbc:mysql://localhost:3306/granja";
            String user = "root";
            String password = "root";
            conn1 = DriverManager.getConnection(url1, user, password);

            if (conn1 != null) {
                System.out.println("Conectado a la BBDD Granja"); // Si se ha conectado correctamente.

            }

        } catch (SQLException ex) {

            ex.printStackTrace();
            System.out.println("Error en la conexión a la BBDD Granja"); // Si no se ha conectado correctamente.
        }

    }

    public void cerrarConexion() {

        try {

            conn1.close();

            System.out.println("Se ha cerrado correctamente");

        } catch (SQLException ex) {
            ex.printStackTrace();
            System.out.println("Error al cerrar");
        }
    }

    public void insertar(Animal a) {
        try {
            String orden = "INSERT INTO animal VALUES (0,?,?,?,?,?,?)";

            PreparedStatement instruccion = conn1.prepareStatement(orden);
            instruccion.setString(1, a.getPeso());
            instruccion.setString(2, a.getCantidad_comida());
            instruccion.setString(3, a.getRaza());
            instruccion.setString(4, a.getTipo_animal());
            instruccion.setString(5, a.getTipo_alimento());
            instruccion.setInt(6, a.getSector().getId_sector());
            instruccion.executeUpdate();

        } catch (SQLException ex) {
            Logger.getLogger(BDDAnimal.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    public void borrar(Animal a) {
        try {
            String orden = "DELETE FROM animal WHERE id_animal = ?";

            PreparedStatement instruccion = conn1.prepareStatement(orden);
            instruccion.setInt(1, a.getId());
            instruccion.executeUpdate();

        } catch (SQLException ex) {
            Logger.getLogger(BDDAnimal.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    public void modificar(Animal a) {
        try {
            String orden = "UPDATE animal SET peso=?, cantidad_comida=?, raza=?, tipo_animal=?, tipo_alimento=?, id_sector=? WHERE id_animal=?";

            PreparedStatement instruccion = conn1.prepareStatement(orden);
            instruccion.setString(1, a.getPeso());
            instruccion.setString(2, a.getCantidad_comida());
            instruccion.setString(3, a.getRaza());
            instruccion.setString(4, a.getTipo_animal());
            instruccion.setString(5, a.getTipo_alimento());
            instruccion.setInt(6, a.getSector().getId_sector());
            instruccion.setInt(7, a.getId());
            instruccion.executeUpdate();

        } catch (SQLException ex) {
            Logger.getLogger(BDDAnimal.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    public ArrayList<Animal> consultarTodosAnimales() {
        ArrayList<Animal> lista = new ArrayList<>();
        try {
            String orden = "SELECT * FROM animal";
            PreparedStatement instruccion = conn1.prepareStatement(orden);
            ResultSet registros = instruccion.executeQuery();
            while (registros.next()) {

                int id_animal = registros.getInt("id_animal");
                String peso = registros.getString("peso");
                String cantidad_comida = registros.getString("cantidad_comida");
                String raza = registros.getString("raza");
                String tipo_animal = registros.getString("tipo_animal");
                String tipo_alimento = registros.getString("tipo_alimento");
                int id_sector_leido = registros.getInt("id_sector");

                String orden2 = "SELECT nombre FROM sector WHERE id_sector = ?";
                PreparedStatement instruccion2 = conn1.prepareStatement(orden2);
                instruccion2.setInt(1, id_sector_leido);
                ResultSet registros2 = instruccion2.executeQuery();
                while (registros2.next()) {
                    String nombre = registros2.getString("nombre");
                    Sector sector = new Sector(id_sector_leido, nombre);
                    Animal a = new Animal(id_animal, peso, cantidad_comida, raza, tipo_animal, tipo_alimento, sector);
                    lista.add(a);
                }

            }

        } catch (SQLException ex) {
            Logger.getLogger(BDDAnimal.class.getName()).log(Level.SEVERE, null, ex);
        }

        return lista;
    }

}
