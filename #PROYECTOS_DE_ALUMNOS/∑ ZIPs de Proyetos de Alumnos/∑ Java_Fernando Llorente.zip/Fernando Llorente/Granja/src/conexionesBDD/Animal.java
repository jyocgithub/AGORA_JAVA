/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package conexionesBDD;

/**
 *
 * @author 
 */
public class Animal {
    
    private int id;
    private String peso;
    private String cantidad_comida;
    private String raza;
    private String tipo_animal;
    private String tipo_alimento;
    private Sector sector;

    public int getId() {
        return id;
    }

    public String getPeso() {
        return peso;
    }

    public String getCantidad_comida() {
        return cantidad_comida;
    }

    public String getRaza() {
        return raza;
    }

    public String getTipo_animal() {
        return tipo_animal;
    }

    public String getTipo_alimento() {
        return tipo_alimento;
    }

    public Sector getSector() {
        return sector;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setPeso(String peso) {
        this.peso = peso;
    }

    public void setCantidad_comida(String cantidad_comida) {
        this.cantidad_comida = cantidad_comida;
    }

    public void setRaza(String raza) {
        this.raza = raza;
    }

    public void setTipo_animal(String tipo_animal) {
        this.tipo_animal = tipo_animal;
    }

    public void setTipo_alimento(String tipo_alimento) {
        this.tipo_alimento = tipo_alimento;
    }

    public void setSector(Sector sector) {
        this.sector = sector;
    }

    public Animal(int id, String peso, String cantidad_comida, String raza, String tipo_animal, String tipo_alimento, Sector sector) {
        this.id = id;
        this.peso = peso;
        this.cantidad_comida = cantidad_comida;
        this.raza = raza;
        this.tipo_animal = tipo_animal;
        this.tipo_alimento = tipo_alimento;
        this.sector = sector;
    }
    
    
}
