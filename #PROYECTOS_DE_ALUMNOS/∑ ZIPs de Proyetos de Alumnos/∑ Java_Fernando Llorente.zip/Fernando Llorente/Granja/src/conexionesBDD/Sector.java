/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package conexionesBDD;

/**
 *
 * @author Usuario
 */
public class Sector {
    
    private int id_sector;
    private String nombre_sector;
    

    public Sector(int id_sector, String nombre_sector) {
        this.id_sector = id_sector;
        this.nombre_sector = nombre_sector;
    }

    public void setId_sector(int id_sector) {
        this.id_sector = id_sector;
    }

    public void setNombre_sector(String nombre_sector) {
        this.nombre_sector = nombre_sector;
    }

    public int getId_sector() {
        return id_sector;
    }

    public String getNombre_sector() {
        return nombre_sector;
    }
}
