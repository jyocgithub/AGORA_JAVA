/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ventana;

import java.awt.Component;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import javax.swing.JFileChooser;

/**
 *
 * @author Fernando Llorente
 */
public class Fichero {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        Fichero f = new Fichero();
        
        EscogerFichero();
        
        
    }

    //metodo para escoger un fichero a
    public static File EscogerFichero() {
        
        File fichero = null;
        
        try {
        JFileChooser fileChooser = new JFileChooser();
        Component areaTexto = null;
        fileChooser.setMultiSelectionEnabled(false);
        // OPEN_DIALOG es una constante que representa un número
        fileChooser.setDialogType(JFileChooser.OPEN_DIALOG);
        int seleccion = fileChooser.showSaveDialog(areaTexto);
        
        
        if (seleccion == JFileChooser.APPROVE_OPTION) {
            fichero = fileChooser.getSelectedFile();
        }
        
        } catch (Exception ex) {
            System.out.println(ex.toString());
        }
        
        // se puede poner solo un return porque devolverá o null o el fichero
        return fichero;
    }

    public static String leerArchivo(File fichero) {
 
        // StringBuilder sirve para que no tengas que destruir un objeto String cada vez que modificas. 
        //StringBuider evita la recreacion continua de objetos, con solo un objeto y concatenar cientos de cadenas
        StringBuilder texto = new StringBuilder();
        
        try {
            FileReader fr = new FileReader(fichero);
            int num = fr.read();
            while (num != -1) {
                // append añade caracteres o lo que sea al final de la cadena
                texto.append((char) num);
                System.out.print((char) num);
                // leemos siguiente caracter
                num = fr.read();
                
            }
            fr.close();
        } catch (IOException ex) {
            ex.printStackTrace();
        }//convertimos ese objeto a String
        return texto.toString();
    }
    
   public static void guardarArchivo(File fichero, String textoQueGuardo) {
        try {
            FileWriter fw = new FileWriter(fichero);
            for (int i = 0; i < textoQueGuardo.length(); i++) {
                char c = textoQueGuardo.charAt(i);
                fw.write(c);
            }
            fw.close();
        } catch (IOException ex) {
            ex.printStackTrace();
        }
        
   }
   
   public static String leerArchivoBuffered(File fichero) {
 
        StringBuilder texto = new StringBuilder();

        try {
            BufferedReader br = new BufferedReader(new FileReader(fichero));
            
            String linea = br.readLine();
            while (linea != null) {
                // append añade caracteres o lo que sea al final de la cadena
                texto.append(linea);
                System.out.print(linea);
                // leemos siguiente caracter
                linea = br.readLine();
            }
            br.close();
        } catch (IOException ex) {
            ex.printStackTrace();
        }//convertimos ese objeto a String
        return texto.toString();
    }
   
   public static void guardarArchivoBuffered(File fichero, String textoQueGuardo) {
        try {
            BufferedWriter bw=new BufferedWriter(new FileWriter(fichero));
            bw.write(textoQueGuardo);

            bw.close();
        } catch (IOException ex) {
            ex.printStackTrace();
        }   
   }
   
   public static String eliminar(String texto){
       
       return texto=" ";
   }
  
}