package utilidades;

import java.security.InvalidKeyException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.KeyGenerator;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;


/**
 * Clase que contiene metodos estaticos para encriptado y desencriptado de 
 * mensajes por algoritmos simetricos o HASH
 */
public class UtilidadesCriptografia {

	static private SecretKey claveComun;
	static private Cipher cifrador;
	
	/**
	 * Metodo que crea la clave para cifrado simetrico
	 */
	static public void crearClaveYCifrador() {
		try {
			cifrador = Cipher.getInstance("AES");
			KeyGenerator keyGenerator = KeyGenerator.getInstance("AES");
			claveComun = keyGenerator.generateKey();
		} catch (NoSuchAlgorithmException | NoSuchPaddingException e) {
			e.printStackTrace();
		}
	}

	/**
	 * Método que encripta una cadena con un algoritmo simetrico 
	 * @param men cadena para encriptar
	 * @return array de bytes con la cadena encriptada
	 */
	static public byte[] encriptarString(String men) {
		byte[] mensajeCifrado = null;
		try {
			cifrador.init(Cipher.ENCRYPT_MODE, claveComun);
			mensajeCifrado = cifrador.doFinal(men.getBytes());
		} catch (InvalidKeyException | IllegalBlockSizeException | BadPaddingException e) {
			e.printStackTrace();
		}
		return mensajeCifrado;
	}

	/**
	 * Método que deencripta un array de bytes en una cadena, con un algoritmo simetrico 
	 * @param cifra arary de bytes con la caden encriptada
	 * @return cadena desencriptada
	 */
	static public String desencriptarString(byte[] cifra) {
		String solucion = null;
		try {
			cifrador.init(Cipher.DECRYPT_MODE, claveComun);
			byte[] mensajeDescifrado = cifrador.doFinal(cifra);
			solucion = new String(mensajeDescifrado);
		} catch (InvalidKeyException | IllegalBlockSizeException | BadPaddingException e) {
			e.printStackTrace();
		}
		return solucion;
	}
	
	/**
	 * Método que encripta una cadena con un algoritmo HASH 
	 * @param men cadena para encriptar
	 * @return array de bytes con la cadena encriptada
	 */
    static public byte[] encriptarStringHASH(String men) {
        try {
            return MessageDigest.getInstance("MD5").digest(men.getBytes());
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        }
        return null;
    }

	
}
