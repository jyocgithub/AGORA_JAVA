package requerimiento1;

import java.util.Scanner;

import utilidades.UtilidadesCriptografia;
/**
 * Clase para el primer requerimiento
 */
public class MainRequerimiento1 {


	static String frase;
	static  byte[] encriptado;

	/**
	 * Metodo de inicio, con un menu con las opciones necesarias
	 * @param args
	 */
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		UtilidadesCriptografia.crearClaveYCifrador();
		
		int opcion = 0;

		do {
			System.out.println("------MENU-----------");
			System.out.println("1.- Encriptar una frase");
			System.out.println("2.- Desencriptar frase encriptada");
			System.out.println("0.- Salir");
			opcion = Integer.parseInt(sc.nextLine());
			switch (opcion) {
			case 1:
				encriptar();
				break;

			case 2:
				desencriptar();
				break;

			case 0:
				System.out.println("Cierre del menu");
				break;
			}

		} while (opcion != 0);
		

	}

	/**
	 * Metodo que pide informacion al usuario para encriptar una frase
	 */
	static public void encriptar() {
		Scanner sc = new Scanner(System.in);
		System.out.println("\nEscriba un frase:");
		frase = sc.nextLine();
		
		encriptado = UtilidadesCriptografia.encriptarString(frase);
		System.out.println("Resultado de la encriptacion: ");
		String res = new String(encriptado);
		System.out.println(res);
		
	}
	
	
	/**
	 * Metodo que informa al usuario al desencriptar una frase
	 */
	static public void desencriptar() {
		if(frase!=null) {
		
		String frase = UtilidadesCriptografia.desencriptarString(encriptado);
		System.out.println("Resultado de la desencriptacion: ");
		System.out.println(frase);
		}else {
			System.out.println("No hay nada encriptado aun...");
		}
	}
	
	
}
