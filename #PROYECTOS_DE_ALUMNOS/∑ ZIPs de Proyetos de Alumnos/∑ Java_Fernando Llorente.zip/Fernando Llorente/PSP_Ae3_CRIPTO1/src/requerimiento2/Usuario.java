package requerimiento2;
/**
 * JavaBean para guardar usuarios
 * Las contraseñas se almacenan como byte[]
 */
public class Usuario {
	private String nombre;
	private byte[] password;
	public Usuario(String nombre, byte[]  password) {
		super();
		this.nombre = nombre;
		this.password = password;
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public byte[]  getPassword() {
		return password;
	}
	public void setPassword(byte[]  password) {
		this.password = password;
	}
	
	
	
	
	
}
