package requerimiento2;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;

import utilidades.UtilidadesCriptografia;

/**
 * Clase inicio del requerimiento 2
 */
public class MainRequerimiento2 {

	static ArrayList<Usuario> listaUsuarios = new ArrayList<>();

	/**
	 * Medoto de inicio de la clase
	 * @param args
	 */
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		String nombre, password;
		crearUsuarios();
		boolean acerto = false;

		int intentos = 0;
		do {
			intentos++;
			
			System.out.println("Escriba nombre :");
			nombre = sc.nextLine();
			System.out.println("Escriba contraseña :");
			password = sc.nextLine();

			byte[] passencrip = UtilidadesCriptografia.encriptarStringHASH(password);
			for (Usuario u : listaUsuarios) {
				// No se debe comparar dos byte[] ni con == ni con equals
				// El medio mas eficiente es usar el la clase Arrays
				if (u.getNombre().equalsIgnoreCase(nombre) && Arrays.equals(u.getPassword() ,passencrip)) {
					acerto = true;
					System.out.println("bingo....");
				}
			}
			if (!acerto) {
				System.out.println("Usuario o contraseña erróneos");
			}
			
		} while (intentos < 3 && acerto == false);

		if (acerto) {
			System.out.println("Acceso concedido");
		} else {
			System.out.println("Acceso denegado, demasiados intentos erróneos");
		}
	}

	/**
	 * Metodo auxiliar para crear los usuarios con las contraseñas encriptadas
	 * y guardarlo todo en un lista
	 */
	public static void crearUsuarios() {

		String contra1 = "camion";
		String contra2 = "pelota";
		String contra3 = "anillo";

		byte[] c1 = UtilidadesCriptografia.encriptarStringHASH(contra1);
		byte[] c2 = UtilidadesCriptografia.encriptarStringHASH(contra2);
		byte[] c3 = UtilidadesCriptografia.encriptarStringHASH(contra3);

		Usuario u1 = new Usuario("Paco", c1);
		Usuario u2 = new Usuario("Pepe", c2);
		Usuario u3 = new Usuario("Luis", c3);

		listaUsuarios.add(u1);
		listaUsuarios.add(u2);
		listaUsuarios.add(u3);

	}
}
