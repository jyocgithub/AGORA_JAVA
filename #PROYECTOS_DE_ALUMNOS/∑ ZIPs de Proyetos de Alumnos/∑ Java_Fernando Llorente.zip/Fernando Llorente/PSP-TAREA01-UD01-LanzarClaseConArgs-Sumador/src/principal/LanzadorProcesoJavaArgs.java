package principal;

import java.io.File;

public class LanzadorProcesoJavaArgs {

	public static void main(String[] args) {
		try {
			String clase = "sumador.Sumador";
			File file = new File("./bin");
			ProcessBuilder pb = new ProcessBuilder("java", clase, "1", "51");
			pb.inheritIO();
			pb.directory(file);
			pb.start();
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
