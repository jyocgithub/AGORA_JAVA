package sumador;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Arrays;

public class Sumador {

	public static void main(String[] args) {

		guarda("inicio.txt", "inicio");
		String arraycomounstring = Arrays.toString(args);

		System.out.println("Argumentos de entrada " + arraycomounstring);
		int a = Integer.parseInt(args[0]);
		int b = Integer.parseInt(args[1]);

		sumar(a, b);
		System.out.println("Finalizado");
	}

	public static void sumar(int num1, int num2) {

		int sum = 0;
		while (num1 <= num2) {
			sum = sum + num1;
			num1++;
		}
		System.out.println(sum);

		guarda(sum + ".txt", sum + "");

	}

	public static void guarda(String nombre, String contenido) {
		File fichero = new File(nombre);
		try {
			BufferedWriter bw = new BufferedWriter(new FileWriter(fichero));
			bw.write(contenido);
			bw.flush();
			bw.close();
		} catch (IOException ex) {
			System.err.println("Error en escritura fichero: " + ex.getMessage());
		}

	}
}
