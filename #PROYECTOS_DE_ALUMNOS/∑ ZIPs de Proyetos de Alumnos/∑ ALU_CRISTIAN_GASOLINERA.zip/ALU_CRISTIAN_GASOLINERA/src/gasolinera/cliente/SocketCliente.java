package cliente;

import servidor.Operario;
import servidor.Vehiculo;
import java.awt.Color;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import static java.lang.Thread.sleep;
import java.net.Socket;
import java.util.ArrayList;

/**
 * Clase que crea un SocketCliente para recibir datos.
 *
 * @author CristianDiaz,ManuelaLopez
 */
public class SocketCliente extends Thread {

    private Socket socket;
    private ObjectInputStream entrada;
    private ObjectOutputStream salida;
    private Boolean seguir = true;
    private Cliente cliente;

    private ArrayList<Color> surtidoresElectricos;
    private ArrayList<String> estadosElectricos;
    private ArrayList<String> matriculasElectricos;
    private ArrayList<Operario> operariosElectricos;

    private ArrayList<Color> surtidoresGasolina;
    private ArrayList<String> estadosGasolina;
    private ArrayList<String> matriculasGasolina;
    private ArrayList<Operario> operariosGasolina;

    private ArrayList<Color> surtidoresPesados;
    private ArrayList<String> estadosPesados;
    private ArrayList<String> matriculasPesados;
    private ArrayList<Operario> operariosPesados;

    /**
     * Constructor de la clase SocketServidor.
     *
     * @param cliente : Cliente
     * @param socket : Socket
     */
    public SocketCliente(Cliente cliente, Socket socket) {
        this.socket = socket;
        this.cliente = cliente;
    }

    /**
     * Método que arranca el hilo al ser lanzado.
     */
    public void run() {
        try {
            salida = new ObjectOutputStream(socket.getOutputStream());
            entrada = new ObjectInputStream(socket.getInputStream());

            String precioGasolina = (String) (entrada.readObject());
            String precioKw = (String) (entrada.readObject());

            cliente.getLabelPrecioCombustible().setText(precioGasolina + " €");
            cliente.getLabelPrecioKWh().setText(precioKw + " €");
            while (true) {
                try {

                    salida = new ObjectOutputStream(socket.getOutputStream());
                    entrada = new ObjectInputStream(socket.getInputStream());

                    mostrarInfoElectricos();
                    mostrarInfoGasolina();
                    mostrarInfoPesados();
                    mostrarInfoSaldos();
                    mostrarLog();

                    sleep(10);
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }
        } catch (Exception ux) {
            ux.printStackTrace();
        }
    }

    /**
     * Método que muestra el Log de la Gasolinera.
     *
     */
    public void mostrarLog() {
        try {
            String log = (String) (entrada.readObject());
            cliente.getLogOut().setText(log);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    /**
     * Método que muestra la informacion de los saldos de la Gasolinera.
     *
     */
    public void mostrarInfoSaldos() {
        String formato = "";
        String formato2 = "";
        try {
            Double saldoElectricos = (Double) (entrada.readObject());
            Double saldoGasolina = (Double) (entrada.readObject());
            formato = String.format("%.2f", saldoGasolina);
            formato2 = String.format("%.2f", saldoElectricos);
            cliente.getLabelRecaudacionElectrico().setText(formato2 + " €");
            cliente.getLabelRecaudacionGasolina().setText(formato + " €");

        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    /**
     * Método que muestra la informacion de los vehiculos pesados en los
     * surtidores.
     *
     */
    public void mostrarInfoPesados() {
        try {
            surtidoresPesados = (ArrayList<Color>) (entrada.readObject());
            estadosPesados = (ArrayList<String>) (entrada.readObject());
            matriculasPesados = (ArrayList<String>) (entrada.readObject());
            operariosPesados = (ArrayList<Operario>) (entrada.readObject());

            pintarCochesPesados();
        } catch (Exception ux) {
            ux.printStackTrace();
        }
    }

    /**
     * Método que muestra la informacion de los vehiculos de gasolina en los
     * surtidores.
     *
     */
    public void mostrarInfoGasolina() {
        try {
            surtidoresGasolina = (ArrayList<Color>) (entrada.readObject());
            estadosGasolina = (ArrayList<String>) (entrada.readObject());
            matriculasGasolina = (ArrayList<String>) (entrada.readObject());
            operariosGasolina = (ArrayList<Operario>) (entrada.readObject());

            pintarCochesGasolina();
        } catch (Exception ux) {
            ux.printStackTrace();
        }
    }

    /**
     * Método que pinta los vehiculos pesados en los surtidores.
     *
     */
    public void pintarCochesPesados() {
        String estado = "";
        for (int i = 0; i < surtidoresPesados.size(); i++) {
            estado = estadosPesados.get(i);
            cliente.pintarPolloLabel(i + 6, true, operariosPesados.get(i));
            cliente.pintarCocheLabel(i + 6, true, Vehiculo.PESADO, surtidoresPesados.get(i));
            cliente.pintarLabelInfo(i + 6, estado);
            if (matriculasPesados.get(i) == null) {
                cliente.pintarLabelMatricula(i + 6, matriculasPesados.get(i), false);
            } else {
                cliente.pintarLabelMatricula(i + 6, matriculasPesados.get(i), true);
            }
        }
    }

    /**
     * Método que pinta los vehiculos de gasolina en los surtidores.
     *
     */
    public void pintarCochesGasolina() {
        String estado = "";
        for (int i = 0; i < surtidoresGasolina.size(); i++) {
            estado = estadosGasolina.get(i);
            cliente.pintarPolloLabel(i + 3, true, operariosGasolina.get(i));
            cliente.pintarCocheLabel(i + 3, true, Vehiculo.COMBUSTIBLE, surtidoresGasolina.get(i));
            cliente.pintarLabelInfo(i + 3, estado);
            if (matriculasGasolina.get(i) == null) {
                cliente.pintarLabelMatricula(i + 3, matriculasGasolina.get(i), false);
            } else {
                cliente.pintarLabelMatricula(i + 3, matriculasGasolina.get(i), true);
            }
        }
    }

    /**
     * Método que muestra la informacion de los vehiculos electricos en los
     * surtidores.
     *
     */
    public void mostrarInfoElectricos() {
        try {
            surtidoresElectricos = (ArrayList<Color>) (entrada.readObject());
            estadosElectricos = (ArrayList<String>) (entrada.readObject());
            matriculasElectricos = (ArrayList<String>) (entrada.readObject());
            operariosElectricos = (ArrayList<Operario>) (entrada.readObject());

            pintarCochesElectricos();
        } catch (Exception ux) {
            ux.printStackTrace();
        }
    }

    /**
     * Método que pinta los vehiculos electricos en los surtidores.
     *
     */
    public void pintarCochesElectricos() {
        String estado = "";

        for (int i = 0; i < surtidoresElectricos.size(); i++) {
            estado = estadosElectricos.get(i);
            cliente.pintarPolloLabel(i, true, operariosElectricos.get(i));
            cliente.pintarCocheLabel(i, true, Vehiculo.ELECTRICO, surtidoresElectricos.get(i));
            cliente.pintarLabelInfo(i, estado);
            if (matriculasElectricos.get(i) == null) {
                cliente.pintarLabelMatricula(i, matriculasElectricos.get(i), false);
            } else {
                cliente.pintarLabelMatricula(i, matriculasElectricos.get(i), true);
            }
        }
    }

}
