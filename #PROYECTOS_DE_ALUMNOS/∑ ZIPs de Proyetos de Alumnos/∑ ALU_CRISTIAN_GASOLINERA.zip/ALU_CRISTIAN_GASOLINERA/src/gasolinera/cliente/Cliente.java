/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cliente;

import servidor.Operario;
import static servidor.Vehiculo.COMBUSTIBLE;
import static servidor.Vehiculo.ELECTRICO;
import static servidor.Vehiculo.PESADO;
import java.awt.Color;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.awt.image.WritableRaster;
import java.io.File;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JTextArea;

/**
 * Clase que crea una ventana Cliente
 *
 * @author CristianDiaz,ManuelaLopez
 */
public class Cliente extends javax.swing.JFrame {
    
    private List<JLabel> labelesCoches = new ArrayList<>();
    private List<JLabel> labelesPollos = new ArrayList<>();
    private List<JLabel> labelesInfo = new ArrayList<>();
    private List<JLabel> labelesMatriculas = new ArrayList<>();
    private ObjectOutputStream salida;
    private ObjectInputStream entrada;
    private SocketCliente cliente;
    private boolean pulsado = false;
    private Socket socketEjecucion;

    /**
     * Constructor de la clase Cliente.
     */
    public Cliente() {
        initComponents();
        pintarPantalla();
        this.getContentPane().setBackground(Color.WHITE);
        Socket socket;
        try {
            socket = new Socket("localhost", 2222); // socket para datos
            socketEjecucion = new Socket("localhost", 4444); // socket para ejecucion

            cliente = new SocketCliente(this, socket);
            cliente.start();
            
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        BotonReanudar.setBackground(Color.GREEN);
        BotonParar.setBackground(Color.red);
        logOut.setEditable(false);
        
    }
    
    public void pintarLabelMatricula(int posicion, String mensaje, boolean estado) {
        labelesMatriculas.get(posicion).setText(mensaje);
        labelesMatriculas.get(posicion).setVisible(estado);
    }
    
    public void pintarLabelInfo(int posicion, String mensaje) {
        labelesInfo.get(posicion).setText(mensaje);
    }
    
    public void pintarCocheLabel(int posicion, boolean estado, int tipo, Color color) {
        Color nulo = new Color(255, 255, 255);
        if (color != nulo) {
            Image imagen = null;
            try {
                switch (tipo) {
                    case ELECTRICO:
                        imagen = ImageIO.read(new File("./src/Imagenes/CocheElectrico.png"));
                        break;
                    case COMBUSTIBLE:
                        imagen = ImageIO.read(new File("./src/Imagenes/CocheGasolina.png"));
                        break;
                    case PESADO:
                        imagen = ImageIO.read(new File("./src/Imagenes/Autobus.png"));
                        break;
                }
                imagen = cambiarColorImagen((BufferedImage) imagen, color);
            } catch (IOException ex) {
                ex.printStackTrace();
            }
            ImageIcon imageIcon = new ImageIcon(imagen);
            
            labelesCoches.get(posicion)
                    .setIcon(imageIcon);
            labelesCoches.get(posicion)
                    .setVisible(estado);
        } else {
            labelesCoches.get(posicion)
                    .setVisible(false);
        }
        
    }
    
    public void pintarPolloLabel(int posicion, boolean estado, Operario pollo) {
        try {
            
            if (pollo != null) {
                
                Image imagen = null;
                switch (pollo.getNombre()) {
                    case "Juan":
                        imagen = ImageIO.read(new File("./src/Imagenes/Pollo.png"));
                        break;
                    case "Pepe":
                        imagen = ImageIO.read(new File("./src/Imagenes/Pollo2.png"));
                        break;
                    case "Maria":
                        imagen = ImageIO.read(new File("./src/Imagenes/Pollo3.png"));
                        break;
                }
                
                ImageIcon imageIcon = new ImageIcon(imagen);
                
                labelesPollos.get(posicion).setIcon(imageIcon);
                labelesPollos.get(posicion).setVisible(estado);
            } else {
                labelesPollos.get(posicion).setVisible(false);
                
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    /**
     * Método getter de PrecioCombustible.
     *
     * @return JTextField
     */
    public JLabel getLabelPrecioCombustible() {
        return labelPrecioCombustible;
    }

    /**
     * Método getter de PrecioKWh.
     *
     * @return JTextField
     */
    public JLabel getLabelPrecioKWh() {
        return labelPrecioKWh;
    }

    /**
     * Método getter de RecaudacionElectrico.
     *
     * @return JTextField
     */
    public JLabel getLabelRecaudacionElectrico() {
        return labelRecaudacionElectrico;
    }

    /**
     * Método getter de RecaudacionGasolina.
     *
     * @return JTextField
     */
    public JLabel getLabelRecaudacionGasolina() {
        return labelRecaudacionGasolina;
    }

    /**
     * Método getter de LogOut.
     *
     * @return JTextField
     */
    public JTextArea getLogOut() {
        return logOut;
    }

    /**
     * Método que se encarga de modificar el oclor de la imagen que sale por
     * pantalla.
     *
     * @param image : BufferedImage
     * @param miColor : Color
     * @return image : BufferedImage
     */
    public BufferedImage cambiarColorImagen(BufferedImage image, Color miColor) {
        int width = image.getWidth();
        int height = image.getHeight();
        WritableRaster raster = image.getRaster();
        
        for (int xx = 0; xx < width; xx++) {
            for (int yy = 0; yy < height; yy++) {
                int[] pixels = raster.getPixel(xx, yy, (int[]) null);
                pixels[0] = miColor.getRed();
                pixels[1] = miColor.getGreen();
                pixels[2] = miColor.getBlue();
                raster.setPixel(xx, yy, pixels);
            }
        }
        return image;
    }

    /**
     * Método que pinta las imagenes por pantalla.
     */
    private void pintarPantalla() {
        // Pintamos las imagenes de los Surtidores:
        labelSurtidor1.setIcon(new ImageIcon(getClass().getResource("/Imagenes/SurtidorPequeñoVerde.png")));
        labelSurtidor2.setIcon(new ImageIcon(getClass().getResource("/Imagenes/SurtidorPequeñoVerde.png")));
        labelSurtidor3.setIcon(new ImageIcon(getClass().getResource("/Imagenes/SurtidorPequeñoVerde.png")));
        labelSurtidor4.setIcon(new ImageIcon(getClass().getResource("/Imagenes/SurtidorPequeñoRojo.png")));
        labelSurtidor5.setIcon(new ImageIcon(getClass().getResource("/Imagenes/SurtidorPequeñoRojo.png")));
        labelSurtidor6.setIcon(new ImageIcon(getClass().getResource("/Imagenes/SurtidorPequeñoRojo.png")));
        labelSurtidor7.setIcon(new ImageIcon(getClass().getResource("/Imagenes/SurtidorGrandeRojo.png")));
        labelSurtidor8.setIcon(new ImageIcon(getClass().getResource("/Imagenes/SurtidorGrandeRojo.png")));
        // Crear los ArrayList con Labeles dentro
        iniciarLabelesCoches();
        iniciarLabelesPollos();
        iniciarLabelesInfo();
        iniciarLabelesMatriculas();
    }

    /**
     * Método que inicia los label de las matriculas del programa.
     *
     */
    private void iniciarLabelesMatriculas() {
        labelesMatriculas.add(labelMatricula1);
        labelesMatriculas.add(labelMatricula2);
        labelesMatriculas.add(labelMatricula3);
        labelesMatriculas.add(labelMatricula4);
        labelesMatriculas.add(labelMatricula5);
        labelesMatriculas.add(labelMatricula6);
        labelesMatriculas.add(labelMatricula7);
        labelesMatriculas.add(labelMatricula8);
        for (int i = 0; i < labelesMatriculas.size(); i++) {
            labelesMatriculas.get(i).setVisible(false);
        }
    }

    /**
     * Método que inicia los label de los vehiculos del programa.
     *
     */
    private void iniciarLabelesCoches() {
        
        labelesCoches.add(labelCoche1);
        labelesCoches.add(labelCoche2);
        labelesCoches.add(labelCoche3);
        labelesCoches.add(labelCoche4);
        labelesCoches.add(labelCoche5);
        labelesCoches.add(labelCoche6);
        labelesCoches.add(labelCoche7);
        labelesCoches.add(labelCoche8);
        for (int i = 0; i < labelesCoches.size(); i++) {
            labelesCoches.get(i).setVisible(false);
        }
    }

    /**
     * Método que inicia los label de la informacion del programa.
     *
     */
    private void iniciarLabelesInfo() {
        
        labelesInfo.add(labelInfo1);
        labelesInfo.add(labelInfo2);
        labelesInfo.add(labelInfo3);
        labelesInfo.add(labelInfo4);
        labelesInfo.add(labelInfo5);
        labelesInfo.add(labelInfo6);
        labelesInfo.add(labelInfo7);
        labelesInfo.add(labelInfo8);
        
    }

    /**
     * Método que inicia los label de los operarios del programa.
     *
     */
    private void iniciarLabelesPollos() {
        labelesPollos.add(labelPollo1);
        labelesPollos.add(labelPollo2);
        labelesPollos.add(labelPollo3);
        labelesPollos.add(labelPollo4);
        labelesPollos.add(labelPollo5);
        labelesPollos.add(labelPollo6);
        labelesPollos.add(labelPollo7);
        labelesPollos.add(labelPollo8);
        for (int i = 0; i < labelesPollos.size(); i++) {
            labelesPollos.get(i).setVisible(false);
        }
    }


    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        labelSurtidor8 = new javax.swing.JLabel();
        labelSurtidor1 = new javax.swing.JLabel();
        labelSurtidor3 = new javax.swing.JLabel();
        labelSurtidor5 = new javax.swing.JLabel();
        labelCoche7 = new javax.swing.JLabel();
        labelSurtidor6 = new javax.swing.JLabel();
        labelSurtidor7 = new javax.swing.JLabel();
        labelPollo6 = new javax.swing.JLabel();
        labelCoche4 = new javax.swing.JLabel();
        labelSurtidor2 = new javax.swing.JLabel();
        labelPrecioCombustible = new javax.swing.JLabel();
        labelCoche5 = new javax.swing.JLabel();
        labelCoche3 = new javax.swing.JLabel();
        labelCoche2 = new javax.swing.JLabel();
        labelPollo2 = new javax.swing.JLabel();
        labelPollo3 = new javax.swing.JLabel();
        labelPollo4 = new javax.swing.JLabel();
        labelPrecioKWh = new javax.swing.JLabel();
        labelPollo5 = new javax.swing.JLabel();
        labelCoche6 = new javax.swing.JLabel();
        labelPanelGasolinera = new javax.swing.JLabel();
        labelPollo7 = new javax.swing.JLabel();
        labelCoche8 = new javax.swing.JLabel();
        labelPollo8 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        labelCoche1 = new javax.swing.JLabel();
        labelPollo1 = new javax.swing.JLabel();
        labelInfo1 = new javax.swing.JLabel();
        labelInfo2 = new javax.swing.JLabel();
        labelInfo3 = new javax.swing.JLabel();
        labelSurtidor4 = new javax.swing.JLabel();
        labelInfo4 = new javax.swing.JLabel();
        labelInfo5 = new javax.swing.JLabel();
        labelInfo6 = new javax.swing.JLabel();
        labelInfo7 = new javax.swing.JLabel();
        labelInfo8 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        logOut = new javax.swing.JTextArea();
        jLabel2 = new javax.swing.JLabel();
        labelRecaudacionGasolina = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        labelRecaudacionElectrico = new javax.swing.JLabel();
        labelLitros1 = new javax.swing.JLabel();
        labelLitros2 = new javax.swing.JLabel();
        labelLitros3 = new javax.swing.JLabel();
        labelLitros4 = new javax.swing.JLabel();
        labelLitros5 = new javax.swing.JLabel();
        labelLitros6 = new javax.swing.JLabel();
        labelLitros7 = new javax.swing.JLabel();
        labelLitros8 = new javax.swing.JLabel();
        labelMatricula1 = new javax.swing.JLabel();
        labelMatricula2 = new javax.swing.JLabel();
        labelMatricula3 = new javax.swing.JLabel();
        labelMatricula4 = new javax.swing.JLabel();
        labelMatricula5 = new javax.swing.JLabel();
        labelMatricula6 = new javax.swing.JLabel();
        labelMatricula7 = new javax.swing.JLabel();
        labelMatricula8 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        BotonReanudar = new javax.swing.JButton();
        BotonParar = new javax.swing.JButton();
        Litros1 = new javax.swing.JLabel();
        Litros2 = new javax.swing.JLabel();
        Litros3 = new javax.swing.JLabel();
        Litros4 = new javax.swing.JLabel();
        Litros5 = new javax.swing.JLabel();
        Litros6 = new javax.swing.JLabel();
        Litros7 = new javax.swing.JLabel();
        Litros8 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setMinimumSize(new java.awt.Dimension(1380, 880));
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        labelSurtidor8.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/SurtidorGrandeRojo.png"))); // NOI18N
        getContentPane().add(labelSurtidor8, new org.netbeans.lib.awtextra.AbsoluteConstraints(1120, 110, 200, -1));
        getContentPane().add(labelSurtidor1, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 320, 200, -1));

        labelSurtidor3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/SurtidorPequeñoRojo.png"))); // NOI18N
        getContentPane().add(labelSurtidor3, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 50, 200, -1));

        labelSurtidor5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/SurtidorPequeñoRojo.png"))); // NOI18N
        getContentPane().add(labelSurtidor5, new org.netbeans.lib.awtextra.AbsoluteConstraints(630, 180, 200, 130));

        labelCoche7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/Autobus.png"))); // NOI18N
        getContentPane().add(labelCoche7, new org.netbeans.lib.awtextra.AbsoluteConstraints(1010, 310, 120, 120));

        labelSurtidor6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/SurtidorPequeñoRojo.png"))); // NOI18N
        getContentPane().add(labelSurtidor6, new org.netbeans.lib.awtextra.AbsoluteConstraints(810, 50, 200, -1));

        labelSurtidor7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/SurtidorGrandeRojo.png"))); // NOI18N
        getContentPane().add(labelSurtidor7, new org.netbeans.lib.awtextra.AbsoluteConstraints(940, 260, 200, -1));

        labelPollo6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/Pollo2.png"))); // NOI18N
        getContentPane().add(labelPollo6, new org.netbeans.lib.awtextra.AbsoluteConstraints(970, 90, 80, 110));

        labelCoche4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/CocheGasolina.png"))); // NOI18N
        getContentPane().add(labelCoche4, new org.netbeans.lib.awtextra.AbsoluteConstraints(520, 380, 120, 80));

        labelSurtidor2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/SurtidorPequeñoRojo.png"))); // NOI18N
        getContentPane().add(labelSurtidor2, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 180, 200, -1));

        labelPrecioCombustible.setFont(new java.awt.Font("Lucida Grande", 0, 24)); // NOI18N
        labelPrecioCombustible.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        getContentPane().add(labelPrecioCombustible, new org.netbeans.lib.awtextra.AbsoluteConstraints(1200, 590, 150, 50));

        labelCoche5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/CocheGasolina.png"))); // NOI18N
        getContentPane().add(labelCoche5, new org.netbeans.lib.awtextra.AbsoluteConstraints(710, 250, 120, 80));

        labelCoche3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/CocheElectrico.png"))); // NOI18N
        getContentPane().add(labelCoche3, new org.netbeans.lib.awtextra.AbsoluteConstraints(470, 110, 120, 80));

        labelCoche2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/CocheElectrico.png"))); // NOI18N
        getContentPane().add(labelCoche2, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 230, 120, 80));

        labelPollo2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/Pollo2.png"))); // NOI18N
        getContentPane().add(labelPollo2, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 210, 80, 100));

        labelPollo3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/Pollo2.png"))); // NOI18N
        getContentPane().add(labelPollo3, new org.netbeans.lib.awtextra.AbsoluteConstraints(550, 80, 80, 110));

        labelPollo4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/Pollo3.png"))); // NOI18N
        getContentPane().add(labelPollo4, new org.netbeans.lib.awtextra.AbsoluteConstraints(600, 350, 80, 110));

        labelPrecioKWh.setFont(new java.awt.Font("Lucida Grande", 0, 24)); // NOI18N
        labelPrecioKWh.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        getContentPane().add(labelPrecioKWh, new org.netbeans.lib.awtextra.AbsoluteConstraints(1190, 670, 150, 50));

        labelPollo5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/Pollo2.png"))); // NOI18N
        getContentPane().add(labelPollo5, new org.netbeans.lib.awtextra.AbsoluteConstraints(790, 220, 80, 110));

        labelCoche6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/CocheGasolina.png"))); // NOI18N
        getContentPane().add(labelCoche6, new org.netbeans.lib.awtextra.AbsoluteConstraints(890, 120, 120, 80));

        labelPanelGasolinera.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/PanelGasolinera.png"))); // NOI18N
        getContentPane().add(labelPanelGasolinera, new org.netbeans.lib.awtextra.AbsoluteConstraints(1180, 340, -1, 510));

        labelPollo7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/Pollo2.png"))); // NOI18N
        getContentPane().add(labelPollo7, new org.netbeans.lib.awtextra.AbsoluteConstraints(1080, 330, 80, 110));

        labelCoche8.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/Autobus.png"))); // NOI18N
        getContentPane().add(labelCoche8, new org.netbeans.lib.awtextra.AbsoluteConstraints(1190, 160, 120, 120));

        labelPollo8.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/Pollo2.png"))); // NOI18N
        getContentPane().add(labelPollo8, new org.netbeans.lib.awtextra.AbsoluteConstraints(1270, 180, 80, 110));
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(830, 590, -1, -1));

        labelCoche1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/CocheElectrico.png"))); // NOI18N
        getContentPane().add(labelCoche1, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 370, 120, 80));

        labelPollo1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/Pollo3.png"))); // NOI18N
        getContentPane().add(labelPollo1, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 350, 80, 110));

        labelInfo1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        getContentPane().add(labelInfo1, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 280, 120, 40));

        labelInfo2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        getContentPane().add(labelInfo2, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 150, 120, 40));

        labelInfo3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        getContentPane().add(labelInfo3, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 20, 120, 40));

        labelSurtidor4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/SurtidorPequeñoRojo.png"))); // NOI18N
        getContentPane().add(labelSurtidor4, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 310, 200, -1));

        labelInfo4.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        getContentPane().add(labelInfo4, new org.netbeans.lib.awtextra.AbsoluteConstraints(510, 280, 120, 40));

        labelInfo5.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        getContentPane().add(labelInfo5, new org.netbeans.lib.awtextra.AbsoluteConstraints(690, 140, 120, 40));

        labelInfo6.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        getContentPane().add(labelInfo6, new org.netbeans.lib.awtextra.AbsoluteConstraints(880, 20, 120, 40));

        labelInfo7.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        getContentPane().add(labelInfo7, new org.netbeans.lib.awtextra.AbsoluteConstraints(1000, 230, 120, 40));

        labelInfo8.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        getContentPane().add(labelInfo8, new org.netbeans.lib.awtextra.AbsoluteConstraints(1180, 80, 120, 40));

        logOut.setColumns(20);
        logOut.setRows(5);
        jScrollPane1.setViewportView(logOut);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 480, 750, 370));

        jLabel2.setFont(new java.awt.Font("Lucida Grande", 1, 16)); // NOI18N
        jLabel2.setText("Recaudacion Gasolina:");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 600, 200, 30));

        labelRecaudacionGasolina.setFont(new java.awt.Font("Lucida Grande", 1, 16)); // NOI18N
        labelRecaudacionGasolina.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        getContentPane().add(labelRecaudacionGasolina, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 590, 160, 40));

        jLabel3.setFont(new java.awt.Font("Lucida Grande", 1, 16)); // NOI18N
        jLabel3.setText("Recaudacion Kwh:");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 640, 160, -1));

        labelRecaudacionElectrico.setFont(new java.awt.Font("Lucida Grande", 1, 16)); // NOI18N
        labelRecaudacionElectrico.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        getContentPane().add(labelRecaudacionElectrico, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 630, 150, 40));
        getContentPane().add(labelLitros1, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 360, 20, 20));
        getContentPane().add(labelLitros2, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 260, 20, 20));
        getContentPane().add(labelLitros3, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 130, 20, 20));
        getContentPane().add(labelLitros4, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 390, 20, 20));
        getContentPane().add(labelLitros5, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 250, 20, 20));
        getContentPane().add(labelLitros6, new org.netbeans.lib.awtextra.AbsoluteConstraints(840, 120, 20, 20));
        getContentPane().add(labelLitros7, new org.netbeans.lib.awtextra.AbsoluteConstraints(960, 360, 20, 20));
        getContentPane().add(labelLitros8, new org.netbeans.lib.awtextra.AbsoluteConstraints(1140, 210, 20, 20));

        labelMatricula1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        getContentPane().add(labelMatricula1, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 330, 110, 30));

        labelMatricula2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        getContentPane().add(labelMatricula2, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 200, 90, 30));

        labelMatricula3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        getContentPane().add(labelMatricula3, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 70, 80, 30));

        labelMatricula4.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        getContentPane().add(labelMatricula4, new org.netbeans.lib.awtextra.AbsoluteConstraints(480, 330, 80, 30));

        labelMatricula5.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        getContentPane().add(labelMatricula5, new org.netbeans.lib.awtextra.AbsoluteConstraints(670, 190, 80, 30));

        labelMatricula6.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        getContentPane().add(labelMatricula6, new org.netbeans.lib.awtextra.AbsoluteConstraints(860, 60, 80, 30));

        labelMatricula7.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        getContentPane().add(labelMatricula7, new org.netbeans.lib.awtextra.AbsoluteConstraints(980, 280, 80, 30));

        labelMatricula8.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        getContentPane().add(labelMatricula8, new org.netbeans.lib.awtextra.AbsoluteConstraints(1160, 130, 80, 30));

        jLabel4.setFont(new java.awt.Font("Lucida Grande", 1, 14)); // NOI18N
        jLabel4.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel4.setText("8");
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(1120, 130, 20, 20));

        jLabel5.setFont(new java.awt.Font("Lucida Grande", 1, 14)); // NOI18N
        jLabel5.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel5.setText("1");
        getContentPane().add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 330, 20, 20));

        jLabel6.setFont(new java.awt.Font("Lucida Grande", 1, 14)); // NOI18N
        jLabel6.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel6.setText("2");
        getContentPane().add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 200, 20, 20));

        jLabel7.setFont(new java.awt.Font("Lucida Grande", 1, 14)); // NOI18N
        jLabel7.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel7.setText("3");
        getContentPane().add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 70, 20, 20));

        jLabel8.setFont(new java.awt.Font("Lucida Grande", 1, 14)); // NOI18N
        jLabel8.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel8.setText("4");
        getContentPane().add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 330, 20, 20));

        jLabel9.setFont(new java.awt.Font("Lucida Grande", 1, 14)); // NOI18N
        jLabel9.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel9.setText("5");
        getContentPane().add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(630, 200, 20, 20));

        jLabel10.setFont(new java.awt.Font("Lucida Grande", 1, 14)); // NOI18N
        jLabel10.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel10.setText("6");
        getContentPane().add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(810, 70, 20, 20));

        jLabel11.setFont(new java.awt.Font("Lucida Grande", 1, 14)); // NOI18N
        jLabel11.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel11.setText("7");
        getContentPane().add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(940, 280, 20, 20));

        BotonReanudar.setText("Reanudar");
        BotonReanudar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BotonReanudarActionPerformed(evt);
            }
        });
        getContentPane().add(BotonReanudar, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 740, 110, 70));

        BotonParar.setText("Parar");
        BotonParar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BotonPararActionPerformed(evt);
            }
        });
        getContentPane().add(BotonParar, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 740, 120, 70));
        getContentPane().add(Litros1, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 280, 50, 40));
        getContentPane().add(Litros2, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 150, 50, 40));
        getContentPane().add(Litros3, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 20, 50, 40));
        getContentPane().add(Litros4, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 280, 50, 40));
        getContentPane().add(Litros5, new org.netbeans.lib.awtextra.AbsoluteConstraints(630, 140, 50, 40));
        getContentPane().add(Litros6, new org.netbeans.lib.awtextra.AbsoluteConstraints(810, 20, 50, 40));
        getContentPane().add(Litros7, new org.netbeans.lib.awtextra.AbsoluteConstraints(940, 230, 50, 40));
        getContentPane().add(Litros8, new org.netbeans.lib.awtextra.AbsoluteConstraints(1120, 70, 50, 40));

        jLabel12.setFont(new java.awt.Font("Impact", 3, 48)); // NOI18N
        jLabel12.setText("CLIENTE");
        getContentPane().add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 50, 180, 80));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    /**
     * Método que se encarga de reanudar la entrada de los coches.
     *
     * @param evt : java.awt.event.ActionEvent
     */
    private void BotonReanudarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BotonReanudarActionPerformed
        // TODO add your handling code here:
        try {
            boolean cerrar = false;
            salida = new ObjectOutputStream(socketEjecucion.getOutputStream());
            entrada = new ObjectInputStream(socketEjecucion.getInputStream());
            salida.writeObject(cerrar);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }//GEN-LAST:event_BotonReanudarActionPerformed

    /**
     * Método que se encarga de detener la entrada a los coches.
     *
     * @param evt : java.awt.event.ActionEvent
     */
    private void BotonPararActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BotonPararActionPerformed
        // TODO add your handling code here:
        try {
            boolean cerrar = true;
            salida = new ObjectOutputStream(socketEjecucion.getOutputStream());
            entrada = new ObjectInputStream(socketEjecucion.getInputStream());
            salida.writeObject(cerrar);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }//GEN-LAST:event_BotonPararActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Cliente.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Cliente.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Cliente.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Cliente.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Cliente().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton BotonParar;
    private javax.swing.JButton BotonReanudar;
    private javax.swing.JLabel Litros1;
    private javax.swing.JLabel Litros2;
    private javax.swing.JLabel Litros3;
    private javax.swing.JLabel Litros4;
    private javax.swing.JLabel Litros5;
    private javax.swing.JLabel Litros6;
    private javax.swing.JLabel Litros7;
    private javax.swing.JLabel Litros8;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel labelCoche1;
    private javax.swing.JLabel labelCoche2;
    private javax.swing.JLabel labelCoche3;
    private javax.swing.JLabel labelCoche4;
    private javax.swing.JLabel labelCoche5;
    private javax.swing.JLabel labelCoche6;
    private javax.swing.JLabel labelCoche7;
    private javax.swing.JLabel labelCoche8;
    private javax.swing.JLabel labelInfo1;
    private javax.swing.JLabel labelInfo2;
    private javax.swing.JLabel labelInfo3;
    private javax.swing.JLabel labelInfo4;
    private javax.swing.JLabel labelInfo5;
    private javax.swing.JLabel labelInfo6;
    private javax.swing.JLabel labelInfo7;
    private javax.swing.JLabel labelInfo8;
    private javax.swing.JLabel labelLitros1;
    private javax.swing.JLabel labelLitros2;
    private javax.swing.JLabel labelLitros3;
    private javax.swing.JLabel labelLitros4;
    private javax.swing.JLabel labelLitros5;
    private javax.swing.JLabel labelLitros6;
    private javax.swing.JLabel labelLitros7;
    private javax.swing.JLabel labelLitros8;
    private javax.swing.JLabel labelMatricula1;
    private javax.swing.JLabel labelMatricula2;
    private javax.swing.JLabel labelMatricula3;
    private javax.swing.JLabel labelMatricula4;
    private javax.swing.JLabel labelMatricula5;
    private javax.swing.JLabel labelMatricula6;
    private javax.swing.JLabel labelMatricula7;
    private javax.swing.JLabel labelMatricula8;
    private javax.swing.JLabel labelPanelGasolinera;
    private javax.swing.JLabel labelPollo1;
    private javax.swing.JLabel labelPollo2;
    private javax.swing.JLabel labelPollo3;
    private javax.swing.JLabel labelPollo4;
    private javax.swing.JLabel labelPollo5;
    private javax.swing.JLabel labelPollo6;
    private javax.swing.JLabel labelPollo7;
    private javax.swing.JLabel labelPollo8;
    private javax.swing.JLabel labelPrecioCombustible;
    private javax.swing.JLabel labelPrecioKWh;
    private javax.swing.JLabel labelRecaudacionElectrico;
    private javax.swing.JLabel labelRecaudacionGasolina;
    private javax.swing.JLabel labelSurtidor1;
    public static javax.swing.JLabel labelSurtidor2;
    private javax.swing.JLabel labelSurtidor3;
    private javax.swing.JLabel labelSurtidor4;
    private javax.swing.JLabel labelSurtidor5;
    private javax.swing.JLabel labelSurtidor6;
    private javax.swing.JLabel labelSurtidor7;
    private javax.swing.JLabel labelSurtidor8;
    private javax.swing.JTextArea logOut;
    // End of variables declaration//GEN-END:variables
}
