/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package servidor;

import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Clase que crea un SocketEscuchador de comunicacion.
 *
 * @author CristianDiaz,ManuelaLopez
 */
public class SocketEscuchador extends Thread {

    private Gasolinera gasolinera;
    private Paso paso;
    private ExecutorService pool;
    private Utilidades util;
    public ArrayList<SocketServidor> hilos = new ArrayList<>();

    /**
     * Constructor de la clase SocketEscuchador.
     *
     * @param util : Utilidades es una clase multiusos.
     * @param gasolinera : Gasolinera
     * @param paso : Paso
     */
    public SocketEscuchador(Utilidades util, Gasolinera gasolinera, Paso paso) {
        this.gasolinera = gasolinera;
        this.util = util;
        this.paso = paso;
        pool = Executors.newFixedThreadPool(10);
    }

    /**
     * Método que arranca el hilo al ser lanzado.
     */
    public void run() {
        ServerSocket ss;

        try {
            ss = new ServerSocket(2222);
            while (true) {

                Socket socket = ss.accept();

                SocketServidor servidor = new SocketServidor(util, gasolinera, socket, paso, hilos);
                pool.execute(servidor);

            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

}
