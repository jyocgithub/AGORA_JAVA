package servidor;

import java.io.Serializable;

/**
 * Clase que crea un Operario
 * @author CristianDiaz,ManuelaLopez
 */
public class Operario implements Serializable {

    public static final int LIBRE = 0;
    public static final int OCUPADO = 1;

    private String nombre;
    public int estado;
    
     /**
     * Constructor de la clase Operario.
     *
     * @param nombre : String
     */
    public Operario(String nombre) {
        this.nombre = nombre;
        estado = LIBRE;
    }

     /**
     * Método getter de Nombre.
     *
     * @return nombre : Nombre
     */
    public String getNombre() {
        return nombre;
    }

     /**
     * Metodo setter del Nombre.
     *
     * @param nombre : String
     */
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    
     /**
     * Método getter de EstadoString.
     *
     * @return devolver : String
     */
    public String getEstadoString() {
        String devolver = " ";
        switch (estado) {
            case OCUPADO:
                devolver = "OCUPADO";
                break;

            case LIBRE:
                devolver = "LIBRE";
                break;

        }
        return devolver;
    }

     /**
     * Método getter de Estado.
     *
     * @return estado : int
     */
    public int getEstado() {
        return estado;
    }

     /**
     * Metodo setter del Estado.
     *
     * @param estado : int
     */
    public void setEstado(int estado) {
        this.estado = estado;
    }
}
