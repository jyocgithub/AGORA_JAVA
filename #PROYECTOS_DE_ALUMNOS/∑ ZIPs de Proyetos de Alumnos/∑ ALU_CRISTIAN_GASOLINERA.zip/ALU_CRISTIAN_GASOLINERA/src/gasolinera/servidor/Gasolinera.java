package servidor;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.concurrent.Semaphore;


/**
 * Clase que crea una Gasolinera.
 * @author CristianDiaz,ManuelaLopez
 */
public class Gasolinera implements Serializable {

    private Utilidades util;

    private int tiempoMaximoRepostar = 5000;
    private int tiempoMinimoRepostar = 2000;

    private double saldoCombustible = 0;
    private double saldoElectrico = 0;
    private double precioLitroCombustible = 0;
    private double precioKW = 0;
    private Paso paso;

    private int maximoSurtidoresCombustible;
    private int maximoSurtidoresElectricos;
    private int maximoSurtidoresPesados;

    private ArrayList<Surtidor> surtidoresCombustible;
    private ArrayList<Surtidor> surtidoresElectricos;
    private ArrayList<Surtidor> surtidoresPesados;

    private Semaphore surtidoresCombustible_Semaphore;
    private Semaphore surtidoresElectricos_Semaphore;
    private Semaphore surtidoresPesados_Semaphore;

    private Semaphore cochesAtender;

    /**
     * Constructor de la clase Gasolinera.
     *
     * @param util : Utilidades es una clase multiusos.
     * @param maximoSurtidoresCombustible : int limite de Surtidores de
     * Combustible.
     * @param maximoSurtidoresElectricos : int limite de Suritidores de
     * Electricidad.
     * @param maximoSurtidoresPesados : int limite de Surtidores de vehiculos
     * Pesados.
     * @param precioLitroCombustible : double
     * @param precioKW : double
     * @param paso : Paso
     */
    public Gasolinera(Utilidades util, int maximoSurtidoresCombustible, int maximoSurtidoresElectricos, int maximoSurtidoresPesados, double precioLitroCombustible, double precioKW, Paso paso) {
        try {

            this.maximoSurtidoresCombustible = maximoSurtidoresCombustible;
            this.maximoSurtidoresElectricos = maximoSurtidoresElectricos;
            this.maximoSurtidoresPesados = maximoSurtidoresPesados;
            this.precioLitroCombustible = precioLitroCombustible;
            this.precioKW = precioKW;
            this.paso = paso;
            this.util = util;

            surtidoresCombustible = new ArrayList<>();
            for (int i = 0; i < maximoSurtidoresCombustible; i++) {
                surtidoresCombustible.add(new Surtidor(i, Surtidor.COMBUSTIBLE));
            }

            surtidoresElectricos = new ArrayList<>();
            for (int i = 0; i < maximoSurtidoresElectricos; i++) {
                surtidoresElectricos.add(new Surtidor(i, Surtidor.ELECTRICO));
            }

            surtidoresPesados = new ArrayList<>();
            for (int i = 0; i < maximoSurtidoresPesados; i++) {
                surtidoresPesados.add(new Surtidor(i, Surtidor.PESADOS));
            }

        } catch (Exception ex) {
            ex.printStackTrace();
        }

        surtidoresCombustible_Semaphore = new Semaphore(maximoSurtidoresCombustible, true);
        surtidoresElectricos_Semaphore = new Semaphore(maximoSurtidoresElectricos, true);
        surtidoresPesados_Semaphore = new Semaphore(maximoSurtidoresPesados, true);
        cochesAtender = new Semaphore(0, true);
    }

    /**
     * Método que se encarga de que un operario atienda un vehiculo, se debe
     * coprobar que tipo de vehiculo es el que va a ser atendido. Tras ser
     * atendido el surtidor quedara libre.
     *
     * @param ho : HiloOperario
     */
    public void atenderVehiculo(HiloOperario ho) {
        Surtidor surtidor = null;
        try {
            cochesAtender.acquire();
            paso.mirar();
            surtidor = mirarSurtidores(ho);
            paso.mirar();
            if (surtidor != null) { // En este caso hay algun coche en un surtidor

                switch (surtidor.getVehiculo().getTipoVehiculo()) {
                    case Vehiculo.ELECTRICO:
                        paso.mirar();
                        paso.mirar();
                        echarKW(surtidor.getVehiculo(), surtidor.getId());
                        paso.mirar();
                        util.sout(surtidor.getVehiculo().getMatricula() + " libera el surtidor: " + (surtidor.getId() + 1));
                        paso.mirar();
                        break;
                    case Vehiculo.COMBUSTIBLE:
                        paso.mirar();
                        echarGasofa(surtidor.getVehiculo(), surtidor.getId());
                        paso.mirar();
                        util.sout(surtidor.getVehiculo().getMatricula() + " libera el surtidor: " + (surtidor.getId() + 4));
                        break;
                    case Vehiculo.PESADO:
                        paso.mirar();
                        echarGasofa(surtidor.getVehiculo(), surtidor.getId());
                        paso.mirar();
                        util.sout(surtidor.getVehiculo().getMatricula() + " libera el surtidor: " + (surtidor.getId() + 7));
                        paso.mirar();
                        break;

                }
                paso.mirar();
                util.sout("Libre el operario: " + ho.getOperario().getNombre());
                surtidor.setPollo(null);
                paso.mirar();
                surtidor.cambiarContinuar(true);
                paso.mirar();
                continuar();
                paso.mirar();

                paso.mirar();

            } else {
                System.out.println("-------**********************------SUUUUUUUUUUURRRRRRTIIIIIIDOOOOOOR NULO/////" + ho.getOperario().getNombre());
            }

        } catch (InterruptedException ex) {
            ex.printStackTrace();
        }
    }

    /**
     * Método getter de SurtidoresCombustible.
     *
     * @return surtidoresCombustible : ArrayList
     */
    public ArrayList<Surtidor> getSurtidoresCombustible() {
        return surtidoresCombustible;
    }

    /**
     * Método getter de SurtidoresPesados.
     *
     * @return surtidoresPesados : ArrayList
     */
    public ArrayList<Surtidor> getSurtidoresPesados() {
        return surtidoresPesados;
    }

    /**
     * Método que consulta el estado del Surtidor, si esta ocupado se bloquea.
     *
     * @param surtidor : Surtidor
     */
    public synchronized void esperar(Surtidor surtidor) {
        try {
            while (surtidor.consultarContinuar() == false) {
                wait();
            }

        } catch (InterruptedException ex) {
            ex.printStackTrace();
        }
    }

    /**
     * Método que se encarga de liberar un Surtidor. Se debe tener en cuenta el
     * tipo de Vehiculo.
     *
     * @param surtidor : Surtidor
     */
    public void liberarSurtidor(Surtidor surtidor) {

        switch (surtidor.getCombustible()) {

            case Surtidor.COMBUSTIBLE:
                paso.mirar();
                util.espera(1000, 1500);
                paso.mirar();
                surtidoresCombustible_Semaphore.release();
                break;
            case Surtidor.ELECTRICO:
                paso.mirar();
                util.espera(1000, 1500);
                paso.mirar();
                surtidoresElectricos_Semaphore.release();
                break;
            case Surtidor.PESADOS:
                paso.mirar();
                paso.mirar();
                util.espera(1000, 1500);
                surtidoresPesados_Semaphore.release();
        }
        surtidor.setVehiculo(null);

        surtidor.setEstado(Surtidor.LIBRE);

    }

    /**
     * Método que despierta a los hilos dormidos por la espera a ser atendidos.
     *
     */
    public synchronized void continuar() {
        notifyAll();
    }

    /**
     * Método que se ocupa de retornar que surtidor esta libre, tras eso cambia
     * el estado del surtidor a REPOSTANDO. Se consulta que tipo de Vehiculo es.
     *
     * @param ho : HiloOperario
     * @return surtidor : Surtidor
     */
    public synchronized Surtidor mirarSurtidores(HiloOperario ho) {
        Surtidor surtidor = null;
        boolean seguir = true;

        for (int i = 0; i < maximoSurtidoresElectricos && seguir; i++) {
            if (surtidoresElectricos.get(i).getEstado() == Surtidor.OCUPADO) {
                surtidor = surtidoresElectricos.get(i);
                seguir = false;
                surtidoresElectricos.get(i).setEstado(Surtidor.REPOSTANDO);
                surtidoresElectricos.get(i).setPollo(ho.getOperario());
            }
        }
        if (seguir) {
            for (int i = 0; i < maximoSurtidoresCombustible && seguir; i++) {
                if (surtidoresCombustible.get(i).getEstado() == Surtidor.OCUPADO) {
                    surtidor = surtidoresCombustible.get(i);
                    seguir = false;
                    surtidoresCombustible.get(i).setEstado(Surtidor.REPOSTANDO);
                    surtidoresCombustible.get(i).setPollo(ho.getOperario());
                }
            }
        }
        if (seguir) {
            for (int i = 0; i < maximoSurtidoresPesados && seguir; i++) {
                if (surtidoresPesados.get(i).getEstado() == Surtidor.OCUPADO) {
                    surtidor = surtidoresPesados.get(i);
                    seguir = false;
                    surtidoresPesados.get(i).setEstado(Surtidor.REPOSTANDO);
                    surtidoresPesados.get(i).setPollo(ho.getOperario());
                }
            }
        }

        return surtidor;
    }

    /**
     * Método que, mediante un semaforo, coge un surtidor Electrico y cambia su
     * estado. Si hay algun error devuelve -1.
     *
     * @param hv : HiloVehiculo
     * @return surtidor : Surtidor
     */
    public Surtidor cogerSurtidorElectrico(HiloVehiculo hv) {
        int numeroSurtidor = -1;
        try {
            surtidoresElectricos_Semaphore.acquire();
            numeroSurtidor = escogerSurtidorElectrico(hv);
            surtidoresElectricos.get(numeroSurtidor).cambiarContinuar(false);

        } catch (InterruptedException ex) {
            ex.printStackTrace();
        }
        return surtidoresElectricos.get(numeroSurtidor);
    }

    /**
     * Método que busca y escoge un surtidor Electrico que este libre y asi
     * asignarle un vehiculo, se devuelve la posicion del surtidor seleccionado.
     * Si hay algun error devuelve -1.
     *
     * @param hv : HiloVehiculo
     * @return posicion : int
     */
    public synchronized int escogerSurtidorElectrico(HiloVehiculo hv) {
        int posicion = -1;
        boolean seguir = true;
        for (int i = 0; i < surtidoresElectricos.size() && seguir; i++) {
            if (surtidoresElectricos.get(i).getEstado() == Surtidor.LIBRE) {
                posicion = i;
                seguir = false;
                surtidoresElectricos.get(i).setEstado(Surtidor.OCUPADO);
                surtidoresElectricos.get(i).setVehiculo(hv.getVehiculo());
                util.sout(hv.getVehiculo().getMatricula() + " entra en el surtidor: " + (i + 1)); // Tipificar mensajes

                cochesAtender.release();
            }
        }
        return posicion;
    }

    /**
     * Método que, mediante un semaforo, coge un surtidor de vehiculos Pesados y
     * cambia su estado. Si hay algun error devuelve -1.
     *
     * @param hv : HiloVehiculo
     * @return surtidor : Surtidor
     */
    public Surtidor cogerSurtidorPesados(HiloVehiculo hv) {
        int numeroSurtidor = -1;
        try {
            surtidoresPesados_Semaphore.acquire();
            numeroSurtidor = escogerSurtidorPesados(hv);
            surtidoresPesados.get(numeroSurtidor).cambiarContinuar(false);
        } catch (InterruptedException ex) {
            ex.printStackTrace();
        }
        return surtidoresPesados.get(numeroSurtidor);
    }

    /**
     * Método que busca y escoge un surtidor de vehiculos Pesados que este libre
     * y asi asignarle un vehiculo, se devuelve la posicion del surtidor
     * seleccionado. Si hay algun error devuelve -1.
     *
     * @param hv : HiloVehiculo
     * @return posicion : int
     */
    public synchronized int escogerSurtidorPesados(HiloVehiculo hv) {
        int posicion = -1;
        boolean continuar = true;
        for (int i = 0; i < surtidoresPesados.size() && continuar; i++) {
            if (surtidoresPesados.get(i).getEstado() == Surtidor.LIBRE) {
                posicion = i;
                continuar = false;
                surtidoresPesados.get(i).setEstado(Surtidor.OCUPADO);
                surtidoresPesados.get(i).setVehiculo(hv.getVehiculo());
                util.sout(hv.getVehiculo().getMatricula() + " entra en el surtidor: " + (i + 7)); // Tipificar mensajes

                cochesAtender.release();
            }
        }

        return posicion;
    }

    /**
     * Método que, mediante un semaforo, coge un surtidor de Combustible y
     * cambia su estado. Si hay algun error devuelve -1.
     *
     * @param hv : HiloVehiculo
     * @return surtidor : Surtidor
     */
    public Surtidor cogerSurtidorCombustible(HiloVehiculo hv) {
        int numeroSurtidor = -1;
        try {
            surtidoresCombustible_Semaphore.acquire();
            numeroSurtidor = escogerSurtidorCombustible(hv);
            surtidoresCombustible.get(numeroSurtidor).cambiarContinuar(false);

        } catch (InterruptedException ex) {
            ex.printStackTrace();
        }
        return surtidoresCombustible.get(numeroSurtidor);
    }

    /**
     * Método que busca y escoge un surtidor de Combustible que este libre y asi
     * asignarle un vehiculo, se devuelve la posicion del surtidor seleccionado.
     * Si hay algun error devuelve -1.
     *
     * @param hv : HiloVehiculo
     * @return posicion : int
     */
    public synchronized int escogerSurtidorCombustible(HiloVehiculo hv) {
        int posicion = -1;
        boolean continuar = true;
        for (int i = 0; i < surtidoresCombustible.size() && continuar; i++) {
            if (surtidoresCombustible.get(i).getEstado() == Surtidor.LIBRE) {
                posicion = i;
                continuar = false;
                surtidoresCombustible.get(i).setEstado(Surtidor.OCUPADO);
                surtidoresCombustible.get(i).setVehiculo(hv.getVehiculo());
                util.sout(hv.getVehiculo().getMatricula() + " entra en el surtidor: " + (i + 4)); // Tipificar mensajes

                cochesAtender.release();
            }
        }

        return posicion;
    }

    /**
     * Metodo que calcula el precio y muestra el numero de litros gasolina que
     * han sido repostados.
     *
     * @param v : Vehiculo
     * @param numeroSurtidor : int
     */
    public void echarGasofa(Vehiculo v, int numeroSurtidor) {
        String formato = " ";
        String formato2 = " ";
        int tiempo = util.aleatorio(tiempoMinimoRepostar, tiempoMaximoRepostar);
        int litrosRepostar = (tiempo / 1000) * 10;
        paso.mirar();
        v.setLitrosRepostados(litrosRepostar);
        util.espera(tiempo * 2, tiempo * 2);
        paso.mirar();
        double dinero = litrosRepostar * precioLitroCombustible;
        sumarDinero(dinero, Vehiculo.COMBUSTIBLE);
        paso.mirar();
        formato = String.format("%.2f", dinero);
        formato2 = String.format("%.2f", saldoCombustible);
        util.sout(v.getMatricula() + " litros repostados: " + litrosRepostar + " importe de: " + formato + " €" + " saldo total combustible: " + formato2 + " €");
    }

    /**
     * Metodo que calcula el precio y muestra el numero de kiloVatios que han
     * sido repostados.
     *
     * @param v : Vehiculo
     * @param numeroSurtidor : int
     */
    public void echarKW(Vehiculo v, int numeroSurtidor) {
        String formato = " ";
        String formato2 = " ";
        paso.mirar();
        int tiempo = util.aleatorio(tiempoMinimoRepostar * 3, tiempoMaximoRepostar * 3);
        int litrosRepostar = (tiempo / 1000) * 40;
        util.espera(tiempo, tiempo);
        paso.mirar();
        v.setLitrosRepostados(litrosRepostar);
        double dinero = litrosRepostar * precioKW;
        sumarDinero(dinero, Vehiculo.ELECTRICO);
        paso.mirar();
        formato = String.format("%.2f", dinero);
        formato2 = String.format("%.2f", saldoElectrico);
        util.sout(v.getMatricula() + " Kilowatios repostados: " + litrosRepostar + " importe de: " + formato + " €" + " saldo total Electricos: " + formato2 + " €");

    }

    /**
     * Metodo suma el dinero que cuesta repostar. Se tiene en cuenta que tipo de
     * energia se usa al repostar.
     *
     * @param dinero : double
     * @param tipo : int
     */
    public synchronized void sumarDinero(double dinero, int tipo) {

        switch (tipo) {
            case Vehiculo.COMBUSTIBLE:
                saldoCombustible += dinero;
                break;
            case Vehiculo.ELECTRICO:
                saldoElectrico += dinero;
                break;
        }

    }

    /**
     * Método getter de SurtidoresElectricos.
     *
     * @return ArrayList
     */
    public ArrayList<Surtidor> getSurtidoresElectricos() {
        return surtidoresElectricos;
    }

    /**
     * 0 * Método getter de Paso.
     *
     * @return paso : Paso
     */
    public Paso getPaso() {
        return paso;
    }

    /**
     * Método getter de SaldoCombustible.
     *
     * @return saldoCombustible : double
     */
    public double getSaldoCombustible() {
        return saldoCombustible;
    }

    /**
     * Método getter de SaldoElectrico.
     *
     * @return saldoElectrico : double
     */
    public double getSaldoElectrico() {
        return saldoElectrico;
    }

    /**
     * Método getter de PrecioLitroCombustible.
     *
     * @return precioLitroCombustible : double
     */
    public double getPrecioLitroCombustible() {
        return precioLitroCombustible;
    }

    /**
     * Método getter de PrecioKW.
     *
     * @return precioKW : double
     */
    public double getPrecioKW() {
        return precioKW;
    }
}
