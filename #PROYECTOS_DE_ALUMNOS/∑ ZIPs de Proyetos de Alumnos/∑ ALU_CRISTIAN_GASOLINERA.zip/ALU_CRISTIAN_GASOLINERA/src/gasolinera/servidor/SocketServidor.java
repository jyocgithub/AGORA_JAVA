package servidor;

import java.awt.Color;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.ArrayList;

/**
 * Clase que crea un SocketServidor para enviar datos.
 *
 * @author CristianDiaz,ManuelaLopez
 */
public class SocketServidor extends Thread {

    private Gasolinera gasolinera;
    private Socket socket;
    private ObjectOutputStream salida;
    private ObjectInputStream entrada;
    private Paso paso;
    private Utilidades util;

    private ArrayList<Color> coloresElectricos = new ArrayList<>();
    private ArrayList<String> estadosElectricos = new ArrayList<>();
    private ArrayList<String> matriculasElectricos = new ArrayList<>();
    private ArrayList<Operario> operariosElectricos = new ArrayList<>();

    private ArrayList<Color> coloresGasolina = new ArrayList<>();
    private ArrayList<String> estadosGasolina = new ArrayList<>();
    private ArrayList<String> matriculasGasolina = new ArrayList<>();
    private ArrayList<Operario> operariosGasolina = new ArrayList<>();

    private ArrayList<Color> coloresPesados = new ArrayList<>();
    private ArrayList<String> estadosPesados = new ArrayList<>();
    private ArrayList<String> matriculasPesados = new ArrayList<>();
    private ArrayList<Operario> operariosPesados = new ArrayList<>();

    public ArrayList<SocketServidor> hilos;

     /**
     * Constructor de la clase SocketServidor.
     *
     * @param util : Utilidades es una clase multiusos.
     * @param gasolinera : Gasolinera
     * @param socket : Socket
     * @param paso : Paso
     * @param hilos : ArrayList
     */
    public SocketServidor(Utilidades util, Gasolinera gasolinera, Socket socket, Paso paso, ArrayList<SocketServidor> hilos) {
        this.gasolinera = gasolinera;
        this.util = util;
        this.socket = socket;
        this.paso = paso;
        this.hilos = hilos;
    }

     /**
     * Método que arranca el hilo al ser lanzado.
     */
    public void run() {
        try {
            paso.mirar();
            salida = new ObjectOutputStream(socket.getOutputStream());
            paso.mirar();
            entrada = new ObjectInputStream(socket.getInputStream());
            paso.mirar();
            salida.writeObject(gasolinera.getPrecioLitroCombustible() + "");
            paso.mirar();
            salida.writeObject(gasolinera.getPrecioKW() + "");

            while (true) {
                try {
                    paso.mirar();
                    salida = new ObjectOutputStream(socket.getOutputStream());
                    paso.mirar();
                    entrada = new ObjectInputStream(socket.getInputStream());
                    paso.mirar();
                    enviarInfoElectricos();
                    paso.mirar();
                    enviarInfoGasolina();
                    paso.mirar();
                    enviarInfoPesados();
                    paso.mirar();
                    enviarRecaudaciones();
                    paso.mirar();
                    enviarLog();
                    paso.mirar();

                    sleep(10);
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

     /**
     * Método que envia el Log de la Gasolinera.
     *
     */
    public void enviarLog() {
        try {
            salida.writeObject(util.getLog());
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

     /**
     * Método que envia la ejecucion del programa.
     *
     */
    public void enviarEjecucion() {
        try {
            salida.writeObject(paso.getPulsado());
            salida.writeObject(paso.getEstado());
            paso.setPulsado(false);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

     /**
     * Método que recibe la ejecucion.
     *
     * @param pulsado : boolean
     * @param estado : boolean
     */
    public void recibirEjecucion2(boolean pulsado, boolean estado) {
        try {
            if (pulsado) {
                paso.setEstado(estado);
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

     /**
     * Método que envia las recaudaciones de la Gasolinera.
     *
     */
    public void enviarRecaudaciones() {
        try {
            salida.writeObject(gasolinera.getSaldoElectrico());
            salida.writeObject(gasolinera.getSaldoCombustible());
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

     /**
     * Método que envia la informacion de los vehiculos pesados en los surtidores.
     *
     */
    public void enviarInfoPesados() {
        String estado = " ";
        Vehiculo vehiculo;
        String matricula = " ";
        Operario operario = null;
        Color nulo = new Color(255, 255, 255);
        try {
            for (int i = 0; i < gasolinera.getSurtidoresPesados().size(); i++) {
                estado = gasolinera.getSurtidoresPesados().get(i).getEstadoString();
                operario = gasolinera.getSurtidoresPesados().get(i).getPollo();
                if (operario == null) {
                    operariosPesados.add(null);
                } else {
                    operariosPesados.add(operario);
                }
                estadosPesados.add(estado);
                vehiculo = gasolinera.getSurtidoresPesados().get(i).getVehiculo();
                if (vehiculo == null) {
                    coloresPesados.add(nulo);
                    matricula = null;
                } else {
                    coloresPesados.add(vehiculo.getColorCoche());
                    matricula = vehiculo.getMatricula();
                }
                matriculasPesados.add(matricula);
            }
            salida.writeObject(coloresPesados);
            coloresPesados.clear();
            salida.writeObject(estadosPesados);
            estadosPesados.clear();
            salida.writeObject(matriculasPesados);
            matriculasPesados.clear();
            salida.writeObject(operariosPesados);
            operariosPesados.clear();
        } catch (Exception ex) {
            ex.printStackTrace();
        }

    }

     /**
     * Método que envia la informacion de los vehiculos de gasolina en los surtidores.
     *
     */
    public void enviarInfoGasolina() {
        String estado = " ";
        Vehiculo vehiculo;
        String matricula = " ";
        Operario operario = null;
        Color nulo = new Color(255, 255, 255);
        try {
            for (int i = 0; i < gasolinera.getSurtidoresCombustible().size(); i++) {
                estado = gasolinera.getSurtidoresCombustible().get(i).getEstadoString();
                operario = gasolinera.getSurtidoresCombustible().get(i).getPollo();
                if (operario == null) {
                    operariosGasolina.add(null);
                } else {
                    operariosGasolina.add(operario);
                }
                estadosGasolina.add(estado);
                vehiculo = gasolinera.getSurtidoresCombustible().get(i).getVehiculo();
                if (vehiculo == null) {
                    coloresGasolina.add(nulo);
                    matricula = null;
                } else {
                    coloresGasolina.add(vehiculo.getColorCoche());
                    matricula = vehiculo.getMatricula();
                }
                matriculasGasolina.add(matricula);
            }
            salida.writeObject(coloresGasolina);
            coloresGasolina.clear();
            salida.writeObject(estadosGasolina);
            estadosGasolina.clear();
            salida.writeObject(matriculasGasolina);
            matriculasGasolina.clear();
            salida.writeObject(operariosGasolina);
            operariosGasolina.clear();
        } catch (Exception ex) {
            ex.printStackTrace();
        }

    }

    /**
     * Método que envia la informacion de los vehiculos electricos en los surtidores.
     *
     */
    public void enviarInfoElectricos() {
        String estado = " ";
        Vehiculo vehiculo;
        String matricula = " ";
        Operario operario = null;
        Color nulo = new Color(255, 255, 255);
        try {
            for (int i = 0; i < gasolinera.getSurtidoresElectricos().size(); i++) {
                estado = gasolinera.getSurtidoresElectricos().get(i).getEstadoString();
                operario = gasolinera.getSurtidoresElectricos().get(i).getPollo();
                if (operario == null) {
                    operariosElectricos.add(null);
                } else {
                    operariosElectricos.add(operario);
                }
                estadosElectricos.add(estado);
                vehiculo = gasolinera.getSurtidoresElectricos().get(i).getVehiculo();
                if (vehiculo == null) {
                    coloresElectricos.add(nulo);
                    matricula = null;
                } else {
                    coloresElectricos.add(vehiculo.getColorCoche());
                    matricula = vehiculo.getMatricula();
                }
                matriculasElectricos.add(matricula);
            }
            salida.writeObject(coloresElectricos);
            coloresElectricos.clear();
            salida.writeObject(estadosElectricos);
            estadosElectricos.clear();
            salida.writeObject(matriculasElectricos);
            matriculasElectricos.clear();
            salida.writeObject(operariosElectricos);
            operariosElectricos.clear();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

}
