/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package servidor;

import java.net.ServerSocket;
import java.net.Socket;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Clase que crea un SocketEscuchador de sincronizacion.
 *
 * @author CristianDiaz,ManuelaLopez
 */
public class SocketEscuchadorEjecucion extends Thread {

    private Paso paso;
    private ExecutorService pool;

     /**
     * Constructor de la clase SocketEscuchadorEjecucion.
     *
     * @param paso = Paso
     */
    public SocketEscuchadorEjecucion(Paso paso) {
        this.paso = paso;
        pool = Executors.newFixedThreadPool(10);
    }

     /**
     * Método que arranca el hilo al ser lanzado.
     */
    public void run() {
        ServerSocket ss;

        try {
            ss = new ServerSocket(4444);
            while (true) {

                Socket socket = ss.accept();

                SocketServidorEjecucion servidor = new SocketServidorEjecucion(paso, socket);
                pool.execute(servidor);

            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
}
