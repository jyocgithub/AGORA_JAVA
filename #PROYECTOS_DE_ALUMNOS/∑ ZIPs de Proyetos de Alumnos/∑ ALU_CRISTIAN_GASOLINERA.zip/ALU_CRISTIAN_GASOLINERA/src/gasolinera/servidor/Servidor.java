package servidor;

import static servidor.Vehiculo.COMBUSTIBLE;
import static servidor.Vehiculo.ELECTRICO;
import static servidor.Vehiculo.PESADO;
import java.awt.Color;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.awt.image.WritableRaster;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JLabel;

/**
 * Clase que crea la ventana Servidor.
 * @author CristianDiaz,ManuelaLopez
 */
public class Servidor extends javax.swing.JFrame {

    private Utilidades util = new Utilidades();

    private double precioCombustible = 1.429;
    private double precioKW = 0.147;
    private Color neutral = new Color(238, 238, 238);

    private Paso paso = new Paso();
    private Gasolinera gasolinera = new Gasolinera(util, 3, 3, 2, precioCombustible, precioKW, paso);

    private List<JLabel> labelesColaEspera = new ArrayList<>();

    private ExecutorService pool = Executors.newFixedThreadPool(20);

    private ArrayList<Vehiculo> colaEspera = new ArrayList<>(12);
    private ArrayList<JLabel> matriculas = new ArrayList<>(12);
    private Lock cerrojo = new ReentrantLock(true);
    private Condition lleno = cerrojo.newCondition();
    private Condition vacio = cerrojo.newCondition();

    /**
     * Constructor de la clase Servidor.
     */
    public Servidor() {
        initComponents();
        pintarPantalla();

        this.getContentPane().setBackground(Color.white);

        iniciarMatriculas();
        SocketEscuchador servidor = new SocketEscuchador(util, gasolinera, paso);
        servidor.start();
        SocketEscuchadorEjecucion servidorEjecucion = new SocketEscuchadorEjecucion(paso);
        servidorEjecucion.start();
        crearVehiculos(300);
        crearPollos();
        paso.cerrar();
        BotonReanudar.setBackground(Color.GREEN);
        BotonParar.setBackground(Color.red);

    }

    /**
     * Metodo que rellen aun ArrayList con labeles de matriculas
     */
    public void iniciarMatriculas() {
        matriculas.add(label0);
        matriculas.add(label1);
        matriculas.add(label2);
        matriculas.add(label3);
        matriculas.add(label4);
        matriculas.add(label5);
        matriculas.add(label6);
        matriculas.add(label7);
        matriculas.add(label8);
        matriculas.add(label9);
        matriculas.add(label10);
        matriculas.add(label11);

        for (int i = 0; i < matriculas.size(); i++) {
            matriculas.get(i).setVisible(false);
        }
    }

    /**
     * Método getter de ColaEspera.
     *
     * @return ArrayList
     */
    public ArrayList<Vehiculo> getColaEspera() {
        try {
            cerrojo.lock();
        } catch (Exception ex) {
            ex.printStackTrace();
        } finally {
            cerrojo.unlock();
        }
        return colaEspera;

    }

    /**
     * Metodo que añade un vehiculo a la cola de espera.
     *
     * @param v : vehiculo
     */
    public void añadirColaEspera(Vehiculo v) {
        try {
            cerrojo.lock();
            while (colaEspera.size() == 12) {
                lleno.await();
            }
            colaEspera.add(v);
            vacio.signal();
        } catch (Exception ex) {
            ex.printStackTrace();
        } finally {
            cerrojo.unlock();
        }
    }

    /**
     * Método que se encarga de borrar los elementos en espera.
     *
     * @param v : vehiculo
     */
    public void eliminarColaEspera(Vehiculo v) {
        try {
            cerrojo.lock();
            while (colaEspera.size() == 0) {
                vacio.await();
            }
            colaEspera.remove(v);
            lleno.signal();
        } catch (Exception ex) {
            ex.printStackTrace();
        } finally {
            cerrojo.unlock();
        }
    }

    /**
     * Método que se encarga de pintar los elementos en espera.
     */
    public void pintarColaEspera() {
        try {
            cerrojo.lock();
            int i = 0;
            Image imagen = null;
            for (; i < colaEspera.size() && i < 12; i++) {
                paso.mirar();
                try {

                    switch (colaEspera.get(i).getTipoVehiculo()) {
                        case ELECTRICO:
                            imagen = ImageIO.read(new File("./src/Imagenes/CocheElectrico.png"));
                            break;
                        case COMBUSTIBLE:
                            imagen = ImageIO.read(new File("./src/Imagenes/CocheGasolina.png"));
                            break;
                        case PESADO:
                            imagen = ImageIO.read(new File("./src/Imagenes/Autobus.png"));
                            break;
                    }
                    imagen = servidor.Servidor.cambiarColorImagen((BufferedImage) imagen, colaEspera.get(i).getColorCoche());
                } catch (IOException ex) {
                    ex.printStackTrace();
                }
                ImageIcon imageIcon = new ImageIcon(imagen);
                labelesColaEspera.get(i).setIcon(imageIcon);
                labelesColaEspera.get(i).setVisible(true);
                matriculas.get(i).setText(colaEspera.get(i).getMatricula());
                matriculas.get(i).setVisible(true);

            }
            for (int j = i; j < labelesColaEspera.size(); j++) {
                labelesColaEspera.get(j).setVisible(false);
                matriculas.get(j).setVisible(false);
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        } finally {
            cerrojo.unlock();
        }
    }

    /**
     * Método que crea los Operarios.
     */
    public void crearPollos() {

        Operario a = new Operario("Juan");
        Operario b = new Operario("Pepe");
        Operario c = new Operario("Maria");

        Thread a1 = new Thread(new HiloOperario(gasolinera, a, paso));
        Thread a2 = new Thread(new HiloOperario(gasolinera, b, paso));
        Thread a3 = new Thread(new HiloOperario(gasolinera, c, paso));

        a1.start();
        a2.start();
        a3.start();

    }

    /**
     * Método que crea los Vehiculos.
     *
     * @param numeroVehiculos : int
     */
    public void crearVehiculos(int numeroVehiculos) {
        String matricula = "ffff ";
        int tipo = -1;
        Vehiculo v = null;
        int numero = 0;
        for (int i = 0; i < numeroVehiculos; i++) {
            paso.mirar();
            numero = util.aleatorio(0, 10);
            if (numero < 2) {
                tipo = 2;

            } else if (numero < 6) {
                tipo = 1;
            } else {
                tipo = 0;
            }
            matricula = generarMatricula();
            v = new Vehiculo(i, tipo, matricula, util);
            HiloVehiculo hv = new HiloVehiculo(this, util, v, gasolinera, paso);
            Thread h = new Thread(hv);
            pool.execute(h);
        }
    }

    /**
     * Método que genera aleatoriamente una matricula para un vehiculo.
     *
     * @return matricula : String
     */
    public String generarMatricula() {
        String matricula = " ";
        int numeros = util.aleatorio(1000, 9999);
        int numeroAleatorio = -1;
        matricula = numeros + "";
        for (int i = 0; i < 3; i++) {
            numeroAleatorio = util.aleatorio(0, 25);
            char letra = (char) (numeroAleatorio + 65);
            matricula = matricula + letra;
        }
        return matricula;
    }

    /**
     * Método que se encarga de modificar el oclor de la imagen que sale por
     * pantalla.
     *
     * @param image : BufferedImage
     * @param miColor : Color
     * @return image : BufferedImage
     */
    public static BufferedImage cambiarColorImagen(BufferedImage image, Color miColor) {
        int width = image.getWidth();
        int height = image.getHeight();
        WritableRaster raster = image.getRaster();

        for (int xx = 0; xx < width; xx++) {
            for (int yy = 0; yy < height; yy++) {
                int[] pixels = raster.getPixel(xx, yy, (int[]) null);
                pixels[0] = miColor.getRed();
                pixels[1] = miColor.getGreen();
                pixels[2] = miColor.getBlue();
                raster.setPixel(xx, yy, pixels);
            }
        }
        return image;
    }

    /**
     * Método que pinta los elementos en pantalla.
     *
     */
    private void pintarPantalla() {
        iniciarLabelesColaEspera();
    }

    /**
     * Método que inicia los label del programa.
     *
     */
    private void iniciarLabelesColaEspera() {
        labelesColaEspera.add(labelCoche9);
        labelesColaEspera.add(labelCoche10);
        labelesColaEspera.add(labelCoche11);
        labelesColaEspera.add(labelCoche12);
        labelesColaEspera.add(labelCoche13);
        labelesColaEspera.add(labelCoche14);
        labelesColaEspera.add(labelCoche15);
        labelesColaEspera.add(labelCoche16);
        labelesColaEspera.add(labelCoche17);
        labelesColaEspera.add(labelCoche18);
        labelesColaEspera.add(labelCoche19);
        labelesColaEspera.add(labelCoche20);
        for (int i = 0; i < labelesColaEspera.size(); i++) {
            labelesColaEspera.get(i).setVisible(false);
        }

    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        labelSurtidor1 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        labelCoche9 = new javax.swing.JLabel();
        labelCoche10 = new javax.swing.JLabel();
        labelCoche11 = new javax.swing.JLabel();
        labelCoche12 = new javax.swing.JLabel();
        labelCoche13 = new javax.swing.JLabel();
        labelCoche14 = new javax.swing.JLabel();
        labelCoche15 = new javax.swing.JLabel();
        labelCoche16 = new javax.swing.JLabel();
        labelCoche17 = new javax.swing.JLabel();
        labelCoche18 = new javax.swing.JLabel();
        labelCoche19 = new javax.swing.JLabel();
        labelCoche20 = new javax.swing.JLabel();
        BotonReanudar = new javax.swing.JButton();
        BotonParar = new javax.swing.JButton();
        jLabel12 = new javax.swing.JLabel();
        label0 = new javax.swing.JLabel();
        label1 = new javax.swing.JLabel();
        label2 = new javax.swing.JLabel();
        label3 = new javax.swing.JLabel();
        label4 = new javax.swing.JLabel();
        label5 = new javax.swing.JLabel();
        label6 = new javax.swing.JLabel();
        label7 = new javax.swing.JLabel();
        label8 = new javax.swing.JLabel();
        label9 = new javax.swing.JLabel();
        label10 = new javax.swing.JLabel();
        label11 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setMinimumSize(new java.awt.Dimension(870, 560));
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        getContentPane().add(labelSurtidor1, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 320, 200, -1));
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(830, 590, -1, -1));

        labelCoche9.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/CocheGasolina.png"))); // NOI18N
        getContentPane().add(labelCoche9, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 200, 120, 80));

        labelCoche10.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/CocheElectrico.png"))); // NOI18N
        getContentPane().add(labelCoche10, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 190, 120, 80));

        labelCoche11.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/CocheElectrico.png"))); // NOI18N
        getContentPane().add(labelCoche11, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 190, 120, 80));

        labelCoche12.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/CocheElectrico.png"))); // NOI18N
        getContentPane().add(labelCoche12, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 190, 120, 80));

        labelCoche13.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/CocheElectrico.png"))); // NOI18N
        getContentPane().add(labelCoche13, new org.netbeans.lib.awtextra.AbsoluteConstraints(550, 190, 120, 80));

        labelCoche14.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/CocheElectrico.png"))); // NOI18N
        getContentPane().add(labelCoche14, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 190, 120, 80));

        labelCoche15.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/CocheElectrico.png"))); // NOI18N
        getContentPane().add(labelCoche15, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 360, 120, 80));

        labelCoche16.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/CocheElectrico.png"))); // NOI18N
        getContentPane().add(labelCoche16, new org.netbeans.lib.awtextra.AbsoluteConstraints(550, 360, 120, 80));

        labelCoche17.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/CocheElectrico.png"))); // NOI18N
        getContentPane().add(labelCoche17, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 360, 120, 80));

        labelCoche18.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/CocheElectrico.png"))); // NOI18N
        getContentPane().add(labelCoche18, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 360, 120, 80));

        labelCoche19.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/CocheElectrico.png"))); // NOI18N
        getContentPane().add(labelCoche19, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 360, 120, 80));

        labelCoche20.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/CocheElectrico.png"))); // NOI18N
        getContentPane().add(labelCoche20, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 360, 120, 80));

        BotonReanudar.setText("Reanudar");
        BotonReanudar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BotonReanudarActionPerformed(evt);
            }
        });
        getContentPane().add(BotonReanudar, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 460, 110, 50));

        BotonParar.setText("Parar");
        BotonParar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BotonPararActionPerformed(evt);
            }
        });
        getContentPane().add(BotonParar, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 460, 120, 50));

        jLabel12.setFont(new java.awt.Font("Impact", 3, 48)); // NOI18N
        jLabel12.setText("SERVIDOR");
        getContentPane().add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 40, 210, 70));

        label0.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        getContentPane().add(label0, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 150, 120, 40));

        label1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        getContentPane().add(label1, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 140, 120, 40));

        label2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        getContentPane().add(label2, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 140, 120, 40));

        label3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        getContentPane().add(label3, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 140, 120, 40));

        label4.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        getContentPane().add(label4, new org.netbeans.lib.awtextra.AbsoluteConstraints(550, 140, 120, 40));

        label5.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        getContentPane().add(label5, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 140, 120, 40));

        label6.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        getContentPane().add(label6, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 310, 120, 40));

        label7.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        getContentPane().add(label7, new org.netbeans.lib.awtextra.AbsoluteConstraints(550, 310, 120, 40));

        label8.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        getContentPane().add(label8, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 310, 120, 40));

        label9.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        getContentPane().add(label9, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 310, 120, 40));

        label10.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        getContentPane().add(label10, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 310, 120, 40));

        label11.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        getContentPane().add(label11, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 310, 120, 40));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    /**
     * Método que se encarga de reanudar la entrada de los coches.
     *
     * @param evt : java.awt.event.ActionEvent
     */
    private void BotonReanudarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BotonReanudarActionPerformed
        // TODO add your handling code here:

        paso.abrir();
    }//GEN-LAST:event_BotonReanudarActionPerformed

    /**
     * Método que se encarga de detener la entrada a los coches.
     *
     * @param evt : java.awt.event.ActionEvent
     */
    private void BotonPararActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BotonPararActionPerformed
        // TODO add your handling code here:

        paso.cerrar();

    }//GEN-LAST:event_BotonPararActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;

                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Servidor.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);

        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Servidor.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);

        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Servidor.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);

        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Servidor.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Servidor().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton BotonParar;
    private javax.swing.JButton BotonReanudar;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel label0;
    private javax.swing.JLabel label1;
    private javax.swing.JLabel label10;
    private javax.swing.JLabel label11;
    private javax.swing.JLabel label2;
    private javax.swing.JLabel label3;
    private javax.swing.JLabel label4;
    private javax.swing.JLabel label5;
    private javax.swing.JLabel label6;
    private javax.swing.JLabel label7;
    private javax.swing.JLabel label8;
    private javax.swing.JLabel label9;
    private javax.swing.JLabel labelCoche10;
    private javax.swing.JLabel labelCoche11;
    private javax.swing.JLabel labelCoche12;
    private javax.swing.JLabel labelCoche13;
    private javax.swing.JLabel labelCoche14;
    private javax.swing.JLabel labelCoche15;
    private javax.swing.JLabel labelCoche16;
    private javax.swing.JLabel labelCoche17;
    private javax.swing.JLabel labelCoche18;
    private javax.swing.JLabel labelCoche19;
    private javax.swing.JLabel labelCoche20;
    private javax.swing.JLabel labelCoche9;
    private javax.swing.JLabel labelSurtidor1;
    // End of variables declaration//GEN-END:variables
}
