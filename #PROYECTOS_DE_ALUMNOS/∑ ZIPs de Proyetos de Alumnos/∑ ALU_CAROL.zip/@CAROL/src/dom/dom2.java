package dom;

import com.sun.org.apache.xml.internal.serialize.OutputFormat;
import com.sun.org.apache.xml.internal.serialize.XMLSerializer;
import org.w3c.dom.DOMImplementation;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;

public class dom2 {


    public static void main(String[] args) {


       ArrayList<Empleado> lista = new ArrayList<>();
       lista.add( new Empleado(1,"eva","perex","lengua"));
       lista.add( new Empleado(2,"pepe","ruiz","historia"));
       lista.add( new Empleado(121,"ana","perex","lengua"));


        Document doc = crearDocument(lista);
        guardarDocumentoDOMcomoXML(doc, "doc2.xml");


    }

    public static Document crearDocument( ArrayList<Empleado> lista) {

        DocumentBuilder builder = null;
        Document miDocDom=null;
        try {


            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            builder = factory.newDocumentBuilder();
            DOMImplementation implementation = builder.getDOMImplementation();
            miDocDom = implementation.createDocument(null, "datos", null);
            // --------------------------------------- RAMA DE PERSONAL DEL XML
            //-- crea ETIQUETA PERSONAL
            Element raiz = miDocDom.getDocumentElement();

            for (Empleado em : lista) {
                Element etpersonal = miDocDom.createElement("personal");
                Element etempleado = miDocDom.createElement("empleado");
                Element etnombre = miDocDom.createElement("nombre");
                Element etapellido = miDocDom.createElement("apellido");

                etempleado.setAttribute("codigoEmp", em.getCodigoEmpleado()+"");
                etempleado.setAttribute("codDptoPertenencia", em.getCodDptoPertenecia()+"");

                Node valornombre = miDocDom.createTextNode(em.getNombreEmpleado());
                Node valorapellido = miDocDom.createTextNode(em.getApellidoEmpleado());

                raiz.appendChild(etpersonal);
                etpersonal.appendChild(etempleado);
                etempleado.appendChild(etnombre);
                etempleado.appendChild(etapellido);

                etnombre.appendChild(valornombre);
                etapellido.appendChild(valorapellido);
            }


        } catch (ParserConfigurationException e) {
            e.printStackTrace();
        }
        return miDocDom;
    }

    public static void guardarDocumentoDOMcomoXML(Document miDocumentoDom, String nombreFicheroXML)  {
        try {
            //Crea un File con el nombre del parametro del método
            File archivo_xml = new File(nombreFicheroXML);
            //Especifica el formato de salida, que es en realidad el objeto Document creado
            //en el método anterior a este
            OutputFormat miFormato = new OutputFormat(miDocumentoDom);
            //Especifica ademas que la salida esté indentada, esto es, con formato indentado
            miFormato.setIndenting(true);
            //Escribe (fisicamente) el contenido en el FILE
            // Para ello crea primero un objeto serializador, con el File y el format creados
            FileOutputStream fos = new FileOutputStream(archivo_xml);
            XMLSerializer serializer = new XMLSerializer(fos, miFormato);
            // y finalmente ejecuta la serializacion
            serializer.serialize(miDocumentoDom);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}


class Empleado {
    int codigoEmpleado;
    String nombreEmpleado;
    String apellidoEmpleado;
    String codDptoPertenecia;

//    public Empleado() {
//    }

    public Empleado(int codigoEmpleado, String nombreEmpleado, String apellidoEmpleado, String codDptoPertenecia) {
        this.codigoEmpleado = codigoEmpleado;
        this.nombreEmpleado = nombreEmpleado;
        this.apellidoEmpleado = apellidoEmpleado;
        this.codDptoPertenecia = codDptoPertenecia;
    }

    public int getCodigoEmpleado() {
        return codigoEmpleado;
    }

    public String getNombreEmpleado() {
        return nombreEmpleado;
    }

    public String getApellidoEmpleado() {
        return apellidoEmpleado;
    }

    public String getCodDptoPertenecia() {
        return codDptoPertenecia;
    }

    public void setCodigoEmpleado(int codigoEmpleado) {
        this.codigoEmpleado = codigoEmpleado;
    }

    public void setNombreEmpleado(String nombreEmpleado) {
        this.nombreEmpleado = nombreEmpleado;
    }

    public void setApellidoEmpleado(String apellidoEmpleado) {
        this.apellidoEmpleado = apellidoEmpleado;
    }

    public void setCodDptoPertenecia(String codDptoPertenecia) {
        this.codDptoPertenecia = codDptoPertenecia;
    }

}