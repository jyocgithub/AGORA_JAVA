package dom;

public class ejemploSingleton {

    public static void main(String[] args) {

        MiSingleton pepe = MiSingleton.getInstance();
        MiSingleton paco = MiSingleton.getInstance();

        if (pepe==paco){
            System.out.println("semos iguales");
        }
    }


}


class MiSingleton {

    static MiSingleton mm = null;

    private MiSingleton() {
    }

    public static MiSingleton getInstance() {
        if (mm == null) {
            mm = new MiSingleton();
        }
        return mm;
    }
}