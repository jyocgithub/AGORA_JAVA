package dom;

import com.sun.org.apache.xml.internal.serialize.OutputFormat;
import com.sun.org.apache.xml.internal.serialize.XMLSerializer;
import org.w3c.dom.DOMImplementation;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.HashMap;

public class dom {


    public static void main(String[] args) {


        HashMap<String, String> map = new HashMap<>();

        map.put("123", "pepe");
        map.put("3234", "ana");
        map.put("53", "eva");

        Document doc = crearDocument(map);
        guardarDocumentoDOMcomoXML(doc, "doc.xml");


    }

    public static Document crearDocument(HashMap<String, String> hashmap) {

        DocumentBuilder builder = null;
        Document miDocDom=null;
        try {


            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            builder = factory.newDocumentBuilder();
            DOMImplementation implementation = builder.getDOMImplementation();
            miDocDom = implementation.createDocument(null, "BDAlumnos", null);
            // --------------------------------------- RAMA DE PERSONAL DEL XML
            //-- crea ETIQUETA PERSONAL
            Element raiz = miDocDom.getDocumentElement();

            for (String clavedni : hashmap.keySet()) {
                Element etalumno = miDocDom.createElement("alumno");
                Element etnombre = miDocDom.createElement("nombre");
                Element etdni = miDocDom.createElement("dni");
                Node valordni = miDocDom.createTextNode(clavedni);
                Node valornombre = miDocDom.createTextNode(hashmap.get(clavedni));

                etalumno.appendChild(etnombre);
                etalumno.appendChild(etdni);

                etnombre.appendChild(valornombre);
                etdni.appendChild(valordni);

                raiz.appendChild(etalumno);

            }


        } catch (ParserConfigurationException e) {
            e.printStackTrace();
        }
        return miDocDom;
    }

    public static void guardarDocumentoDOMcomoXML(Document miDocumentoDom, String nombreFicheroXML)  {
        try {
            //Crea un File con el nombre del parametro del método
            File archivo_xml = new File(nombreFicheroXML);
            //Especifica el formato de salida, que es en realidad el objeto Document creado
            //en el método anterior a este
            OutputFormat miFormato = new OutputFormat(miDocumentoDom);
            //Especifica ademas que la salida esté indentada, esto es, con formato indentado
            miFormato.setIndenting(true);
            //Escribe (fisicamente) el contenido en el FILE
            // Para ello crea primero un objeto serializador, con el File y el format creados
            FileOutputStream fos = new FileOutputStream(archivo_xml);
            XMLSerializer serializer = new XMLSerializer(fos, miFormato);
            // y finalmente ejecuta la serializacion
            serializer.serialize(miDocumentoDom);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}

