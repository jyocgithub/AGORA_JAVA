import java.util.HashMap;

public class BDAlumno
{
	private Fichero fichero = null;
	HashMap<String, String> hm = null;

	public BDAlumno(String ruta)
	{
		fichero = new Fichero(ruta);
		fichero.crear(false);
		hm = new HashMap<>();
	}

	/**
	 * Guarda los datos de un alumno en una linea del fichero con el formato nombre#DNI
	 * @param alu
	 */
	public void guardarAlumno(Alumno alu)
	{
		fichero.escribirFicheroTextoAlFinal(alu.getDni() + "#" + alu.getNombre());
	}

	/**
	 * Almacena las lineas de un fichero en un ArrayList<String> y lo devuelve
	 * @return
	 */
	public HashMap<String, String> devuelveAlumnos()
	{
		hm = fichero.leerFicheroTexto();
		return hm;
	}

	/**
	 * Borra la linea de la BD en la que se encuentra el alumno con el DNI pasado como parametro.
	 */
	public void borrarAlumno(String dni)
	{
		fichero.borrarLineaFicheroTexto(dni);
	}

	/**
	 * Busca un objeto alumno por DNI y lo devuelve
	 * @param dni
	 * @return
	 */
	public Alumno buscarAlumno(String dni)
	{
		return new Alumno(dni, hm.get(dni));
	}

	/**
	 * Metodo que reemplaca una linea por otra en un fichero
	 * @param nuevo
	 */
	public void modificarAlumno(String dni, String nuevo)
	{
		fichero.modificarFicheroTexto(dni, nuevo);
	}
}
