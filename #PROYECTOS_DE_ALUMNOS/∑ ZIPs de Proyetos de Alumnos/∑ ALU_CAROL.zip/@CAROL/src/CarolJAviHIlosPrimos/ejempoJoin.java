
public class ejempoJoin {

	public static void main(String[] args) {

		Hilo h1 = new Hilo(1);
		Hilo h2 = new Hilo(2);
		Hilo h3 = new Hilo(3);

		h1.start();
		h2.start();
		h3.start();

		// try {
		// h1.join();
		// h2.join();
		// h3.join();
		// } catch (InterruptedException e) {
		// e.printStackTrace();
		// }

		for (int i = 0; i < 10; i++) {

			System.out.println("Soy  MAIN" + " : " + i);
		}

	}

}

class Hilo extends Thread {
	int id;

	public Hilo(int id) {
		this.id = id;
	}

	@Override
	public void run() {

		for (int i = 0; i < 100; i++) {
			// try {
			// Thread.sleep(200);
			// } catch (InterruptedException e) {
			// e.printStackTrace();
			// }
			System.out.println("Soy " + id + " : " + i);
		}

	}
}