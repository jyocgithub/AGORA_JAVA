public class BuscarPrimos extends Thread
{
	private int inicio, tope;

	public BuscarPrimos(int inicio, int tope)
	{
		this.inicio = inicio;
		this.tope = tope;
	}

	@Override
	public void run()
	{
		muestraPrimos();
	}

	public void muestraPrimos()
	{
		for (int i = inicio; i < tope; i++)
		{
			if (esPrimo(i))
				System.out.println(i);
		}
	}

	private boolean esPrimo(int i)
	{
		boolean tieneDivisores = false;

		for (int div = 2; div <= i / 2 && !tieneDivisores; div++)
		{
			if (i % div == 0)
				tieneDivisores = true;
		}

		if (tieneDivisores)
			return false;
		else
			return true;
	}
}
