
public class Main {
	private final static int NUM = 1000000;

	public static void main(String[] args) throws InterruptedException {
		Runtime r = Runtime.getRuntime();
		System.out.println("Numero de cores: " + r.availableProcessors());

		int cores = r.availableProcessors();
		int rango = Math.round(NUM / (float) cores);

		System.out.println("Rango de numeros: " + rango);

		BuscarPrimos[] p = new BuscarPrimos[cores];

		int inicioRango = 1, finRango = rango;

		for (int i = 0; i < cores; i++) {
			p[i] = new BuscarPrimos(inicioRango, finRango);

			inicioRango += rango;
			finRango += rango;

			p[i].start();

		}
		for (int i = 0; i < cores; i++) {
			p[i].join();
		}

		System.out.println("ACABE");

	}
}
