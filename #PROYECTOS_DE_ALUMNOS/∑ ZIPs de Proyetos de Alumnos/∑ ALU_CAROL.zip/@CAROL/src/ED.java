import java.io.*;

/**
 * Clase Estructura de Datos
 *
 * @author Carolina
 */

public abstract class ED {
    protected String ruta;
    protected File f = null;

    /**
     * Constructor que recibe un String con la ruta que queremos darle al fichero
     * y la guarda en su atributo y crea el File
     *
     * @param r
     */
    public ED(String r) {
        ruta = r;
        f = new File(r);

    }

    /**
     * Devuelve el valor del atributo ruta
     *
     * @param ed
     * @return String
     */
    public String dameRuta(File ed) {
        return ruta;
    }

    /**
     * Devuelve una cadena con la ruta del fichero
     */
    public void actualizaRuta() {
        ruta = f.getAbsolutePath();
    }

    /**
     * Renombra el fichero con el String que recibe como parametro.
     * Si ha conseguido renombrarlo devuelve true, sino false.
     *
     * @param destino
     * @return boolean
     */
    public boolean renombrar(String destino) {
        if (f.exists()) {
            File f2 = new File(destino);
            f.renameTo(f2);
            actualizaRuta(); //Al cambiar el nombre cambia la ruta
            return true;
        }

        return false;
    }

    public abstract void crear(boolean crear);

    //public abstract BufferedReader abrirFicheroTexto();

    //public abstract void cerrarFicheroTexto();

    /**
     * Permite renombrar un fichero reemplazando o no el que ya habia del mismo
     * nombre. Si reemplazar es true el fichero se renombra, sino no se hace
     * nada. Si ha conseguido renombrarlo devuelve true, sino false.
     *
     * @param destino
     * @param reemplazar
     * @return boolean
     */
    public boolean renombrar(String destino, boolean reemplazar) {
        if (f.exists()) {
            File f2 = new File(destino);

            if (f2.exists() && reemplazar) {
                f.renameTo(f2);
                actualizaRuta(); //Al cambiar el nombre cambia la ruta
                return true;
            }
        }
        return false;
    }

}
