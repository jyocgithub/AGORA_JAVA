import java.io.*;
import java.util.*;
/**
 * Clase Fichero que hereda de Estructura de Datos
 * @author Carolina
 *
 */
public class Fichero extends ED
{

	BufferedReader br = null;
	FileWriter fw = null;
	PrintWriter pw = null;

	public Fichero(String ruta)
	{
		super(ruta);
	}


	/**
	 * Crea un fichero de texto con la ruta, si aun no existia ese fichero.
	 * Si ya existia no hace nada
	 * @param crear
	 */
	@Override
	public void crear(boolean crear)
	{
		try
		{
			f.createNewFile();
		}
		catch (IOException e1)
		{
			e1.printStackTrace();
		}

	}

	/**
	 * Abre un fichero de texto si ya existe y sino no hace nada y devuelve
	 * null. Si existe el fichero devuelve un BufferedReader apuntando al
	 * principio del fichero. Controla las excepciones que surgen.
	 *
	 * @return BufferedReader
	 */
	private BufferedReader abrirFicheroTexto()
	{

		try
		{
			br = new BufferedReader(new FileReader(f));
		}
		catch (FileNotFoundException e)
		{
			e.printStackTrace();
		}

		return br;
	}

	/**
	 * Si existe alg�n BufferedReader o PrintWriter lo cierra, lo cual hace que
	 * tambien se cierre el fichero que contienen. Controla las excepciones que
	 * surgen.
	 */
	private void cerrarFicheroTexto()
	{
		try
		{
			if (br != null)
				br.close();
			if (pw != null)
				pw.close();
		}
		catch (IOException e)
		{
			e.printStackTrace();
		}
	}


	/**
	 * Lee un fichero de texto, almacena linea a linea en un HashMap<String, String> y
	 * lo devuelve
	 *
	 * @return HashMap<String, String>
	 */
	public HashMap<String, String> leerFicheroTexto()
	{
		HashMap<String, String> hm = new HashMap<>();

		br = abrirFicheroTexto();
		String linea = "";
		String []datos = null;
		try
		{
			linea = br.readLine();

			while (linea != null)
			{
				datos = linea.split("#");
				hm.put(datos[0], datos[1]); //Clave: DNI, Valor: Nombre alumno
				linea = br.readLine();
			}
		}
		catch (IOException e)
		{
			e.printStackTrace();
		}

		cerrarFicheroTexto();

		return hm;
	}

	/**
	 * Escribe lineas al final de un fichero de texto que ya existe
	 * @param linea
	 */
	public void escribirFicheroTextoAlFinal(String linea)
	{
		if (f.exists())
		{
			try
			{
				pw = new PrintWriter(new FileWriter(f, true));// Abre el fichero para a�adir al final
				pw.println(linea);
			}
			catch (IOException e)
			{
				e.printStackTrace();
			}
		}

		cerrarFicheroTexto();
	}

	/**
	 * Escribe lineas machacando las que ya existian
	 * @param linea
	 */
	public void escribirFicheroTexto(String linea)
	{
		if (f.exists())
		{
			try
			{
				pw = new PrintWriter(new FileWriter(f));
				pw.println(linea);
			}
			catch (IOException e)
			{
				e.printStackTrace();
			}
		}

		cerrarFicheroTexto();
	}

	/**
	 * Recibe un String con la clave del elemento en el HashMap, lo busca y borra su linea completa.
	 * @param clave
	 */
	public void borrarLineaFicheroTexto(String clave)
	{
		HashMap<String, String> hm = new HashMap<>();

		hm = leerFicheroTexto();

		hm.remove(clave);

		vaciarFichero();

		for(String dni : hm.keySet())
		{
			escribirFicheroTextoAlFinal(dni + "#" + hm.get(dni));
		}
	}


	/**
	 * Si el fichero existe vacia su contenido y si no existe lo crea (por tanto
	 * estar� vacio al estar recien creado)
	 */
	public void vaciarFichero()
	{
		if (f.exists())
		{
			f.delete();
		}

		try
		{
			f.createNewFile();
		}
		catch (IOException e)
		{
			e.printStackTrace();
		}
	}

	/**
	 * Busca la linea que contiene el String "antiguo" y lo modifica por el String "nuevo"
	 * @param nuevo
	 */
	public void modificarFicheroTexto(String dni, String nuevo)
	{
		HashMap<String,String> hm = new HashMap<>();
		hm = leerFicheroTexto();

		if(hm.containsKey(dni))
		{
			hm.put(dni, nuevo);//Si el HashMap ya contenia ese dni, reemplaza el valor por "nuevo"

			for(String clave : hm.keySet())
			{
				escribirFicheroTexto(clave + "#" + hm.get(clave));
			}
		}
	}


}
