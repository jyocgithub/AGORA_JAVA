import java.util.HashMap;

public class Main
{

	public static void main(String[] args)
	{
		Alumno pepe = new Alumno("11111111-A", "Pepe");
		Alumno pipi = new Alumno("22222222-B", "Pipi");
		Alumno popo = new Alumno("33333333-C", "Popo");
		Alumno pupu = new Alumno("44444444-D", "Pupu");
		BDAlumno bd = new BDAlumno("carol.txt");

		//Guardar Alumno --- FUNCIONA
		bd.guardarAlumno(pepe);
		bd.guardarAlumno(pipi);
		bd.guardarAlumno(popo);
		bd.guardarAlumno(pupu);

		//Listar Alumnos --- FUNCIONA
		HashMap<String, String> hm = bd.devuelveAlumnos();
		listar(hm);

		//Borrar Alumno --- FUNCIONA

		bd.borrarAlumno("33333333-C");
		listar(bd.devuelveAlumnos());

		//Modificar Alumno --- NO FUNCIONA
		bd.modificarAlumno("44444444-D", "Maria");
		listar(bd.devuelveAlumnos());

	}

	/**
	 * Metodo estatico y privado del Main que permite imprimir por pantalla
	 * el contenido del fichero con System.out.println
	 * @param hm
	 */
	private static void listar(HashMap<String,String> hm)
	{
		for(String dni : hm.keySet())
		{
			System.out.println(dni + "#" + hm.get(dni));
		}
		System.out.println();
	}

}
