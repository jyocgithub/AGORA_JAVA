package Swing;

import Codigo.Apuesta;
import Codigo.Carta;
import Codigo.Jugador;
import Codigo.Jugador_ocasional;
import Codigo.Jugador_registrado;
import Codigo.CasaApuestas;
import Codigo.Ficheros;
import Codigo.Premio;
import java.awt.Color;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;

/**
 * ContinuacionAplicacion : Ejecuta el juego del poker y muestra los premios.
 *
 * @author cristiandiaz
 * @version 1.0
 */
public class ContinuacionAplicacion extends javax.swing.JFrame {

    private Apuesta unaApuesta;
    private Jugador primero;
    private double dineroApostar;
    private CasaApuestas casaApuestas;

    /**
     * Metodo constructor referido a Jugadores Ocasionales.
     *
     * @param primero : Objeto de tipo Jugador_ocasional.
     * @param unaApuesta : Objeto de tipo Apuesta.
     * @param dineroApostar : Parametro de tipo double.
     *
     */
    public ContinuacionAplicacion(Jugador_ocasional primero, Apuesta unaApuesta, double dineroApostar) {
        initComponents();
        BotonSalir.setEnabled(false);
        Color azulEspesial = new Color(176, 224, 230);
        this.getContentPane().setBackground(azulEspesial);

        this.unaApuesta = unaApuesta;
        this.dineroApostar = dineroApostar;
        this.primero = primero;

        pintarMano();
        premio(unaApuesta);

    }

    /**
     * Metodo constructor sobrecarga referido a Jugadores Registrados.
     *
     * @param casaApuestas : Objeto de tipo CasaApuestas
     * @param dineroApostar : Parametro de tipo double
     *
     */
    public ContinuacionAplicacion(CasaApuestas casaApuestas, double dineroApostar) {
        initComponents();
        BotonSalir.setEnabled(true);
        Color azulEspesial = new Color(176, 224, 230);
        this.getContentPane().setBackground(azulEspesial);

        this.casaApuestas = casaApuestas;
        this.dineroApostar = dineroApostar;

        primero = casaApuestas.getJug();

        pintarMano();
        premio(unaApuesta);

    }

    /**
     * Metodo que pinta las cartas de la mano en los JLabel. En el creamos dos
     * ArrayList para poder ordenar las cartas, uno para Jugadores ocasionales (
     * se usa la clase Jugador registrado ) y otro para Jugadores registrados (
     * se usa la clase CasaApuestas ). Ordeno las cartas antes de pintarlarlas
     * por pantalla.
     *
     */
    void pintarMano() {

        Carta c = new Carta(0, 0);
        ArrayList<Carta> mano; // Usa la clase CasaApuestas para obtener el HashMap de Jugadores.
        ArrayList<Carta> lista; // Usa la clase Jugador_ocasional para obtener el HashMap de Jugadores.

        if (primero instanceof Jugador_registrado) {
            mano = casaApuestas.getUnaApuesta().getMimano();
            Collections.sort(mano);
        } else if (primero instanceof Jugador_ocasional) {
            lista = unaApuesta.getMimano();
            Collections.sort(lista);
        }

        for (int i = 0; i < 5; i++) {

            if (primero instanceof Jugador_ocasional) {
                c = unaApuesta.getMimano().get(i);
            } else if (primero instanceof Jugador_registrado) {
                c = casaApuestas.getUnaApuesta().getMimano().get(i);
            }

            ImageIcon foto = devuelveImagen(c); // Me devuelve Imagen = Copas 3.JPG

            switch (i) {
                case 0:
                    jLabel5.setIcon(foto);
                    break;
                case 1:
                    jLabel4.setIcon(foto);
                    break;
                case 2:
                    jLabel3.setIcon(foto);
                    break;
                case 3:
                    jLabel2.setIcon(foto);
                    break;
                case 4:
                    jLabel1.setIcon(foto);
                    break;
            }
        }

    }

    /**
     * Metodo para asignar la direccion de la foto de una carta. Recibe una
     * carta y coge tanto el palo como la figura de este. A continuacion crea
     * dos variables de tipo String en las que se localiza la direccion de la
     * foto de dicha carta y se procede a crear el ImageIcon.
     *
     * @param c : Objeto de tipo Carta.
     * @return ImageIcon : Objeto que contiene la direccion de la carta para
     * pintarla.
     */
    ImageIcon devuelveImagen(Carta c) {
        String palo = "";
        String figura = "";

        switch (c.getPalo()) {
            case 0:
                palo = "/Copas";
                break;
            case 1:
                palo = "/Espadas";
                break;
            case 2:
                palo = "/Oros";
                break;
            case 3:
                palo = "/Bastos";
        }
        switch (c.getFigura()) {
            case 0:
                figura = "/As.jpg";
                break;
            case 1:
                figura = "/Dos.jpg";
                break;
            case 2:
                figura = "/3.jpg";
                break;
            case 3:
                figura = "/4.jpg";
                break;
            case 4:
                figura = "/5.jpg";
                break;
            case 5:
                figura = "/6.jpg";
                break;
            case 6:
                figura = "/7.jpg";
                break;
            case 7:
                figura = "/8.jpg";
                break;
            case 8:
                figura = "/9.jpg";
                break;
            case 9:
                figura = "/Sota.jpg";
                break;
            case 10:
                figura = "/Caballo.jpg";
                break;
            case 11:
                figura = "/Rey.jpg";
                break;
        }

        ImageIcon foto = new ImageIcon(getClass().getResource(palo + figura));
        //       ImageIcon foto = new ImageIcon(palo + figura);

        return foto;
    }

    /**
     * Metodo que especifica los valores y tipo de premio. Informa al Jugador en
     * los Jlabel sobre los premios o dinero que ha obtenido. Tambien se encarga
     * de actualizar el saldo del jugador.
     *
     * @param unaApuesta : Objeto de tipo Apuesta.
     */
    void premio(Apuesta unaApuesta) {
        int multiplicador = 0;
        double dineroGanado = 0;

        if (primero instanceof Jugador_registrado) {
            multiplicador = casaApuestas.getUnaApuesta().verPremio();

        } else if (primero instanceof Jugador_ocasional) {
            multiplicador = unaApuesta.verPremio();
        }

        dineroGanado = dineroApostar * multiplicador;

        // Con este condicional podre decirle al usuario que premio tiene dependiendo del multiplicador.
        if (primero instanceof Jugador_ocasional) {
            switch (multiplicador) {
                case 5:
                    TextoPremio.setText("FULL");
                    break;
                case 2:
                    TextoPremio.setText("DOBLE PAREJA");
                    break;
                case 3:
                    TextoPremio.setText("TRIO");
                    break;
                case 4:
                    TextoPremio.setText("COLOR");
                    break;
                case 6:
                    TextoPremio.setText("POKER");
                    break;
                case 1:
                    TextoPremio.setText("PAREJA");
                    break;
                case 0:
                    TextoPremio.setText("NO HAY PREMIO");
                    TextoMultiplica.setText("NO MULTIPLICA");
                    break;

            }
        } else if (primero instanceof Jugador_registrado) {
            int jugada = 0;
            switch (multiplicador) {
                case 8:
                    jugada = Premio.FULL;
                    TextoPremio.setText("FULL");
                    break;
                case 2:
                    jugada = Premio.DOBLE_PAREJA;
                    TextoPremio.setText("DOBLE PAREJA");
                    break;
                case 4:
                    jugada = Premio.TRIO;
                    TextoPremio.setText("TRIO");
                    break;
                case 6:
                    jugada = Premio.COLOR;
                    TextoPremio.setText("COLOR");
                    break;
                case 10:
                    jugada = Premio.POKER;
                    TextoPremio.setText("POKER");
                    break;
                case 1:
                    jugada = Premio.PAREJA;
                    TextoPremio.setText("PAREJA");
                    break;
                case 0:
                    TextoPremio.setText("NO HAY PREMIO");
                    TextoMultiplica.setText("NO MULTIPLICA");
                    break;

            }
            if (multiplicador != 0) {
                Premio pre = new Premio(dineroGanado, "INDIVIDUAL", jugada);
                casaApuestas.getJug().getListaPremios().add(pre);
            }

        }
        if (multiplicador != 0) {
            TextoMultiplica.setText(multiplicador + "");
        }

        primero.setSaldo(primero.getSaldo() - dineroApostar);

        primero.aumentarSaldo(dineroGanado);
        if (primero instanceof Jugador_registrado) {
            Ficheros.guardarMapa(casaApuestas);
        }

        TextoDineroObtenido.setText(dineroGanado + "");
        TextoSaldoAcumulado.setText(primero.getSaldo() + "");

    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        BotonGenerar = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        TextoPremio = new javax.swing.JTextField();
        TextoDineroObtenido = new javax.swing.JTextField();
        TextoSaldoAcumulado = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        BotonVolverJugar = new javax.swing.JButton();
        BotonSalir = new javax.swing.JButton();
        BotonRetirarBeneficios = new javax.swing.JButton();
        jLabel10 = new javax.swing.JLabel();
        TextoMultiplica = new javax.swing.JTextField();

        BotonGenerar.setText("Generar");
        BotonGenerar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BotonGenerarActionPerformed(evt);
            }
        });

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel6.setText("El premio obtenido es: ");

        jLabel7.setText("El saldo acumulado es:");

        jLabel8.setText("El dinero obtenido es: ");

        TextoPremio.setEditable(false);
        TextoPremio.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TextoPremioActionPerformed(evt);
            }
        });

        TextoDineroObtenido.setEditable(false);
        TextoDineroObtenido.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TextoDineroObtenidoActionPerformed(evt);
            }
        });

        TextoSaldoAcumulado.setEditable(false);
        TextoSaldoAcumulado.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TextoSaldoAcumuladoActionPerformed(evt);
            }
        });

        jLabel9.setFont(new java.awt.Font("Lucida Grande", 3, 18)); // NOI18N
        jLabel9.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel9.setText("Su mano es:");

        BotonVolverJugar.setText("Volver a jugar");
        BotonVolverJugar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BotonVolverJugarActionPerformed(evt);
            }
        });

        BotonSalir.setText("Guardar y volver");
        BotonSalir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BotonSalirActionPerformed(evt);
            }
        });

        BotonRetirarBeneficios.setText("Retirar Beneficios");
        BotonRetirarBeneficios.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BotonRetirarBeneficiosActionPerformed(evt);
            }
        });

        jLabel10.setText("Multiplica por:");

        TextoMultiplica.setEditable(false);
        TextoMultiplica.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TextoMultiplicaActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(328, 328, 328)
                .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 166, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(37, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 153, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 155, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 149, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(27, 27, 27))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(BotonVolverJugar)
                                .addGap(73, 73, 73)
                                .addComponent(BotonSalir)
                                .addGap(63, 63, 63)
                                .addComponent(BotonRetirarBeneficios))
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(jLabel6)
                                        .addGap(18, 18, 18)
                                        .addComponent(TextoPremio, javax.swing.GroupLayout.PREFERRED_SIZE, 116, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(layout.createSequentialGroup()
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(jLabel7)
                                            .addComponent(jLabel8)
                                            .addComponent(jLabel10))
                                        .addGap(19, 19, 19)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(TextoMultiplica, javax.swing.GroupLayout.PREFERRED_SIZE, 116, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(TextoSaldoAcumulado, javax.swing.GroupLayout.PREFERRED_SIZE, 116, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(TextoDineroObtenido, javax.swing.GroupLayout.PREFERRED_SIZE, 116, javax.swing.GroupLayout.PREFERRED_SIZE))))
                                .addGap(139, 139, 139)))
                        .addGap(141, 141, 141))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(41, 41, 41)
                .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 233, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 233, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 233, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 233, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 233, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 28, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6)
                    .addComponent(TextoPremio, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel10)
                    .addComponent(TextoMultiplica, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel8)
                    .addComponent(TextoDineroObtenido, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(24, 24, 24)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel7)
                    .addComponent(TextoSaldoAcumulado, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(33, 33, 33)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(BotonVolverJugar)
                    .addComponent(BotonSalir)
                    .addComponent(BotonRetirarBeneficios))
                .addGap(58, 58, 58))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void TextoPremioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TextoPremioActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_TextoPremioActionPerformed

    private void TextoDineroObtenidoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TextoDineroObtenidoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_TextoDineroObtenidoActionPerformed

    private void TextoSaldoAcumuladoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TextoSaldoAcumuladoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_TextoSaldoAcumuladoActionPerformed

    /**
     * {@inheritDoc} Metodo que permite volver a jugar. Nos lleva a la ventana
     * anterior ( InicioAplicacion ) para poder aumentar nuestro saldo o
     * realizar otra apuesta. Guarda la informacion de la ultima apuesta del
     * jugador en el fichero en caso de ser registrado.
     *
     * @param evt : : ActionEvent del boton volver a jugar.
     */
    private void BotonVolverJugarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BotonVolverJugarActionPerformed
        // TODO add your handling code here:

        if (primero instanceof Jugador_registrado) {
            Jugador_registrado segundo = (Jugador_registrado) (primero);
            InicioAplicacion x = new InicioAplicacion(casaApuestas);
            Ficheros.guardarMapa(casaApuestas);
            x.setVisible(true);
            this.setVisible(false);
            dispose();

        } else if (primero instanceof Jugador_ocasional) {
            Jugador_ocasional segundo = (Jugador_ocasional) (primero);
            InicioAplicacion x = new InicioAplicacion(segundo);
            this.setVisible(false);
            x.setVisible(true);
            dispose();
        }


    }//GEN-LAST:event_BotonVolverJugarActionPerformed

    /**
     * Metodo que se encarga de dar el dinero de las ganancias a los jugadores
     * cuando se quieren retirar. Diferencia entre un jugador registrado y uno
     * ocasional. En ambos casos genera una factura y la guarda en el proyeco.
     * En el caso especial del usuario registrado calcula si este lleva mas de 1
     * año registrado para poder darle algun tipo de bonificacion. Al final de
     * todo procede a borrar todos los datos de los jugadores en la casa de
     * apuestas.
     *
     * @param evt : ActionEvent del boton retirar beneficios.
     */
    private void BotonRetirarBeneficiosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BotonRetirarBeneficiosActionPerformed
        // TODO add your handling code here:
        double suplemento = 0;
        double saldoTotal;
        int diferenciaAños = 1;
        double beneficios = 0;

        if (primero instanceof Jugador_registrado) {

            Jugador_registrado segundo = (Jugador_registrado) (primero);

            Date fechaRegistro = segundo.getFechaRegistro(); // Obtenermos la fecha en la que se registro

            Date hoy = Calendar.getInstance().getTime(); // Obtenemos fecha actual

            int dias = (int) ((hoy.getTime() - fechaRegistro.getTime()) / 86400000); // _Nos devuelve milisegundos. Al hacer el casting se carga la parte decimal
            diferenciaAños = (int) (dias / 365);

            suplemento = diferenciaAños * (2 * primero.getSaldo() / 100);      // Porcentaje que dan por cada año registrado.

        }

        /**
         * Tenemos que crear un fichero con la informacion de los jugadores
         * durante su estancia en la Casa de Apuestas Hay que hacerlo tanto si
         * se trata de un Jugador ocasional como de uno registrado, con la
         * diferencia de que en estos ultimos hay que contar con la posibilidad
         * de tener una bonificacion por cada año registrados.
         */
        PrintWriter pw = null;
        try {
            pw = new PrintWriter(primero.getNif() + ".txt");
            pw.println("Nombre: " + primero.getNombre());
            pw.println("NIF: " + primero.getNif());
            pw.println("Apellidos: " + primero.getApellidos());
            pw.println("Saldo inicial: 50€");
            pw.println("Saldo final: " + primero.getSaldo());
            pw.println("Beneficios en premios: " + (primero.getSaldo() - 50));
            pw.println("Premio obtenido: " + TextoPremio.getText());
            pw.println("Multiplica la apuesta por: " + TextoMultiplica.getText());

            if (primero instanceof Jugador_registrado) {
                Jugador_registrado segundo = (Jugador_registrado) (primero);
                for (int i = 0; i < 10; i++) {
                    if (segundo.getListaPremios().get(i).getTipoJuego().equals("INIDIVDUAL")) {
                        pw.println(i);
                        switch (segundo.getListaPremios().get(i).getTipoPremio()) {
                            case 0:
                                pw.println("Pareja " + segundo.getListaPremios().get(i).getImportePremio());
                            case 1:
                                pw.println("Doble Pareja " + segundo.getListaPremios().get(i).getImportePremio());
                            case 2:
                                pw.println("Trio " + segundo.getListaPremios().get(i).getImportePremio());
                            case 3:
                                pw.println("Color " + segundo.getListaPremios().get(i).getImportePremio());
                            case 4:
                                pw.println("Full " + segundo.getListaPremios().get(i).getImportePremio());
                            case 5:
                                pw.println("Poker " + segundo.getListaPremios().get(i).getImportePremio());
                        }
                    }

                }

                saldoTotal = suplemento + segundo.getSaldo();
                segundo.setSaldo(saldoTotal);
                pw.println("Bonificaciones (Años registrado en la aplicacion) : " + diferenciaAños);
                pw.println("Saldo definitivo con bonificacion: " + segundo.getSaldo());

                beneficios = casaApuestas.getJug().retirarBeneficios();
                Ficheros.guardarMapa(casaApuestas);
            }

        } catch (FileNotFoundException ex) {
            Logger.getLogger(ContinuacionAplicacion.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            if (pw != null) {
                pw.close();
            }

        }
        if (primero instanceof Jugador_ocasional) {

            JOptionPane.showMessageDialog(this, "El jugador: " + primero.getNombre() + " con nif: " + primero.getNif() + "Abandona la casa con: " + primero.getSaldo() + " €", "Confirmacion", JOptionPane.INFORMATION_MESSAGE);
            Empezar x = new Empezar();
            x.setVisible(true);
            this.setVisible(false);
            dispose();
        } else if (primero instanceof Jugador_registrado) {
            JOptionPane.showMessageDialog(this, "El jugador: " + primero.getNombre() + " con nif: " + primero.getNif() + "Abandona la casa con: " + beneficios + " €", "Confirmacion", JOptionPane.INFORMATION_MESSAGE);
            Empezar x = new Empezar();
            this.setVisible(false);
            x.setVisible(true);
            dispose();

        }
    }//GEN-LAST:event_BotonRetirarBeneficiosActionPerformed

    private void BotonGenerarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BotonGenerarActionPerformed
        // TODO add your handling code here
    }//GEN-LAST:event_BotonGenerarActionPerformed

    /**
     * Metodo que guarda y cierra la sesion. Esta bloqueado en caso de ser
     * jugador ocasional,guarda la informacion del jugador en un fichero y
     * ejecuta un JoptionPane para informar sobre la sesion.
     *
     * @param evt ; ActionEvent del boton salir.
     */
    private void BotonSalirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BotonSalirActionPerformed
        // TODO add your handling code here:

// Ocultar este boton en caso de ser Jugador Ocasional. 
        String nif = primero.getNif();
        String nombre = primero.getNombre();
        double saldo = primero.getSaldo();
        Ficheros.guardarMapa(casaApuestas);
        JOptionPane.showMessageDialog(this, "El jugador: " + nombre + " con nif: " + nif + " con saldo: " + saldo + "€ guarda su sesion en la casa de apuestas", "Confirmacion", JOptionPane.INFORMATION_MESSAGE);

        Empezar x = new Empezar();
        this.setVisible(false);
        x.setVisible(true);
        dispose();


    }//GEN-LAST:event_BotonSalirActionPerformed

    private void TextoMultiplicaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TextoMultiplicaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_TextoMultiplicaActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton BotonGenerar;
    private javax.swing.JButton BotonRetirarBeneficios;
    private javax.swing.JButton BotonSalir;
    private javax.swing.JButton BotonVolverJugar;
    private javax.swing.JTextField TextoDineroObtenido;
    private javax.swing.JTextField TextoMultiplica;
    private javax.swing.JTextField TextoPremio;
    private javax.swing.JTextField TextoSaldoAcumulado;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    // End of variables declaration//GEN-END:variables
}
