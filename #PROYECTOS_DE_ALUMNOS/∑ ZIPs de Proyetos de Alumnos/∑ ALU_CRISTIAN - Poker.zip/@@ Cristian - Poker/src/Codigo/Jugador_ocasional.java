/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Codigo;


/**
 *
 * @author cristiandiaz
 */
public class Jugador_ocasional extends Jugador {
    
    private String tarjeta;
    
    /**
     * Constructor de la clase Jugador_ocasional
     * @param nif : String
     * @param nombre : String
     * @param apellidos : String
     * @param fechaNacimiento : String
     * @param tarjeta : String
     */
    public Jugador_ocasional(String nif, String nombre, String apellidos, String fechaNacimiento,String tarjeta) {
        super(nif, nombre, apellidos, fechaNacimiento);
        this.tarjeta = tarjeta;
    }
    /**
     * Metodo getter del atributo tarjeta
     * 
     * @return tarjeta : String 
     */
    public String getTarjeta() {
        return tarjeta;
    }
    /**
     * Metodo setter del atributo tarjeta
     * 
     * @param tarjeta : String
     */
    public void setTarjeta(String tarjeta) {
        this.tarjeta = tarjeta;
    }
    
    /**
     * Metodo para retiar los beneficios del jugador.
     * 
     * @return w : double
     */
    @Override
    public double retirarBeneficios() {
        double w = 0;
        if (this.getSaldo()>0){
            w = this.getSaldo();
            this.setSaldo(0);
            
        }
        return w;
    }
    
}
