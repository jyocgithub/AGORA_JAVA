/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Codigo;

import java.util.ArrayList;

/**
 *
 * @author cristiandiaz
 */
public class Apuesta {

    private ArrayList<Carta> mimano;
    private Jugador jug;
    private int premio;
    private int cartaPremiadaUno;
    private int cartaPremiadaDos;
   

    /**
     * Metodo constructor de Apuesta.
     *
     * @param mimano : arrayList de cartas a meter en la apuesta
     * @param jug : jugador que hace la apuesta
     */
    public Apuesta(ArrayList<Carta> mimano, Jugador jug) {
        this.mimano = mimano;
        this.jug = jug;

    }
    

    /**
     * Metodo que se encarga de ver si nuestra apuesta tiene premio. Recorro el
     * ArrayList de mimano y extraigo las figuras y las almaceno en un contador.
     * Despues clasifico lo que contiene este contador. Tengo atributos
     * booleanos que me indican si hay grupos de figuras.
     *
     * @return int : multiplicador del valor de la apuesta. Depende del tipo de
     * jugador que sea.
     */
    public int verPremio() {

        int multiplicador = 0;
        int[] contador = new int[12];

        boolean haygruposde2 = false;
        boolean haygruposde3 = false;
        boolean haygruposde4 = false;
        boolean haycolor = false;

        /* 
        Creo un bucle para recorrer mi Array de mano. Extraigo la figura de cada una 
        de las posiciones y las almaceno en un contador.
         */
        for (int i = 0; i < 5; i++) {
            Carta p = mimano.get(i);
            int fig = p.getFigura();
            contador[fig]++;
        }
        /*
        Creo un bucle para recorrer el Array contador. Tengo que ir viendo si hay grupos
        de cartas en este Array. En caso de haberlas se activaran contadores de cada tipo.
         */
        int cuantosGruposDos = 0;
        for (int i = 0; i < 12; i++) {
            switch (contador[i]) {
                case 4:
                    haygruposde4 = true;
                    break;
                case 3:
                    haygruposde3 = true;
                    break;
                case 2:
                    haygruposde2 = true;
                    cuantosGruposDos++;
                    break;
                default:
                    break;
            }
        }

        /*
        Para saber que hay color tenemos que extraer el palo de cada carta y compararlos.
        Si el segundo es igual al primero, y el tercero igual al segundo etc... Tendremos 
        color.
         */
        int palo0 = mimano.get(0).getPalo();

        int palo1 = mimano.get(1).getPalo();

        int palo2 = mimano.get(2).getPalo();

        int palo3 = mimano.get(3).getPalo();

        int palo4 = mimano.get(4).getPalo();

        if (palo0 == palo1 && palo1 == palo2 && palo2 == palo3 && palo3 == palo4) {
            haycolor = true;
        }

        // Nuevo condicional para los premio
        if (haygruposde3 == true && haygruposde2 == true) {     // Full
            if (jug instanceof Jugador_ocasional) {
                multiplicador = 5;
            } else {
                multiplicador = 8;
            }

        } else if (haygruposde2 == true && cuantosGruposDos == 2) {        // Doble pareja
            multiplicador = 2;
        } else if (haygruposde3 == true) {             // Trio
            if (jug instanceof Jugador_ocasional) {
                multiplicador = 3;
            } else {
                multiplicador = 4;
            }
        } else if (haycolor == true) {                 // Color
            if (jug instanceof Jugador_ocasional) {
                multiplicador = 4;
            } else {
                multiplicador = 6;
            }
        } else if (haygruposde4 == true) {             // Poker
            if (jug instanceof Jugador_ocasional) {
                multiplicador = 6;
            } else {
                multiplicador = 10;
            }
        } else if (haygruposde2 == true) {                 // Pareja
            multiplicador = 1;
        }

        return multiplicador;
    }

    public int verPremioMesa() {

        int multiplicador = 0;
        int[] contador = new int[12];

        boolean haygruposde2 = false;
        boolean haygruposde3 = false;
        boolean haygruposde4 = false;
        boolean haycolor = false;

        /* 
        Creo un bucle para recorrer mi Array de mano. Extraigo la figura de cada una 
        de las posiciones y las almaceno en un contador.
         */
        for (int i = 0; i < 5; i++) {
            Carta p = mimano.get(i);
            int fig = p.getFigura();
            contador[fig]++;
        }
        /*
        Creo un bucle para recorrer el Array contador. Tengo que ir viendo si hay grupos
        de cartas en este Array. En caso de haberlas se activaran contadores de cada tipo.
        cartaPremiadaUno hace referencia a la figura de la primera combinacion de la mano
        cartaPremiadaDos hace referencia a la figura de la segunda combiacion de la mano.
        
        En el caso 4 si tenemos una combinacion con 4 cartas no podran ocurrir mas casos.
        En el caso 3 puede pasar que haya una pareja antes que yo entonces seriamos un 
        Full o puede que no hubiese nada antes en cuyo caso seriamos un trio.
        En el caso 2 puede ocurrir que hubiese una pareja antes ( seriamos una doble pareja)
        podria darse el del trio antes y seriamos un full, o podria no haber nada, en cuyo caso 
        seria una pareja.
         */
        int cuantosGruposDos = 0;
        cartaPremiadaDos = -1;
        cartaPremiadaUno = -1;
        premio = -9;

        for (int i = 0; i < 12; i++) {
            
            switch (contador[i]) {
                case 4:
                    haygruposde4 = true;
                    premio = Premio.POKER;
                    cartaPremiadaUno = i;
                    break;
                case 3:
                    haygruposde3 = true;
                    if (premio == Premio.PAREJA) {
                        cartaPremiadaDos = cartaPremiadaUno;
                        cartaPremiadaUno = i;
                        premio = Premio.FULL;
                    } else {
                        premio = Premio.TRIO;
                        cartaPremiadaUno = i;
                    }
                    break;
                case 2:
                    haygruposde2 = true;
                    if (cartaPremiadaUno == -1) {
                        premio = Premio.PAREJA;
                        cartaPremiadaUno = i;
                    } else if (premio == Premio.TRIO) {
                        premio = Premio.FULL;
                        cartaPremiadaDos = i;

                    } else if (premio == Premio.PAREJA) {
                        cartaPremiadaDos = cartaPremiadaUno;
                        cartaPremiadaUno = i;
                        premio = Premio.DOBLE_PAREJA;
                    } 
                    cuantosGruposDos++;
                    break;
                default:
                    break;
            }
        }

        /*
        Para saber que hay color tenemos que extraer el palo de cada carta y compararlos.
        Si el segundo es igual al primero, y el tercero igual al segundo etc... Tendremos 
        color.
         */
        int palo0 = mimano.get(0).getPalo();

        int palo1 = mimano.get(1).getPalo();

        int palo2 = mimano.get(2).getPalo();

        int palo3 = mimano.get(3).getPalo();

        int palo4 = mimano.get(4).getPalo();

        if (palo0 == palo1 && palo1 == palo2 && palo2 == palo3 && palo3 == palo4) {
            haycolor = true;
        }

        // Nuevo condicional para los premios
        if (haygruposde3 == true && haygruposde2 == true) {     // Full
            multiplicador = 8;
        } else if (haygruposde2 == true && cuantosGruposDos == 2) {        // Doble pareja
            multiplicador = 2;
        } else if (haygruposde3 == true) {             // Trio
            multiplicador = 4;
        } else if (haycolor == true) {                 // Color
            multiplicador = 6;
        } else if (haygruposde4 == true) {             // Poker
            multiplicador = 10;
        } else if (haygruposde2 == true) {                 // Pareja
            multiplicador = 1;
        }

        return multiplicador;
    }

    public int getPremio() {
        return premio;
    }

    public int getCartaPremiadaUno() {
        return cartaPremiadaUno;
    }

    public int getCartaPremiadaDos() {
        return cartaPremiadaDos;
    }

    public ArrayList<Carta> getMimano() {
        return mimano;
    }

    public Jugador getJug() {
        return jug;
    }
            /**
     * Metodo que contiene un bucle que recorre el ArrayMano y pinta cada una de
     * las posiciones
     *
     */
    public void pintarmanoConsola() {
        for (int i = 0; i < mimano.size(); i++) {
            System.out.println(mimano.get(i));
        }

    }
}
