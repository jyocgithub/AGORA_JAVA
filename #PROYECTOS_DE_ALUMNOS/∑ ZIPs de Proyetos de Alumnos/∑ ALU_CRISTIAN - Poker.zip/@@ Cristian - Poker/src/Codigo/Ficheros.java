/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Codigo;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.HashMap;
import java.util.logging.Level;
import java.util.logging.Logger;


/**
 * Ficheros : Clase que contiene ficheros.
 * 
 * @author cristiandiaz
 * @version 1.0
 */
public class Ficheros {
    
    

    /**
     * Metodo para guardar el HashMap en un fichero.
     * @param casaApuestas : CasaApuestas
     */
    public static void guardarMapa(CasaApuestas casaApuestas) {
        
        
        
        File f = null;
        ObjectOutputStream oos = null;

        try {

            f = new File("jugadores.dat");
            oos = new ObjectOutputStream(new FileOutputStream(f));

            oos.writeObject(casaApuestas.getLista());

        } catch (IOException ex) {

        } finally {
            try {
                oos.close();
            } catch (IOException ex) {
                Logger.getLogger(CasaApuestas.class.getName()).log(Level.SEVERE, null, ex);
            }
        }

    }

    
    /**
     * Metodo para leer la informacion de un fichero que contiene un HashMap.
     * @return lista : HashMap
     */
    public static HashMap<String, Jugador_registrado> leerMapa() {
        HashMap<String, Jugador_registrado> lista = new HashMap<>();
        File f = null;
        ObjectInputStream oos = null;

        try {

            f = new File("jugadores.dat");
            oos = new ObjectInputStream(new FileInputStream(f));

            Object ooo  = oos.readObject();
            lista = (HashMap<String, Jugador_registrado>) ooo;

        } catch (IOException ex) {
           ex.printStackTrace();
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(Ficheros.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            try {
                oos.close();
            } catch (IOException ex) {
                Logger.getLogger(CasaApuestas.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        return lista;
    }
}
