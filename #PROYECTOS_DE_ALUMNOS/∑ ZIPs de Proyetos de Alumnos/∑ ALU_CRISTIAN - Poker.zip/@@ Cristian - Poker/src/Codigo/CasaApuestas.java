/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Codigo;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.HashMap;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author cristiandiaz
 */
public class CasaApuestas {

    private Jugador_registrado jug;
    private Apuesta unaApuesta;
    HashMap<String, Jugador_registrado> lista;

    /**
     * Metodo constructor de CasaApuestas.
     *
     * @param jug : Jugador_registrado
     * @param unaApuesta : Apuesta
     * @param lista : HashMap
     */
    public CasaApuestas(Jugador_registrado jug, Apuesta unaApuesta, HashMap<String, Jugador_registrado> lista) {
        this.jug = jug;
        this.unaApuesta = unaApuesta;
        this.lista = lista;
    }

    /**
     * Metodo getter del objeto Jugador
     *
     * @return jug : Jugador_registrado.
     */
    public Jugador_registrado getJug() {
        return jug;
    }
    /**
     * Metodo setter del objeto Jugador
     *
     * @param jug : Jugador_registrado.
     */
    public void setJug(Jugador_registrado jug) {
        this.jug = jug;
    }

    /**
     * Metodo getter del objeto Apuesta
     *
     * @return unaApuesta : Apuesta.
     */
    public Apuesta getUnaApuesta() {
        return unaApuesta;
    }

    /**
     * Metodo setter del objeto Apuesta
     *
     * @param unaApuesta : Apuesta.
     */
    public void setUnaApuesta(Apuesta unaApuesta) {
        this.unaApuesta = unaApuesta;
    }

    /**
     * Metodo para dar alta de un jugador. Lo introduce en el HashMap.
     *
     * @param jr : Jugador_registrado.
     */
    public void altaJugador(Jugador_registrado jr) {
        lista.put(jr.getNif(), jr);

    }

    /**
     * Metodo para dar baja a un jugador. Lo elimina del HashMap
     *
     * @param nif : String
     * @return beneficios : double.
     */
    public double bajaJugador(String nif) {
        double beneficios = -1;
        if (lista.containsKey(nif)) {

            Jugador x = lista.get(nif);
            beneficios = x.retirarBeneficios();
            lista.remove(nif);
        }
        // -1 El jugador no existe
        // 0 El jugador no tiene dinero
        // cualquier otro es el dinero que devuelve. 
        return beneficios;
    }

    /**
     * Metodo para Juardar la informacion del jugador en un fichero.
     * @param jug : Jugador_registrado.
     */
    public void guardarJugador(Jugador_registrado jug) {

        File f = null;
        ObjectOutputStream oos = null;

        try {

            f = new File(jug.getNombre() + jug.getNif() + ".dat");
            oos = new ObjectOutputStream(new FileOutputStream(f));

            oos.writeObject(jug);

        } catch (IOException ex) {

        } finally {
            try {
                oos.close();
            } catch (IOException ex) {
                Logger.getLogger(CasaApuestas.class.getName()).log(Level.SEVERE, null, ex);
            }
        }

    }
   
    /**
     * Metodo getter del HashMap.
     *
     * @return lista : HashMap
     */
    public HashMap<String, Jugador_registrado> getLista() {
        return lista;
    }
    
    /**
     * Metodo setter del HashMap
     *
     * @param lista : HashMap
     */
    public void setLista(HashMap<String, Jugador_registrado> lista) {
        this.lista = lista;
    }

}
