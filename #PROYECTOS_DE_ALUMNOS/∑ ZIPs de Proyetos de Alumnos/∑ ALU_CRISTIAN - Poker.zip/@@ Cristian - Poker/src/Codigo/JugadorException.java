/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Codigo;

/**
 *
 * @author cristiandiaz
 */
public class JugadorException extends Exception {

    public JugadorException(String mensaje) {
        super(mensaje);
    }

    public JugadorException() {
        super("Se ha producido una excepcion: ");
    }

    public static final String SALDO_INSUFICIENTE = "No se dispone de saldo para realizar la apuesta.";
    public static final String NIF_INCORRECTO = "El NIF proporcionado no corresponde a ningún jugador registrado.";
    public static final String CONTRASEÑA_INCORRECTA = "Contraseña incorrecta.";
    public static final String EDAD_INCORRECTA = "El jugador debe ser mayor de edad para poder jugar";
    public static final String APUESTA_CERO = "No puedes introducir un importe igual o inferior a 0.";
    
    public static final String APUESTA_MAYOR_SALDO = "Introduce un importe menor que el saldo para poder continuar. ";
    public static final String DINERO_MAL = " No puedes introducir un aumento de dinero negativo.";
    public static final String FALTA_CASILLA = "Rellene todas las casillas para poder continuar";
    public static final String NIF_ERROEO = "El nif proporcionado no corresponde a ningun cliente";
    public static final String SELECCIONAR_JUGADOR = "Debes seleccionar un tipo de jugador para continuar. ";
    public static final String FECHA_SUPERIOR = "La fecha introducida es superior a la actual";

}
