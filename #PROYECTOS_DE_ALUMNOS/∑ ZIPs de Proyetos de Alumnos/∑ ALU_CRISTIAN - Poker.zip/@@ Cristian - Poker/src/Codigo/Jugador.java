/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Codigo;

import java.io.Serializable;
import java.time.LocalDate;

/**
 *
 * @author cristiandiaz
 */
public abstract class Jugador implements Serializable {

    private String nif;
    private String nombre;
    private String apellidos;
    private String fechaNacimiento;
    private double saldo = 5000;

    public Jugador() {

    }
    
    /**
     *
     * @param nif : String
     * @param nombre : String
     * @param apellidos : String
     * @param fechaNacimiento : String
     */
    public Jugador(String nif, String nombre, String apellidos, String fechaNacimiento) {
        this.nif = nif;
        this.nombre = nombre;
        this.apellidos = apellidos;
        this.fechaNacimiento = fechaNacimiento;

    }

    /**
     * Metodo getter del atributo nif del jugador
     *
     * @return String : nif del jugador
     */
    public String getNif() {
        return nif;
    }
      /**
     * Metodo setter del atributo nig
     *
     * @param nif : NIF del jugador
     */
    public void setNif(String nif) {
        this.nif = nif;
    }
    /**
     * Metodo getter del atributo nombre del jugador
     *
     * @return String : nombre del jugador
     */
    public String getNombre() {
        return nombre;
    }
    /**
     * Metodo setter del atributo nombre
     *
     * @param nombre : String nombre del jugador
     */
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    
    /**
     * Metodo getter del atributo apellidos
     * 
     * @return apellidos : String
     */
    public String getApellidos() {
        return apellidos;
    }
    /**
     * Metodo setter del atributo apellidos.
     *
     * @param apellidos : String
     */
    public void setApellidos(String apellidos) {
        this.apellidos = apellidos;
    }
    /**
     * Metodo getter del atributo fechaNacimiento
     * 
     * @return fechaNacimiento : String
     */
    public String getFechaNacimiento() {
        return fechaNacimiento;
    }
    /**
     * Metodo setter del atributo fechaNacimiento.
     *
     * @param fechaNacimiento : String
     */
    public void setFechaNacimiento(String fechaNacimiento) {
        this.fechaNacimiento = fechaNacimiento;
    }
    /**
     * Metodo getter del atributo saldo
     *
     * @return saldo : double
     */
    public double getSaldo() {
        return saldo;
    }
    
    /**
     * Metodo setter del atributo saldo.
     *
     * @param saldo : double
     */
    public void setSaldo(double saldo) {
        this.saldo = saldo;
    }
    
    /**
     * Metodo abstracto a implementar por los hijos, aumenta el saldo.
     * 
     * @return double
     */
    abstract public double retirarBeneficios();

    
    /**
     * Metodo que aumenta el saldo del jugador
     * 
     * @param saldo : double
     */
    public void aumentarSaldo(double saldo) {

        // this.setSaldo(saldo + this.getSaldo());
        this.saldo = this.saldo + saldo;
    }
    
    /**
     * Metodo que pinta informacion del jugador
     * 
     * @return String.
     */
    @Override
    public String toString() {
        return "NIF: " + nif + ", Nombre: " + nombre + ", saldo acumulado: " + saldo;
    }

}
