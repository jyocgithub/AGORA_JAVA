/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Codigo;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;

/**
 *
 * @author cristiandiaz
 */
public class Jugador_registrado extends Jugador implements Serializable {

    private String cuentaBancaria;
    private String contraseña;
    private Date fechaRegistro;

    private ArrayList<Premio> listaPremios;

        /**
     * Metodo constructor de la clase Jugador_Ocasional
     *
     * @param nif : String
     * @param nombre : String
     * @param apellidos : String
     * @param fechaNacimiento : String
     * @param cuentaBancaria : String
     * @param contraseña : String
     * @param fechaRegistro : Date
     */
    public Jugador_registrado(String nif, String nombre, String apellidos, String fechaNacimiento, String cuentaBancaria, String contraseña, Date fechaRegistro) {
        super(nif, nombre, apellidos, fechaNacimiento);
        this.cuentaBancaria = cuentaBancaria;
        this.contraseña = contraseña;
        this.fechaRegistro = fechaRegistro;
        listaPremios = new ArrayList<>();
    }

    public Jugador_registrado() {
        super();
    }

    /**
     * Metodo getter del atributo cuentaBancaria
     *
     * @return cuentaBancaria : String
     */
    public String getCuentaBancaria() {
        return cuentaBancaria;
    }

    /**
     * Metodo setter del atributo cuentaBancaria
     *
     * @param cuentaBancaria : String
     */
    public void setCuentaBancaria(String cuentaBancaria) {
        this.cuentaBancaria = cuentaBancaria;
    }

    /**
     * Metodo getter del atributo ontraseña
     *
     * @return contraseña : String
     */
    public String getContraseña() {
        return contraseña;
    }

    /**
     * Metodo setter del atributo contraseña
     *
     * @param contraseña : String
     */
    public void setContraseña(String contraseña) {
        this.contraseña = contraseña;
    }

    /**
     * Metodo getter del atributo fechaRegistro
     *
     * @return fechaRegistro : Date
     */
    public Date getFechaRegistro() {
        return fechaRegistro;
    }

    /**
     * Metodo setter del atributo fechaRegistro
     *
     * @param fechaRegistro : Date
     */
    public void setFechaRegistro(Date fechaRegistro) {
        this.fechaRegistro = fechaRegistro;
    }

    /**
     * Metodo para retiar los beneficios del jugador.
     *
     * @return w : double
     */
    @Override
    public double retirarBeneficios() {
        double w = 0;
        if (this.getSaldo() > 0) {
            w = this.getSaldo();
            this.setSaldo(0);

        }
        return w;
    }

    public ArrayList<Premio> getListaPremios() {
        return listaPremios;
    }

    public void setListaPremios(ArrayList<Premio> listaPremios) {
        this.listaPremios = listaPremios;
    }

}
