
package Codigo;

import java.io.Serializable;

/**
 *
 * @author cristiandiaz
 */
public class Premio implements Serializable{
    
    private double importePremio;
    private String tipoJuego;
    private int tipoPremio;
    
    public static final int PAREJA = 0; 
    public static final int DOBLE_PAREJA = 1; 
    public static final int TRIO = 2; 
    public static final int FULL = 4; 
    public static final int POKER = 5; 
    public static final int COLOR = 3; 
     
    
    
    public Premio(double importePremio,String tipoJuego,int tipoPremio){
        this.importePremio = importePremio;
        this.tipoJuego = tipoJuego;
        this.tipoPremio = tipoPremio;
    }

    
    public double getImportePremio() {
        return importePremio;
    }

    public void setImportePremio(double importePremio) {
        this.importePremio = importePremio;
    }

    public String getTipoJuego() {
        return tipoJuego;
    }

    public void setTipoJuego(String tipoJuego) {
        this.tipoJuego = tipoJuego;
    }

    public int getTipoPremio() {
        return tipoPremio;
    }

    public void setTipoPremio(int tipoPremio) {
        this.tipoPremio = tipoPremio;
    }
    
    
    
    
}
