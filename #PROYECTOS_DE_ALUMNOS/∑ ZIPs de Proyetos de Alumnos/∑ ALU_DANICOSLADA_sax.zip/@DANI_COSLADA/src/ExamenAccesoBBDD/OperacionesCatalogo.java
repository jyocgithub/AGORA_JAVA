package ExamenAccesoBBDD;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class OperacionesCatalogo implements DAO<Producto>{
	
	private static final String insert="insert into productos values(?,?,?)"; 
	private static final String select="select * from productos";
	private static final String muestraprecios="select * from productos where precio>?";
	
	private Statement statement=null;
	private PreparedStatement preparedStatement=null;
	private ResultSet resultset=null;
	private Connection connection;
	
	public OperacionesCatalogo(Connection connection) {
		
		//la conexion la voy a recibir de un objeto de la clase DBConecction. 
		this.connection=connection;
	}

   public void save(Producto producto) {
		
		try {
			preparedStatement = connection.prepareStatement(insert);
			preparedStatement.setInt(1, producto.getCod_producto()+1);
			preparedStatement.setString(2, producto.getNombre());
			preparedStatement.setInt(3, producto.getPrecio());
			
			int resultado=preparedStatement.executeUpdate();
		
			if(resultado!=0) System.out.println("producto a�adido"); //para indicar que se ha a�adido
			
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
	}
   
   public void modificaPrecio(int porcentaje) {
	   double descuento = porcentaje * 0.01;
		try {
			connection.setAutoCommit(false); // lo cambio para que no modifique auto�tico
			statement = connection.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
			resultset = statement.executeQuery(select);
			while (resultset.next()) {
				float precioActual = resultset.getInt("precio");
				double aDescontar = precioActual * descuento;
				double precioNuevo = Math.floor(precioActual - aDescontar);
				resultset.updateDouble("precio", precioNuevo);
				resultset.updateRow();
				connection.commit(); // por cada uno hago yo el commit
			}

		} catch (SQLException e) {
			e.printStackTrace();
			try {
				connection.rollback(); // si salta la excepci�n porque pasa algo se deshace.
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
		} finally {

			try {
				if (resultset != null)
					resultset.close();
				if (statement != null)
					statement.close();
				connection.setAutoCommit(true);
			} catch (SQLException e) {
				e.printStackTrace();
			}

		}

	}
	
   
    //para mostrar los precios del rango 
   public ArrayList<Producto>muestraPrecios(int precioRango){
	   ArrayList<Producto> productos = new ArrayList<>();
       Producto producto;
		try {
			preparedStatement = connection.prepareStatement(muestraprecios);
			preparedStatement.setInt(1, precioRango);
			resultset = preparedStatement.executeQuery();
			while (resultset.next()) {
				int cod_producto=resultset.getInt(1);
				String nom=resultset.getString(2);
				int precio=resultset.getInt(3);
				producto=new Producto(cod_producto,nom,precio);
				productos.add(producto);
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (resultset != null) {
				try {
					resultset.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			
		}
		return productos;
   }

	@Override
	public ArrayList<Producto> getAll() {
		ArrayList<Producto> productos = new ArrayList<>();
         Producto producto;
		try {
			statement = connection.prepareStatement(select);
			resultset = statement.executeQuery(select);
			while (resultset.next()) {
				int cod_producto=resultset.getInt(1);
				String nom=resultset.getString(2);
				int precio=resultset.getInt(3);
				producto=new Producto(cod_producto,nom,precio);
				productos.add(producto);
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (resultset != null) {
				try {
					resultset.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			
		}
		return productos;
	}

	

	
	

}
