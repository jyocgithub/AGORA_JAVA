package ExamenAccesoBBDD;

import java.util.List;

public interface DAO <T>{
	
	 //solo voy a implementar la operacion de guardar
	 // public T get(T id) ;
	
	  public List<T> getAll();
	  
	  public void save(T t);
	  
	 // public void delete(T t)throws DAOException;   
	  
	 // public void update(T t);

}
