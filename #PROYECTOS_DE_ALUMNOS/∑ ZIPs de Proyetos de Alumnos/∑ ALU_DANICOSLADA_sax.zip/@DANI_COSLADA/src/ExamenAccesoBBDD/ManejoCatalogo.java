package ExamenAccesoBBDD;

import java.util.ArrayList;
import java.util.Scanner;

public class ManejoCatalogo {

    public static void main(String[] args) {

        //creo los parametros de conexion
        String lineaConexion = "jdbc:mysql://localhost:3306/catalogo?autoReconnect=true&useSSL=false&serverTimezone=GMT";
        String user = "root";
        String password = "1234";

        //instancio el singleton y le paso mi conexion propia
        DBConnection objetoDBConnection = DBConnection.getInstance(lineaConexion, user, password);
        OperacionesCatalogo operarCatalogo = new OperacionesCatalogo(objetoDBConnection.getConnection());

        Scanner scan = new Scanner(System.in);
        int opcion = 0; //opcion para a�adir los registros que quiera


        do {
            System.out.println("MENU");
            System.out.println("1.- A�ADIR PRODUCTO");
            System.out.println("0.- Mostrar el catalogo y realizar otras operaciones");
            opcion = scan.nextInt();

            if (opcion == 1) {

                //  no dejar que el codigo de producto introducido por usuario este repetido;

                // opcion 1, con el metodo contains de ArrayList
//                boolean seguirenelbucle = true;
//                Producto producto;
//                ArrayList<Producto> listaproductos = operarCatalogo.getAll();
//                while (seguirenelbucle) {
//                    System.out.println("Codigo producto: ");
//                    int codigo = scan.nextInt();
//                    System.out.println("Nombre: ");
//                    String nombre = scan.next();
//                    System.out.println("Precio: ");
//                    int precio = scan.nextInt();
//                    producto = new Producto(nombre, precio);
//                    if (listaproductos.contains(producto)) {
//                        System.out.println("Codigo de producto existente, intente con otro");
//                    } else {
//                        seguirenelbucle = false;
//                    }
//                }

                // opcion 2, mirando uno a uno todos los codigos ya existentes
                boolean seguirenelbucle = true;
                Producto producto;
                ArrayList<Producto> listaproductos = operarCatalogo.getAll();
                while (seguirenelbucle) {
                    System.out.println("Codigo producto: ");
                    int codigo = scan.nextInt();
                    boolean existeElCodigo = false;
                    for (Producto pro : listaproductos) {
                        if (pro.getCod_producto() == codigo) {
                            existeElCodigo = true;
                            System.out.println("Codigo de producto existente, intente con otro");
                        }
                    }
                    if (!existeElCodigo) {
                        System.out.println("Nombre: ");
                        String nombre = scan.next();
                        System.out.println("Precio: ");
                        int precio = scan.nextInt();
                        producto = new Producto(nombre, precio);
                        operarCatalogo.save(producto);

                        seguirenelbucle = false;
                    }
                }

            } else {
                System.out.println(operarCatalogo.getAll());
            }


        } while (opcion != 0);

        System.out.println("\n mostrar los datos de productos con precio superior a: ");
        int preciomayorque = scan.nextInt();
        //int preciomayorque=Integer.parseInt(precio);
        System.out.println(operarCatalogo.muestraPrecios(preciomayorque));

        System.out.println("\n introduce el porcentaje a modificar");
        int porcentaje = scan.nextInt();
        operarCatalogo.modificaPrecio(porcentaje);
        scan.close();
    }

}
