package ExamenAccesoBBDD;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnection {
    
	//solo puedo generar un objeto desde esta clase (singleton)
	private static DBConnection instance;
	private Connection connection;

	private DBConnection(String lineaConexion, String user, String password) {

		try {

			//Class.forName("com.mysql.jdbc.Driver"); ya no es necesario, lanza un deprecated

			connection = DriverManager.getConnection(lineaConexion, user, password);

		} catch (SQLException e) {
			e.printStackTrace();
		}

	}

	public Connection getConnection() {

		return connection;
	}
   
	public static DBConnection getInstance(String lineaConexion, String user, String password) {

		if (instance == null) {
			instance = new DBConnection(lineaConexion,user,password);
		} else
			try {
				if (instance.getConnection().isClosed()) {
					instance = new DBConnection(lineaConexion,user,password);
				}
			} catch (SQLException e) {

				e.printStackTrace();
			}
		return instance;
	}

}