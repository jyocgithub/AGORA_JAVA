package ExamenAccesoBBDD;

public class Producto{

	 private int cod_producto=0; //para no repetir el cod_producto
	 private String nombre;
	 private int precio;
	 
	 public Producto(int cod_producto,String nombre,int precio) {
		 
		 this.cod_producto=cod_producto;
		 this.nombre=nombre;
		 this.precio=precio;
	 }
  public Producto(String nombre,int precio) {
		 //este constructor permite la insercion de productos y evita repetir el id ya que es unico.
		 
		 
		 this.nombre=nombre;
		 this.precio=precio;
		 System.out.println(cod_producto);
	 }

	public int getCod_producto() {
		return cod_producto;
	}

	public void setCod_producto(int cod_producto) {
		this.cod_producto = cod_producto;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public int getPrecio() {
		return precio;
	}

	public void setPrecio(int precio) {
		this.precio = precio;
	}
	
	//sobreescribir toString para que me lo muestre as�
	public String toString() {
		return cod_producto+ " - "+nombre+ " - "+precio;
		
	}
}
