
import java.io.Serializable;


public class Jugador implements Serializable {

    //public enum Posicion{PORTERO, DEFENSA, CENTROCAMPISTA, DELANTERO};

    private String nombre;
    private int dorsal;
    private String posicion;

    public Jugador(int dorsal, String nombre, String posicion) {

        this.dorsal = dorsal;
        this.nombre = nombre;
        this.posicion = posicion;

    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getDorsal() {
        return dorsal;
    }

    public void setDorsal(int dorsal) {
        this.dorsal = dorsal;
    }

    public String getPosicion() {
        return posicion;
    }

    public void setPosicion(String pos) {

    }

    @Override
    public String toString() {
        return "Jugador{" + "nombre='" + nombre + '\'' + ", dorsal=" + dorsal + ", posicion='" + posicion + '\'' + '}';
    }
}
