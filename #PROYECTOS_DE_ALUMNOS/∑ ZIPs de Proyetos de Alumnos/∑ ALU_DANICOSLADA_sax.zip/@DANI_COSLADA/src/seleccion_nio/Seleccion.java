import java.util.ArrayList;
import java.util.Scanner;

public class Seleccion {

    JugadorDao judao;

    public static void main(String[] args) {
        Seleccion s = new Seleccion();
        System.out.println("Bienvenido Seleccionador! \n");
        s.menu();
    }

    public void menu() {
        judao = new JugadorDao();

        // Inicialmente, llamamos al metodo que LEE FISICAMENTE el fichero
        // y guarda la informacion en un buffer
        judao.leerFichero();

        int opcion = 0;

        Scanner scan = new Scanner(System.in);

        do {
            System.out.println("MENU");
            System.out.println("1.- ANADIR/MODIFICAR UN JUGADOR");
            System.out.println("2.- LISTAR TODOS");
            System.out.println("3.- MOSTRAR UN JUGADOR");
            System.out.println("4.- BORRAR UN JUGADOR");
            System.out.println("0.- SALIR");
            opcion = scan.nextInt();
            switch (opcion) {
                case 1:
                    System.out.println("Datos del Jugador:");
                    System.out.println("Dorsal:");
                    int dor = scan.nextInt();
                    System.out.println("Nombre: ");
                    String nom = scan.next();
                    System.out.println("Posicion: ");
                    String pos = scan.next();
                    Jugador jug = new Jugador(dor, nom, pos);
                    judao.anadir(jug);
                    break;
                case 2:
                    ArrayList<Jugador> lista = (ArrayList<Jugador>) judao.listar();
                    for (Jugador j : lista) {
                        Jugador k = judao.consultar(j.getDorsal());
                        System.out.println(j.toString());
                        System.out.println("_________________");
                    }
                    break;
                case 3:
                    System.out.println("Datos del Jugador:");
                    System.out.println("Dorsal:");
                    int dorsal = scan.nextInt();
                    Jugador k = judao.consultar(dorsal);
                    if (k == null) {
                        System.out.println("No existe jugador con ese dorsal");

                    } else {
                        System.out.println(k.toString());
                    }

                    System.out.println("-------------------");
                    break;
                case 4:
                    System.out.println("Datos del Jugador:");
                    System.out.println("Dorsal:");
                    int dorsal2 = scan.nextInt();
                    judao.borrar(dorsal2);
                    break;
            }

        } while (opcion != 0);

        // Finalmente, llamamos al metodo que guarda FISICAMENTE el buffer en un fichero
        judao.guardarFichero();
    }
}
