

import java.util.ArrayList;
import java.util.List;

public interface ISeleccion<T> {

    public List<T> listar();

    public void anadir(T a);

    public void borrar(int dorsal);

    public T consultar(int d);

    public void modificar(T jug);

}
