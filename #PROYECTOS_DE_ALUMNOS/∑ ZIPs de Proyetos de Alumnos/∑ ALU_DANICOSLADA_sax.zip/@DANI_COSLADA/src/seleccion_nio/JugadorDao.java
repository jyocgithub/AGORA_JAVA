

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.RandomAccessFile;
import java.nio.ByteBuffer;
import java.nio.channels.ByteChannel;
import java.util.ArrayList;
import java.util.List;

public class JugadorDao implements ISeleccion {

    public static final String NOMBREFICHERO = "jugadores.dat";
    public static final int TAMANO_MAX_CADA_JUGADOR = 500;
    public static final int NUM_MAX_JUGAD = 25;
    RandomAccessFile raf;
    ByteBuffer bufferJugadores;

    // Este método abre el fichero de jugadores, lo lee y lo mete en un buffer
    // el buffer (bufferJugadores) queda en memoria, y las acciones de consulta y
    // actualización se hacen siempre sobre el buffer
    public void leerFichero() {
        try {
            // abre un acceso al fichero con un RandomAccessFile
            raf = new RandomAccessFile(NOMBREFICHERO, "rw");
            // le pide al acceso al fichero que cree un channel, de tipo ByteChannel
            ByteChannel channelAlFichero = raf.getChannel();
            // se crea el buffer vacio con un tamaño de numero jugadores x tamaño de cada jugador
            bufferJugadores = ByteBuffer.allocate(TAMANO_MAX_CADA_JUGADOR * NUM_MAX_JUGAD);
            // usamos el channel que conecta con el fichero para leer este y meterlo en el buffer
            channelAlFichero.read(bufferJugadores);
            raf.close(); // deberia estar en un finally, pero esta aqui para ahorrar espacio :-)
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // Este método coge el buffer de jugadores y lo guarda en el fichero
    public void guardarFichero() {
        try {
            // abre un acceso al fichero con un RandomAccessFile
            raf = new RandomAccessFile(NOMBREFICHERO, "rw");
            bufferJugadores.flip(); // darme la vuelta porque estara al final
            ByteChannel channelAlFichero = raf.getChannel();

            channelAlFichero.write(bufferJugadores);
            raf.close(); // deberia estar en un finally, pero esta aqui para ahorrar espacio :-)
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    public List<Jugador> listar() {

        ArrayList<Jugador> lista = new ArrayList<>();
        byte[] trozo;
        for (int i = 0; i < NUM_MAX_JUGAD; i++) {
            int offset = i * TAMANO_MAX_CADA_JUGADOR;
            bufferJugadores.position(offset);
            trozo = new byte[500];
            bufferJugadores.get(trozo);
            if (trozo[0] != 0) {
                Jugador j = deserializar(trozo);
                lista.add(j);
            }
        }
        return lista;

    }

    @Override
    public void anadir(Object a) {
        Jugador j = (Jugador) a;
        byte[] trozo = serializar(j);
        int offset = j.getDorsal() * TAMANO_MAX_CADA_JUGADOR; // desplazamiento
        bufferJugadores.position(offset);
        bufferJugadores.put(trozo);
    }

    @Override
    public void borrar(int dorsal) {

        byte[] trozo = new byte[TAMANO_MAX_CADA_JUGADOR];
        int offset = dorsal * TAMANO_MAX_CADA_JUGADOR; // desplazamiento
        bufferJugadores.position(offset);
        bufferJugadores.put(trozo);

    }

    @Override
    public Jugador consultar(int dorsal) {
        Jugador j = null;
        int offset = dorsal * TAMANO_MAX_CADA_JUGADOR;
        bufferJugadores.position(offset);
        byte[] trozo = new byte[500];
        bufferJugadores.get(trozo);
        if (trozo[0] != 0) {
            j = deserializar(trozo);
        }
        return j;
    }

    public Jugador deserializar(byte[] trozo) {
        ByteArrayInputStream bais = new ByteArrayInputStream(trozo);
        ObjectInputStream ois = null;
        Jugador j = null;
        try {
            ois = new ObjectInputStream(bais);
            j = (Jugador) ois.readObject();

        } catch (IOException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } finally {
            if (ois != null) try {
                ois.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return j;
    }

    public byte[] serializar(Jugador j) {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        ObjectOutputStream oos = null;
        try {
            oos = new ObjectOutputStream(baos);
            oos.writeObject(j);
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return baos.toByteArray();
    }

    @Override
    public void modificar(Object a) {
        Jugador j = (Jugador) a;
        byte[] trozo = serializar(j);
        int offset = j.getDorsal() * TAMANO_MAX_CADA_JUGADOR; // desplazamiento
        bufferJugadores.position(offset);
        bufferJugadores.put(trozo);
    }

}
