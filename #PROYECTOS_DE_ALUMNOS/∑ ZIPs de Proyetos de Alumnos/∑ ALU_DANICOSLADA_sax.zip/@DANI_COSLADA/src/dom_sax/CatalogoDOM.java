//package dom_sax;
//
//import org.w3c.dom.Document;
//import org.w3c.dom.Element;
//import org.w3c.dom.Node;
//import org.w3c.dom.NodeList;
//import org.xml.sax.SAXException;
//
//import javax.xml.parsers.DocumentBuilder;
//import javax.xml.parsers.DocumentBuilderFactory;
//import javax.xml.parsers.ParserConfigurationException;
//import java.io.FileInputStream;
//import java.io.FileNotFoundException;
//import java.io.IOException;
//import java.util.ArrayList;
//
//
//public class CatalogoDOM {
//
//    private Document document;
//    private DocumentBuilderFactory builderFactory;
//    private DocumentBuilder builder;
//    private Element rootElement;
//    private String archivo;
//    String editorial = "", anyo = "", titulo = "", genre = "", price = "0", publish_date = "", description = "", lang = "", id = "0";
//    Node datoContenido, dato, unbook, nodolibro, unautor;
//    NodeList listaCatalogo, listahijoslibro ;
//    ArrayList<String> alistAutores ;
//    ArrayList<Libro> alistLibros;
//
//    public CatalogoDOM(String archivo) {
//
//        this.archivo = archivo;
//    }
//
//    public void readXml() {
//
//        //esto hay que crearlo si o si tipo Scanner para trabajar por teclado
//        builderFactory = DocumentBuilderFactory.newInstance();
//
//        try {
//
//            builder = builderFactory.newDocumentBuilder(); //mauquina de xml
//            document = builder.parse(new FileInputStream(archivo)); //aqui ya tengo en el objeto document todo el xml
//
//
//        } catch (FileNotFoundException e1) {
//            e1.printStackTrace();
//        } catch (IOException e1) {
//            e1.printStackTrace();
//        } catch (ParserConfigurationException e) {
//            e.printStackTrace();
//        } catch (SAXException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        }
//
//
//    }
//
//    public Catalogo crearCatalogoDOM() {
//        Catalogo catalogo = null;
//        rootElement = document.getDocumentElement();
//        listaCatalogo = rootElement.getChildNodes();
//
//        for (int m = 0; m < listaCatalogo.getLength(); m++) {
//            dato = listaCatalogo.item(m);
//            if (dato.getNodeName().equals("editorial")) {
//                datoContenido = dato.getFirstChild();
//                editorial = datoContenido.getNodeValue();
//            }
//            if (dato.getNodeName().equals("year")) {
//                datoContenido = dato.getFirstChild();
//                anyo = datoContenido.getNodeValue();
//            }
//            if (dato.getNodeName().equals("books")) {
//                NodeList listalibros = document.getElementsByTagName("book");
//                alistLibros = new ArrayList<>();
//
//                for (int x = 0; x < listalibros.getLength(); x++) {
//                    titulo = "";
//                    unbook = listalibros.item(x);
//                    //id=unbook.getAttributes().getNamedItem("id").getNodeName();
//                    ArrayList<String> listaautores = new ArrayList<>();
//                    NodeList listahijoslibro = unbook.getChildNodes();
//
//                    for (int t = 0; t < listahijoslibro.getLength(); t++) {
//                        nodolibro = listahijoslibro.item(t);
//
//                        Libro l = procesarLibro(nodolibro);
//
//                        if (l.getTitle().equals("")) {
//                            alistLibros.add(l);
//                        }
//                    }
//                }
//            }
//        }
//        catalogo = new Catalogo(editorial, Integer.parseInt(anyo), alistLibros);
//
//        return catalogo;
//    }
//
//    public Libro procesarLibro(Node nodolibro) {
//
//
//        if (nodolibro.getNodeName().equals("title")) {
//            datoContenido = nodolibro.getFirstChild();
//            titulo = datoContenido.getNodeValue();
//            //  lang =datoContenido.getAttributes().getNamedItem("lang").getNodeName();
//
//        }
//        if (nodolibro.getNodeName().equals("genre")) {
//            datoContenido = nodolibro.getFirstChild();
//            genre = datoContenido.getNodeValue();
//        }
//        if (nodolibro.getNodeName().equals("price")) {
//            datoContenido = nodolibro.getFirstChild();
//            price = datoContenido.getNodeValue();
//        }
//        if (nodolibro.getNodeName().equals("publish_date")) {
//            datoContenido = nodolibro.getFirstChild();
//            publish_date = datoContenido.getNodeValue();
//        }
//        if (nodolibro.getNodeName().equals("description")) {
//            datoContenido = nodolibro.getFirstChild();
//            description = datoContenido.getNodeValue();
//        }
//        if (nodolibro.getNodeName().equals("authors")) {
//            alistAutores = new ArrayList<>();
//
//            NodeList listaauthor = nodolibro.getChildNodes();
//            for (int g = 0; g < listaauthor.getLength(); g++) {
//                unautor = listaauthor.item(g);
//                String author = unautor.getNodeValue();
//                alistAutores.add(author);
//            }
//        }
//        Libro book = new Libro(alistAutores, Integer.parseInt(id), titulo, genre, lang, Double.parseDouble(price), publish_date, description);
//        return book;
//
//    }
//
//
//}
