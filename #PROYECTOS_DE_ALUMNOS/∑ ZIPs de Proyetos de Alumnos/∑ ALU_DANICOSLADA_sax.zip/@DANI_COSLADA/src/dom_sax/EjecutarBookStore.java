package dom_sax;

public class EjecutarBookStore {

	public static void main(String[] args) {
		
		Bookstore bookstore=new Bookstore("boockstore.xml"); 
		
		bookstore.readXml();
		
		Catalogo catalogo=bookstore.crearCatalogo();

		System.out.println("catalogo -------------------------------------------");
		System.out.println(catalogo.getEditorial());
		System.out.println(catalogo.getAnyo());
		for(Libro libro : catalogo.getLibros()) {
		System.out.println("libro -----------------");
			for(String autor  : libro.getAuthor()) {
				System.out.println("Autor:"+ autor);
			}

			System.out.println("Titulo:"+libro.getTitle());
            System.out.println("Genero:"+libro.getGenre());
			System.out.println("Precio:"+libro.getPrice());
			System.out.println("Publish_date:"+libro.getPublish_date());
			System.out.println("Description: "+libro.getDescription());
			System.out.println("Id :"+libro.getId());
			System.out.println("Lenguaje:"+libro.getLenguaje());
			
			
		}


	}

}
