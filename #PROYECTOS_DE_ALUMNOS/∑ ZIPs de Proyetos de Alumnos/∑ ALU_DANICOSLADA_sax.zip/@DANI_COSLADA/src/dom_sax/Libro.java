package dom_sax;

import java.util.ArrayList;

public class Libro {
	
	private ArrayList<String> author;
	private String id;
	private String title;
	private String lenguaje;
	private String genre;
	private double price;
	private String publish_date;
	private String description;
	
	@Override
	public String toString() {
		return "Libro [author=" + author + ", id=" + id + ", title=" + title + ", lenguaje=" + lenguaje + ", genre="
				+ genre + ", price=" + price + ", publish_date=" + publish_date + ", description=" + description + "]";
	}

	public Libro(ArrayList<String> author,String id,String title,String genre,String lenguaje,double price,String publish_date,String description) {
		
		this.lenguaje=lenguaje;
		this.id=id;
		this.author=author;
		this.title=title;
		this.genre=genre;
		this.price=price;
		this.publish_date=publish_date;
		this.description=description;
		
		
	}

	public ArrayList<String> getAuthor() {
		return author;
	}

	public void setAuthor(ArrayList<String> author) {
		this.author = author;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getLenguaje() {
		return lenguaje;
	}

	public void setLenguaje(String lenguaje) {
		this.lenguaje = lenguaje;
	}

	public String getGenre() {
		return genre;
	}

	public void setGenre(String genre) {
		this.genre = genre;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public String getPublish_date() {
		return publish_date;
	}

	public void setPublish_date(String publish_date) {
		this.publish_date = publish_date;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}
	

}
