package dom_sax;

import java.util.ArrayList;

public class Catalogo {
	
	private String editorial;
	private int anyo;
	private ArrayList<Libro> libros;
	
	
	
	@Override
	public String toString() {
		return "Catalogo [editorial=" + editorial + ", anyo=" + anyo + ", libros=" + libros + "]";
	}


	public Catalogo(String editorial, int anyo, ArrayList<Libro> libros) {
		this.editorial = editorial;
		this.anyo = anyo;
		this.libros = libros;
	}
	
	
	public String getEditorial() {
		return editorial;
	}
	public void setEditorial(String editorial) {
		this.editorial = editorial;
	}
	public int getAnyo() {
		return anyo;
	}
	public void setAnyo(int anyo) {
		this.anyo = anyo;
	}
	public ArrayList<Libro> getLibros() {
		return libros;
	}
	public void setLibros(ArrayList<Libro> libros) {
		this.libros = libros;
	}
	
	
	

}
