package dom_sax;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;
import org.w3c.dom.Node;


public class Bookstore {

    private Document document;
    private DocumentBuilderFactory builderFactory;
    private DocumentBuilder builder;
    private Element rootElement;
    private String archivo;
    String editorial = "", anyo = "", titulo = "", genre = "", author = "";
    String price = "0", publish_date = "", description = "", lang = "", id = "0";

    Node datoContenido, dato, unbook, nodoLibro, unautor;
    NodeList listaNodosLibro, listahijoslibro;
    ArrayList<String> alistAutores;
    ArrayList<Libro> alistLibros;

    public Bookstore(String archivo) {

        this.archivo = archivo;
    }

    public void readXml() {
        builderFactory = DocumentBuilderFactory.newInstance();
        try {
            builder = builderFactory.newDocumentBuilder(); //mauquina de xml
            document = builder.parse(new FileInputStream(archivo)); //aqui ya tengo en el objeto document todo el xml
        } catch (FileNotFoundException e1) {
            e1.printStackTrace();
        } catch (IOException e1) {
            e1.printStackTrace();
        } catch (ParserConfigurationException e) {
            e.printStackTrace();
        } catch (SAXException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }

    public Catalogo crearCatalogo() {

        Catalogo catalogo = null;
        rootElement = document.getDocumentElement();

        String nombreDelNodoRaiz = rootElement.getNodeName();  // para sacar el nombre de un elemento
        if (nombreDelNodoRaiz.equalsIgnoreCase("Catalog")) {
            alistLibros = new ArrayList<>();

            editorial = getValorNodoHijoSimple("editorial", rootElement);
            anyo = getValorNodoHijoSimple("year", rootElement);

            // ------ cada libro
            listaNodosLibro = rootElement.getElementsByTagName("book");
            // listaNodosLibro = document.getElementsByTagName("book");  // otra opcion

            for (int t = 0; t < listaNodosLibro.getLength(); t++) {
                nodoLibro = listaNodosLibro.item(t);
                inicializarVariablesLibro();

                id = getValorAtributo("id", nodoLibro);
                Libro l = procesarLibro(nodoLibro);

                if (!l.getTitle().equals("")) {
                    alistLibros.add(l);
                }
            }

        }

        anyo = (anyo.equals("")) ? "0" : anyo;
        catalogo = new Catalogo(editorial, Integer.parseInt(anyo), alistLibros);

        return catalogo;
    }


    public Libro procesarLibro(Node nodolibro) {
        titulo = getValorNodoHijoSimple("title", nodolibro);
        genre = getValorNodoHijoSimple("genre", nodolibro);
        price = getValorNodoHijoSimple("price", nodolibro);
        publish_date = getValorNodoHijoSimple("publish_date", nodolibro);
        description = getValorNodoHijoSimple("description", nodolibro);

        // necesitamos el nodo titulo para sacar de el el atributo lengua
        Node nodotitulo = getNodoSimple("title", nodolibro);
        lang = getValorAtributo("lang", nodotitulo);

        alistAutores = new ArrayList<>();
        NodeList listaNodosHijosDeLibro = ((Element) nodoLibro).getElementsByTagName("author");
        for (int g = 0; g < listaNodosHijosDeLibro.getLength(); g++) {
            unautor = listaNodosHijosDeLibro.item(g);
            author = getValorNodo(unautor);
            alistAutores.add(author);
        }

        price = (price.equals("")) ? "0" : price;
        Libro book = new Libro(alistAutores, id, titulo, genre, lang, Double.parseDouble(price), publish_date, description);
        return book;
    }

    /**
     * getNodoSimple
     * Extrae el contenido de una etiqueta XML que es hija única de su padre
     * <p>
     * si tenemos esto:
     * <persona>
     * <nombre> Pepe </nombre>
     * ...
     * <p>
     * <p>
     * y se sabe que la etiqueta <nombre> es unica dentro de Persona
     *
     * @param etiquetaABuscar (en el ejemplo, "nombre" , como String)
     * @param elementoPadre   (en el ejemplo, "Persona", como un objeto Element)
     * @return el valor de etiquetaABuscar (en el ejemplo, "Pepe")
     */
    public String getValorNodoHijoSimple(String etiquetaABuscar, Element elementoPadre) {
        String resultado = "";
        // sacar una lista de todos los nodo-etiqueta que se llame "etiquetaABuscar" y sea hijo de "elementoPadre"
        // con el ejemplo, esto da una lista de elementos <nombre>
        NodeList listaNodosHijos = elementoPadre.getElementsByTagName(etiquetaABuscar);
        // sacar el unico nodo-etiqueta que tiene esa lista (se sabe que el nodo es simple)
        // con el ejemplo, esto da el unico elemento <nombre> que existe
        Node nodo = listaNodosHijos.item(0);
        // sacar del nodo-etiqueta su único hijo, que es el CONTENIDO de la etiqueta (que sigue siendo un nodo...)
        // en el ejemplo, es Pepe, pero con formato de nodo
        if (nodo != null) {
            Node contenido = nodo.getFirstChild();
            // sacar del nodo-contenido su valor
            // en el ejemplo, ahora si, la cadena "Pepe"
            resultado = contenido.getNodeValue();
        }
        return resultado;
    }

    /**
     * getNodoSimple
     * Version sobrecargada, con Node en vez de Element
     */
    public String getValorNodoHijoSimple(String etiquetaABuscar, Node nodoPadre) {
        Element elementoPadre = (Element) nodoPadre;
        return getValorNodoHijoSimple(etiquetaABuscar, elementoPadre);
    }

    public String getValorAtributo(String atributoABuscar, Node nodoPadre) {
        String resultado = "";
        NamedNodeMap nnm = nodoPadre.getAttributes();
        Node attr = nnm.getNamedItem(atributoABuscar);
        if (attr != null) {
            resultado = attr.getNodeValue();
        }
        return resultado;
    }

    public String getValorNodo(Node nodo) {
        String resultado = nodo.getFirstChild().getNodeValue();
        return resultado;
    }


    public Node getNodoSimple(String etiquetaABuscar, Element elementoPadre) {
        Node resultado = null;
        // sacar una lista de todos los nodo-etiqueta que se llame "etiquetaABuscar" y sea hijo de "elementoPadre"
        // con el ejemplo, esto da una lista de elementos <nombre>
        NodeList listaNodosHijos = elementoPadre.getElementsByTagName(etiquetaABuscar);
        // sacar el unico nodo-etiqueta que tiene esa lista (se sabe que el nodo es simple)
        // con el ejemplo, esto da el unico elemento <nombre> que existe
        Node nodo = listaNodosHijos.item(0);
        return nodo;
    }

    public Node getNodoSimple(String etiquetaABuscar, Node nodoPadre) {
        Element elementoPadre = (Element) nodoPadre;
        return getNodoSimple(etiquetaABuscar, elementoPadre);
    }

    public void inicializarVariablesLibro() {
        titulo = "";
        genre = "";
        author = "";
        price = "0";
        publish_date = "";
        description = "";
        lang = "";
        id = "0";
    }
}
