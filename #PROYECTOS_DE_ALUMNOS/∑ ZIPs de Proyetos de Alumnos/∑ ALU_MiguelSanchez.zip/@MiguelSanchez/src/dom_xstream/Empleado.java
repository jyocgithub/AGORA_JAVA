package dom_xstream;

import java.io.Serializable;

class Empleado implements Serializable {
    int id;
    String nombre;
    Departamento departamento;

    public Empleado(int id, String nombre, Departamento departamento, double salario) {
        this.id = id;
        this.nombre = nombre;
        this.departamento = departamento;
        salario = salario;
    }
}
