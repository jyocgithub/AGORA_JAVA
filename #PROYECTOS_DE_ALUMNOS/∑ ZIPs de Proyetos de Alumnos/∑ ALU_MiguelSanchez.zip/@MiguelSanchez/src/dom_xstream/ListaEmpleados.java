package dom_xstream;

import java.io.Serializable;
import java.util.ArrayList;

class ListaEmpleados  implements Serializable {
    ArrayList<Empleado> lista;

    public ListaEmpleados() {
        lista = new ArrayList<>();
    }

    public void addEmpleado(Empleado e) {
        lista.add(e);
    }

    public ArrayList<Empleado> getLista() {
        return lista;
    }
}
