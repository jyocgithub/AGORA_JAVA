package dom_xstream;

import java.io.Serializable;

class Departamento  implements Serializable {
    int idDepartamento;
    String nombreDepartamento;

    public Departamento(int idDepartamento, String nombreDepartamento) {
        this.idDepartamento = idDepartamento;
        this.nombreDepartamento = nombreDepartamento;
    }


}
