package dom_xstream;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import com.thoughtworks.xstream.XStream;
import com.thoughtworks.xstream.security.NoTypePermission;
import com.thoughtworks.xstream.security.NullPermission;
import com.thoughtworks.xstream.security.PrimitiveTypePermission;


public class LeerFichEmpleadosDeptoXML {

	
	static FileInputStream fis;
	
	public static void main(String[] args) {

		ListaEmpleados listaEmp = new ListaEmpleados();
		XStream xs = new XStream();
		
		xs.addPermission(NoTypePermission.NONE);
		xs.addPermission(NullPermission.NULL);
		xs.addPermission(PrimitiveTypePermission.PRIMITIVES);
		
		Class[] clases = {ListaEmpleados.class, Empleado.class, Departamento.class};
		xs.allowTypes(clases);
		
		xs.allowTypesByWildcard(new String[] {"pruebas.javabin.*"});
		
		xs.alias("listaEmpleados", ListaEmpleados.class);
		xs.alias("empleado", Empleado.class);
		xs.alias("departamento", Departamento.class);
		xs.addImplicitCollection(ListaEmpleados.class, "lista");
		
		try {
			fis = new FileInputStream("empleadosDepto.xml");
			listaEmp = (ListaEmpleados) xs.fromXML(fis);
			
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} finally {
			if(fis != null)
				try {
					fis.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
		}
		for (Empleado emp : listaEmp.getLista()) {
			System.out.println(emp);
		}
		
	}

}
