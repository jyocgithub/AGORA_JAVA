package dom_xstream;

import com.thoughtworks.xstream.XStream;

import java.io.EOFException;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.ArrayList;

//import com.thoughtworks.xstream.XStream;

public class GenFichEmpleadosDeptoXML {

    static ObjectInputStream ois;

    public static void main(String[] args) {

        Empleado emp;
        Departamento depto;
        ListaEmpleados lista = new ListaEmpleados();


        try {
            ois = new ObjectInputStream(new FileInputStream("empleadosDeptoObj.dat"));

            try {
                while ((emp = (Empleado) ois.readObject()) != null) {
                    lista.addEmpleado(emp);
                }
            } catch (ClassNotFoundException e) {
                e.printStackTrace();
            } catch (EOFException e) {
                System.out.println("Fin del fichero");
            }

            //Generar fichero xml con XStream

            XStream xs = new XStream();
            xs.alias("listaEmpleados", ListaEmpleados.class);
            xs.alias("empleado", Empleado.class);
            xs.alias("departamento", Departamento.class);
            xs.addImplicitCollection(ListaEmpleados.class, "lista");

            xs.toXML(lista, new FileOutputStream("empleadosDepto.xml"));


        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (ois != null) try {
                ois.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

    }

}


















