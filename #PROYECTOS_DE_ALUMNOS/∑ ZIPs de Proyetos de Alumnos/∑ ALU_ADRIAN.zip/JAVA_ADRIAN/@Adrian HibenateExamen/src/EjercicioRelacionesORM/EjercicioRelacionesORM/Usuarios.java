package EjercicioRelacionesORM.EjercicioRelacionesORM;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;
/**
 * Clase que gestiona los usuarios
 * @author adrianantolinosmorato
 * @version 1
 *
 */
@Entity
@Table(name = "Usuarios") 
public class Usuarios implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "dni") 
	private String dni;
	@Column(name = "nombre")
	private String nombre;
	@Column(name = "apellidos")
	private String apellidos;
	@Column(name = "correo")
	private String correo;
	@Column(name = "telefono")
	private int telefono;

	@ManyToMany(cascade = { CascadeType.ALL })
	@JoinTable(name = "localizaciones_usuarios", joinColumns = { @JoinColumn(name = "dni") }, inverseJoinColumns = {
			@JoinColumn(name = "id_localizacion") })
	private Set<Localizaciones> localizaciones = new HashSet<Localizaciones>();

	/**
	 * Metodo que devuelve las localizaciones
	 * @return  el conjunto de las localizaciones
	 */
	public Set<Localizaciones> getLocalizaciones() {
		return this.localizaciones;
	}

	/**
	 * Constructor vacio
	 */
	public Usuarios() {

	}
	/**
	 * Constructor con todos los atributos
	 * @param dni dni del usuario
	 * @param nombre   nombre del usuario
	 * @param apellidos apellidos del usuario
	 * @param correo correo del usuario
	 * @param telefono telefono del usuario
	 */
	public Usuarios(String dni, String nombre, String apellidos, String correo, int telefono) {
		this.dni = dni;
		this.nombre = nombre;
		this.apellidos = apellidos;
		this.correo = correo;
		this.telefono = telefono;
	}


	@Override
	/**
	 * Metodo que devuelve todos los atributos de la clase
	 * 	@return  string con la descripcion de un usario
	 */
	public String toString() {
		return "Usuarios [dni=" + dni + ", nombre=" + nombre + ", apellidos=" + apellidos + ", correo=" + correo
				+ ", telefono=" + telefono + ", localizaciones=" + localizaciones + "]";
	}

	/**
	 * Metodo que devuelve el dni del usuario
	 * @return dni del usuario
	 */
	public String getDni() {
		return dni;
	}

	/**
	 * Metodo que devuelve del nombre del usuario
	 * @return nombre del usuario
	 */
	public String getNombre() {
		return nombre;
	}

	/**
	 * Metodo que devuelve el apellido del usuario
	 * @return apellidos del usuario
	 */
	public String getApellidos() {
		return apellidos;
	}

	/**
	 * Metodo que devuelve el correo del usuario
	 * @return correo del usuario
	 */
	public String getCorreo() {
		return correo;
	}

	/**
	 * Metodo que devuelve el correo del usuario
	 * @return telefono del usuario
	 */
	public int getTelefono() {
		return telefono;
	}

}
