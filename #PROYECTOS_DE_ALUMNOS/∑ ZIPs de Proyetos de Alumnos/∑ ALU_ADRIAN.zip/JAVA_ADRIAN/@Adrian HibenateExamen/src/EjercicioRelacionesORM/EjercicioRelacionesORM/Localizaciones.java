package EjercicioRelacionesORM.EjercicioRelacionesORM;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

@Entity
@Table(name = "Localizaciones")
/**
 * clase que contiene las localizaciones de un usuario
 * @author adrianantolinosmorato
 * @version 1 
 */
public class Localizaciones implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "id_localizacion")
	private int id_localizacion;

	@Column(name = "longitud")
	private double longitud;

	@Column(name = "latitud")
	private double latitud;

	@ManyToMany(cascade = { CascadeType.ALL }, mappedBy = "localizaciones")
	private Set<Usuarios> usuarios = new HashSet<Usuarios>();

	/**
	 * metodo que devuelve los usuarios
	 * @return conjumto de usuarios
	 */
	public Set<Usuarios> getUsuarios() {
		return this.usuarios;
	}

	/**
	 * Contructor con todos los parametros
	 * @param id_localizacion   localiacion
	 * @param longitud  longitud de la localizacion
	 * @param latitud    latitud de la localizacion
	 */
	public Localizaciones(int id_localizacion, double longitud, double latitud) {
		this.id_localizacion = id_localizacion;
		this.longitud = longitud;
		this.latitud = latitud;
	}

	/**
	 * Constructor vacio
	 */
	public Localizaciones() {
	}

	/**
	 * Metodo que devuelve el id_localizacion de la localizacion
	 * @return id_localizacion de la localizacion
	 */
	public int getId_localizacion() {
		return id_localizacion;
	}

	/**
	 * Metodo que devuelve la longitud de la localizacion
	 * @return longitud de la localizacion
	 */
	public double getLongitud() {
		return longitud;
	}

	/**
	 * Metodo que devuelve la latitud de la localizacion
	 * @return latitud de la localizacion
	 */
	public double getLatitud() {
		return latitud;
	}

}
