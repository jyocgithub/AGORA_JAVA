package EjercicioRelacionesORM.EjercicioRelacionesORM;

import java.io.IOException;
import java.io.Serializable;
import java.util.Scanner;

import javax.persistence.PersistenceException;

import java.util.*;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;
import org.hibernate.exception.JDBCConnectionException;
import org.hibernate.service.ServiceRegistry;
/**
 * Clase qie ejecuta el ejercicio EjercicioRelacionesORM
 * @author Adrian
 * @version 1
 */
public class Main implements Serializable {

	private static SessionFactory SesionFactory;

	/**
	 * Crea una SessionFactory para conectar con la BBDD
	 * @return un objeto SessionFactory
	 */
	public static SessionFactory getSessionFactory() {
		Configuration configuracion = new Configuration();
		configuracion.configure();
		ServiceRegistry ServicioRegistro = new StandardServiceRegistryBuilder()
				.applySettings(configuracion.getProperties()).build();
		SesionFactory = configuracion.buildSessionFactory(ServicioRegistro);
		return SesionFactory;
	}

	/**
	 * Metodo de inicio del programa
	 * @param args  argumentos de main
	 */
	public static void main(String[] args) {

		Session s = null;

		try {

			Scanner sc = new Scanner(System.in);
			System.out.printf("Introduce id de localización (integer): ");
			String idlocalizacionstring = sc.nextLine();
			int idlocalizacion = Integer.parseInt(idlocalizacionstring);
			System.out.printf("Introduce una longitud (double): ");
			String longitudstring = sc.nextLine();
			Double longitud = Double.parseDouble(longitudstring);
			System.out.printf("Introduce una latitud (double): ");
			String latitudstring = sc.nextLine();
			Double latitud = Double.parseDouble(latitudstring);

			Localizaciones local1 = new Localizaciones(idlocalizacion, longitud, latitud);

			System.out.printf("Introduce un DNI: (String)");
			String dni = sc.nextLine();
			System.out.printf("Introduce un nombre: ");
			String nombre = sc.nextLine();
			System.out.printf("Introduce un apellido: ");
			String apellido = sc.nextLine();
			System.out.printf("Introduce un correo electronico: ");
			String correo = sc.nextLine();
			System.out.printf("Introduce un telefono: ");
			String telefonostring = sc.nextLine();
			int telefono = Integer.parseInt(telefonostring);

			Usuarios us1 = new Usuarios(dni, nombre, apellido, correo, telefono);

			us1.getLocalizaciones().add(local1);

			s = getSessionFactory().openSession();
			s.beginTransaction();

			s.save(us1);

			s.getTransaction().commit();
			s.close();

			s = getSessionFactory().openSession();
			s.beginTransaction();

			Usuarios datosUsuarios = (Usuarios) s.get(Usuarios.class, dni);

			System.out.println("============== DATOS USUARIO ================= ");
			System.out.println("Nombre : " + datosUsuarios.getNombre());
			System.out.println("Apellidos : " + datosUsuarios.getApellidos());
			System.out.println("DNI : " + datosUsuarios.getDni());

			Set<Localizaciones> localizaciones = datosUsuarios.getLocalizaciones();
			for (Localizaciones loc : localizaciones) {
				System.out.println("Localizacion id: " + loc.getId_localizacion() + " Localizacionlatitud: "
						+ loc.getLatitud() + " Localizacionlongitud: " + loc.getLongitud());
			}

			s.getTransaction().commit();
			s.close();

		} catch (NumberFormatException ee) {
			System.out.println("Se le pide que introduzca numeros");

		} catch (JDBCConnectionException ee) {
			System.out.println("Error de conexion a la bbdd");

		}catch (PersistenceException ee) {
			System.out.println("Error de acceso a la bbdd");

		}
		finally {
			if (s != null) {

				if (s.isOpen()) {
					s.close();
				}
				if (!SesionFactory.isClosed()) {
					System.out.println("Fin del programa.");
					SesionFactory.close();
				}
			}
		}
	}
	
}