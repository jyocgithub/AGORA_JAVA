import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JRadioButton;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

public class Principal extends JFrame {

	private Principal frmFormulario;
	private JTextField textFieldw;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_4;
	private JTextField textField_5;
	private JPasswordField passwordField;
	private final ButtonGroup buttonGroup = new ButtonGroup();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			@Override
			public void run() {
				try {
					Principal window = new Principal();
					window.frmFormulario.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	// GETTERS AND SETTERS

	public JTextField getTextFieldw() {
		return textFieldw;
	}

	public void setTextFieldw(JTextField textFieldw) {
		this.textFieldw = textFieldw;
	}
	//
	// public JFrame getFrmFormulario() {
	// return frmFormulario;
	// }
	//
	// public void setFrmFormulario(JFrame frmFormulario) {
	// this.frmFormulario = frmFormulario;
	// }
	//
	// public JTextField getTextField() {
	// return textFieldw;
	// }
	//
	// public void setTextField(JTextField textField) {
	// this.textFieldw = textField;
	// }
	//
	// public JTextField getTextField_1() {
	// return textField_1;
	// }
	//
	// public void setTextField_1(JTextField textField_1) {
	// this.textField_1 = textField_1;
	// }
	//
	// public JTextField getTextField_2() {
	// return textField_2;
	// }
	//
	// public void setTextField_2(JTextField textField_2) {
	// this.textField_2 = textField_2;
	// }
	//
	// public JTextField getTextField_3() {
	// return textField_3;
	// }
	//
	// public void setTextField_3(JTextField textField_3) {
	// this.textField_3 = textField_3;
	// }
	//
	// public JTextField getTextField_4() {
	// return textField_4;
	// }
	//
	// public void setTextField_4(JTextField textField_4) {
	// this.textField_4 = textField_4;
	// }
	//
	// public JTextField getTextField_5() {
	// return textField_5;
	// }
	//
	// public void setTextField_5(JTextField textField_5) {
	// this.textField_5 = textField_5;
	// }
	//
	// public JPasswordField getPasswordField() {
	// return passwordField;
	// }
	//
	// public void setPasswordField(JPasswordField passwordField) {
	// this.passwordField = passwordField;
	// }

	/**
	 * Create the application.
	 */
	public Principal() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmFormulario = this;
		// frmFormulario = new Principal();
		frmFormulario.setTitle("Formulario de registro");
		frmFormulario.setBounds(100, 100, 585, 300);
		frmFormulario.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmFormulario.getContentPane().setLayout(null);

		JLabel lblNombre = new JLabel("Nombre:");
		lblNombre.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNombre.setBounds(21, 22, 61, 16);
		frmFormulario.getContentPane().add(lblNombre);

		JLabel lblApellidos = new JLabel("Apellido:");
		lblApellidos.setHorizontalAlignment(SwingConstants.RIGHT);
		lblApellidos.setBounds(21, 50, 61, 16);
		frmFormulario.getContentPane().add(lblApellidos);

		JLabel lblTelfono = new JLabel("Teléfono:");
		lblTelfono.setHorizontalAlignment(SwingConstants.RIGHT);
		lblTelfono.setBounds(21, 78, 61, 16);
		frmFormulario.getContentPane().add(lblTelfono);

		JLabel lblCorreoElectrnico = new JLabel("Correo electrónico:");
		lblCorreoElectrnico.setHorizontalAlignment(SwingConstants.RIGHT);
		lblCorreoElectrnico.setBounds(-23, 107, 150, 16);
		frmFormulario.getContentPane().add(lblCorreoElectrnico);

		JLabel lblDireccin = new JLabel("Dirección:");
		lblDireccin.setHorizontalAlignment(SwingConstants.RIGHT);
		lblDireccin.setBounds(-68, 134, 150, 16);
		frmFormulario.getContentPane().add(lblDireccin);

		JLabel lblNewLabel = new JLabel("Nombre de usuario:");
		lblNewLabel.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel.setBounds(227, 22, 150, 16);
		frmFormulario.getContentPane().add(lblNewLabel);

		JLabel lblNewLabel_1 = new JLabel("Contraseña:");
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_1.setBounds(227, 50, 100, 16);
		frmFormulario.getContentPane().add(lblNewLabel_1);

		textFieldw = new JTextField();
		textFieldw.setBounds(87, 17, 130, 26);
		frmFormulario.getContentPane().add(textFieldw);
		textFieldw.setColumns(10);

		textField_1 = new JTextField();
		textField_1.setBounds(87, 45, 130, 26);
		frmFormulario.getContentPane().add(textField_1);
		textField_1.setColumns(10);

		textField_2 = new JTextField();
		textField_2.setBounds(87, 73, 130, 26);
		frmFormulario.getContentPane().add(textField_2);
		textField_2.setColumns(10);

		textField_3 = new JTextField();
		textField_3.setBounds(137, 102, 130, 26);
		frmFormulario.getContentPane().add(textField_3);
		textField_3.setColumns(10);

		textField_4 = new JTextField();
		textField_4.setBounds(87, 129, 130, 26);
		frmFormulario.getContentPane().add(textField_4);
		textField_4.setColumns(10);

		textField_5 = new JTextField();
		textField_5.setBounds(387, 17, 130, 26);
		frmFormulario.getContentPane().add(textField_5);
		textField_5.setColumns(10);

		passwordField = new JPasswordField();
		passwordField.setBounds(337, 45, 130, 26);
		frmFormulario.getContentPane().add(passwordField);

		JCheckBox chckbxAceptoLosTrminos = new JCheckBox("Acepto los términos y condiciones");
		chckbxAceptoLosTrminos.setBounds(21, 214, 260, 23);
		frmFormulario.getContentPane().add(chckbxAceptoLosTrminos);

		JButton btnSiguiente = new JButton("Siguiente");

		btnSiguiente.setBounds(397, 213, 117, 29);
		frmFormulario.getContentPane().add(btnSiguiente);

		JRadioButton rdbtnEstudiante = new JRadioButton("Estudiante");
		buttonGroup.add(rdbtnEstudiante);
		rdbtnEstudiante.setHorizontalAlignment(SwingConstants.LEFT);
		rdbtnEstudiante.setBounds(307, 114, 141, 23);
		frmFormulario.getContentPane().add(rdbtnEstudiante);

		JRadioButton rdbtnNewTrabajador = new JRadioButton("Trabajador");
		rdbtnNewTrabajador.setHorizontalAlignment(SwingConstants.RIGHT);
		buttonGroup.add(rdbtnNewTrabajador);
		rdbtnNewTrabajador.setBounds(414, 114, 141, 23);
		frmFormulario.getContentPane().add(rdbtnNewTrabajador);

		JRadioButton rdbtnAmbas = new JRadioButton("Ambos");
		buttonGroup.add(rdbtnAmbas);
		rdbtnAmbas.setBounds(307, 145, 141, 23);
		frmFormulario.getContentPane().add(rdbtnAmbas);

		JLabel lblActualmenteEres = new JLabel("Actualmente eres:");
		lblActualmenteEres.setHorizontalAlignment(SwingConstants.RIGHT);
		lblActualmenteEres.setBounds(255, 91, 143, 16);
		frmFormulario.getContentPane().add(lblActualmenteEres);

		// EVENTOS

		btnSiguiente.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {

				if (textFieldw.getText().length() == 0 || textField_1.getText().length() == 0
						|| textField_2.getText().length() == 0 || textField_3.getText().length() == 0
						|| textField_4.getText().length() == 0 || textField_5.getText().length() == 0
						|| passwordField.getText().length() == 0) {

					JOptionPane.showMessageDialog(null, "Debe rellenar todos los campos.", "Error",
							JOptionPane.ERROR_MESSAGE);

				} else if (!rdbtnEstudiante.isSelected() && !rdbtnNewTrabajador.isSelected()
						&& !rdbtnAmbas.isSelected()) {

					JOptionPane.showMessageDialog(null, "Debe selecionar lo que actualmente está haciendo.", "Error",
							JOptionPane.ERROR_MESSAGE);

				}

				else if (!chckbxAceptoLosTrminos.isSelected()) {
					JOptionPane.showMessageDialog(null, "Debe seleccionar los términos y condiciones", "Error",
							JOptionPane.ERROR_MESSAGE);
				}

				else {
					Secundaria nuevaVentana = new Secundaria(frmFormulario);
					nuevaVentana.getJFrame2().setVisible(true);
					frmFormulario.setVisible(false);
				}

			}

		});
	}

}
