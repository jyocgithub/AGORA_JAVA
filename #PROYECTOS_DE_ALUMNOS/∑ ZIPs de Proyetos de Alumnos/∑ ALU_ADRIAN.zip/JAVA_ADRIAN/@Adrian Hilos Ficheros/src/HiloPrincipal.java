import java.io.*;

import java.util.zip.*;

public class HiloPrincipal extends Thread {

	ZipOutputStream output;

	@Override
	public void run() {

		File f = new File("C:\\Users\\AlumnoM\\Acceso a Datos\\adrian-workspace");

		if (f.exists()) {
			if (f.isDirectory()) {

				// CALCULAR TAMAO
				long tamfinal = tamanodir(f);
				System.out.println(tamfinal);

				// CALCULAR NUM FICHEROS
				long numfinal = numeroFichs(f);
				System.out.println(numfinal);

				// COMPRIMIR
				try {
					output = new ZipOutputStream(new FileOutputStream("comprimido.zip"));
					hacerZip(f);
					output.finish();
					output.close();
				} catch (FileNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

			}
		}

	}

	public long tamanodir(File f) {
		long suma = 0;

		if (f.isFile()) {
			suma = f.length();
			System.out.println(f.getName());
		} else {
			File[] lista = f.listFiles();
			for (int i = 0; i < lista.length; i++) {
				File cadacosa = lista[i];
				suma = suma + tamanodir(cadacosa);
			}
		}
		return suma;

	}

	public long numeroFichs(File f) {
		long suma = 0;

		if (f.isFile()) {
			return 1;
		} else {
			File[] lista = f.listFiles();
			for (int i = 0; i < lista.length; i++) {
				File cadacosa = lista[i];
				suma = suma + numeroFichs(cadacosa);
			}
		}
		return suma;

	}

	public long hacerZip(File f) {
		long suma = 0;

		if (f.isFile()) {

			// a�adirlo al zip
			try {
				byte[] buf = new byte[1024];
				ZipEntry zentry = new ZipEntry(f.getPath());

				output.putNextEntry(zentry);
				FileInputStream fis = new FileInputStream(f);
				int len;
				while ((len = fis.read(buf)) > 0) {
					output.write(buf, 0, len);
				}
				fis.close();
				output.closeEntry();
			} catch (IOException e) {
				e.printStackTrace();
			}

		} else {
			File[] lista = f.listFiles();
			for (int i = 0; i < lista.length; i++) {
				File cadacosa = lista[i];
				hacerZip(cadacosa);
			}
		}
		return suma;

	}

}