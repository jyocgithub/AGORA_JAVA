import java.io.*;
import java.util.Calendar;

public class Principal {

    public static void main(String[] args) {

        Hilo1 primero = new Hilo1();
        Hilo2 segundo = new Hilo2();
        Hilo3 tercero = new Hilo3();
        primero.start();
        try {
            primero.join();

            segundo.start();
            segundo.join();

        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        while (true) {
            // lanzar el hilo solo si es LMXJV y son las 14:00
            if (tocaCopiaAhora()) {
                tercero.start();
            }
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }


    public static boolean tocaCopiaAhora() {
        int horadelacopia = 15;
        int minutodelacopia = 17;

        boolean toca = false;
        Calendar c = Calendar.getInstance();
        if (c.get(Calendar.DAY_OF_WEEK) > 1 && c.get(Calendar.DAY_OF_WEEK) < 7)
            if (c.get(Calendar.HOUR_OF_DAY) == horadelacopia && c.get(Calendar.MINUTE) == minutodelacopia && c.get(Calendar.SECOND) == 0) {
                return true;
            }
        return toca;
    }

}
