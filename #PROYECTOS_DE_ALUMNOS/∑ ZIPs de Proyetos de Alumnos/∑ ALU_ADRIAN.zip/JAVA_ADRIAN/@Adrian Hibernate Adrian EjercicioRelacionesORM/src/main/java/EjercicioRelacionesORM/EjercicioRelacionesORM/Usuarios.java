package EjercicioRelacionesORM.EjercicioRelacionesORM;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

@Entity
@Table(name = "Usuarios") // nombre de la tabla
public class Usuarios implements Serializable {
	/**
	* 
	*/
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "dni") // nombre del campo
	private String dni;// nombre del campo

	@Column(name = "nombre")
	private String nombre;
	@Column(name = "apellidos")
	private String apellidos;
	@Column(name = "correo")
	private String correo;
	@Column(name = "telefono")
	private int telefono;

	@ManyToMany(cascade = { CascadeType.ALL })
	@JoinTable(name = "localizaciones_usuarios", joinColumns = { @JoinColumn(name = "dni") }, inverseJoinColumns = {
			@JoinColumn(name = "id_localizacion") })
	private Set<Localizaciones> localizaciones = new HashSet<Localizaciones>();

	public Set<Localizaciones> getLocalizaciones() {
		return this.localizaciones;
	}

	public Usuarios() {

	}

	public Usuarios(String dni, String nombre, String apellidos, String correo, int telefono) {
		this.dni = dni;
		this.nombre = nombre;
		this.apellidos = apellidos;
		this.correo = correo;
		this.telefono = telefono;
	}

	@Override
	public String toString() {
		return "Usuarios [dni=" + dni + ", nombre=" + nombre + ", apellidos=" + apellidos + ", correo=" + correo
				+ ", telefono=" + telefono + ", localizaciones=" + localizaciones + "]";
	}

	public String getDni() {
		return dni;
	}

	public String getNombre() {
		return nombre;
	}

	public String getApellidos() {
		return apellidos;
	}

	public String getCorreo() {
		return correo;
	}

	public int getTelefono() {
		return telefono;
	}

}
