package EjercicioRelacionesORM.EjercicioRelacionesORM;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

@Entity
@Table(name = "Localizaciones")
public class Localizaciones implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "id_localizacion")
	private int id_localizacion;

	@Column(name = "longitud")
	private double longitud;

	@Column(name = "latitud")
	private double latitud;

	@ManyToMany(cascade = { CascadeType.ALL }, mappedBy = "localizaciones")
	private Set<Usuarios> usuarios = new HashSet<Usuarios>();

	public Set<Usuarios> getUsuarios() {
		return this.usuarios;
	}

	public Localizaciones(int id_localizacion, double longitud, double latitud) {
		this.id_localizacion = id_localizacion;
		this.longitud = longitud;
		this.latitud = latitud;
	}

	public Localizaciones() {
	}

	public int getId_localizacion() {
		return id_localizacion;
	}

	public double getLongitud() {
		return longitud;
	}

	public double getLatitud() {
		return latitud;
	}

}
