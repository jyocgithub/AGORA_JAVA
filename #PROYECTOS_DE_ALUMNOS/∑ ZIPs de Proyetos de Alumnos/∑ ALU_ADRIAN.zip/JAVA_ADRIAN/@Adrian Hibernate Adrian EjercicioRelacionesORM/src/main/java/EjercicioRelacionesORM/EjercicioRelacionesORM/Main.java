package EjercicioRelacionesORM.EjercicioRelacionesORM;

/**
 * Ejemplo de Main para una relacion una a muchas, desordenada.
 * 
 * En este caso, un profesor puede tener muchos correos electr�nicos,
 * Y cada correo electr�nico pertenece a un y solo un profesor.
 * 
 * Se utilizan las tablas Profesor y CorreoElectronico de la BBDD para implementar esta relaci�n
 * 
 * La clase profesor contiene referencia al conjunto de correos que dispone.
 * 
 * Observa que se utiliza una estructura tipo set, lo que indica que la relaci�n
 * no est� ordenada.
 * 
 * 
 * Nota: Implementa el mismo ejemplo utilizando una estructura ordenada para almacenar
 *       los correos electr�nicos.
 * 
 * 
 */

import java.io.Serializable;
import java.util.Set;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;

public class Main implements Serializable {

	private static SessionFactory sessionFactory;

	public static SessionFactory getSessionFactory() {
		Configuration configuration = new Configuration();
		configuration.configure();
		ServiceRegistry serviceRegistry = new StandardServiceRegistryBuilder()
				.applySettings(configuration.getProperties()).build();
		sessionFactory = configuration.buildSessionFactory(serviceRegistry);
		return sessionFactory;
	}

	public static void main(String[] args) {

		Session session = null;
		try {

			Localizaciones local1 = new Localizaciones(11, 111, 112);
			Localizaciones local2 = new Localizaciones(22, 221, 222);
			Localizaciones local3 = new Localizaciones(33, 331, 332);

			Usuarios us1 = new Usuarios("d11", "Paco", "Perez", "pacop@gmail.com", 98767554);
			Usuarios us2 = new Usuarios("d22", "Eva", "Perez", "pacop@gmail.com", 98767554);
			Usuarios us3 = new Usuarios("d33", "Ana", "Perez", "pacop@gmail.com", 98767554);

//			local1.getUsuarios().add(us1);
//			local1.getUsuarios().add(us2);
//			local2.getUsuarios().add(us1);
//			local3.getUsuarios().add(us2);

			us1.getLocalizaciones().add(local1);
			us1.getLocalizaciones().add(local2);
			us2.getLocalizaciones().add(local1);
			us2.getLocalizaciones().add(local3);

//			session = getSessionFactory().openSession();
//			session.beginTransaction();
//
//			session.save(us1);
//			session.save(us2);
//
//			session.getTransaction().commit();
//			session.close();

			session = getSessionFactory().openSession();
			session.beginTransaction();

			Usuarios usuarioRecuperado = (Usuarios) session.get(Usuarios.class, "d11");

			System.out.println("============== USUARIO RECUPERADO ================= ");
			System.out.println("nombre : " + usuarioRecuperado.getNombre());
			System.out.println("apellidos : " + usuarioRecuperado.getApellidos());
			System.out.println("dni : " + usuarioRecuperado.getDni());

			Set<Localizaciones> localizaciones = usuarioRecuperado.getLocalizaciones();
			for (Localizaciones loc : localizaciones) {
				System.out.println("   localizacion : " + loc.getId_localizacion() + " " + loc.getLatitud() + " "
						+ loc.getLongitud());
			}
			session.getTransaction().commit();
			session.close();

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (session.isOpen()) {
				System.out.println("Cerrando session");
				session.close();
			}
			if (!sessionFactory.isClosed()) {
				System.out.println("Cerrando SessionFactory");
				sessionFactory.close();
			}
		}
	}

}