package navegadorweb;

import java.awt.TextArea;
import java.io.*;
//
import java.net.URL;
import java.net.URLConnection;
import java.net.MalformedURLException;
//
import java.util.Date;
import javax.swing.JFileChooser;
import javax.swing.JTextArea;

/**
 * ****************************************************************************
 * hilo para obtener el contenido de una URL tecleada por el usuario, según el
 * 'Content-Type' enviado por el Servidor:
 * <p>
 * -si es 'application/pdf', pide la ruta del disco donde se desea guardar el
 * fichero pdf
 * <p>
 * -si es 'text/html...', muestra el cuerpo de la página en la Salida
 * <p>
 * -en cualquier otro caso, advierte de que no sabe qué hacer con el contenido
 *
 * @author IMCG
 */
class HiloBoton extends Thread {
     //variables locales

     private String cadenaURL;
     private JTextArea textAreaResultado;

     /**
      * **************************************************************************
      * constructor
      *
      * @param cadenaURL
      */
     public HiloBoton(String cadenaURL, JTextArea textAreaResultado) {
          //
          this.cadenaURL = cadenaURL;
          this.textAreaResultado = textAreaResultado;
     }

     //código asociado al hilo
     @Override
     public void run() {

          // para pruebas
          cadenaURL = "https://drive.google.com/uc?export=download&id=1PJIDN7gNrF2wpxtiQPGw3feXvwkQOLzt";  //va bien pues es un txt
//          cadenaURL = "https://www.learningcontainer.com/wp-content/uploads/2020/04/sample-text-file.txt";  // da error 403
//          cadenaURL =  "https://filesamples.com/samples/document/txt/sample3.txt";  // da error 403

          //variables locales
          int leido, contentLength;
          char[] bufChar;
          byte[] bufByte;
          //
          try {
               URL url = new URL(cadenaURL);//crea objeto url
               URLConnection conexion = url.openConnection();//obtiene una conexºión al recurso URL
               conexion.connect();//se conecta pudiendo interactuar con parámetros
               String contentType = conexion.getContentType();//obtiene el tipo de contenido

               if (cadenaURL.endsWith(".pdf")) {
                    contentType = "application/pdf";
               }
               if (cadenaURL.startsWith("https://drive.google.")) {   // para pruebas de descargas con permiso seguro
                    contentType = "text/plain";
               }


               System.out.println("Encabezados destacados:\n* Content-Type: " + contentType);
               contentLength = conexion.getContentLength(); //obtiene el tamaño del contenido
               System.out.println("* Content-Length: " + contentLength);
               Date fecha = new Date(conexion.getLastModified());//obtiene la fecha de la  última modificación
               System.out.println("* Fecha de la última modificación: " + fecha);
               if (contentType.equals("application/pdf")) {//según el tipo de contenido...
                    // ...si se trata de un fichero pdf **************************************
                    File archivoElegido = ficheroDestino();//muestra un cuadro de diálogo modal para generar el fichero de destino
                    if (archivoElegido != null) {        //si fichero generado correctamente
                         InputStream reader = url.openStream();          //flujo de descarga desde la url
                         FileOutputStream writer = new FileOutputStream(archivoElegido.getPath()); //flujo de escritura en el fichero
                         bufByte = new byte[contentLength]; //buffer intermedio ajustado al Content-Length enviado por el Servidor
                         System.out.println("\nDescargando pdf en el directorio elegido...");
                         while ((leido = reader.read(bufByte)) > 0) { //mientras quedan bytes por leer en el buffer intermedio
                              writer.write(bufByte, 0, leido);
                         }
                         System.out.println("El pdf ha sido descargado correctamente");
                         writer.close(); //cierra el flujo de escritura
                    }
               } else if (contentType.startsWith("text/html") || contentType.startsWith("text/plain")) {
                    //si se trata de texto o contenido html *******************************
                    InputStream reader = url.openStream();          //flujo de descarga desde la url
                    InputStream imputString = conexion.getInputStream();//flujo para descargar el cuerpo del texto o página html
                    BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(imputString));//buffer intermedio de tamaño medio
                    bufChar = new char[512];

                    String respuesta = "";
                    while ((leido = bufferedReader.read(bufChar)) > 0) {//mientras quedan caracteres por leer
                         respuesta += new String(bufChar, 0, leido);
                         System.out.println("Cuerpo: " + new String(bufChar, 0, leido));//los escribe en la Salida
                    }
                    //

                    textAreaResultado.setText(respuesta);

                    System.out.println("Cuerpo de texto obtenido correctamente");

               } else {

                    //en cualquier otro caso **********************************************
                    textAreaResultado.setText("Archivo de tipo no conocido (solo se procesar html, txt y pdf)");
               }
          } catch (MalformedURLException e) {
               System.err.println("URL sin sentido");
          } catch (IOException e) {
               System.err.println("Error de lectura/escritura");
               e.printStackTrace();
          } finally {
               
               // System.exit(0);
          }
     }

     /**
      * **************************************************************************
      * muestra un cuadro de diálogo para crear un fichero pdf en la ruta indicada
      * por el usuario
      *
      * @return
      */
     private File ficheroDestino() {
          //cuadro de diálogo 'guardar como' de Java...
          JFileChooser fc = new JFileChooser();
          //...posicionado en el archivo de nombre tomado de la url
          fc.setSelectedFile(new File(cadenaURL.substring(cadenaURL.lastIndexOf("/"))
                  + (cadenaURL.endsWith(".pdf") ? "" : ".pdf")));
          //muestra el cuadro de diálogo en pantalla
          int showSaveDialog = fc.showSaveDialog(null);
          //si se pulsa 'Aceptar'
          if (showSaveDialog == JFileChooser.APPROVE_OPTION) {
               //devuelve el archivo indicado por el usuario
               return fc.getSelectedFile();
          }
          //devuelve nulo
          return null;
     }
}
