/*
 * 
 */

public class ReproductorMusica {
	// Array de canciones. Simula la lista de reproducción
	private Cancion[] listaReproduccion;
	// Nº de canciones en la lista
	private int noCanciones;
	// Indice en el array correspondiente a la canción que suena o va a sonar
	private int punteroReproduccion;
	private int capacidad;

	/*
	 * Un reproductor de canciones con una capacidad predeterminada al inicio
	 */
	public ReproductorMusica(int capacidad) {
		// Sugerencia:
		// Guardar la capacidad en un atributo de la clase
		// Esto nos evita arrastrar el listaReproduccion.length
		// TODO:
		this.listaReproduccion = new Cancion[capacidad];
		this.noCanciones = 0;
		this.punteroReproduccion = -1;
		this.capacidad = capacidad;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString() No modificar!!! OJO: NO hay que hacer nada (bueno sí, leer)
	 */
	@Override
	public String toString() {
		if (this.noCanciones == 0)
			return "vacía"; // si no hay canciones también hay que decir algo
		else {
			String salida = "";
			int i;
			for (i = 0; i < this.noCanciones - 1; i++)
				salida += this.listaReproduccion[i] + ",";

			return salida + this.listaReproduccion[i] + " puntero apunta a " + listaReproduccion[punteroReproduccion];
		}
	}

	/**
	 * Buscar canción con el título y la duración dadas Si hay una canción , devuelve su posición e.o.c. devuelve -1
	 *
	 */
	private int buscarCancion(String titulo, double duracion) {
		// TODO:
		int resultado = -1;
		Cancion ccc = new Cancion(titulo, duracion);
		for (int i = 0; i < listaReproduccion.length && resultado == -1; i++) {
			if (listaReproduccion[i] != null) {
				if ((listaReproduccion[i].esIgual(ccc))) {
					resultado = i;
				}
			}
		}
		return resultado;
	}

	/**
	 * Borrar canción: si está en la biblioteca, borra la primera ocurrencia de la canción e.o.c. no hace nada Esta función no
	 * devuelve nada (es muda) OJO: NUNCA deben quedar HUECOS en el array!!!
	 */
	public void borrarCancion(String titulo, double duracion) {
		// TODO:
		int pos = buscarCancion(titulo, duracion); // guarda el valor del metodo anterior (la posicion de dicha cancion)
		for (int a = pos; a < noCanciones - 2; a++) {
			listaReproduccion[a] = listaReproduccion[a + 1];
		}
		listaReproduccion[noCanciones] = null;
		noCanciones--;
	}

	/**
	 * PRE: OJO!!! Hay suficiente espacio libre para las nuevas canciones Inserta las canciones en la biblioteca (al final) Deja el
	 * puntero apuntando a la primera canción insertada Utiliza las canciones del vector dado como argumento
	 */
	public void insertarCanciones(Cancion[] canciones) {
		// TODO:
		if (canciones != null) {
			punteroReproduccion = noCanciones;
			for (int i = 0; i < canciones.length; i++) {
				listaReproduccion[noCanciones] = canciones[i];
				noCanciones++;
			}
		}
	}

	/**
	 * /** Si la canción existe, pone el puntero en la primera ocurrencia de la canción con el título dado. OJO, NO reproduce,
	 * selecciona!!! e.o.c. deja el puntero igual
	 */
	public void seleccionarCancion(String titulo, double duracion) {
		int newpos = buscarCancion(titulo, duracion);
		if (newpos != -1) {
			punteroReproduccion = newpos;
		}
	}

	/**
	 * PRE: la lista no está vacía reproduce la canción a la que apunta el puntero OJO: NO hay que hacer nada (bueno sí, leer)
	 */
	public void reproducirCancionSeleccionada() {
		/*
		 * No hay que hacer nada más
		 */
		listaReproduccion[this.punteroReproduccion].reproducirCancion();
	}

	/**
	 * PRE: la lista no está vacía y el puntero no está en la última canción avanza el puntero a la siguiente canción de la lista
	 * OJO: NO hay que hacer nada (bueno sí, leer)
	 */
	public void avanzarPuntero() {
		this.punteroReproduccion++;
	}

	/**
	 * Indica si el puntero está en la última canción de la lista
	 */
	public boolean haySiguiente() {
		boolean resultado = true;
		if (punteroReproduccion == capacidad - 1) {
			resultado = false;
		} else if (listaReproduccion[punteroReproduccion + 1] == null) {
			resultado = false;
		}
		return resultado;
	}
}
