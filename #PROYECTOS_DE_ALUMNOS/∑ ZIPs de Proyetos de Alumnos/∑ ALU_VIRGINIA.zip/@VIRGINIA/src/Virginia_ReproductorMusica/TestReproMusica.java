public class TestReproMusica {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ReproductorMusica player = new ReproductorMusica(10);
		Cancion canciones[] = { new Cancion("A", 0.2), new Cancion("B", 0.4), new Cancion("C", 0.4) };

		player.insertarCanciones(canciones);
		// Vemos lo que hemos hecho
		System.out.println(player);

		// Reproducción de la lista completa canción a canción
		// No debería sonar, solo escribe en pantalla :-(
		System.out.println("=====");
		while (player.haySiguiente()) {
			player.reproducirCancionSeleccionada();
			player.avanzarPuntero();
		}

		// Reproducción de la canción donde esté el índice de reproducción
		// Deberá ser la última ya que anteriormente se reprodujeron todas
		player.reproducirCancionSeleccionada();

		// Reproducción canción seleccionándola explícitamente
		System.out.println("=====");
		player.seleccionarCancion("B", 0.4);
		player.reproducirCancionSeleccionada();

		// Comprobar estado del reproductor
		// Revisar conteo de reproducción; debería ser 1, 2, 1
		System.out.println("=====");
		System.out.println(player);

	}

}
