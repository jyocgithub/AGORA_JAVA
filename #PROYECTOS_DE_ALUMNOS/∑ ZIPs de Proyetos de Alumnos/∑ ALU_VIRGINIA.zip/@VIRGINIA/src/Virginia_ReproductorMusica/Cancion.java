/*
 * Clase Canción
 * Revisar el código obviando el método reproducirCancion()
 * No es necesario modificar nada
 */
public class Cancion {
	// título de la canción
	private String titulo;	
	// indica cúantas veces se ha reproducido la canción
	private int noReproducciones; 
	// duración de la canción en segundos
	private double duracion;
	
	/*
	 * Constructor base
	 */
	public Cancion(String titulo, double duracion) {		
		this.titulo = titulo;	
		this.noReproducciones = 0;
		this.duracion = duracion;
	}
	
	/*
	 * Constructor de copia. Obviamente, cancion es un objeto, se ha instanciado (new) previamente
	 * Como son objetos de la misma clase no hace falta getter para acceder a los atributos
	 */
	public Cancion(Cancion cancion){
		this.titulo = cancion.titulo;		
		this.noReproducciones = cancion.noReproducciones;
		this.duracion = cancion.duracion;
	}

	/*
	 * Reproductor de canciones
	 */
	public void reproducirCancion(){
		System.out.println("Reproduciendo... " + titulo);
		/*
		 * Temporizador en Java. Obviar!!!
		 */
		try {
			Thread.sleep((int) duracion*1000);
			this.noReproducciones++;
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/*
	 * Dos canciones serán iguales si tienen idéntico título y duración
	 * Ya sabemos que equals de Java hace otra cosa. O no?
	 */
	public boolean esIgual(Cancion cancion){
		// OJO: NO usamos equals (de strings...)
		return (this.titulo.compareToIgnoreCase(cancion.titulo) == 0) 
				&& this.duracion == cancion.duracion;
/*
		return titulo.equals(cancion.titulo) 
				&& this.duracion == cancion.duracion;
 */
	}
	
	/*
	 * getter noReproduciones
	 */
	public int getNoReproducciones() {
		return noReproducciones;
	}

	/*
	 * setter noReproduciones
	 * OJO!!!: palabra reservada void => es un método "tipo procedimiento". No devuelve nada
	 */
	void setNoReproducciones(int noReproducciones) {
		this.noReproducciones = noReproducciones;
	}

	public String toString(){
		return "(" + titulo + ", " + duracion + ", "+ noReproducciones + ")";
	}

	/*
	 * getter título
	 */
	public String getTitulo() {
		return titulo;
	}

	/*
	 * getter duración
	 */
	public double getDuracion() {
		return duracion;
	}	
	
}
