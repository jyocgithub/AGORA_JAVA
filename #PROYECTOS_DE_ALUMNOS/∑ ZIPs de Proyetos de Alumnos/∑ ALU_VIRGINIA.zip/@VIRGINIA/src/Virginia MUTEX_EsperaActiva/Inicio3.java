
public class Inicio3
{
	int numCambios = 5;
	int tothilosdecada = 3;
	Integer dato = 0;
	boolean estaocupado = false;

	public static void main(String[] args) throws InterruptedException
	{

		new Inicio3().mimain();

	}

	public void mimain()
	{

		for (int i = 0; i < 5; i++)
		{
			HiloDec h = new HiloDec(i);
			h.start();
			new HiloInc(i).start();
		}
	}

	class HiloDec extends Thread
	{
		int numhilo;

		public HiloDec(int numhi)
		{
			super();
			numhilo = numhi;
		}

		@Override
		public void run()
		{
			for (int i = 0; i <= numCambios; i++)
			{
				while (estaocupado)
				{
				}
				estaocupado = true;
				dato--;
				System.out.println("HiloDEC " + numhilo + " : valor de dato " + dato);
				// try
				// {
				// sleep(100);
				// } catch (InterruptedException e)
				// {
				// e.printStackTrace();
				// }
				i++;
				estaocupado = false;
			}
		}
	}

	class HiloInc extends Thread
	{
		int numhilo;

		public HiloInc(int numhi)
		{
			super();
			numhilo = numhi;
		}

		@Override
		public void run()
		{
			for (int i = 0; i <= numCambios; i++)
			{
				while (estaocupado)
				{
				}
				estaocupado = true;
				dato++;
				System.out.println("HiloINC " + numhilo + " : valor de dato " + dato);
				// try
				// {
				// sleep(100);
				// } catch (InterruptedException e)
				// {
				// e.printStackTrace();
				// }

				estaocupado = false;
			}
		}
	}
}
