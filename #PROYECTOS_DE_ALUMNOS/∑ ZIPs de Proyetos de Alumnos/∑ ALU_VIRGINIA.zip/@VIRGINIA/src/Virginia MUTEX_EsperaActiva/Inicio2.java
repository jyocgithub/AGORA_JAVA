
public class Inicio2
{
	public int numCambios = 10;
	int tothilosdecada = 5;
	Integer dato = 0;

	public static void main(String[] args) throws InterruptedException
	{

		new Inicio2().mimain();

	}

	public void mimain()
	{

		for (int i = 0; i < 5; i++)
		{
			HiloDec h = new HiloDec(i);
			h.start();
			new HiloInc(i).start();
		}
	}

	class HiloDec extends Thread
	{
		int numhilo;

		public HiloDec(int numhi)
		{
			super();
			numhilo = numhi;
		}

		@Override
		public void run()
		{
			for (int i = 0; i <= numCambios; i++)
			{
				dato--;
				System.out.println("HiloDEC " + numhilo + " : valor de dato " + dato);
				try
				{
					sleep(300);
				} catch (InterruptedException e)
				{
					e.printStackTrace();
				}

			}
		}
	}

	class HiloInc extends Thread
	{
		int numhilo;

		public HiloInc(int numhi)
		{
			super();
			numhilo = numhi;
		}

		@Override
		public void run()
		{
			for (int i = 0; i <= numCambios; i++)
			{
				dato++;
				System.out.println("HiloINC " + numhilo + " : valor de dato " + dato);
				try
				{
					sleep(200);
				} catch (InterruptedException e)
				{
					e.printStackTrace();
				}

			}
		}
	}
}
