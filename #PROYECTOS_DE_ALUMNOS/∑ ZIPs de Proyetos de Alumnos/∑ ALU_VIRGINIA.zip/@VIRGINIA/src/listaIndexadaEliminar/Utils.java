package listaIndexadaEliminar;

import es.upm.aedlib.indexedlist.*;
import java.util.ArrayList;

public class Utils {

//     public static <E> IndexedList<E> deleteRepeated(IndexedList<E> l) {
//
//          IndexedList<E> lista2 = new ArrayIndexedList<E>(); // la que se va a devoler
//          int i = 0;
//          for (int a = 0; a < lista2.size(); a++) {
//               while (i < l.size()) { // controla la lista que te pasan como parametro
//                    E aux = l.get(i);
//                    int pos = lista2.indexOf(null); // guarda la primera pos libre que hay en lista2
//                    if (lista2.indexOf(aux) == -1) { // en la lista no existe ya ese elemento
//                         lista2.set(a, aux);
//                         i++;
//                    }
//               }
//          }
//          return lista2;
//     }
//     

     public static <E> IndexedList<E> deleteRepeated(IndexedList<E> l) {

          ArrayList<Vestido> milis = new ArrayList<>();
          
          
    
          
          
          IndexedList<E> lista2 = new ArrayIndexedList<E>(); // la que se va a devoler
          int i = 0;
          E elementoAnterior = null;
          E elementoActual = null;
          boolean actualEstaRepetido = false;

          for (int a = 0; a < l.size(); a++) {
               elementoActual = l.get(i);
               if (elementoAnterior == null) {   // es null, es el primer elemento de la lista, tb vale a==0´
                    lista2.add(elementoActual);
               } else {
                    if (elementoAnterior.equals(elementoActual)) { // es igual el anterior que este, no añadimnos el anterior
//                         actualEstaRepetido = true;
                    } else {  // no son iguales, si no habia repetido, añadimos el numero
                         lista2.add(elementoActual);
//                         if (!actualEstaRepetido) {
//                         }
//                         actualEstaRepetido = false;
                    }
               }
               elementoAnterior = elementoActual;
          }

//          if (!actualEstaRepetido) { // hay que ver si metemos el ultimo elemento
//               lista2.add(elementoAnterior);
//          }
          return lista2;
     }


//     public static <E> IndexedList<E> deleteRepeatedSinDejarNinguno(IndexedList<E> l) {
//
//          IndexedList<E> lista2 = new ArrayIndexedList<E>(); // la que se va a devoler
//          int i = 0;
//          E elementoAnterior = null;
//          E elementoActual = null;
//          boolean actualEstaRepetido = false;
//
//          for (int a = 0; a < l.size(); a++) {
//               elementoActual = l.get(i);
//               if (elementoAnterior != null) {   // es null, es el primer elemento de la lista, tb vale a==0
//                    if (elementoAnterior.equals(elementoActual)) { // es igual el anterior que este, no añadimnos el anterior
//                         actualEstaRepetido = true;
//                    } else {  // no son iguales, si no habia repetido, añadimos el numero
//                         if (!actualEstaRepetido) {
//                              lista2.add(elementoAnterior);
//                         }
//                         actualEstaRepetido = false;
//                    }
//               }
//          }
//
//          if (!actualEstaRepetido) { // hay que ver si metemos el ultimo elemento
//               lista2.add(elementoAnterior);
//          }
//          return lista2;
//     }
}
