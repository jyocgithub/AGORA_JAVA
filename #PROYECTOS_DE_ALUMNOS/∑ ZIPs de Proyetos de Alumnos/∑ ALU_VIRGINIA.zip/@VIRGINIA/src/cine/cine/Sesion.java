package cine;

//import anotacion.Programacion2;
//
//@Programacion2 (
//		nombreAutor1 = "Virginia",
//		apellidoAutor1 = "Esteban Salguero",
//		emailUPMAutor1 = "virginia.esteban.salguero@alumnos.upm.es",
//		nombreAutor2 = "",
//		apellidoAutor2 = "", 
//		emailUPMAutor2 = ""
//	)

public class Sesion {

    private String hora;
    private int asientosDisponibles;
    private int sigIdCompra;
    private int[][] estadoAsientos;

    // añadidos 
    private int filas, columnas;

    public Sesion(String hora, int filas, int columnas) {
        if (filas > 0 && columnas > 0) {
            this.hora = hora;
            this.asientosDisponibles = filas * columnas;
            this.sigIdCompra = 1;
            estadoAsientos = new int[filas][columnas];
            this.filas = filas;
            this.columnas = columnas;
        }
    }

    /**
     * Dada la posicion de la butaca la reserva
     *
     * @param fila
     * @param columna
     */

    public void comprarEntrada(int fila, int columna) {
        if (fila > 0 && fila <= filas && columna > 0 && columna <= columnas) {
            estadoAsientos[fila - 1][columna - 1] = sigIdCompra;
            sigIdCompra++;
            asientosDisponibles--;
        }
    }

    /**
     * Dada la posicion de la butaca te muestra su codigo de identificacion
     *
     * @param fila
     * @param columna
     * @return numero de identificacion
     */
    public int getIdEntrada(int fila, int columna) {
        if (fila > 0 && fila <= filas && columna > 0 && columna <= columnas) {
            return estadoAsientos[fila - 1][columna - 1];
        }
        return 0;
    }

    /**
     * Te informa sobre el numero de butacas que quedan sin reservar
     *
     * @return numero de asientos libres
     */

    public int getButacasDisponiblesSesion() {
        return asientosDisponibles;

    }

    /**
     *
     * @return hora de la pelicula
     */

    public String getHora() {
        return hora;

    }

    /**
     * Te mostrara una matriz con las butacas libres y las butacas reservadas
     *
     * @return devuelve 0 si esta libre y # si esta reservada
     */

    public char[][] getEstadoSesion() {
        char[][] resultado = new char[estadoAsientos.length][estadoAsientos[0].length];
        for (int fila = 0; fila < estadoAsientos.length; fila++) {
            for (int colum = 0; colum < estadoAsientos[0].length; colum++) {
                if (estadoAsientos[fila][colum] == 0) {
                    resultado[fila][colum] = 'O';
                } else {
                    resultado[fila][colum] = '#';
                }

            }
        }
        return resultado;

    }

    /**
     *
     * @param id
     * @return
     */
    public String recogerEntradas(int id) {
        String res = hora + "+";
        for (int fila = 0; fila < estadoAsientos.length; fila++) {
            for (int colum = 0; colum < estadoAsientos[0].length; colum++) {
                if (estadoAsientos[fila][colum] == id) {
                    res = res + (fila + 1) + "," + (colum + 1) + "+";
                }

            }
        }
        if (res.equals(hora + "+")) {
            return null;
        }
        return res;
    }

    /**
     * Selecciona un numero de butacas que esten juntas
     *
     * @param noButacas es el numero de butacas que la persona quiere reservar
     * @return devuelve la posicion de las butacas seleccionadas
     */

    public ButacasContiguas recomendarButacasContiguas(int noButacas) {
        ButacasContiguas x = null;
        int finicial, ffinal;

        if (filas == 1) {
            finicial = 0;
            ffinal = 0;

        } else {
            // buscamos hacia abajo
            finicial = (filas + 1) / 2 + 1;
            ffinal = filas;
            // los numeros de fila son una unidad mas que el indice de la matriz
            finicial--;
            ffinal--;
        }
        for (int fil = finicial; fil <= ffinal && x == null; fil++) {
            for (int col = columnas - noButacas; col >= 0 && x == null; col--) {
                boolean estantodaslibres = true;
                // cuento el valor de las butacas existentes a ver si en total es 0
                for (int pos = 0; pos < noButacas; pos++) {
                    if (estadoAsientos[fil][col + pos] > 0) {
                        estantodaslibres = false;
                    }
//                    sumaValoresButacas = sumaValoresButacas + estadoAsientos[fil][col + pos];
                }

//                if (sumaValoresButacas == 0) {  // todas las butacas suman 0, luego estan libres
                if (estantodaslibres) {  // todas las butacas suman 0, luego estan libres
                    x = new ButacasContiguas(fil+1, col+1, noButacas);
                }
            }
        }

        if (filas > 1) {
            // buscamos hacia arriba
            finicial = (filas + 1) / 2;
            ffinal = 1;
            // los numeros de fila son una unidad mas que el indice de la matriz
            finicial--;
            ffinal--;
            for (int fil = finicial; fil >= ffinal && x == null; fil--) {
                for (int col = columnas - noButacas; col >= 0 && x == null; col--) {
                    int sumaValoresButacas = 0;
                    // cuento el valor de las butacas existentes a ver si en total es 0
                    for (int pos = 0; pos < noButacas; pos++) {
                        sumaValoresButacas = sumaValoresButacas + estadoAsientos[fil][col + pos];
                    }

                    if (sumaValoresButacas == 0) {  // todas las butacas suman 0, luego estan libres
                        x = new ButacasContiguas(fil+1, col+1, noButacas);
                    }
                }
            }
        }
        return x;

    }

    /**
     * Sirve para comprar las entradas recomendadas
     *
     * @param butacas indica la fila y columna
     */
    public void comprarEntradasRecomendadas(ButacasContiguas butacas) {
        if (butacas != null) {
            for (int pos = 0; pos < butacas.getNoButacas(); pos++) {
                estadoAsientos[butacas.getFila()-1][butacas.getColumna()-1 + pos] = sigIdCompra;
                asientosDisponibles--;
            }
            sigIdCompra++;
        }
    }

    /**
     *
     */
    public boolean equals(Object obj) {
        Sesion s = (Sesion) obj;
        if (hora.equals(s.hora)) {
            return true;
        }
        return false;
    }

}
