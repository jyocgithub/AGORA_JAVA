package cine;

import list.ArrayList;
//import anotacion.Programacion2;
//
//@Programacion2(nombreAutor1 = "Virginia", apellidoAutor1 = "Esteban Salguero", emailUPMAutor1 = "virginia.esteban.salguero@alumnos.upm.es", nombreAutor2 = "", apellidoAutor2 = "", emailUPMAutor2 = "")

public class Sala {

	private String pelicula;
	private ArrayList<Sesion> sesiones;
	private int filas;
	private int columnas;

	public Sala(String pelicula, String[] horasSesiones, int filas, int columnas) {
		this.pelicula = pelicula;
		this.filas = filas;
		this.columnas = columnas;
		sesiones = new ArrayList<Sesion>();

		if (horasSesiones != null) {
			for (int pos = 0; pos < horasSesiones.length; pos++) {
				incluirSesion(horasSesiones[pos]);
				//Sesion p = new Sesion(horasSesiones[pos], filas, columnas);
				//sesiones.add(pos, p);
			}
		}

	}

	/**
	 * Sirve para reservar una butaca de una sesion
	 *
	 * @param sesion
	 *            sesion a la que se quiere ir
	 * @param fila
	 *            posicion de la butaca
	 * @param columna
	 *            posicion de la butaca
	 */

	public void comprarEntrada(int sesion, int fila, int columna) {
		if (sesion > 0 && sesion <= sesiones.size()) {
			sesiones.get(sesion - 1).comprarEntrada(fila, columna);

		}
	}

	/**
	 * Te mostrara el numero identificador de una butaca de una sesion
	 * determinada
	 *
	 * @param sesion
	 * @param fila
	 * @param columna
	 * @return el numero identificador de la butaca que esta en dicha sesion
	 */

	public int getIdEntrada(int sesion, int fila, int columna) {
		int p = 0;

		if (sesion > 0 && sesion <= sesiones.size()) {

			p = sesiones.get(sesion - 1).getIdEntrada(fila, columna);
		}
		return p;
	}

	/**
	 * Te mostrara las horas de las peliculas
	 *
	 * @return un array con las horas
	 */

	public String[] getHorasDeSesionesDeSala() {
		String x[] = new String[sesiones.size()];
		for (int i = 0; i < x.length; i++) {
			x[i] = sesiones.get(i).getHora();
		}

		return x;
	}

	/**
	 * Te indica si las butacas estan reservadas(#) o libres (0)
	 *
	 * @param sesion
	 * @return matriz de caracteres
	 */

	public char[][] getEstadoSesion(int sesion) {
		char[][] p = null;
		if (sesion > 0 && sesion <= sesiones.size()) {
			p = sesiones.get(sesion - 1).getEstadoSesion();
		}
		return p;
	}

	/**
	 *
	 * @return devuelve el nombre de la pelicula
	 */

	public String getPelicula() {
		return this.pelicula;
	}

	/**
	 *
	 * @param id
	 * @param sesion
	 * @return
	 */

	public String recogerEntradas(int id, int sesion) {
		String p = null;
		if (sesion > 0 && sesion <= sesiones.size()) {
			String rrr = sesiones.get(sesion - 1).recogerEntradas(id);
			if (rrr != null && id > -1 && sesion > -1) {
				p = this.pelicula + "@" + sesiones.get(sesion - 1).recogerEntradas(id);

			}
		}
		return p;

	}

	/**
	 * Muestra cuantas butacas quedan aun sin reservar en una sesion
	 *
	 * @param sesion
	 * @return devuelve el numero de butacas libres
	 */

	public int getButacasDisponiblesSesion(int sesion) {
		if (sesion > 0 && sesion <= sesiones.size()) {
			return sesiones.get(sesion - 1).getButacasDisponiblesSesion();
		}
		return 0;
	}

	/**
	 * Selecciona un numero de butacas que se quieren reservar, las cuales
	 * tienen que estar juntas
	 *
	 * @param noButacas
	 *            numero de butacas que se necesitan libres
	 * @param sesion
	 *            sesion a la que se quiere ir
	 * @return devuelve la posicion en la que estan
	 */

	public ButacasContiguas recomendarButacasContiguas(int noButacas, int sesion) {
		if (sesion > 0 && sesion <= sesiones.size()) {
			ButacasContiguas p = sesiones.get(sesion - 1).recomendarButacasContiguas(noButacas);
			return p;
		}
		return null;
	}

	/**
	 * Compra entradas para unas butacas que estan libres
	 *
	 * @param sesion
	 *            sesion a la que se quiere ir
	 * @param butacas
	 */

	public void comprarEntradasRecomendadas(int sesion, ButacasContiguas butacas) {
		if (sesion > 0 && sesion <= sesiones.size() && butacas != null) {
			sesiones.get(sesion - 1).comprarEntradasRecomendadas(butacas);

		}
	}

	/**
	 * Te permite incluir una sesion
	 *
	 * @param horaSesion
	 *            sesion que se quiere incluir
	 */

	public void incluirSesion(String horaSesion) {
		Sesion sesion = new Sesion(horaSesion, filas, columnas);
		boolean insertado = false;
		for (int i = 0; i < sesiones.size() && !insertado; i++) {
			if (horaSesion.compareTo(sesiones.get(i).getHora()) < 0) {
				sesiones.add(i, sesion);
				insertado = true;
			}
		}
		if (!insertado) {
			sesiones.add(sesiones.size(), sesion);
		}
	}

	/**
	 * Te permite borrar una sesion
	 *
	 * @param horaSesion
	 *            sesion que se quiere eliminar
	 */

	public void borrarSesion(String horaSesion) {
		boolean borrado = false;
		for (int pos = 0; pos < sesiones.size() && !borrado; pos++) {
			if (sesiones.get(pos).getHora().equals(horaSesion)) {
				sesiones.removeElementAt(pos);
				borrado = true;
			}
		}

	}

}
