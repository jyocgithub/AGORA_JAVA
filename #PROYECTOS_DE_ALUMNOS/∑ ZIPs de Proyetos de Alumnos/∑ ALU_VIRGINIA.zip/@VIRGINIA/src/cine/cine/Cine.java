package cine;
//import anotacion.Programacion2; 
//@Programacion2 (
//		nombreAutor1 = "Virginia",
//		apellidoAutor1 = "Esteban Salguero",
//		emailUPMAutor1 = "virginia.esteban.salguero@alumnos.upm.es",
//		nombreAutor2 = "",
//		apellidoAutor2 = "", 
//		emailUPMAutor2 = ""
//	)

public class Cine {

	private String nombre;
	private Sala[] salas;

	public Cine(String nombre, Sala[] salas) {
		this.nombre = nombre;
		this.salas = salas;
	}

	/**
	 * comprarEntrada
	 * Compra las entradas de una sala, sesion y posicion indicada
	 * @param sala sala donde comprar entradas
	 * @param sesion sesion a la que se quiere ir
	 * @param fila    
	 * @param columna   
	 */
	public void comprarEntrada(int sala, int sesion, int fila, int columna) {
		if(fila>-1 && columna>-1 &&       sala>-1 && sala<salas.length){
		salas[sala - 1].comprarEntrada(sesion , fila, columna);
		}
	}

	/**
	 * Recomienda un numero de butacas que esten juntas y libres en una sesion
	 * @param noButacas butacas que se desean
	 * @param sala sala donde comprar las entradas
	 * @param sesion sesion a la que se quiere ir
	 * @return devuelve la posicion en la que estan dichas butacas libres
	 */
	public ButacasContiguas recomendarButacasContiguas(int noButacas, int sala, int sesion) {
		ButacasContiguas p = salas[sala - 1].recomendarButacasContiguas(noButacas, sesion);
		return p;
	}
	/**
	 * te devuelve el numero de identificacion de una butaca conociendo la sala y sesion
	 * @param sala sala donde comprar las entradas
	 * @param sesion sesion a la que se quiere ir
	 * @param fila
	 * @param columna
	 * @return devuelve el numero identificador
	 */

	public int getIdEntrada(int sala, int sesion, int fila, int columna) {
		int p = salas[sala - 1].getIdEntrada(sesion, fila, columna);
		return p;
	}
	/**
	 * Te mostrara una matriz con las butacas libres y las reservadas de una sesion
	 * @param sala sala de la que se quiere ver el estado de las butacas
	 * @param sesion sesion de la sala seleccionada
	 * @return devuelve una matriz de caracteres
	 */

	public char[][] getEstadoSesion(int sala, int sesion) {
		char[][] p = salas[sala - 1].getEstadoSesion(sesion);
		return p;
	}
	/**
	 * Te mostrara el titulo de las peliculas de una sala
	 * @return devuelve un array con los titulos de las peliculas
	 */

	public String[] getPeliculas() {
		String[] p = new String[salas.length];
		for (int i = 0; i < salas.length; i++) {
			p[i] = salas[i].getPelicula();
		}
		return p;
	}
	/**
	 * Te mostrara las horas con las peliculas de una sala
	 * @param sala sala a la que se quiere ir
	 * @return devuelve un array con las horas de las peliculas de una sala
	 */

	public String[] getHorasDeSesionesDeSala(int sala) {
		String[] p = salas[sala - 1].getHorasDeSesionesDeSala();
		return p;

	}
	/**
	 * 
	 * @param id
	 * @param sala sala para la que se compran las entradas
	 * @param sesion sesion a la que se quiere ir
	 * @return
	 */

	public String recogerEntradas(int id, int sala, int sesion) {
		String p = null;

		if (sala > -1 && sala < salas.length) {

			String rrr = salas[sala - 1].recogerEntradas(id, sesion);
			if (rrr != null) {

				p = this.nombre + "@" + salas[sala - 1].recogerEntradas(id, sesion);
			}

		}

		return p;
	}
	/**
	 * Te informa de que butacas hay en una sala sin reservar
	 * @param sala sala para la que se compra la entrada
	 * @param sesion sesion a la que se quiere ir
	 * @return devuelve el numero de butacas que quedan sin reservar
	 */

	public int getButacasDisponiblesSesion(int sala, int sesion) {
		return salas[sala - 1].getButacasDisponiblesSesion(sesion);
	}
	/**
	 * Te selecciona un numero de butacas que esten juntas para que las compres
	 * @param sala sala para la que se compran las entradas
	 * @param sesion sesion a la que se quiere ir
	 * @param butacas devuelve que butacas ha seleccionado el programa 
	 */

	public void comprarEntradasRecomendadas(int sala, int sesion, ButacasContiguas butacas) {
		if (sala > -1 && sala < salas.length && butacas != null) {

			salas[sala - 1].comprarEntradasRecomendadas(sesion, butacas);
		}

	}
	/**
	 * Sirve para incluir horas de sesion en una sala
	 * @param sala sala en la que se quiere incluir una sesion (su hora)
	 * @param horaSesion hora de la sesion que se va a incluir
	 */

	public void incluirSesion(int sala, String horaSesion) {
		salas[sala - 1].incluirSesion(horaSesion);

	}
	
	/**
	 * Sirve para borrar horas de sesion de una sala
	 * @param sala sala en la que se quiere borrar una sesion
	 * @param horaSesion hora de la sesion que se quiere eliminar
	 */

	public void borrarSesion(int sala, String horaSesion) {
		salas[sala - 1].borrarSesion(horaSesion);

	}

}