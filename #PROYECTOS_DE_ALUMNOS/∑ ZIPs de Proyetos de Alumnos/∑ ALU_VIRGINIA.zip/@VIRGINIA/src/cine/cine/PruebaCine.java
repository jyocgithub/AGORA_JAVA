package cine;

import java.util.ArrayList;


/**
 *
 * @author Virginia
 */
public class PruebaCine {

    public static void main(String[] args) {

//        p1();
        p2();


    }

    public static void p2() {

        String horas[] = {"16:00", "20:00", "10:00"};
        Sala sa1 = new Sala("LIFE", horas, 3, 6);
        
        String horas2[] = {"22:00"};
        Sala sa2 = new Sala("MARS", horas2, 1, 10);
        
        Sala[] salas = {sa1, sa2};
        Cine cin = new Cine("IDEAL", salas);

        cin.comprarEntrada(2, 1, 1, 5);
        
        
        ButacasContiguas bc = cin.recomendarButacasContiguas(3, 2, 1);
         cin.comprarEntradasRecomendadas(2, 1, bc);
         
         bc = cin.recomendarButacasContiguas(3, 1, 1);
         bc = cin.recomendarButacasContiguas(9, 1, 1);

    }

    public static void p1() {
        //*********************************************************
        // pruebas creacion sesiones
        //*********************************************************

        Sesion se1 = new Sesion("10:00", 2, 2);
        se1 = new Sesion("10:00", 0, 0);
        se1 = new Sesion("10:00", 2, -1);
        se1 = new Sesion("10:00", -1, 2);
        se1 = new Sesion("", 2, 2);
        se1 = new Sesion(":", -2, -2);
        // Esto falla por outofmemory, pero no creo que debamos controlarlo
        // s1 = new Sesion("10:00", 2000000,20000000);


        //*********************************************************
        // pruebas comprarEntrada , getButacasDisponiblesSesion , getIdEntrada
        //*********************************************************
        se1 = new Sesion("10:00", 4, 5);

        System.out.println("hay de inicio ... " + se1.getButacasDisponiblesSesion());

        System.out.println("> Compramos 0,0 (no existe) ");
        se1.comprarEntrada(0, 0);
        pintarSesion(se1);
        System.out.println("id de entrada 0,0: " + se1.getIdEntrada(0, 0));

        System.out.println("Quedan ... " + se1.getButacasDisponiblesSesion());
        System.out.println("> Compramos 1,1 ");
        se1.comprarEntrada(1, 1);
        pintarSesion(se1);
        System.out.println("id de entrada 1,1: " + se1.getIdEntrada(1, 1));

        System.out.println("Quedan ... " + se1.getButacasDisponiblesSesion());
        System.out.println("> Compramos 4,5 ");
        se1.comprarEntrada(4, 5);
        pintarSesion(se1);
        System.out.println("id de entrada 4,5: " + se1.getIdEntrada(4, 5));


        System.out.println("Quedan ... " + se1.getButacasDisponiblesSesion());
        System.out.println("> Compramos 5,1 (no existe) ");
        se1.comprarEntrada(5, 1);
        pintarSesion(se1);
        System.out.println("id de entrada 5,1 " + se1.getIdEntrada(5, 1));



        System.out.println("Quedan ... " + se1.getButacasDisponiblesSesion());
        System.out.println("> Compramos 2,6 (no existe) ");
        se1.comprarEntrada(2, 6);
        pintarSesion(se1);


        System.out.println("Quedan ... " + se1.getButacasDisponiblesSesion());
        System.out.println("> Compramos 3,2 ");
        se1.comprarEntrada(3, 2);
        pintarSesion(se1);

        //*********************************************************
        // pruebas recomendar buatacas contiguas
        //*********************************************************
        System.out.println(se1.getHora());
        System.out.println(se1.getButacasDisponiblesSesion());

        System.out.println("recomendar 2:-------------");
        ButacasContiguas bc = se1.recomendarButacasContiguas(2);
        pintarButacasContiguas(bc);

        System.out.println("recomendar 4:-------------");
        bc = se1.recomendarButacasContiguas(4);
        pintarButacasContiguas(bc);

        System.out.println("recomendar 5:-------------");
        bc = se1.recomendarButacasContiguas(5);
        pintarButacasContiguas(bc);


        // vendemos mas y nueva comprobacion
        se1.comprarEntrada(2, 2);
        pintarSesion(se1);
        se1.comprarEntrada(4, 2);
        pintarSesion(se1);

        System.out.println("recomendar 4:-------------");
        bc = se1.recomendarButacasContiguas(4);
        pintarButacasContiguas(bc);

        System.out.println("recomendar 5:-------------");
        bc = se1.recomendarButacasContiguas(5);
        pintarButacasContiguas(bc);

        // probamos con un cine con 1 sola fila 
        System.out.println("CINE UNA FILA ______________________________________");
        Sesion se2 = new Sesion("10:00", 1, 5);
        pintarSesion(se2);
        bc = se2.recomendarButacasContiguas(1);
        pintarButacasContiguas(bc);
        bc = se2.recomendarButacasContiguas(3);
        pintarButacasContiguas(bc);
        bc = se2.recomendarButacasContiguas(6);
        pintarButacasContiguas(bc);

        //*********************************************************
        // pruebas comprar entradas recomendadas
        //*********************************************************

        System.out.println("recomendar y comprar  2:-------------");
        bc = se1.recomendarButacasContiguas(2);
        pintarButacasContiguas(bc);
        se1.comprarEntradasRecomendadas(bc);
        pintarSesion(se1);

        System.out.println("recomendar y comprar  4:-------------");
        bc = se1.recomendarButacasContiguas(4);
        pintarButacasContiguas(bc);
        se1.comprarEntradasRecomendadas(bc);
        pintarSesion(se1);

        System.out.println("recomendar y comprar  5:-------------");
        bc = se1.recomendarButacasContiguas(5);
        pintarButacasContiguas(bc);
        se1.comprarEntradasRecomendadas(bc);
        pintarSesion(se1);


        System.out.println("recomendar y comprar  1:-------------");
        bc = se1.recomendarButacasContiguas(1);
        pintarButacasContiguas(bc);
        se1.comprarEntradasRecomendadas(bc);
        pintarSesion(se1);

        System.out.println("recomendar y comprar  3:-------------");
        bc = se1.recomendarButacasContiguas(3);
        pintarButacasContiguas(bc);
        se1.comprarEntradasRecomendadas(bc);
        pintarSesion(se1);

        System.out.println("recomendar y comprar  2:-------------");
        bc = se1.recomendarButacasContiguas(2);
        pintarButacasContiguas(bc);
        se1.comprarEntradasRecomendadas(bc);
        pintarSesion(se1);

        System.out.println("recomendar y comprar  1:-------------");
        bc = se1.recomendarButacasContiguas(1);
        pintarButacasContiguas(bc);
        se1.comprarEntradasRecomendadas(bc);
        pintarSesion(se1);

        System.out.println("recomendar y comprar  1:-------------");
        bc = se1.recomendarButacasContiguas(1);
        pintarButacasContiguas(bc);
        se1.comprarEntradasRecomendadas(bc);
        pintarSesion(se1);

        System.out.println("recomendar y comprar  1:-------------");
        bc = se1.recomendarButacasContiguas(1);
        pintarButacasContiguas(bc);
        se1.comprarEntradasRecomendadas(bc);
        pintarSesion(se1);

        System.out.println("recomendar y comprar  1:-------------");
        bc = se1.recomendarButacasContiguas(1);
        pintarButacasContiguas(bc);
        se1.comprarEntradasRecomendadas(bc);
        pintarSesion(se1);

        System.out.println("id de entrada -1,0: " + se1.getIdEntrada(-1, 0));
        System.out.println("id de entrada 0,-1: " + se1.getIdEntrada(0, -1));
        System.out.println("id de entrada 12,0: " + se1.getIdEntrada(12, 0));
        System.out.println("id de entrada 0,12: " + se1.getIdEntrada(0, 12));
        System.out.println("id de entrada 1,1: " + se1.getIdEntrada(1, 1));
        System.out.println("id de entrada 4,5: " + se1.getIdEntrada(4, 5));
        System.out.println("id de entrada 1,1: " + se1.getIdEntrada(1, 1));
        System.out.println("id de entrada 3,3: " + se1.getIdEntrada(3, 3));

        System.out.println("estas tres han de ser iguales ");
        System.out.println("id de entrada 2,3: " + se1.getIdEntrada(2, 3));
        System.out.println("id de entrada 2,4: " + se1.getIdEntrada(2, 4));
        System.out.println("id de entrada 2,5: " + se1.getIdEntrada(2, 5));


        Sesion s3 = new Sesion("12:20", 3, 3);
        Sesion s4 = new Sesion("12:20", 3, 3);
        Sesion s5 = new Sesion("22:45", 3, 3);
        System.out.println("son iguals s3 y s4:" + s3.equals(s4));
        System.out.println("son iguals s4 y s5:" + s4.equals(s5));

        System.out.println(se1.recogerEntradas(9));

        //*********************************************************
        // pruebas SALA
        //*********************************************************
        System.out.println("\n\nPRUEBAS SALA =====================================");

        String horas[] = {"16:00", "20:00", "22:00"};
        Sala sa1 = new Sala("LIFE", horas, 4, 6);
        String ho[] = sa1.getHorasDeSesionesDeSala();
        System.out.println("");
        for (String h : ho) {
            System.out.println(h);
        }

        sa1.incluirSesion("18:00");
        ho = sa1.getHorasDeSesionesDeSala();
        System.out.println("");
        for (String h : ho) {
            System.out.println(h);
        }

        sa1.incluirSesion("23:30");
        ho = sa1.getHorasDeSesionesDeSala();
        System.out.println("");
        for (String h : ho) {
            System.out.println(h);
        }

        sa1.incluirSesion("10:30");
        ho = sa1.getHorasDeSesionesDeSala();
        System.out.println("");
        for (String h : ho) {
            System.out.println(h);
        }

        sa1.borrarSesion("20:00");
        ho = sa1.getHorasDeSesionesDeSala();
        System.out.println("");
        for (String h : ho) {
            System.out.println(h);
        }

        sa1.borrarSesion("26:00");
        ho = sa1.getHorasDeSesionesDeSala();
        System.out.println("");
        for (String h : ho) {
            System.out.println(h);
        }


        int numsesion = 1;
        System.out.println("hay de inicio ... " + sa1.getButacasDisponiblesSesion(numsesion));

        System.out.println("> Compramos 0,0 (no existe) ");
        sa1.comprarEntrada(numsesion, 0, 0);
        pintarSala(sa1, numsesion);
        System.out.println("id de entrada 0,0: " + sa1.getIdEntrada(numsesion, 0, 0));

        System.out.println("> Compramos 1,1");
        sa1.comprarEntrada(numsesion, 1, 1);
        pintarSala(sa1, numsesion);
        System.out.println("id de entrada 1,1: " + sa1.getIdEntrada(numsesion, 0, 0));

        System.out.println("> Compramos 4,5 ");
        sa1.comprarEntrada(numsesion, 4, 5);
        pintarSala(sa1, numsesion);
        System.out.println("id de entrada 4,5: " + sa1.getIdEntrada(numsesion, 0, 0));

        //*********************************************************
        // pruebas recomendar buatacas contiguas
        //*********************************************************
        System.out.println(se1.getHora());
        System.out.println(se1.getButacasDisponiblesSesion());

        System.out.println("recomendar 2:-------------");
        bc = sa1.recomendarButacasContiguas(2, 1);
        pintarButacasContiguas(bc);

        System.out.println("recomendar 4:-------------");
        bc = sa1.recomendarButacasContiguas(4, 1);
        pintarButacasContiguas(bc);

        System.out.println("recomendar 5:-------------");
        bc = sa1.recomendarButacasContiguas(5, 1);
        pintarButacasContiguas(bc);

        Sala[] arraysalas = {sa1};
        Cine ci1 = new Cine("MICINE", arraysalas);

    }


    public static void pintarSesion(Sesion se1) {
        char[][] plano = se1.getEstadoSesion();
        System.out.println("--------------------------");
        for (int f = 0; f < plano.length; f++) {
            for (int c = 0; c < plano[0].length; c++) {
                System.out.print(plano[f][c] + "\t");
            }
            System.out.println("");
        }
        System.out.println("--------------------------");
    }

    public static void pintarSala(Sala sa1, int sesion) {
        char[][] plano = sa1.getEstadoSesion(1);
        System.out.println("--------------------------");
        for (int f = 0; f < plano.length; f++) {
            for (int c = 0; c < plano[0].length; c++) {
                System.out.print(plano[f][c] + "\t");
            }
            System.out.println("");
        }
        System.out.println("--------------------------");
    }

    public static void pintarButacasContiguas(ButacasContiguas bc) {
        if (bc != null) {
            System.out.println(" fil : " + bc.getFila());
            System.out.println(" col : " + bc.getColumna());
            System.out.println(" total : " + bc.getNoButacas());
        } else {
            System.out.println("ButacasContiguas no da resultado, no existen lo pedido");
        }
    }

}
