package virginia;

import java.util.ArrayList;

public class TestVestido {

	public static void main(String[] args) {

		Vestido v = new Vestido("rojo", "X", 1999);
		System.out.println(v.mostrar());

		v.setPrecio(123);

		ArrayList<String> lis = new ArrayList<>();
		System.out.println(v.color);
		v.color = "jlhljglhj";
		v.getTalla();
		v.setTalla("XXXL");

	}

}
