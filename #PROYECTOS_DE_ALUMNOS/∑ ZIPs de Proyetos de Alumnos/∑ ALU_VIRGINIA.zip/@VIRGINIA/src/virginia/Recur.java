package virginia;

public class Recur {

	public static void main(String[] args) {
		contar(3);
	}

	public static int contar(int x) {
		System.out.println("Tengo un " + x);
		if (x < 320) contar(x + 1);
		System.out.println("Tenia un " + x);
		return x;
	}

}
