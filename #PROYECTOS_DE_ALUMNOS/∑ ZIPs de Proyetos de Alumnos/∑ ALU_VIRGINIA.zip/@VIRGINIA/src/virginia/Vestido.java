package virginia;

public class Vestido {

   public String color;
   private String talla;
   private double precio;
   private double ano;

   Vestido(String c, String t, double p, double a) {
      color = c;
      talla = t;
      precio = p;
      ano = a;

   }

   Vestido() {
   }

   Vestido(String c, String t, double a) {
      color = c;
      talla = t;
      precio = 0;
      ano = a;

   }

   public String mostrar() {
      String res = "";

      res = "El color es : " + color + " y la talla es :" + talla;

      return res;
   }

   public void setColor(String color) {
      this.color = color;
   }

   public String getColor() {
      return color;
   }

   void descuento() {
      double d = precio - 2;
      precio = d;
   }

   void descuento2(int n) {
      double d = precio / 100 * n;
      precio = precio - d;
   }

   void descuento3(int descuento, int anio) {
      if (anio > ano) {

         double d = precio / 100 * descuento;
         precio = precio - d;
      }
   }

   double descuento4(int descuento, int anio) {
      double resultado = 0;

      if (anio > ano) {
         double d = precio / 100 * descuento;
         precio = precio - d;
         resultado = precio;

      }
      return resultado;
   }

   public String getTalla() {
      return talla;
   }

   public void setTalla(String talla) {
      this.talla = talla;
   }

   public double getPrecio() {
      return precio;
   }

   public void setPrecio(double precio) {
      this.precio = precio;
   }

   public double getAno() {
      return ano;
   }

   public void setAno(double ano) {
      this.ano = ano;
   }

}
