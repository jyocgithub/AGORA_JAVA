package virginia;

public class Virginia {


   public static void main(String[] args) {
      
      Vestido v1 = new Vestido();
      
      v1.setColor("Rojo");
      
      v1.ponercolor("Rojo");
      
      System.out.println(v1.damecolor());
      
      
      
      v1.color = "UNAMIERDA";
      
      v1.precio = 120;
      v1.ano = 2000;
      
      System.out.println(v1.precio);
      v1.descuento();
      System.out.println(v1.precio);
      
      v1.descuento2(40);
      System.out.println(v1.precio);
      
      v1.descuento3(70, 2012);
      System.out.println(v1.precio);
      
      double ddd= v1.descuento4(10, 2012);
      System.out.println(ddd);
      
      
      Vestido m = new Vestido("Rojo","X",80,2012);
      
      
        Vestido h = new Vestido("Rojo","X",2012);
      
      
      System.out.println(123);
            System.out.println("bkjvbvb");

      
      
   }
   
}
