package Excepciones;

public class Inicio {
	static int p[] = new int[6];

	public static void main(String[] args) {

		int c = 0;
		int f = 0;

		try {
			int h = 0;
			// int y = h / f;
			// h = p[88];
			contar();

		} catch (NullPointerException ee) {
			System.out.println("Me dio un null !!!");
		} catch (ArithmeticException yyyy) {
			yyyy.printStackTrace();
			System.out.println("Me dio un aritmetic !!!");
		} catch (IndexOutOfBoundsException ee) {
			System.out.println("Me dio un index out  !!!");
			return;

		} catch (Exception ee) {
			String t = ee.getMessage();
			System.out.println("Me dio una excepocino !!!");
		} finally {

			System.out.println("EN EL FINALLY");
		}

		System.out.println("tras el error");

	}

	static void contar() {
		for (int i = 0; i < p.length; i++) {
			int popo = p[i + 3];
		}
	}

}
