package banco;
import persona.Cliente;
import banco.excepciones.ExcepcionNoHayDineroSuficiente;

public class CuentaCorriente {

	/**
	 * id interno de la cuenta
	 * Imposible que haya dos iguales
	 */	
    private static int genCC = 1;
    private int cc;
    
	/**
	 * Cliente al que pertenece la cuenta
	 */
	private Cliente cliente;

	/**
	 * Saldo de la cuenta
	 */
	private double saldo;

	public CuentaCorriente(double saldo, Cliente cliente) {
		// guardar id de la cuenta lo primero
		this.cc = genCC++;		
		this.cliente = cliente;		
		this.saldo = saldo;
	}

	/**
	 * Ingresa dinero en la cuenta
	 * @param valor Cantidad de dinero a ingresar
	 * Ningún impedimento para ingresar pasta
	 */
	public void ingresarDinero (double valor) {
		this.saldo += valor;
	}

	/**
	 * Retira dinero de la cuenta
	 * @param valor Cantidad de dinero a retirar
	 */
	public void retirarDinero (double valor) throws ExcepcionNoHayDineroSuficiente {
		if (this.saldo < valor) {	//Saldo insuficente		
			throw new ExcepcionNoHayDineroSuficiente("Sólo dispone de " + this.saldo + "€. No puede retirar "+valor+"€.");
		}
		this.saldo -= valor;
	}

	public double getCC() {
		return cc;
	}

	public Cliente getCliente() {
		return cliente;
	}

	public double getSaldo() {
		return saldo;
	}

	@Override
	public String toString() {
		return "#CC: " + this.cc + "; Saldo: " + this.saldo +
		" Cliente: [" + this.cliente +"]";
	}
}
