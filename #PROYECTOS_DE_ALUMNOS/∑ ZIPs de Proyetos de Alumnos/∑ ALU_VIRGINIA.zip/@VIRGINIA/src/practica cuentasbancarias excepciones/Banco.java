package banco;

import banco.excepciones.ExcepcionBancoLleno;
import banco.excepciones.ExcepcionCantidadErronea;
import banco.excepciones.ExcepcionClienteNoValido;
import banco.excepciones.ExcepcionCuentaNoExiste;
import banco.excepciones.ExcepcionCuentaYaExiste;
import banco.excepciones.ExcepcionNoHayDineroSuficiente;
import banco.excepciones.ExcepcionSaldoNoValido;

import persona.Cliente;

public class Banco {

     private String nombre;
     private int numCuentas;
     private double gastosApertura;
     private CuentaCorriente[] cuentas;

     public Banco(String nombre, int numCuentas, double gastosApertura) throws ExcepcionCantidadErronea {
          if (numCuentas > 0 && gastosApertura > 0) {
               this.nombre = nombre;
               this.gastosApertura = gastosApertura;
               this.cuentas = new CuentaCorriente[numCuentas];

          } else {
               throw new ExcepcionCantidadErronea("Datos incorrectos");
          }
     }

	// abrir una cuenta en el primer hueco disponible
     // devuelve la cuenta que se haya abierto
     // excepciones: bancoLleno clienteNoValido, CuentaYaExiste,
     // NoHayDineroSuficiente
     // PRE : !EstaLleno && cliente no tiene cuenta && saldoInicial >
     // gastosApertura && cliente != null
     public CuentaCorriente abrirCuentaCorriente(Cliente cliente, double saldoInicial) throws ExcepcionClienteNoValido,
             ExcepcionNoHayDineroSuficiente, ExcepcionCuentaYaExiste, ExcepcionBancoLleno {

          CuentaCorriente p = null;

          for (int i = 0; i < cuentas.length && p == null; i++) {
               if (cliente == null) {
                    throw new ExcepcionClienteNoValido();
               } else if (saldoInicial < gastosApertura) {
                    throw new ExcepcionNoHayDineroSuficiente();
               } else if (cuentas[i] != null) {
                    while (cuentas[i].getCliente() == cliente) {
                         throw new ExcepcionCuentaYaExiste("ya existe esta cuenta");
                    }
               } else if (cuentas[cuentas.length - 1] != null) {
                    throw new ExcepcionBancoLleno();
               } //si no se lanza ninguna excepcion entonces se abre la cuenta
               else {
                    if (cuentas[i] == null) {
                         p = new CuentaCorriente(saldoInicial, cliente);
                         cuentas[i] = p; //para que no entre mas en el bucle
                    }
               }
          }
          return p; //devuelve la cuenta pintada con el toString
     }

	// busca una cuenta a partir del DNI
     // so hay cuenta devuelve la pos en la que se encuentra sino -1
     // excepcion: ClienteNoValido
     private int buscarCuenta(String dni) throws ExcepcionClienteNoValido {
          if (dni == null) {
               throw new ExcepcionClienteNoValido();
          }

          //si el dni es correcto guarda en p la posicion en la que se encuentra
          int p = -1; //en caso de no ser encontrado
          for (int i = 0; i < cuentas.length && p == -1; i++) {
               if (cuentas[i].getCliente().getDni().compareToIgnoreCase(dni) == 0) {
                    p = i; //guarda la posicion en la que esta en el array 
               }
          }
          return p;
     }

	// Cierra una cuenta corriente
     // PRE: cliente tiene cuenta && saldoActual es real && cliente existe
     // excepciones:  ClienteNoValido,SaldoNoValido
     public void cerrarCuentaCorriente(Cliente cliente, double saldo)
             throws ExcepcionClienteNoValido, ExcepcionCuentaNoExiste, ExcepcionSaldoNoValido {

          for (int i = 0; i < cuentas.length; i++) {
               if (cliente == null) {
                    throw new ExcepcionClienteNoValido();
               } else if (cuentas[i] != null) {
                    while (cuentas[i].getCC() <= 0) {
                         throw new ExcepcionCuentaNoExiste();
                    }
               } else if (saldo < 0) {
                    throw new ExcepcionSaldoNoValido();
               } //si no lanza ninguna excepcion borra la cuenta
               else {
                    if (cuentas[i].getCliente() == cliente) {
                         cuentas[i] = null;
                    }
               }
          }

     }

	// si hay cuenta devuelce la cuenta sino devuelve null
     // Excepcion: clienteNoValido
     // devuele la cuenta de un cliente en concreto si no existe devuelve null
     public CuentaCorriente getcuenta(String dni) throws ExcepcionClienteNoValido {
          if (dni == null) {
               throw new ExcepcionClienteNoValido();
          } else {
               int p = buscarCuenta(dni); //guarda la posicion sino es -1
               if (p != -1) {
                    return cuentas[p];
               }
               return null; //si fuese igual a -1 no existiria la cuenta
          }
     }


     public String getNombre() {
          return this.nombre;
     }

	// excepciones:CuentaNoExiste,CantidadErronea
     // Ingresa dinero en la cuenta del cliente identificado por el dni
     // PRE: cliente tiene cuenta && cantidad>0
     public void ingresarDinero(String dni, double cantidad) throws ExcepcionSaldoNoValido, ExcepcionCuentaNoExiste, ExcepcionClienteNoValido {
          if (cantidad < 0) {
               throw new ExcepcionSaldoNoValido();
          }
          // me creo un indicador para saber si me he encontrado ya la cuenta
          boolean existelacuenta = false;
          // ne el for la condicion la amplio para que se salga si ya he encontrado la cuenta 
          for (int i = 0; i < cuentas.length && existelacuenta==false; i++) {
               // solo analizo las cuentas que no sean null
               if (cuentas[i] != null) {
                    // miro si de cada cuenta (que ya se que no es null)
                    // el dni del cliente es el que me han pasado
                    if(cuentas[i].getCliente().getDni().equals(dni)){
                         // si llego aqui es que ya tengo la cuenta correcta
                         // er ingrteso el dinero con el metodo correspondiente
                         // de la cuenta
                         cuentas[i].ingresarDinero(cantidad);
                         // pongo el indicador de que he encotrado cuenta a true
                         existelacuenta = true;
                    }
               }
                    
          }
          // si ya he acabado de buscar en todas las cuentas (todo el for)
          // y no encontre una cuenta, lanzo la excepcion
          if( existelacuenta == false){
               throw new ExcepcionCuentaNoExiste();
          }
     }

	// excepciones: CuentaNoExiste, CantidadErronea, noHayDineroSuf
     // Saca el dinero del cliente identificado por el dni
     //cliente tiene cuenta && cantidad > 0 && saldo > cantidad

     public void retirarDinero(String dni, double cantidad)
             throws ExcepcionCuentaNoExiste, ExcepcionCantidadErronea, ExcepcionNoHayDineroSuficiente, ExcepcionClienteNoValido {
          int p = buscarCuenta(dni);
          for (int i = 0; i < cuentas.length; i++) {

               if (cuentas[i].getCC() <= 0) {
                    throw new ExcepcionCuentaNoExiste();
               } else if (cantidad < 0) {
                    throw new ExcepcionCantidadErronea();
               } else if (cuentas[i].getSaldo() < cantidad) {
                    throw new ExcepcionNoHayDineroSuficiente();
               } else {
                    //no se como sacar el dinero
               }

          }
     }


     public void listarCuentas() {
          for (int i = 0; i < cuentas.length; i++) {
               System.out.println(cuentas[i]);
          }


     }
}
