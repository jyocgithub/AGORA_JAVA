package persona;


/**
 * Clase que representa clientes 
 *
 */
public class Cliente {

	/**
	 * DNI del cliente
	 */
	private String dni;

	/**
	 * Nombre del cliente
	 */
	private String nombre;

	public Cliente(String dni, String nombre) {//Cliente
		this.dni = dni;
		this.nombre = nombre;
	}
	
	public String getDni() {
		return dni;
	}
	
	public String getNombre() {
		return nombre;
	}

	@Override
	public String toString() {
		return "(DNI: " + this.dni + ", NOMBRE: " + this.nombre + ")";
	}
}
