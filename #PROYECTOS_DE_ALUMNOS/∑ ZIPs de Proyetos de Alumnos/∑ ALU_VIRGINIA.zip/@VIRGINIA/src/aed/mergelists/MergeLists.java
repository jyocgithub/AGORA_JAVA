package aed.mergelists;

import java.util.Comparator;

import es.upm.aedlib.Position;
import es.upm.aedlib.indexedlist.ArrayIndexedList;
import es.upm.aedlib.indexedlist.IndexedList;
import es.upm.aedlib.positionlist.NodePositionList;
import es.upm.aedlib.positionlist.PositionList;

public class MergeLists {

	/**
	 * Merges two lists ordered using the comparator cmp, returning a new ordered list.
	 * 
	 * @returns a new list which is the ordered merge of the two argument lists
	 */

	public static <E> PositionList<E> copiarLista(PositionList<E> lista) {

		PositionList<E> resultado = new NodePositionList<>();
		Position<E> puntero = lista.first(); // guarda la referencia al primer nodo
		Position<E> punteroresultado = null;
		while (puntero != null) {
			if (resultado.isEmpty()) {// si es la primera vuelta
				resultado.addFirst(puntero.element());
				punteroresultado = resultado.first();// apunta al nodo del primer elemento
			} else {// si ya hay un elemento guardado
				// punteroresultado = resultado.next(punteroresultado);// apunta al nodo del primer elemento
				resultado.addLast(puntero.element());
			}
			puntero = lista.next(puntero); // queda apuntando al nodo siguiente
		}
		return resultado;
	}

	// public static <E> PositionList<E> merge(final PositionList<E> l1, final PositionList<E> l2,
	// final Comparator<E> comp) {
	//
	// PositionList<E> resultado = new NodePositionList<>();
	// Position<E> indicelista2 = l2.first();
	// Position<E> indiceres = resultado.first();
	// Position<E> indicelista1 = l1.first();
	// // ninguna lista esta vacia
	// while (!(l1.isEmpty()) && !(l2.isEmpty()) && indicelista2 != null && indicelista1 != null) {
	// // el elemento de la lista1 es menor que el elemento de la lista2, por tanto lo copio
	// if (comp.compare(indicelista1.element(), indicelista2.element()) < 0) {
	// if (resultado.isEmpty()) {
	// resultado.addFirst(indicelista1.element());
	// indiceres = resultado.first();
	// indicelista1 = l1.next(indicelista1);
	// }
	// // resultado.addAfter(indiceres, indicelista1.element());
	// // indicelista1=l1.next(indicelista1);
	// // indiceres=resultado.next(indiceres);
	// //
	// } else if (comp.compare(indicelista1.element(), indicelista2.element()) == 0) {
	// if (resultado.isEmpty()) {
	// resultado.addFirst(indicelista1.element());
	// indiceres = resultado.first();
	// indicelista1 = l1.next(indicelista1);
	// resultado.addAfter(indiceres, indicelista2.element());
	// indicelista2 = l2.next(indicelista2);
	// // indiceres=resultado.next(indiceres);
	// }
	// // resultado.addAfter(indiceres, indicelista1.element());
	// // indiceres=resultado.next(indiceres);
	// // indicelista1=l1.next(indicelista1);
	// // resultado.addAfter(indiceres, indicelista2.element());
	// // indicelista2=l2.next(indicelista2);
	// //
	// }
	//
	// else if (comp.compare(indicelista1.element(), indicelista2.element()) > 0) {
	// if (resultado.isEmpty()) {
	// resultado.addFirst(indicelista2.element());
	// indiceres = resultado.first();
	// indicelista2 = l2.next(indicelista2);
	//
	// }
	// // resultado.addAfter(indiceres, indicelista2.element());
	// // indicelista2=l2.next(indicelista2);
	// // indiceres=resultado.next(indiceres);
	//
	// }
	// }
	// if (l1.isEmpty() && !(l2.isEmpty()) && indicelista2 != null) { // la primera lista esta vacia
	// resultado = copiarLista(l2);
	// }
	//
	// if (!(l1.isEmpty()) && l2.isEmpty()) { // la segunda lista esta vacia
	// resultado = copiarLista(l1);
	// }
	//
	// return resultado;
	//
	// }
	public static <E> PositionList<E> merge(final PositionList<E> l1, final PositionList<E> l2,
			final Comparator<E> comp) {

		PositionList<E> resultado = new NodePositionList<>();
		Position<E> indicelista2 = l2.first();
		Position<E> indiceres = resultado.first();
		Position<E> indicelista1 = l1.first();
		// ninguna lista esta vacia
		while (!(l1.isEmpty()) && !(l2.isEmpty()) && indicelista2 != null && indicelista1 != null) {
			// el elemento de la lista1 es menor que el elemento de la lista2, por tanto lo copio
			if (comp.compare(indicelista1.element(), indicelista2.element()) <= 0) {
				if (resultado.isEmpty()) {
					resultado.addFirst(indicelista1.element());
					indiceres = resultado.first();
				} else {
					resultado.addLast(indicelista1.element());
					indiceres = resultado.next(indiceres);
				}
				indicelista1 = l1.next(indicelista1);
				// } else if (comp.compare(indicelista1.element(), indicelista2.element()) == 0) {
				// if (resultado.isEmpty()) {
				// resultado.addFirst(indicelista1.element());
				// indiceres = resultado.first();
				// indicelista1 = l1.next(indicelista1);
				// resultado.addAfter(indiceres, indicelista2.element());
				// indicelista2 = l2.next(indicelista2);
				// // indiceres=resultado.next(indiceres);
				// }
				// // resultado.addAfter(indiceres, indicelista1.element());
				// // indiceres=resultado.next(indiceres);
				// // indicelista1=l1.next(indicelista1);
				// // resultado.addAfter(indiceres, indicelista2.element());
				// // indicelista2=l2.next(indicelista2);
				// //
			}

			else if (comp.compare(indicelista1.element(), indicelista2.element()) > 0) {
				if (resultado.isEmpty()) {
					resultado.addFirst(indicelista2.element());
					indiceres = resultado.first();
				} else {
					resultado.addLast(indicelista2.element());
					indiceres = resultado.next(indiceres);
				}
				indicelista2 = l2.next(indicelista2);
			}
		} // end of while

		if (l1.isEmpty() && !(l2.isEmpty())) { // la primera lista esta vacia
			resultado = copiarLista(l2);
		} else if (!(l1.isEmpty()) && l2.isEmpty()) { // la segunda lista esta vacia
			resultado = copiarLista(l1);
		} else {

			while (indicelista1 != null) { // se acabo l2, pero no l1
				resultado.addLast(indicelista1.element());
				indiceres = resultado.next(indiceres);
				indicelista1 = l1.next(indicelista1);
			}

			while (indicelista2 != null) { // se acabo l1, pero no l2
				resultado.addLast(indicelista2.element());
				indiceres = resultado.next(indiceres);
				indicelista2 = l2.next(indicelista2);
			}
		}

		return resultado;

	}

	/**
	 * Merges two lists ordered using the comparator cmp, returning a new ordered list.
	 * 
	 * @returns a new list which is the ordered merge of the two argument lists
	 */
	public static <E> IndexedList<E> merge(final IndexedList<E> l1, final IndexedList<E> l2, final Comparator<E> comp) {
		IndexedList<E> resultado = new ArrayIndexedList<>();

		if (!(l1.isEmpty()) && l2.isEmpty()) { // l2 viene vacia
			int i = 0;
			while (i < l1.size()) {
				resultado.add(i, l1.get(i));
				i++;
			}
		} else if (l1.isEmpty() && !(l2.isEmpty())) {// l1 viene vacia
			int i = 0;
			while (i < l2.size()) {
				resultado.add(i, l2.get(i));
				i++;
			}

		} else if (!(l1.isEmpty()) && !(l2.isEmpty())) {// ambas estan llenas
			int indicelista1 = 0;
			int indicelista2 = 0;
			int indiceres = 0;

			while (indicelista1 < l1.size() && indicelista2 < l2.size()) {

				if (comp.compare(l1.get(indicelista1), l2.get(indicelista2)) <= 0) {
					resultado.add(indiceres, l1.get(indicelista1));
					indicelista1++;
					indiceres++;
					// if (l2.size() <= l1.size()) {
					// resultado.add(indiceres, l2.get(indicelista2));
					// }

					// } else if (comp.compare(l1.get(indicelista1), l2.get(indicelista2)) == 0) {
					// resultado.add(indiceres, l1.get(indicelista1));
					// indicelista1++;
					// indiceres++;
					// System.out.println("aqui ando");
					// resultado.add(indiceres, l2.get(indicelista2));
					// indicelista2++;
					// indiceres++;

				}

				else if (comp.compare(l1.get(indicelista1), l2.get(indicelista2)) > 0) {
					resultado.add(indiceres, l2.get(indicelista2));
					indicelista2++;
					indiceres++;
					// if (l1.size() <= l2.size()) {
					// resultado.add(indiceres, l1.get(indicelista1));
					// }
				}
			}

			while (indicelista1 < l1.size()) { // se acabo l2, pero no l1
				resultado.add(indiceres, l1.get(indicelista1));
				indicelista1++;
				indiceres++;
			}
			while (indicelista2 < l2.size()) { // se acabo l2, pero no l1
				resultado.add(indiceres, l2.get(indicelista2));
				indicelista2++;
				indiceres++;
			}
		}
		return resultado;
	}
}
