package maximoRepetido;

import sun.applet.Main;

public class testmio {

     
     public static void main(String[] args) {
          Utils.maxNumRepeated(new Integer[]{2}, 2);
     }
}

