package maximoRepetido;

interface IComplejo {
	public double getReal(); // Devuelve la parte real

	public double getImaginaria(); // Devuelve la parte imaginaria

	public double getModulo(); // Devuelve el modulo

	public double getArgumento(); // Devuelve el argumento

	public IComplejo suma(IComplejo c); // Devuelve un Complejo sumando ’c’

	public IComplejo resta(IComplejo c); // Devuelve un Complejo restando ’c’

	public IComplejo conj(IComplejo c); // Devuelve un Complejo conjugando ’c’
}

public class Utils {

	public static int maxNumRepeated(Integer[] l, Integer elem) {
		int solucion = 0;
		int aux = 0;
		if (l != null) {
			for (int i = 0; i < l.length; i++) {
				if (l[i] != null && l[i].equals(elem))
					aux++;
				else {
					if (aux > solucion) solucion = aux;
					aux = 0;
				}
			}
		}
		if (aux > solucion) solucion = aux;
		return solucion;
		// return (aux>solucion ? aux : solucion);

	}
	// public static int maxNumRepeated(Integer[] l, Integer elem) {
	// int solucion = 0;
	// int aux = 0;
	// boolean seguir = true;
	//
	// for (int i = 0; i < l.length && seguir; i++) {
	// if (l.length != 0) {
	// while (l[i].equals(elem)) {
	// solucion = solucion + 1;
	// int pos=i++;
	// if(pos<l.length && l[pos].equals(elem)) {
	// solucion = 0;
	// aux = aux + 1;
	// }
	// }
	//
	// } else { // si esta vacio no haces nada
	// seguir = false;
	// }
	// }
	//
	// if (solucion > aux) {
	// return solucion;
	// } else {
	// return aux;
	// }
	//
	// }
}

// for (int a = i++; a < l.length; a++) { // comprobar el elemento siguiente
// if (l[a].equals(elem)) {
// aux = aux + 1;
// } else { // si el siguiente no es igual ocurrencias se pone a 0
// aux = 0;
// }
// boolean seguir = true;
// int aux = 0;
// if (l.length == 0) {
// aux = 0;
// seguir = false;
// }
//
// for (int i = 0; i < l.length && seguir; i++) {
//
// if (l[i] != null) {
// if (l[i].equals(elem)) { // comprobar lo que hay en i con el parametro
// aux = aux + 1;
// int pos=i++;
// if((pos< l.length) && (l[pos].equals(elem))) {
// aux=aux+1;
// }
// }
// }
// i++;
// }
