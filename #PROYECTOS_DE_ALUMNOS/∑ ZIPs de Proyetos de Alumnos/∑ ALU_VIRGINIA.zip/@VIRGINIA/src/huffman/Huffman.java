package aed.huffman;

import java.util.ArrayList;

import es.upm.aedlib.Position;
import es.upm.aedlib.tree.BinaryTree;
import es.upm.aedlib.tree.LinkedBinaryTree;

/**
 * Defines metodos for Huffman encoding of text strings.
 */
public class Huffman
{
	private LinkedBinaryTree<Character> huffmanTree;

	public Huffman(LinkedBinaryTree<Character> huffmanTree)
	{
		// NO CAMBIA ESTE METODO!!! Esta usado durante las pruebas
		this.huffmanTree = huffmanTree;
	}

	/**
	 * Creates a Huffman tree (and stores it in the attribute huffmanTree). The shape of the (binary) tree is defined by the array
	 * of char-codes.
	 */
	public Huffman(CharCode[] paths)
	{
		huffmanTree = new LinkedBinaryTree<>();
		huffmanTree.addRoot(' ');

		for (int i = 0; i < paths.length; i++)
		{
			String guardado = paths[i].getCode();
			Position<Character> nodo = huffmanTree.root();
			for (int a = 0; a < guardado.length(); a++)
			{
				char direccion = guardado.charAt(a);
				if (direccion == '1')
				{
					if (huffmanTree.right(nodo) == null)
					{
						huffmanTree.insertRight(nodo, ' ');
					}
					nodo = huffmanTree.right(nodo);
				} else
				{
					if (huffmanTree.left(nodo) == null)
					{
						huffmanTree.insertLeft(nodo, ' ');
					}
					nodo = huffmanTree.left(nodo);
				}
			}
			huffmanTree.set(nodo, paths[i].getCh());
		}
	}

	//////////////////////////////////////////////////////////////////////

	/**
	 * Huffman encodes a text, returning a new text string containing only characters '0' and '1'.
	 */
	public String encode(String text)
	{
		Position<Character> pos = this.huffmanTree.root();
		String path = "";
		ArrayList<String> lpath;
		path = "";
		for (int i = 0; i < text.length(); i++)
		{
			lpath = new ArrayList<>();
			findCharacterCode(text.charAt(i), this.huffmanTree, pos, lpath);
			for (String s : lpath)
			{
				path += s;
			}
			path = path.substring(0, path.length() - 1);
		}
		return path;
	}

	private ArrayList<String> findCharacterCode(Character ch, BinaryTree<Character> tree, Position<Character> pos,
			ArrayList<String> path)
	{
		if (pos == null) return path;
		if (path.size() > 1 && path.get(path.size() - 1).equals("X"))
		{
			return path;
		}
		if (ch.equals(pos.element()))
		{
			path.add("X");
			return path;
		} else
		{

			if (tree.hasLeft(pos))
			{
				path.add("0");
				path = findCharacterCode(ch, tree, tree.left(pos), path);

				if (path.size() > 1 && path.get(path.size() - 1).equals("X"))
				{
					return path;
				} else
				{
					path.remove(path.size() - 1);
				}
			}
			if (tree.hasRight(pos))
			{
				path.add("1");
				path = findCharacterCode(ch, tree, tree.right(pos), path);

				if (path.size() > 1 && path.get(path.size() - 1).equals("X"))
				{
					return path;
				} else
				{
					path.remove(path.size() - 1);
				}
			}
		}
		return path;
	}

	//////////////////////////////////////////////////////////////////////

	/**
	 * Given the Huffman encoded text argument (a string of only '0' and '1's), returns the corresponding normal text.
	 */
	public String decode(String encodedText)
	{
		String resultado = "";
		char contenido;

		Position<Character> pos = huffmanTree.root();
		int i = 0;
		contenido = encodedText.charAt(i);

		// ELIJO YA EN POS EL NODO DEL PRIMER NIVEL DEL ARBOL
		pos = (contenido == '1') ? huffmanTree.right(pos) : huffmanTree.left(pos);
		// if (pos.element() != ' ') // HAY CONTENIDO EN EL NODO DE PRIMER NIVEL
		// {
		// resultado += pos.element();
		// }

		while (i < encodedText.length())
		{
			// i++;
			if (pos.element() != ' ') // HAY CONTENIDO EN EL NODO
			{
				resultado += pos.element();
				i++;
				// ELIJO YA EN POS EL NODO DEL PRIMER NIVEL DEL ARBOL
				pos = huffmanTree.root();
				pos = (contenido == '1') ? huffmanTree.right(pos) : huffmanTree.left(pos);
			} else
			{
				i++;
				contenido = encodedText.charAt(i);
				pos = (contenido == '1') ? huffmanTree.right(pos) : huffmanTree.left(pos);
			}
		}
		return resultado;
	}
}

// boolean findCharacterCode(BinaryTree<Character> tree, Position<Character> pos, Character ch,
// ArrayList<String> path)
// {
// boolean ret = false;
// boolean flag = false;
// if (ch.equals(pos.element()))
// {
// // path ;
// return true;
// }
//
// if (tree.hasLeft(pos))
// {
// path.add("0");
// flag = true;
// ret = findCharacterCode(tree, tree.left(pos), ch, path);
// }
//
// if (!ret)
// {
// if (tree.hasRight(pos))
// {
// if (!flag)
// {
// path.add("1");
// }
// ret = findCharacterCode(tree, tree.left(pos), ch, path);
// }
// }
//
// if (!ret)
// {
// path.remove(path.size() - 1);
//
// // path = path.substring(0, path.length() - 1);
// }
//
// return ret;
// }
//
// public Boolean findCharacterCode(BinaryTree<Character> tree, Position<Character> pos, Character ch, int direccion)
// {
// if (pos == null) return false;
// if (ch.equals(pos.element()) || findCharacterCode(tree, tree.left(pos), ch, 1)
// || findCharacterCode(tree, tree.right(pos), ch, 0))
// {
// System.out.print(" " + pos.element());
// // path.add(root.data);
// return true;
// }
// return false;
// }

// // CAMBIA e UTILIZA si quiereis
// private String findCharacterCode(String auxi, Character ch, BinaryTree<Character> tree, Position<Character> pos,
// String path)
// {
// if (pos == null) return path;
//
// if (ch.equals(pos.element()))
// {
// auxi = path;
// return path;
// } else
// {
// // if (tree.hasLeft(pos)) {
// path = findCharacterCode(auxi, ch, tree, tree.left(pos), path + "0");
// // } if (tree.hasRight(pos)) {
// path = findCharacterCode(auxi, ch, tree, tree.right(pos), path + "1");
// // }
// }
// return path;
// }

// pr