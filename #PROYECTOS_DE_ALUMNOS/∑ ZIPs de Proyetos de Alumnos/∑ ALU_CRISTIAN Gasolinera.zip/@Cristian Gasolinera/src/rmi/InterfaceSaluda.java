import java.rmi.Remote;
import java.rmi.RemoteException;

public interface InterfaceSaluda extends Remote
{
    String saludar(String nombre) throws RemoteException;
    String saludar2(String nombre) throws RemoteException;
    String saludar3(String nombre) throws RemoteException;
}
