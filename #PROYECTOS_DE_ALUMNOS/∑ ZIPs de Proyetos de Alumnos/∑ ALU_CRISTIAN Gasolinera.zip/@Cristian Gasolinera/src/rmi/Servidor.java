import java.rmi.*;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
 
public class Servidor
{ 
    public static void main(String args[])
    {
        try
        {
           // publicamos el metodo 1
            Saludador obj = new Saludador(); //Crea una instancia del objeto que implementa la interfaz, como objeto a registrar
            Registry registry = LocateRegistry.createRegistry(1099); //Arranca rmiregistry local en el puerto 1099
            Naming.rebind("//localhost/ObjetoSaluda",obj);   //rebind sólo funciona sobre una url del equipo local 
            System.out.println("El Objeto Saluda ha quedado registrado");

           // publicamos el metodo 2
            Saludador obj2 = new Saludador(); //Crea una instancia del objeto que implementa la interfaz, como objeto a registrar
//            Registry registry = LocateRegistry.createRegistry(1098); //Arranca rmiregistry local en el puerto 1099
            Naming.rebind("//localhost/ObjetoSaluda2",obj2);   //rebind sólo funciona sobre una url del equipo local
            System.out.println("El Objeto Saluda2 ha quedado registrado");

           // publicamos el metodo 3
            Saludador obj3 = new Saludador(); //Crea una instancia del objeto que implementa la interfaz, como objeto a registrar
//            Registry registry = LocateRegistry.createRegistry(1098); //Arranca rmiregistry local en el puerto 1099
            Naming.rebind("//localhost/ObjetoSaluda3",obj3);   //rebind sólo funciona sobre una url del equipo local
            System.out.println("El Objeto Saluda3 ha quedado registrado");
        }
        catch (Exception e)
        {
            System.out.println(" Error: " + e.getMessage());
            e.printStackTrace();
        }
    }
}