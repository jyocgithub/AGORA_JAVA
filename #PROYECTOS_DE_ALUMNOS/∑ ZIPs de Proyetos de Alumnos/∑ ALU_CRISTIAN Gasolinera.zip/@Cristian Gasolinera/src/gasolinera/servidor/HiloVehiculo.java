package servidor;

/**
 * Clase que crea un hilo de Vehiculo.
 * @author CristianDiaz,ManuelaLopez
 */
public class HiloVehiculo implements Runnable {

    private Gasolinera gasolinera;
    private Utilidades util;
    private Vehiculo vehiculo;
    private Servidor servidor;
    private Paso paso;

     /**
     * Constructor de la clase HiloVehiculo.
     *
     * @param gasolinera : Gasolinera
     * @param servidor : Servidor
     * @param util : Utilidades es una clase multiusos.
     * @param vehiculo : Vehiculo
     * @param paso : Paso
     */
    public HiloVehiculo(Servidor servidor, Utilidades util, Vehiculo vehiculo, Gasolinera gasolinera, Paso paso) {
        this.gasolinera = gasolinera;
        this.servidor = servidor;
        this.util = util;
        this.vehiculo = vehiculo;
        this.paso = paso;
    }

     /**
     * Método que arranca el hilo al ser lanzado.
     */
    public void run() {

        util.espera(3000, 10000);
        paso.mirar();
        servidor.añadirColaEspera(vehiculo);
        paso.mirar();
        servidor.pintarColaEspera();
        paso.mirar();
        Surtidor surtidor = null;
        paso.mirar();

        switch (vehiculo.getTipoVehiculo()) {

            case Vehiculo.COMBUSTIBLE:
                surtidor = gasolinera.cogerSurtidorCombustible(this);
                paso.mirar();
                servidor.eliminarColaEspera(vehiculo);
                servidor.pintarColaEspera();
                paso.mirar();
                gasolinera.esperar(surtidor);
                paso.mirar();
                gasolinera.liberarSurtidor(surtidor);
                break;
            case Vehiculo.ELECTRICO:
                surtidor = gasolinera.cogerSurtidorElectrico(this);
                paso.mirar();
                servidor.eliminarColaEspera(vehiculo);
                servidor.pintarColaEspera();
                paso.mirar();
                gasolinera.esperar(surtidor);
                paso.mirar();
                gasolinera.liberarSurtidor(surtidor);
                break;

            case Vehiculo.PESADO:
                surtidor = gasolinera.cogerSurtidorPesados(this);
                paso.mirar();
                servidor.eliminarColaEspera(vehiculo);
                servidor.pintarColaEspera();
                paso.mirar();
                gasolinera.esperar(surtidor);
                paso.mirar();
                gasolinera.liberarSurtidor(surtidor);
                break;

        }

    }

     /**
     * Método getter de Vehiculo.
     *
     * @return vehiculo : Vehiculo
     */
    public Vehiculo getVehiculo() {
        return vehiculo;
    }

     /**
     * Metodo setter del Vehiculo.
     *
     * @param vehiculo : Vehiculo
     */
    public void setVehiculo(Vehiculo vehiculo) {
        this.vehiculo = vehiculo;
    }
}
