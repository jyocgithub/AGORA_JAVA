/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package servidor;

/**
 * Clase que crea un hilo de Operario.
 * @author CristianDiaz,ManuelaLopez
 */
public class HiloOperario implements Runnable {

    private Gasolinera gasolinera;
    private Operario operario;
    private Paso paso;
     
     /**
     * Constructor de la clase HiloOperario.
     *
     * @param gasolinera : Gasolinera
     * @param operario : Operario
     * @param paso : Paso
     */
    public HiloOperario(Gasolinera gasolinera, Operario operario, Paso paso) {
        this.operario = operario;
        this.gasolinera = gasolinera;
        this.paso = paso;
    }

     /**
     * Método que arranca el hilo al ser lanzado.
     */
    public void run() {

        while (true) {
            paso.mirar();
            gasolinera.atenderVehiculo(this);
            paso.mirar();

        }

    }

     /**
     * Método getter de Operario.
     *
     * @return operario : Operario
     */
    public Operario getOperario() {
        return operario;
    }

    /**
     * Metodo setter del Operario.
     *
     * @param operario : Operario
     */
    public void setOperario(Operario operario) {
        this.operario = operario;
    }

}
