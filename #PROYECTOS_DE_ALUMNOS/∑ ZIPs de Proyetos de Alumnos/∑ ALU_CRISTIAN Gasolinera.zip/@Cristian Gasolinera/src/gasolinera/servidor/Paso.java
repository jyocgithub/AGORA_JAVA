package servidor;

import java.io.Serializable;

/**
 * Clase que controla la ejecución.
 *
 * @author CristianDiaz,ManuelaLopez
 */
public class Paso implements Serializable {

    private boolean cerrar = false;
    private boolean pulsado = false;

    /**
     * Método que se encarga de bloquear o permitir el paso.
     */
    public synchronized void mirar() {
        while (cerrar) {
            try {
                wait();
            } catch (InterruptedException ie) {
            }
        }
    }

    /**
     * Método que despierta a los hilos que estan en un await();.
     */
    public synchronized void abrir() {
        cerrar = false;
        notifyAll();
        pulsado = true;
    }

    /**
     * Método que cambia el valor de una variable de control.
     */
    public synchronized void cerrar() {
        cerrar = true;
        pulsado = true;
    }

    /**
     * Método getter de Estado.
     *
     * @return cerrar : boolean
     */
    public boolean getEstado() {
        return cerrar;
    }

    /**
     * Metodo setter del Estado.
     *
     * @param estado : boolean
     */
    public synchronized void setEstado(boolean estado) {
        cerrar = estado;
        if (!estado) {
            notifyAll();

        }
    }

    /**
     * Método getter de Pulsado.
     *
     * @return pulsado : boolean
     */
    public boolean getPulsado() {
        return pulsado;
    }

    /**
     * Metodo setter del Estado.
     *
     * @param estado : boolean
     */
    public void setPulsado(boolean estado) {
        pulsado = estado;
    }

}
