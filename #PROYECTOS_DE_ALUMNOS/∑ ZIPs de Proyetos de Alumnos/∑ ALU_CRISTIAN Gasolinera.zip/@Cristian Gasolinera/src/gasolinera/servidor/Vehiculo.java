package servidor;

import java.awt.Color;
import java.awt.Image;

import java.io.Serializable;

/**
 * Clase que crea un Vehiculo.
 *
 * @author CristianDiaz,ManuelaLopez
 */
public class Vehiculo implements Serializable {

    public static final int ELECTRICO = 0;
    public static final int COMBUSTIBLE = 1;
    public static final int PESADO = 2;

    private int id;
    private int tipoVehiculo;
    private Utilidades util;

    private int litrosRepostados = 0;
    private String matricula;
    private Color colorCoche;
    private Image imagen;

    /**
     * Constructor de la clase Vehiculo.
     *
     * @param id : int
     * @param tipoVehiculo : int que indica que tipo de carro que sera.
     * @param matricula : String
     * @param util : Utilidades es una clase multiusos.
     */
    public Vehiculo(int id, int tipoVehiculo, String matricula, Utilidades util) {
        this.id = id;
        this.tipoVehiculo = tipoVehiculo;
        this.matricula = matricula;
        this.util = util;
        colorCoche = escogerColor();
    }

    /**
     * Metodo que escoge y retorna el color del coche, se reserva el 255, 255,
     * 255 para cuando se quiera meter un null.
     *
     * @return new Color
     */
    public Color escogerColor() {
        int R = util.aleatorio(1, 250);
        int G = util.aleatorio(1, 250);
        int B = util.aleatorio(1, 250);
        return new Color(R, G, B);
    }

    /**
     * Método getter de LitrosRepostados.
     *
     * @return litrosRepostados : int
     */
    public int getLitrosRepostados() {
        return litrosRepostados;
    }

    /**
     * Metodo setter del LitrosRepostados.
     *
     * @param litrosRepostados : int
     */
    public void setLitrosRepostados(int litrosRepostados) {
        this.litrosRepostados = litrosRepostados;
    }

    /**
     * Método getter de Matricula.
     *
     * @return matricula : String
     */
    public String getMatricula() {
        return matricula;
    }

    /**
     * Metodo setter del Matricula.
     *
     * @param matricula : String
     */
    public void setMatricula(String matricula) {
        this.matricula = matricula;
    }

    /**
     * Método getter de TipoVehiculo.
     *
     * @return tipoVehiculo : int
     */
    public int getTipoVehiculo() {
        return tipoVehiculo;
    }

    /**
     * Metodo setter del TipoVehiculo.
     *
     * @param tipoVehiculo : int
     */
    public void setTipoVehiculo(int tipoVehiculo) {
        this.tipoVehiculo = tipoVehiculo;
    }

    /**
     * Método getter de Id.
     *
     * @return id : int
     */
    public int getId() {
        return id;
    }

    /**
     * Metodo setter del Id.
     *
     * @param id : int
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * Método getter de ColorCoche.
     *
     * @return colorCoche : Color
     */
    public Color getColorCoche() {
        return colorCoche;
    }

    /**
     * Metodo setter del ColorCoche.
     *
     * @param colorCoche : Color
     */
    public void setColorCoche(Color colorCoche) {
        this.colorCoche = colorCoche;
    }

    /**
     * Método getter de Imagen.
     *
     * @return imagen : Image
     */
    public Image getImagen() {
        return imagen;
    }

}
