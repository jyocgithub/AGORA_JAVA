/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package servidor;

import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;

/**
 * Clase que crea un SocketServidor para comprobar la ejecucion.
 *
 * @author CristianDiaz,ManuelaLopez
 */
public class SocketServidorEjecucion extends Thread {

    private Socket socket;
    private Paso paso;
    private ObjectOutputStream salida;
    private ObjectInputStream entrada;

     /**
     * Constructor de la clase SocketServidorEjecucion.
     *
     * @param paso : Paso
     * @param socket : Socket
     */
    public SocketServidorEjecucion(Paso paso, Socket socket) {
        this.paso = paso;
        this.socket = socket;
    }

     /**
     * Método que arranca el hilo al ser lanzado.
     */
    public void run() {
        try {
            while (true) {

                salida = new ObjectOutputStream(socket.getOutputStream());
                entrada = new ObjectInputStream(socket.getInputStream());
                boolean cerrar = (boolean) (entrada.readObject());
                if (cerrar) {
                    paso.cerrar();
                } else {
                    paso.abrir();
                }
            }

        } catch (Exception ex) {
            ex.printStackTrace();
        }

    }

}
