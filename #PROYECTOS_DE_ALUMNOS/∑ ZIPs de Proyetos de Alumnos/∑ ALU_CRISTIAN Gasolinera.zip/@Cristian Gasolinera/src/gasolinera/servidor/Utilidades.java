package servidor;

import java.io.FileWriter;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Random;

/**
 * Clase que contiene metodos varios.
 *
 * @author CristianDiaz,ManuelaLopez
 */
public class Utilidades {

    private String log = "";

    /**
     * Metodo que retorna un numero aleatorio para simular una espera.
     *
     * @param desde : int
     * @param hasta : int
     *
     * @return tiempo : int
     */
    public int espera(int desde, int hasta) {
        int tiempo = 0;
        try {
            tiempo = aleatorio(desde, hasta);
            Thread.sleep(tiempo);
        } catch (Exception ex) {

        }
        return tiempo;
    }

    /**
     * Metodo que selecciona un numero aleatorio.
     * @param desde : int
     * @param hasta : int
     *
     * @return new Random
     */
    public int aleatorio(int desde, int hasta) {
        return new Random().nextInt((hasta - desde) + desde);
    }

    /**
     * Método que se encarga de mostrar el mensaje.
     *
     * @param mensaje : String
     */
    public synchronized void sout(String mensaje) {
        Date fecha = Calendar.getInstance().getTime();
        String fechaTexto = new SimpleDateFormat("dd/MM/yyyy hh:mm:ss.SSS").format(fecha);
        mensaje = fechaTexto + " - " + mensaje;
        //System.out.println(mensaje);
        PrintWriter pw = null;
        try {
            pw = new PrintWriter(new FileWriter("LogGasolinera.txt", true));
            log += "\n " + mensaje;
            pw.println(mensaje);
        } catch (Exception ex) {

        } finally {
            pw.close();
        }
    }

    /**
     * Método getter de Log.
     *
     * @return log : String
     */
    public String getLog() {
        return log;
    }

}
