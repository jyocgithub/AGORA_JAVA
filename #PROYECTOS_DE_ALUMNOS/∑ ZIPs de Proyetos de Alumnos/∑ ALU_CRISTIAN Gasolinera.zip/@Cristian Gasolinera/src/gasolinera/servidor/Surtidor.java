package servidor;

import java.io.Serializable;

/**
 * Clase que crea un Surtidor
 *
 * @author CristianDiaz,ManuelaLopez
 */
public class Surtidor implements Serializable {

    public static final int OCUPADO = 1;
    public static final int LIBRE = 0;
    public static final int REPOSTANDO = 2;

    public static final String COMBUSTIBLE = "Combustible";
    public static final String ELECTRICO = "Electrico";
    public static final String PESADOS = "Pesados";

    private int estado;
    private int id;
    private String combustible;
    private Vehiculo vehiculo;
    private Operario pollo;

    private boolean continuar = true;

    /**
     * Constructor de la clase Surtidor.
     *
     * @param id : int numero de cada surtidor, del 1 al 8 incluidos.
     * @param combustible : String
     */
    public Surtidor(int id, String combustible) {
        estado = LIBRE;
        this.id = id;
        this.combustible = combustible;
    }

    /**
     * Método que se encarga de cambiar el estado del surtidor.
     *
     * @param estado : boolean
     */
    public void cambiarContinuar(boolean estado) {
        continuar = estado;
    }

    /**
     * Método que retorna si se puede continuar o debe esperar a ser repostado.
     *
     * @return continuar : boolean
     */
    public boolean consultarContinuar() {
        return continuar;
    }

    /**
     * Método getter de Vehiculo.
     *
     * @return vehiculo : Vehiculo
     */
    public Vehiculo getVehiculo() {
        return vehiculo;
    }

    /**
     * Metodo setter del Vehiculo.
     *
     * @param vehiculo : Vehiculo
     */
    public void setVehiculo(Vehiculo vehiculo) {
        this.vehiculo = vehiculo;
    }

    /**
     * Método getter de Estado.
     *
     * @return estado : int
     */
    public int getEstado() {

        return estado;
    }

    /**
     * Método getter de EstadoString.
     *
     * @return devolver : String
     */
    public String getEstadoString() {
        String devolver = " ";
        switch (estado) {
            case OCUPADO:
                devolver = "OCUPADO";
                break;

            case LIBRE:
                devolver = "LIBRE";
                break;
            case REPOSTANDO:
                devolver = "REPOSTANDO";
                break;
        }
        return devolver;
    }

    /**
     * Método getter de Pollo.
     *
     * @return pollo : Operario
     */
    public Operario getPollo() {
        return pollo;
    }

    /**
     * Metodo setter del Pollo.
     *
     * @param pollo : Operario
     */
    public void setPollo(Operario pollo) {
        this.pollo = pollo;
    }

    /**
     * Metodo setter del Estado.
     *
     * @param estado : int
     */
    public void setEstado(int estado) {
        this.estado = estado;
    }

    /**
     * Método getter de Combustible.
     *
     * @return combustible : String
     */
    public String getCombustible() {
        return combustible;
    }

    /**
     * Metodo setter del Combustible.
     *
     * @param combustible: String
     */
    public void setCombustible(String combustible) {
        this.combustible = combustible;
    }

    /**
     * Método getter de Id.
     *
     * @return id : int
     */
    public int getId() {
        return id;
    }

    /**
     * Metodo setter del Id.
     *
     * @param id : int
     */
    public void setId(int id) {
        this.id = id;
    }

}
