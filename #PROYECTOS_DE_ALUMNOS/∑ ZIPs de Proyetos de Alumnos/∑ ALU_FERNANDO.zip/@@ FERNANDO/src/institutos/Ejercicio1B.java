package institutos;
/**
*  EAC 6 (FICHEROS)
*  EJERCICIO 2
*  Programa que ordena valores enteros de un fichero binario. 
*  
*  author Fernando Gamero Rodríguez
*/

import java.io.File;
import java.io.RandomAccessFile;
import java.util.Scanner;

public class Ejercicio1B {
   
   public static void main(String[] args){
       Ejercicio1B fb = new Ejercicio1B();
       final String rutaFichero = "Enters.bin";
       
       try {
           File f = new File (rutaFichero);
           RandomAccessFile raf = new RandomAccessFile(f, "rw");            
           fb.crearFichero(rutaFichero, f, raf);
           fb.ordenarFichero(rutaFichero, f, raf);
       } catch (Exception ex) {
           System.out.println("Se ha producido una excepción (controlada o no) error: " + ex.getMessage());
       }
   }
   
   /**
    * Ordena los valores enteros de mayor a menor.
    * @param rutaFichero ruta con el fichero a crear.
    * @param f 
    * @param raf
    * @throws Exception genera un error que será tratado fuera de este método
    */
   public void ordenarFichero(String rutaFichero, File f, RandomAccessFile raf) throws Exception{
       //Cada INT ocupa 4 byes, per tant, cal avançar de 4 en 4
       for (int i = 0; i < f.length(); i = i + 4) {
           for (int j = i + 4; j < f.length(); j = j + 4) {
               //Es llegeix el valor a la posició "i"
               raf.seek(i);
               int valorI = raf.readInt();
               //Es llegeix el valor a la posició "j"
               raf.seek(j);
               int valorJ = raf.readInt();
               //Es comparen
               if (valorI > valorJ) {
                   //Si "i" major que "j", s’intercanvien el lloc
                   raf.seek(i);
                   raf.writeInt(valorJ);
                   raf.seek(j);
                   raf.writeInt(valorI);
               }
           }
       }
      
       
       
       // lectura del fichero de prueba de resultado 
       leerFichero(f,raf);

       raf.close();
       
       
   }
   
   
   
   /** Crea un fichero binario con nombre 'rutaFichero'
    * con datos numéricos que pide al usuario
    * @param rutaFichero ruta con el fichero a crear, 
    *          ejemplo:  c:\windows\numeros.bin
    * @param f
    * @param raf
    * @throws  Exception Genera un error que será tratado fuera de este método
    */
   public void crearFichero(String rutaFichero, File f, RandomAccessFile raf) throws Exception {
       Scanner teclado = new Scanner(System.in);
       //Escribimos en el fichero cinco números que se piden al usuario
       
       
       for(int contador= 0; contador <5; contador++){
           System.out.println("Dime el valor para el registro núm " + contador + " del fichero");
           int numeroDadoPorUsuario = teclado.nextInt();
    
           raf.seek(contador*4);  //Se posiciona (seek) en el registro/byte número 'contador'
           raf.writeInt(numeroDadoPorUsuario);
           //ims 
           //raf.writeUTF(numeroDadoPorUsuario+"");
       }
       
       
       // lectura del fichero de prueba de resultado 
       leerFichero(f,raf);
       //raf.close();
   }
   
   
   
   public void leerFichero(File f, RandomAccessFile raf) throws Exception {
	   
       // lectura del fichero de prueba de resultado 
       for (int i = 0; i < f.length(); i = i + 4) {
               raf.seek(i);
               int valorI = raf.readInt();
               System.out.println("Valor leido del fichero :"+valorI);
       }
       System.out.println("");
   
   }
   
   
   
   
   
}