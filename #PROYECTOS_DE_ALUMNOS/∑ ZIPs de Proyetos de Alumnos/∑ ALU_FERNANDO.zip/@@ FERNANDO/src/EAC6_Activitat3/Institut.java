package EAC6_Activitat3;

public class Institut {

		private int id;
		private String nom;
		private String equip;
		private int punts;
		public Institut(int id, String nom, String equip, int punts) {
			super();
			this.id = id;
			this.nom = nom;
			this.equip = equip;
			this.punts = punts;
		}
		public int getId() {
			return id;
		}
		public void setId(int id) {
			this.id = id;
		}
		public String getNom() {
			return nom;
		}
		public void setNom(String nom) {
			this.nom = nom;
		}
		public String getEquip() {
			return equip;
		}
		public void setEquip(String equip) {
			this.equip = equip;
		}
		public int getPunts() {
			return punts;
		}
		public void setPunts(int punts) {
			this.punts = punts;
		}
		
		
}
