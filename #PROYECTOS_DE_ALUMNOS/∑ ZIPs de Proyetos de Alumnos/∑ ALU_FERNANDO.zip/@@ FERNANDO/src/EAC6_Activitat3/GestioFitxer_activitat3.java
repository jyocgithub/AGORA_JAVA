package EAC6_Activitat3;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.RandomAccessFile;

import java.util.Scanner;

public class GestioFitxer_activitat3 {
	//public Scanner sc2 = new Scanner(System.in);
	String fichero = "Partides.dat";
	File f ;
	RandomAccessFile raf ; 
	Institut [] arrayDeInstitutos;
	int pos;
	int mayor  =0, media=0;
	

	
	//********************************************************************************************
	public void introducirPuntos(){
		int suma = 0;
		for (int i = 0; i < arrayDeInstitutos.length; i++) {
			System.out.println("Nom del Institut "+i+".");			
			System.out.println("Cuantos puntos consiguió?");
			int pun  = leerIntDeTeclado();
			arrayDeInstitutos[i].setPunts(pun);
			suma = suma + arrayDeInstitutos[i].getPunts();
			if (arrayDeInstitutos[i].getPunts() > mayor ) {
				mayor = arrayDeInstitutos[i].getPunts() ;
			}
		}
		media = suma / arrayDeInstitutos.length;
		
	}
	
	
	public void mostrarEquiposConMasPuntos(){
		//int mayor  =0;
		System.out.println("Puntuacion mas alta:"+mayor+", conseguida por:");			

		for (int i = 0; i < arrayDeInstitutos.length; i++) {
			if (arrayDeInstitutos[i].getPunts() == mayor ) {
				System.out.println("- Institut "+i+".");			
			}
		}
	}
	
	//********************************************************************************************
	public void mostrarMejoresPorcentajes(){
		System.out.println("Puntuacion mas alta es:"+mayor);
		System.out.println("Puntuacion media es de:"+media);
		
		// numInstitutosPorEncimaDeLaMedia ha de ser double, 
		// pues las operaciones posteriores pueden dar decimal
		// si no es double los decimales se pasan a enteros
		double numInstitutosPorEncimaDeLaMedia = 0;
		
		for (int i = 0; i < arrayDeInstitutos.length; i++) {
			if (arrayDeInstitutos[i].getPunts() >= media ) {
				numInstitutosPorEncimaDeLaMedia++;			
			}
		}
		double porcen =  numInstitutosPorEncimaDeLaMedia / arrayDeInstitutos.length  ;
		int totPorEncima = (int) (porcen*100);
		System.out.println("Hay "+numInstitutosPorEncimaDeLaMedia+" institutos por encima de la media");
		System.out.println("Que suponen el "+totPorEncima+" % de participantes por encima de la media");
		
		
	}
	
	
	//********************************************************************************************
	public void guardarInstitutosEnFichero(){

		abrirficheroParaEscribir();

		try {
			// escribir en el fichero el array de institutos el numero de institutos
			pos = 0 ;
			raf.seek(pos);
			raf.writeInt(arrayDeInstitutos.length);
			int indiceArray = 0;
			
			for (int i = 0; i < arrayDeInstitutos.length; i++) {

				// escribir en el fichero el array de institutos 

				pos = i * 48  + 4;
				raf.seek(pos);
				raf.writeInt(arrayDeInstitutos[indiceArray].getId());

				pos +=4;
				raf.seek(pos);
				raf.writeChars(arrayDeInstitutos[indiceArray].getNom());

				pos +=20;
				raf.seek(pos);
				raf.writeChars(arrayDeInstitutos[indiceArray].getEquip());

				pos +=20;
				raf.seek(pos);
				raf.writeInt(arrayDeInstitutos[indiceArray].getPunts());

				indiceArray++;
				
				
			}

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		cerrarFichero();
		System.out.println("Fin de escritura de Institutos en fichero");
	}

	
	//********************************************************************************************
		public void leerInstitutodPorTeclado(){
			
			System.out.println("Cuantos institutos vamos a crear?");
			int cantInst = leerIntDeTeclado();
			arrayDeInstitutos = new Institut [cantInst];

			for (int i = 0; i < arrayDeInstitutos.length; i++) {

				System.out.println("Nom del Institut"+i+" ?");
				String nomb = leerStringDeTeclado();

				System.out.println("Nom del equip?");
				String equ = leerStringDeTeclado();

				Institut in = new Institut (i,nomb,equ,0);
				arrayDeInstitutos[i] = in;

			}
		}

		
		
	//********************************************************************************************
	public void leerInstitutosDesdeFichero(){

		abrirficheroParaLeer();
		int pos, v1, v4;
		String v2, v3;
		int indiceArray  = 0;
		
		if (arrayDeInstitutos == null){
			pos = 0 ;
			v1 = leerIntDeBinario(raf, pos);
			arrayDeInstitutos = new Institut [v1];
		}
		for (int i = 4; i < f.length(); i = i + 48) {
			pos = i ;
			v1 = leerIntDeBinario(raf, pos);

			pos +=4;
			v2 = leerPalabraDeBinario(raf,pos);

			pos +=20;
			v3 = leerPalabraDeBinario(raf,pos);

			pos += 20;
			v4 = leerIntDeBinario(raf,pos);
			
			Institut in = new Institut (v1,v2,v3,v4);
			
			arrayDeInstitutos[indiceArray] = in;
			indiceArray++;
		}
		
		cerrarFichero();
		System.out.println("Fin de lectura de Institutos desde fichero");
	}
	
	//********************************************************************************************
	public void listarInstitutosPorPantalla(){

		for (int i = 0; i < arrayDeInstitutos.length; i ++) {
			
			System.out.println("Id del equipo :"+arrayDeInstitutos[i].getId());
			System.out.println("Nom del institut :"+ arrayDeInstitutos[i].getNom());
			System.out.println("Nom del equip :"+arrayDeInstitutos[i].getEquip());
			System.out.println("Punts :"+ arrayDeInstitutos[i].getPunts());
			System.out.println("--------------------------------------");
		}
	}
	//********************************************************************************************
	public int leerIntDeBinario(RandomAccessFile raf, int pos) {
		try {
			raf.seek(pos);

			int result = raf.readInt();
			return result ;
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return 0;
		}
	}


	//********************************************************************************************
	public String leerStringDeTeclado(){
		Scanner sc = new Scanner(System.in);
		return sc.nextLine();


	}

	//********************************************************************************************
	public int leerIntDeTeclado(){
		Scanner sc = new Scanner(System.in);
		return sc.nextInt();


	}


	//********************************************************************************************
	public String leerPalabraDeBinario(RandomAccessFile raf, int pos) { try {

		String pal = "";
		raf.seek(pos);
		char c = raf.readChar();
		while (c != 0x0000) { 
			pal = pal + c;
			c = raf.readChar();
		}
		return pal;
	} 
	catch (Exception e) { 
		return null;
	} 
	}


	//********************************************************************************************
	public void abrirficheroParaEscribir(){
		f = new File (fichero);
		try {
			raf = new RandomAccessFile(f, "rw");
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}  

	}

	//********************************************************************************************
	public void abrirficheroParaLeer(){
		f = new File (fichero);
		try {
			raf = new RandomAccessFile(f, "r");
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}  

	}  

	//********************************************************************************************
	public void cerrarFichero(){
		try {
			raf.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
}
