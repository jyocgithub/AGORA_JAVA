package EAC6_Activitat2;

import java.util.Scanner;


public class EAC6_Activitat2 {

	   public static void main(String[] args){
	       
		   GestioFitxer_activitat2 gf = new GestioFitxer_activitat2();
		   
		   // pintar menu y llamar a opciones principales
		   int opcion = 0;
		   do{	
			   // pintar menu
			   opcion = pintarMenu();
			   
			   // elegir opcion de menu
			   switch (opcion){
			   case 1:
				   gf.leerInstitutodPorTeclado();
				   gf.guardarInstitutosEnFichero();
				   break;
			   case 2:
				   gf.listarInstitutosPorPantalla();
				   break;
			   case 3:
				   gf.guardarInstitutosEnFichero();
				   break;
			   case 4:
				   gf.leerInstitutosDesdeFichero();
				   break;
			   }

		   }while (opcion !=0) ;

	   }
	
	   public static int pintarMenu(){
		   System.out.println("");
		   System.out.println("------------------------------------------------ ");
		   System.out.println("MENU ");
		   System.out.println("------------------------------------------------ ");
		   System.out.println("1.- Introducir los institutos participantes y guardar en fichero");
		   System.out.println("2.- Listar institutos existentes");
		   System.out.println("3.- Guardar institutos en fichero binario");
		   System.out.println("4.- Recuperar institutos de fichero binario");
		   System.out.println("0.- Fin");
		   System.out.println("------------------------------------------------ ");
		   System.out.println("Indique la opcion deseada: ");
		   Scanner sc = new Scanner(System.in);
		   int op= sc.nextInt();
		   return op;
	   }
}
