package cap50_a_02_fabricadetrajes.excepciones;

public class MuchoExtracomunitarioException extends Exception {
    public MuchoExtracomunitarioException(String mensaje) {
        super(mensaje) ;
    }
}
