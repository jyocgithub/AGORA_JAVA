package cap50_a_02_fabricadetrajes.excepciones;

public class MangasException extends Exception {
    public MangasException(String mensaje) {
        super(mensaje) ;
    }
}
