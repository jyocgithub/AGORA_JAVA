package cap50_a_02_fabricadetrajes.excepciones;

public class IdException extends Exception {
    public IdException(String mensaje) {
        super(mensaje) ;
    }
}
