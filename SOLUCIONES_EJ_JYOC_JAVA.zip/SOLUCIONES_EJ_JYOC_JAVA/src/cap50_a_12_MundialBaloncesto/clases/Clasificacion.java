package cap50_a_12_MundialBaloncesto.clases;

import java.util.ArrayList;

public class Clasificacion {
	
	
	private ArrayList<Seleccion> selecciones;
	

	public void clasificar() {
		
	}
	
	

}
