package cap50_a_12_MundialBaloncesto.interfaces;

public interface InterfazComponentes {

	void concentrarse();

	void entrenar();

	void viajar();

	void jugarPartido();
}
